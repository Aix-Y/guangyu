/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GSYNC_LIBRA_GSYNC_LIBRA_H_
#define HARDWARE_GSYNC_LIBRA_GSYNC_LIBRA_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "device/dtus/libra/register_soc.h"
#include "hardware/include/gsync/gsync.h"

namespace efvf {
namespace hardware {
namespace gsync {

#define LIBRA_GSYNC_ENTRY_NUM 256
#define LIBRA_GSYNC_THREAD_NUM 128
#define DIE_ADDR_OFFSET (0x800000)
class GsyncLibra : public Gsync {
 public:
    explicit GsyncLibra(std::shared_ptr<spdlog::logger> logger) : Gsync(logger) {
        inited_ = false;
    }
    virtual ~GsyncLibra() {}

    virtual bool HwInit();
    virtual void ClearSingleEntry(uint32_t entry_id);
    virtual void ClearAllEntries();
    virtual void ClearSingleThread(uint32_t thread_id);
    virtual void ClearAllThreads();

    virtual void Wait(const GsyncCtxCfg &ctx_cfg);
    virtual void Signal(const GsyncCtxCfg &ctx_cfg);
    virtual bool CheckEntryValidStatus(uint32_t entry_id);
    virtual uint32_t GetEntryCtxId(uint32_t entry_id);
    virtual uint32_t GetEntryAsId(uint32_t entry_id);
    virtual void GetSingleEntryData(GsyncCtxCfg *ctx_cfg);
    virtual uint32_t GetSingleCntData(uint32_t thread_id);
    virtual uint8_t GetSingleCntMode(uint32_t thread_id);
    virtual uint32_t GetGsyncBaseAddr();
    virtual uint32_t GetGsyncCntAddr(uint32_t thread_id);
    virtual uint32_t GetWcbValue(uint32_t thread_id);

    virtual uint32_t GetMaxEntryNum();
    virtual uint32_t GetMaxThreadNum();

    virtual uint32_t GetMaxOutstanding();
    virtual void SetMaxOutstanding(uint32_t outstd_val);
    virtual void SetWakeupMode(GsyncWakeupMode wakeup_mode);
    virtual void SetSelfClear(const GsyncSelfClearCfg &clear_cfg);
    // virtual void SetMaxMinMasterId(const GsyncCtxCfg &ctx_cfg);

    virtual void SetGsyncSramParityErrEnjCountOneTime(uint32_t par_err_enj_count = 1);

    virtual void Snapshot();

    virtual int  GetAvailThread();
    virtual int  GetAvailEntry();
    virtual void ReleaseUsedThreads(std::vector<int> &threads);
    virtual void ReleaseUsedEntrys(std::vector<int> &entrys);

    void SetIrqAxUserOverride(bool enable);

 private:
    virtual bool      HwInitMini();
    std::mutex        mutex_;
    std::vector<bool> thread_status_;
    std::vector<bool> entry_status_;

 protected:
    uint32_t entry_num_  = 0;
    uint32_t thread_num_ = 0;
};

}  // namespace gsync
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GSYNC_LIBRA_GSYNC_LIBRA_H_
