/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GSYNC_SCORPIO_GSYNC_SCORPIO_VF_H_
#define HARDWARE_GSYNC_SCORPIO_GSYNC_SCORPIO_VF_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "hardware/gsync/scorpio/gsync_scorpio.h"
#include "hardware/include/gsync/gsync.h"
#include "hardware/include/hardware.h"
namespace efvf {
namespace hardware {
namespace gsync {

class GsyncScorpioVf : public Gsync {
 public:
    explicit GsyncScorpioVf(std::shared_ptr<spdlog::logger> logger) : Gsync(logger) {
        inited_ = false;
    }
    virtual ~GsyncScorpioVf() {}

    virtual bool HwInit();
    virtual void ClearSingleEntry(uint32_t entry_id);
    virtual void ClearAllEntries();
    virtual void ClearSingleThread(uint32_t thread_id);
    virtual void ClearAllThreads();

    virtual void Wait(const GsyncCtxCfg &ctx_cfg);
    virtual void Signal(const GsyncCtxCfg &ctx_cfg);
    virtual bool CheckEntryValidStatus(uint32_t entry_id);
    virtual void GetSingleEntryData(GsyncCtxCfg *ctx_cfg);
    virtual uint32_t GetSingleCntData(uint32_t thread_id);
    virtual uint32_t GetGsyncBaseAddr();
    virtual uint32_t GetGsyncCntAddr(uint32_t thread_id);
    virtual uint32_t GetMaxEntryNum();
    virtual uint32_t GetMaxThreadNum();
    virtual void     Snapshot();

    // PF configured features
    virtual uint32_t GetMaxOutstanding();
    virtual void SetMaxOutstanding(uint32_t outstd_val);
    virtual void SetWakeupMode(GsyncWakeupMode wakeup_mode);
    virtual void SetSelfClear(const GsyncSelfClearCfg &clear_cfg);
    // virtual void SetMaxMinMasterId(const GsyncCtxCfg &ctx_cfg);

    virtual void     EnableGsyncSramRasCheck();
    virtual void     DisableGsyncSramRasCheck();
    virtual bool     GetGsyncSramRasStatus();
    virtual void     ClearGsyncSramRasStatus();
    virtual uint32_t GetGsyncSramRasLogAddr();

    virtual void EnableGsyncSramParityCheck();
    virtual void DisableGsyncSramParityCheck();
    virtual void EnableGsyncSramParityErrEnj();
    virtual void DisableGsyncSramParityErrEnj();
    virtual void SetGsyncSramParityErrEnjCountOneTime(uint32_t par_err_enj_count = 1);

    virtual void SetSpIhBaseAddr(uint32_t addr);
    virtual void SetSpIhBaseData(uint32_t data);
    virtual void SetPcieIhBaseAddr(uint32_t addr);
    virtual void SetPcieIhBaseData(uint32_t data);

    virtual int  GetAvailThread();
    virtual int  GetAvailEntry();
    virtual void ReleaseUsedThreads(std::vector<int> &threads);
    virtual void ReleaseUsedEntrys(std::vector<int> &entrys);

 protected:
    uint32_t entry_num_  = 0;
    uint32_t thread_num_ = 0;
    int      vf_num_     = 1;
    int      vf_index_   = 0;
    bool     isDualDie_  = false;
    std::vector<bool> thread_status_;
    std::vector<bool> entry_status_;
};

}  // namespace gsync
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GSYNC_SCORPIO_GSYNC_SCORPIO_VF_H_
