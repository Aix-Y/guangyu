/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GSYNC_SCORPIO_GSYNC_SCORPIO_H_
#define HARDWARE_GSYNC_SCORPIO_GSYNC_SCORPIO_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "device/dtus/scorpio/register_soc.h"
#include "hardware/include/gsync/gsync.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace gsync {

#define SCORPIO_GSYNC_ENTRY_NUM 256
#define SCORPIO_GSYNC_THREAD_NUM 128
#define DIE_ADDR_OFFSET (0x800000)
class GsyncScorpio : public Gsync {
 public:
    explicit GsyncScorpio(std::shared_ptr<spdlog::logger> logger) : Gsync(logger) {
        inited_ = false;
    }
    virtual ~GsyncScorpio() {}

    virtual bool HwInit();
    virtual void ClearSingleEntry(uint32_t entry_id);
    virtual void ClearAllEntries();
    virtual void ClearSingleThread(uint32_t thread_id);
    virtual void ClearAllThreads();

    virtual void Wait(const GsyncCtxCfg &ctx_cfg);
    virtual void Signal(const GsyncCtxCfg &ctx_cfg);
    virtual bool CheckEntryValidStatus(uint32_t entry_id);
    virtual void GetSingleEntryData(GsyncCtxCfg *ctx_cfg);
    virtual uint32_t GetSingleCntData(uint32_t thread_id);
    virtual uint32_t GetGsyncBaseAddr();
    virtual uint32_t GetGsyncCntAddr(uint32_t thread_id);

    virtual uint32_t GetMaxEntryNum();
    virtual uint32_t GetMaxThreadNum();

    virtual uint32_t GetMaxOutstanding();
    virtual void SetMaxOutstanding(uint32_t outstd_val);
    virtual void SetWakeupMode(GsyncWakeupMode wakeup_mode);
    virtual void SetSelfClear(const GsyncSelfClearCfg &clear_cfg);
    // virtual void SetMaxMinMasterId(const GsyncCtxCfg &ctx_cfg);

    virtual void     EnableGsyncSramRasCheck();
    virtual void     DisableGsyncSramRasCheck();
    virtual bool     GetGsyncSramRasStatus();
    virtual void     ClearGsyncSramRasStatus();
    virtual uint32_t GetGsyncSramRasLogAddr();

    virtual void EnableGsyncSramParityCheck();
    virtual void DisableGsyncSramParityCheck();
    virtual void EnableGsyncSramParityErrEnj();
    virtual void DisableGsyncSramParityErrEnj();
    virtual void SetGsyncSramParityErrEnjCountOneTime(uint32_t par_err_enj_count = 1);

    virtual void SetSpIhBaseAddr(uint32_t addr);
    virtual void SetSpIhBaseData(uint32_t data);
    virtual void SetPcieIhBaseAddr(uint32_t addr);
    virtual void SetPcieIhBaseData(uint32_t data);

    virtual void Snapshot();

    virtual int  GetAvailThread();
    virtual int  GetAvailEntry();
    virtual void ReleaseUsedThreads(std::vector<int> &threads);
    virtual void ReleaseUsedEntrys(std::vector<int> &entrys);

 private:
    virtual bool      HwInitMini();
    virtual void      LibInit();
    std::mutex        mutex_;
    std::vector<bool> thread_status_;
    std::vector<bool> entry_status_;

 protected:
    uint32_t entry_num_  = 0;
    uint32_t thread_num_ = 0;
};

}  // namespace gsync
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GSYNC_SCORPIO_GSYNC_SCORPIO_H_
