/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_VPP_VPP_EVP_SCORPIO_H_
#define HARDWARE_VPP_VPP_EVP_SCORPIO_H_
#include <memory>
#include <string>
#include <vector>
#include "hardware/include/vpp_codec/vpp_codec.h"
#include "hardware/include/vpp_evp/vpp_evp.h"
#include "hardware/mailbox/mailbox_scorpio.h"
#include "hardware/vpp/vpp_ras_scorpio.h"

using efvf::hardware::codec::Codec;

using efvf::hardware::mailbox::MailboxScorpio;
using efvf::hardware::mailbox::MailboxScorpioParam;

#undef PCIE_INTERRUPT_ADDR
#define PCIE_INTERRUPT_ADDR (0x2490000 + 0x180)
#define VPP0_INTERRUPT_ADDR (0x2705800 + 0x180)
#define AP_INTERRUPT_ADDR (0x2600000 + 0xF180)
#define SP_INTERRUPT_ADDR (0x2300000 + 0x15180)
#define VPP_0_MIH_MASTER_ID (0x300)
#define VPP_1_MIH_MASTER_ID (0x320)
#define EVP_STRIDE_ALIGN (0x80)

namespace efvf {
namespace hardware {
namespace vpp {

struct FwCmdDewarp {
    struct {
        uint32_t src_image_addr_lo;
        uint32_t src_image_addr_hi;
        uint32_t src_image_format : 16;
        uint32_t src_image_width : 16;
        uint32_t src_image_height : 16;
        uint32_t src_image_stride : 16;
    };

    struct {
        uint32_t dst_image_addr_lo;
        uint32_t dst_image_addr_hi;
        uint32_t dst_image_format : 16;
        uint32_t dst_image_width : 16;
        uint32_t dst_image_height : 16;
        uint32_t dst_image_stride : 16;
    };

    struct {
        uint32_t warp_mode : 8;
        uint32_t reserved_8_31 : 24;
        int32_t  warp_matrix[9];
        uint16_t warp_constant_value[4];
    };
};

struct FwCmdDewarpResp {
    uint32_t dst_image_addr_lo;
    uint32_t dst_image_addr_hi;
    uint32_t dst_image_format : 16;
    uint32_t dst_image_width : 16;
    uint32_t dst_image_height : 16;
    uint32_t dst_image_stride : 16;
};

struct FwCmdCrop {
    struct {
        uint32_t src_image_addr_lo;
        uint32_t src_image_addr_hi;
        uint32_t src_image_format : 16;
        uint32_t src_image_width : 16;
        uint32_t src_image_height : 16;
        uint32_t src_image_stride : 16;
    };

    struct {
        uint32_t dst_image_addr_lo;
        uint32_t dst_image_addr_hi;
        uint32_t dst_image_format : 16;
        uint32_t dst_image_width : 16;
        uint32_t dst_image_height : 16;
        uint32_t dst_image_stride : 16;
    };

    struct {
        uint32_t x_pos : 16;
        uint32_t y_pos : 16;
    };
};

struct FwCmdCropResp {
    uint32_t dst_image_addr_lo;
    uint32_t dst_image_addr_hi;
    uint32_t dst_image_format : 16;
    uint32_t dst_image_width : 16;
    uint32_t dst_image_height : 16;
    uint32_t dst_image_stride : 16;
};

struct FwCmdResize {
    struct {
        uint32_t src_image_addr_lo;
        uint32_t src_image_addr_hi;
        uint32_t src_image_format : 16;
        uint32_t src_image_width : 16;
        uint32_t src_image_height : 16;
        uint32_t src_image_stride : 16;
    };

    struct {
        uint32_t dst_image_addr_lo;
        uint32_t dst_image_addr_hi;
        uint32_t dst_image_format : 16;
        uint32_t dst_image_width : 16;
        uint32_t dst_image_height : 16;
        uint32_t dst_image_stride : 16;
    };

    struct {
        uint32_t mode : 8;
        uint32_t reserved_8_31 : 24;
    };
};

struct FwCmdResizeResp {
    uint32_t dst_image_addr_lo;
    uint32_t dst_image_addr_hi;
    uint32_t dst_image_format : 16;
    uint32_t dst_image_width : 16;
    uint32_t dst_image_height : 16;
    uint32_t dst_image_stride : 16;
};

struct FwCmdPadding {
    struct {
        uint32_t src_image_addr_lo;
        uint32_t src_image_addr_hi;
        uint32_t src_image_format : 16;
        uint32_t src_image_width : 16;
        uint32_t src_image_height : 16;
        uint32_t src_image_stride : 16;
    };

    struct {
        uint32_t dst_image_addr_lo;
        uint32_t dst_image_addr_hi;
        uint32_t dst_image_format : 16;
        uint32_t dst_image_width : 16;
        uint32_t dst_image_height : 16;
        uint32_t dst_image_stride : 16;
    };

    struct {
        uint32_t mode : 8;
        uint32_t reserved_8_31 : 24;
        uint32_t upper_num : 16;
        uint32_t down_num : 16;
        uint32_t left_num : 16;
        uint32_t right_num : 16;
        uint16_t value[4];
    };
};

struct FwCmdPaddingResp {
    uint32_t dst_image_addr_lo;
    uint32_t dst_image_addr_hi;
    uint32_t dst_image_format : 16;
    uint32_t dst_image_width : 16;
    uint32_t dst_image_height : 16;
    uint32_t dst_image_stride : 16;
};

struct FwCmdCsc {
    struct {
        uint32_t src_image_addr_lo;
        uint32_t src_image_addr_hi;
        uint32_t src_image_format : 16;
        uint32_t src_image_width : 16;
        uint32_t src_image_height : 16;
        uint32_t src_image_stride : 16;
    };

    struct {
        uint32_t dst_image_addr_lo;
        uint32_t dst_image_addr_hi;
        uint32_t dst_image_format : 16;
        uint32_t dst_image_width : 16;
        uint32_t dst_image_height : 16;
        uint32_t dst_image_stride : 16;
    };

    struct {
        uint32_t mode : 8;
    };

    uint32_t reserved_8_31 : 24;
};

struct FwCmdCscResp {
    uint32_t dst_image_addr_lo;
    uint32_t dst_image_addr_hi;
    uint32_t dst_image_format : 16;
    uint32_t dst_image_width : 16;
    uint32_t dst_image_height : 16;
    uint32_t dst_image_stride : 16;
};

struct FwCmdResizePadding {
    struct {
        uint32_t src_image_addr_lo;
        uint32_t src_image_addr_hi;
        uint32_t src_image_format : 16;
        uint32_t src_image_width : 16;
        uint32_t src_image_height : 16;
        uint32_t src_image_stride : 16;
    };

    struct {
        uint32_t dst_image_addr_lo;
        uint32_t dst_image_addr_hi;
        uint32_t dst_image_format : 16;
        uint32_t dst_image_width : 16;
        uint32_t dst_image_height : 16;
        uint32_t dst_image_stride : 16;
    };

    struct {
        uint32_t resize_mode : 8;
        uint32_t padding_mode : 8;
        uint32_t aspect_ratio : 8;
        uint32_t reserved_24_31 : 8;
        uint32_t upper_num : 16;
        uint32_t down_num : 16;
        uint32_t left_num : 16;
        uint32_t right_num : 16;
        uint16_t value[4];
    };
};

struct FwCmdResizePaddingResp {
    uint32_t dst_image_addr_lo;
    uint32_t dst_image_addr_hi;
    uint32_t dst_image_format : 16;
    uint32_t dst_image_width : 16;
    uint32_t dst_image_height : 16;
    uint32_t dst_image_stride : 16;
};

enum vpu_fw_cmd_type {
    VPU_FW_CMD_EVP_DEWARP = 0,
    VPU_FW_CMD_EVP_CROP,
    VPU_FW_CMD_EVP_RESIZE,
    VPU_FW_CMD_EVP_PADDING,
    VPU_FW_CMD_EVP_CSC,
    VPU_FW_CMD_EVP_RESIZE_PADDING,
    VPU_FW_CMD_CVA_ECCL,
    VPU_FW_CMD_CVA_EFC,
    VPU_FW_CMD_CVA_EMAR,
    VPU_FW_CMD_MAX,
};

typedef struct FwEvpCmd {
    union {
        struct FwCmdDewarp        dewarp;
        struct FwCmdCrop          crop;
        struct FwCmdResize        resize;
        struct FwCmdPadding       padding;
        struct FwCmdCsc           csc;
        struct FwCmdResizePadding resize_padding;
    } cmd;
} FwEvpCmd;

typedef struct FwSingleCmd {
    uint32_t idx : 11;
    uint32_t ctx_id : 4;
    uint32_t evp_cmd_len : 10;
    uint32_t type : 7;
    FwEvpCmd evp_cmd;
} FwSingleCmd;

typedef struct FwBatchCmd {
    uint32_t    num : 11;
    uint32_t    ctx_id : 4;
    uint32_t    cmd_len : 10;
    uint32_t    type : 7;
    FwSingleCmd cmd;
} FwBatchCmd;

typedef struct FwSqMsg {
    uint32_t   batch_id;
    FwBatchCmd bcmd;
} FwSqMsg;

// CQ
typedef struct FwEvpResp {
    union {
        struct FwCmdDewarpResp        dewarp;
        struct FwCmdCropResp          crop;
        struct FwCmdResizeResp        resize;
        struct FwCmdPaddingResp       padding;
        struct FwCmdCscResp           csc;
        struct FwCmdResizePaddingResp resize_padding;
    } resp;
} FwEvpResp;

typedef struct FwSingleCmdResp {
    uint32_t  status : 2;
    uint32_t  index : 11;
    uint32_t  length : 10;
    uint32_t  type : 7;
    uint32_t  reserved_30_31 : 2;
    FwEvpResp evp_resp;
} FwSingleCmdResp;

typedef struct FwBatchCmdResp {
    uint32_t        status : 8;
    uint32_t        reserved_8_14 : 8;
    uint32_t        length : 10;
    uint32_t        type : 7;
    uint32_t        number;
    FwSingleCmdResp sresp;
} FwBatchCmdResp;

typedef struct FwCqMsg {
    uint32_t       batch_id;
    FwBatchCmdResp bresp;
} FwCqMsg;

typedef struct FwMsgQueue {
    uint64_t src_addr;
    uint32_t src_size;
    uint32_t src_rptr;
    uint32_t src_wptr;
    uint32_t src_full_wm;
    uint64_t dst_addr;
    uint32_t dst_size;
    uint32_t dst_rptr;
    uint32_t dst_wptr;
    uint32_t dst_full_wm;
    uint32_t q_ctrl;
    uint32_t scratch;
    uint32_t id;
    FwMsgQueue()
        : src_addr(0),
          src_size(0),
          src_rptr(0),
          src_wptr(0),
          src_full_wm(0),
          dst_addr(0),
          dst_size(0),
          dst_rptr(0),
          dst_wptr(0),
          dst_full_wm(0),
          q_ctrl(0),
          scratch(0),
          id(0) {}
} FwMsgQueue;

class EvpScorpio : public Vpp {
 private:
    uint32_t m_mode;
    Ih *     m_mih_ptr;
    Mdma *   m_mdma_ptr;
    Gdte *   m_dte_ptr;

    std::shared_ptr<MailboxScorpio> m_evp_wrapper_mbx;
    std::shared_ptr<MailboxScorpio> m_vpm_mbx;

    // CQ/SQ for fw communication
    std::unique_ptr<Mem> m_fw_cq_mem;
    std::unique_ptr<Mem> m_fw_sq_mem;
    std::unique_ptr<Mem> m_fw_log_mem;

    FwMsgQueue m_msg_sqcq[3];

 public:
    EvpScorpio() : Vpp() {}
    explicit EvpScorpio(std::shared_ptr<spdlog::logger> logger);
    virtual ~EvpScorpio();

    virtual bool HwInit();
    virtual bool HwDeinit();
    virtual void LibInit();
    virtual bool HwInitMini();
    virtual void Snapshot();

 public:
    virtual uint32_t GetRunMode() const;
    virtual void SetRunMode(uint32_t mode);

    virtual void SetL2CacheForCodec(bool en);

    virtual bool FillConfigByInputParam(EvpConfig &cfg);

    virtual bool RunEvpPipeline(uint32_t inst, EvpConfig &cfg);
    virtual void CleanEvpSetting(uint32_t inst);
    virtual bool CheckIdle(uint32_t inst, bool is_shadow);

    //  virtual Hardware *GetEvp(int inst);

    virtual bool RegAccessTest();
    virtual bool SramAccessTest();

    virtual bool FwSubmitData(uint32_t cmd_type, EvpConfig &cfg);
    virtual bool FwGetResp(uint32_t cmd_type, uint64_t &out_addr, uint64_t &out_param);
    virtual uint32_t GetFwVersion(uint32_t &major, uint32_t &minor);
    virtual uint32_t GetFwHeartbeat();
    virtual uint32_t GetFwStatus();

    virtual uint32_t CheckSidebandInterrupt(uint32_t inst);
    virtual bool CleanSidebandInterrupt(uint32_t inst);
    virtual bool GetEvpStatus(EvpStatus &st);

    virtual void SetSmemParityInject(uint32_t status);
    virtual bool FindSmemParity(uint32_t intfx);
    virtual void CleanSmemParity();

    virtual void SetEvpSramParityInject(uint32_t evp_inst, uint32_t func_type, bool inject);
    virtual uint32_t GetEvpSramParity(uint32_t evp_inst, uint32_t func_type);
    virtual void CleanEvpSramParity(uint32_t evp_inst, uint32_t func_type);

    virtual void SetCodecParityInject(uint32_t codec_inst, uint32_t status);
    virtual bool FindCodecParity(uint32_t codec_inst);
    virtual void CleanCodecParity(uint32_t codec_inst);

    virtual bool HandleToolReq(const std::string &req);
    virtual bool HandleToolReq(const std::string &req, uint64_t &in_out);
    bool HandleSrammisc(Hardware *hw, uint32_t reg_addr, uint32_t idx, uint32_t inj_cnt = 1);

    //
    virtual bool SetVppBlr();
    void         SsmResetVpp();

    //
    virtual bool SetProfiler(bool trace_en, bool profiling_en);

    virtual Mailbox *GetVpmMailBox() {
        return m_vpm_mbx.get();
    }
    virtual Mailbox *GetEvpMailBox() {
        return m_evp_wrapper_mbx.get();
    }

    virtual Ih *GetMih() {
        return m_mih_ptr;
    }

    virtual Mdma *GetMdma() {
        return m_mdma_ptr;
    }

    virtual SystemAdapter *GetSa() {
        return dynamic_cast<SystemAdapter *>(GetVppSaHw());
    }

    // DTE OP
    virtual bool MemConstFill(uint64_t buf_addr, uint64_t buf_size, uint32_t pattern,
        uint64_t off, uint64_t size, int timeout);
    virtual bool DataCopy(uint64_t src_addr, uint64_t dst_addr, uint64_t size);
    virtual uint32_t GetDataCrc(uint64_t src_addr, uint64_t dst_addr, uint64_t size);

    // ************************************************
    //                    VPU EVP
    // ************************************************

 public:
    Hardware *GetEvp(uint32_t inst = 0);  // 0: evp_lite0, 1: evp_lite1, 2: evp pro
    Hardware *GetVppTopHw();
    Hardware *GetVpmMcuHw();
    Hardware *GetVpmMihHw();
    Hardware *GetVpmTopHw();
    Hardware *GetVppSaHw();

    bool EvpInstConfig(Hardware *evp_inst, EvpConfig &cfg);

    uint32_t GetEvpPipeWorkingStatus(uint32_t inst);

    bool GetOutputFmtByInputFmt(EvpConfig &cfg);
    bool GetFormatMemLayout(EvpConfig &cfg);

    //
    bool SetIfcCfg(Hardware *ifc, IfcCfg &cfg);
    bool SetOfcCfg(Hardware *ofc, OfcCfg &cfg);
    // cus or cds
    bool SetChromaSamplingCfg(Hardware *chroma, ChromaSamplingCfg &cfg);
    // bdc
    bool SetBdcCfg(Hardware *bdc, BitdepthCfg &cfg);

    // EVP Feature
    bool SetDewarpCfg(Hardware *dewarp, DewarpCfg &cfg);
    bool SetCropCfg(Hardware *crop, CropCfg &cfg);
    bool SetResizeCfg(Hardware *resize, ResizeCfg &cfg);
    bool SetPaddingCfg(Hardware *padding, PaddingCfg &cfg);
    bool SetCscCfg(Hardware *csc, CscCfg &cfg);

    //
    bool SetGlobalCfg(Hardware *global, EvpConfig &cfg);
    bool SetFuncCfg(Hardware *func, EvpConfig &cfg);
    //
    bool SetSramCfg(Hardware *sram, EvpConfig &cfg);
    bool SetDebugCfg(Hardware *debug);
    bool SetVbusGenCfg(Hardware *vbus, uint16_t w, uint16_t h);  //
    bool GetStatus(Hardware *st);

    //
    bool SetVpmtopCfg(EvpConfig &cfg);

    uint32_t CheckAutoEnableFunc(EvpConfig &cfg);

    void MailboxInit();
    void MihInit();
    void VpmInit();
    void MdmaInit();

    void ProfileInit();
    void CodecInit();
    void SetVmhEntry(uint32_t flag);

    void DbgShowHwInfo(Hardware *hw);
    void DbgShowEvpInfo(uint32_t inst);

    // FW
    bool McuDeassert();
    bool EnableMcu(bool en);
    bool ReleaseMcuReset(bool en);
    bool McuResetReg(uint64_t fw_mem_addr);
    bool WriteRam(uint8_t *data, uint32_t sz);
    bool ReadRam(uint8_t *buf, uint32_t sz);
    bool LoadFw(const std::string &dls_file, bool cmp = true, bool auto_run = true);
    bool LoadToRam(const std::string &file_name, bool cmp);

    void FwResetReg();
    bool FwCreateMsgQ();
    bool FwRmcInit();
    void FwSendCmd(uint32_t cmd, uint32_t data);
    int32_t FwRmcHandleCmd(uint32_t cmd, uint32_t data);
    int32_t FwWaitCmdDone();

    int FwQueueGetAvailable(FwMsgQueue &q);
    bool WriteMsgToQ(FwSqMsg &msg, FwMsgQueue &msg_q);
    bool ReadMsgFromQ(FwCqMsg &msg, FwMsgQueue &msg_q);
    void DbgShowMsgQ(FwMsgQueue &q);
    void DbgShowSqMsg(uint32_t cmd_type, FwSqMsg &m);
    void DbgShowCqMsg(uint32_t cmd_type, FwCqMsg &m);

    // ************************************************
    //              VPU codec
    // ************************************************
    virtual Codec *GetCodec(uint32_t inst);
    Codec *m_combo_core_hdl;
    Codec *m_decoder_core_hdl;
};

}  // namespace vpp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_VPP_VPP_EVP_SCORPIO_H_
