/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_VPP_VPP_RAS_SCORPIO_H_
#define HARDWARE_VPP_VPP_RAS_SCORPIO_H_

#include <algorithm>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "hardware/include/vpp_evp/vpp_evp.h"
#include "hardware/include/vpp_evp/vpp_ras.h"

namespace efvf {
namespace hardware {
namespace vpp {

// class VppRasScorpio;
class VppRasScorpio : public VppRas {
 public:
    explicit VppRasScorpio(Vpp *vpp);
    virtual ~VppRasScorpio();

    /**
     * @brief enable ras
     */
    virtual void Enable(RasCfg *cfg);

    /**
     * @brief disable ras
     */
    virtual void Disable(RasCfg *cfg);

    /**
     * @brief start ras inject
     */
    virtual void StartErrInjection(RasCfg *cfg, RasErrInj *err_inj);

    /**
     * @brief stop ras inject
     */
    virtual void StopErrInjection(RasCfg *cfg, RasErrInj *err_inj);

    /**
     * @brief query err
     */
    virtual void QueryErrStatus(RasCfg *cfg, RasErrStat *err_stat);

    /**
     * @brief clear err
     */
    virtual void ClearErrStatus(RasCfg *cfg);

    /**
     * @brief print err
     */
    virtual void PrintErrStatus(RasCfg *cfg) {}

    /**
     * @berif get ras cfg
     *
     * @param      cfg   The configuration
     */
    virtual void GetRasCfg(RasCfg *cfg);

    /**
     * @brief enable interrupt
     */
    virtual void EnableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief disable interrupt
     */
    virtual void DisableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief clear interrupt
     */
    virtual void ClearInterrupt(IntrptCfg *cfg) {}

    /**
     * @berif save interrupt
     */
    virtual void QueryInterrupt(IntrptCfg *cfg, IntrptStat *stat) {}

    /**
     * @brief print interrupt
     */
    virtual void PrintInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  type  The type
     * @param[in]  is_stop  is stopping err inj?
     *
     * @return     { description_of_the_return_value }
     */
    virtual RasErrInj *GenRasErrInjCfg(const std::string &type, bool is_stop);

 private:
    Vpp *       vpp_;
    std::string m_name;
};

}  // namespace vpp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_VPP_VPP_RAS_SCORPIO_H_
