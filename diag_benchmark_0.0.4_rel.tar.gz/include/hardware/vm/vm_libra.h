
/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_VM_VM_LIBRA_H_
#define HARDWARE_VM_VM_LIBRA_H_

#include <memory>
#include <vector>

#include "hardware/include/vm.h"

namespace efvf {
namespace hardware {
namespace vm {

class VmLibra : public Vm {
 public:
    explicit VmLibra(std::shared_ptr<spdlog::logger> logger);
    ~VmLibra() {}

    virtual bool HwInit();
    virtual bool HwDeinit();

    virtual void EnClkGating(bool on);
    virtual void Bypass();
    virtual void DisableAllMap();
    virtual bool IsDirectMapEn();
    virtual void TlbForceUpdate(int id);
    virtual void SetDirectMap(DirectMapCfg cfg);
    virtual void SetDirectMapEn(uint32_t status);
    virtual void SetSpecialMap(SpecialMapCfg cfg);
    virtual void SetSpecialMapEn(uint32_t status);
    virtual void SetPteMap(PteMapCfg cfg);
    virtual void SetPteSetEn(int id, uint32_t status);
    virtual void SetPteLocation(int id, uint32_t in_sys);
    virtual void SetPtePageSize(int id, uint64_t size);
    virtual void SetPteSnoop(int id, VmSnoopMode mode);
    virtual void SetPteUsageEn(int id, uint32_t status);
    virtual void SetPteUsageWinAddr(int id, uint64_t addr);
    virtual void SetPteUsageWinSize(int id, uint64_t size);
    virtual void SetPteUsageBaseAddr(int id, uint64_t addr);
    virtual void SetPteUsageInvalidateTlb(int id);
    virtual void SetPteBurstFetch(int id, uint32_t val);
    virtual void SetCauseAddr(uint64_t addr);
    virtual void SetPteForecastCfg(int id, uint32_t step, uint32_t index);
    virtual Absp *   GetAbsp();
    virtual Pmc *    GetPmc();
    virtual Xmc *    GetDfXmc();
    virtual uint64_t GetPcieEdfStart();
    virtual void FillPteContent(uint8_t *pte_base, uint64_t map_to_addr, uint32_t page_size,
        const std::vector<uint32_t> &map_order, uint32_t local = 0, uint32_t snoop = 1,
        uint32_t valid = 1);
    virtual void SetRdFaultAddr(uint64_t ecf_addr);
    virtual void SetWrFaultAddr(uint64_t ecf_addr);
    virtual bool FindMappingError(uint64_t &err_addr);

 private:
    bool is_direct_map_en_  = false;
    bool is_special_map_en_ = false;
    // bool is_special_master_en_ = false;
};

class VmLibraRas : public efvf::hardware::IRas {
 public:
    explicit VmLibraRas(Hardware *ip) : ip_(ip) {
        logger_ = ip->get_logger();
    }

    ~VmLibraRas() {}

    virtual void Enable(RasCfg *cfg);
    virtual void Disable(RasCfg *cfg);
    virtual void StartErrInjection(RasCfg *cfg, RasErrInj *err_inj);
    virtual void StopErrInjection(RasCfg *cfg, RasErrInj *err_inj);
    virtual void QueryErrStatus(RasCfg *cfg, RasErrStat *err_stat);
    virtual void ClearErrStatus(RasCfg *cfg);
    virtual void PrintErrStatus(RasCfg *cfg);
    virtual void GetRasCfg(RasCfg *cfg);
    virtual void EnableInterrupt(IntrptCfg *cfg);
    virtual void DisableInterrupt(IntrptCfg *cfg);
    virtual void ClearInterrupt(IntrptCfg *cfg);
    virtual void QueryInterrupt(IntrptCfg *cfg, IntrptStat *stats);
    virtual void PrintInterrupt(IntrptCfg *cfg);

 private:
    uint32_t RegRead(uint64_t offset) {
        return ip_->RegRead(offset);
    }

    void RegWrite(uint64_t offset, uint32_t val) {
        return ip_->RegWrite(offset, val);
    }

    Hardware *ip_ = nullptr;
};
}  // namespace vm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_VM_VM_LIBRA_H_
