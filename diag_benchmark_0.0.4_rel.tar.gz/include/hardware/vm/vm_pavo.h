/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_VM_VM_PAVO_H_
#define HARDWARE_VM_VM_PAVO_H_

#include <memory>
#include "hardware/include/vm.h"

namespace efvf {
namespace hardware {
namespace vm {
class VmPavo : public Vm {
 public:
    VmPavo() : Vm() {}
    explicit VmPavo(std::shared_ptr<spdlog::logger> logger);
    virtual ~VmPavo();

    //!
    //! \berif direct map
    //!
    virtual void SetDirectMap(DirectMapCfg cfg);

    /**
     * @brief      Determines if direct map en.
     *
     * @return     True if direct map en, False otherwise.
     */
    virtual bool IsDirectMapEn() {
        return false;
    }

    //!
    //! \berif special map
    //!
    virtual void SetSpecialMap(SpecialMapCfg cfg);

    //!
    //! \berif pte map
    //!
    virtual void SetPteMap(PteMapCfg cfg);

    //!
    //! \berif
    //!
    virtual void SetRdFaultAddr(uint64_t ecf_addr);

    //!
    //! \berif
    //!
    virtual void SetWrFaultAddr(uint64_t ecf_addr);

 private:
    //!
    //! \berif
    //!
    virtual bool HwInit();

    //!
    //! \berif
    //!
    virtual bool HwDeinit();
};
}  // namespace vm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_VM_VM_PAVO_H_
