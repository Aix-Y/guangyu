/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_VM_VM_SCORPIO_VF_H_
#define HARDWARE_VM_VM_SCORPIO_VF_H_

#include <memory>
#include <vector>
#include "hardware/include/vm.h"

namespace efvf {
namespace hardware {
namespace vm {
class VmScorpioVf : public Vm {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    VmScorpioVf() : Vm() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit VmScorpioVf(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~VmScorpioVf();

    /**
     * @brief      { function_description }
     */
    virtual void Bypass() {}

    /**
     * @brief      Disables all map.
     */
    virtual void DisableAllMap() {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  id    The identifier
     */
    virtual void TlbForceUpdate(int id);

    /**
     * @brief      Determines if direct map en.
     *
     * @return     True if direct map en, False otherwise.
     */
    virtual bool IsDirectMapEn() {
        return false;
    }

    /**
     * @brief      Sets the direct map.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetDirectMap(DirectMapCfg /*cfg*/) {}

    /**
     * @brief      Disables the direct map.
     */
    virtual void SetDirectMapEn(uint32_t /*status*/) {}

    /**
     * @brief      Sets the special map.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetSpecialMap(SpecialMapCfg /*cfg*/) {}

    /**
     * @brief      Disables the special map.
     */
    virtual void SetSpecialMapEn(uint32_t /*status*/) {}

    /**
     * @brief      Sets the pte map.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetPteMap(PteMapCfg cfg);

    /**
     * @brief      Sets the pte set en.
     *
     * @param[in]  id      The new value
     * @param[in]  status  The status
     */
    virtual void SetPteSetEn(int id, uint32_t status);

    /**
     * @brief      Sets the pte location.
     *
     * @param[in]  id      The new value
     * @param[in]  in_sys  In system
     */
    virtual void SetPteLocation(int id, uint32_t in_sys);

    /**
     * @brief      Sets the pte page size.
     *
     * @param[in]  id    The new value
     * @param[in]  size  The size
     */
    virtual void SetPtePageSize(int id, uint64_t size);

    /**
     * @brief      Sets the pte usage en.
     *
     * @param[in]  id      The new value
     * @param[in]  status  The status
     */
    virtual void SetPteUsageEn(int id, uint32_t status);

    /**
     * @brief      Sets the pte usage window address.
     *
     * @param[in]  id    The new value
     * @param[in]  addr  The address
     */
    virtual void SetPteUsageWinAddr(int id, uint64_t addr);

    /**
     * @brief      Sets the pte usage window size.
     *
     * @param[in]  id    The new value
     * @param[in]  size  The size
     */
    virtual void SetPteUsageWinSize(int id, uint64_t size);

    /**
     * @brief      the address to save pte
     *
     * @param[in]  id    The new value
     * @param[in]  addr  The address
     */
    virtual void SetPteUsageBaseAddr(int id, uint64_t addr);

    /**
     * @brief      Sets the pte usage invalidate tlb.
     *
     * @param[in]  id      The new value
     * @param[in]  status  The status
     */
    virtual void SetPteUsageInvalidateTlb(int id);

    /**
     * @brief      Sets the pte burst fetch.
     *
     * @param[in]  id    The new value
     * @param[in]  val   The new value
     */
    virtual void SetPteBurstFetch(int id, uint32_t val);

    /**
     * @brief      Sets the cause address.
     */
    virtual void SetCauseAddr(uint64_t /*addr*/) {}

    /* @brief Set the Pte Forecast config
     *
     * @param[in] id    The pte set id
     * @param[in] step  The forecast step which control cacheline
     * @param[in] index When to do forecast which is invalid if value >7.
     */
    virtual void SetPteForecastCfg(int id, uint32_t step, uint32_t index);

    /**
     * @brief      Gets the absp.
     *
     * @return     The absp.
     */
    virtual Absp *GetAbsp() {
        return nullptr;
    }

    /**
     * @brief      Gets the pmc.
     *
     * @return     The pmc.
     */
    virtual Pmc *GetPmc() {
        return nullptr;
    }

    /**
     * @brief      Gets the pcie edf start.
     *
     * @return     The pcie edf start.
     */
    virtual uint64_t GetPcieEdfStart();

    /**
     * @brief      { function_description }
     */
    virtual void Snapshot();

    /**
     * @brief      { function_description }
     *
     * @param      pte_base     The pte base
     * @param[in]  map_to_addr  The map to address
     * @param[in]  local        map to addree is local address (0 or 1)
     * @param[in]  page_size    The page size
     * @param[in]  map_order    The map order
     */
    virtual void FillPteContent(uint8_t *pte_base, uint64_t map_to_addr, uint32_t page_size,
        const std::vector<uint32_t> &map_order, uint32_t local, uint32_t snoop,
        uint32_t valid);

    /**
     * @brief      Sets the rd fault address.
     *
     * @param[in]  ecf_addr  The ecf address
     */
    virtual void SetRdFaultAddr(uint64_t /*ecf_addr*/) {}

    /**
     * @brief      Sets the wr fault address.
     *
     * @param[in]  ecf_addr  The ecf address
     */
    virtual void SetWrFaultAddr(uint64_t /*ecf_addr*/) {}

    /**
     * @brief      Finds a mapping error.
     *
     * @param      err_addr  The error address
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FindMappingError(uint64_t & /*err_addr*/) {
        return false;
    }

    /**
     * @brief      Finds a pte parity error.
     *
     * @param[in]  set_id    The set identifier
     * @param      err_addr  The error address
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FindPteParityErr(int /*set_id*/, uint64_t & /*err_addr*/) {
        return false;
    }

 private:
    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit();
};

}  // namespace vm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_VM_VM_SCORPIO_VF_H_
