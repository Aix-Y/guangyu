/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file abmp.h
    \brief define a common axi bus master parity lib
 */

#ifndef HARDWARE_COMMON_ABMP_LIBRA_ABMP_H_
#define HARDWARE_COMMON_ABMP_LIBRA_ABMP_H_

#include <memory>
#include <string>
#include <vector>

#include "hardware/include/abmp.h"

namespace efvf {
namespace hardware {
namespace abmp {

/*!
 * @brief AbmpLibra lib
 */
class AbmpLibra : public Abmp {
 public:
    /*!
     * @brief abmp constructors
     */
    explicit AbmpLibra(std::shared_ptr<spdlog::logger> logger);

    /*!
     * @brief desctructor
     */
    virtual ~AbmpLibra();

 public:
    /*!
     * @brief enable write parity check
     */
    virtual bool AbmpWrParityCheckEnable(bool check_en);

    /*!
     * @brief enable write error interrupt
     */
    virtual bool AbmpWrErrIntEnable(AbmpWrErrIntType err_int, bool enable);

    /*!
     * @brief enable write parity generation
     */
    virtual bool AbmpWrParityGenEnable(bool gen_en);

    /*!
     * @brief enable write parity eror injection
     */
    virtual bool AbmpWrParityErrInject(AbmpWrParityInjectType inj_type, uint16_t num);

    /*!
     * @brief stop write parity error injection
     */
    virtual bool AbmpStopWrParityErrInject(void);

    /*!
     * @brief Get write parity eror injection count
     */
    virtual uint16_t AbmpGetWrParityErrInJCnt(void);

    /*!
     * @brief Get write parity eror injection status
     */
    virtual uint16_t AbmpGetWrParityErrInJStat(void);

    /*!
     * @brief get write parity error status
     */
    virtual bool AbmpGetWrParityErrStat(uint32_t &err_stat);

    /*!
     * @brief enable read parity check
     */
    virtual bool AbmpRdParityCheckEnable(bool check_en);

    /*!
     * @brief enable read response check
     */
    virtual bool AbmpRdRespCheckEnable(bool check_en);

    /*!
     * @brief enable read error interrupt
     */
    virtual bool AbmpRdErrIntEnable(AbmpRdErrIntType err_int, bool enabl);

    /*!
     * @brief get read parity error status
     */
    virtual bool AbmpGetRdParityErrStat(uint32_t &err_stat);

    /*!
     * @brief clear error
     */
    virtual void AbmpClearErrStat(void);

    /*!
     * @brief print all the abmp configuration
     */
    virtual void PrintAll(std::string &);

 private:
    bool wr_parity_check_en;
    bool wr_parity_gen_en;
    bool wr_parity_err_int_en;
    bool wr_bresp_err_int_en;
    bool wr_buser_err_int_en;

    bool        rd_resp_check_en;
    bool        rd_parity_check_en;
    bool        rd_rresp_err_int_en;
    bool        rd_ruser_err_int_en;
    bool        rd_parity_err_int_en;
    std::string m_name;

 private:
    uint32_t regr32(uint64_t);
    void     regw32(uint64_t, uint32_t);
};

class AbmpRasLibra : public AbmpRas {
 public:
    explicit AbmpRasLibra(AbmpLibra *abmp);
    virtual ~AbmpRasLibra();

    /**
     * @brief enable ras
     */
    virtual void Enable(RasCfg *cfg);

    /**
     * @brief disable ras
     */
    virtual void Disable(RasCfg *cfg);

    /**
     * @brief start ras inject
     */
    virtual void StartErrInjection(RasCfg *cfg, RasErrInj *err_inj);

    /**
     * @brief stop ras inject
     */
    virtual void StopErrInjection(RasCfg *cfg, RasErrInj *err_inj);

    /**
     * @brief query err
     */
    virtual void QueryErrStatus(RasCfg *cfg, RasErrStat *err_stat);

    /**
     * @brief clear err
     */
    virtual void ClearErrStatus(RasCfg *cfg);

    /**
     * @brief print err
     */
    virtual void PrintErrStatus(RasCfg *cfg);

    /**
     * @berif get ras cfg
     *
     * @param      cfg   The configuration
     */
    virtual void GetRasCfg(RasCfg *cfg) {}

    /**
     * @brief enable interrupt
     */
    virtual void EnableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief disable interrupt
     */
    virtual void DisableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief clear interrupt
     */
    virtual void ClearInterrupt(IntrptCfg *cfg) {}

    /**
     * @berif save interrupt
     */
    virtual void QueryInterrupt(IntrptCfg *cfg, IntrptStat *stat) {}

    /**
     * @brief print interrupt
     */
    virtual void PrintInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  type     The type
     * @param[in]  is_stop  is stopping err inj?
     *
     * @return     { description_of_the_return_value }
     */
    virtual RasErrInj *GenRasErrInjCfg(const std::string &type, bool is_stop = false);

 private:
    AbmpLibra *abmp_;
};

}  // namespace abmp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_ABMP_LIBRA_ABMP_H_
