/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_MESSAGE_AGENT_LIBRA_H_
#define HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_MESSAGE_AGENT_LIBRA_H_

#include <memory>
#include <vector>

#include "hardware/include/message_agent.h"

namespace efvf {
namespace hardware {
namespace message_collector {

//!
//! @brief Libra message agent lib
//!
//! It is base class for all Libra agents. It provides general functions like enable/disable
//! agent and set agent target address.
//!
class MessageCollectorLibra;
class MessageAgentLibra : virtual public MessageAgent {
 public:
    MessageAgentLibra(MessageCollectorLibra *mc, uint8_t index);

    //! @brief enable/disable message agent
    void Enable() override;
    void Disable() override;

    //! @brief set message agent's target address
    //!
    //! @param addr: target address. It is a CF address that receives events.
    //! For interrupt agent, the target address should be MIH.
    //! For trace event agent, profiling agent, l2loss agent, and log agent, the target address
    //! should be DPF.
    void SetTargetAddr(uint32_t addr) override;
};

}  // namespace message_collector
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_MESSAGE_AGENT_LIBRA_H_
