/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_PROFILING_PROFILING_AGENT_LIBRA_H_
#define HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_PROFILING_PROFILING_AGENT_LIBRA_H_

#include "hardware/common/message_collector/libra/message_agent_libra.h"
#include "hardware/include/message_agent.h"

namespace efvf {
namespace hardware {
namespace message_collector {

//!
//! @brief Libra profiling agent lib
//!
class ProfilingAgentLibra : public MessageAgentLibra, public ProfilingAgent {
 public:
    explicit ProfilingAgentLibra(MessageCollectorLibra *mc);
    ~ProfilingAgentLibra() = default;

    //! @brief config valid length for specific counter
    //!
    //! @param vlen: specify the valid length
    //! @param index: specify counter index, -1 if all counters
    void CfgCounterByteNum(CounterValidLength vlen, int index = -1) override;
    void CfgPackageId(uint32_t package_id) override;
};

}  // namespace message_collector
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_PROFILING_PROFILING_AGENT_LIBRA_H_
