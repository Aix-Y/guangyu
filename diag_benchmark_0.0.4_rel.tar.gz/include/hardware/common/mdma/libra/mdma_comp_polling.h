/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_POLLING_H_
#define HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_POLLING_H_

#include "hardware/include/mdma/mdma.h"

namespace efvf {
namespace hardware {
namespace mdma {

class MdmaCPollingLibra : public MdmaCPolling {
 public:
    explicit MdmaCPollingLibra(Mdma *dma, MdmaEngineCompDesc_t &comp)
        : MdmaCPolling(dma, comp) {}
    virtual ~MdmaCPollingLibra() {}

 public:
    void HandleCfg(const MdmaCfg &);

 private:
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_POLLING_H_
