/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_MPQ_H_
#define HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_MPQ_H_

#include "hardware/include/mdma/mdma.h"

namespace efvf {
namespace hardware {
namespace mdma {

class MdmaCMpqLibra : public MdmaCMpq {
 public:
    explicit MdmaCMpqLibra(Mdma *dma, MdmaEngineCompDesc_t &comp) : MdmaCMpq(dma, comp) {}
    virtual ~MdmaCMpqLibra() {}

 public:
    void HandleCfg(const MdmaCfg &);

 private:
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_MPQ_H_
