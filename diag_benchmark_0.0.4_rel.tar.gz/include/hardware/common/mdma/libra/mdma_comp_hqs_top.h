/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_HQS_TOP_H_
#define HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_HQS_TOP_H_

#include "hardware/include/mdma/mdma.h"

namespace efvf {
namespace hardware {
namespace mdma {

class MdmaCHqsTopLibra : public MdmaCHqsTop {
 public:
    explicit MdmaCHqsTopLibra(Mdma *dma, MdmaEngineCompDesc_t &comp)
        : MdmaCHqsTop(dma, comp) {}
    virtual ~MdmaCHqsTopLibra() {}

 public:
    void HandleCfg(const MdmaCfg &);

 private:
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_HQS_TOP_H_
