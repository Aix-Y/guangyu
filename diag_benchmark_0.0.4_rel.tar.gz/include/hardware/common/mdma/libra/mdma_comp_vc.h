/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_VC_H_
#define HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_VC_H_

#include "hardware/include/mdma/mdma.h"

namespace efvf {
namespace hardware {
namespace mdma {

class MdmaCVcLibra : public MdmaCVc {
 public:
    explicit MdmaCVcLibra(Mdma *dma, MdmaEngineCompDesc_t &comp) : MdmaCVc(dma, comp) {}
    virtual ~MdmaCVcLibra() {}

 public:
    void HandleCfg(const MdmaCfg &);
    void Trigger(uint64_t = TIMEOUTMS_10S);
    bool WaitIdle(uint64_t = TIMEOUTMS_10S);
    bool IsVcDone(void);
    bool ClearVcDone(uint64_t = TIMEOUTMS_10S);
    bool IsVcOngoing(void);

 private:
    void     handle_cfg_vc_linear_copy(const MdmaCfg &);
    void     handle_cfg_vc_gather(const MdmaCfg &);
    void     handle_cfg_vc_scatter(const MdmaCfg &);
    void     handle_cfg_vc_polling(const MdmaCfg &);
    void     handle_cfg_vc_constant_filling(const MdmaCfg &);
    void     handle_cfg_vc_derived_scatter(const MdmaCfg &);
    void     set_vc_trig(uint32_t);
    bool     get_vc_trig_ext_en(void);
    void     set_vc_trig_ext(bool);
    bool     get_vc_trig_vc_en(void);
    void     set_vc_trig_vc(bool);
    uint32_t dec_vc_op(const MdmaOp_t &);
    void     set_vc_opctrl_op(const MdmaOp_t &);
    void     set_vc_opctrl_static_inst(bool, uint32_t);
    void     set_vc_opctrl_ctx(uint32_t);
    void     set_vc_opctrl_priority(uint32_t);
    void     set_vc_opctrl_fence(uint32_t);
    void     set_vc_opctrl_idmode(uint32_t);
    void     set_vc_opctrl_id(uint32_t);
    void     set_vc_opctrl_awcache(uint32_t);
    void     set_vc_opctrl_arcache(uint32_t);
    void     set_vc_opctrl_sig_mode(uint32_t);
    void     set_src_addr(uint64_t);
    void     set_dst_addr(uint64_t);
    void     set_size(const MdmaOp_t &, uint32_t, uint32_t = 0);
    void     set_dst_offset(uint32_t);
    void     set_scatter_res_id(uint32_t);
    void     set_scatter_derived_addr(uint32_t);
    void     set_constant_data(uint32_t);
    void     set_sig_cfg(uint32_t, bool, uint64_t, uint32_t);
    bool     get_repeat_src_en(void);
    bool     get_repeat_dst_en(void);
    void     set_repeat(bool, bool);
    uint32_t get_repeat_times(void);
    void     set_repeat_times(uint32_t);
    bool     wat_repeat_src_en_clr_possible(void);
    bool     wat_repeat_dst_en_clr_possible(void);
    bool     wat_repeat_src_en_clr(uint64_t);
    bool     wat_repeat_dst_en_clr(uint64_t);
    uint32_t get_src_repeat_ring_loop(void);
    void     set_src_repeat_ring_loop(uint32_t);
    bool     get_src_repeat_ring_loop_en(void);
    uint32_t get_dst_repeat_ring_loop(void);
    void     set_dst_repeat_ring_loop(uint32_t);
    bool     get_dst_repeat_ring_loop_en(void);
    void     set_src_repeat_stride(uint32_t);
    void     set_dst_repeat_stride(uint32_t);
    void     set_src_repeat_pp_offset(uint32_t);
    void     set_dst_repeat_pp_offset(uint32_t);
    bool     get_vc_trig_missing(void);
    void     clr_vc_trig_missing(void);
    bool     get_vc_done(void);
    bool     is_vc_done_clr(void);
    bool     clr_vc_done(uint64_t);
    uint32_t get_vc_state(void);
    bool     is_vc_state_busy(void);
    bool     is_vc_state_request(void);
    bool     is_vc_state_ongoing(void);
    void     dbg_vc_dump_status(void);
    bool     wat_vc_idle(uint64_t);
    bool     get_vc_int_trig_miss_en(void);
    void     set_vc_int_trig_miss(bool);
    bool     get_vc_int_done_en(void);
    void     set_vc_int_done(bool);
    uint32_t get_repeat_times_s(void);
    uint64_t get_repeat_addr_src_s(void);
    uint64_t get_repeat_addr_dst_s(void);
    uint32_t get_polling_s(void);
    uint32_t get_vc_idle_s(void);
    bool     is_vc_idle(void);
    bool     is_vc_busy(void);
    void     set_vc_awuser_19_16(uint32_t);
    void     set_vc_aruser_19_16(uint32_t);
    void     set_vc_scratch(uint32_t);
    void     set_vc_awuser_35_20(uint32_t);
    void     set_vc_aruser_35_20(uint32_t);
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_VC_H_
