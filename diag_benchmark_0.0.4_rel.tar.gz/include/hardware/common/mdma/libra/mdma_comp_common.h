/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_COMMON_H_
#define HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_COMMON_H_

#include "hardware/include/mdma/mdma.h"

namespace efvf {
namespace hardware {
namespace mdma {

class MdmaCCommonLibra : public MdmaCCommon {
 public:
    explicit MdmaCCommonLibra(Mdma *dma, MdmaEngineCompDesc_t &comp)
        : MdmaCCommon(dma, comp) {}
    virtual ~MdmaCCommonLibra() {}

 public:
    void HandleCfg(const MdmaCfg &);

 private:
    uint32_t get_br_raw(uint32_t);
    uint32_t get_bl_r();
    void     set_bl_r(uint32_t);
    uint32_t get_bl_w();
    void     set_bl_w(uint32_t);
    void     set_bl_rw(uint32_t, uint32_t);
    bool     get_axi_ost_ctrl_en(const MdmaAxiPort_t &);
    void     set_axi_ost_ctrl_en(const MdmaAxiPort_t &, bool);
    uint32_t get_axi_ost_ctrl_num(const MdmaAxiPort_t &);
    void     set_axi_ost_ctrl_num(const MdmaAxiPort_t &, uint32_t);
    uint32_t get_axi_qos(const MdmaAxiPort_t &);
    void     set_axi_qos(const MdmaAxiPort_t &, uint32_t);
    uint32_t get_lmem_addr_st(void);
    void     set_lmem_addr_st(uint32_t);
    uint32_t get_lmem_sz(void);
    void     set_lmem_sz(uint32_t);
    uint32_t get_lmem_map_addr_st(uint32_t);
    void     set_lmem_map_addr_st(uint32_t, uint32_t);
    bool     get_lmem_map_en(uint32_t);
    void     set_lmem_map_en(uint32_t, bool);
    uint32_t get_mcu_view_addr_st(const MdmaEle_t &);
    void     set_mcu_view_addr_st(const MdmaEle_t &, uint32_t);
    uint32_t get_mcu_view_addr_ed(const MdmaEle_t &);
    void     set_mcu_view_addr_ed(const MdmaEle_t &, uint32_t);
    uint32_t get_mcu_view_addr_offset(const MdmaEle_t &);
    void     set_mcu_view_addr_offset(const MdmaEle_t &, uint32_t);
    uint32_t get_spare_in(void);
    void     set_spare_in(uint32_t);
    uint32_t get_spare_out(void);
    void     set_spare_out(uint32_t);
    uint32_t get_lc_static_id(uint32_t);
    void     set_lc_static_id(uint32_t, uint32_t);
    uint32_t get_elcg_idle_cnts(void);
    void     set_elcg_idle_cnts(uint32_t);
    bool     get_int_ena(const MdmaEle_t &);
    void     set_int_ena(const MdmaEle_t &, bool);
    bool     get_int_vc_done(uint32_t);
    bool     get_cfdd_idle(uint32_t);
    bool     get_lc_idle(uint32_t);
    bool     get_scatter_idle(uint32_t);
    bool     get_gather_idle(void);
    bool     get_polling_idle(void);
    bool     get_port_idle(const MdmaEle_t &);
    uint32_t get_chobs_sel(const MdmaEle_t &, uint32_t);
    void     set_chobs_sel(const MdmaEle_t &, uint32_t, uint32_t);
    void     get_chobs_status(
        const MdmaEle_t &, const uint32_t &, uint32_t &, uint32_t &, uint32_t &);
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_COMMON_H_
