/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_COMMON_PMC_PAVO_PMC_H_
#define HARDWARE_COMMON_PMC_PAVO_PMC_H_
#include <map>
#include <memory>
#include <string>
#include <vector>
#include "boost/property_tree/ptree.hpp"
#include "hardware/common/pmc/pavo/pmc_counter.h"
#include "hardware/include/pmc.h"

namespace efvf {
namespace hardware {
namespace pmc {

class PmcPavo : public Pmc {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit PmcPavo(std::shared_ptr<spdlog::logger> logger) : Pmc(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~PmcPavo() {}

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual void LibInit();

    /**
     * @brief      Resets the given identifier.
     *
     * @param[in]  id    The identifier
     */
    virtual void Reset(int id = -1);

    /**
     * @brief      Start pmc counter
     *
     * @param[in]  id    The identifier
     */
    virtual void Start(int id = -1);

    /**
     * @brief      Stop pmc counter
     *
     * @param[in]  id    The identifier
     */
    virtual void Stop(int id = -1);

    /**
     * @brief      Gets the result.
     *
     * @return     The result.
     */
    virtual std::vector<uint64_t> GetResult();

    /**
     * @brief      Loads a setting 2.
     *
     * @param[in]  cfg   The configuration
     */
    virtual void LoadSetting2(const std::string &cfg);

    /**
     * @brief      Loads a with out setting.
     *
     * @param[in]  cfg   The configuration
     */
    virtual void LoadWithOutSel(const std::string &cfg);

    /**
     * @brief      Loads a setting.
     *
     * @param      ss    { parameter_description }
     */
    void LoadSetting(std::stringstream &ss) override;
    /**
     * @brief      Loads a setting.
     *
     * @param      json_filename   { the file name of a json file, which contains pmc setting }
     */
    void LoadSetting(const std::string &json_filename) override;

    /**
     * @brief      Gets the events description.
     *
     * @return     The events description.
     */
    virtual std::vector<std::string> &GetEventsDesc() {
        return events_;
    }

    /**
     * @brief      Gets the counter.
     *
     * @return     The counter.
     */
    virtual std::vector<int> &GetCounter() {
        return counters_;
    }

    /**
     * @brief      Prints a result.
     */
    virtual void PrintResult() {}

    /**
     * @brief      { function_description }
     */
    virtual void SelSetting();

 protected:
    /**
     * @brief      Loads an option.
     *
     * @param      ss    { parameter_description }
     */
    void LoadOpt(std::stringstream &ss);

    std::vector<std::string> events_;
    std::vector<int>         counters_;

    std::map<std::string, uint32_t> monitor_event_opt_;
    std::map<std::string, int>      start_event_opt_;
    std::map<std::string, int>      stop_event_opt_;

    int      state_      = 0;
    int      evt_or_cvl_ = 0;
    int      start_sel_  = 0;
    int      stop_sel_   = 0;
    int      int_mask_   = 0;
    uint32_t cvalue_     = 0;

    int                                          cnt_num_ = 0;
    std::vector<std::shared_ptr<PmcCounterPavo>> pmc_counters_;

 private:
    void LoadConfig(const boost::property_tree::ptree &pt);
};

class McAxiPmcPavo : public PmcPavo {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit McAxiPmcPavo(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~McAxiPmcPavo();

 private:
    /**
     * @brief      { function_description }
     */
    virtual void SelSetting();
};

}  // namespace pmc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_COMMON_PMC_PAVO_PMC_H_
