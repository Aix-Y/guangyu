/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_COMMON_PMC_LIBRA_PMC_H_
#define HARDWARE_COMMON_PMC_LIBRA_PMC_H_

#include <map>
#include <memory>
#include <string>
#include <vector>
#include "hardware/common/pmc/libra/pmc_counter.h"
#include "hardware/common/pmc/pavo/pmc.h"

namespace efvf {
namespace hardware {
namespace pmc {

class PmcLibra : public PmcPavo {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit PmcLibra(Hardware *bpm, std::shared_ptr<spdlog::logger> logger)
        : PmcPavo(logger) {
        bpm_      = bpm;
        name_     = bpm_->name_;
        ecf_addr_ = bpm_->ecf_addr_;
    }

    /**
     * @brief      Destroys the object.
     */
    virtual ~PmcLibra() {}

    /**
     * @brief      Resets the given identifier.
     *
     * @param[in]  id    The identifier
     */
    virtual void Reset(int id = -1);

    /**
     * @brief      Start pmc counter
     *
     * @param[in]  id    The identifier
     */
    virtual void Start(int id = -1);

    /**
     * @brief      Stop pmc counter
     *
     * @param[in]  id    The identifier
     */
    virtual void Stop(int id = -1);

    /**
     * @brief      Gets the result.
     *
     * @return     The result.
     */
    virtual std::vector<uint64_t> GetResult();

    /**
     * @brief      Prints a result.
     */
    virtual void PrintResult();

    /**
     * @brief      { function_description }
     */
    virtual void SelSetting();

 private:
    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual void LibInit();

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint64_t offset) {
        return bpm_->RegRead(offset);
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     * @param[in]  val     The value
     */
    virtual void RegWrite(uint64_t offset, uint32_t val) {
        return bpm_->RegWrite(offset, val);
    }

    Hardware *bpm_ = nullptr;
};

}  // namespace pmc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_PMC_LIBRA_PMC_H_
