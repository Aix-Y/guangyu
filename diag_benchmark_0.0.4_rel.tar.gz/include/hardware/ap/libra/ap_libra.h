/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_AP_LIBRA_AP_LIBRA_H_
#define HARDWARE_AP_LIBRA_AP_LIBRA_H_
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "hardware/ap/libra/ap_ras_libra.h"
#include "hardware/include/ap/ap.h"
#include "hardware/mailbox/mailbox_libra.h"

using efvf::hardware::mailbox::MailboxLibra;
using efvf::hardware::mailbox::MailboxLibraParam;

namespace efvf {
namespace hardware {
namespace ap {

class ApLibra : public Ap {
 private:
    Mdma *m_mdma_ptr;
    // std::shared_ptr<MailboxLibra> m_mbx_ptr[2];

 public:
    ApLibra() : Ap() {}
    explicit ApLibra(std::shared_ptr<spdlog::logger> logger);
    ~ApLibra();

    virtual bool HwInit();
    virtual bool HwDeinit();
    virtual void LibInit();
    virtual bool HwInitMini();

    virtual Ih *           GetMih();
    virtual Mdma *         GetMdma();
    virtual SystemAdapter *GetSa();
    // virtual Mailbox       *GetMailbox(uint32_t inst);
    virtual bool SetAxuserCtrl(
        uint32_t type, uint32_t ctx_id, uint32_t user_id, bool overwrite);
    virtual bool SetSaAgent(uint32_t ctx_id, bool en);
    virtual bool RegAccessTest();
    virtual bool TriggerTraceEvent(uint32_t event_type, uint32_t ctx_id, uint32_t proc_id);
    virtual bool ApBlr();
    virtual bool MailboxTest(uint32_t mb_inst, uint32_t mb_id, uint32_t uniq_id);
    virtual uint32_t MailboxErrTest(
        uint32_t mb_inst, uint32_t mb_id, uint32_t uniq_id, uint32_t type);

    virtual bool GetShareMemAddr(uint32_t &cf_addr, uint32_t &cf_offset, uint32_t &size);

    virtual bool SetBusMonTimeout(uint32_t to);
    virtual uint32_t GetNocDbgSts();
    virtual void     ClearPendingSts();

    virtual bool HandleToolReq(const std::string &req);
    virtual bool HandleToolReq(const std::string &req, uint64_t &in_out);

    virtual void SemResetLock(uint32_t id);
    virtual void SemSetCfg(uint32_t id, uint32_t credit);
    virtual bool SemGetLock(uint32_t id);
    virtual bool SemReleaseLock(uint32_t id);
    virtual uint32_t SemCurCredit(uint32_t id, bool &is_ovfl);
    //
    bool HandleSrammisc(Hardware *hw, uint32_t reg_addr, uint32_t idx, uint32_t inj_cnt = 1);

    void DbgShowHwInfo(Hardware *hw);
    void DbgShowRegInfo();

    //
    // void MboxInit();
    void MdmaInit();
    //
    Hardware *GetSaHw();
    Hardware *GetMdmaHw();
    Hardware *GetMihHw();
    Hardware *GetMmuHw();
    Hardware *GetApRegHw();
};

}  // namespace ap
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_AP_LIBRA_AP_LIBRA_H_
