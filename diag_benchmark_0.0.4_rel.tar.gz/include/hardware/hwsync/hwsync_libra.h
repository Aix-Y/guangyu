/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_HWSYNC_HWSYNC_LIBRA_H_
#define HARDWARE_HWSYNC_HWSYNC_LIBRA_H_

#include <framework/include/log.h>
#include <cstdint>
#include <initializer_list>
#include <map>
#include <memory>
#include <numeric>
#include <set>
#include <string>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>
#include "device/dtus/libra/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/hwsync/hwsync_new.h"
using efvf::framework::utils::Millis;
namespace efvf {
namespace hardware {
namespace hwsync {

// L3 hwsync
#define LIBRA_HWSYNC_ENTRY_NUM 1024
#define LIBRA_HWSYNC_CNT_NUM 256
#define LIBRA_HWSYNC_MUTEX_NUM 2048
#define LIBRA_HWSYNC_LUT_NUM 160
#define LIBRA_HWSYNC_ATOMIC_NUM 64
#define LIBRA_HWSYNC_MAX_CTX_NUM 16
#define LIBRA_HWSYNC_MAX_VG_NUM 8
#define LIBRA_HWSYNC_MAX_OUTSTANDING_NUM 256

typedef std::shared_ptr<spdlog::logger> ShrLog;

template <typename Taddr>
class HwSyncVgDesc {
 private:
    int    id_            = 0;
    int    vf_            = 0;
    Taddr  mutex_addr_    = 0;
    int    mutex_num_     = 0;
    Taddr  cnt_addr_      = 0;
    int    cnt_num_       = 0;
    int    entry_num_     = 0;
    int    sta_mutex_num_ = 0;
    int    sta_cnt_num_   = 0;
    ShrLog logger_;

 public:
    explicit HwSyncVgDesc(ShrLog logger) : logger_(logger) {}

    Taddr MutexAddr(int mutex_id) {
        LOG_ASSERT(mutex_id < mutex_num_,
            "vg {} mutex id should be in range [{}, {}), current value is {}", id_, 0,
            mutex_num_, mutex_id);
        return mutex_addr_ + 0x4 * mutex_id;
    }

    Taddr CntAddr(int cnt_id) {
        LOG_ASSERT(cnt_id < cnt_num_,
            "vg {} cnt id should be in range [{}, {}), current value is {}", id_, 0, cnt_num_,
            cnt_id);
        return cnt_addr_ + 0x4 * cnt_id;
    }

    void SetMutexBar(Taddr ba) {
        mutex_addr_ = ba;
    }

    void SetMutexNum(int mutex_num) {
        mutex_num_ = mutex_num;
    }

    void SetStaMutexNum(int sta_mutex_num) {
        sta_mutex_num_ = sta_mutex_num;
    }

    void SetCntNum(int cnt_num) {
        cnt_num_ = cnt_num;
    }

    void SetStaCntNum(int sta_cnt_num) {
        sta_cnt_num_ = sta_cnt_num;
    }

    void SetCntBar(Taddr ba) {
        cnt_addr_ = ba;
    }

    int GetEntryNum() {
        return entry_num_;
    }

    void SetEntryNum(int entry_num) {
        entry_num_ = entry_num;
    }

    void SetVf(int vf) {
        vf_ = vf;
    }
};

template <typename Taddr>
struct HwSyncRes {
    int mutex_num     = 0;
    int cnt_num       = 0;
    int entry_num     = 0;
    int atomicinc_num = 0;

    explicit HwSyncRes(const std::initializer_list<int> &list) {
        if (list.size() != 4) {
            throw;
        }
        mutex_num     = *list.begin();
        cnt_num       = *(list.begin() + 1);
        entry_num     = *(list.begin() + 2);
        atomicinc_num = *(list.begin() + 3);
    }
};

template <typename Taddr>
class HwSyncMgr {
 public:
    explicit HwSyncMgr(ShrLog logger) : logger_(logger) {}
    HwSyncMgr(ShrLog logger, int mutex_num, int cnt_num, int entry_num, int atomicinc_num)
        : logger_(logger) {}
    void ResInit(unsigned int vg, const std::initializer_list<int> &mutex_nums,
        const std::initializer_list<int> &cnt_nums,
        const std::initializer_list<int> &entry_nums) {
        LOG_ASSERT(vg == mutex_nums.size(), "invalid mutex init param");
        LOG_ASSERT(vg == cnt_nums.size(), "invalid cnt init param");
        LOG_ASSERT(vg == entry_nums.size(), "invalid entry init param");
        auto total_mutex_num = std::accumulate(mutex_nums.begin(), mutex_nums.end(), 0);
        auto total_cnt_num   = std::accumulate(cnt_nums.begin(), cnt_nums.end(), 0);
        auto total_entry_num = std::accumulate(entry_nums.begin(), entry_nums.end(), 0);
        LOG_ASSERT(total_mutex_num == res_.mutex_num,
            "total mutex num miss match, real {} vs. phy {}", total_mutex_num, res_.mutex_num);
        LOG_ASSERT(total_cnt_num == res_.cnt_num,
            "total cnt num miss match, real {} vs. phy {}", total_cnt_num, res_.cnt_num);
        LOG_ASSERT(total_entry_num == res_.entry_num,
            "total entry num miss match, real {} vs. phy {}", total_entry_num, res_.entry_num);
        Taddr mutex_ba = 0;
        Taddr cnt_ba   = 0;
        for (unsigned int vg_id = 0; vg_id < vg; vg_id++) {
            HwSyncVgDesc<Taddr> vg_desc(logger_);
            // set mutex
            vg_desc.SetMutexNum(*(mutex_nums.begin() + vg_id));
            vg_desc.SetMutexBar(mutex_ba);
            // set cnt
            vg_desc.SetCntNum(*(cnt_nums.begin() + vg_id));
            vg_desc.SetCntBar(cnt_ba);
            // set entry
            vg_desc.SetEntryNum(*(entry_nums.begin() + vg_id));
            // append desc
            desc_.push_back(std::move(vg_desc));
            // addr accumulation
            mutex_ba += sizeof(Taddr) * (*(mutex_nums.begin() + vg_id));
            cnt_ba += sizeof(Taddr) * (*(cnt_nums.begin() + vg_id));
        }
    }

    void StaticResInit(const std::initializer_list<int> &sta_mutex,
        const std::initializer_list<int> &               sta_cnt,
        const std::initializer_list<int> &               sta_entry) {
        auto vg = desc_.size();
        for (unsigned int vg_id = 0; vg_id < vg; vg_id++) {
            // set static mutex
            auto &vg_desc = desc_.at(vg_id);
            vg_desc.SetMutexNum(*(sta_mutex.begin() + vg_id));
            // set static cnt
            vg_desc.SetCntNum(*(sta_cnt.begin() + vg_id));
        }
    }

    void VgInit() {
        auto vg              = desc_.size();
        auto vg_static_alloc = [&](unsigned int vg_id) -> void {
            auto &desc          = desc_.at(vg_id);
            auto  sta_mutex_num = desc.GetStaMutexNum();
            auto  sta_cnt_num   = desc.GetStaCntNum();
            return;
        };
        for (unsigned int vg_id = 0; vg_id < vg; vg_id++) {
        }
    }

 private:
    std::vector<HwSyncVgDesc<Taddr>> desc_;
    HwSyncRes<Taddr>                 res_;
    ShrLog                           logger_;
    HwSync *                         hwsync_;
};

class HwSyncLibra : public HwSync {
 public:
    explicit HwSyncLibra(std::shared_ptr<spdlog::logger> logger) : HwSync(logger) {}
    virtual ~HwSyncLibra() {}
    // common interface
    virtual bool HwInit();

 public:
    virtual void InitVgResource(const HwSyncVgInitParam &res_param);
    virtual void InitCtx(const HwSyncCtxInitParam &ctx_param);
    virtual void InitLut(const HwSyncLutInitParam &lut_param);
    virtual void InitAllocStaCnt(const HwSyncStaCntAllocParam &cnt_sta_param);

    virtual void SetLut(const HwSyncLutInfo &lut_info);
    virtual void SetLut(uint32_t lut_id, uint32_t addr, uint32_t axi_id);
    virtual void SetRegister(const HwSyncRegisterInfo &register_info);
    virtual void ResetRegister(const HwSyncUnRegisterInfo &unregister_info);
    virtual void InitCnt(const HwSyncCntInitInfo &cnt_info);

    virtual void AllocStaCnt(const HwSyncStaCntAllocInfo &alloc_info);

 private:
    void InitVgMutexResNum(uint32_t vg_id, uint32_t total_num, uint32_t sta_num);
    void InitVgCntResNum(uint32_t vg_id, uint32_t total_num, uint32_t sta_num);
    void InitVgEntryResNum(uint32_t vg_id, uint32_t total_num);
    void InitCtxVgMap(uint32_t ctx_id, uint32_t vg_id);
    void InitLutNotifyAddr(uint32_t lut_id, uint32_t notify_addr);
    void InitLutAxiId(uint32_t lut_id, uint32_t axi_id);
    void InitStaticAlloc(uint32_t res_id, uint32_t static_alloc_id, uint32_t sync_type);

 public:
    virtual uint32_t GetMaxMutex();
    virtual uint32_t GetMaxCnt();
    virtual uint32_t GetMaxEntry();

    virtual uint32_t GetStaMutexNum(uint32_t static_mutex_num);
    virtual uint32_t GetStaCntNum(uint32_t static_cnt_num);
    virtual uint32_t GetDynMutexNum(uint32_t static_mutex_num);
    virtual uint32_t GetDynCntNum(uint32_t static_cnt_num);
    virtual uint32_t GetEntryNum(uint32_t entry_num);

    virtual void ForceClearEntry(uint32_t entry_id);
    virtual void ForceClearAllEntries();
    virtual void ForceClearCounter(uint32_t cnt_id);
    virtual void ForceClearAllCounters();
    virtual void ForceClearMutex(uint32_t mutex_id);
    virtual void ForceClearAllMutex();

 public:
    // MUTEX
    virtual uint32_t AllocMutex();
    virtual void DeallocMutex(uint32_t mutex_id);
    virtual bool TryLockMutex(uint32_t mutex_id);
    virtual void UnlockMutex(uint32_t mutex_id);
    // BARRIER
    virtual uint32_t AllocBarrier();
    virtual void DeallocBarrier(uint32_t barrier_id);
    virtual void SetBarrierCount(uint32_t barrier_id, uint32_t count, uint32_t uniq_id);
    virtual void RegisterBarrierWait(
        uint32_t barrier_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info);
    virtual void ArriveBarrier(uint32_t barrier_id, uint32_t uniq_id);
    virtual void ArriveAndDropBarrier(uint32_t barrier_id, uint32_t uniq_id);
    virtual void UnRegisterBarrierWait(uint32_t barrier_id, uint32_t uniq_id);
    // LATCH
    virtual uint32_t AllocLatch();
    virtual void DeallocLatch(uint32_t latch_id);
    virtual void SetLatchCount(uint32_t latch_id, uint32_t count, uint32_t uniq_id);
    virtual void RegisterLatchWait(
        uint32_t latch_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info);
    virtual void ArriveLatch(uint32_t latch_id, uint32_t count, uint32_t uniq_id);
    virtual void UnRegisterLatchWait(uint32_t latch_id, uint32_t uniq_id);
    virtual bool TryWaitLatch(uint32_t latch_id);
    // QUEUE
    virtual std::tuple<uint32_t, uint32_t> AllocQueue();
    virtual void DeallocQueue(uint32_t queue_producer_id);
    virtual void SetQueueProducerCount(
        uint32_t queue_producer_id, uint32_t count, uint32_t uniq_id);
    virtual void SetQueueConsumerCount(
        uint32_t queue_consumer_id, uint32_t count, uint32_t uniq_id);
    virtual void RegisterQueueProducer(
        uint32_t queue_producer_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info);
    virtual void RegisterQueueConsumer(
        uint32_t queue_consumer_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info);
    virtual void AdvanceWriteFar(uint32_t queue_producer_id, uint32_t uniq_id);
    virtual void AdvanceReadFar(uint32_t queue_consumer_id, uint32_t uniq_id);
    virtual void UnregisterQueueProducer(uint32_t queue_producer_id, uint32_t uniq_id);
    virtual void UnregisterQueueConsumer(uint32_t queue_consumer_id, uint32_t uniq_id);
    // AtomicInc
    virtual uint32_t ReadSelfIncrMem(uint32_t id);
    virtual void IncSelfIncrMem(uint32_t id);
    virtual void ClrSelfIncrMem(uint32_t id);

 public:
    // Reset
    virtual void ResetAllVg();
    virtual void ResetVg(uint8_t vg_id);
    // MISC
    virtual void SetCfMstOts(uint32_t ostd);
    virtual uint32_t GetMaxCfMstOts();
    virtual void SetLutAxidMax(uint32_t v);
    virtual void SetCfMstQos(uint32_t qos);
    virtual void SetIrqMifAxid(uint32_t axid);
    // Idle
    virtual bool WaitIdle(int timeout);
    virtual bool     AllIdle();
    virtual uint32_t CtxIdle();
    virtual bool CtxIdle(uint32_t ctx);
    // Clock
    virtual void EnableClkGating();
    virtual void DisableClkGating();
    // Self Clr
    virtual void SetCntSelfClr(const HwSyncCntSelfClrCfg &cfg);
    virtual void SetEntryVldSelfClr(const HwSyncEntryVldSelfClrCfg &cfg);
    virtual void SetCntTrigSelfClr(const HwSyncCntTrigSelfClrCfg &cfg);
    // Dbg
    virtual void EnableErrorHang();
    virtual void DisableErrorHang();
    // Interrupt
    virtual void ConfigInterrupt(const HwSyncInterruptCfg &cfg);
    virtual bool               HasInterrupt();
    virtual HwSyncInterruptSts GetInterruptSts();
    virtual HwSyncInterruptLog GetInterruptLog();
    virtual void ClearInterrupt(const std::vector<HwSyncInt> &interrupt);
    virtual void ClearAllInterrupt();
    virtual void ClearInterrupt(uint32_t mask);
    virtual void ClearInterruptLog();
    virtual void ClearInterruptWdata();

 private:
    std::unordered_map<uint32_t, HwSyncCntInitInfo> cnt_info_;
};

}  // namespace hwsync
}  // namespace hardware
}  // namespace efvf

#endif  //  HARDWARE_HWSYNC_HWSYNC_LIBRA_H_
