/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_HWSYNC_L1HWSYNC_LIBRA_H_
#define HARDWARE_HWSYNC_L1HWSYNC_LIBRA_H_

#include <framework/include/log.h>
#include <cstdint>
#include <initializer_list>
#include <map>
#include <memory>
#include <numeric>
#include <set>
#include <string>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>
#include "device/dtus/libra/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/hwsync/hwsync_new.h"
using efvf::framework::utils::Millis;
namespace efvf {
namespace hardware {
namespace hwsync {

// L3 hwsync
#define LIBRA_L1HWSYNC_ENTRY_NUM 256
#define LIBRA_L1HWSYNC_CNT_NUM 64
#define LIBRA_L1HWSYNC_MUTEX_NUM 255
#define LIBRA_L1HWSYNC_LUT_NUM 160
#define LIBRA_L1HWSYNC_ATOMIC_NUM 32
#define LIBRA_L1HWSYNC_MAX_OUTSTANDING_NUM 128

typedef std::shared_ptr<spdlog::logger> ShrLog;

class L1HwSyncLibra : public HwSync {
 public:
    explicit L1HwSyncLibra(std::shared_ptr<spdlog::logger> logger) : HwSync(logger) {}
    virtual ~L1HwSyncLibra() {}
    // common interface
    virtual bool HwInit();

 public:
    virtual void InitVgResource(const HwSyncVgInitParam &res_param);
    virtual void InitCtx(const HwSyncCtxInitParam &ctx_param);
    virtual void InitLut(const HwSyncLutInitParam &lut_param);
    virtual void InitAllocStaCnt(const HwSyncStaCntAllocParam &cnt_sta_param);

    virtual void SetLut(const HwSyncLutInfo &lut_info);
    virtual void SetLut(uint32_t lut_id, uint32_t addr, uint32_t axi_id);
    virtual void SetRegister(const HwSyncRegisterInfo &register_info);
    virtual void ResetRegister(const HwSyncUnRegisterInfo &unregister_info);
    virtual void InitCnt(const HwSyncCntInitInfo &cnt_info);

    virtual void AllocStaCnt(const HwSyncStaCntAllocInfo &alloc_info);

 private:
    void InitVgMutexResNum(uint32_t vg_id, uint32_t total_num, uint32_t sta_num);
    void InitVgCntResNum(uint32_t vg_id, uint32_t total_num, uint32_t sta_num);
    void InitVgEntryResNum(uint32_t vg_id, uint32_t total_num);
    void InitCtxVgMap(uint32_t ctx_id, uint32_t vg_id);
    void InitLutNotifyAddr(uint32_t lut_id, uint32_t notify_addr);
    void InitLutAxiId(uint32_t lut_id, uint32_t axi_id);
    void InitStaticAlloc(uint32_t res_id, uint32_t static_alloc_id, uint32_t sync_type);

 public:
    virtual uint32_t GetMaxMutex();
    virtual uint32_t GetMaxCnt();
    virtual uint32_t GetMaxEntry();

    virtual uint32_t GetStaMutexNum(uint32_t static_mutex_num);
    virtual uint32_t GetStaCntNum(uint32_t static_cnt_num);
    virtual uint32_t GetDynMutexNum(uint32_t static_mutex_num);
    virtual uint32_t GetDynCntNum(uint32_t static_cnt_num);
    virtual uint32_t GetEntryNum(uint32_t entry_num);

    virtual void ForceClearEntry(uint32_t entry_id);
    virtual void ForceClearAllEntries();
    virtual void ForceClearCounter(uint32_t cnt_id);
    virtual void ForceClearAllCounters();
    virtual void ForceClearMutex(uint32_t mutex_id);
    virtual void ForceClearAllMutex();

 public:
    // MUTEX
    virtual uint32_t AllocMutex();
    virtual void DeallocMutex(uint32_t mutex_id);
    virtual bool TryLockMutex(uint32_t mutex_id);
    virtual void UnlockMutex(uint32_t mutex_id);
    // BARRIER
    virtual uint32_t AllocBarrier();
    virtual void DeallocBarrier(uint32_t barrier_id);
    virtual void SetBarrierCount(uint32_t barrier_id, uint32_t count, uint32_t uniq_id);
    virtual void RegisterBarrierWait(
        uint32_t barrier_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info);
    virtual void ArriveBarrier(uint32_t barrier_id, uint32_t uniq_id);
    virtual void ArriveAndDropBarrier(uint32_t barrier_id, uint32_t uniq_id);
    virtual void UnRegisterBarrierWait(uint32_t barrier_id, uint32_t uniq_id);
    // LATCH
    virtual uint32_t AllocLatch();
    virtual void DeallocLatch(uint32_t latch_id);
    virtual void SetLatchCount(uint32_t latch_id, uint32_t count, uint32_t uniq_id);
    virtual void RegisterLatchWait(
        uint32_t latch_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info);
    virtual void ArriveLatch(uint32_t latch_id, uint32_t count, uint32_t uniq_id);
    virtual void UnRegisterLatchWait(uint32_t latch_id, uint32_t uniq_id);
    virtual bool TryWaitLatch(uint32_t latch_id);
    // QUEUE
    virtual std::tuple<uint32_t, uint32_t> AllocQueue();
    virtual void DeallocQueue(uint32_t queue_producer_id);
    virtual void SetQueueProducerCount(
        uint32_t queue_producer_id, uint32_t count, uint32_t uniq_id);
    virtual void SetQueueConsumerCount(
        uint32_t queue_consumer_id, uint32_t count, uint32_t uniq_id);
    virtual void RegisterQueueProducer(
        uint32_t queue_producer_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info);
    virtual void RegisterQueueConsumer(
        uint32_t queue_consumer_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info);
    virtual void AdvanceWriteFar(uint32_t queue_producer_id, uint32_t uniq_id);
    virtual void AdvanceReadFar(uint32_t queue_consumer_id, uint32_t uniq_id);
    virtual void UnregisterQueueProducer(uint32_t queue_producer_id, uint32_t uniq_id);
    virtual void UnregisterQueueConsumer(uint32_t queue_consumer_id, uint32_t uniq_id);
    // AtomicInc
    virtual uint32_t ReadSelfIncrMem(uint32_t id);
    virtual void IncSelfIncrMem(uint32_t id);
    virtual void ClrSelfIncrMem(uint32_t id);

 public:
    // Reset
    virtual void ResetAllVg();
    virtual void ResetVg(uint8_t vg_id);
    // MISC
    virtual void SetCfMstOts(uint32_t ostd);
    virtual uint32_t GetMaxCfMstOts();
    virtual void SetLutAxidMax(uint32_t v);
    virtual void SetCfMstQos(uint32_t qos);
    virtual void SetIrqMifAxid(uint32_t axid);
    // Idle
    virtual bool WaitIdle(int timeout);
    virtual bool     AllIdle();
    virtual uint32_t CtxIdle();
    virtual bool CtxIdle(uint32_t ctx);
    // Clock
    virtual void EnableClkGating();
    virtual void DisableClkGating();
    // Self Clr
    virtual void SetCntSelfClr(const HwSyncCntSelfClrCfg &cfg);
    virtual void SetEntryVldSelfClr(const HwSyncEntryVldSelfClrCfg &cfg);
    virtual void SetCntTrigSelfClr(const HwSyncCntTrigSelfClrCfg &cfg);
    // Dbg
    virtual void EnableErrorHang();
    virtual void DisableErrorHang();
    // Interrupt
    virtual void ConfigInterrupt(const HwSyncInterruptCfg &cfg);
    virtual bool               HasInterrupt();
    virtual HwSyncInterruptSts GetInterruptSts();
    virtual HwSyncInterruptLog GetInterruptLog();
    virtual void ClearInterrupt(const std::vector<HwSyncInt> &interrupt);
    virtual void ClearAllInterrupt();
    virtual void ClearInterrupt(uint32_t mask);
    virtual void ClearInterruptLog();
    virtual void ClearInterruptWdata();

 private:
    std::unordered_map<uint32_t, HwSyncCntInitInfo> cnt_info_;
};

}  // namespace hwsync
}  // namespace hardware
}  // namespace efvf

#endif  //  HARDWARE_HWSYNC_L1HWSYNC_LIBRA_H_
