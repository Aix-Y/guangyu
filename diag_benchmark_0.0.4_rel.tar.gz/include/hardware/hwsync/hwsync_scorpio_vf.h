/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_HWSYNC_HWSYNC_SCORPIO_VF_H_
#define HARDWARE_HWSYNC_HWSYNC_SCORPIO_VF_H_

#include <memory>
#include <set>
#include <string>
#include "hardware/hwsync/hwsync_scorpio.h"
#include "hardware/include/hardware.h"
#include "hardware/include/hwsync/hwsync.h"

namespace efvf {
namespace hardware {
namespace hwsync {

class HwsyncScorpioVf : public HwsyncScorpio {
 public:
    explicit HwsyncScorpioVf(std::shared_ptr<spdlog::logger> logger) : HwsyncScorpio(logger) {}
    virtual ~HwsyncScorpioVf() {}

    virtual uint32_t RegRead(uint64_t offset);

    virtual void RegWrite(uint64_t offset, uint32_t val);

 private:
    Dtu *dtu_ = nullptr;
};

}  // namespace hwsync
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_HWSYNC_HWSYNC_SCORPIO_VF_H_
