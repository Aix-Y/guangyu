/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_PAVO_PARSER_PAVO_H_
#define HARDWARE_PROFILER_PAVO_PARSER_PAVO_H_

#include <cstdint>
#include <string>

#include "hardware/profiler/parser2d0.h"

namespace efvf {
namespace hardware {
namespace profiler {

class ProfilerRingPavo;
class ParserPavo : public Parser2D0 {
 public:
    explicit ParserPavo(ProfilerRingPavo *ring);
    virtual ~ParserPavo() = default;

 protected:
    DpfMasterType GetMasterType(uint32_t master_id) override;
    std::string GetMasterName(uint32_t master_id) override;
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_PAVO_PARSER_PAVO_H_
