/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_LIBRA_EVENT_PARSER_LIBRA_H_
#define HARDWARE_PROFILER_LIBRA_EVENT_PARSER_LIBRA_H_

#include <cstdint>

#include <iostream>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

#include "hardware/profiler/libra/parser_libra.h"

namespace efvf {
namespace hardware {
namespace profiler {

typedef struct {
    uint32_t master_id : 10;
    uint32_t context_id : 4;
    uint32_t die_id : 1;
    uint32_t pid : 16;
    uint32_t event_flg : 1;
} TraceHeader;

typedef struct {
    uint32_t fine_timer : 14;
    uint32_t type : 9;
    uint32_t asid : 4;
    uint32_t counter : 4;
    uint32_t counter_flg : 1;
} TraceMisc;

typedef struct {
    TraceHeader head;
    TraceMisc   misc;
    uint32_t    timer_high;
    uint32_t    packet_id;
} EventTracePacket;

typedef struct {
    TraceHeader           head;
    TraceMisc             misc;
    uint32_t              timer_high;
    std::vector<uint32_t> content;
} CustomizedEventPacket;

class ParserEventLibra : public ParserLibra {
 public:
    explicit ParserEventLibra(ProfilerRingLibra *ring);
    virtual ~ParserEventLibra() = default;

    //!
    //! @brief parse all events in corresponding specified system buffer
    //!
    void Parse(std::string   filename = "",
        std::vector<uint8_t> len      = std::vector<uint8_t>(8, 4)) override;

    //!
    //! @brief get duration from first valid event to last valid event
    //!
    //! it doesn't parse all events. It finds the first and the last valid event,
    //! and, calculate the duration. It will much faster than Parser() for
    //! large event number
    uint64_t GetDuration() override;
    // duration between master's first event and last event
    uint64_t GetDuration(uint16_t master_id) override;
    // duration between first event and last event
    uint64_t GetOverallDuration() override;

    //!
    //! @brief print summary of parsed result
    //!
    void PrintSummary() override;
    void PrintTraceEvents() override;

    //!
    //! @brief write parsed events to a json file
    //!
    void WritetoFile(const std::string &json_filename) override;

    //!
    //! @brief Find the timestamp of a specific event from a given master
    //!
    uint64_t GetEventTimestamp(
        uint32_t master_id, uint8_t event_type, uint32_t index, bool reverve = false) override;
    //!
    //! @brief accessor
    //!
    std::map<uint32_t, std::vector<TraceEvent>> trace_events() {
        return trace_events_;
    }
    std::map<uint32_t, std::vector<CustomizedEvent>> customized_events() {
        return customized_events_;
    }

 private:
    void ConvertTraceEventToJson(boost::property_tree::ptree &root);
    void ConvertGdteTraceEventToJson(uint32_t master_id, std::vector<TraceEvent> &events,
        boost::property_tree::ptree &ptree_events);
    void ConvertSipTraceEventToJson(uint32_t master_id, std::vector<TraceEvent> &events,
        boost::property_tree::ptree &ptree_events);
    // void ConvertVppTraceEventToJson(uint32_t master_id, std::vector<TraceEvent> &events,
    //     boost::property_tree::ptree &ptree_events);
    std::vector<uint64_t> ConvertRawDataToFormatedData(
        const uint8_t *data, const std::vector<uint8_t> &len);

 private:
    //!
    //! @brief property tree root for all events
    //!
    // boost::property_tree::ptree ptree_root_;
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_LIBRA_EVENT_PARSER_LIBRA_H_
