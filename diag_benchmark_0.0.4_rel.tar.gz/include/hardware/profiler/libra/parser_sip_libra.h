/**
 *
 * Enflame Tech, All Rights Reserved. 2021 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_LIBRA_PARSER_SIP_LIBRA_H_
#define HARDWARE_PROFILER_LIBRA_PARSER_SIP_LIBRA_H_

namespace efvf {
namespace hardware {
namespace profiler {

//!
//! @brief sip events
//!
enum DpfSipEventType {
    XPU_ENTER_RUN          = 0,
    XPU_ENTER_HALT         = 1,
    XPU_ENTER_BUSY         = 2,
    XPU_EXIT_BUSY          = 3,
    XPU_ENTER_WAIT_MAILBOX = 4,
    XPU_EXIT_WAIT_MAILBOX  = 5,
    XPU_ENTER_WAIT_GSYNC   = 6,
    XPU_EXIT_WAIT_GSYNC    = 7,
    XPU_EVENT_NUM          = 16,
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_LIBRA_PARSER_SIP_LIBRA_H_
