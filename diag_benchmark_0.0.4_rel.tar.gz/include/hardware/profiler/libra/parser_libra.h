/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_LIBRA_PARSER_LIBRA_H_
#define HARDWARE_PROFILER_LIBRA_PARSER_LIBRA_H_

#include "hardware/include/profiler/parser.h"

#include <cstdint>

#include <iostream>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

#include "hardware/profiler/libra/profiler_libra.h"
namespace efvf {
namespace hardware {
namespace profiler {

typedef struct {
    uint32_t reserved0 : 15;
    uint32_t pid : 16;
    uint32_t reserved1 : 1;
} LogEventHeader;

typedef struct {
    LogEventHeader head;
    uint32_t       data;
} LogEventPacket;

class ParserLibra : public Parser {
 public:
    // messages are always sent to DPF ring buffer in the unit of 128B
    static const uint32_t kDpfMsgSize = 128;

 public:
    explicit ParserLibra(ProfilerRingLibra *ring);
    virtual ~ParserLibra() = default;

    DpfMasterType GetMasterType(uint32_t master_id) override;
    std::string GetMasterName(uint32_t master_id) override;
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_LIBRA_PARSER_LIBRA_H_
