/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_LIBRA_LOG_BUFFER_PARSER_LIBRA_H_
#define HARDWARE_PROFILER_LIBRA_LOG_BUFFER_PARSER_LIBRA_H_

#include <cstdint>

#include <string>
#include <vector>

#include "hardware/profiler/libra/parser_libra.h"

namespace efvf {
namespace hardware {
namespace profiler {

typedef struct {
    uint32_t master_id : 10;
    uint32_t context_id : 4;
    uint32_t die_id : 1;
    uint32_t process_id : 16;
    uint32_t drop_flag : 1;
} LogBufferEventHeader;

class ParserLogBufferLibra : public ParserLibra {
 public:
    explicit ParserLogBufferLibra(ProfilerRingLibra *ring) : ParserLibra(ring) {}
    virtual ~ParserLogBufferLibra() = default;

    //!
    //! @brief parse all events in corresponding specified system buffer
    //!
    void Parse(std::string   filename = "",
        std::vector<uint8_t> len      = std::vector<uint8_t>(8, 4)) override;

    //!
    //! @brief print summary of parsed result
    //!
    void PrintSummary() override;
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_LIBRA_LOG_BUFFER_PARSER_LIBRA_H_
