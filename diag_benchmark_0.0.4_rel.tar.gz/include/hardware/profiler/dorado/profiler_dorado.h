/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_DORADO_PROFILER_DORADO_H_
#define HARDWARE_PROFILER_DORADO_PROFILER_DORADO_H_

#include <cstdint>
#include <memory>

#include "hardware/include/profiler/profiler.h"

namespace efvf {
namespace hardware {
namespace profiler {
class ProfilerDorado : public Profiler {
    //!
    //! Only one ring buffer for Pavo DPF
    //!
    static const uint32_t DORADO_DPF_RING_NUM = 1;

 public:
    explicit ProfilerDorado(std::shared_ptr<spdlog::logger> logger);
    virtual ~ProfilerDorado() = default;
};

class ProfilerRingDorado : public ProfilerRing {
 public:
    explicit ProfilerRingDorado(ProfilerDorado *profiler);
    virtual ~ProfilerRingDorado() = default;

    void FlushFifo() override;

 private:
    void SetupHW(const RingCfg &cfg) override;
    void StartHW() override;
    void StopHW() override;
    void GetProducerStatus(uint32_t &wptr, bool &wwrap) override;
    void Move(uint64_t ring_offset, uint64_t buff_offset, uint64_t size) override;
    void Update(const uint32_t &rptr, const bool &rwrp) override;
    bool IsDfOngoing();
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_PROFILER_DORADO_PROFILER_DORADO_H_
