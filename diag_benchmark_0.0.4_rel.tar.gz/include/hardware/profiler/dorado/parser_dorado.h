/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_DORADO_PARSER_DORADO_H_
#define HARDWARE_PROFILER_DORADO_PARSER_DORADO_H_

#include <cstdint>
#include <string>

#include "hardware/profiler/parser2d0.h"

namespace efvf {
namespace hardware {
namespace profiler {

class ProfilerRingDorado;
class ParserDorado : public Parser2D0 {
 public:
    explicit ParserDorado(ProfilerRingDorado *ring);
    virtual ~ParserDorado() = default;

 protected:
    DpfMasterType GetMasterType(uint32_t master_id) override;
    std::string GetMasterName(uint32_t master_id) override;
};
}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_DORADO_PARSER_DORADO_H_
