/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_CBF_CBF_DP_CBF_DP_SCORPIO_H_
#define HARDWARE_CBF_CBF_DP_CBF_DP_SCORPIO_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "hardware/include/cbf/cbf_dp.h"

namespace efvf {
namespace hardware {
namespace cbf {
namespace cbf_dp {

#define SCORPIO_CBF_BB_HASH_CFG_BITS 15
#define SCORPIO_CBF_SB_HASH_CFG_BITS 11
#define SCORPIO_CBF_BC_HASH_CFG_BITS 25

class CbfDpScorpio : public CbfDp {
 public:
    explicit CbfDpScorpio(std::shared_ptr<spdlog::logger> logger);
    virtual ~CbfDpScorpio();

    virtual void EnableHash(CbfType cbf_type);

    virtual void DisableHash(CbfType cbf_type);

    virtual void ConfigHashAddr(const CbfHashCfg &cbf_hash_cfg);

    virtual uint64_t GetHashAddr(CbfType cbf_type, uint64_t addr);

    virtual void EnableDeHash();

    virtual void DisableDeHash();

    virtual void ConfigDeHash(const CbfDeHashCfg &dehash_cfg);

    virtual void SetVfDeHash(const CbfVfType &cbf_vf_type);

    virtual void SetCbfGroupNum(const CbfVfType &cbf_vf_type);

    virtual uint32_t GetCbfGroupNum();

    virtual void SetCbfIndex(uint8_t idx);

    virtual void SetCacheLineTimeout(uint8_t num);

    virtual void ConfigCacheMaintenance(const CbfCacheMtnCfg &cbf_mtn_cfg);

    virtual bool WaitCacheMaintenanceDone(const CbfCacheMtnCfg &cbf_mtn_cfg);

    virtual void RestoreCacheMaintenanceSetting();

    virtual void SetHwPrefSize(const CbfCachePrefSize hw_pref_size, uint32_t *pref_size_val);

    virtual void SetHwPrefOutstanding(uint32_t outstd_num);

    virtual void SetHwPrefQos(
        const CbfCachePrefType &pref_type, const CbfCachePrefQosType &qos_num);

    virtual void RestoreHwPrefSetting();

    virtual void EnableDpRwBurstMerge(const CbfRwType &rw_type);

    virtual void DisableDpRwBurstMerge(const CbfRwType &rw_type);

 protected:
    virtual uint32_t GetDieId() {
        return parent_->parent_->parent_->parent_->inst_;
        // DIE_INST::CBF_INST::CBF_CHN0_SYS::CBF_DP::CBF_DP_BLOCK
    }

 private:
    std::vector<std::bitset<SCORPIO_CBF_BB_HASH_CFG_BITS>> bb_hash_mask_ = {};
    std::vector<std::bitset<SCORPIO_CBF_SB_HASH_CFG_BITS>> sb_hash_mask_ = {};
    std::vector<std::bitset<SCORPIO_CBF_BC_HASH_CFG_BITS>> bc_hash_mask_ = {};
};

}  // namespace cbf_dp
}  // namespace cbf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CBF_CBF_DP_CBF_DP_SCORPIO_H_
