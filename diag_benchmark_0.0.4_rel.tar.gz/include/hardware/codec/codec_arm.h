/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_CODEC_CODEC_ARM_H_
#define HARDWARE_CODEC_CODEC_ARM_H_

#include <list>
#include <memory>
#include <string>
#include <vector>

#include "framework/include/mem.h"
#include "hardware/codec/mve_define.h"
#include "hardware/include/vpp_codec/vpp_codec.h"
#include "hardware/include/vpp_evp/vpp_evp.h"

using efvf::hardware::vpp::Vpp;

namespace efvf {
namespace hardware {
namespace codec {

// combo_top and decoder_top
#define CODEC_HW_COMBO_TOP (0)
#define CODEC_HW_DECODER_TOP (1)

#define CODEC_VER_SCORPIO (0)
#define CODEC_VER_LIBRA (1)

#define VPP_CODEC_DDR_MEM_OFFSET (0x1000000)
#define VPP_CODEC_DDR_MEM_ALIGN (0x1000)
// #define VPP_CODEC_FIRMWARE_INST_NUM (1)  // (0x8)

class CodecArm : public Codec {
 public:
    Hardware * m_hw_ptr;
    std::mutex m_deq_mtx;
    std::mutex m_enq_mtx;
    std::mutex m_rpc_mtx;
    std::mutex m_q_mtx;
    //
    std::shared_ptr<spdlog::logger> logger_;

    uint32_t m_codec_inst;
    uint32_t m_waiting_msg_flag;
    uint32_t m_setoption_cnt;
    uint32_t CODEC_REG_OFFSET;
    uint32_t m_codec_ext_addr_bit;  // IPA [40:47] bit
    uint32_t m_codec_version;       // 0 - scorpio, 1 - libra
    uint32_t m_asid;

    bool m_mmu_on;
    bool m_is_exit;

    std::unique_ptr<std::thread> m_irq_handle;
    //
    uint32_t m_fw_state;
    uint32_t m_buffer_min;
    uint32_t m_interlaced;
    uint32_t m_lsid;
    uint32_t m_ncores;
    uint32_t m_disallow_cores;
    uint32_t m_user_id;
    uint32_t m_io_buf_in_ddr;  // 0 - host, 1 - ddr
    uint32_t m_port_fmt[MVE_DIR_MAX];
    uint32_t m_buf_cnt[MVE_DIR_MAX];
    uint32_t m_buf_size[MVE_DIR_MAX];
    uint32_t m_img_width[MVE_DIR_MAX];
    uint32_t m_img_height[MVE_DIR_MAX];
    uint32_t m_frame_cnt;
    uint32_t m_crop_x;
    uint32_t m_crop_y;
    uint32_t m_rotation;  // 0/1/2/3
    uint32_t m_mirror;    // 0/1/2/
    bool     m_crop_en;
    bool     m_resize_en;
    bool     m_is_decoder;
    bool     m_output_flushed;
    // option
    int32_t  m_ignore_stream_headers;
    int32_t  m_frame_reordering;
    int32_t  m_nalu_fmt;
    int32_t  m_stream_escaping;
    int32_t  m_profiling;
    uint64_t m_codec_frames_num;
    uint64_t m_sum_frames_fps;
    uint64_t m_max_frame_fps;
    uint64_t m_min_frame_fps;
    uint64_t m_last_frame_fps;
    double   m_average_fps;
    int32_t  m_ddr_die_id;

    uint32_t m_sfo_itvl;  //

    std::chrono::time_point<std::chrono::high_resolution_clock> m_start_point;

    // encoder
    uint32_t m_profile;  // init 0
    uint32_t m_level;
    uint32_t m_rc_type;  // 0
    uint32_t m_rc_mode;
    uint32_t m_bitrate;
    uint32_t m_max_bitrate;
    uint32_t m_frame_rate;
    uint32_t m_rc_bit_i_mode;   // 0
    uint32_t m_rc_bit_i_ratio;  // 0
    uint32_t m_mulit_sps_pps;   // 0
    uint32_t m_enable_visual;   // 0
    bool     m_rc_enabled;      // false
    int32_t  m_qp_min;
    int32_t  m_qp_max;
    uint32_t m_fixedqp;     // 0
    uint32_t m_qp_i_frame;  // 0
    uint32_t m_qp_p_frame;  // 0
    uint32_t m_qp_b_frame;  // 0
    uint32_t m_qp_min_i;    // 0
    uint32_t m_qp_max_i;    // 0
    uint32_t m_qp_i;        // 0
    uint32_t m_p_frames;    // 0
    uint32_t m_b_frames;    // 0

    // #define MVE_OPT_GOP_TYPE_BIDIRECTIONAL              (1)
    // #define MVE_OPT_GOP_TYPE_LOW_DELAY                  (2)
    // #define MVE_OPT_GOP_TYPE_PYRAMID                    (3)
    // #define MVE_OPT_GOP_TYPE_SVCT3                      (4)
    // #define MVE_OPT_GOP_TYPE_GDR                        (5)
    uint32_t m_gop_type;             // 0
    uint32_t m_inter_med_buf_size;   // 0
    int32_t  m_constr_ipred;         // -1
    uint32_t m_jpeg_quality;         // 0
    uint32_t m_jpeg_quality_chroma;  // 0
    uint32_t m_jpeg_quality_luma;    // 0
    uint32_t m_min_luma_cb_size;     // 0
    int32_t  m_entropy_sync;         // -1
    int32_t  m_temporal_mvp;         // -1

    uint32_t m_tile_rows;          // 0
    uint32_t m_tile_cols;          // 0
    uint32_t m_entropy_mode;       // 0 : CAVLC, 1: CABAC
    uint32_t m_slice_spacing_mb;   // 0
    uint32_t m_cabac_init_idc;     // 0
    uint32_t m_crop_left;          // 0
    uint32_t m_crop_right;         // 0
    uint32_t m_crop_top;           // 0
    uint32_t m_crop_bottom;        // 0
    uint32_t m_nHRDBufsize;        // 0
    uint32_t m_ltr_mode;           // 0
    uint32_t m_ltr_period;         // 0
    uint32_t m_gdr_number;         // 0
    uint32_t m_gdr_period;         // 0
    uint32_t m_vp9_prob_update;    // 0
    uint32_t m_mv_h_search_range;  // 0
    uint32_t m_mv_v_search_range;  // 0
    uint32_t m_bitdepth_chroma;    // 0
    uint32_t m_bitdepth_luma;      // 0
    uint32_t m_chroma_format;      // 0
    uint32_t m_rgb_to_yuv_mode;    // 0
    uint32_t m_band_limit;         // 0
    uint32_t m_init_qpi;           // 0
    uint32_t m_init_qpp;           // 0
    uint32_t m_sao_luma;           // 0
    uint32_t m_sao_chroma;         // 0
    uint32_t m_qp_delta_i_p;       // 0
    uint32_t m_ref_rb_en;          // 0
    uint32_t m_rc_qp_clip_top;     // 0
    uint32_t m_rc_qp_clip_bot;     // 0
    uint32_t m_mini_frame_cnt;     // 0

    // comm
    uint32_t m_msg_pending;

    struct mve_rpc_communication_area g_rpc_area;

    uint32_t m_frame_size;
    uint32_t m_frame_nplane;
    uint32_t m_frame_plane_size[3];
    uint32_t m_frame_stride[3];
    uint32_t m_setting_stride[3];
    // firmware
    Mem *m_mem_text;
    Mem *m_mem_bss;
    Mem *m_mem_bss_shared;
    // mmu
    Mem *              m_l1_pagetable;  //
    std::vector<Mem *> m_l2_pagetable_vec;

    std::vector<std::shared_ptr<Mem>> m_mem_all_vec;

// hw register session
// communication
#define CODEC_MSG_INQ_HOST_TO_MVE (0)
#define CODEC_MSG_OUTQ_MVE_TO_HOST (1)
#define CODEC_BUF_INQ_HOST_TO_MVE (2)
#define CODEC_BUF_INRQ_MVE_TO_HOST (3)
#define CODEC_BUF_OUTQ_HOST_TO_MVE (4)
#define CODEC_BUF_OUTRQ_MVE_TO_HOST (5)
#define CODEC_RPC_Q_MVE_HOST (6)
#define CODEC_PRINT_RAM_Q (7)
#define CODEC_MSG_Q_MAX_NUM (8)
#define CODEC_MSG_Q_MEM_SIZE (0x1000)
    Mem *m_mve_queue_mem[CODEC_MSG_Q_MAX_NUM];
    // RPC memory
    std::vector<Mem *> m_rpc_mem_vec;
    //
    uint32_t latest_used_region_protected_pages;
    uint32_t latest_used_region_outbuf_pages;

    // buffer
    std::vector<struct mve_core_buffer *> m_data_buffer_vec[MVE_DIR_MAX];
    std::list<struct mve_core_buffer *>   m_data_buffer_ready_q[MVE_DIR_MAX];
    // std::list<struct mve_core_buffer *>   m_data_buffer_wait_q[MVE_DIR_MAX];
    std::list<struct mve_core_buffer *> m_data_buffer_pending_q[MVE_DIR_MAX];

 public:
    CodecArm() {}
    CodecArm(uint32_t codec_inst, Hardware *hw, uint32_t reg_offset,
        std::shared_ptr<spdlog::logger> logger);
    ~CodecArm();
    //
    uint32_t CodecRegRead(uint64_t offset) {
        return m_hw_ptr->RegRead(CODEC_REG_OFFSET + offset);
    }
    void CodecRegWrite(uint64_t offset, uint32_t val) {
        return m_hw_ptr->RegWrite(CODEC_REG_OFFSET + offset, val);
    }

 public:
    virtual bool OpenCodec(uint32_t inst);
    virtual bool CloseCodec();
    virtual bool InitCodec(CodecConfig &cfg);
    virtual bool DeinitCodec();
    //
    virtual bool SetUserInfo(uint32_t lsid, uint64_t ipa_addr, uint32_t axuser);
    // Libra support 48 bit IPA L3 addr, codec Only support 40 bit mmu
    uint64_t FixedLibraIpa48Bit(uint64_t phy_addr_48);
    bool CheckLibraExtAddrBit(uint64_t phy_addr);

    virtual bool RegisterPortMem(Mem *m, uint32_t dir);
    virtual Mem *GetPortMem(uint32_t dir, uint32_t &offset, uint32_t &data_len);
    virtual bool PutPortMem(Mem *m, uint32_t data_len, uint32_t dir);
    virtual bool GetPortMem(PortBufInfo &info);
    virtual bool PutPortMem(PortBufInfo &info);
    virtual bool GetCodecStatus(CodecStatus &info);

    virtual bool SetL2Cache(bool en);
    virtual bool WaitOutputFlushed() {
        return m_output_flushed;
    }

    virtual bool CodecRegAccessTest();
    virtual bool GetFrameInfo(uint32_t fmt, uint32_t w, uint32_t h, uint32_t *np,
        uint32_t *stride, uint32_t *plane_size, uint32_t *setting_stride);
    virtual bool GetFrameInfo2(uint32_t *np, uint32_t *stride, uint32_t *plane_size);
    virtual bool MemConstFill(uint64_t buf_addr, uint64_t buf_size, uint32_t pattern);
    virtual bool DataCopy(uint64_t src_addr, uint64_t dst_addr, uint64_t size);
    virtual uint32_t GetDataCrc(uint64_t src_addr, uint64_t dst_addr, uint64_t size);
    // For libdmm
    virtual int32_t InitCodec();
    virtual int32_t GetCodecOpt(uint32_t opt, int64_t &val);
    virtual int32_t SetCodecOpt(uint32_t opt, int64_t val);

    // common
    void IrqThreadProc();
    void HandleIrq(uint32_t lsid);
    bool InitCodecCfgByUser(CodecConfig &cfg);
    //
    uint32_t GetFrameDir();
    uint32_t GetBitstreamDir();

    // profiling
    void     SetClkforceCore();
    uint32_t GetCodecFps();
    void CodecProcessedInfo(struct mve_event_processed *p);

    //
    bool WaitingForMsg(uint32_t flag, uint32_t time_out_sec = 3);

    void DbgShowHwReg();
    void DbgShowBuffer(struct mve_core_buffer *b);
    void DbgShowEventProcessed(struct mve_event_processed *p);
    void DbgShowEventRefFrame(struct mve_event_ref_frame *p);
    void DbgShowEventTraceBuffers(struct mve_event_trace_buffers *p);
    void DbgSetCodecFps(uint32_t inst, uint32_t fps);
    uint32_t DbgGetCodecFps(uint32_t inst);

    //
    uint64_t GetMemAddr(Mem *m, uint32_t addr_type = 1);
    Mem *AllocaMem(uint32_t size, MemType type = MemType::MEM_TYPE_DMEM);

 public:
    //  firmware
    bool LoadFw(const std::string &fw_name, uint32_t ncores);
    // mmu
    bool mmuInit();
    bool mapProtocol_v3();
    bool mmuMapMem(Mem *m, uint32_t vaddr, mve_mmu_attrib attr, mve_mmu_access access);
    bool mmuMapMem(uint64_t phy_addr, uint64_t size, uint32_t vaddr, mve_mmu_attrib attr,
        mve_mmu_access access);
    bool mmuUnmapMem(uint64_t phy_addr, uint64_t size, uint32_t va);
    // HW
    bool hwInit();
    bool hwExit();
    bool hwLsidMap(uint32_t lsid, uint32_t ncores, uint32_t disallow_cores, uint32_t user_id);
    bool hwLsidUnmap(uint32_t lsid);
    bool hwLsidJobQueueAdd(uint32_t lsid, uint32_t ncores);
    bool hwLsidJobQueueRemove();
    bool hwLsidFlushMmu(uint32_t lsid);
    bool hwLsidSingleIrq(uint32_t lsid);
    bool hwAckHostIrq();
    bool hwLsidTerminate(uint32_t lsid);
    bool hwIsLsidAlloc(uint32_t lsid);

    // communication
    // void PutMsgToMve(mve_core_message &msg);
    bool PutMsgToMveSimple(uint32_t cmd);
    bool PutMsgToMveJob(uint32_t ncores, uint32_t frames, uint32_t flags);
    bool PutMsgToMveDebug(uint32_t level);
    bool PutMsgToMveSetOption(struct mve_request_set_option &option, uint32_t size);
    bool GetMsgFromMve();
    bool HandleMsg(struct mve_core_message &msg);
    bool HandleEvent(struct mve_response_event &event);
    bool PutBufToMve(struct mve_core_buffer *buf, uint32_t dir);
    bool PutBufToMveBitstream(struct mve_core_buffer *buf, uint32_t dir);
    bool PutBufToMveFrame(struct mve_core_buffer *buf, uint32_t dir);
    bool PutBufToMveEos(uint32_t dir, bool is_frame);
    bool PutBufToMveParam(struct mve_buffer_param &param, uint32_t size);
    bool GetBufFromMve(struct mve_core_message &msg, uint32_t dir);
    bool comm_queue_enqueue(Mem *host_q, Mem *mve_q, uint16_t code, uint16_t size, void *data);
    bool comm_queue_dequeue(
        Mem *host_q, Mem *mve_q, uint16_t &code, uint16_t &size, void *data);

    bool PutFwEosToMve();
    //
    bool rpcHandle(uint32_t lsid);
    // buffer
    bool CreateBuffer(uint32_t buf_cnt, uint32_t dir);
    bool MapPortBuffer(struct mve_core_buffer *buf);
    bool UpdateCoreBuffer(struct mve_core_buffer *buf, uint32_t dir);
    bool PutPendingBufferToMve(uint32_t dir);

    struct mve_core_buffer *FindMveBufByMem(Mem *m, uint32_t dir);

    void convert_buffer_bitstream(
        uint32_t dir, struct mve_core_message *msg, struct mve_buffer_bitstream *b);
    void convert_buffer_frame(
        uint32_t dir, struct mve_core_message *msg, struct mve_buffer_frame *f);
    void convert_buffer_param(
        uint32_t dir, struct mve_core_message *msg, struct mve_buffer_param *p);
    void convert_buffer_general(
        uint32_t dir, struct mve_core_message *msg, struct mve_buffer_general *g);

    //
    bool PutBufToPendingQ(struct mve_core_buffer *buf, uint32_t dir);
    bool PutBufToReadyQ(struct mve_core_buffer *buf, uint32_t dir);
    int GetReadyQBufCnt(uint32_t dir);

    struct mve_core_buffer *GetBufFromPendingQ(uint32_t dir);
    struct mve_core_buffer *GetBufFromReadyQ(uint32_t dir);

    bool rpcMemAlloc(struct mve_rpc_communication_area *rpc_area);
    bool rpcMemResize(struct mve_rpc_communication_area *rpc_area);
    bool rpcMemFree(struct mve_rpc_communication_area *rpc_area);
    Mem *FindRpcMem(uint32_t va);
    // codec
    bool SetupDecoderOpt();
    bool SetupEncoderOpt();
    bool SetupCommonOpt();
};

}  // namespace codec
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CODEC_CODEC_ARM_H_
