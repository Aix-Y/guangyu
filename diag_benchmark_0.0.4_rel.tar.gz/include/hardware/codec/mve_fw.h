/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_CODEC_MVE_FW_H_
#define HARDWARE_CODEC_MVE_FW_H_
#include <stdint.h>
#include "customize/customize.h"
#include "hardware/codec/mve_protocol_def_libra.h"

namespace efvf {
namespace hardware {
namespace codec {

/**
 * struct mvx_fw_header - Firmware binary header.
 * @rasc_jmp:        Start address.
 * @protocol_minor:    Host internface protocol minor version.
 * @protocol_major:    Host internface protocol major version.
 * @reserved:        Reserved for future use. Always 0.
 * @info_string:    Human readable codec information.
 * @part_number:    Part number.
 * @svn_revision:    SVN revision.
 * @version_string:    Firmware version.
 * @text_length:    Length in bytes of the read-only part of the firmware.
 * @bss_start_address:    Start address for BSS segment. This is always
 *                      page-aligned.
 * @bss_bitmap_size:    The number of bits used in 'bss_bitmap'.
 * @bss_bitmap:        Bitmap which pages that shall be allocated and MMU
 *                      mapped. If bit N is set, then a page shall be allocated
 *                      and MMU mapped to VA address
 *                      FW_BASE + bss_start_address + N * MVE_PAGE_SIZE.
 * @master_rw_start_address: Defines a region of shared pages.
 * @master_rw_size:    Defines a region of shared pages.
 */
struct fw_header {
    uint32_t rasc_jmp;
    uint8_t  protocol_minor;
    uint8_t  protocol_major;
    uint8_t  reserved[2];
    uint8_t  info_string[56];
    uint8_t  part_number[8];
    uint8_t  svn_revision[8];
    uint8_t  version_string[16];
    uint32_t text_length;
    uint32_t bss_start_address;
    uint32_t bss_bitmap_size;
    uint32_t bss_bitmap[16];
    uint32_t master_rw_start_address;
    uint32_t master_rw_size;
};

/* Look up an added firmware.
 * It returns a template L2 page table for the first 4MB with text pages already
 * allocated.
 * Format:
 * bit 31-2 page nr, i.e. physical address >> 12
 * bit  1-0 type of page.
 */
typedef enum {
    FWMGR_PAGETYPE_INVALID = 0, /**< No page */
    FWMGR_PAGETYPE_TEXT    = 1, /**< TEXT page, shared between sessions. Page is allocated. */
    FWMGR_PAGETYPE_BSS     = 2, /**< BSS page, separate per core in same session. */
    FWMGR_PAGETYPE_BSS_SHARED = 3, /**< BSS page, shared across cores in same session. */
} mve_fw_pagetype_t;

/**
 * test_bit_32() - 32 bit version Linux test_bit.
 *
 * Test if bit is set in bitmap array.
 */
bool test_bit_32(int bit, uint32_t *addr);

/**
 * enum mvx_fw_region - Firmware memory regions.
 */
enum fw_region {
    FW_REGION_CORE_0,
    FW_REGION_CORE_1,
    FW_REGION_CORE_2,
    FW_REGION_CORE_3,
    FW_REGION_CORE_4,
    FW_REGION_CORE_5,
    FW_REGION_CORE_6,
    FW_REGION_CORE_7,
    FW_REGION_PROTECTED,
    FW_REGION_FRAMEBUF,
    FW_REGION_MSG_HOST,
    FW_REGION_MSG_MVE,
    FW_REGION_BUF_IN_HOST,
    FW_REGION_BUF_IN_MVE,
    FW_REGION_BUF_OUT_HOST,
    FW_REGION_BUF_OUT_MVE,
    FW_REGION_RPC,
    FW_REGION_PRINT_RAM
};

bool get_region_v3(uint32_t region, uint32_t &begin, uint32_t &end);

/**
 * enum mvx_fw_code - Codes for messages sent between driver and firmware.
 */
enum mvx_fw_code {
    MVX_FW_CODE_ALLOC_PARAM,    /* Driver <- Firmware. */
    MVX_FW_CODE_BUFFER,         /* Driver <-> Firmware. */
    MVX_FW_CODE_ERROR,          /* Driver <- Firmware. */
    MVX_FW_CODE_IDLE,           /* Driver <- Firmware. */
    MVX_FW_CODE_INPUT_FLUSH,    /* Driver <-> Firmware. */
    MVX_FW_CODE_OUTPUT_FLUSH,   /* Driver <-> Firmware. */
    MVX_FW_CODE_JOB,            /* Driver -> Firmware. */
    MVX_FW_CODE_PING,           /* Driver -> Firmware. */
    MVX_FW_CODE_PONG,           /* Driver <- Firmware. */
    MVX_FW_CODE_SEQ_PARAM,      /* Driver <- Firmware. */
    MVX_FW_CODE_SET_OPTION,     /* Driver <-> Firmware. */
    MVX_FW_CODE_STATE_GO,       /* Driver <-> Firmware. */
    MVX_FW_CODE_STATE_STOP,     /* Driver <-> Firmware. */
    MVX_FW_CODE_SWITCH_IN,      /* Driver <- Firmware. */
    MVX_FW_CODE_SWITCH_OUT,     /* Driver <-> Firmware. */
    MVX_FW_CODE_IDLE_ACK,       /* Driver -> Firmware. */
    MVX_FW_CODE_EOS,            /* Driver <-> Firmware. */
    MVX_FW_CODE_COLOR_DESC,     /* Driver <- Firmware. */
    MVX_FW_CODE_DUMP,           /* Driver <-> Firmware. */
    MVX_FW_CODE_DEBUG,          /* Driver <-> Firmware. */
    MVX_FW_CODE_BUFFER_GENERAL, /* Driver <-> Firmware. */
    MVX_FW_CODE_DISPLAY_SIZE,   /* Driver <- Firmware. */
    MVX_FW_CODE_UNKNOWN,        /* Driver <- Firmware. */
    MVX_FW_CODE_MAX
};

struct mve_core_buffer {
    // the buffer is allocated as a single block of memory,
    // and then individual plane pointers are defined with offsets
    // from this base pointer
    void *   mem_ptr;
    uint64_t mem_addr;
    uint32_t buf_size;
    uint32_t data_size;
    uint32_t offset;
    uint32_t virtual_addr;
    uint32_t dir;
    // uint32_t decode;  // 0: dec, 1: enc
    uint32_t flags;
    // online process
    uint32_t format;
    uint32_t width;
    uint32_t height;
    uint32_t crop_left;
    uint32_t crop_top;
    uint32_t src_transform;
    //
    uint32_t frame_type;
    uint32_t nplanes;

    uint32_t type;
#define MVE_CORE_BUFFER_FRAME (0)
#define MVE_CORE_BUFFER_BITSTREAM (1)
#define MVE_CORE_BUFFER_GENERAL (2)
#define MVE_CORE_BUFFER_PARAM (3)

    union {
        struct mve_buffer_frame     frame;
        struct mve_buffer_bitstream bitstream;
        struct mve_buffer_general   general;
        struct mve_buffer_param     param;
    } __attribute__((aligned(8))) buffer;
} __attribute__((aligned(8)));

// clang-format off
#define MVX_BUFFER_EOS                  0x00000001
#define MVX_BUFFER_EOF                  0x00000002
#define MVX_BUFFER_CORRUPT              0x00000004
#define MVX_BUFFER_REJECTED             0x00000008
#define MVX_BUFFER_DECODE_ONLY          0x00000010
#define MVX_BUFFER_CODEC_CONFIG         0x00000020
#define MVX_BUFFER_AFBC_TILED_HEADERS   0x00000040
#define MVX_BUFFER_AFBC_TILED_BODY      0x00000080
#define MVX_BUFFER_AFBC_32X8_SUPERBLOCK 0x00000100
#define MVX_BUFFER_INTERLACE            0x00000200
#define MVX_BUFFER_END_OF_SUB_FRAME     0x00000400
#define MVX_BUFFER_FRAME_PRESENT        0x00000800

#define MVX_BUFFER_FRAME_FLAG_ROTATION_90   0x00001000  /* Frame is rotated 90 degrees */
#define MVX_BUFFER_FRAME_FLAG_ROTATION_180  0x00002000  /* Frame is rotated 180 degrees */
#define MVX_BUFFER_FRAME_FLAG_ROTATION_270  0x00003000  /* Frame is rotated 270 degrees */
#define MVX_BUFFER_FRAME_FLAG_ROTATION_MASK 0x00003000

#define MVX_BUFFER_FRAME_FLAG_MIRROR_HORI   0x00010000
#define MVX_BUFFER_FRAME_FLAG_MIRROR_VERT   0x00020000
#define MVX_BUFFER_FRAME_FLAG_MIRROR_MASK   0x00030000

#define MVX_BUFFER_FRAME_FLAG_SCALING_2     0x00004000  /* Frame is scaled by half */
#define MVX_BUFFER_FRAME_FLAG_SCALING_4     0x00008000  /* Frame is scaled by quarter */
#define MVX_BUFFER_FRAME_FLAG_SCALING_MASK  0x0000C000

#define MVX_BUFFER_FRAME_FLAG_GENERAL       0x00040000  /* Frame is a general buffer */
#define MVX_BUFFER_FRAME_FLAG_ROI           0x00080000  /* This buffer has a roi region */
#define MVX_BUFFER_FRAME_FLAG_CHR           0x01000000

#define MVX_BUFFER_FRAME_NEED_REALLOC       0x00100000  /* This buffer needs realloc */
#define MVX_BUFFER_FRAME_FLAG_GOP_REST      0x00200000  /* This buffer needs gop reset */
#define MVX_BUFFER_FRAME_FLAG_LTR_REST      0x00400000
#define MVX_BUFFER_FRAME_FLAG_FORCE_IDR    (0x00800000)
#define MVX_BUFFER_ENC_STATS                0x02000000

// clang-format on
// Message returned from mve_core_wait_for_notification. Corresponds to messages
// sent from firmware to host.
struct mve_core_message {
    union {
        struct mve_core_buffer *                   buffer;
        struct mve_response_frame_alloc_parameters decoded_frame_alloc_parameters;
        struct mve_response_sequence_parameters    decoded_sequence_parameters;
        struct mve_event_ref_frame                 refframe;
        struct mve_response_job_dequeued           job_dequeued;
        struct mve_buffer_param                    buffer_param;
        // struct mve_response_set_option_fail        set_option_confirm;
        struct mve_response_set_option_fail  set_option_fail;
        struct mve_response_ref_frame_unused ref_frame_unused;
        struct mve_response_error            error;
        struct mve_response_event            event;
        struct mve_response_state_change     state_change;
        struct mve_response_switched_in      switched_in;
        struct mve_response_switched_out     switched_out;
        uint8_t                              raw_data[1024];
    } message;

    uint16_t message_code;
    uint16_t data_size;
};

const char *string_from_msg_code(uint32_t code);

#define WAITING_MSG_FLAG_SWITCHTCHED_IN (0x00000001)
#define WAITING_MSG_FLAG_SET_OPTION_CONFIRM (0x00000002)
#define WAITING_MSG_FLAG_JOB_DEQUEUED (0x00000004)
#define WAITING_MSG_FLAG_STATE_CHANGE (0x00000008)
#define WAITING_MSG_FLAG_FRAME_ALLOC_PARAM (0x000000010)
#define WAITING_MSG_FLAG_SEQ_PARAM (0x00000020)
#define WAITING_MSG_FLAG_OUTPUT_FLUSHED (0x00000040)
#define WAITING_MSG_FLAG_SWITCHED_OUT (0x00000080)
#define WAITING_MSG_FLAG_SET_OPTION_FAIL (0x00000100)

/**
 * enum mvx_format - List of compressed formats and frame formats.
 *
 * Enumeration of formats that are supported by all know hardware revisions.
 *
 * The enumeration should start at 0 and should not contain any gaps.
 */
enum mvx_format {
    /* Compressed formats. */
    MVX_FORMAT_BITSTREAM_FIRST,
    MVX_FORMAT_AVS = MVX_FORMAT_BITSTREAM_FIRST,
    MVX_FORMAT_AVS2,
    MVX_FORMAT_H263,
    MVX_FORMAT_H264,
    MVX_FORMAT_HEVC,
    MVX_FORMAT_JPEG,
    MVX_FORMAT_MPEG2,
    MVX_FORMAT_MPEG4,
    MVX_FORMAT_RV,
    MVX_FORMAT_VC1,
    MVX_FORMAT_VP8,
    MVX_FORMAT_VP9,
    MVX_FORMAT_AV1,
    MVX_FORMAT_BITSTREAM_LAST = MVX_FORMAT_AV1,

    /* Uncompressed formats. */
    MVX_FORMAT_FRAME_FIRST,
    MVX_FORMAT_YUV420_AFBC_8 = MVX_FORMAT_FRAME_FIRST,
    MVX_FORMAT_YUV420_AFBC_10,
    MVX_FORMAT_YUV422_AFBC_8,
    MVX_FORMAT_YUV422_AFBC_10,
    MVX_FORMAT_YUV420_I420,
    MVX_FORMAT_YUV420_NV12,
    MVX_FORMAT_YUV420_NV21,
    MVX_FORMAT_YUV420_P010,
    MVX_FORMAT_YUV422_YUY2,
    MVX_FORMAT_YUV422_UYVY,
    MVX_FORMAT_YUV422_Y210,
    MVX_FORMAT_RGBA_8888,
    MVX_FORMAT_BGRA_8888,
    MVX_FORMAT_ARGB_8888,
    MVX_FORMAT_ABGR_8888,
    MVX_FORMAT_RGB_888,
    MVX_FORMAT_BGR_888,
    MVX_FORMAT_RGB_888_3P,
    MVX_FORMAT_Y,
    MVX_FORMAT_Y_10,
    MVX_FORMAT_YUV444,
    MVX_FORMAT_YUV444_10,
    MVX_FORMAT_YUV420_2P_10,
    MVX_FORMAT_YUV422_1P_10,
    MVX_FORMAT_YUV420_I420_10,
    MVX_FORMAT_YUV444_1P_10,
    MVX_FORMAT_YUV420_Y0L2,
    MVX_FORMAT_BGR_888_3P,
    MVX_FORMAT_FRAME_LAST = MVX_FORMAT_BGR_888_3P,

    MVX_FORMAT_MAX
};

enum mve_direction { MVE_DIR_INPUT, MVE_DIR_OUTPUT, MVE_DIR_MAX };

#define SUBSAMPLE_PIXELS 2

int mvx_buffer_frame_dim(uint32_t format, uint32_t width, uint32_t height, uint32_t *nplanes,
    uint32_t *stride, uint32_t *size, uint32_t *setting_stride);
/**
 * get_stride() - Get 3 plane stride for 2x2 pixels square.
 * @format:    MVX frame format.
 * @stride:    [plane 0, plane 1, plane 2][x, y] stride.
 *
 * Calculate the stride in bytes for each plane for a subsampled (2x2) pixels
 * square.
 *
 * Return: 0 on success, else error code.
 */
int get_stride(uint32_t format, uint32_t *nplanes, uint32_t stride[3][2]);

/**
 * mvx_is_bitstream(): Detect if format is of type bitstream.
 * @format:    Format.
 *
 * Return: True if format is bitstream, else false.
 */
bool mvx_is_bitstream(uint32_t format);

/**
 * mvx_is_frame(): Detect if format is of type frame.
 * @format:    Format.
 *
 * Return: True if format is frame, else false.
 */
bool mvx_is_frame(uint32_t format);

/**
 * mvx_is_rgb(): Detect if format is of type RGB.
 * @format:    Format.
 *
 * Return: True if format is RGB, else false.
 */
bool mvx_is_rgb(uint32_t format);

/**
 * mvx_is_rgb24(): Detect if format is of type RGB24.
 * @format:    Format.
 *
 * Return: True if format is RGB24, else false.
 */

bool mvx_is_rgb24(uint32_t format);

const char *mvx_get_codec_fw_name(bool is_dec, uint32_t fmt);

}  // namespace codec
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CODEC_MVE_FW_H_
