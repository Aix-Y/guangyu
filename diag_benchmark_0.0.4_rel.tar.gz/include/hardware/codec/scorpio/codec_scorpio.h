/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_CODEC_SCORPIO_CODEC_SCORPIO_H_
#define HARDWARE_CODEC_SCORPIO_CODEC_SCORPIO_H_

#include <memory>
#include "hardware/codec/codec_arm.h"
// #include "hardware/vpu/vpu_libra.h"
#include "hardware/include/vpp_evp/vpp_evp.h"

using efvf::hardware::vpp::Vpp;

// using efvf::hardware::codec::CodecScorpio;

namespace efvf {
namespace hardware {
namespace codec {

class CodecScorpio : public CodecArm {
 private:
 public:
    CodecScorpio() {}
    CodecScorpio(uint32_t codec_inst, Vpp *pvpp, std::shared_ptr<spdlog::logger> logger);
    ~CodecScorpio();

    bool HwInit();
    bool HwDeinit();
    void Snapshot();

    virtual bool MemConstFill(uint64_t buf_addr, uint64_t buf_size, uint32_t pattern);
    virtual bool DataCopy(uint64_t src_addr, uint64_t dst_addr, uint64_t size);
    virtual uint32_t GetDataCrc(uint64_t src_addr, uint64_t dst_addr, uint64_t size);

    //
};

}  // namespace codec
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CODEC_SCORPIO_CODEC_SCORPIO_H_
