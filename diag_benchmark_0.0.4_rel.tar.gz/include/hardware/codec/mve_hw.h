/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_CODEC_MVE_HW_H_
#define HARDWARE_CODEC_MVE_HW_H_
#include <stdint.h>
#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace codec {

// #define MVX_HWREG_FUSE_DISABLE_AFBC (1 << 0)
// #define MVX_HWREG_FUSE_DISABLE_REAL (1 << 1)
// #define MVX_HWREG_FUSE_DISABLE_VPX (1 << 2)
// #define MVX_HWREG_FUSE_DISABLE_HEVC (1 << 3)

#define MVE_JOBQUEUE_JOB_BITS 8
#define MVE_JOBQUEUE_JOB_MASK ((1 << MVE_JOBQUEUE_JOB_BITS) - 1)
#define MVE_JOBQUEUE_JOB_INVALID 0xf
#define MVE_JOBQUEUE_NJOBS 4
#define MVE_JOBQUEUE_LSID_SHIFT 0
#define MVE_JOBQUEUE_LSID_BITS 4
#define MVE_JOBQUEUE_LSID_MASK ((1 << MVE_JOBQUEUE_LSID_BITS) - 1)
#define MVE_JOBQUEUE_NCORES_SHIFT 4
#define MVE_JOBQUEUE_NCORES_BITS 4

#define MVE_BUSCTRL_SPLIT_SHIFT (0)
#define MVE_BUSCTRL_SPLIT_BITS (2)
#define MVE_BUSCTRL_SPLIT_MASK ((1 << MVE_BUSCTRL_SPLIT_BITS) - 1)
#define MVE_BUSCTRL_REF64_SHIFT (2)
#define MVE_BUSCTRL_REF64_BITS (1)

#define MVE_CORELSID_LSID_BITS 4
#define MVX_CORELSID_LSID_MASK ((1 << MVE_CORELSID_LSID_BITS) - 1)

#define MVE_CTRL_DISALLOW_SHIFT 0
#define MVE_CTRL_DISALLOW_BITS 8
#define MVE_CTRL_DISALLOW_MASK ((1 << MVE_CTRL_DISALLOW_BITS) - 1)
#define MVE_CTRL_MAXCORES_SHIFT 8
#define MVE_CTRL_MAXCORES_BITS 4
#define MVE_CTRL_MAXCORES_MASK ((1 << MVE_CTRL_MAXCORES_BITS) - 1)
#define MVE_CTRL_USERINFO_SHIFT 12

#define MVE_CLKFORCE_CS_SHIFT (8)
#define MVE_CLKFORCE_CS_BITS (1)
#define MVE_CLKFORCE_CS_MASK ((1 << MVE_CLKFORCE_CS_BITS) - 1)

#define MVE_ALLOC_FREE 0
#define MVE_ALLOC_NON_PROTECTED 1
#define MVE_ALLOC_PROTECTED 2

/**
 * enum mvx_hwreg_what - Hardware registers that can be read or written.
 */
enum hwreg_codec {
    HWREG_HARDWARE_ID,
    HWREG_ENABLE,
    HWREG_NCORES,
    HWREG_NLSID,
    HWREG_CORELSID,
    HWREG_JOBQUEUE,
    HWREG_IRQVE,
    HWREG_CLKFORCE,
    HWREG_FUSE,
    HWREG_PROTCTRL,
    HWREG_BUSCTRL,
    HWREG_RESET,
    HWREG_WHAT_MAX
};

/**
 * enum mvx_hwreg_lsid - Hardware registers per LSID.
 */
enum hwreg_lsid_reg {
    LSID_HWREG_CTRL,
    LSID_HWREG_MMU_CTRL,
    LSID_HWREG_NPROT,
    LSID_HWREG_ALLOC,
    LSID_HWREG_FLUSH_ALL,
    LSID_HWREG_SCHED,
    LSID_HWREG_TERMINATE,
    LSID_HWREG_LIRQVE,
    LSID_HWREG_IRQHOST,
    LSID_HWREG_INTSIG,
    LSID_HWREG_USERINFO,
    LSID_HWREG_STREAMID,
    LSID_HWREG_BUSATTR_0,
    LSID_HWREG_BUSATTR_1,
    LSID_HWREG_BUSATTR_2,
    LSID_HWREG_BUSATTR_3,
    LSID_HWREG_LSID_MAX
};

uint32_t codec_reg_offset(enum hwreg_codec what);
uint32_t codec_lsid_reg_offset(uint32_t lsid, enum hwreg_lsid_reg what);

uint32_t get_core_lsid(uint32_t reg, unsigned int core);

uint32_t get_jobqueue_job(uint32_t reg, unsigned int nr);

uint32_t set_jobqueue_job(uint32_t reg, unsigned int nr, uint32_t job);

uint32_t get_jobqueue_lsid(uint32_t reg, unsigned int nr);

uint32_t set_lsid_ncores(
    uint32_t reg, unsigned int nr, unsigned int lsid, unsigned int ncores);

}  // namespace codec
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CODEC_MVE_HW_H_
