/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_IH_IH_LIBRA_H_
#define HARDWARE_IH_IH_LIBRA_H_

#include <cstdint>
#include <map>
#include <memory>
#include <string>
#include <vector>
#include "hardware/include/ih.h"

namespace efvf {
namespace hardware {
namespace ih {

typedef struct _MIH_ENTRY_HEADER_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    uint32_t master_id : 10;
    uint32_t die_id : 1;
    uint32_t rsvd : 1;
    uint32_t ctx_id : 4;
    uint32_t ip_info : 4;  // libra changed for asid or sip thread slot id
    uint32_t timestamp : 10;
    uint32_t msg_type : 2;
#elif BYTE_ORDER == BIG_ENDIAN
    uint32_t msg_type : 2;
    uint32_t timestamp : 10;
    uint32_t ip_info : 4;  // libra changed for asid or sip thread slot id
    uint32_t ctx_id : 4;
    uint32_t rsvd : 1;
    uint32_t die_id : 1;
    uint32_t master_id : 10;
#endif
} MIH_ENTRY_HEADER_t;

typedef struct _MIH_IRQ_CAUSE0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    uint32_t userdata : 24;
    uint32_t cause_id : 8;
#elif BYTE_ORDER == BIG_ENDIAN
    uint32_t cause_id : 8;
    uint32_t userdata : 24;
#endif
} MIH_IRQ_CAUSE0_t;

typedef union {
    unsigned int     val : 32;
    MIH_IRQ_CAUSE0_t f;
} MIH_IRQ_CAUSE0_u;

typedef struct _MIH_IRQ_ENTRY_t {
    MIH_ENTRY_HEADER_t header;
    MIH_IRQ_CAUSE0_t   cause0;
} MIH_IRQ_ENTRY_t;

typedef struct _MIH_RPC_ENTRY_t {
    MIH_ENTRY_HEADER_t header;
    uint32_t           rpcdata0;
    uint32_t           rpcdata1;
    uint32_t           dummy;
} MIH_RPC_ENTRY_t;

typedef struct _MIH_DBG_ENTRY_t {
    MIH_ENTRY_HEADER_t header;
    uint32_t           dbg_data;
} MIH_DBG_ENTRY_t;

class IhLibra : public Ih {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    IhLibra() : Ih() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit IhLibra(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~IhLibra() {
        Deinit();
    }

    /**
     * @brief      Sets the ring location.
     *
     * @param[in]  loc   The new value
     */
    virtual void SetRingLoc(std::string loc) {
        if (loc == "host") {
            ring_loc_ = MemType::MEM_TYPE_HOST;
        } else {
            ring_loc_ = MemType::MEM_TYPE_DMEM;
        }
    }

    /**
     * @brief      Sets the ring location.
     *
     * @param[in]  num   The ring num
     * @param[in]  loc   The new value
     */
    virtual void SetRingLoc(int num, std::string loc) {
        if (loc == "host") {
            ring_config[num].ring_loc = MemType::MEM_TYPE_HOST;
        } else {
            ring_config[num].ring_loc = MemType::MEM_TYPE_DMEM;
        }
    }

    /**
     * @brief      { function_description }
     */
    virtual void Snapshot();

    /**
     * @brief      Sets the ring entry number.
     *
     * @param[in]  num   The new value
     */
    virtual void SetRingEntryNum(uint64_t num) {
        ring_config[num].ring_entry_num = num;
    }

    /**
     * @brief      Sets the ring type.
     *
     * @param[in]  type  The type
     */
    virtual void SetRingType(std::string type) {
        ring_type_ = type;
    }

    /**
     * @brief      Sets the ring type.
     *
     * @param[in]  num   The ring id
     * @param[in]  type  The type
     */
    virtual void SetRingType(int num, std::string type) {
        ring_config[num].ring_type = type;
    }

    /**
     * @brief      Sets the mask array.
     *
     * @param[in]  master_id  The master identifier
     */
    virtual void SetMaskArray(uint32_t master_id);

    /**
     * @brief      Sets the timer.
     *
     * @param[in]  timer  The timer
     */
    virtual void SetTimer(uint32_t timer);

    /**
     * @brief      Sets the timer.
     *
     * @param[in]  get trim timer value
     */
    virtual uint32_t GetTimer(void);

    /**
     * @brief      Sets the integer type mask.
     *
     * @param[in]  idx       The new value
     * @param[in]  cause_id  The cause identifier
     */
    virtual void SetIntTypeMask(uint32_t idx, uint32_t cause_id);

    /**
     * @brief      Sets the parity generate.
     *
     * @param[in]  status  The status
     */
    virtual void SetParityGen(uint32_t status);

    /**
     * @brief      Sets the ring pool index.
     *
     * @param[in]  indx  The indx
     */
    virtual void SetPoolLLQNode(uint32_t idx, uint32_t node_num);

    /**
     * @brief      Sets the clock gate.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetClkGate(uint32_t val);

    /**
     * @brief      Sets the fake message data.
     *
     * @param[in]  data0  The data 0
     * @param[in]  data1  The data 1
     */
    virtual void SetFakeMsgData(uint32_t data0, uint32_t data1);

    /**
     * @brief      { function_description }
     *
     * @param[in]  num       The number
     * @param[in]  ctxid     The ctxid
     * @param[in]  masterid  The masterid
     */
    virtual void FakeMsgTrigger(int num, uint32_t ctxid, uint32_t masterid);

    /**
     * @brief      Determines whether the specified number is ring idle.
     *
     * @param[in]  num   The number
     *
     * @return     True if the specified number is ring idle, False otherwise.
     */
    virtual bool IsRingIdle(int num);

    /**
     * @brief      Sets the ring en.
     *
     * @param[in]  num     The new value
     * @param[in]  status  The status
     */
    virtual void SetRingEn(int num, uint32_t status);

    /**
     * @brief      Gets the cause 0 address.
     *
     * @param[in]  num   The number
     *
     * @return     The cause 0 address.
     */
    virtual uint64_t GetCause0Addr(int num);

    /**
     * @brief      Prints an excp status.
     */
    virtual void PrintExcpStatus();

    /**
     * @brief      { function_description }
     */
    virtual void CleanExcp();

    /**
     * @brief      Finds a llq full.
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FindLLQFull();

    /**
     * @brief      Finds a llq full.
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FindSramParity();

    /**
     * @brief      Creates a ring.
     *
     * @param[in]  num   The number
     */
    virtual void CreateRing(int num);

    /**
     * @brief      Creates a ring.
     *
     * @param[in]  ring_id      Ring index
     * @param[in]  entry_num    Total ring entry numbers
     * @param[in]  ring_loc     Ring location
     * @param[in]  ring_type    Ring type
     *
     */
    virtual void CreateRing(int ring_id, uint32_t entry_num, const std::string ring_loc,
        const std::string ring_type);

    /**
     * @brief      Creates a ring.
     *
     * @param[in]  ring_cfg     Const Ring config
     *
     */
    virtual void CreateRing(const RingConfig &ring_cfg);

    /**
     * @brief      Get Drop counter.
     *
     * @param[in]  rind_id     Ring id
     *
     */
    virtual uint32_t GetDropCounter(uint32_t rind_id);

    /**
     * @brief      { function_description }
     *
     * @param[in]  num       The number
     * @param[in]  cause_id  The cause identifier
     * @param[in]  userdata  The userdata
     */
    virtual void TriggerIrq(int num, uint32_t cause_id, uint32_t userdata);

    /**
     * @brief      { function_description }
     *
     * @param[in]  num     The number
     * @param[in]  cause0  The cause 0
     * @param[in]  cause1  The cause 1
     */
    virtual void TriggerRpc(int num, uint32_t cause0, uint32_t cause1);

    /**
     * @brief      { function_description }
     *
     * @param[in]  num   The number
     * @param[in]  data  The data
     */
    virtual void TriggerDbg(int num, uint32_t data);

    /**
     * @brief      { function_description }
     *
     * @param[in]  master_id    The master identifier
     * @param[in]  cause_id     The cause identifier
     * @param      entry        The entry
     * @param[in]  timeout_sec  The timeout security
     * @param[in]  asid         The matched asid
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitForIrq(uint32_t master_id, uint32_t cause_id, IrqEntry *entry,
        int timeout_sec, uint32_t asid = 0);

    /**
     * @brief      { function_description }
     *
     * @param[in]  num          The number
     * @param[in]  die_id       The die identifier
     * @param[in]  master_id    The master identifier
     * @param[in]  cause_id     The cause identifier
     * @param      entry        The entry
     * @param[in]  timeout_sec  The timeout security
     * @param[in]  asid         The matched asid
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitForIrq(int num, uint32_t die_id, uint32_t master_id, uint32_t cause_id,
        IrqEntry *entry, int timeout_sec, uint32_t asid = 0);

    /**
     * @brief      { function_description }
     *
     * @param[in]  num          The number
     * @param[in]  die_id       The die identifier
     * @param[in]  master_id    The master identifier
     * @param      entry        The entry
     * @param[in]  timeout_sec  The timeout security
     * @param[in]  asid         The matched asid
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitForRpc(int num, uint32_t die_id, uint32_t master_id, RpcEntry *entry,
        int timeout_sec, uint32_t asid = 0);

    /**
     * @brief      { function_description }
     *
     * @param[in]  num          The number
     * @param[in]  die_id       The die identifier
     * @param[in]  master_id    The master identifier
     * @param      entry        The entry
     * @param[in]  timeout_sec  The timeout security
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitForDbg(
        int num, uint32_t die_id, uint32_t master_id, DbgEntry *entry, int timeout_sec);

    virtual std::map<uint32_t, std::vector<IrqEntry>> DumpIrqEntry(int num);

    virtual std::map<uint32_t, std::vector<RpcEntry>> DumpRpcEntry(int num);

    virtual std::map<uint32_t, std::vector<DbgEntry>> DumpDbgEntry(int num);

    /**
     * @brief      Gets one interrupt.
     *
     * @param[in]  num    The number
     * @param      entry  The entry
     *
     * @return     One interrupt.
     */
    bool GetOneIrq(int num, IrqEntry *entry) override;

    /**
     * @brief      Gets one rpc.
     *
     * @param[in]  num    The number
     * @param      entry  The entry
     *
     * @return     One rpc.
     */
    bool GetOneRpc(int num, RpcEntry *entry) override;

    /**
     * @brief      Gets one rpc.
     *
     * @param[in]  num    The number
     * @param      entry  The entry
     *
     * @return     One rpc.
     */
    bool GetOneDbg(int num, DbgEntry *entry) override;

 private:
    /**
     * @brief      { function_description }
     *
     */
    virtual void LibInit();
    /**
     * @brief      { function_description }
     *
     */
    virtual void LibDeinit();
    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit();

    template <class Entry>
    std::map<uint32_t, std::vector<Entry>> DumpEntry(int num);

    template <class Entry>
    bool GetOneEntry(int num, Entry *entry) {
        return false;
    }

    virtual int GetTotalRingNum() {
        return TOTAL_RING_NUM;
    }

 protected:
    static const int TOTAL_RING_NUM              = 16;
    uint32_t         ih_blcg_dis_                = 1;  // block level clock gate disable
    MemType          ring_loc_                   = MemType::MEM_TYPE_DMEM;
    std::string      ring_type_                  = "dmem";
    RingConfig       ring_config[TOTAL_RING_NUM] = {};
};

}  // namespace ih
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_IH_IH_LIBRA_H_
