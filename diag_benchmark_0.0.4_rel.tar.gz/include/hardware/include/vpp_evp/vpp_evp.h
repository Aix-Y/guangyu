/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_VPP_EVP_VPP_EVP_H_
#define HARDWARE_INCLUDE_VPP_EVP_VPP_EVP_H_

#include <memory>
#include <string>
#include <vector>

#include "framework/include/mem.h"
#include "hardware/include/hardware.h"
#include "hardware/include/ih.h"
#include "hardware/include/mailbox.h"
#include "hardware/include/mdma/mdma.h"
#include "hardware/include/system_adapter.h"
#include "hardware/include/vpp_codec/vpp_codec.h"

// using efvf::framework::mem::Mem;
using efvf::hardware::codec::Codec;
using efvf::hardware::ih::Ih;
using efvf::hardware::mailbox::Mailbox;
using efvf::hardware::mdma::Mdma;
using efvf::hardware::system_adapter::SystemAdapter;

namespace efvf {
namespace hardware {
namespace vpp {

#define MAX_DIE_NUM (2)
#define MAX_VPP_INST (1)        // FIXME: 2
#define MAX_VPP_EVP_INST (3)    // evp_lite0, evp_lite1, evp_pro
#define MAX_VPP_CODEC_INST (2)  // combo_top and decoder_top

#undef VPP_DBG_SHOW_FUNC
#define VPP_DBG_SHOW_FUNC LOG_DEBUG("{}", __func__)
// #define VPP_DBG_SHOW_FUNC

enum EVP_MODE { EVP_MODE_REG = 0, EVP_MODE_FW, EVP_MODE_TOOL, EVP_MODE_KMD, EVP_MODE_MAX };
enum VPP_CODEC_INSTANCE { VPP_CODEC_COMBO_CORE = 0x0, VPP_CODEC_DECODER_CORE = 0x1 };

enum EVP_PIPELINE_FLAG {
    EVP_PIPELINE_RCROP = 1 << 0,
    EVP_PIPELINE_IFC   = 1 << 1,
    EVP_PIPELINE_BDUC  = 1 << 2,
    EVP_PIPELINE_CUS   = 1 << 3,

    EVP_PIPELINE_DEWARP  = 1 << 4,  // DEWARP 与 IFC 互斥，DEWARP only support EVP_PRO
    EVP_PIPELINE_CROP    = 1 << 5,
    EVP_PIPELINE_RESIZE  = 1 << 6,
    EVP_PIPELINE_PADDING = 1 << 7,
    EVP_PIPELINE_CSC     = 1 << 8,

    EVP_PIPELINE_BDDC  = 1 << 9,
    EVP_PIPELINE_CDS   = 1 << 10,
    EVP_PIPELINE_OFC   = 1 << 11,
    EVP_PIPELINE_WCROP = 1 << 12,
};

enum EVP_FEATURE {
    // register : EVP_FEATURE_REG
    EVP_FEATURE_DEWARP  = 1 << 0,  // only evp_pro
    EVP_FEATURE_CROP    = 1 << 1,
    EVP_FEATURE_RESIZE  = 1 << 2,
    EVP_FEATURE_PADDING = 1 << 3,
    EVP_FEATURE_CSC     = 1 << 4
};

enum INPUT_FORMAT {
    // range:[ 0x0; 0x3ff ]
    // domain: func
    // description: EVP input data format:
    // bitwidth [8+:2]: 2'b00:8bit ; 2'b01:10bit ; 2'b10:12bit ; 2'b11:16bit ;
    // color_space [6+:2]: 2'b00:YUV0 ; 2'b01:YUV1 ; 2'b10:RGB ; 2'b11:GRAY/YUVA ;
    // store_format[4+:2]: 2'b00:Planar; 2'b01:Semi-Plannar; 2'b10:Packet; 2'b11: reserved;
    // color_format[3:0]:
    // [2+:2]:YUV0/1 : 2'b00: yuv420; 2'b01:yuv422; 2'b10:yuv444; 2'b11:reserved;
    // GRAY/YUVA/RGBA: 2'b00: YUVA; 2'b01:RGBA0; 2'b10:RGBA1; 2'b11:GRAY/RGBA16;
    // RGB : randon number;
    // [0+:2]:GRAY/RGBA16 : 2'b00:GRAY; 2'b01: RGB888A16; other: reserved;
    // other : randon number;
    // 4'b1100: GRAY; 4'b1101:RGB888A16
    // YUV Planar
    /* 10'h000 (10'b00_00_00_00_00): */ YUV420_PLANAR_U8_INPUT  = 0x0,
    /* 10'h004 (10'b00_00_00_01_00): */ YUV422_PLANAR_U8_INPUT  = 0x4,
    /* 10'h008 (10'b00_00_00_10_00): */ YUV444_PLANAR_U8_INPUT  = 0x08,
    /* 10'h100 (10'b01_00_00_00_00): */ YUV420_PLANAR_U10_INPUT = 0x100,
    /* 10'h104 (10'b01_00_00_01_00): */ YUV422_PLANAR_U10_INPUT = 0x104,
    /* 10'h108 (10'b01_00_00_10_00): */ YUV444_PLANAR_U10_INPUT = 0x108,
    /* 10'h200 (10'b10_00_00_00_00): */ YUV420_PLANAR_U12_INPUT = 0x200,
    /* 10'h204 (10'b10_00_00_01_00): */ YUV422_PLANAR_U12_INPUT = 0x204,
    /* 10'h208 (10'b10_00_00_10_00): */ YUV444_PLANAR_U12_INPUT = 0x208,
    /* 10'h300 (10'b11_00_00_00_00): */ YUV420_PLANAR_U16_INPUT = 0x300,
    /* 10'h304 (10'b11_00_00_01_00): */ YUV422_PLANAR_U16_INPUT = 0x304,
    /* 10'h308 (10'b11_00_00_10_00): */ YUV444_PLANAR_U16_INPUT = 0x308,
    /* 10'h0C0 (10'b00_11_00_00_00): */ YUVA420_PLANAR_U8_INPUT = 0x0C0,
    // YUV Semi-Planar
    /* 10'h010 (10'b00_00_01_00_00): */ YUV420_SEMI_PLANAR_UV_U8_INPUT  = 0x010,
    /* 10'h110 (10'b01_00_01_00_00): */ YUV420_SEMI_PLANAR_UV_U10_INPUT = 0x110,
    /* 10'h210 (10'b10_00_01_00_00): */ YUV420_SEMI_PLANAR_UV_U12_INPUT = 0x210,
    /* 10'h310 (10'b11_00_01_00_00): */ YUV420_SEMI_PLANAR_UV_U16_INPUT = 0x310,
    /* 10'h011 (10'b00_00_01_00_01): */ YUV420_SEMI_PLANAR_VU_U8_INPUT  = 0x011,
    /* 10'h111 (10'b01_00_01_00_01): */ YUV420_SEMI_PLANAR_VU_U10_INPUT = 0x111,
    /* 10'h211 (10'b10_00_01_00_01): */ YUV420_SEMI_PLANAR_VU_U12_INPUT = 0x211,
    /* 10'h311 (10'b11_00_01_00_01): */ YUV420_SEMI_PLANAR_VU_U16_INPUT = 0x311,
    /* 10'h014 (10'b00_00_01_01_00): */ YUV422_SEMI_PLANAR_UV_U8_INPUT  = 0x014,
    /* 10'h114 (10'b01_00_01_01_00): */ YUV422_SEMI_PLANAR_UV_U10_INPUT = 0x114,
    /* 10'h214 (10'b10_00_01_01_00): */ YUV422_SEMI_PLANAR_UV_U12_INPUT = 0x214,
    /* 10'h015 (10'b00_00_01_01_01): */ YUV422_SEMI_PLANAR_VU_U8_INPUT  = 0x015,
    /* 10'h115 (10'b01_00_01_01_01): */ YUV422_SEMI_PLANAR_VU_U10_INPUT = 0x115,
    /* 10'h215 (10'b10_00_01_01_01): */ YUV422_SEMI_PLANAR_VU_U12_INPUT = 0x215,
    /* 10'h018 (10'b00_00_01_10_00): */ YUV444_SEMI_PLANAR_UV_U8_INPUT  = 0x018,
    /* 10'h118 (10'b01_00_01_10_00): */ YUV444_SEMI_PLANAR_UV_U10_INPUT = 0x118,
    /* 10'h218 (10'b10_00_01_10_00): */ YUV444_SEMI_PLANAR_UV_U12_INPUT = 0x218,
    /* 10'h019 (10'b00_00_01_10_01): */ YUV444_SEMI_PLANAR_VU_U8_INPUT  = 0x019,
    /* 10'h119 (10'b01_00_01_10_01): */ YUV444_SEMI_PLANAR_VU_U10_INPUT = 0x119,
    /* 10'h219 (10'b10_00_01_10_01): */ YUV444_SEMI_PLANAR_VU_U12_INPUT = 0x219,
    // YUV packet
    /* 10'h3E3 (10'b11_11_10_00_11): */ XYUV_PACKET_U16_INPUT       = 0x3E3,
    /* 10'h024 (10'b00_00_10_01_00): */ YUV422_YUYV_PACKET_U8_INPUT = 0x024,
    /* 10'h026 (10'b00_00_10_01_01): */ YUV422_UYVY_PACKET_U8_INPUT = 0x026,
    /* 10'h0A0 (10'b00_10_10_00_00): */ RGB_PACKET_U8_INPUT         = 0x0A0,
    /* 10'h0A1 (10'b00_10_10_00_01): */ BGR_PACKET_U8_INPUT         = 0x0A1,
    /* 10'h3A0 (10'b11_10_10_00_00): */ RGB_PACKET_U16_INPUT        = 0x3A0,
    /* 10'h3A1 (10'b11_10_10_00_01): */ BGR_PACKET_U16_INPUT        = 0x3A1,
    /* 10'h0E4 (10'b00_11_10_01_00): */ RGBA_PACKET_U8_INPUT        = 0x0E4,
    /* 10'h0E5 (10'b00_11_10_01_01): */ ARGB_PACKET_U8_INPUT        = 0x0E5,
    /* 10'h0E6 (10'b00_11_10_01_10): */ BGRA_PACKET_U8_INPUT        = 0x0E6,
    /* 10'h0E7 (10'b00_11_10_01_11): */ ABGR_PACKET_U8_INPUT        = 0x0E7,
    /* 10'h0ED (10'b00_11_10_11_01): */ RGB888A16_PACKET_INPUT      = 0x0ED,
    /* 10'h080 (10'b00_10_00_00_00): */ RGB_PLANAR_U8_INPUT         = 0x080,
    /* 10'h380 (10'b11_10_00_00_00): */ RGB_PLANAR_U16_INPUT        = 0x380,
    /* 10'h0C4 (10'b00_11_00_01_00): */ RGBA_PLANAR_U8_INPUT        = 0x0C4,
    /* 10'h0CD (10'b00_11_00_11_01): */ RGB888A16_PLANAR_INPUT      = 0x0CD,
    /* 10'h0CC (10'b00_11_00_11_00): */ GRAY_PACKET_U8_INPUT        = 0x0CC,
    /* 10'h1CC (10'b01_11_00_11_00): */ GRAY_PACKET_U10_INPUT       = 0x1CC,
    /* 10'h2CC (10'b10_11_00_11_00): */ GRAY_PACKET_U12_INPUT       = 0x2CC,
    /* 10'h3CC (10'b11_11_00_11_00): */ GRAY_PACKET_U16_INPUT       = 0x3CC
};

enum OUTPUT_FORMAT {
    // YUV Plannar:
    /* 10'h000 (10'b00_00_00_00_00): */ YUV420_PLANAR_U8_OUTPUT  = 0x000,
    /* 10'h008 (10'b00_00_00_10_00): */ YUV444_PLANAR_U8_OUTPUT  = 0x008,
    /* 10'h100 (10'b01_00_00_00_00): */ YUV420_PLANAR_U10_OUTPUT = 0x100,
    /* 10'h108 (10'b01_00_00_10_00): */ YUV444_PLANAR_U10_OUTPUT = 0x108,
    /* 10'h200 (10'b10_00_00_00_00): */ YUV420_PLANAR_U12_OUTPUT = 0x200,
    /* 10'h208 (10'b10_00_00_10_00): */ YUV444_PLANAR_U12_OUTPUT = 0x208,
    /* 10'h300 (10'b11_00_00_00_00): */ YUV420_PLANAR_U16_OUTPUT = 0x300,
    /* 10'h308 (10'b11_00_00_10_00): */ YUV444_PLANAR_U16_OUTPUT = 0x308,
    /* 10'h0C2 (10'b00_11_00_00_10): */ YUVA444_PLANAR_U8_OUTPUT = 0x0C2,
    /* YUV444A:2'b10; XYU444V: 2'b11 */
    // YUV Packet:
    /* 10'h3E3 (10'b11_11_10_00_11): */ XYUV_PACKET_U16_OUTPUT = 0x3E3,
    /* YUV444A:2'b10; XYU444V:2'b11  */
    /* 10'h028 (10'b00_00_10_10_00): */ YUV444_PACKET_U8_OUTPUT  = 0x028,
    /* 10'h128 (10'b01_00_10_10_00): */ YUV444_PACKET_U10_OUTPUT = 0x128,
    /* 10'h228 (10'b10_00_10_10_00): */ YUV444_PACKET_U12_OUTPUT = 0x228,
    /* 10'h328 (10'b11_00_10_10_00): */ YUV444_PACKET_U16_OUTPUT = 0x328,
    // RGB Packet:
    /* 10'h0A0 (10'b00_10_10_00_00): */ RGB_PACKET_U8_OUTPUT    = 0x0A0,
    /* 10'h0A1 (10'b00_10_10_00_01): */ BGR_PACKET_U8_OUTPUT    = 0x0A1,
    /* 10'h3A0 (10'b11_10_10_00_00): */ RGB_PACKET_U16_OUTPUT   = 0x3A0,
    /* 10'h3A1 (10'b11_10_10_00_01): */ BGR_PACKET_U16_OUTPUT   = 0x3A1,
    /* 10'h0E4 (10'b00_11_10_01_00): */ RGBA_PACKET_U8_OUTPUT   = 0x0E4,
    /* 10'h0E5 (10'b00_11_10_01_01): */ ARGB_PACKET_U8_OUTPUT   = 0x0E5,
    /* 10'h0E6 (10'b00_11_10_01_11): */ BGRA_PACKET_U8_OUTPUT   = 0x0E6,
    /* 10'h0E7 (10'b00_11_10_01_10): */ ABGR_PACKET_U8_OUTPUT   = 0x0E7,
    /* 10'h0ED (10'b00_11_10_11_01): */ RGB888A16_PACKET_OUTPUT = 0x0ED,
    // RGB Plannar:
    /* 10'h080 (10'b00_10_00_00_00): */ RGB_PLANAR_U8_OUTPUT       = 0x080,
    /* 10'h0C4 (10'b00_11_00_01_00): */ RGBA_PLANAR_U8_OUTPUT      = 0x0C4,
    /* 10'h0CD (10'b00_11_00_11_01): */ RGB888A16_PLANAR_OUTPUT    = 0x0CD,
    /* 10'h380 (10'b11_10_00_00_00): */ RGB_PLANAR_U16_OUTPUT      = 0x380,
    /* 10'h0CC (10'b00_11_00_11_00): */ GRAY_PACKET_U8_OUTPUT      = 0x0CC,
    /* 10'h1CC (10'b01_11_00_11_00): */ GRAY_PACKET_U10_OUTPUT     = 0x1CC,
    /* 10'h2CC (10'b10_11_00_11_00): */ GRAY_PACKET_U12_OUTPUT     = 0x2CC,
    /* 10'h3CC (10'b11_11_00_11_00): */ GRAY_PACKET_U16_OUTPUT     = 0x3CC,
    /* 10'h010 (10'b00_00_01_00_00): */ reserved0_semi_plannar_U8  = 0x010,
    /* 10'h310 (10'b11_00_01_00_00): */ reserved1_semi_plannar_U16 = 0x310,
};

typedef struct VDmaParam {
    uint64_t start_addr;  // 128 bytes align
    uint32_t stride;      // 128 bytes align
    uint32_t offset_x;    // 2 bytes align
    uint32_t offset_y;
    uint32_t width;
    uint32_t height;
    VDmaParam() : start_addr(0), stride(0), offset_x(0), offset_y(0), width(0), height(0) {}
} VDmaParam;

// IFC
#define IFC_PARSE_PAR_CNT (4)
typedef struct IfcCfg {
    uint32_t auto_gen;  // auto
    uint32_t parse_par[IFC_PARSE_PAR_CNT][2];
    uint32_t output_src_par;
    IfcCfg() : auto_gen(0), output_src_par(0) {
        for (uint32_t i = 0; i < IFC_PARSE_PAR_CNT; i++) {
            parse_par[i][0] = 0;
            parse_par[i][1] = 0;
        }
    }
} IfcCfg;

// OFC
typedef struct OfcCfg {
    uint32_t auto_gen;  // auto
    uint32_t remap_src;
    uint32_t pixel_width;  // INT8 or INT16
    uint32_t packet_mode;
    uint32_t data_num;
    OfcCfg() : auto_gen(0), remap_src(0), pixel_width(0), packet_mode(0), data_num(0) {}
} OfcCfg;

// CUS or CDS
typedef struct ChromaSamplingCfg {
    bool     is_cds;
    uint32_t cfg_reg;
    uint16_t pic_width;  // m
    uint16_t pic_height;
    ChromaSamplingCfg() : is_cds(true), cfg_reg(0), pic_width(0), pic_height(0) {}
} ChromaSamplingCfg;

// BDC: Bit-Depth Convertion
typedef struct BitdepthCfg {
    // bit[1:0] : RGB/YUV channel bitdepth;
    // 2'h0:8bit
    // 2'h1:10bit
    // 2'h2:12bit
    // 2'h3:16bit
    // bit[3:2] : A/X channel bitdepth;
    // 2'h0:8bit
    // 2'h1:10bit
    // 2'h2:12bit
    // 2'h3:16bit
    uint8_t origin_width_yuv;  // origin RGB/YUV channel
    uint8_t origin_width_x;    // origin A/X channel
    uint8_t target_width_yuv;  // target RGB/YUV channel
    uint8_t target_width_x;    // target A/X channel
    BitdepthCfg()
        : origin_width_yuv(0), origin_width_x(0), target_width_yuv(0), target_width_x(0) {}
} BitdepthCfg;

typedef struct CropCfg {
    uint16_t offset_x;
    uint16_t offset_y;
    uint16_t output_width;
    uint16_t output_height;
    CropCfg() : offset_x(0), offset_y(0), output_width(0), output_height(0) {}
} CropCfg;

typedef struct ResizeCfg {
    uint32_t mode;
    uint16_t input_width;
    uint16_t input_height;
    uint16_t output_width;
    uint16_t output_height;
    uint32_t hor_ratio;
    uint32_t ver_ratio;
    uint32_t phase_x;
    uint32_t phase_y;
    ResizeCfg()
        : mode(0),
          input_width(0),
          input_height(0),
          output_width(0),
          output_height(0),
          hor_ratio(0),
          ver_ratio(0),
          phase_x(0),
          phase_y(0) {}
} ResizeCfg;

typedef struct PaddingCfg {
    uint32_t mode;
    uint16_t chx_padding_val[4];
    uint16_t input_width;
    uint16_t input_height;
    uint16_t size_v_up;
    uint16_t size_v_down;
    uint16_t size_h_left;
    uint16_t size_h_right;
    PaddingCfg()
        : mode(0),
          input_width(0),
          input_height(0),
          size_v_up(0),
          size_v_down(0),
          size_h_left(0),
          size_h_right(0) {
        for (uint32_t i = 0; i < 4; i++) {
            chx_padding_val[i] = 0;
        }
    }
} PaddingCfg;

typedef struct CscCfg {
    uint32_t cfg_reg;
    uint16_t width;
    uint16_t height;
    uint16_t y_min_th;
    uint16_t y_max_th;
    uint16_t uv_min_th;
    uint16_t uv_max_th;
#define CSC_MATRIX_COEFF_CNT (9)
    uint32_t matrix_coeff[CSC_MATRIX_COEFF_CNT];  // 0 - 8
#define CSC_OFFSET_CNT (3)
    uint32_t offset[CSC_OFFSET_CNT];  // 0 - 2
    CscCfg()
        : cfg_reg(0),
          width(0),
          height(0),
          y_min_th(0),
          y_max_th(0),
          uv_min_th(0),
          uv_max_th(0) {
        for (uint32_t i = 0; i < CSC_MATRIX_COEFF_CNT; i++) {
            matrix_coeff[i] = 0;
        }

        for (uint32_t i = 0; i < CSC_OFFSET_CNT; i++) {
            offset[i] = 0;
        }
    }
} CscCfg;

typedef struct DewarpCfg {
    uint32_t mode;
    uint32_t chx_border[4];  // ch0, ch1, ch2,ch3
    uint16_t input_width;
    uint16_t input_height;
    uint16_t output_width;
    uint16_t output_height;
    uint16_t output_offset_x;
    uint16_t output_offset_y;
    uint32_t matrix_coeff[9];  // 0 - 8
    uint32_t hash_coeff[4];
    uint32_t idx_ds_x;
    uint32_t idx_ds_y;
    DewarpCfg()
        : mode(0),
          input_width(0),
          input_height(0),
          output_width(0),
          output_height(0),
          output_offset_x(0),
          output_offset_y(0),
          idx_ds_x(0),
          idx_ds_y(0) {
        for (uint32_t i = 0; i < 9; i++) {
            matrix_coeff[i] = 0;
        }

        for (uint32_t i = 0; i < 4; i++) {
            hash_coeff[i] = 0;
            chx_border[i] = 0;
        }
    }
} DewarpCfg;

typedef struct SliceCfg {
    uint32_t slice_in_width;
    uint32_t slice_in_height;
    uint32_t slice_out_width;
    uint32_t slice_out_height;
    SliceCfg()
        : slice_in_width(0), slice_in_height(0), slice_out_width(0), slice_out_height(0) {}
} SliceCfg;
typedef struct EvpConfig {
    //
    uint32_t context_id;  // [1, 4], map to int0 ~ int3
    uint32_t vmh_interrupt_flag;
    uint32_t evp_inst;
    uint32_t golden_crc;
    uint64_t crc_buffer_addr;
    bool     check_output;
    bool     cbf_cache_en;
    bool     event_trace_en;
    bool     mb_mask_en;
    bool     is_shadow;
    // EVP_FUNCTION
    bool ifc_en;
    bool ofc_en;
    bool cus_en;
    bool cds_en;
    bool bduc_en;
    bool bddc_en;
    // EVP_FEATURE
    bool dewarp_en;
    bool crop_en;
    bool resize_en;
    bool padding_en;
    bool csc_en;
    bool slice_en;
    //
    uint32_t input_fmt;
    uint32_t input_offset_x;
    uint32_t input_offset_y;
    uint32_t input_img_width;
    uint32_t input_img_height;
    uint32_t output_fmt;
    uint32_t output_offset_x;
    uint32_t output_offset_y;
    uint32_t output_img_width;
    uint32_t output_img_height;
    uint64_t input_buffer_addr;
    uint64_t output_buffer_addr;

    // rdma / wdma
    uint32_t input_planar_num;
    uint32_t output_planar_num;
    //
    uint32_t input_planar_size[4];
    uint32_t input_planar_offset[4];
    uint32_t input_stride_width[4];
    uint32_t input_pixel_width[4];
    uint32_t input_pixel_height[4];
    uint32_t input_bytes_pre_pixel[4];
    //
    uint32_t output_planar_size[4];
    uint32_t output_planar_offset[4];
    uint32_t output_stride_width[4];
    uint32_t output_pixel_width[4];
    uint32_t output_pixel_height[4];
    uint32_t output_bytes_pre_pixel[4];

    // get support output format by input format
    std::vector<uint32_t> support_ofmt_vec;

    // pipeline param
    IfcCfg            ifc;
    OfcCfg            ofc;
    ChromaSamplingCfg cus;
    ChromaSamplingCfg cds;
    BitdepthCfg       bduc;
    BitdepthCfg       bddc;

    CropCfg    crop;
    ResizeCfg  resize;
    PaddingCfg padding;
    CscCfg     csc;
    DewarpCfg  dewarp;
    SliceCfg   slice;

    EvpConfig()
        : context_id(0),
          vmh_interrupt_flag(0),
          evp_inst(0),
          golden_crc(0),
          crc_buffer_addr(0),
          check_output(true),
          cbf_cache_en(false),
          event_trace_en(false),
          mb_mask_en(false),
          is_shadow(false),
          ifc_en(false),
          ofc_en(false),
          cus_en(false),
          cds_en(false),
          bduc_en(false),
          bddc_en(false),
          dewarp_en(false),
          crop_en(false),
          resize_en(false),
          padding_en(false),
          csc_en(false),
          slice_en(false),
          input_fmt(0),
          input_offset_x(0),
          input_offset_y(0),
          input_img_width(0),
          input_img_height(0),
          output_fmt(0),
          output_offset_x(0),
          output_offset_y(0),
          output_img_width(0),
          output_img_height(0),
          input_buffer_addr(0),
          output_buffer_addr(0),
          input_planar_num(0),
          output_planar_num(0) {
        for (uint32_t i = 0; i < 4; ++i) {
            input_planar_size[i]     = 0;
            input_planar_offset[i]   = 0;
            input_stride_width[i]    = 0;
            input_pixel_width[i]     = 0;
            input_pixel_height[i]    = 0;
            input_bytes_pre_pixel[i] = 0;
            //
            output_planar_size[i]     = 0;
            output_planar_offset[i]   = 0;
            output_stride_width[i]    = 0;
            output_pixel_width[i]     = 0;
            output_pixel_height[i]    = 0;
            output_bytes_pre_pixel[i] = 0;
        }
    }
} EvpConfig;

typedef struct EvpStatus {
    uint32_t evp_inst_num;
    uint32_t evp_is_busy[3];
    EvpStatus() : evp_inst_num(3) {
        for (uint32_t i = 0; i < 3; i++) {
            evp_is_busy[i] = 0x0;
        }
    }
} EvpStatus;

class Vpp : public Hardware {
 public:
    Vpp();
    explicit Vpp(std::shared_ptr<spdlog::logger> logger);
    virtual ~Vpp();

 public:
    virtual uint32_t GetRunMode() const = 0;
    virtual void SetRunMode(uint32_t mode = 0) = 0;

    virtual void SetL2CacheForCodec(bool en) = 0;

    virtual bool FillConfigByInputParam(EvpConfig &cfg) = 0;

    virtual bool RunEvpPipeline(uint32_t inst, EvpConfig &cfg) = 0;
    virtual void CleanEvpSetting(uint32_t inst) = 0;
    virtual bool CheckIdle(uint32_t inst, bool is_shadow = false) = 0;

    virtual uint32_t CheckSidebandInterrupt(uint32_t inst) = 0;
    virtual bool CleanSidebandInterrupt(uint32_t inst)     = 0;
    virtual bool GetEvpStatus(EvpStatus &st)               = 0;

    virtual Mailbox *      GetVpmMailBox() = 0;
    virtual Mailbox *      GetEvpMailBox() = 0;
    virtual Ih *           GetMih()        = 0;
    virtual Mdma *         GetMdma()       = 0;
    virtual SystemAdapter *GetSa()         = 0;

    virtual bool SetVppBlr() = 0;
    virtual bool SetProfiler(bool trace_en = false, bool profiling_en = false) = 0;

    // test case in library
    virtual bool RegAccessTest()  = 0;
    virtual bool SramAccessTest() = 0;

    virtual bool FwSubmitData(uint32_t cmd_type, EvpConfig &cfg) = 0;
    virtual bool FwGetResp(uint32_t cmd_type, uint64_t &out_addr, uint64_t &out_param) = 0;
    virtual uint32_t GetFwVersion(uint32_t &major, uint32_t &minor) = 0;
    virtual uint32_t GetFwHeartbeat() = 0;
    virtual uint32_t GetFwStatus()    = 0;

    virtual void SetSmemParityInject(uint32_t status) = 0;
    virtual bool FindSmemParity(uint32_t intfx)       = 0;
    virtual void CleanSmemParity()                    = 0;

    virtual void SetCodecParityInject(uint32_t codec_inst, uint32_t status) = 0;
    virtual bool FindCodecParity(uint32_t codec_inst)  = 0;
    virtual void CleanCodecParity(uint32_t codec_inst) = 0;

    virtual void SetEvpSramParityInject(
        uint32_t evp_inst, uint32_t func_type, bool inject) = 0;
    virtual uint32_t GetEvpSramParity(uint32_t evp_inst, uint32_t func_type) = 0;
    virtual void CleanEvpSramParity(uint32_t evp_inst, uint32_t func_type)   = 0;

    virtual bool HandleToolReq(const std::string &req) = 0;
    virtual bool HandleToolReq(const std::string &req, uint64_t &in_out) = 0;

    virtual bool MemConstFill(uint64_t buf_addr, uint64_t buf_size, uint32_t pattern,
        uint64_t off = 0, uint64_t size = 0, int timeout = 1000)                     = 0;
    virtual bool DataCopy(uint64_t src_addr, uint64_t dst_addr, uint64_t size)       = 0;
    virtual uint32_t GetDataCrc(uint64_t src_addr, uint64_t dst_addr, uint64_t size) = 0;

    /**
     * @brief      Gets the eng name.
     *
     * @return     The eng name.
     */
    virtual std::string GetEngName() {
        return "vpp";
    }

    // ************************************************
    //              VPU codec
    // ************************************************
    virtual Codec *GetCodec(uint32_t inst) = 0;
};

}  // namespace vpp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_VPP_EVP_VPP_EVP_H_
