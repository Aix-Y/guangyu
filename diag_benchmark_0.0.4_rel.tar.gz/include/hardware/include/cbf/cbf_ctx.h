/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CBF_CBF_CTX_H_
#define HARDWARE_INCLUDE_CBF_CBF_CTX_H_

#include <stdint.h>
#include <memory>
#include <string>
#include <vector>
#include "framework/include/mem.h"

using efvf::framework::mem::Mem;
using efvf::framework::mem::MemType;

namespace efvf {
namespace hardware {
namespace cbf {

/**
 * @brief CBF block type
 */
typedef enum _CbfType {
    Cbf_BB,
    Cbf_SB,
    Cbf_BC,
} CbfType;

/**
 * @brief CBF block DP R/W type
 */
typedef enum _CbfRwType {
    Cbf_W,
    Cbf_R,
} CbfRwType;

/**
 * @brief CBF VF GROUP
 */
typedef enum _CbfVfType {
    Cbf_VF_4  = 0,
    Cbf_VF_8  = 1,
    Cbf_VF_16 = 2,
    Cbf_VF_32 = 3,
} CbfVfType;

/**
 * @brief CBF bpm type
 */
typedef enum _CbfBpmType { Cbf_SLV_BPM, Cbf_MST_BPM } CbfBpmType;

/**
 * @brief CBF cache rw mem type
 */
typedef enum _CbfCacheMemType {
    Write_Thr_No_Alloc = 0,
    Write_Thr_Read_Alloc,
    Write_Thr_Write_Alloc,
    Write_Thr_RW_Alloc,
    Write_Back_No_Alloc,
    Write_Back_Read_Alloc,
    Write_Back_Write_Alloc,
    Write_Back_RW_Alloc,
} CbfCacheMemType;

/**
 * @brief CBF cache mem config
 */
typedef struct _CbfCacheMemCfg {
    uint32_t arcache;
    uint32_t awcache;
} CbfCacheMemCfg;

/**
 * @brief CBF hash cfg
 */
typedef struct _CbfHashCfg {
    CbfType cbf_type = Cbf_BB;
    union _cbf_hash_addr_config {
        struct _cbf_bb_hash {
            uint32_t bb_hash_config0 = 0x7591;  // 15 bits
            uint32_t bb_hash_config1 = 0x1eb2;
            uint32_t bb_hash_config2 = 0x3d64;
            uint32_t bb_hash_config3 = 0x7ac8;
        } cbf_bb_hash;

        struct _cbf_sb_hash {
            uint32_t sb_hash_config0 = 0x1591;  // 13 bits
            uint32_t sb_hash_config1 = 0x1eb2;
        } cbf_sb_hash;

        struct _cbf_bc_hash {
            uint32_t bc_hash_config0 = 0x228c01;  // 25 bits
            uint32_t bc_hash_config1 = 0x2de082;
            uint32_t bc_hash_config2 = 0x65c704;
            uint32_t bc_hash_config3 = 0x1f58408;
            uint32_t bc_hash_config4 = 0x76ad10;
            uint32_t bc_hash_config5 = 0xcf3320;
            uint32_t bc_hash_config6 = 0x3b7840;
        } cbf_bc_hash;
    } cbf_hash_addr_config;
} CbfHashCfg;

/**
 * @brief CBF dehash cfg
 */
typedef struct _CbfDeHashCfg {
    uint32_t de_hash_addr_offset  = 0;  // 29 bits
    uint32_t de_hash_mask_config0 = 0;
    uint32_t de_hash_mask_config1 = 0;
    uint32_t de_hash_mask_config2 = 0;
    uint32_t de_hash_mask_config3 = 0;
    uint32_t de_hash_mask_config4 = 0;
} CbfDeHashCfg;

/**
 * @brief CBF priority type
    0: stream
    1: normal
    2: residency
 */
typedef enum _CbfCachePriorType {
    Cache_Prior_Stream = 0,
    Cache_Prior_Normal,
    Cache_Prior_Residency,
} CbfCachePriorType;

/**
 * @brief CBF cache maintenance type
 */
typedef enum _CbfCacheMtnType {
    MTN_Clean_Line_by_VA = 0,
    MTN_Clean_All,
    MTN_Invalidate_Line_by_VA,
    MTN_Invalidate_All,
    MTN_Flush_Line_by_VA,
    MTN_Flush_All,
    MTN_Lock_Line_by_VA,
    MTN_Lock_Line_All,
    MTN_Unlock_Line_by_VA,
    MTN_Unlock_Line_All,
    MTN_Degrate_prority_by_VA,
    MTN_Degrate_prority_All,
} CbfCacheMtnType;

/**
 * @brief CBF cache maintenance config struct
 */
typedef struct _CbfCacheMtnCfg {
    CbfCacheMtnType   mtn_type;
    bool              mtn_notify_en   = false;
    uint32_t          mtn_notify_addr = 0;
    uint32_t          mtn_notify_data = 0;
    uint32_t          mtn_start_addr  = 0;
    uint32_t          mtn_size        = 0;
    uint32_t          mtn_time_out    = 0x1fa0000;
    CbfCachePriorType mtn_degr_rsdt_prior;
} CbfCacheMtnCfg;

/**
 * @brief CBF cache prefetch type
 */
typedef enum _CbfCachePrefType {
    CBF_SW_PREF,
    CBF_HW_RD_MISS_PREF,
    CBF_HW_FAKE_WR_PREF,
} CbfCachePrefType;

/**
 * @brief CBF cache prefetch Qos type
 */
typedef enum _CbfCachePrefQosType {
    CBF_PREF_ARB_QOS_0 = 0,
    CBF_PREF_ARB_QOS_1 = 1,
    CBF_PREF_ARB_QOS_2 = 2,
    CBF_PREF_ARB_QOS_3 = 3,
} CbfCachePrefQosType;

/**
 * @brief CBF cache hw prefetch size
 */
typedef enum _CbfCachePrefSize {
    HW_PREF_SIZE_1_CACHELINE,
    HW_PREF_SIZE_2_CACHELINE,
    HW_PREF_SIZE_4_CACHELINE,
    HW_PREF_SIZE_8_CACHELINE,
} CbfCachePrefSize;

/**
 * @brief CBF profiler indicator info
 */
typedef struct _CbfProfilerInfo {
    uint32_t cbf_id                                      = 0;
    uint32_t profile_cache_rd_hit_cnt                    = 0;
    uint32_t profile_cache_wr_hit_cnt                    = 0;
    uint32_t profile_cache_rd_miss_cnt                   = 0;
    uint32_t profile_cache_wr_miss_cnt                   = 0;
    uint32_t profile_cache_rd_cnt                        = 0;
    uint32_t profile_cache_wr_cnt                        = 0;
    uint32_t profile_cache_rd_hit_but_no_data_cnt        = 0;
    uint32_t profile_cache_wr_hit_but_no_data_cnt        = 0;
    uint32_t profile_cache_rd_prefetch_cmd_cnt           = 0;
    uint32_t profile_cache_wr_prefetch_cmd_cnt           = 0;
    uint32_t profile_cache_rd_miss_prefetch_cmd_drop_cnt = 0;
    uint32_t profile_cache_wr_miss_prefetch_cmd_drop_cnt = 0;
    uint32_t profile_cache_sw_prefetch_cmd_drop_cnt      = 0;
} CbfProfilerInfo;

/**
 * @brief CBF BC cache MSHR queue status
 */
typedef struct _CbfBcCacheMshrStatus {
    uint32_t mshr_que_conflict_id;
    uint32_t mshr_que_node_num_underflow;
    uint32_t mshr_que_node_num_overflow;
    uint32_t mshr_que_node_conflict;
    uint32_t mshr_que_deque_id_err;
    uint32_t mshr_que_deque_err;
    uint32_t mshr_que_enque_err;
    uint32_t mshr_que_all_empty;
} CbfBcCacheMshrStatus;

/**
 * @brief CBF BC channel R/W log
 */
typedef struct _CbfBcChannelRwLog {
    uint32_t rw_master_id;
    uint32_t err_type;
    uint32_t rw_cmd_addr;
} CbfBcChannelRwLog;

/**
 * @brief CBF cache flush control struct
 */
typedef struct _CbfCacheFlushCtrl {
    uint32_t mshr_strobe_flush_enable   = 0;
    uint32_t sector_flush_enable        = 0;
    uint32_t tag_flush_enable           = 0;
    uint32_t internal_FIFO_flush_enable = 0;
} CbfCacheFlushCtrl;

/**
 * @brief CBF internal status type
 */
typedef enum _CbfInnType {
    Cbf_Inn0,
    Cbf_Inn1,
    Cbf_Inn2,
    Cbf_Inn3,
} CbfInnType;

/**
 * @brief CBF internal status struct (will update, TBD)
 */
typedef struct _CbfInnStatus {
    CbfInnType inn_type = Cbf_Inn0;
    union _cbf_inn_status_config {
        struct _cbf_inn_status0 {
            uint32_t BC0_CORE0_LLQ0;
            uint32_t BC0_CORE0_LLQ1;
            uint32_t BC0_CORE0_LLQ2;
            uint32_t BC0_CORE0_LLQ3;
            uint32_t BC0_CORE1_LLQ0;
            uint32_t BC0_CORE1_LLQ1;
            uint32_t BC0_CORE1_LLQ2;
            uint32_t BC0_CORE1_LLQ3;
            uint32_t BC1_CORE0_LLQ0;
            uint32_t BC1_CORE0_LLQ1;
            uint32_t BC1_CORE0_LLQ2;
            uint32_t BC1_CORE0_LLQ3;
            uint32_t BC1_CORE1_LLQ0;
            uint32_t BC1_CORE1_LLQ1;
            uint32_t BC1_CORE1_LLQ2;
            uint32_t BC1_CORE1_LLQ3;
            uint32_t BC0_BANK0_EHIB;
            uint32_t BC0_BANK1_EHIB;
            uint32_t BC1_BANK0_EHIB;
            uint32_t BC1_BANK1_EHIB;
            uint32_t OPU_WR_LLQ;
            uint32_t OPU_RD_LLQ;
        } cbf_inn_status0;

        struct _cbf_inn_status1 {
            uint32_t BB0_BANK0_LLQ;
            uint32_t BB0_BANK1_LLQ;
            uint32_t BB0_BANK2_LLQ;
            uint32_t BB0_BANK3_LLQ;
            uint32_t BB0_BANK4_LLQ;
            uint32_t BB0_BANK5_LLQ;
            uint32_t BB0_BANK6_LLQ;
            uint32_t BB0_BANK7_LLQ;
            uint32_t BB1_BANK0_LLQ;
            uint32_t BB1_BANK1_LLQ;
            uint32_t BB1_BANK2_LLQ;
            uint32_t BB1_BANK3_LLQ;
            uint32_t BB1_BANK4_LLQ;
            uint32_t BB1_BANK5_LLQ;
            uint32_t BB1_BANK6_LLQ;
            uint32_t BB1_BANK7_LLQ;
            uint32_t DPR0_RREORDER_LLEQ;
            uint32_t DPR0_RD_MC_LLQ;
            uint32_t DPW0_BREORDER_LLEQ;
            uint32_t DPW0_WR_MC_LLQ;
            uint32_t DPR1_RREORDER_LLEQ;
            uint32_t DPR1_RD_MC_LLQ;
            uint32_t DPW1_BREORDER_LLEQ;
            uint32_t DPW1_WR_MC_LLQ;
        } cbf_inn_status1;

        struct _cbf_inn_status2 {
            uint32_t BB0_DP0_WR_ECC_ERR;
            uint32_t BB0_DP0_RD_ECC_ERR;
            uint32_t BB0_DP1_WR_ECC_ERR;
            uint32_t BB0_DP1_RD_ECC_ERR;
            uint32_t BB1_DP0_WR_ECC_ERR;
            uint32_t BB1_DP0_RD_ECC_ERR;
            uint32_t BB1_DP1_WR_ECC_ERR;
            uint32_t BB1_DP1_RD_ECC_ERR;
            uint32_t BC0_CORE0_BANK0_RAS_ERR;
            uint32_t BC0_CORE0_BANK1_RAS_ERR;
            uint32_t BC0_CORE1_BANK0_RAS_ERR;
            uint32_t BC0_CORE1_BANK1_RAS_ERR;
            uint32_t BC1_CORE0_BANK0_RAS_ERR;
            uint32_t BC1_CORE0_BANK1_RAS_ERR;
            uint32_t BC1_CORE1_BANK0_RAS_ERR;
            uint32_t BC1_CORE1_BANK1_RAS_ERR;
            uint32_t DPR0_RREORDER_RAM_RAS_ERR;
            uint32_t DPW0_QCW_RAM_RAS_ERR;
            uint32_t DPR1_RREORDER_RAM_RAS_ERR;
            uint32_t DPW1_QCW_RAM_RAS_ERR;
            uint32_t DPW0_WDATA_PTY_ERR;
            uint32_t DPW1_WDATA_PTY_ERR;
        } cbf_inn_status2;

        struct _cbf_inn_status3 {
            uint32_t RC0_TOUCH_RESERVED_ADDR;
            uint32_t WC0_TOUCH_RESERVED_ADDR;
            uint32_t RC1_TOUCH_RESERVED_ADDR;
            uint32_t WC1_TOUCH_RESERVED_ADDR;
            uint32_t SWPF_CMDCFG_ERR;
            uint32_t MTN_CMDCFG_ERR;
            uint32_t MTN_CMD_OVERFLOW;
            uint32_t MTN_TIMEOUT;
        } cbf_inn_status3;
    } cbf_inn_status_config;
} CbfInnStatus;

/**
 * @brief CBF IRQ status struct (will update, TBD)
 */
typedef struct _CbfIrqStatus {
    CbfInnType inn_type = Cbf_Inn0;
    union _cbf_irq_status_mask_config {
        struct _cbf_irq_status0 {
            uint32_t BC0_CORE0_LLQ0_IRQ_MASK;
            uint32_t BC0_CORE0_LLQ1_IRQ_MASK;
            uint32_t BC0_CORE0_LLQ2_IRQ_MASK;
            uint32_t BC0_CORE0_LLQ3_IRQ_MASK;
            uint32_t BC0_CORE1_LLQ0_IRQ_MASK;
            uint32_t BC0_CORE1_LLQ1_IRQ_MASK;
            uint32_t BC0_CORE1_LLQ2_IRQ_MASK;
            uint32_t BC0_CORE1_LLQ3_IRQ_MASK;
            uint32_t BC1_CORE0_LLQ0_IRQ_MASK;
            uint32_t BC1_CORE0_LLQ1_IRQ_MASK;
            uint32_t BC1_CORE0_LLQ2_IRQ_MASK;
            uint32_t BC1_CORE0_LLQ3_IRQ_MASK;
            uint32_t BC1_CORE1_LLQ0_IRQ_MASK;
            uint32_t BC1_CORE1_LLQ1_IRQ_MASK;
            uint32_t BC1_CORE1_LLQ2_IRQ_MASK;
            uint32_t BC1_CORE1_LLQ3_IRQ_MASK;
            uint32_t BC0_BANK0_EHIB_IRQ_MASK;
            uint32_t BC0_BANK1_EHIB_IRQ_MASK;
            uint32_t BC1_BANK0_EHIB_IRQ_MASK;
            uint32_t BC1_BANK1_EHIB_IRQ_MASK;
            uint32_t OPU_WR_LLQ_IRQ_MASK;
            uint32_t OPU_RD_LLQ_IRQ_MASK;
        } cbf_irq_status0;

        struct _cbf_irq_status1 {
            uint32_t BB0_BANK0_LLQ_IRQ_MASK;
            uint32_t BB0_BANK1_LLQ_IRQ_MASK;
            uint32_t BB0_BANK2_LLQ_IRQ_MASK;
            uint32_t BB0_BANK3_LLQ_IRQ_MASK;
            uint32_t BB0_BANK4_LLQ_IRQ_MASK;
            uint32_t BB0_BANK5_LLQ_IRQ_MASK;
            uint32_t BB0_BANK6_LLQ_IRQ_MASK;
            uint32_t BB0_BANK7_LLQ_IRQ_MASK;
            uint32_t BB1_BANK0_LLQ_IRQ_MASK;
            uint32_t BB1_BANK1_LLQ_IRQ_MASK;
            uint32_t BB1_BANK2_LLQ_IRQ_MASK;
            uint32_t BB1_BANK3_LLQ_IRQ_MASK;
            uint32_t BB1_BANK4_LLQ_IRQ_MASK;
            uint32_t BB1_BANK5_LLQ_IRQ_MASK;
            uint32_t BB1_BANK6_LLQ_IRQ_MASK;
            uint32_t BB1_BANK7_LLQ_IRQ_MASK;
            uint32_t DPR0_RREORDER_LLEQ_IRQ_MASK;
            uint32_t DPR0_RD_MC_LLQ_IRQ_MASK;
            uint32_t DPW0_BREORDER_LLEQ_IRQ_MASK;
            uint32_t DPW0_WR_MC_LLQ_IRQ_MASK;
            uint32_t DPR1_RREORDER_LLEQ_IRQ_MASK;
            uint32_t DPR1_RD_MC_LLQ_IRQ_MASK;
            uint32_t DPW1_BREORDER_LLEQ_IRQ_MASK;
            uint32_t DPW1_WR_MC_LLQ_IRQ_MASK;
        } cbf_irq_status1;

        struct _cbf_irq_status2 {
            uint32_t BB0_DP0_WR_ECC_ERR_IRQ_MASK;
            uint32_t BB0_DP0_RD_ECC_ERR_IRQ_MASK;
            uint32_t BB0_DP1_WR_ECC_ERR_IRQ_MASK;
            uint32_t BB0_DP1_RD_ECC_ERR_IRQ_MASK;
            uint32_t BB1_DP0_WR_ECC_ERR_IRQ_MASK;
            uint32_t BB1_DP0_RD_ECC_ERR_IRQ_MASK;
            uint32_t BB1_DP1_WR_ECC_ERR_IRQ_MASK;
            uint32_t BB1_DP1_RD_ECC_ERR_IRQ_MASK;
            uint32_t BC0_CORE0_BANK0_RAS_ERR_IRQ_MASK;
            uint32_t BC0_CORE0_BANK1_RAS_ERR_IRQ_MASK;
            uint32_t BC0_CORE1_BANK0_RAS_ERR_IRQ_MASK;
            uint32_t BC0_CORE1_BANK1_RAS_ERR_IRQ_MASK;
            uint32_t BC1_CORE0_BANK0_RAS_ERR_IRQ_MASK;
            uint32_t BC1_CORE0_BANK1_RAS_ERR_IRQ_MASK;
            uint32_t BC1_CORE1_BANK0_RAS_ERR_IRQ_MASK;
            uint32_t BC1_CORE1_BANK1_RAS_ERR_IRQ_MASK;
            uint32_t DPR0_RREORDER_RAM_RAS_ERR_IRQ_MASK;
            uint32_t DPW0_QCW_RAM_RAS_ERR_IRQ_MASK;
            uint32_t DPR1_RREORDER_RAM_RAS_ERR_IRQ_MASK;
            uint32_t DPW1_QCW_RAM_RAS_ERR_IRQ_MASK;
            uint32_t DPW0_WDATA_PTY_ERR_IRQ_MASK;
            uint32_t DPW1_WDATA_PTY_ERR_IRQ_MASK;
        } cbf_irq_status2;

        struct _cbf_irq_status3 {
            uint32_t RC0_TOUCH_RESERVED_ADDR_IRQ_MASK;
            uint32_t WC0_TOUCH_RESERVED_ADDR_IRQ_MASK;
            uint32_t RC1_TOUCH_RESERVED_ADDR_IRQ_MASK;
            uint32_t WC1_TOUCH_RESERVED_ADDR_IRQ_MASK;
            uint32_t SWPF_CMDCFG_ERR_IRQ_MASK;
            uint32_t MTN_CMDCFG_ERR_IRQ_MASK;
            uint32_t MTN_CMD_OVERFLOW_IRQ_MASK;
            uint32_t MTN_TIMEOUT_IRQ_MASK;
        } cbf_irq_status3;
    } cbf_irq_status_mask_config;
} CbfIrqStatus;

}  // namespace cbf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CBF_CBF_CTX_H_
