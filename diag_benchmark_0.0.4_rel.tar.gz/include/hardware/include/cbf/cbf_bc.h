/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CBF_CBF_BC_H_
#define HARDWARE_INCLUDE_CBF_CBF_BC_H_

#include <memory>
#include <set>
#include <string>
#include "hardware/include/cbf/cbf_ctx.h"
#include "hardware/include/cbf/cbf_ras.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace cbf {
namespace cbf_bc {

/**
 * @brief CBF BC Hardware Interface
 */
class CbfBc : public Hardware {
 public:
    explicit CbfBc(std::shared_ptr<spdlog::logger> logger);
    virtual ~CbfBc();

    /**
     * @brief  Get one bc size
     * @return uint32_t
     */
    virtual uint32_t GetOneBcSize() = 0;

    /**
     * @brief  Get bank cnt for one bc
     * @return uint32_t
     */
    virtual uint32_t GetOneBcBankCnt() = 0;

    /**
     * @brief  Enable sram redundant mask
     * @param mask_sel: mask sel(sram num)
     */
    virtual void EnableRedunMask(uint32_t mask_sel) = 0;

    /**
     * @brief  Disable sram redundant mask
     */
    virtual void DisableRedunMask() = 0;

    /**
     * @brief  Set cache replacement policy, default 0 is LRU.
     */
    virtual void SetReplacePolicy() = 0;

    /**
     * @brief  Set cache priority max way num.
     * @param high_way: high_max_way
     * @param high_way: mid_max_way
     */
    virtual void SetCachePriorityMaxWay(uint8_t high_way, uint8_t mid_way) = 0;

    /**
     * @brief  Enable bc buf parity check
     */
    virtual void EnableParityCheck() = 0;

    /**
     * @brief  Disable bc buf parity check
     */
    virtual void DisableParityCheck() = 0;

    /**
     * @brief  Enable bc buf parity err enj
     */
    virtual void EnableParityErrEnj() = 0;

    /**
     * @brief  Disable bc buf parity err enj
     */
    virtual void DisableParityErrEnj() = 0;

    /**
     * @brief  Set bc buf par err enj type
     * @param par_err_enj_type: par err enj type:
     *              0: insert par error in par_code[lsb]
     *              1: insert par error in data[lsb]
     */
    virtual void SetParityErrEnjType(const CbfBcParityErrEnjType par_err_enj_type) = 0;

    /**
     * @brief  Set bc buf par err enj counts at a time
     * @param par_err_enj_count: par error counters which will insert in data[lsb]
     *              or par code[lsb] at a time
     */
    virtual void SetParityErrEnjCountOneTime(uint32_t par_err_enj_count) = 0;

    /**
     * @brief  Print BB buffer ras err mem addr
     * @param port_id: cbf port id
     * @return bool
     */
    virtual bool CheckParityErrInfo(uint16_t port_id) = 0;

    /**
     * @brief  Enable BC clk force on
     */
    virtual void EnableForceClkOn() = 0;

    /**
     * @brief  Disable BC clk force on
     */
    virtual void DisableForceClkOn() = 0;

    /**
     * @brief  Check cache mshr queue empty status.
     * @param mshr_idx: mshr_idx
     */
    virtual bool CheckCacheMshrEmpty(uint16_t mshr_idx) = 0;

    /**
     * @brief  Get cache mshr queue status.
     * @param mshr_idx: mshr_idx
     * @param mshr_sts: CbfBcCacheMshrStatus
     */
    virtual void GetCacheMshrStatus(uint16_t mshr_idx, CbfBcCacheMshrStatus *mshr_sts) = 0;

    /**
     * @brief  Print cache mshr queue status.
     * @param bc_id: bc_id
     * @param mshr_idx: mshr_idx
     */
    virtual void PrintCacheMshrStatus(uint16_t bc_id, uint16_t mshr_idx) = 0;

    /**
     * @brief  Enable evict FIFO QOS
     */
    virtual void EnableEvictFifoQos() = 0;

    /**
     * @brief  Disable evict FIFO QOS
     */
    virtual void DisableEvictFifoQos() = 0;

    /**
     * @brief  Set evict FIFO QOS data
     */
    virtual void SetEvictFifoQosData(uint16_t qos_data) = 0;

    /**
     * @brief  Cache flush config
     * @param flush_ctrl: Cache flush control struct
     */
    virtual void ConfigCacheFlush(const CbfCacheFlushCtrl &flush_ctrl) = 0;

    /**
     * @brief  Cacheline lock control for protecting
     */
    virtual void LockCacheLine() = 0;

    /**
     * @brief  Check tag flush done status
     * @return uint32_t
     */
    virtual uint32_t CheckTagFlushDone() = 0;

    /**
     * @brief  Check Sector flush done status
     * @return bool
     */
    virtual bool CheckSectorFlushDone() = 0;

    /**
     * @brief  Check Strobe flush done status
     * @return bool
     */
    virtual bool CheckStrobeFlushDone() = 0;
};

}  // namespace cbf_bc
}  // namespace cbf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CBF_CBF_BC_H_
