/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_DTM_H_
#define HARDWARE_INCLUDE_DTM_H_

#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include "device/include/dtu.h"
#include "framework/include/log.h"
#include "framework/include/mem.h"
#include "hardware/include/atomic/atomic_ctx.h"
#include "hardware/include/dtm_ctx.h"

using efvf::device::Dtu;
using efvf::hardware::atomic::AtomAttr;
using efvf::hardware::codec::CodecConfig;
using efvf::hardware::cva::EfcCmdCfg;
using efvf::hardware::gdte::DteVcCtx;
using efvf::hardware::vpp::EvpConfig;
using efvf::hardware::dtm::DtmEngineId;
namespace efvf {
namespace hardware {
namespace dtm {

class DtmBackend;
class DtmCommand;
class DtmQueue;
class KernelContext;
class L2CacheCfg;
class PmonStat;
class VpuTaskParam;

typedef void (*CallbackFunc)(void *user_param);

class Dtm {
 public:
    virtual ~Dtm() {
        if (backend_)
            delete backend_;
    }

    // for action

    /**
     * @brief      { function_description }
     *
     * @param      queue   The queue
     * @param[in]  cmd_id  must be sequence, provide convenient for deps
     * @param      cmd     The command
     * @param[in]  deps    The deps
     *
     * @return     { description_of_the_return_value }
     */
    DtmCommand *Add(DtmQueue *queue, int cmd_id, DtmCommand *cmd, std::set<int> deps = {});

    /**
     * @brief      { function_description }
     *
     * @param      queue  The queue
     * @param      cmd    The command
     *
     * @return     { description_of_the_return_value }
     */
    DtmCommand *Add(DtmQueue *queue, DtmCommand *cmd);

    /**
     * @brief      { function_description }
     */
    void Build();

    /**
     * @brief      { function_description }
     */
    void Emit();

    /**
     * @brief      { function_description }
     */
    bool WaitIdle(bool non_block = false);

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    bool CheckRet();

    // for queue

    /**
     * @brief      Creates a quarter.
     *
     * @param[in]  id    The identifier
     * @param[in]  mode  "framing"
     *
     * @return     { description_of_the_return_value }
     */
    DtmQueue *CreateQ(int id, std::string mode = "");

    // for command

    /**
     * @brief      Starts a dpf.
     */
    virtual void StartDpf() {}

    /**
     * @brief      Stops a dpf.
     */
    virtual void StopDpf(std::string trace = "trace.json") {}

    virtual void StopDpf(
        const std::vector<DtmEngineId> &, std::vector<uint64_t> &duration, uint64_t id) {}

    virtual void ReportDpf(std::string tag) {}
    /**
     * @brief start perf monitor
     * could be profiler pmc, dvfs pmc, bpm
     */
    virtual void StartPmon(std::string opt = "") {}

    /**
     * @brief stop perf monitor
     *
     */
    virtual void StopPmon(PmonStat *p = nullptr, std::string csv = "pmon.csv") {}

    /**
     * @brief      Creates a linear command.
     *
     * @return     { description_of_the_return_value }
     */
    virtual DtmCommand *CreateLinearCmd(
        std::string engine, const std::vector<int> &loc, uint32_t size, std::string dir) {
        return nullptr;
    }

    /**
     * @brief      Create a Linear Cmd object
     *
     * @param      engine    The engine
     * @param      loc       The location
     * @param      src       The source
     * @param      dst       The destination
     * @param[in]  src_offs  The source offs
     * @param[in]  dst_offs  The destination offs
     * @param[in]  size      The size
     *
     * @return     DtmCommand*
     */
    virtual DtmCommand *CreateLinearCmd(std::string engine, const std::vector<int> &loc,
        Mem *src, Mem *dst, uint64_t src_offs = 0, uint64_t dst_offs = 0, uint64_t size = 0) {
        return nullptr;
    }

    /**
     * @brief Create a Linear Cmd object
     *    src / dst address & size are provided by user
     *    only for some cases, like sdte load/store sip memory which uses direct address
     * @param engine
     * @param loc
     * @param src_addr
     * @param dst_addr
     * @param size
     * @return DtmCommand*
     */
    virtual DtmCommand *CreateLinearCmd(std::string engine, const std::vector<int> &loc,
        uint64_t src_addr, uint64_t dst_addr, uint64_t size) {
        return nullptr;
    }

    /**
     * @brief Create a Host Cmd object
     *
     * @param cb_func
     * @param user_param
     * @return DtmCommand*
     */
    virtual DtmCommand *CreateHostCmd(CallbackFunc cb_func, void *user_param) {
        return nullptr;
    }

    virtual DtmCommand *CreateHostAssistCmd(DtmCommand *cons) {
        return nullptr;
    }

    /**
     * @brief Create a Deslice Cmd object
     *
     * @param engine  The engine
     * @param loc     engine location
     * @param src
     * @param dst
     * @param offset  element offset in dst dim
     * @return DtmCommand*
     */
    virtual DtmCommand *CreateDesliceCmd(std::string engine, const std::vector<int> &loc,
        Mem *src, Mem *dst, const std::vector<dim_t> &offset) {
        return nullptr;
    }

    /**
     * @brief      Creates a synchronize command.
     *
     * @param[in]  engine  The engine
     * @param[in]  loc     The location
     *
     * @return     { description_of_the_return_value }
     */
    virtual DtmCommand *CreateSyncCmd(std::string engine, const std::vector<int> &loc) {
        return nullptr;
    }

    /**
     * @brief      Creates a synchronize command.
     *
     * @param[in]  engine  The engine
     * @param[in]  loc     The location
     *
     * @return     { description_of_the_return_value }
     */
    virtual DtmCommand *CreateDteCmd(std::string engine, const std::vector<int> &loc,
        const DteVcCtx &ctx, int vc, DteVcCtx **ctx_out = nullptr, bool iter_op = false) {
        return nullptr;
    }

    /**
     * @brief      Create a Load Kern Code Cmd object
     *
     * @param      kctx  The kctx
     *
     * @return     stdDtmCommand *
     */
    virtual DtmCommand *CreateLoadKernCodeCmd(const KernelContext *kctx) {
        return nullptr;
    }

    /**
     * @brief      Create a Load Kern Data Cmd object
     *
     * @param      kctx        : kernel context
     * @param      kdata_type  : "sdmem", "vdmem"
     *
     * @return     DtmCommand *
     */
    virtual DtmCommand *CreateLoadKernDataCmd(
        const KernelContext *kctx, std::string kdata_type) {
        return nullptr;
    }

    /**
     * @brief      Create a Launch Sip Cmd object
     *
     * @param      kctx  The kctx
     *
     * @return     DtmCommand *
     */
    virtual DtmCommand *CreateLaunchSipCmd(const KernelContext *kctx) {
        return nullptr;
    }

    /**
     * @brief      Creates a sip launch command.
     *
     * @return     { description_of_the_return_value }
     */
    virtual DtmCommand *CreateSipLaunchCmd() {
        return nullptr;
    }

    /**
     * @brief      Creates a evp command.
     *
     * @param[in]  kctx  The kctx
     *
     * @return     { description_of_the_return_value }
     */
    virtual DtmCommand *CreateEvpCmd(const std::vector<int> &loc, EvpConfig *cfg) {
        return nullptr;
    }

    /**
     * @brief      Creates a efc command.
     *
     * @param[in]  kctx  The kctx
     *
     * @return     { description_of_the_return_value }
     */
    virtual DtmCommand *CreateEfcCmd(const std::vector<int> &loc, EfcCmdCfg *cfg) {
        return nullptr;
    }

    /**
     * @brief      Creates a codec command.
     *
     * @param[in]  kctx  The kctx
     *
     * @return     { description_of_the_return_value }
     */
    virtual DtmCommand *CreateCodecCmd(const std::vector<int> &loc, CodecConfig *cfg,
        Mem *in_data_mem, uint32_t in_data_size, std::vector<uint32_t> &golden_crc,
        std::vector<Mem *> &out_buf) {
        return nullptr;
    }

    /**
     * @brief      Creates a vpu command.
     *
     * @param[in]  vpu_task  The VPU task param
     *
     * @return     { description_of_the_return_value }
     */
    virtual DtmCommand *CreateVpuTaskCmd(const VpuTaskParam *vpu_task) {
        return nullptr;
    }

    const Dtu *dtu_;

    bool b_show_progress_ = true;

 protected:
    DtmBackend *                    backend_ = nullptr;
    std::shared_ptr<spdlog::logger> logger_;
};

class DtmCommand {
 public:
    /**
     * @brief      Destroys the object.
     */
    virtual ~DtmCommand() {}

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    DtmCommand *WaitOn(std::vector<DtmCommand *> list);

    /**
     * @brief      { function_description }
     *
     * @param[in]  list  The list
     *
     * @return     { description_of_the_return_value }
     */
    DtmCommand *SignalTo(std::vector<DtmCommand *> list);

    /**
     * @brief      { function_description }
     */
    virtual void BuildHostPkt() {}

    /**
     * @brief      { function_description }
     */
    virtual void BuildHost2Pkt() {}

    /**
     * @brief      { function_description }
     */
    virtual void BuildHost3Pkt() {}

    /**
     * @brief      Builds an amos packet.
     */
    virtual void BuildAmosPkt() {}

    /**
     * @brief      { function_description }
     */
    virtual void Trigger() {}

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitIdle(bool non_block = false) {
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool CheckRet() {
        return false;
    }

    /**
     * @brief      Sets the cache configuration.
     *
     * @param      cache  The cache
     */
    virtual DtmCommand *SetCacheCfg(L2CacheCfg *cache) {
        return nullptr;
    }

    virtual DtmCommand *SetAtomFlag(AtomAttr *atop) {
        return nullptr;
    }

    virtual std::string GetCmdInfo() {
        return "";
    }

    int              queue_id_;
    int              cmd_id_;
    std::string      cmd_name_;
    std::set<int>    deps_;
    std::string      engine_;
    std::vector<int> engine_loc_;

    L2CacheCfg *cache_attr_ = nullptr;
    AtomAttr *  atom_attr_  = nullptr;

    DtmCommand *next_ = nullptr;

    std::set<DtmCommand *> prod_;
    std::set<DtmCommand *> cons_;
    bool                   is_vec_cmd  = false;
    int                    vec_cmd_idx = -1;

    friend class DtmQueue;

 protected:
    Dtm *                           dtm_;
    std::shared_ptr<spdlog::logger> logger_;
};

class DtmQueue {
 public:
    /**
     * @brief      Destroys the object.
     */
    virtual ~DtmQueue() {
        for (uint32_t i = 0; i < cmd_list_.size(); i++) {
            if (cmd_list_[i]) {
                LOG_DEBUG("del cmd {}", cmd_list_[i]->cmd_id_);
                delete cmd_list_[i];
            }
        }
    }

    /**
     * @brief      { function_description }
     */
    void Build();

    /**
     * @brief
     *  doing pre-process before Build the queue.
     */
    void PreBuild();

    void DumpCmdInfo();

    int                             id_;         // virtual id
    int                             unique_id_;  // used by dirver to support moulti card
    std::vector<DtmCommand *>       cmd_list_;
    std::string                     mode_ = "";
    std::shared_ptr<spdlog::logger> logger_;

    L2CacheCfg *      cache_attr_ = nullptr;
    static int        unique_id_val;
    static std::mutex cls_mut_;
};

class DtmBackend {
 public:
    /**
     * @brief      Destroys the object.
     */
    virtual ~DtmBackend() {
        for (auto &q : queues2_) {
            if (q.second) {
                LOG_DEBUG("del queue {}", q.first);
                delete q.second;
            }
        }
    }

    /**
     * @brief      { function_description }
     */
    virtual void Build() {}

    /**
     * @brief      { function_description }
     */
    virtual void Emit() {}

    /**
     * @brief      { function_description }
     */
    virtual bool WaitIdle(bool non_block = false) {
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool CheckRet() {
        return false;
    }

    std::map<int, DtmQueue *> queues2_;

 protected:
    Dtm *                           dtm_;
    std::shared_ptr<spdlog::logger> logger_;
};

extern Dtm *GetDtm(const Dtu *dtu, std::string backend);

}  // namespace dtm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_DTM_H_
