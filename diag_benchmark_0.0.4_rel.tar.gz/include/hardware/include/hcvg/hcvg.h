/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_HCVG_HCVG_H_
#define HARDWARE_INCLUDE_HCVG_HCVG_H_

#include <memory>
#include <string>
#include "framework/include/mem.h"
#include "hardware/include/hardware.h"
#include "hardware/include/hcvg/hcvg_sch_cmd.h"

using efvf::framework::mem::Mem;

namespace efvf {
namespace hardware {
namespace hcvg {

#define MAX_HCVG_INST (2)
#define MAX_HCVG_HCVGE_INST (2)
#define MAX_HCVG_SCH_VC_INST (4)

#undef HCVG_SHOW_FUNC_NAME
#define HCVG_SHOW_FUNC_NAME LOG_DEBUG("{}", __func__)

// FW MODE {{
#define HCVG_MAX_STREAM_NUM 16
#define HCVG_MAX_PACKET_NUM 16
#define HCVG_INTERNAL_BUFFER_LEN (1 << 28)  // 256 MB
#define HCVG_MAX_CTX_NUM (HCVG_MAX_STREAM_NUM * HCVG_MAX_PACKET_NUM)

#define HCVG_VDSP_DEBUG_VERSION_REG (HCVG_SIGMSG3_INT_TRIG_OFFSET)
#define HCVG_VDSP_DEBUG_COMMIT_ID_REG (HCVG_SIGMSG4_INT_TRIG_OFFSET)
#define HCVG_VDSP_DEBUG_COMMIT_DATE_REG (HCVG_SIGMSG5_INT_TRIG_OFFSET)
#define HCVG_VDSP_DEBUG_ERROR_CODE_REG (HCVG_SIGMSG6_INT_TRIG_OFFSET)

#define HCVG_RING_BUFFER_INIT_SIG_REG (HCVG_SIGMSG7_INT_TRIG_OFFSET)
#define HCVG_RING_BUFFER_BASE_ADDR_LO_REG (HCVG_SIGMSG8_INT_TRIG_OFFSET)
#define HCVG_RING_BUFFER_BASE_ADDR_HI_REG (HCVG_SIGMSG9_INT_TRIG_OFFSET)
#define HCVG_RING_BUFFER_LENGTH_REG (HCVG_SIGMSG10_INT_TRIG_OFFSET)
#define HCVG_RING_BUFFER_WPTR_REG (HCVG_SIGMSG11_INT_TRIG_OFFSET)
#define HCVG_RING_BUFFER_RPTR_REG (HCVG_SIGMSG12_INT_TRIG_OFFSET)

// }}

enum HCVG_MODE {
    HCVG_MODE_REG = 0,
    HCVG_MODE_FW,
    HCVG_MODE_TOOL,
    VDEC_MODE_KMD,
    HCVG_MODE_MAX
};

enum HCVE_CMD_TYPE {
    TYPE_CCL_NORMAL          = 0x10,
    TYPE_CCL_NBR_LINK        = 0x11,
    TYPE_FC_EXTERNAL         = 0x20,
    TYPE_FC_EXTONCE          = 0x21,
    TYPE_MAR_NORMAL          = 0x30,
    TYPE_CONVEX_HULL         = 0x31,
    TYPE_ROTCALIP_MAX_HEIGHT = 0x32,
    TYPE_ROTCALIP_MIN_AREA   = 0x33,
    TYPE_BATCH_CMD           = 0x7F
};

typedef struct HcvgImgMetaData {
    uint32_t stretched_width;
    uint32_t stretched_height;
    uint32_t contours_num;
    uint32_t original_width;
    uint32_t original_height;
    HcvgImgMetaData()
        : stretched_width(0),
          stretched_height(0),
          contours_num(0),
          original_width(0),
          original_height(0) {}
} HcvgImgMetaData;

typedef struct HcvgInputBufTable_t {
    uint32_t params_table_addr_lo;
    uint32_t params_table_addr_hi;
    uint32_t params_table_len;
    uint32_t ccl_pixel_addr_lo;
    uint32_t ccl_pixel_addr_hi;
    uint32_t ccl_link_addr_lo;
    uint32_t ccl_link_addr_hi;
    uint32_t ccl_output_label_addr_lo;
    uint32_t ccl_output_label_addr_hi;
    uint32_t ccl_angle_maps_addr_lo;
    uint32_t ccl_angle_maps_addr_hi;
    uint32_t ccl_mlabel_logit_addr_lo;
    uint32_t ccl_mlabel_logit_addr_hi;
    uint32_t fc_output_contours_addr_lo;
    uint32_t fc_output_contours_addr_hi;
    uint32_t fc_output_contours_num_addr_lo;
    uint32_t fc_output_contours_num_addr_hi;
    uint32_t mara_output_hull_addr_lo;
    uint32_t mara_output_hull_addr_hi;
    HcvgInputBufTable_t()
        : params_table_addr_lo(0),
          params_table_addr_hi(0),
          params_table_len(0),
          ccl_pixel_addr_lo(0),
          ccl_pixel_addr_hi(0),
          ccl_link_addr_lo(0),
          ccl_link_addr_hi(0),
          ccl_output_label_addr_lo(0),
          ccl_output_label_addr_hi(0),
          ccl_angle_maps_addr_lo(0),
          ccl_angle_maps_addr_hi(0),
          ccl_mlabel_logit_addr_lo(0),
          ccl_mlabel_logit_addr_hi(0),
          fc_output_contours_addr_lo(0),
          fc_output_contours_addr_hi(0),
          fc_output_contours_num_addr_lo(0),
          fc_output_contours_num_addr_hi(0),
          mara_output_hull_addr_lo(0),
          mara_output_hull_addr_hi(0) {}
} HcvgInputBufTable_t;

typedef struct HcvgParamsTable_t {
    uint32_t ccl_cmd_type;
    uint32_t fc_cmd_type;
    uint32_t mara_cmd_type;
    uint32_t contextID;
    uint32_t ocr_resize_width;
    uint32_t ocr_resize_height;
    uint32_t original_image_width;
    uint32_t original_image_height;
    uint32_t ccl_image_size;
    uint32_t ccl_connectivity;
    uint32_t ccl_lable_type;
    uint32_t angle_map_type;
    uint32_t fc_mode;
    uint32_t fc_method;
    uint32_t mara_convexhull_clockwise;
    HcvgParamsTable_t()
        : ccl_cmd_type(0),
          fc_cmd_type(0),
          mara_cmd_type(0),
          contextID(0),
          ocr_resize_width(0),
          ocr_resize_height(0),
          original_image_width(0),
          original_image_height(0),
          ccl_image_size(0),
          ccl_connectivity(0),
          ccl_lable_type(0),
          angle_map_type(0),
          fc_mode(0),
          fc_method(0),
          mara_convexhull_clockwise(0) {}
} HcvgParamsTable_t;

typedef struct HcvgExecCtx_t {
#define RESERVED_VG_MEM_LEN (1024)
    uint32_t input_buffer_addr_table_lo;
    uint32_t input_buffer_addr_table_hi;
    uint32_t input_buffer_len;
    uint32_t output_buffer_addr_table_lo;
    uint32_t output_buffer_addr_table_hi;
    uint32_t output_buffer_len;
    uint32_t internal_buffer_addr_table_lo;
    uint32_t internal_buffer_addr_table_hi;
    uint32_t internal_buffer_len;
    // reserved 4K byte for VG
    uint32_t ocr_reserved_VG_mem[RESERVED_VG_MEM_LEN];
    HcvgExecCtx_t()
        : input_buffer_addr_table_lo(0),
          input_buffer_addr_table_hi(0),
          input_buffer_len(0),
          output_buffer_addr_table_lo(0),
          output_buffer_addr_table_hi(0),
          output_buffer_len(0),
          internal_buffer_addr_table_lo(0),
          internal_buffer_addr_table_hi(0),
          internal_buffer_len(0) {
        for (uint32_t i = 0; i < RESERVED_VG_MEM_LEN; i++) {
            ocr_reserved_VG_mem[i] = 0;
        }
    }
} HcvgExecCtx_t;

typedef struct HcvgCtxParam_t {
    HcvgExecCtx_t       exec_ctx;
    HcvgInputBufTable_t buf_tbl;
    HcvgParamsTable_t   param_tbl;
} HcvgCtxParam_t;

// FIXME: temp define here, must sync with packet_api.h
// {{
typedef struct executable_start {
    uint32_t header_dw;
    uint32_t packet_id;
    uint32_t context_addr_dw;
    uint32_t context_dw_len_dw;
    uint32_t executable_id;
    uint32_t ih_addr;
} executable_start;

#define __executable_start__header 0x25000006

typedef struct executable_start HcvgExecPkt_t;

typedef uint64_t HcvgExecCtxId;

#define HcvgExec_Header (0x25000006)
// }}

class Hcvg : public Hardware {
 public:
    Hcvg() : Hardware() {}
    explicit Hcvg(std::shared_ptr<spdlog::logger> logger);
    virtual ~Hcvg();

 public:
    virtual HCVG_MODE GetRunMode() const = 0;
    virtual void SetRunMode(HCVG_MODE mode = HCVG_MODE_REG) = 0;

    virtual bool SoftResetReg() = 0;
    virtual bool CheckInterruptReg(uint32_t vc = 0) = 0;
    virtual bool ClearInterruptReg(uint32_t vc = 0) = 0;

    //  virtual bool TriggerHcvgReg()                = 0;
    virtual bool RunSchCmdReg(SchCmd &cmd, uint32_t vc = 0) = 0;
    virtual bool GetSchCmdRespReg(SchCmd &cmd, uint32_t vc = 0) = 0;

    virtual bool LoadFw(const std::string &iram_file, const std::string &dram_file,
        bool auto_cmp, bool auto_run) = 0;
    virtual void VdspEnable(bool enable) = 0;

    // FW MODE {{
    virtual void          DumpFwDebugInfo()            = 0;
    virtual uint32_t      GetFwInternalBufSize() const = 0;
    virtual uint64_t      GetFwInternalBufAddr() const = 0;
    virtual HcvgExecCtxId FwWriteExecCtx(
        const uint32_t ctx_idx, void *data, uint32_t data_len) const = 0;
    virtual bool FwRunCtxPkt(
        const HcvgExecCtxId ctx_id, const uint32_t pkt_id, const uint32_t exec_id) = 0;
    // }}
};

#define DefineHcvg(chip, class_name, ...)                                               \
    class class_name : public Hcvg {                                                    \
     public:                                                                            \
        class_name() : Hcvg() {}                                                        \
        explicit class_name(std::shared_ptr<spdlog::logger> logger);                    \
        virtual ~class_name();                                                          \
                                                                                        \
        virtual void SetRunMode(HCVG_MODE mode);                                        \
        virtual HCVG_MODE GetRunMode() const;                                           \
                                                                                        \
        virtual bool SoftResetReg();                                                    \
        virtual bool CheckInterruptReg(uint32_t vc);                                    \
        virtual bool ClearInterruptReg(uint32_t vc);                                    \
                                                                                        \
        virtual bool RunSchCmdReg(SchCmd &cmd, uint32_t vc);                            \
        virtual bool GetSchCmdRespReg(SchCmd &cmd, uint32_t vc);                        \
        virtual bool LoadFw(const std::string &iram_file, const std::string &dram_file, \
            bool auto_cmp, bool auto_run);                                              \
        virtual void VdspEnable(bool enable);                                           \
                                                                                        \
        virtual void          DumpFwDebugInfo();                                        \
        virtual uint32_t      GetFwInternalBufSize() const;                             \
        virtual uint64_t      GetFwInternalBufAddr() const;                             \
        virtual HcvgExecCtxId FwWriteExecCtx(                                           \
            const uint32_t ctx_id, void *data, uint32_t data_len) const;                \
        virtual bool FwRunCtxPkt(                                                       \
            const HcvgExecCtxId ctx_id, const uint32_t pkt_id, const uint32_t exec_id); \
                                                                                        \
     private:                                                                           \
        virtual bool HwInit();                                                          \
        virtual bool HwDeinit();                                                        \
                                                                                        \
        void     FwAllocMemBuf();                                                       \
        uint32_t GetCtxParamSize() const;                                               \
        void     FwRingBufSetup();                                                      \
        uint32_t GetFwRingBufRdPtr();                                                   \
        void SetFwRingBufRdPtr(uint32_t rptr);                                          \
        uint32_t GetFwRingBufWrPtr();                                                   \
        void SetFwRingBufWrPtr(uint32_t wptr);                                          \
        uint32_t GetFwRingBufSize();                                                    \
        void SetFwRingBufSize(uint32_t dw_num);                                         \
        uint64_t GetFwRingBufBaseAddr();                                                \
        void SetFwRingBufBaseAddr(uint64_t addr);                                       \
        bool CheckFwRingBufStatus(uint32_t dw_num);                                     \
                                                                                        \
        bool LoadFwToRam(const std::string &ram_file, bool to_iram, bool auto_cmp);     \
                                                                                        \
        void InitInterruptReg();                                                        \
        void InitHcveMemReg();                                                          \
                                                                                        \
     private:                                                                           \
        HCVG_MODE m_mode;                                                               \
        bool      m_reload_fw;                                                          \
                                                                                        \
        std::shared_ptr<Mem> m_bzn_mem_hdl;                                             \
        std::shared_ptr<Mem> m_rtmp_mem_hdl;                                            \
        std::shared_ptr<Mem> m_plb_ext_mem_hdl;                                         \
        std::shared_ptr<Mem> m_elb_ext_mem_hdl;                                         \
                                                                                        \
        std::shared_ptr<Mem> m_ring_buf_mem_hdl;                                        \
        std::shared_ptr<Mem> m_internal_mem_hdl;                                        \
        std::shared_ptr<Mem> m_exec_ctx_mem_hdl;                                        \
                                                                                        \
        const uint64_t TEST_INTERRUPT_ADDR = 0xC90054;                                  \
        const uint32_t TEST_INTERRUPT_DATA = 0x1234;                                    \
                                                                                        \
        const uint32_t TMP_HCVE_MEM_SIZE = 0X10000000;                                  \
    }

}  // namespace hcvg
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_HCVG_HCVG_H_
