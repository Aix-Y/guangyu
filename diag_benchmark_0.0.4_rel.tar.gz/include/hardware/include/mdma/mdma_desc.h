/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MDMA_MDMA_DESC_H_
#define HARDWARE_INCLUDE_MDMA_MDMA_DESC_H_

#include <string>

namespace efvf {
namespace hardware {
namespace mdma {

class Mdma;
class MdmaComp;
class MdmaCCommon;
class MdmaCPolling;
class MdmaCVc;
class MdmaCQueue;
class MdmaCHqsQueue;
class MdmaCHqsTop;

const uint32_t NON_SPECIFIED = 0xdeadbeef;
const uint64_t TIMEOUTMS_10S = (1000 * 1000);

typedef enum _MdmaBurstLen {
    MdmaBurstLenInvalid = 0,
    MdmaBurstLen1,
    MdmaBurstLen2,
    MdmaBurstLen4,
    MdmaBurstLen8,
    MdmaBurstLen16,
    MdmaBurstLenMax,
} MdmaBurstLen_t;

typedef enum _MdmaOperation {
    MdmaOpInvalid = 0,
    MdmaOpVcLinearcopy,
    MdmaOpVcGather,
    MdmaOpVcScatter,
    MdmaOpVcPolling,
    MdmaOpVcConstantFilling,
    MdmaOpVcDerivedScatter,
    MdmaOpCmdqLinearcopy,
    MdmaOpCmdqScatter,
    MdmaOpCmdqDerivedScatter,
    MdmaOpMax,
} MdmaOp_t;

typedef enum _MdmaAxiPortType {
    MdmaAxiPortInvalid = 0,
    MdmaAxiNPortRd,
    MdmaAxiNPortWr,
    MdmaAxiWPortRd,
    MdmaAxiWPortWr,
    MdmaAxiPortMax,
} MdmaAxiPort_t;

typedef enum _MdmaMcuViewType {
    MdmaMcuViewInvalid = 0,
    MdmaMcuViewL1,
    MdmaMcuViewL2,
    MdmaMcuViewMax,
} MdmaMcuView_t;

typedef enum _MdmaEleType {
    MdmaEleInvalid = 0,
    MdmaEleMcuL1,
    MdmaEleMcuL2,
    MdmaEleLc,
    MdmaEleOvflHqsSrc,
    MdmaEleOvflCmdq,
    MdmaEleVc,
    MdmaEleScatter,
    MdmaEleGather,
    MdmaElePolling,
    MdmaElePortL,
    MdmaElePortN,
    MdmaElePortW,
    MdmaElePIS,
    MdmaEleFUIS,
    MdmaElePIIS,
    MdmaEleMIS,
    MdmaEleMax,
} MdmaEle_t;

typedef enum _MdmaEngineType {
    MdmaEngineInvalid = 0,
    MdmaEngineSp,
    MdmaEngineAp,
    MdmaEngineCva,
    MdmaEngineVpp,
    MdmaEngineVpu,
    MdmaEngineSsm,
    MdmaEngineMax,
} MdmaEngine_t;

inline std::string _mdma_engt_2str(MdmaEngine_t &e_t) {
    switch (e_t) {
        case MdmaEngineInvalid:
            return "mdma.na";
        case MdmaEngineSp:
            return "mdma.sp";
        case MdmaEngineAp:
            return "mdma.ap";
        case MdmaEngineCva:
            return "mdma.cva";
        case MdmaEngineVpp:
            return "mdma.vpp";
        case MdmaEngineVpu:
            return "mdma.vpu";
        case MdmaEngineSsm:
            return "mdma.ssm";
        case MdmaEngineMax:
            return "mdma.max";
        default:
            break;
    }
    return "eng_udef";  // engine type undefined
}

typedef enum _MdmaCompType {
    MdmaCompInvalid = 0,
    MdmaCompCommon,
    MdmaCompPolling,
    MdmaCompVc,
    MdmaCompQueue,
    MdmaCompHqsQueue,
    MdmaCompHqsTop,
    MdmaCompMpq,
    MdmaCompMax,
} MdmaComp_t;

typedef struct _MdmaEngineCompDesc {
    uint32_t     inst  = 0;
    uint32_t     addr  = 0;
    uint32_t     size  = 0;
    uint32_t     numx  = 0;
    std::string  desc  = "";
    MdmaComp_t   ctype = MdmaCompInvalid;
    MdmaEngine_t etype = MdmaEngineInvalid;

    void set_type(const MdmaEngine_t &_et, const MdmaComp_t &_ct) {
        etype = _et;
        ctype = _ct;
    }
    bool IsEngineSp(void) {
        return (MdmaEngineSp == etype);
    }
    bool IsEngineAp(void) {
        return (MdmaEngineAp == etype);
    }
    bool IsEngineCva(void) {
        return (MdmaEngineCva == etype);
    }
    bool IsEngineVpp(void) {
        return (MdmaEngineVpp == etype);
    }
    bool IsEngineVpu(void) {
        return (MdmaEngineVpu == etype);
    }
    bool IsEngineSsm(void) {
        return (MdmaEngineSsm == etype);
    }
    bool IsCommon(void) {
        return (MdmaCompCommon == ctype);
    }
    bool IsPolling(void) {
        return (MdmaCompPolling == ctype);
    }
    bool IsVc(void) {
        return (MdmaCompVc == ctype);
    }
    bool IsQueue(void) {
        return (MdmaCompQueue == ctype);
    }
    bool IsHqsQueue(void) {
        return (MdmaCompHqsQueue == ctype);
    }
    bool IsHqsTop(void) {
        return (MdmaCompHqsTop == ctype);
    }
    bool IsMpq(void) {
        return (MdmaCompMpq == ctype);
    }
} MdmaEngineCompDesc_t;

typedef struct _MdmaEngineDesc {
    bool                 eready    = false;
    MdmaEngine_t         etype     = MdmaEngineInvalid;
    MdmaEngineCompDesc_t common    = {};
    MdmaEngineCompDesc_t polling   = {};
    MdmaEngineCompDesc_t vc        = {};
    MdmaEngineCompDesc_t queue     = {};
    MdmaEngineCompDesc_t hqs_queue = {};
    MdmaEngineCompDesc_t hqs_top   = {};
    MdmaEngineCompDesc_t mpq       = {};

    void set_type(const MdmaEngine_t &_etype) {
        etype = _etype;
        common.set_type(etype, MdmaCompCommon);
        polling.set_type(etype, MdmaCompPolling);
        vc.set_type(etype, MdmaCompVc);
        queue.set_type(etype, MdmaCompQueue);
        hqs_queue.set_type(etype, MdmaCompHqsQueue);
        hqs_top.set_type(etype, MdmaCompHqsTop);
        mpq.set_type(etype, MdmaCompMpq);
    }
    bool IsEngineSp(void) {
        return (MdmaEngineSp == etype);
    }
    bool IsEngineAp(void) {
        return (MdmaEngineAp == etype);
    }
    bool IsEngineCva(void) {
        return (MdmaEngineCva == etype);
    }
    bool IsEngineVpp(void) {
        return (MdmaEngineVpp == etype);
    }
    bool IsEngineVpu(void) {
        return (MdmaEngineVpu == etype);
    }
    bool IsEngineSsm(void) {
        return (MdmaEngineSsm == etype);
    }
} MdmaEngineDesc_t;

inline std::string _mdma_compt_2str(MdmaComp_t &c_t) {
    switch (c_t) {
        case MdmaCompInvalid:
            return "comp.na";
        case MdmaCompCommon:
            return "comp.common";
        case MdmaCompPolling:
            return "comp.polling";
        case MdmaCompVc:
            return "comp.vc";
        case MdmaCompQueue:
            return "comp.queue";
        case MdmaCompHqsQueue:
            return "comp.hqs.queue";
        case MdmaCompHqsTop:
            return "comp.hqs.top";
        case MdmaCompMpq:
            return "comp.mpq";
        case MdmaCompMax:
            return "comp.max";
        default:
            break;
    }
    return "comp_udef";  // component type undefined
}

typedef struct _MdmaItemCfg {
    _MdmaItemCfg() {
        clear();  // default
    }
    _MdmaItemCfg(const _MdmaItemCfg &c) {
        set(c);  // copy
    }
    _MdmaItemCfg &operator=(const _MdmaItemCfg &c) {
        set(c);
        return *this;  // assign
    }
    void operator()(const bool &_v) {
        set(_v);  // bool val
    }
    void operator()(const uint32_t &_v) {
        set(_v);  // u32 val
    }
    void operator()(const uint64_t &_v) {
        set(_v);  // u64 val
    }
    void operator()(const _MdmaItemCfg &c) {
        set(c);  // copy
    }
    void operator()(const MdmaBurstLen_t &bl) {
        set(uint32_t(bl));
    }
    void clear() {  // reset
        ena = false;
        val = 0;
    }
    void set(const bool &_v) {  // bool val
        set(true, (uint64_t)(_v ? 1 : 0));
    }
    void set(const uint32_t &_v) {  // u32 val
        set(true, (uint64_t)(_v));
    }
    void set(const uint64_t &_v) {  // u64 val
        set(true, _v);
    }
    void set(const bool &_e, const uint64_t &_v) {  // raw
        ena = _e;
        val = _v;
    }
    void set(const _MdmaItemCfg &c) {  // copy
        ena = c.ena;
        val = c.val;
    }
    std::string str(const std::string item) {
        std::stringstream info("");
        info << (ena ? "[*]" : "[o]") << item << " = 0x" << std::hex << val;
        return info.str();
    }
    bool     ena;  // default disabled [1] apply val [0] skip setting
    uint64_t val;  // default val-zero
} MdmaItemCfg;

typedef struct _MdmaCommonCfg {
    MdmaItemCfg wport_bl_r;     // burst length
    MdmaItemCfg wport_bl_w;     // burst length
    MdmaItemCfg lmem_addr_st;   // local memory start addr
    MdmaItemCfg lmem_addr_sz;   // local memory size
    MdmaItemCfg static_id_lc0;  // static channel id in linear copy 0
    MdmaItemCfg static_id_lc1;  // static channel id in linear copy 1

    // clang-format off
    std::string str(std::string tag = "") {  // debug
        std::stringstream info("");
        info << std::endl << tag << "|common " <<    wport_bl_r.str("wport_bl_r   "); // NOLINT
        info << std::endl << tag << "|common " <<    wport_bl_w.str("wport_bl_w   "); // NOLINT
        info << std::endl << tag << "|common " <<  lmem_addr_st.str("lmem_addr_st "); // NOLINT
        info << std::endl << tag << "|common " <<  lmem_addr_sz.str("lmem_addr_sz "); // NOLINT
        info << std::endl << tag << "|common " << static_id_lc0.str("static_id_lc0"); // NOLINT
        info << std::endl << tag << "|common " << static_id_lc1.str("static_id_lc1"); // NOLINT
        return info.str();
    }
    // clang-format on
} MdmaCommonCfg;

typedef struct _MdmaLinearCopyCfg {
    MdmaItemCfg src_addr;           // copy source address
    MdmaItemCfg dst_addr;           // copy destination address
    MdmaItemCfg size;               // copy data size in byte
    MdmaItemCfg signal0_en;         // signaling target 0 enable
    MdmaItemCfg signal0_addr;       // signaling target 0 address
    MdmaItemCfg signal0_data;       // signaling target 0 data
    MdmaItemCfg signal1_en;         // signaling target 1 enable
    MdmaItemCfg signal1_addr;       // signaling target 1 address
    MdmaItemCfg signal1_data;       // signaling target 1 data
    MdmaItemCfg op_static_inst_en;  // linear copy unit
    MdmaItemCfg op_static_inst;     // linear copy unit
    MdmaItemCfg op_ctx;             // operation context id
    MdmaItemCfg op_priority;        // operation priority
    MdmaItemCfg op_fence;           // operation fence flag
    MdmaItemCfg op_awcache;         // operation write cacheable attribution
    MdmaItemCfg op_arcache;         // operation read cacheable attribution
    MdmaItemCfg id_mode;            // 0: dynamic id 1: static ID
    MdmaItemCfg static_id;          // static id
    MdmaItemCfg awuser_19_16;       // awuser_19_16
    MdmaItemCfg aruser_19_16;       // aruser_19_16
    MdmaItemCfg scratch;            // scratch
    MdmaItemCfg awuser_35_20;       // awuser_35_20
    MdmaItemCfg aruser_35_20;       // aruser_35_20

    // clang-format off
    std::string str(std::string tag = "") {  // debug
        std::stringstream info("");
        info << std::endl << tag << "|linear-copy " <<          src_addr.str("src_addr         "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<          dst_addr.str("dst_addr         "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<              size.str("size             "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<        signal0_en.str("signal0_en       "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<      signal0_addr.str("signal0_addr     "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<      signal0_data.str("signal0_data     "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<        signal1_en.str("signal1_en       "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<      signal1_addr.str("signal1_addr     "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<      signal1_data.str("signal1_data     "); // NOLINT
        info << std::endl << tag << "|linear-copy " << op_static_inst_en.str("op_static_inst_en"); // NOLINT
        info << std::endl << tag << "|linear-copy " <<    op_static_inst.str("op_static_inst   "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<            op_ctx.str("op_ctx           "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<       op_priority.str("op_priority      "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<          op_fence.str("op_fence         "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<        op_awcache.str("op_awcache       "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<        op_arcache.str("op_arcache       "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<           id_mode.str("id_mode          "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<         static_id.str("static_id        "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<      awuser_19_16.str("awuser_19_16     "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<      aruser_19_16.str("aruser_19_16     "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<           scratch.str("scratch          "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<      awuser_35_20.str("awuser_35_20     "); // NOLINT
        info << std::endl << tag << "|linear-copy " <<      aruser_35_20.str("aruser_35_20     "); // NOLINT
        return info.str();
    }
    // clang-format on
} MdmaLinearCopyCfg;

typedef struct _MdmaConstFillCfg {
    MdmaItemCfg dst_addr;               // copy destination address
    MdmaItemCfg size;                   // copy data size in byte
    MdmaItemCfg constant_filling_data;  // constant filling data
    MdmaItemCfg signal0_en;             // signaling target 0 enable
    MdmaItemCfg signal0_addr;           // signaling target 0 address
    MdmaItemCfg signal0_data;           // signaling target 0 data
    MdmaItemCfg signal1_en;             // signaling target 1 enable
    MdmaItemCfg signal1_addr;           // signaling target 1 address
    MdmaItemCfg signal1_data;           // signaling target 1 data
    MdmaItemCfg op_static_inst_en;      // linear copy unit
    MdmaItemCfg op_static_inst;         // linear copy unit
    MdmaItemCfg op_ctx;                 // operation context id
    MdmaItemCfg op_priority;            // operation priority
    MdmaItemCfg op_fence;               // operation fence flag
    MdmaItemCfg op_awcache;             // operation write cacheable attribution
    MdmaItemCfg op_arcache;             // operation read cacheable attribution
    MdmaItemCfg id_mode;                // 0: dynamic id 1: static ID
    MdmaItemCfg static_id;              // static id
    MdmaItemCfg awuser_19_16;           // awuser_19_16
    MdmaItemCfg aruser_19_16;           // aruser_19_16
    MdmaItemCfg scratch;                // scratch
    MdmaItemCfg awuser_35_20;           // awuser_35_20
    MdmaItemCfg aruser_35_20;           // aruser_35_20
    // clang-format off
    std::string str(std::string tag = "") {  // debug
        std::stringstream info("");
        info << std::endl << tag << "|const-f " <<              dst_addr.str("dst_addr             "); // NOLINT
        info << std::endl << tag << "|const-f " <<                  size.str("size                 "); // NOLINT
        info << std::endl << tag << "|const-f " << constant_filling_data.str("constant_filling_data"); // NOLINT
        info << std::endl << tag << "|const-f " <<            signal0_en.str("signal0_en           "); // NOLINT
        info << std::endl << tag << "|const-f " <<          signal0_addr.str("signal0_addr         "); // NOLINT
        info << std::endl << tag << "|const-f " <<          signal0_data.str("signal0_data         "); // NOLINT
        info << std::endl << tag << "|const-f " <<            signal1_en.str("signal1_en           "); // NOLINT
        info << std::endl << tag << "|const-f " <<          signal1_addr.str("signal1_addr         "); // NOLINT
        info << std::endl << tag << "|const-f " <<          signal1_data.str("signal1_data         "); // NOLINT
        info << std::endl << tag << "|const-f " <<     op_static_inst_en.str("op_static_inst_en    "); // NOLINT
        info << std::endl << tag << "|const-f " <<        op_static_inst.str("op_static_inst       "); // NOLINT
        info << std::endl << tag << "|const-f " <<                op_ctx.str("op_ctx               "); // NOLINT
        info << std::endl << tag << "|const-f " <<           op_priority.str("op_priority          "); // NOLINT
        info << std::endl << tag << "|const-f " <<              op_fence.str("op_fence             "); // NOLINT
        info << std::endl << tag << "|const-f " <<            op_awcache.str("op_awcache           "); // NOLINT
        info << std::endl << tag << "|const-f " <<            op_arcache.str("op_arcache           "); // NOLINT
        info << std::endl << tag << "|const-f " <<               id_mode.str("id_mode              "); // NOLINT
        info << std::endl << tag << "|const-f " <<             static_id.str("static_id            "); // NOLINT
        info << std::endl << tag << "|const-f " <<          awuser_19_16.str("awuser_19_16         "); // NOLINT
        info << std::endl << tag << "|const-f " <<          aruser_19_16.str("aruser_19_16         "); // NOLINT
        info << std::endl << tag << "|const-f " <<               scratch.str("scratch              "); // NOLINT
        info << std::endl << tag << "|const-f " <<          awuser_35_20.str("awuser_35_20         "); // NOLINT
        info << std::endl << tag << "|const-f " <<          aruser_35_20.str("aruser_35_20         "); // NOLINT
        return info.str();
    }
    // clang-format on
} MdmaConstFillCfg;

typedef struct _MdmaScatterCfg {
    MdmaItemCfg desc_addr;          // descriptor addr to local memory
    MdmaItemCfg desc_size;          // descriptor size in byte
    MdmaItemCfg scatter_offset;     // scatter offset
    MdmaItemCfg resource_id;        // scatter resource id
    MdmaItemCfg signal0_en;         // signaling target 0 enable
    MdmaItemCfg signal0_addr;       // signaling target 0 address
    MdmaItemCfg signal0_data;       // signaling target 0 data
    MdmaItemCfg signal1_en;         // signaling target 1 enable
    MdmaItemCfg signal1_addr;       // signaling target 1 address
    MdmaItemCfg signal1_data;       // signaling target 1 data
    MdmaItemCfg op_static_inst_en;  // scatter unit
    MdmaItemCfg op_static_inst;     // scatter unit
    MdmaItemCfg op_ctx;             // operation context id
    MdmaItemCfg op_priority;        // operation priority
    MdmaItemCfg op_fence;           // operation fence flag
    MdmaItemCfg op_awcache;         // operation write cacheable attribution
    MdmaItemCfg op_arcache;         // operation read cacheable attribution
    MdmaItemCfg op_signal_mode;     // signaling target mode
    MdmaItemCfg awuser_19_16;       // awuser_19_16
    MdmaItemCfg aruser_19_16;       // aruser_19_16
    MdmaItemCfg scratch;            // scratch
    MdmaItemCfg awuser_35_20;       // awuser_35_20
    MdmaItemCfg aruser_35_20;       // aruser_35_20
    // clang-format off
    std::string str(std::string tag = "") {  // debug
        std::stringstream info("");
        info << std::endl << tag << "|scatter " <<         desc_addr.str("desc_addr        "); // NOLINT
        info << std::endl << tag << "|scatter " <<         desc_size.str("desc_size        "); // NOLINT
        info << std::endl << tag << "|scatter " <<    scatter_offset.str("scatter_offset   "); // NOLINT
        info << std::endl << tag << "|scatter " <<       resource_id.str("resource_id      "); // NOLINT
        info << std::endl << tag << "|scatter " <<        signal0_en.str("signal0_en       "); // NOLINT
        info << std::endl << tag << "|scatter " <<      signal0_addr.str("signal0_addr     "); // NOLINT
        info << std::endl << tag << "|scatter " <<      signal0_data.str("signal0_data     "); // NOLINT
        info << std::endl << tag << "|scatter " <<        signal1_en.str("signal1_en       "); // NOLINT
        info << std::endl << tag << "|scatter " <<      signal1_addr.str("signal1_addr     "); // NOLINT
        info << std::endl << tag << "|scatter " <<      signal1_data.str("signal1_data     "); // NOLINT
        info << std::endl << tag << "|scatter " << op_static_inst_en.str("op_static_inst_en"); // NOLINT
        info << std::endl << tag << "|scatter " <<    op_static_inst.str("op_static_inst   "); // NOLINT
        info << std::endl << tag << "|scatter " <<            op_ctx.str("op_ctx           "); // NOLINT
        info << std::endl << tag << "|scatter " <<       op_priority.str("op_priority      "); // NOLINT
        info << std::endl << tag << "|scatter " <<          op_fence.str("op_fence         "); // NOLINT
        info << std::endl << tag << "|scatter " <<        op_awcache.str("op_awcache       "); // NOLINT
        info << std::endl << tag << "|scatter " <<        op_arcache.str("op_arcache       "); // NOLINT
        info << std::endl << tag << "|scatter " <<    op_signal_mode.str("op_signal_mode   "); // NOLINT
        info << std::endl << tag << "|scatter " <<      awuser_19_16.str("awuser_19_16     "); // NOLINT
        info << std::endl << tag << "|scatter " <<      aruser_19_16.str("aruser_19_16     "); // NOLINT
        info << std::endl << tag << "|scatter " <<           scratch.str("scratch          "); // NOLINT
        info << std::endl << tag << "|scatter " <<      awuser_35_20.str("awuser_35_20     "); // NOLINT
        info << std::endl << tag << "|scatter " <<      aruser_35_20.str("aruser_35_20     "); // NOLINT
        return info.str();
    }
    // clang-format on
} MdmaScatterCfg;

typedef struct _MdmaScatterDerivedCfg {
    MdmaItemCfg desc_addr;          // template descriptor address
    MdmaItemCfg desc_size;          // template scatter descriptor size in byte
    MdmaItemCfg derived_desc_addr;  // derived descriptor addr to local memory
    MdmaItemCfg derived_desc_size;  // derived scatter descriptor size in byte
    MdmaItemCfg scatter_offset;     // scatter offset
    MdmaItemCfg resource_id;        // scatter resource id
    MdmaItemCfg signal0_en;         // signaling target 0 enable
    MdmaItemCfg signal0_addr;       // signaling target 0 address
    MdmaItemCfg signal0_data;       // signaling target 0 data
    MdmaItemCfg signal1_en;         // signaling target 1 enable
    MdmaItemCfg signal1_addr;       // signaling target 1 address
    MdmaItemCfg signal1_data;       // signaling target 1 data
    MdmaItemCfg op_static_inst_en;  // scatter unit
    MdmaItemCfg op_static_inst;     // scatter unit
    MdmaItemCfg op_ctx;             // operation context id
    MdmaItemCfg op_priority;        // operation priority
    MdmaItemCfg op_fence;           // operation fence flag
    MdmaItemCfg op_awcache;         // operation write cacheable attribution
    MdmaItemCfg op_arcache;         // operation read cacheable attribution
    MdmaItemCfg op_signal_mode;     // signaling target mode
    MdmaItemCfg awuser_19_16;       // awuser_19_16
    MdmaItemCfg aruser_19_16;       // aruser_19_16
    MdmaItemCfg scratch;            // scratch
    MdmaItemCfg awuser_35_20;       // awuser_35_20
    MdmaItemCfg aruser_35_20;       // aruser_35_20
    // clang-format off
    std::string str(std::string tag = "") {  // debug
        std::stringstream info("");
        info << std::endl << tag << "|scatter-d " <<         desc_addr.str("desc_addr        "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<         desc_size.str("desc_size        "); // NOLINT
        info << std::endl << tag << "|scatter-d " << derived_desc_addr.str("derived_desc_addr"); // NOLINT
        info << std::endl << tag << "|scatter-d " << derived_desc_size.str("derived_desc_size"); // NOLINT
        info << std::endl << tag << "|scatter-d " <<    scatter_offset.str("scatter_offset   "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<       resource_id.str("resource_id      "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<        signal0_en.str("signal0_en       "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<      signal0_addr.str("signal0_addr     "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<      signal0_data.str("signal0_data     "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<        signal1_en.str("signal1_en       "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<      signal1_addr.str("signal1_addr     "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<      signal1_data.str("signal1_data     "); // NOLINT
        info << std::endl << tag << "|scatter-d " << op_static_inst_en.str("op_static_inst_en"); // NOLINT
        info << std::endl << tag << "|scatter-d " <<    op_static_inst.str("op_static_inst   "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<            op_ctx.str("op_ctx           "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<       op_priority.str("op_priority      "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<          op_fence.str("op_fence         "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<        op_awcache.str("op_awcache       "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<        op_arcache.str("op_arcache       "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<    op_signal_mode.str("op_signal_mode   "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<      awuser_19_16.str("awuser_19_16     "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<      aruser_19_16.str("aruser_19_16     "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<           scratch.str("scratch          "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<      awuser_35_20.str("awuser_35_20     "); // NOLINT
        info << std::endl << tag << "|scatter-d " <<      aruser_35_20.str("aruser_35_20     "); // NOLINT
        return info.str();
    }
    // clang-format on
} MdmaScatterDerivedCfg;

typedef struct _MdmaGatherCfg {
    MdmaItemCfg desc_addr;          // descriptor addr to local memory
    MdmaItemCfg gather_offset;      // gather offset
    MdmaItemCfg dest_addr;          // gather result store address
    MdmaItemCfg signal0_en;         // signaling target 0 enable
    MdmaItemCfg signal0_addr;       // signaling target 0 address
    MdmaItemCfg signal0_data;       // signaling target 0 data
    MdmaItemCfg signal1_en;         // signaling target 1 enable
    MdmaItemCfg signal1_addr;       // signaling target 1 address
    MdmaItemCfg signal1_data;       // signaling target 1 data
    MdmaItemCfg op_static_inst_en;  // gather unit
    MdmaItemCfg op_static_inst;     // gather unit
    MdmaItemCfg op_ctx;             // operation context id
    MdmaItemCfg op_priority;        // operation priority
    MdmaItemCfg op_fence;           // operation fence flag
    MdmaItemCfg op_awcache;         // operation write cacheable attribution
    MdmaItemCfg op_arcache;         // operation read cacheable attribution
    MdmaItemCfg awuser_19_16;       // awuser_19_16
    MdmaItemCfg aruser_19_16;       // aruser_19_16
    MdmaItemCfg scratch;            // scratch
    MdmaItemCfg awuser_35_20;       // awuser_35_20
    MdmaItemCfg aruser_35_20;       // aruser_35_20
    // clang-format off
    std::string str(std::string tag = "") {  // debug
        std::stringstream info("");
        info << std::endl << tag << "|gather " <<         desc_addr.str("desc_addr    "); // NOLINT
        info << std::endl << tag << "|gather " <<     gather_offset.str("gather_offset"); // NOLINT
        info << std::endl << tag << "|gather " <<         dest_addr.str("dest_addr    "); // NOLINT
        info << std::endl << tag << "|gather " <<        signal0_en.str("signal0_en   "); // NOLINT
        info << std::endl << tag << "|gather " <<      signal0_addr.str("signal0_addr "); // NOLINT
        info << std::endl << tag << "|gather " <<      signal0_data.str("signal0_data "); // NOLINT
        info << std::endl << tag << "|gather " <<        signal1_en.str("signal1_en   "); // NOLINT
        info << std::endl << tag << "|gather " <<      signal1_addr.str("signal1_addr "); // NOLINT
        info << std::endl << tag << "|gather " <<      signal1_data.str("signal1_data "); // NOLINT
        info << std::endl << tag << "|gather " << op_static_inst_en.str("op_static_inst_en "); // NOLINT
        info << std::endl << tag << "|gather " <<    op_static_inst.str("op_static_inst "); // NOLINT
        info << std::endl << tag << "|gather " <<            op_ctx.str("op_ctx       "); // NOLINT
        info << std::endl << tag << "|gather " <<       op_priority.str("op_priority  "); // NOLINT
        info << std::endl << tag << "|gather " <<          op_fence.str("op_fence     "); // NOLINT
        info << std::endl << tag << "|gather " <<        op_awcache.str("op_awcache   "); // NOLINT
        info << std::endl << tag << "|gather " <<        op_arcache.str("op_arcache   "); // NOLINT
        info << std::endl << tag << "|gather " <<      awuser_19_16.str("awuser_19_16     "); // NOLINT
        info << std::endl << tag << "|gather " <<      aruser_19_16.str("aruser_19_16     "); // NOLINT
        info << std::endl << tag << "|gather " <<           scratch.str("scratch          "); // NOLINT
        info << std::endl << tag << "|gather " <<      awuser_35_20.str("awuser_35_20     "); // NOLINT
        info << std::endl << tag << "|gather " <<      aruser_35_20.str("aruser_35_20     "); // NOLINT
        return info.str();
    }
    // clang-format on
} MdmaGatherCfg;

typedef struct _MdmaPollingCfg {
    MdmaItemCfg desc_addr;          // descriptor addr to local memory
    MdmaItemCfg dest_addr;          // gather result store address
    MdmaItemCfg polling_interval;   // polling op interval
    MdmaItemCfg op_static_inst_en;  // polling unit
    MdmaItemCfg op_static_inst;     // polling unit
    MdmaItemCfg op_ctx;             // operation context id
    MdmaItemCfg op_priority;        // operation priority
    MdmaItemCfg op_fence;           // operation fence flag
    MdmaItemCfg op_awcache;         // operation write cacheable attribution
    MdmaItemCfg op_arcache;         // operation read cacheable attribution
    MdmaItemCfg awuser_19_16;       // awuser_19_16
    MdmaItemCfg aruser_19_16;       // aruser_19_16
    MdmaItemCfg scratch;            // scratch
    MdmaItemCfg awuser_35_20;       // awuser_35_20
    MdmaItemCfg aruser_35_20;       // aruser_35_20

    // clang-format off
    std::string str(std::string tag = "") {  // debug
        std::stringstream info("");
        info << std::endl << tag << "|polling " <<         desc_addr.str("desc_addr        "); // NOLINT
        info << std::endl << tag << "|polling " <<         dest_addr.str("dest_addr        "); // NOLINT
        info << std::endl << tag << "|polling " <<  polling_interval.str("polling_interval "); // NOLINT
        info << std::endl << tag << "|polling " << op_static_inst_en.str("op_static_inst_en"); // NOLINT
        info << std::endl << tag << "|polling " <<    op_static_inst.str("op_static_inst   "); // NOLINT
        info << std::endl << tag << "|polling " <<            op_ctx.str("op_ctx           "); // NOLINT
        info << std::endl << tag << "|polling " <<       op_priority.str("op_priority      "); // NOLINT
        info << std::endl << tag << "|polling " <<          op_fence.str("op_fence         "); // NOLINT
        info << std::endl << tag << "|polling " <<        op_awcache.str("op_awcache       "); // NOLINT
        info << std::endl << tag << "|polling " <<        op_arcache.str("op_arcache       "); // NOLINT
        info << std::endl << tag << "|polling " <<      awuser_19_16.str("awuser_19_16     "); // NOLINT
        info << std::endl << tag << "|polling " <<      aruser_19_16.str("aruser_19_16     "); // NOLINT
        info << std::endl << tag << "|polling " <<           scratch.str("scratch          "); // NOLINT
        info << std::endl << tag << "|polling " <<      awuser_35_20.str("awuser_35_20     "); // NOLINT
        info << std::endl << tag << "|polling " <<      aruser_35_20.str("aruser_35_20     "); // NOLINT
        return info.str();
    }
    // clang-format on
} MdmaPollingCfg;

typedef struct _MdmaCfg {
    MdmaOp_t              opt = MdmaOpInvalid;
    MdmaCommonCfg         cmn = {};
    MdmaLinearCopyCfg     lcp = {};
    MdmaConstFillCfg      cfl = {};
    MdmaScatterCfg        sct = {};
    MdmaGatherCfg         gat = {};
    MdmaPollingCfg        pol = {};
    MdmaScatterDerivedCfg scd = {};

    // clang-format off
    std::string str(std::string tag = "") {  // debug
        std::stringstream info("");
        info << std::endl << cmn.str(tag); // NOLINT
        info << std::endl << lcp.str(tag); // NOLINT
        info << std::endl << cfl.str(tag); // NOLINT
        info << std::endl << sct.str(tag); // NOLINT
        info << std::endl << gat.str(tag); // NOLINT
        info << std::endl << pol.str(tag); // NOLINT
        info << std::endl << scd.str(tag); // NOLINT
        return info.str();
    }
    // clang-format on
} MdmaCfg;

typedef struct _MdmaCommandPointer {
    uint32_t fence;       // fence flag
    uint32_t dependency;  // dependency flag
    uint32_t mcp;         // MDMA command buffer pointer
    uint32_t ctx;         // context id
    uint32_t priority;    // priority
    uint32_t asid;        // asid
} MdmaCommandPointer;

typedef struct _MdmaScatterTemplateInfo {
    uint64_t addr;      // scatter dst addr
    uint32_t data;      // scatter dst data
    bool     variable;  // data is variable, addr is a template
} MdmaScatterTemplateInfo;

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_MDMA_MDMA_DESC_H_
