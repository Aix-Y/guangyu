/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MDMA_MDMA_COMP_POLLING_H_
#define HARDWARE_INCLUDE_MDMA_MDMA_COMP_POLLING_H_

#include "hardware/include/mdma/mdma_comp.h"

namespace efvf {
namespace hardware {
namespace mdma {

class MdmaCPolling : public MdmaComp {
 public:
    explicit MdmaCPolling(Mdma *dma, MdmaEngineCompDesc_t &desc) : MdmaComp(dma, desc) {}
    virtual ~MdmaCPolling() {}
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MDMA_MDMA_COMP_POLLING_H_
