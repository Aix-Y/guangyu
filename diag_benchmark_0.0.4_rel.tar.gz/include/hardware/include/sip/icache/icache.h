/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file icache.h
    \brief define sip icache interface lib

    1. define IA access interfaces
    2. define get size interfaces
 */

#ifndef HARDWARE_INCLUDE_SIP_ICACHE_ICACHE_H_
#define HARDWARE_INCLUDE_SIP_ICACHE_ICACHE_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace icache {
struct ImemTag {
    uint32_t vld  = 0;
    uint32_t pnd  = 0;
    uint32_t lock = 0;
    uint32_t err  = 0;
    uint32_t tag  = 0;
    // add by libra
    uint32_t ras_err      = 0;
    uint32_t resp_err     = 0;
    uint32_t asid         = 0;
    uint32_t ksid         = 0;
    uint32_t virtual_tag  = 0;
    uint32_t imem_base_lo = 0;
    uint32_t imem_base_hi = 0;

    bool operator==(const ImemTag &ctag) const {
        if (vld != ctag.vld) {
            return false;
        }
        if (pnd != ctag.pnd) {
            return false;
        }
        if (lock != ctag.lock) {
            return false;
        }
        if (err != ctag.err) {
            return false;
        }
        if (tag != ctag.tag) {
            return false;
        }
        if (ras_err != ctag.ras_err) {
            return false;
        }
        if (resp_err != ctag.resp_err) {
            return false;
        }
        if (asid != ctag.asid) {
            return false;
        }
        if (ksid != ctag.ksid) {
            return false;
        }
        if (virtual_tag != ctag.virtual_tag) {
            return false;
        }
        if (imem_base_lo != ctag.imem_base_lo) {
            return false;
        }
        if (imem_base_hi != ctag.imem_base_hi) {
            return false;
        }
        return true;
    }

    bool operator!=(const ImemTag &ctag) const {
        if (vld != ctag.vld) {
            return true;
        }
        if (pnd != ctag.pnd) {
            return true;
        }
        if (lock != ctag.lock) {
            return true;
        }
        if (err != ctag.err) {
            return true;
        }
        if (tag != ctag.tag) {
            return true;
        }
        if (ras_err != ctag.ras_err) {
            return true;
        }
        if (resp_err != ctag.resp_err) {
            return true;
        }
        if (asid != ctag.asid) {
            return true;
        }
        if (ksid != ctag.ksid) {
            return true;
        }
        if (virtual_tag != ctag.virtual_tag) {
            return true;
        }
        if (imem_base_lo != ctag.imem_base_lo) {
            return true;
        }
        if (imem_base_hi != ctag.imem_base_hi) {
            return true;
        }
        return false;
    }
};

struct IcacheConfig {
    bool     cache_en          = false;
    bool     va_en             = false;
    bool     miss_fetch_en     = false;
    bool     dma_ins_en        = false;
    uint32_t imem_prefetch_blk = 0;
};

struct IcacheDfMstRasCtrl {
    uint32_t ecc_gen_en      = 0;
    uint32_t ecc_chk_en      = 0;
    uint32_t ecc_err_inject  = 0;
    uint32_t inj_en          = 0;
    uint32_t force_trigger   = 0;
    uint32_t err_cnt_clr     = 0;
    uint32_t inj_err_cnt_clr = 0;
    uint32_t ecc_err_sel     = 0;
    uint32_t ecc_err_inj_cnt = 0;
};

struct IcacheDfMstRasSts {
    uint32_t mst_err_gnt               = 0;
    uint32_t mst_single_err_inject_cnt = 0;
    uint32_t mst_multi_err_inject_cnt  = 0;
    uint32_t mst_err_inject_cnt        = 0;
};

struct IcacheAxiFieldCfg {
    uint32_t ar_qos = 0;
};

struct IcacheSramCtrl {
    uint32_t par_err_cnt;
    uint32_t ecc_err_cnt;
    uint32_t inj_type;
    uint32_t ecc_err_inject;
    uint32_t ecc_chk_en;
    uint32_t ecc_gen_en;
    uint32_t par_err_sel;
    uint32_t par_err_inject;
    uint32_t par_chk_en;
    uint32_t par_gen_en;
};

class Icache {
 public:
    virtual ~Icache() {}
    virtual void ConfigIcacheCtrl(const IcacheConfig &cfg) = 0;
    virtual void WriteImemTag(uint32_t idx, ImemTag data) = 0;
    virtual ImemTag ReadImemTag(uint32_t idx) = 0;

    // following interfaces are used for non-signoff features
    // virtual void SetIcacheScratchZero(uint32_t val) = 0;
    // virtual void SetMissRange(uint32_t id, uint32_t lo, uint32_t hi) = 0;
    // virtual void SetLinearVaHighBound(std::uint32_t addr) = 0;
    virtual uint32_t GetCacheLineSize() = 0;
    virtual void WriteScratch(uint32_t id, uint32_t data) {}
    virtual uint32_t ReadScratch(uint32_t id) {
        return 0xffff'ffffu;
    }
    virtual void SetDfMstRasCtrl(const IcacheDfMstRasCtrl &ctrl) {}
    virtual IcacheDfMstRasSts                              GetDfMstRasSts() {
        return {};
    }
    virtual void InvalidateTag() {}
    virtual void SetAxiFieldCfg(const IcacheAxiFieldCfg &axi_cfg) {}
    virtual void SetSramCtrl(const IcacheSramCtrl &sram_ctrl) {}
};
}  // namespace icache
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_ICACHE_ICACHE_H_
