/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SIP_XLCG_XLCG_H_
#define HARDWARE_INCLUDE_SIP_XLCG_XLCG_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace xlcg {

enum class BlcgModule {
    kXpu                 = 0,
    kXpuMalu             = 1,
    kXpuValu             = 2,
    kComCsr              = 3,
    kL1LinearPath        = 4,
    kL1ScatterGatherPath = 5,
    kL2L3Path            = 6,
    kAxiBridge           = 7,
};

struct SipBlcgCfg {
    uint32_t xpu0_disable              = 1;
    uint32_t xpu1_disable              = 1;
    uint32_t xpu0_malu_disable         = 1;
    uint32_t xpu0_valu_disable         = 1;
    uint32_t com_csr_disable           = 1;
    uint32_t l1_linear_disable         = 1;
    uint32_t l1_scatter_gather_disable = 1;
    uint32_t l2_l3_disable             = 1;
    uint32_t axi_bridge_disable        = 1;
};

class SipXlcg {
 public:
    virtual ~SipXlcg() {}
    virtual void EnableXlcg()                           = 0;
    virtual void DisableXlcg()                          = 0;
    virtual void EnableSipSaElcg()                      = 0;
    virtual void DisableSipSaElcg()                     = 0;
    virtual void SetSipBlcg(const SipBlcgCfg &blcg_cfg) = 0;
    virtual void EnableSipCoreBlcg(BlcgModule m, uint32_t xpu_id = 0) = 0;
    virtual void DisableSipCoreBlcg(BlcgModule m, uint32_t xpu_id = 0) = 0;
};
}  // namespace xlcg
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_XLCG_XLCG_H_
