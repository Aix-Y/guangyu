/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file sram.h
    \brief define sip sram interface lib

    1. define IA access interfaces
    2. define get size interfaces
 */

#ifndef HARDWARE_INCLUDE_SIP_SRAM_SRAM_H_
#define HARDWARE_INCLUDE_SIP_SRAM_SRAM_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {

namespace sram {

enum class SipSramType : uint32_t { kVdmem = 0, kSdmem = 1, kImem = 2, kVdmemMirror = 3 };

class SipSram {
 public:
    SipSram() = default;
    virtual ~SipSram() {}

    virtual void IndexRead(
        SipSramType type, uint32_t offset, uint32_t size, uint32_t *data) = 0;
    virtual void IndexWrite(
        SipSramType type, uint32_t offset, uint32_t size, uint32_t *data) = 0;
    virtual uint32_t SramSize(SipSramType sram_type)   = 0;
    virtual uint32_t SramOffset(SipSramType sram_type) = 0;
    virtual std::string Type2Name(SipSramType sram_type) {
        switch (sram_type) {
            case SipSramType::kImem:
                return "imem";
            case SipSramType::kSdmem:
                return "sdmem";
            case SipSramType::kVdmem:
                return "vdmem";
            case SipSramType::kVdmemMirror:
                return "vdmem_mirror";
            default:
                throw std::runtime_error("unknown sip sram type");
                // return "unknown";
        }
    }
};
}  // namespace sram
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_SRAM_SRAM_H_
