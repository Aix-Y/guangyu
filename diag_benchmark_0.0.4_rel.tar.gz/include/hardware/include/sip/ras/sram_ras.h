/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file sram_ras.h
    \brief define sip sram ras interface lib

    1. define IA access interfaces
    2. define get size interfaces
 */

#ifndef HARDWARE_INCLUDE_SIP_RAS_SRAM_RAS_H_
#define HARDWARE_INCLUDE_SIP_RAS_SRAM_RAS_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace ras {

enum class SipRasType : uint32_t {
    kVdram = 0,
    kSdram = 1,
    kIram  = 2,
    kVaram = 3,
    kNcbuf = 4,
    kLdq   = 5,
    kStq   = 6,
    // add from libra
    KSrTarram  = 7,
    KIvSmrram  = 8,
    KS3Instram = 9,
    KL0Iram    = 10,
};

enum class SipRasInjectType : uint32_t {
    kInjectCode        = 0,
    kInjectData        = 1,
    kInjectCodeAndData = 2,
};

class SipSramRas {
 public:
    SipSramRas() = default;
    virtual ~SipSramRas() {}
    virtual void SramRasInit()                                               = 0;
    virtual void SramRasReset()                                              = 0;
    virtual void EnableParityCheck()                                         = 0;
    virtual void EnableParityCheck(SipRasType type)                          = 0;
    virtual void EnableParityCheck(const std::vector<SipRasType> &type)      = 0;
    virtual void DisableParityCheck()                                        = 0;
    virtual void DisableParityCheck(SipRasType type)                         = 0;
    virtual void DisableParityCheck(const std::vector<SipRasType> &type)     = 0;
    virtual void EnableParityInjection()                                     = 0;
    virtual void EnableParityInjection(SipRasType type)                      = 0;
    virtual void EnableParityInjection(const std::vector<SipRasType> &type)  = 0;
    virtual void DisableParityInjection()                                    = 0;
    virtual void DisableParityInjection(SipRasType type)                     = 0;
    virtual void DisableParityInjection(const std::vector<SipRasType> &type) = 0;
    // add from libra
    virtual void EnableEccCheck() {}
    virtual void EnableEccCheck(SipRasType type) {}
    virtual void EnableEccCheck(const std::vector<SipRasType> &type) {}
    virtual void                                               DisableEccCheck() {}
    virtual void DisableEccCheck(SipRasType type) {}
    virtual void DisableEccCheck(const std::vector<SipRasType> &type) {}
    virtual void                                                EnableEccInjection() {}
    virtual void                                                EnableEccInjection(
        SipRasType type, SipRasInjectType inj_type = SipRasInjectType::kInjectCode) {}
    virtual void EnableEccInjection(const std::vector<SipRasType> &type) {}
    virtual void                                                   DisableEccInjection() {}
    virtual void DisableEccInjection(SipRasType type) {}
    virtual void DisableEccInjection(const std::vector<SipRasType> &type) {}
};
}  // namespace ras
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_RAS_SRAM_RAS_H_
