/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_PROFILER_PROFILER_H_
#define HARDWARE_INCLUDE_PROFILER_PROFILER_H_

#include <memory>
#include <set>
#include <string>
#include <vector>

#include "hardware/include/profiler/parser.h"

#include "framework/include/mem.h"
#include "hardware/include/hardware.h"

using efvf::framework::mem::Mem;

namespace efvf {
namespace hardware {
namespace profiler {

// when to move messages in ring buffer to system buffer
enum RingWorkMode {
    kPolling,   // polling periodically
    kInterupt,  // interrupt
    kStop,      // move all message at stop
};

//!
//! @brief struct to construct a profiler ring
//!
//! @param is_in_hbm: is ring in HBM or system memory. Default in system memory.
//! @param period_ms: period to move data from ring buffer to system memory.
//! @param base: ring buffer start address in HBM, only valid when ring buffer is in HBM.
//! @param size: ring buffer size, default 1M.
//! @param sys_buf_size: corresponding system buffer size for the ring. Data in ring buffer
//! will be moved to this buffer periodically.
//!
typedef struct _RingCfg {
    bool     is_in_hbm       = false;
    uint32_t period_ms       = 10;
    uint64_t base            = 0x4000000000;
    uint32_t size            = 0x100000;
    uint64_t sys_buffer_size = 0x400000;

    // Added in 4.0
    enum RingWorkMode mode = RingWorkMode::kPolling;
    // DPF_LOGBUFFER_CFG
    // uint8_t df_qos = 0;
    uint8_t df_osd = 16;
    // uint8_t enqueue_pri = 3;
    uint8_t  burst       = 0;  // 0 for 1 burst, or 128B
    uint32_t timeout_thd = 3;  // 7 for 131072 cycles
    uint8_t  vf_id       = 0xf;
    uint8_t  asid        = 0;
    uint16_t process_id  = 0;
    // DPF_LOGBUFFER_DUMMY
    uint32_t dummy_data = 0xfefefefe;
    // DPF_RING_CFG
    uint16_t ctx_mask   = 0xffff;  // no mask by default
    uint8_t  die_mask   = 0;       // no mask by default
    uint8_t  priority   = 3;       // ring priority
    uint8_t  watermark  = 7;       // 7 for 512B
    bool     ring_cover = false;   // no cover by default
    bool     pte_valid  = true;

    // DPF_RING_MASTER_MASK0-31
    std::vector<uint32_t> master_masks;  // no mask by default
    _RingCfg() : master_masks(32, 0xFFFFFFFF) {}
} RingCfg;

//!
//! @brief Profiler lib
//!
//! It is a wrapper of ProfilerRing
//!
class ProfilerRing;
class Profiler : public Hardware {
 public:
    Profiler(std::shared_ptr<spdlog::logger> logger, int num_rings);
    virtual ~Profiler() = default;

    ProfilerRing *ring(uint32_t id = 0) {
        LOG_ASSERT(id < rings_.size(), "Invalid ring id " + std::to_string(id) +
                                           ", which exceeds limit: " +
                                           std::to_string(rings_.size()));
        return rings_[id].get();
    }

    virtual ProfilerRing *profiling_ring() {
        return rings_[0].get();
    }
    virtual ProfilerRing *event_ring(uint8_t ring_id = 0) {
        return rings_[ring_id].get();
    }
    virtual ProfilerRing *log_buffer_ring() {
        LOG_ERROR("log buffer ring is not implemented!");
        return nullptr;
    }

    virtual bool CheckRasStatus() {
        return true;
    }

    virtual void ShowStatus() {}

    virtual void StartInterruptHandler() {
        LOG_ERROR("{} was not implemented!", __func__);
        throw;
    }
    virtual void StopInterruptHandler() {
        LOG_ERROR("{} was not implemented!", __func__);
        throw;
    }
    virtual void HandleInterrupt() {}
    virtual void SetUnDispatchInitId(const std::vector<uint16_t> &init_ids) {}
    virtual void StartSramParityInjection(uint16_t count = 1) {}
    virtual void                                   StopSramParityInjection() {}

 protected:
    std::vector<std::shared_ptr<ProfilerRing>> rings_;
    std::atomic<bool>                          exit_ = ATOMIC_VAR_INIT(false);
    std::shared_ptr<std::thread>               interrupt_handler_thread_;
};

//!
//! @brief ProfilerRing lib
//!
//! Each ProfilerRing instance
//!
class ProfilerRing {
 public:
    explicit ProfilerRing(Profiler *profiler, uint8_t ring_id = 0);
    virtual ~ProfilerRing() = default;

 public:
    //!
    //! @brief setup dpf
    //!
    void Setup(const RingCfg &cfg);

    //!
    //! @brief start dpf
    //!
    void Start();

    //!
    //! @brief stop dpf
    //!
    //! need flush before stop dpf
    //!
    void Stop();

    //!
    //! @brief flush events in fifo
    //!
    //! Events in profiler fifo will be moved to ring buffer when event number exceeds 16,
    //! so a flush is needed to make sure all valid events are moved to ring buffer before
    //! stopping profiler Flush is writing magic number by PCIe, and these flush events will be
    //! ignored during parsing
    //!

    virtual void FlushFifo() {}

    //!
    //! @brief return ring's cause register for source
    //!
    virtual uint32_t GetCauseAddr() {
        return 0;
    }

    //!
    //! @brief base function to move events from ring buffer to system memory
    //!
    bool MoveEventsToSystemBuffer();

    virtual void DeInit() {
        ring_buf_ = nullptr;
        sys_buf_  = nullptr;
    }

    virtual void MaskAllMaster() {}
    virtual void UnmaskAllMaster() {}

 public:
    //! accessors
    //!
    //! @brief get a pointer to parser for parsing received events
    //!
    Parser *parser() {
        return parser_.get();
    }

    Profiler *profiler() {
        return profiler_;
    }

    Mem *sys_buf() {
        return sys_buf_.get();
    }

    Mem *ring_buf() {
        return ring_buf_.get();
    }

    //!
    //! @brief system buffer(store events from ring buffer) size
    //!
    uint64_t GetSysBufferWritePtr() {
        return sys_buffer_write_ptr_;
    }

    uint8_t ring_id() const {
        return ring_id_;
    }

 protected:
    //!
    //! Reg read
    //!
    uint32_t RegRead(uint64_t offset) {
        return profiler_->RegRead(offset);
    }

    //!
    //! Reg write
    //!
    void RegWrite(uint64_t offset, uint32_t val) {
        profiler_->RegWrite(offset, val);
    }

 protected:
    //!
    //! @brief ring buffer base address
    //!
    uint64_t GetRingBufferBase() {
        return ring_buf_->GetDevAddr().at(0);
    }

    //!
    //! @brief ring buffer size
    //!
    uint32_t GetRingBufferSize() {
        return ring_buf_->GetSize();
    }

    //!
    //! @brief system buffer(store events from ring buffer) base address
    //!
    uint64_t GetSysBufferBase() {
        return sys_buf_->GetHostAddr();
    }

    //!
    //! @brief system buffer(store events from ring buffer) size
    //!
    uint64_t GetSysBufferSize() {
        return sys_buf_->GetSize();
    }

 private:
    //!
    //! @brief thread function to move events from ring buffer to system memory periodically
    //!
    void MoveEventsPeriodically();

    //!
    //! @brief allocate memory for dpf ring buffer
    //!
    void AllocateRingBuffer(
        bool in_hbm, uint64_t base, uint32_t size, bool valid = true, uint16_t asid = 0);

    //!
    //! @brief allocate system buffer to store events fetched from ring buffer
    //!
    void AllocateSystemBuffer(uint64_t size, uint16_t asid = 0);

    //!
    //! @brief setup profiler
    //!
    virtual void SetupHW(const RingCfg &cfg) = 0;

    //!
    //! @brief start profiler
    //!
    virtual void StartHW() = 0;

    //!
    //! @brief stop profiler
    //!
    virtual void StopHW() = 0;

    //!
    //! @brief get ring buffer write pointer and write wrap
    //!
    virtual void GetProducerStatus(uint32_t &wptr, bool &wwrap) = 0;

    //!
    //! @brief move events from ring buffer to system buffer
    //!
    virtual void Move(uint64_t ring_offset, uint64_t buf_offset, uint64_t size) = 0;

    //!
    //! @brief update read(consumer) pointer and read wrap
    //!
    virtual void Update(const uint32_t &rptr, const bool &rwrap) = 0;

 protected:
    std::shared_ptr<spdlog::logger> logger_;
    //!
    //! @brief smart pointer to parser
    //!
    std::shared_ptr<Parser> parser_;

    //!
    //! @brief ring buffer read pointer
    //!
    uint32_t rptr_ = 0;

    //!
    //! @brief ring buffer read wrap
    //!
    bool rwrap_ = false;

 private:
    //!
    //! @brief pointer to profiler, which inheritance from hardware
    //!
    Profiler *profiler_ = nullptr;

    //! period_ms_: the period to move data in ring buffer to system memory
    uint32_t period_ms_ = 10;

    //!
    //! @brief hbm or system memory for ring buffer
    //!
    std::unique_ptr<Mem> ring_buf_ = nullptr;

    //!
    //! @brief system memory for system buffer
    //!
    std::unique_ptr<Mem> sys_buf_ = nullptr;

    //!
    //! @brief system buffer write pointer
    //!
    uint64_t sys_buffer_write_ptr_ = 0;  // current write pointer

    //!
    //! @brief flag to indicate if moving thread exits
    //!
    bool flg_exit_thread_ = false;

    //!
    //! @brief thread for moving events from ring buffer to system buffer periodically
    //!
    std::unique_ptr<std::thread> thread_ = nullptr;

    //!
    //! @brief ring id
    //!
    uint8_t ring_id_ = 0;

    enum RingWorkMode mode_ = RingWorkMode::kPolling;

    friend class Parser;
    friend class Parser2D0;
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_PROFILER_PROFILER_H_
