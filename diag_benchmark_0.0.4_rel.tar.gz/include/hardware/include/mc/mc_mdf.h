/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MC_MC_MDF_H_
#define HARDWARE_INCLUDE_MC_MC_MDF_H_

#include <memory>
#include <string>
#include <vector>

#include "hardware/include/hardware.h"
#include "hardware/include/mc/mc_test.h"
#include "hardware/include/pmc.h"

namespace efvf {
namespace hardware {
namespace mc {

class Mdf : public Hardware {
 public:
    typedef enum {
        CHECK_REG = 0,
    } TaskId;

    typedef struct TaskParam { uint32_t addr; };

 public:
    Mdf() : Hardware() {}
    explicit Mdf(std::shared_ptr<spdlog::logger> logger);
    virtual ~Mdf() {}

 public:
    std::shared_ptr<IMcTest> GetTest() {
        return test_;
    }

 public:
    virtual std::string GetName(void);
    virtual bool        handle_tool_req(const std::string);
    virtual bool        handle_tool_req(const std::string, std::string);
    virtual bool handle_tool_req(const std::string req, std::string *p);
    virtual bool handle_tool_req(const std::string, uint64_t &);
    virtual bool handle_tool_req(const std::string, uint64_t, uint64_t &);
    virtual void print_info(const std::string = "");

 protected:
    std::shared_ptr<IMcTest> test_;
};

class MdfRas : public efvf::hardware::IRas {};

class MdfRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t edf0_aw_err_flag : 1;
    uint32_t edf0_ar_err_flag : 1;
    uint32_t edf1_aw_err_flag : 1;
    uint32_t edf1_ar_err_flag : 1;

    uint32_t : 28;

    uint64_t edf0_aw_err_addr;
    uint64_t edf0_ar_err_addr;
    uint64_t edf1_aw_err_addr;
    uint64_t edf1_ar_err_addr;

    MdfRasErrStat() {
        edf0_aw_err_flag = 0;
        edf0_ar_err_flag = 0;
        edf1_aw_err_flag = 0;
        edf1_ar_err_flag = 0;
        edf0_aw_err_addr = 0;
        edf0_ar_err_addr = 0;
        edf1_aw_err_addr = 0;
        edf1_ar_err_addr = 0;
    }
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_MC_MC_MDF_H_
