/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_MC_MC_TEST_H_
#define HARDWARE_INCLUDE_MC_MC_TEST_H_

#include <memory>
#include "framework/include/log.h"

namespace efvf {
namespace hardware {
namespace mc {
class IMcTest {
 public:
    virtual bool TestPmc() = 0;

 protected:
    std::shared_ptr<spdlog::logger> logger_;
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_MC_MC_TEST_H_
