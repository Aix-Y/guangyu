/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file mc_phy.h
    \brief define a mc phy lib
 */

#ifndef HARDWARE_INCLUDE_MC_MC_PHY_H_
#define HARDWARE_INCLUDE_MC_MC_PHY_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/mc/mc.h"

namespace efvf {
namespace hardware {
namespace mc {

/*!
 * @brief struct to init a mc phy lib
 */
typedef struct McPhyInit_ {
    std::shared_ptr<spdlog::logger> logger;
    void *                          mc;
} McPhyInit;

/*!
 * @brief McPhy lib
 */
class McPhy : public Hardware {
 public:
    /*!
     * @brief McPhy constructor
     */
    explicit McPhy(const McPhyInit &init);

    /*!
     * @brief desctructor
     */
    virtual ~McPhy();

 public:
    /*!
     * @brief print all the McPhy configuration
     */
    virtual void PrintAll(std::string &);

    /*!
     * @brief write phy reg
     */
    virtual void WritePhyReg(uint32_t addr, uint32_t val);

    /*!
     * @brief read phy reg
     */
    virtual uint32_t ReadPhyReg(uint32_t addr);

 protected:
    Hpd *    hpd_;
    uint64_t mc_top_base_addr_;
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MC_MC_PHY_H_
