/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_CACHE_CACHE_RAS_H_
#define HARDWARE_INCLUDE_CACHE_CACHE_RAS_H_
#include "hardware/include/abmp.h"
#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace cache {

typedef struct _ComRasStatus {
    bool     err        = false;
    uint32_t int_status = 0;
    uint32_t int_log    = 0;
} ComRasStatus;

class CacheRasCfg : public efvf::hardware::RasCfg {
 public:
    CacheRasCfg() {}
};

class CacheRasErrInj : public efvf::hardware::RasErrInj {
 public:
    uint32_t sram_parity_err_inj;
    uint32_t sram_parity_err_inj_sel_data;
    uint32_t sram_parity_err_inj_num;
    uint32_t sram_ecc_err_inj;
    uint32_t sram_ecc_err_inj_sel_code;
    uint32_t sram_ecc_err_inj_num;
    uint32_t err_inj_block_id;  // 0: LLC; 0x80: ASH

    uint32_t df_abmp_err_inj;
    uint32_t df_abmp_err_inj_sel_data;
    uint32_t df_abmp_err_inj_num;

    bool ash_sram_cecc;
    bool ash_sram_uecc;
    bool ash_sram_parity;
    bool sram_cecc;
    bool sram_uecc;
    bool dpw_sram_cecc, dpw_sram_uecc;
    bool dpr_sram_cecc, dpr_sram_uecc;

    bool tag_sram_parity;
    bool df_abmp_parity;

    CacheRasErrInj() {
        sram_parity_err_inj          = 0;
        sram_parity_err_inj_sel_data = 0;
        sram_ecc_err_inj             = 0;
        sram_ecc_err_inj_sel_code    = 0;
        sram_parity_err_inj_num      = 0;
        sram_ecc_err_inj_num         = 0;
        err_inj_block_id             = 0;

        df_abmp_err_inj          = 0;
        df_abmp_err_inj_sel_data = 0;
        df_abmp_err_inj_num      = 0;

        ash_sram_cecc   = false;
        ash_sram_uecc   = false;
        ash_sram_parity = false;
        sram_cecc       = false;
        sram_uecc       = false;
        dpw_sram_cecc   = false;
        dpw_sram_uecc   = false;
        dpr_sram_cecc   = false;
        dpr_sram_uecc   = false;
        tag_sram_parity = false;
        df_abmp_parity  = false;
    }
};

class CacheRasErrStat : public efvf::hardware::RasErrStat {
 public:
    //...
    bool     ash_err_;
    uint32_t err_inst_flg;
    uint32_t ash_uecc_err_int;
    uint32_t ash_cecc_err_int;
    uint32_t ash_inner_err_int;
    uint32_t ash_llc_bus_err_int;
    uint32_t ash_noc_bus_err_int;
    uint32_t ash_alu_err_int;
    uint32_t ash_ins_err_int;
    uint32_t ash_time_out_int;
    // llc
    // uint32_t df_mst_ambp_rderr_parity;
    // uint32_t df_mst_ambp_rderr_ruser;
    // uint32_t df_mst_ambp_rderr_rresp;
    uint32_t df_slv_absp_wrerr_parity;
    uint32_t cf_slv_absp_wrerr_parity;

    bool     sram_err_;
    uint32_t cecc_interrupt_status;
    uint32_t uecc_interrupt_status;
    uint32_t bank0_slice0_cecc_err_cnt;
    uint32_t bank0_slice1_cecc_err_cnt;
    uint32_t bank1_slice0_cecc_err_cnt;
    uint32_t bank1_slice1_cecc_err_cnt;
    uint32_t bank2_slice0_cecc_err_cnt;
    uint32_t bank2_slice1_cecc_err_cnt;
    uint32_t bank3_slice0_cecc_err_cnt;
    uint32_t bank3_slice1_cecc_err_cnt;
    uint32_t bank0_slice0_sram_err_addr;
    uint32_t bank0_slice1_sram_err_addr;
    uint32_t bank1_slice0_sram_err_addr;
    uint32_t bank1_slice1_sram_err_addr;
    uint32_t bank2_slice0_sram_err_addr;
    uint32_t bank2_slice1_sram_err_addr;
    uint32_t bank3_slice0_sram_err_addr;
    uint32_t bank3_slice1_sram_err_addr;

    bool     tag_sram_err_;
    uint32_t bc_ctrl_int_status;
    uint32_t bc_ctrl_int_log_grp0_0;
    uint32_t bc_ctrl_int_log_grp0_1;
    uint32_t bc_ctrl_int_log_grp0_2;
    uint32_t bc_ctrl_int_log_grp0_3;

    bool     dpw_sram_err_;
    uint32_t dpw_sram_cecc_cnt;
    uint32_t dpw_sram_cecc_log;
    uint32_t dpw_sram_cecc_intr;
    uint32_t dpw_sram_uecc_cnt;
    uint32_t dpw_sram_uecc_log;
    uint32_t dpw_sram_uecc_intr;

    bool     dpr_sram_err_;
    uint32_t dpr_sram_cecc_cnt;
    uint32_t dpr_sram_cecc_log;
    uint32_t dpr_sram_cecc_intr;
    uint32_t dpr_sram_uecc_cnt;
    uint32_t dpr_sram_uecc_log;
    uint32_t dpr_sram_uecc_intr;

    ComRasStatus priority;
    ComRasStatus both_prft_and_mtn_hint;
    ComRasStatus wr_prft_hint;
    ComRasStatus wr_prft_drop_by_fifo_full;
    ComRasStatus rd_prft_drop_by_fifo_full;
    ComRasStatus wr_prft_drop_by_mtn_flush;
    ComRasStatus rd_prft_drop_by_mtn_flush;
    ComRasStatus mtn_timeout;
    ComRasStatus mtn_cmd;
    ComRasStatus mtn_hint;
    ComRasStatus priority_max_way_cfg;
    ComRasStatus bc_dmem_init;

    efvf::hardware::abmp::AbmpRasErrStat df_abmp;

    CacheRasErrStat() {
        ash_err_            = false;
        is_err_             = false;
        err_inst_flg        = 0;
        ash_uecc_err_int    = 0;
        ash_cecc_err_int    = 0;
        ash_inner_err_int   = 0;
        ash_llc_bus_err_int = 0;
        ash_noc_bus_err_int = 0;
        ash_alu_err_int     = 0;
        ash_ins_err_int     = 0;
        ash_time_out_int    = 0;

        // df_mst_ambp_rderr_parity = 0;
        // df_mst_ambp_rderr_ruser  = 0;
        // df_mst_ambp_rderr_rresp  = 0;
        df_slv_absp_wrerr_parity = 0;
        cf_slv_absp_wrerr_parity = 0;

        sram_err_                  = false;
        cecc_interrupt_status      = 0;
        uecc_interrupt_status      = 0;
        bank0_slice0_cecc_err_cnt  = 0;
        bank0_slice1_cecc_err_cnt  = 0;
        bank1_slice0_cecc_err_cnt  = 0;
        bank1_slice1_cecc_err_cnt  = 0;
        bank2_slice0_cecc_err_cnt  = 0;
        bank2_slice1_cecc_err_cnt  = 0;
        bank3_slice0_cecc_err_cnt  = 0;
        bank3_slice1_cecc_err_cnt  = 0;
        bank0_slice0_sram_err_addr = 0;
        bank0_slice1_sram_err_addr = 0;
        bank1_slice0_sram_err_addr = 0;
        bank1_slice1_sram_err_addr = 0;
        bank2_slice0_sram_err_addr = 0;
        bank2_slice1_sram_err_addr = 0;
        bank3_slice0_sram_err_addr = 0;
        bank3_slice1_sram_err_addr = 0;

        tag_sram_err_          = false;
        bc_ctrl_int_status     = 0;
        bc_ctrl_int_log_grp0_0 = 0;
        bc_ctrl_int_log_grp0_1 = 0;
        bc_ctrl_int_log_grp0_2 = 0;
        bc_ctrl_int_log_grp0_3 = 0;

        dpw_sram_err_      = false;
        dpw_sram_cecc_cnt  = 0;
        dpw_sram_cecc_log  = 0;
        dpw_sram_cecc_intr = 0;
        dpw_sram_uecc_cnt  = 0;
        dpw_sram_uecc_log  = 0;
        dpw_sram_uecc_intr = 0;

        dpr_sram_err_      = false;
        dpr_sram_cecc_cnt  = 0;
        dpr_sram_cecc_log  = 0;
        dpr_sram_cecc_intr = 0;
        dpr_sram_uecc_cnt  = 0;
        dpr_sram_uecc_log  = 0;
        dpr_sram_uecc_intr = 0;
    }
};

class CacheIntrptCfg : public efvf::hardware::IntrptCfg {};

class CacheRas : public efvf::hardware::IRas {};

}  // namespace cache
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CACHE_CACHE_RAS_H_
