/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CACHE_CACHE_H_
#define HARDWARE_INCLUDE_CACHE_CACHE_H_

#include <memory>
#include <set>
#include <string>
#include "framework/include/log.h"
#include "hardware/include/atomic/ash.h"
#include "hardware/include/bpm.h"
#include "hardware/include/cache/cache_ctx.h"
#include "hardware/include/hardware.h"
#include "hardware/include/system_adapter.h"

using efvf::hardware::pmc::Bpm;
using efvf::hardware::system_adapter::SystemAdapter;
using efvf::hardware::atomic::Ash;

namespace efvf {
namespace hardware {
namespace cache {

class Cache : public Hardware {
 public:
    Cache();
    explicit Cache(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}
    virtual ~Cache() {}

    virtual CACHE_TYPE GetCacheType()       = 0;
    virtual uint16_t   GetDieId()           = 0;
    virtual uint32_t   GetCacheId()         = 0;
    virtual uint32_t   GetCacheSize()       = 0;
    virtual uint32_t   GetCacheSectorNum()  = 0;
    virtual uint32_t   GetCacheSectorSize() = 0;
    virtual uint32_t   GetCacheBankNum()    = 0;
    virtual uint32_t   GetCacheBankSize()   = 0;
    virtual uint32_t   GetCacheSetNum()     = 0;
    virtual uint32_t   GetCacheSetSize()    = 0;
    virtual uint32_t   GetCacheLineNum()    = 0;
    virtual uint32_t   GetCacheLineSize()   = 0;
    virtual uint32_t   GetBcNum()           = 0;
    virtual uint32_t   GetBcCoreNum()       = 0;
    virtual uint32_t   GetBcBankSize()      = 0;
    virtual uint32_t   GetCacheHitRatio()   = 0;
    virtual uint32_t   GetCacheSramSize()   = 0;
    virtual uint32_t   GetCacheMtnMaxOst()  = 0;
    virtual uint32_t   GetCacheMaxWayNum()  = 0;

    virtual bool IsBypassModeEnable()                             = 0;
    virtual bool IsBCHashModeEnable()                             = 0;
    virtual void ConfigBypassMode(const BYPASS_MODE &mode)        = 0;
    virtual void ConfigBCHashMode(const BC_HASH_MODE &mode)       = 0;
    virtual void ConfigBCHashAddr(const BcHashAddrCfg &cfg)       = 0;
    virtual void ConfigClockGating(const ClockGatingCfg &cfg)     = 0;
    virtual void ConfigCacheAttribute(const CacheAttribCfg &cfg)  = 0;
    virtual void ConfigCacheMaintenance(const CacheMtnCfg &cfg)   = 0;
    virtual void ConfigCachePriority(const CachePriorCfg &cfg)    = 0;
    virtual void ConfigCachePrefetch(const CachePrefetchCfg &cfg) = 0;
    virtual void EnableCacheRedunReplace(uint32_t replace_info)   = 0;
    virtual void DisableCacheRedunReplace()                       = 0;
    virtual void StartProfiler(bool clear = true)              = 0;
    virtual void StopProfiler()                                = 0;
    virtual void ClearProfiler()                               = 0;
    virtual void GetProfilerInfo(CacheProfilerInfo &prfl_info) = 0;
    virtual void PrintProfilerInfo(std::string vbose = "debug") = 0;
    virtual void PrintProfilerInfo(
        const CacheProfilerInfo &prfl_info, const std::string &vbose) = 0;
    virtual bool CheckProfilerInfo(
        const CacheProfilerInfo &prfl_actual, const CacheProfilerInfo &prfl_expt) = 0;

    virtual uint32_t GetCacheAttribVal(
        const AXI_CACHE_TYPE &ctype, const CACHE_ATTRIBUTE &attrib) = 0;
    virtual uint32_t GetCacheAttribVal(
        const AXI_CACHE_TYPE &ctype, const std::string &attrib_str) = 0;

    virtual SystemAdapter *GetSa()       = 0;
    virtual Bpm *GetBpm(uint8_t bpm_idx) = 0;
    virtual Ash *GetAsh()                = 0;

    virtual bool HandleToolReq(const std::string &req) = 0;
    virtual bool HandleToolReq(const std::string &req, uint64_t &val) = 0;
    virtual bool HandleToolReq(const std::string &req, bool val)      = 0;
    virtual bool HandleToolReq(const std::string &req, void *ptr)     = 0;
};

}  // namespace cache
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CACHE_CACHE_H_
