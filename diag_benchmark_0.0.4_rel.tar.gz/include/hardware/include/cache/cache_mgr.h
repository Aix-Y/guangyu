/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CACHE_CACHE_MGR_H_
#define HARDWARE_INCLUDE_CACHE_CACHE_MGR_H_

#include <memory>
#include <string>
#include <vector>

#include "hardware/include/atomic/ash_mgr.h"
#include "hardware/include/cache/cache.h"
#include "hardware/include/hardware.h"

using efvf::hardware::atomic::AshMgr;

namespace efvf {
namespace hardware {
namespace cache {

class CacheMgr {
 public:
    CacheMgr(std::shared_ptr<spdlog::logger> logger, const Dtu &dtu)
        : logger_(logger), cache_mgr_dtu_(dtu), cache_mgr_inited_(false) {}
    virtual ~CacheMgr() {}

 private:
    //  virtual bool HwInit() = 0;

 public:
    virtual bool Init() = 0;
    virtual void PrintCacheInfo(bool detail = false) = 0;
    virtual CACHE_TYPE GetCacheType()                = 0;
    virtual uint32_t   GetNumOfCacheInsts()          = 0;
    virtual uint32_t   GetNumOfAvailCacheInsts()     = 0;
    virtual uint32_t   GetMaskOfCacheInsts()         = 0;
    virtual Cache *    GetFirstAvailCacheInsts()     = 0;
    virtual Cache *GetCacheInst(uint32_t id)         = 0;
    virtual uint32_t GetCacheLineSize()              = 0;
    virtual uint32_t GetOneCacheSize()               = 0;
    virtual uint64_t GetTotalCacheSize()             = 0;

    virtual bool IsBypassModeEnable()                         = 0;
    virtual bool IsBCHashModeEnable()                         = 0;
    virtual void ConfigBypassMode(const BYPASS_MODE &mode)    = 0;
    virtual void ConfigBCHashMode(const BC_HASH_MODE &mode)   = 0;
    virtual void ConfigBCHashAddr(const BcHashAddrCfg &cfg)   = 0;
    virtual void ConfigClockGating(const ClockGatingCfg &cfg) = 0;

    virtual void ConfigCacheAttribute(const CacheAttribCfg &cfg) = 0;

    virtual void ConfigCacheMaintenance(const CacheMtnCfg &cfg)   = 0;
    virtual void ConfigCachePriority(const CachePriorCfg &cfg)    = 0;
    virtual void ConfigCachePrefetch(const CachePrefetchCfg &cfg) = 0;

    virtual void CacheCleanAll() = 0;
    virtual void CacheCleanByAddr(uint64_t addr, uint64_t size, uint64_t offset = 0) = 0;
    virtual void CacheInvalidateAll() = 0;
    virtual void CacheInvalidateByAddr(uint64_t addr, uint64_t size, uint64_t offset = 0) = 0;
    virtual void CacheFlushAll() = 0;
    virtual void CacheFlushByAddr(uint64_t addr, uint64_t size, uint64_t offset = 0) = 0;

    // virtual void CacheWritePrefetch(uint64_t addr, uint64_t size)      = 0;
    // virtual void ConfigCacheReadPrefetch(uint64_t addr, uint64_t size) = 0;

    virtual void EnableCacheRedunReplace(const std::vector<uint32_t> &replace_info_list) = 0;
    virtual void DisableCacheRedunReplace()                                              = 0;

    virtual void StartProfiler(bool clear = true)                       = 0;
    virtual void StopProfiler()                                         = 0;
    virtual void ClearProfiler()                                        = 0;
    virtual void GetProfilerInfo(CacheProfilerInfoList &prfl_info_list) = 0;
    virtual void PrintProfilerInfo(std::string vbose = "debug") = 0;
    virtual void PrintProfilerInfo(
        const CacheProfilerInfoList &prfl_info_list, std::string vbose = "debug") = 0;
    virtual bool CheckProfilerInfo(const CacheProfilerInfoList &prfl_actual_list,
        const CacheProfilerInfo &prfl_expt, std::bitset<32> *err_list = nullptr) = 0;
    virtual bool CheckProfilerInfo(const CacheProfilerInfoList &prfl_actual_list,
        const CacheProfilerInfoList &prfl_expt_list, std::bitset<32> *err_list = nullptr) = 0;

    virtual uint32_t GetCacheAttribVal(
        const AXI_CACHE_TYPE &ctype, const CACHE_ATTRIBUTE &attrib) = 0;
    virtual uint32_t GetCacheAttribVal(
        const AXI_CACHE_TYPE &ctype, const std::string &attrib_str) = 0;
    virtual uint32_t GetArCacheAttribVal(const std::string &attrib_str) = 0;
    virtual uint32_t GetAwCacheAttribVal(const std::string &attrib_str) = 0;

    virtual AshMgr *             GetAshMgr()                = 0;
    virtual std::vector<Cache *> GetCacheList() const       = 0;
    virtual void                 CachePrefetchOpt(uint32_t) = 0;
    virtual void PrintPrefetchOpt(uint32_t idx = -1ULL) = 0;
    virtual uint64_t GetPrefetchOptHashCode(uint32_t idx = -1ULL) = 0;

 protected:
    std::shared_ptr<spdlog::logger> logger_;
    const Dtu &                     cache_mgr_dtu_;

    bool cache_mgr_inited_;
};

}  // namespace cache
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_CACHE_CACHE_MGR_H_
