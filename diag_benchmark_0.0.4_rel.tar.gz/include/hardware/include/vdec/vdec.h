/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_VDEC_VDEC_H_
#define HARDWARE_INCLUDE_VDEC_VDEC_H_

#include <memory>
#include <string>
#include "framework/include/mem.h"
#include "hardware/include/hardware.h"

using efvf::framework::mem::Mem;

namespace efvf {
namespace hardware {
namespace vdec {

#define MAX_DECODER_NUM (2)

#undef VDEC_DEBUG_SHOW_FUNC
#define VDEC_DEBUG_SHOW_FUNC LOG_DEBUG("{}", __func__)

// FW MODE {{
#define VDEC_INTERNAL_BUFFER_LEN (1 << 28)  // 256 MB
#define VDEC_MAX_STREAM_NUM (32)
#define VDEC_MAX_PACKET_NUM (8)
#define VDEC_MAX_CTX_NUM (VDEC_MAX_STREAM_NUM * VDEC_MAX_PACKET_NUM)

#define VDEC_MCU_DEBUG_VERSION_REG VDEC_BLANK_REG100_OFFSET
#define VDEC_MCU_DEBUG_COMMIT_ID_REG VDEC_BLANK_REG101_OFFSET
#define VDEC_MCU_DEBUG_COMMIT_DATE_REG VDEC_BLANK_REG102_OFFSET
#define VDEC_MCU_DEBUG_ERROR_CODE_REG VDEC_BLANK_REG104_OFFSET

#define VDEC_RING_BUFFER_INIT_SIG_REG (VDEC_BLANK_REG103_OFFSET)
#define VDEC_RING_BUFFER_BASE_ADDR_LO_REG (VDEC_MCU_SCRATCH0_OFFSET)
#define VDEC_RING_BUFFER_BASE_ADDR_HI_REG (VDEC_MCU_SCRATCH1_OFFSET)
#define VDEC_RING_BUFFER_LENGTH_REG (VDEC_MCU_SCRATCH2_OFFSET)
#define VDEC_RING_BUFFER_WPTR_REG (VDEC_MCU_SCRATCH3_OFFSET)
#define VDEC_RING_BUFFER_RPTR_REG (VDEC_MCU_SCRATCH4_OFFSET)

#define VDEC_IB_ADDR_LO (VDEC_BLANK_REG220_OFFSET)
#define VDEC_IB_ADDR_HI (VDEC_BLANK_REG221_OFFSET)
#define VDEC_IB_SIZE (VDEC_BLANK_REG222_OFFSET)
#define VDEC_STATE_REG (VDEC_BLANK_REG103_OFFSET)

enum VDEC_STATE {
    // init
    VDEC_UNINIT = 0,
    VDEC_GO     = 1,
    // running
    VDEC_IB_NEW = 10,
    VDEC_IB_FIN,

    VDEC_WORKING,
    VDEC_IDLE,
    VDEC_SLEEPING,

    VDEC_ABNORMAL = 20,
};
// }}

enum VDEC_DECODER_ID { VDEC_DEC_ENG0 = 0, VDEC_DEC_ENG1, VDEC_DEC_ENG_MAX };
enum DECODE_TYPE { DECODE_TYPE_JPEG = 0, DECODE_TYPE_H264, DECODE_TYPE_H265, DECODE_TYPE_MAX };
enum VDEC_MODE {
    VDEC_MODE_REG = 0,  // Direct register mode
    VDEC_MODE_FW,       // FW mode
    VDEC_MODE_TOOL,     // efsmt load or dump fw
    VDEC_MODE_KMD,      // run with kmd
    VDEC_MODE_MAX
};

typedef struct VdecExeCtx {
#define VDEC_RESERVED_VG_MEM_LEN 1024  // DWORD
    uint32_t deocde_type;
    uint32_t deocde_task_number;
    uint32_t deocde_single_input_len;
    uint32_t deocde_input_buffer_addr_lo;
    uint32_t deocde_input_buffer_addr_hi;
    uint32_t deocde_input_buffer_len;
    uint32_t deocde_output_buffer_addr_lo;
    uint32_t deocde_output_buffer_addr_hi;
    uint32_t deocde_output_buffer_len;
    uint32_t internal_buffer_addr_table_lo;
    uint32_t internal_buffer_addr_table_hi;
    uint32_t internal_buffer_len;
    uint32_t decode_reserved_VG_mem[VDEC_RESERVED_VG_MEM_LEN];
    VdecExeCtx()
        : deocde_type(0),
          deocde_task_number(0),
          deocde_single_input_len(0),
          deocde_input_buffer_addr_lo(0),
          deocde_input_buffer_addr_hi(0),
          deocde_input_buffer_len(0),
          deocde_output_buffer_addr_lo(0),
          deocde_output_buffer_addr_hi(0),
          deocde_output_buffer_len(0),
          internal_buffer_addr_table_lo(0),
          internal_buffer_addr_table_hi(0),
          internal_buffer_len(0) {
        for (int i = 0; i < VDEC_RESERVED_VG_MEM_LEN; ++i) {
            decode_reserved_VG_mem[i] = 0;
        }
    }
} VdecExeCtx;

typedef struct VdecOutHeader {
#define HEADER_RESERVED_U32_NUM (27)
    uint32_t status;          // 1 -> OK. otherwise -> fail
    uint32_t height;          // JPEG decode output height
    uint32_t width;           // JPEG decode output width
    uint32_t channel;         // JPEG decode output channel
    uint32_t output_img_len;  // JPEG decode output length = height * width * channel (byte)
    uint32_t reserved[HEADER_RESERVED_U32_NUM];
    VdecOutHeader() : status(0), height(0), width(0), channel(0), output_img_len(0) {
        for (int i = 0; i < HEADER_RESERVED_U32_NUM; ++i) {
            reserved[i] = 0;
        }
    }
} VdecOutHeader;

typedef uint64_t VdecExecCtxId;

// FIXME: temp define here, must sync with packet_api.h
// {{

#define __executable_start__header 0x25000006

typedef struct executable_start_ {
    union {
        struct {
            uint32_t count : 8;
            uint32_t reserved_8_23 : 16;
            uint32_t type_id : 8;
        } header;
        uint32_t header_dw;
    };
    uint32_t packet_id;
    union {
        struct {
            uint32_t context_addr_lo : 24;
            uint32_t context_addr_hi : 8;
        } context_addr;
        uint32_t context_addr_dw;
    };
    union {
        struct {
            uint32_t context_length : 16;
            uint32_t reserved : 16;
        } context_dw_len;
        uint32_t context_dw_len_dw;
    };
    uint32_t executable_id;
    uint32_t ih_addr;
} executable_start;

// }}

class Vdec : public Hardware {
 public:
    Vdec() : Hardware() {}
    explicit Vdec(std::shared_ptr<spdlog::logger> logger);
    virtual ~Vdec();

    virtual VDEC_MODE GetRunMode() const = 0;
    virtual void SetRunMode(VDEC_MODE mode = VDEC_MODE_REG) = 0;

    virtual bool DecSoftResetReg(VDEC_DECODER_ID engine_id = VDEC_DEC_ENG0) = 0;
    virtual bool CheckInterruptReg()                                        = 0;
    virtual void ClearInterruptReg()                                        = 0;

    virtual bool StartDecByVcmdReg(uint64_t vcmd_addr, DECODE_TYPE dec_type,
        VDEC_DECODER_ID engine_id = VDEC_DEC_ENG0) = 0;

    virtual bool LoadFw(const std::string &iram_file, const std::string &dram_file,
        bool auto_cmp, bool auto_run) = 0;
    virtual void VdecMcuEnable(bool enable) = 0;
    // FW mode {{
    virtual void          DumpFwDebugInfo()            = 0;
    virtual uint32_t      GetFwInternalBufSize() const = 0;
    virtual uint64_t      GetFwInternalBufAddr() const = 0;
    virtual VdecExecCtxId WriteFwExecCtx(
        uint32_t ctx_idx, uint8_t *data, uint32_t data_size)                              = 0;
    virtual bool RunFwExecCtxPkt(VdecExecCtxId ctx_id, uint32_t pkt_id, uint32_t exec_id) = 0;
    // }}
};

#define DefineVdec(chip, class_name, ...)                                               \
    class class_name : public Vdec {                                                    \
     public:                                                                            \
        class_name() : Vdec() {}                                                        \
        explicit class_name(std::shared_ptr<spdlog::logger> logger);                    \
        virtual ~class_name();                                                          \
                                                                                        \
        virtual void SetRunMode(VDEC_MODE mode);                                        \
        virtual VDEC_MODE GetRunMode() const;                                           \
                                                                                        \
        virtual bool DecSoftResetReg(VDEC_DECODER_ID engine_id);                        \
        virtual bool CheckInterruptReg();                                               \
        virtual void ClearInterruptReg();                                               \
        virtual bool StartDecByVcmdReg(                                                 \
            uint64_t vcmd_addr, DECODE_TYPE dec_type, VDEC_DECODER_ID engine_id);       \
                                                                                        \
        virtual void VdecMcuEnable(bool enable);                                        \
        virtual bool LoadFw(const std::string &iram_file, const std::string &dram_file, \
            bool auto_cmp, bool auto_run);                                              \
                                                                                        \
        virtual void          DumpFwDebugInfo();                                        \
        virtual uint32_t      GetFwInternalBufSize() const;                             \
        virtual uint64_t      GetFwInternalBufAddr() const;                             \
        virtual VdecExecCtxId WriteFwExecCtx(                                           \
            uint32_t ctx_idx, uint8_t *data, uint32_t data_size);                       \
                                                                                        \
        virtual bool RunFwExecCtxPkt(                                                   \
            VdecExecCtxId ctx_id, uint32_t pkt_id, uint32_t exec_id);                   \
                                                                                        \
     private:                                                                           \
        virtual bool HwInit();                                                          \
        virtual bool HwDeinit();                                                        \
        void ShowHwInfo(Hardware *hw);                                                  \
                                                                                        \
        void VmcConfigReg();                                                            \
        void InitInterruptReg();                                                        \
        void EnableInterruptReg();                                                      \
        void DecoderRst(VDEC_DECODER_ID engine_id, bool enable);                        \
                                                                                        \
        void FwInternalBufSetup();                                                      \
                                                                                        \
        void     FwRingBufSetup();                                                      \
        uint32_t GetFwRingBufRdPtr();                                                   \
        void SetFwRingBufRdPtr(uint32_t rptr);                                          \
        uint32_t GetFwRingBufWrPtr();                                                   \
        void SetFwRingBufWrPtr(uint32_t wptr);                                          \
        uint32_t GetFwRingBufSize();                                                    \
        void SetFwRingBufSize(uint32_t dw_num);                                         \
        uint64_t GetFwRingBufBaseAddr();                                                \
        void SetFwRingBufBaseAddr(uint64_t ring_base_addr);                             \
        bool CheckFwRingBufStatus(uint32_t dw_num);                                     \
                                                                                        \
        bool FwAllocMemBuffer();                                                        \
        void FwFreeMemBuffer();                                                         \
                                                                                        \
        bool LoadFwToRam(const std::string &ram_file, bool to_iram, bool auto_cmp);     \
                                                                                        \
     private:                                                                           \
        VDEC_MODE m_mode;                                                               \
        bool      m_reload_fw;                                                          \
                                                                                        \
        const uint64_t TEST_INTERRUPT_ADDR = 0xC90054;                                  \
        const uint32_t TEST_INTERRUPT_DATA = 0x1234;                                    \
                                                                                        \
        std::shared_ptr<Mem> m_ring_buf_mem;                                            \
        std::shared_ptr<Mem> m_internal_mem;                                            \
        std::shared_ptr<Mem> m_exec_ctx_mem;                                            \
    }

}  // namespace vdec
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_VDEC_VDEC_H_
