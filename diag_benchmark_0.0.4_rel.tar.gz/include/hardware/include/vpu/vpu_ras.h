/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_VPU_VPU_RAS_H_
#define HARDWARE_INCLUDE_VPU_VPU_RAS_H_

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace vpu {

class VpuRasCfg : public efvf::hardware::RasCfg {
 public:
    uint32_t jdec_sram_parity_gen_en : 1;
    uint32_t jdec_sram_parity_check_en : 1;
    uint32_t vdec_sram_parity_gen_en : 1;
    uint32_t vdec_sram_parity_check_en : 1;
    uint32_t smem_parity_gen_en : 1;
    uint32_t smem_parity_check_en : 1;
    uint32_t mih_sram_parity_gen_en : 1;
    uint32_t mih_sram_parity_check_en : 1;
    uint32_t mmu_sram_parity_gen_en : 1;
    uint32_t mmu_sram_parity_check_en : 1;
    uint32_t vrdma_sram_parity_gen_en : 1;
    uint32_t vrdma_sram_parity_check_en : 1;
    uint32_t vwdma_sram_parity_gen_en : 1;
    uint32_t vwdma_sram_parity_check_en : 1;
    uint32_t cus_sram_parity_gen_en : 1;
    uint32_t cus_sram_parity_check_en : 1;
    uint32_t resize_sram_parity_gen_en : 1;
    uint32_t resize_sram_parity_check_en : 1;
    uint32_t padding0_sram_parity_gen_en : 1;
    uint32_t padding0_sram_parity_check_en : 1;
    uint32_t padding1_sram_parity_gen_en : 1;
    uint32_t padding1_sram_parity_check_en : 1;
    uint32_t cds_sram_parity_gen_en : 1;
    uint32_t cds_sram_parity_check_en : 1;
    uint32_t mdma_sram_parity_gen_en : 1;
    uint32_t mdma_sram_parity_check_en : 1;
    uint32_t : 6;

    VpuRasCfg() {
        jdec_sram_parity_gen_en       = 0;
        jdec_sram_parity_check_en     = 0;
        vdec_sram_parity_gen_en       = 0;
        vdec_sram_parity_check_en     = 0;
        smem_parity_gen_en            = 0;
        smem_parity_check_en          = 0;
        mih_sram_parity_gen_en        = 0;
        mih_sram_parity_check_en      = 0;
        mmu_sram_parity_gen_en        = 0;
        mmu_sram_parity_check_en      = 0;
        vrdma_sram_parity_gen_en      = 0;
        vrdma_sram_parity_check_en    = 0;
        vwdma_sram_parity_gen_en      = 0;
        vwdma_sram_parity_check_en    = 0;
        cus_sram_parity_gen_en        = 0;
        cus_sram_parity_check_en      = 0;
        resize_sram_parity_gen_en     = 0;
        resize_sram_parity_check_en   = 0;
        padding0_sram_parity_gen_en   = 0;
        padding0_sram_parity_check_en = 0;
        padding1_sram_parity_gen_en   = 0;
        padding1_sram_parity_check_en = 0;
        cds_sram_parity_gen_en        = 0;
        cds_sram_parity_check_en      = 0;
        mdma_sram_parity_gen_en       = 0;
        mdma_sram_parity_check_en     = 0;
    }
};

class VpuRasErrInj : public efvf::hardware::RasErrInj {
 public:
    uint32_t jdec_sram_parity_inj : 1;
    uint32_t vdec_sram_parity_inj : 1;
    uint32_t smem_parity_inj : 1;
    uint32_t mih_sram_parity_inj : 1;
    uint32_t mmu_sram_parity_inj : 1;
    uint32_t vrdma_sram_parity_inj : 1;
    uint32_t vwdma_sram_parity_inj : 1;
    uint32_t cus_sram_parity_inj : 1;
    uint32_t resize_sram_parity_inj : 1;
    uint32_t padding0_sram_parity_inj : 1;
    uint32_t padding1_sram_parity_inj : 1;
    uint32_t cds_sram_parity_inj : 1;
    uint32_t mdma_sram_parity_inj : 1;
    // uint32_t sram_evp_idx : 8;
    uint32_t sram_parity_err_inj_num : 8;
    uint32_t : 11;
    VpuRasErrInj() {
        jdec_sram_parity_inj     = 0;
        vdec_sram_parity_inj     = 0;
        smem_parity_inj          = 0;
        mih_sram_parity_inj      = 0;
        mmu_sram_parity_inj      = 0;
        vrdma_sram_parity_inj    = 0;
        vwdma_sram_parity_inj    = 0;
        cus_sram_parity_inj      = 0;
        resize_sram_parity_inj   = 0;
        padding0_sram_parity_inj = 0;
        padding1_sram_parity_inj = 0;
        cds_sram_parity_inj      = 0;
        mdma_sram_parity_inj     = 0;
        sram_parity_err_inj_num  = 1;
    }
};

class VpuRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t jdec_sram_parity_error[4];
    uint32_t vdec_sram_parity_error[4];
    uint32_t smem_parity_error[9];
    // uint32_t smem_parity_error_log[9];
    uint32_t mmu_sram_parity_error;
    uint32_t mih_sram_parity_error;
    uint32_t mdma_sram_parity_error;
    uint32_t mdma_sram_parity_error_log;
    // uint32_t mih_sram_parity_error_log;
    // 2 evp instance
    uint32_t vrdma_sram_parity_error[2];
    uint32_t vrdma_sram_parity_error_log[2];
    uint32_t vwdma_sram_parity_error[2];
    uint32_t vwdma_sram_parity_error_log[2];
    uint32_t cus_sram_parity_error[2];
    uint32_t cus_sram_parity_error_log[2];
    uint32_t resize_sram_parity_error[2];
    uint32_t resize_sram_parity_error_log[2];
    uint32_t padding0_sram_parity_error[2];
    uint32_t padding0_sram_parity_error_log[2];
    uint32_t padding1_sram_parity_error[2];
    uint32_t padding1_sram_parity_error_log[2];
    uint32_t cds_sram_parity_error[2];
    uint32_t cds_sram_parity_error_log[2];

    VpuRasErrStat() {
        for (uint32_t i = 0; i < 4; i++) {
            jdec_sram_parity_error[i] = 0;
            vdec_sram_parity_error[i] = 0;
        }

        for (uint32_t i = 0; i < 4; i++) {
            smem_parity_error[i] = 0;
        }

        mdma_sram_parity_error     = 0;
        mdma_sram_parity_error_log = 0;

        mmu_sram_parity_error = 0;
        mih_sram_parity_error = 0;

        // 2 evp instance
        for (uint32_t i = 0; i < 2; i++) {
            vrdma_sram_parity_error[i]        = 0;
            vrdma_sram_parity_error_log[i]    = 0;
            vwdma_sram_parity_error[i]        = 0;
            vwdma_sram_parity_error_log[i]    = 0;
            cus_sram_parity_error[i]          = 0;
            cus_sram_parity_error_log[i]      = 0;
            resize_sram_parity_error[i]       = 0;
            resize_sram_parity_error_log[i]   = 0;
            padding0_sram_parity_error[i]     = 0;
            padding0_sram_parity_error_log[i] = 0;
            padding1_sram_parity_error[i]     = 0;
            padding1_sram_parity_error_log[i] = 0;
            cds_sram_parity_error[i]          = 0;
            cds_sram_parity_error_log[i]      = 0;
        }
    }
};

class VpuIntrptCfg : public efvf::hardware::IntrptCfg {
 public:
};

class VpuIntrptStat : public efvf::hardware::IntrptStat {
 public:
};

class VpuRas : public efvf::hardware::IRas {};

}  // namespace vpu
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_VPU_VPU_RAS_H_
