/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file absp.h
    \brief define a common axi bus slave parity lib
 */

#ifndef HARDWARE_INCLUDE_ABSP_H_
#define HARDWARE_INCLUDE_ABSP_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace absp {

enum AbspRdParityInjectType { ErrorInParityBits = 0, ErrorInDataBits = 1 };

class AbspRasCfg : public RasCfg {
 public:
    uint32_t wr_parity_check_en : 1;
    uint32_t wr_parity_check_int_en : 1;
    uint32_t wr_parity_log_update_en : 1;
    uint32_t rd_parity_gen_en : 1;
    uint32_t : 28;

    AbspRasCfg() {
        wr_parity_check_en      = 0;
        wr_parity_check_int_en  = 0;
        wr_parity_log_update_en = 0;
        rd_parity_gen_en        = 0;
    }
};

class AbspRasErrStat : public RasErrStat {
 public:
    uint32_t wr_parity_err_status : 1;
    uint32_t wr_parity_log_done : 1;
    uint32_t wr_parity_log_reli : 1;
    uint32_t wr_cmd_data_mismatch : 1;
    uint32_t : 28;
    uint32_t awid;
    uint32_t awuser;
    uint64_t awaddr;
    uint32_t master_id;

    AbspRasErrStat() {
        wr_parity_err_status = 0;
        wr_parity_log_done   = 0;
        wr_parity_log_reli   = 0;
        wr_cmd_data_mismatch = 0;
        awid                 = 0;
        awuser               = 0;
        awaddr               = 0;
        master_id            = 0;
    }
};

class AbspRasErrInj : public RasErrInj {
 public:
    uint32_t rd_parity_err_inj : 1;
    uint32_t rd_parity_err_inj_sel_data : 1;
    uint32_t wr_parity_force_once : 1;
    uint32_t wr_parity_force_continue : 1;
    uint32_t : 28;
    uint32_t rd_parity_err_inj_num;

    AbspRasErrInj() {
        rd_parity_err_inj          = 0;
        rd_parity_err_inj_sel_data = 0;
        wr_parity_force_once       = 0;
        wr_parity_force_continue   = 0;
        rd_parity_err_inj_num      = 0;
    }
};

class AbspRas : public efvf::hardware::IRas {};

/*!
 * @brief Abspbase lib
 */
class Absp : public Hardware {
 public:
    /*!
     * @brief absp constructor
     */
    explicit Absp(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /*!
     * @brief desctructor
     */
    virtual ~Absp() {}

 public:
    /*!
     * @brief enable write parity check
     */
    virtual bool AbspWrParityCheckEnable(bool check_en) {
        return false;
    }

    /*!
     * @brief enable write parity check intrrrupt
     */
    virtual bool AbspWrParityCheckIntrEnable(bool int_en) {
        return false;
    }

    /*!
     * @brief enable write parity check log update
     */
    virtual bool AbspWrParityCheckLogUpdateEnable(bool log_en) {
        return false;
    }

    /*!
     * @brief get write parity check error status
     */
    virtual bool AbspGetWrParityErrStat(
        bool &err_stat, bool &log_done, bool &log_reli, bool &cmd_data_mismatch) {
        return false;
    }

    /*!
     * @brief get write parity check error log
     */
    virtual bool AbspGetWrParityErrLog(
        uint64_t &err_awaddr, uint32_t &err_awid, uint32_t &err_awuser) {
        return false;
    }

    /*!
     * @brief enable read parity generate
     */
    virtual bool AbspRdParityGenEnable(bool gen_en) {
        return false;
    }

    /*!
     * @brief read parity error injection
     */
    virtual bool AbspRdParityErrInject(AbspRdParityInjectType inj_type, uint16_t num) {
        return false;
    }

    /*!
     * @brief stop read parity error injection
     */
    virtual bool AbspStopRdParityErrInject(void) {
        return false;
    }

    /*!
     * @brief Get write parity eror injection count
     */
    virtual uint16_t AbspGetRdParityErrInJCnt(void) {
        return 0;
    }

    /*!
     * @brief Get write parity eror injection status
     */
    virtual uint16_t AbspGetRdParityErrInJStat(void) {
        return 0;
    }

    /*!
     * @brief get read/write parity cfg
     */
    virtual bool AbspGetRdWrParityCfg(RasCfg *cfg) {
        return false;
    }

    /*!
     * @brief clear error
     */
    virtual void AbspClearErrStat(void) {}

    /*!
     * @brief set wr parity force trig mode
     */
    virtual void AbspSetForceTrigMode(uint32_t) {}

    /*!
     * @brief set wr parity force trig mode
     */
    virtual void AbspSetForceTrigSig(uint32_t) {}

    /*!
     * @brief print all the absp information
     */
    virtual void PrintAll(std::string &) {}

 protected:
    std::shared_ptr<Hpd> hpd_;
};

}  // namespace absp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_ABSP_H_
