/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_XMC_XMC_H_
#define HARDWARE_INCLUDE_XMC_XMC_H_

#include <memory>
#include "hardware/include/hardware.h"
#include "hardware/include/xmc/xmc_ctx.h"

namespace efvf {
namespace hardware {
namespace xmc {
typedef struct _FirstAptCfgCtx {
    int      index;
    int      ctx_enable;
    int      ctx_id;
    int      ctx_host;
    uint64_t start_addr;
    uint64_t mem_size;
    uint64_t mapped_addr;
    bool     cache_overwrite = false;
    uint32_t cache_value     = 0;
} FirstAptCfgCtx;

typedef struct _SecondAptCfgCtx {
    int      index;
    uint64_t start_addr;
    int      no_cache;
    uint64_t mem_size;
    uint64_t mapped_addr;
    bool     qos_overwrite = false;
    uint32_t qos_value     = 0;
    int      ctx_id        = 0;
} SecondAptCfgCtx;

typedef struct _HashCfgCtx {
    int      index;
    uint64_t start_addr;
    int      clip_unit;
    int      hash_unit;
    int      hash_mode;
    int      hash_group;
    uint64_t mem_size;
    uint64_t mapped_addr;
} HashCfgCtx;

typedef struct _StrideCfgCtx {
    int      index;
    int      ctx_enable;
    int      ctx_id;
    int      ctx_host;
    int      ctx_num;
    uint64_t start_addr;
    uint64_t mem_size;
    uint64_t mapped_addr;
} StrideCfgCtx;

typedef struct _HashMaskCfg { uint32_t data[11]; } HashMaskCfg;

class Xmc : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    Xmc() : Hardware() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Xmc(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~Xmc() {}

    /**
     *  EFVS XMC interfaces
     */

    /**
     * @brief Set the Hash Mask
     *
     * @param mask Used to specify how many address bits are used for hash calculation.
     * @return true
     * @return false
     */
    virtual bool SetHashMask(uint32_t index, HashMaskCfg mask) {
        return false;
    }

    /**
     * @brief Set the Hash Mask
     *
     * @param index
     * @param mask
     * @return true
     * @return false
     */
    virtual bool SetHashMask(uint32_t index, LibraHashMask mask) {
        return false;
    }

    virtual void SetBasicAptCfg(const XmcAptCfg &ctx) {}

    /**
     * @brief Set the First Aperture config
     *
     * @param apt_index
     * @param ctx_enable
     * @param ctx_id
     * @param ctx_host
     * @param start_addr
     * @param mem_size 1MB for df path, 4KB for cf path
     * @param mapped_addr
     * @param cache_overwrite enable or disable the cache overwrite
     * @param cache_value only valid when cache overwrite enabled
     */
    virtual void SetFirstAptCfg(FirstAptCfgCtx ctx) {}

    /**
     * @brief Set the First aperture configuration.
     *
     * @param ctx
     */
    virtual void SetFirstAptCfg(const XmcAptCfg &ctx) {}

    /**
     * @brief Set the Second Aperture config
     *
     * @param apt_index
     * @param start_addr
     * @param no_cache enable or disable cache ignore
     * @param mem_size
     * @param mapped_addr
     * @param qos_overwrite enable or disable the qos overwrite
     * @param qos_value only valid when qos overwrite enabled
     * @param ctx_id
     */
    virtual void SetSecondAptCfg(SecondAptCfgCtx ctx) {}

    /**
     * @brief Set the Second Aperture Configuratiom
     *
     * @param ctx
     */
    virtual void SetSecondAptCfg(const XmcAptCfg &ctx) {}

    /**
     * @brief Set the Hash Cfg object
     *
     * @param apt_index
     * @param start_addr
     * @param clip_unit 0/1/2 -> no clip/128Bytes/512Bytes
     * @param hash_unit 0/1/2/3/4 -> no hash/128Bytes/256Bytes/512Bytes/4K Bytes
     * @param hash_mode 0/1/2/3 -> 4/8/16/32 CBF
     * @param hash_group 0/1 -> [0:4] or [5:9]
     * @param mem_size
     * @param mapped_addr
     */
    virtual void SetHashCfg(HashCfgCtx ctx) {}

    /**
     * @brief Set the Window Map object
     *
     * @param fault
     * @param default_addr
     * @param win_addr
     * @param win_size
     */
    virtual void SetWindowMap(
        int fault, uint64_t default_addr, uint64_t win_addr, uint64_t win_size) {}

    /**
     * @brief Set the Window Map
     *
     * @param ctx
     */
    virtual void SetWindowMap(const XmcAptCfg &ctx) {}

    /**
     * @brief Set the Stride Cfg object
     *
     * @param apt_index
     * @param ctx_enable enable or disable the context
     * @param ctx_id valid only if ctx_enable is 1
     * @param ctx_host valid only if ctx_enable is 1
     * @param ctx_num valid only if ctx_enable is 1
     * @param start_addr
     * @param mem_size
     * @param mapped_addr
     */
    virtual void SetStrideCfg(StrideCfgCtx ctx) {}

    /**
     * @brief Set the Stride Configuratiom
     *
     * @param ctx
     */
    virtual void SetStrideCfg(const XmcAptCfg &ctx) {}

    /**
     * @brief Set the Ctx Overwrite object
     *
     * @param overwrite
     * @param ctx_id
     * @param ctx_host
     */
    virtual void SetCtxOverwrite(int overwrite, int ctx_id, int ctx_host) {}

    /**
     * @brief      Enable AR/AW reorder bit.
     *
     * @param[in]  val   The new value
     */
    virtual void SetReorder(bool val) {}

    /**
     * @brief Set the Reorder
     *
     * @param ctx
     */
    virtual void SetReorder(const XmcAptCfg &ctx) {}

    /**
     * @brief      Set xmc ctrl enable value
     *
     * @param[in]  val   true for enable, false for disable
     */
    virtual void SetEnable(bool val) {}

    /**
     * @brief      Disable hash function which set hash unit to 0
     *
     */
    virtual void DisableHash() {}

    /**
     * @brief      Dump the xmc aperture info, ctrl value and window info.
     *
     */
    virtual void XmcDump() {}

    /**
     * @brief      Dump all the xmc info in the hardware tree.
     */
    virtual void DumpInfo() {}

    /**
     * @brief      Dumps an information table.
     */
    virtual void DumpInfoTable() {}

    /**
     * @brief Parsing fault information if it has.
     *
     */
    virtual void DumpFaultInfo() {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr       The address
     * @param[in]  cacheable  The cacheable
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint64_t VA2PA(uint64_t addr, bool cacheable, int ctx_id = -1) {
        return 0;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr       The address
     * @param[in]  cacheable  The cacheable
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint64_t PA2VA(uint64_t addr, bool cacheable, int ctx_id = -1) {
        return 0;
    }

    /**
     * @brief Translate IPA to PA in libra
     *
     * @param addr_in
     * @return uint64_t
     */
    virtual uint64_t IPA2PA(uint64_t addr_in) {
        return 0;
    }

    /**
     * @brief Translate L3 PA to IPA in libra
     *
     * @param addr_in
     * @return uint64_t
     */
    virtual uint64_t PA2IPA(uint64_t addr_in) {
        return 0;
    }

    /**
     * @brief Get second aperture config of given index.
     *
     * @param index apeture index
     * @return SecondAptCfgCtx
     */
    virtual SecondAptCfgCtx Get2ndAptCfg(int index) {
        SecondAptCfgCtx ctx = {};
        return ctx;
    }

    /**
     * @brief Set the Dynamic Qos of given aperture
     *
     * @param index apeture index
     * @param qos_value overwrite value
     */
    virtual void SetDynamicQos(bool enable, int index, uint32_t qos_value, int qos_ratio) {}

    /**
     * @brief
     *
     * @param index
     * @param addr_in
     * @param hash_mask
     * @param isReserved is the view PF reserved.
     * @return uint64_t
     */
    virtual uint64_t GetLLCHashAddr(int index, uint64_t addr_in, bool isReserved = true) {
        return 0;
    }

    /**
     * @brief Get the Dsm Hash Addr object
     *
     * @param index
     * @param addr_in
     * @param hash_mask
     * @return uint64_t
     */
    virtual uint64_t GetDsmHashAddr(int index, uint64_t addr_in) {
        return 0;
    }

    /**
     * @brief Get the Shadow Port Selec Addr
     *
     * @param index
     * @param addr_in
     * @return uint64_t
     */
    virtual uint64_t GetShadowPortSelecAddr(int index, uint64_t addr_in) {
        return 0;
    }

    virtual uint64_t GetDsmHarvest(uint64_t addr_in) {
        return 0;
    }
#if 0
    /**
     * @brief      { function_description }
     *
     * @param[in]  addr       The address
     * @param[in]  cacheable  The cacheable
     *
     * @return     { description_of_the_return_value }
     */
    virtual void DumpVA2PA(uint64_t addr, bool cacheable, int ctx_id = -1) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr       The address
     * @param[in]  cacheable  The cacheable
     *
     * @return     { description_of_the_return_value }
     */
    virtual void DumpPA2VA(uint64_t addr, bool cacheable, int ctx_id = -1) {}
#endif
};

}  // namespace xmc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_XMC_XMC_H_
