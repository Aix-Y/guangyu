/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_XMC_XMC_RAS_H_
#define HARDWARE_INCLUDE_XMC_XMC_RAS_H_
#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace xmc {
class XmcRasCfg : public efvf::hardware::RasCfg {
 public:
    uint32_t ecc_enc_enable = 0;
    uint32_t ecc_dec_enable = 0;
    uint32_t par_gen_en     = 0;
    uint32_t par_chk_en     = 0;
};

class XmcRasErrInj : public efvf::hardware::RasErrInj {
 public:
    uint32_t ecc_err_inject     = 0;
    uint32_t ecc_err_sel        = 0;
    uint32_t ecc_err_inject_cnt = 0;
    uint32_t par_err_inject     = 0;
    uint32_t par_err_sel        = 0;
    uint32_t par_err_inject_cnt = 0;
};

class XmcErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t rr_sram_stat    = 0;
    uint32_t rr_err_inj_done = 0;
    uint32_t wr_sram_stat    = 0;
    uint32_t wr_err_inj_done = 0;
    uint32_t fault_master_id = 0;  // STATUS[9:0]
    uint8_t  fault_ctx_host  = 0;  // STATUS[10]
    uint8_t  fault_ctx_id    = 0;  // STATUS[14:11]
    uint32_t fault_aw_ar_id  = 0;  // STATUS[27:15], AWID or ARID.
    uint8_t  fault_rw_flag   = 0;  // STATUS[28], 1 means write req, 0 means read req.
    uint8_t  fault_flag      = 0;  // STATUS[29], 1 means fault happened.
};

class XmcIntrptCfg : public efvf::hardware::IntrptCfg {
 public:
    uint32_t remap_fault_err_int_en_  = 0;
    uint32_t cross_4k_err_int_en_     = 0;
    uint32_t rr_sram_ecc1_err_int_en_ = 0;
    uint32_t rr_sram_ecc2_err_int_en_ = 0;
    uint32_t wr_sram_par_err_int_en_  = 0;
};

class XmcIntrptStat : public efvf::hardware::IntrptStat {
 public:
    uint32_t remap_fault_err_sts  = 0;
    uint32_t cross_4k_err_sts     = 0;
    uint32_t rr_sram_ecc1_err_sts = 0;
    uint32_t rr_sram_ecc2_err_sts = 0;
    uint32_t wr_sram_par_err_sts  = 0;

    bool IsClean() {
        if (GetIntrptVal() != 0)
            return false;
        return true;
    }

    bool FoundRemapFaultErr() {
        return remap_fault_err_sts == 1;
    }

    bool FoudnCross4kErr() {
        return cross_4k_err_sts == 1;
    }

    bool FoundRRSramEcc1Err() {
        return rr_sram_ecc1_err_sts == 1;
    }

    bool FoundRRSramEcc2Err() {
        return rr_sram_ecc2_err_sts == 1;
    }

    bool FoundWRSramParErr() {
        return wr_sram_par_err_sts == 1;
    }

    uint32_t GetIntrptVal() {
        return (remap_fault_err_sts << 0) | (cross_4k_err_sts << 1) |
               (rr_sram_ecc1_err_sts << 2) | (rr_sram_ecc2_err_sts << 3) |
               (wr_sram_par_err_sts << 4);
    }
};

class XmcRas : public efvf::hardware::IRas {};

}  //  namespace xmc
}  //  namespace hardware
}  //  namespace efvf

#endif  //  HARDWARE_INCLUDE_XMC_XMC_RAS_H_
