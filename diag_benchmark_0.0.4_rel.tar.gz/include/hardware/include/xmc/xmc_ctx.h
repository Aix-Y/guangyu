/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_XMC_XMC_CTX_H_
#define HARDWARE_INCLUDE_XMC_XMC_CTX_H_

#include <string>
#include <vector>

namespace efvf {
namespace hardware {
namespace xmc {

typedef struct _XmcAptCfgCtx {
    int      index = 0;
    uint64_t start_addr;
    uint64_t size;
    uint64_t mapped_val;
} XmcAptCfgCtx;

typedef struct _CtxIdCfg {
    int ctx_enable;
    int ctx_id;
    int ctx_host;
} CtxIdCfg;

typedef struct _CacheCfg {
    int      cache_overwrite = 0;
    uint32_t cache_value     = 0;
} CacheCfg;

typedef struct _HashCfg {
    int clip_unit;
    int hash_unit;
    int hash_mode;
    int hash_group;
    int shadow_mode;
} HashCfg;

typedef struct _QosCtrl {
    int      overwrite = 0;
    int      mode      = 0;
    uint32_t value     = 0;
    uint32_t ratio_nu  = 0;  // QoS_Ratio = (qos_ratio_nu+1) / (qos_ratio_de+1),
    uint32_t ratio_de  = 0;  // and qos_ratio_nu <= qos_ratio_de
} QosCtrl;

typedef struct _StrideCfg {
    int      ctx_enable = 0;
    int      ctx_id     = 0;
    int      ctx_host   = 0;
    int      ctx_num    = 0;
    uint64_t stride;
} StrideCfg;

typedef struct _ReorderCfg {
    int ar_map;
    int aw_map;
    int atomic_ignore;  // setting to 0 when access PCIE address segment only.
} ReorderCfg;

typedef struct _XmcAptCfg {
    int  apt_mode;
    bool auto_increase = false;

    bool     fault_enable = false;
    uint64_t fault_addr;
    uint64_t win_addr;
    uint64_t win_size;

    XmcAptCfgCtx basic         = {};
    bool         ctx_overwrite = false;
    int          ctx_id;
    int          ctx_host;

    CtxIdCfg   ctx_match = {};
    CacheCfg   cache     = {};
    HashCfg    hash      = {};
    ReorderCfg reorder   = {};
    QosCtrl    qos       = {};

    StrideCfg stride = {};
} XmcAptCfg;

typedef struct _LibraHashMask { uint32_t data[16]; } LibraHashMask;

}  // namespace xmc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_XMC_XMC_CTX_H_
