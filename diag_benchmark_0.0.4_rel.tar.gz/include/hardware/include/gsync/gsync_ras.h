/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_GSYNC_GSYNC_RAS_H_
#define HARDWARE_INCLUDE_GSYNC_GSYNC_RAS_H_

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace gsync {

class GsyncRasCfg : public efvf::hardware::RasCfg {};

class GsyncRasErrInj : public efvf::hardware::RasErrInj {
 public:
    uint32_t sram_par_gen_     = 0;
    uint32_t sram_par_check_   = 0;
    uint32_t sram_par_err_inj_ = 0;
    uint32_t parity_err_sel_   = 0;
    uint32_t parity_err_cnt_   = 0;
};

class GsyncRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t ras_log_ = 0;
};

class GsyncIntrptCfg : public efvf::hardware::IntrptCfg {
 public:
    uint8_t entry_vf_mismatch_en_       = 0;
    uint8_t tid_overflow_en_            = 0;
    uint8_t wait_cfg_under_overflow_en_ = 0;
    uint8_t wait_incr_overflow_en_      = 0;
    uint8_t cnt_overflow_en_            = 0;
};

class GsyncIntrptStat : public efvf::hardware::IntrptStat {
 public:
    uint32_t entry_vf_mismatch_sta_       = 0;
    uint32_t tid_overflow_sta_            = 0;
    uint32_t wait_cfg_under_overflow_sta_ = 0;
    uint32_t wait_incr_overflow_sta_      = 0;
    uint32_t cnt_overflow_sta_            = 0;
    uint8_t  sram_ras_sta_                = 0;

    bool IsClean() {
        if (GetExcpIrqValue() != 0 || GetMemIrqValue() != 0) {
            return false;
        }
        return true;
    }

    bool FoundVFMisMatch() {
        return entry_vf_mismatch_sta_ == 1;
    }

    bool FoundTidOverflow() {
        return tid_overflow_sta_ == 1;
    }

    bool FoundWaitCfgUnOverflow() {
        return wait_cfg_under_overflow_sta_ == 1;
    }

    bool FoundWaitIncrOverflow() {
        return wait_incr_overflow_sta_ == 1;
    }

    bool FoundCntOverflow() {
        return cnt_overflow_sta_ == 1;
    }

    bool FoundSramRasErr() {
        return sram_ras_sta_ == 1;
    }

    uint32_t GetExcpIrqValue() {
        return (entry_vf_mismatch_sta_ << 0) | (tid_overflow_sta_ << 1) |
               (wait_cfg_under_overflow_sta_ << 2) | (wait_incr_overflow_sta_ << 3) |
               (cnt_overflow_sta_ << 4);
    }

    uint32_t GetMemIrqValue() {
        return sram_ras_sta_;
    }
};

class GsyncRas : public efvf::hardware::IRas {};

}  // namespace gsync
}  // namespace hardware
}  // namespace efvf

#endif  //  HARDWARE_INCLUDE_GSYNC_GSYNC_RAS_H_
