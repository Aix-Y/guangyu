
/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_AP_AP_H_
#define HARDWARE_INCLUDE_AP_AP_H_
#include <memory>
#include <string>

#include "hardware/include/ap/ap_ras.h"
#include "hardware/include/hardware.h"
#include "hardware/include/ih.h"
#include "hardware/include/mailbox.h"
#include "hardware/include/mdma/mdma.h"
#include "hardware/include/system_adapter.h"

using efvf::hardware::ih::Ih;
using efvf::hardware::mailbox::Mailbox;
using efvf::hardware::mdma::Mdma;
using efvf::hardware::system_adapter::SystemAdapter;

namespace efvf {
namespace hardware {
namespace ap {

#define AP_DBG_SHOW_FUNC LOG_DEBUG("{}", __func__)

class Ap : public Hardware {
 public:
    Ap() : Hardware() {}
    explicit Ap(std::shared_ptr<spdlog::logger> logger);
    virtual ~Ap();

 public:
    virtual Ih *           GetMih()  = 0;
    virtual Mdma *         GetMdma() = 0;
    virtual SystemAdapter *GetSa()   = 0;
    // virtual Mailbox *GetMailbox(uint32_t inst = 0) = 0;
    virtual bool MailboxTest(uint32_t mb_inst, uint32_t mb_id, uint32_t uniq_id) = 0;
    virtual uint32_t MailboxErrTest(
        uint32_t mb_inst, uint32_t mb_id, uint32_t uniq_id, uint32_t type) = 0;

    virtual bool ApBlr() = 0;
    virtual bool SetSaAgent(uint32_t ctx_id, bool en) = 0;
    virtual bool GetShareMemAddr(uint32_t &cf_addr, uint32_t &cf_offset, uint32_t &size) = 0;

    virtual void SemResetLock(uint32_t id) = 0;
    virtual void SemSetCfg(uint32_t id, uint32_t credit) = 0;
    virtual bool SemGetLock(uint32_t id)     = 0;
    virtual bool SemReleaseLock(uint32_t id) = 0;
    virtual uint32_t SemCurCredit(uint32_t id, bool &is_ovfl) = 0;

    virtual bool TriggerTraceEvent(uint32_t event_type, uint32_t ctx_id, uint32_t proc_id) = 0;
    virtual bool SetAxuserCtrl(
        uint32_t type, uint32_t ctx_id, uint32_t user_id, bool overwrite) = 0;
    virtual bool RegAccessTest()                       = 0;
    virtual bool HandleToolReq(const std::string &req) = 0;
    virtual bool HandleToolReq(const std::string &req, uint64_t &in_out) = 0;

    virtual bool SetBusMonTimeout(uint32_t to) = 0;
    virtual uint32_t GetNocDbgSts()            = 0;
    virtual void     ClearPendingSts()         = 0;
};

}  // namespace ap
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_AP_AP_H_
