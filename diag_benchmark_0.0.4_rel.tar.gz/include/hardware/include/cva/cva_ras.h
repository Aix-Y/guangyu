/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_CVA_CVA_RAS_H_
#define HARDWARE_INCLUDE_CVA_CVA_RAS_H_

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace cva {

class CvaRasCfg : public efvf::hardware::RasCfg {
    // MIH, EFC, SMEM
 public:
    uint32_t vam_smem_parity_gen_en : 1;
    uint32_t vam_smem_parity_check_en : 1;
    uint32_t mih_sram_parity_gen_en : 1;
    uint32_t mih_sram_parity_check_en : 1;
    uint32_t efc_sram_parity_gen_en : 1;
    uint32_t efc_sram_parity_check_en : 1;
    uint32_t : 26;
    CvaRasCfg() {
        vam_smem_parity_gen_en   = 0;
        vam_smem_parity_check_en = 0;
        mih_sram_parity_gen_en   = 0;
        mih_sram_parity_check_en = 0;
        efc_sram_parity_gen_en   = 0;
        efc_sram_parity_check_en = 0;
    }
};

class CvaRasErrInj : public efvf::hardware::RasErrInj {
 public:
    uint32_t vam_smem_parity_inj : 1;
    uint32_t mih_sram_parity_inj : 1;
    uint32_t efc_sram_parity_inj : 1;
    uint32_t : 13;
    uint32_t parity_err_inj_num : 16;
    uint32_t efc_sram_idx;
    CvaRasErrInj() {
        vam_smem_parity_inj = 0;
        mih_sram_parity_inj = 0;
        efc_sram_parity_inj = 0;
        parity_err_inj_num  = 1;
        efc_sram_idx        = 0;
    }
};

class CvaRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t vam_smem_parity_error;
    uint32_t mih_sram_parity_error;
    uint32_t efc_sram_parity_error[MAX_EFC_INST];
    // uint32_t efc_sram_parity_fifo_error[MAX_EFC_INST];

    uint32_t vam_smem_parity_error_log;
    uint32_t efc_sram_parity_error_log[MAX_EFC_INST];  // 0:15 - irq addr, 16:19 - num
    uint32_t efc_sram_parity_error_vcache_addr[MAX_EFC_INST][8];
    CvaRasErrStat() {
        vam_smem_parity_error = 0;
        mih_sram_parity_error = 0;
        // efc_sram_parity_fifo_error       = 0;
        vam_smem_parity_error_log = 0;
        // efc_sram_parity_error_vcache_log = 0;
        for (uint32_t inst = 0; inst < MAX_EFC_INST; inst++) {
            efc_sram_parity_error[inst]     = 0;
            efc_sram_parity_error_log[inst] = 0;
            for (uint32_t i = 0; i < 8; i++) {
                efc_sram_parity_error_vcache_addr[inst][i] = 0;
            }
        }
    }
};

class CvaIntrptCfg : public efvf::hardware::IntrptCfg {
 public:
};

class CvaIntrptStat : public efvf::hardware::IntrptStat {
 public:
};

class CvaRas : public efvf::hardware::IRas {};

}  // namespace cva
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CVA_CVA_RAS_H_
