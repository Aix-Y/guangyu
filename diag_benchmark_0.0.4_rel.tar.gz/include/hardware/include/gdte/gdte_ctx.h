/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_GDTE_GDTE_CTX_H_
#define HARDWARE_INCLUDE_GDTE_GDTE_CTX_H_

#include <stdint.h>
#include <memory>
#include <string>
#include <vector>
#include "framework/include/mem.h"

using efvf::framework::mem::Mem;
using efvf::framework::mem::MemType;

namespace efvf {
namespace hardware {
namespace gdte {

typedef struct _DvfsResult {
    uint32_t dte_thd_busy[4] = {
        0,
    };
    uint32_t dte_to_L2_throughput[4] = {
        0,
    };
    uint32_t dte_to_L3_throughput[4] = {
        0,
    };
    uint32_t dte_read_throughput      = 0;
    uint32_t dte_write_throughput     = 0;
    uint32_t dte_to_l1_efficiency     = 0;
    uint32_t dte_to_non_l1_efficiency = 0;
    uint32_t dte_to_l1_stall          = 0;
    uint32_t dte_to_non_l1_stall      = 0;
} DvfsResult;

typedef enum _HSDC_TYPE {
    HSDC_NONE = 0,
    HSDC_RAW2RAW,
    HSDC_RAW2SCP,
    HSDC_RAW2GSCP,
    HSDC_RAW2GSCPC,
} HSDC_TYPE;

typedef struct _HsdcScpDesc { uint32_t raw_size; } HsdcScpDesc;

typedef struct _HsdcGscpDesc {
    uint32_t                 min_scp = 0xFFFFFFFF;
    uint32_t                 max_scp = 0;
    std::vector<HsdcScpDesc> scp;
} HsdcGscpDesc;

typedef struct _HsdcGscpcDesc {
    uint32_t                  min_gscp = 0xFFFFFFFF;
    uint32_t                  max_gscp = 0;
    std::vector<HsdcGscpDesc> gscp;
} HsdcGscpcDesc;

typedef struct _HsdcPkt {
    HSDC_TYPE     hsdc_type       = HSDC_RAW2SCP;
    uint32_t      raw_size        = 0;
    uint8_t *     raw_data        = nullptr;
    uint32_t      compressed_size = 0;
    uint8_t *     compressed_data = nullptr;
    uint32_t      min_gscpc       = 0xFFFFFFFF;
    HsdcGscpcDesc desc;
} HsdcPkt;

typedef enum _DteOpType {
    LinearCopy,
    Sync,
    GSync,
    DataShrink,
    DataExpand,
    ConstantFilling,
    TilingPadding4D,
    TilingReshape4D,
    TilingBroadcasting4D,
    TilingSlice4D,
    TilingDeSlice4D,
    TilingSubSampling2DHW,
    TilingMirrorLeftRight2DHW,
    TilingMirrorTopBottom2DHW,
    HSDC,
    SlicePadding,
    SliceDeslice,
    SliceExpand,
    HorizontalMirrorDeslice,
    VerticalMirrorDeslice,
    HorizontalMirrorPadding,
    VerticalMirrorPadding,
    ConstantfillingDeslice,
    Slicereshape,
    ReshapeDeslice,
    ShrinkDeslice,
    SliceBroadcasting,
    InvalidOpType,
} DteOpType;

typedef struct _DteBurstLen {
    uint32_t rbl;
    uint32_t wbl;
} DteBurstLen;

typedef struct _DataShrinkExpand {
    uint32_t phase;
    uint32_t ratio;
} DataShrinkExpand;

typedef struct _DataPadding {
    uint32_t dim_pad[4][3];  // low, interior, high
    uint32_t value;
} DataPadding;

typedef struct _DataReshape {
    uint32_t dim_map[5];
    bool     enhance_mode = true;
} DataReshape;

typedef struct _DataBrdcst {
    uint32_t brdcst_dim;
    uint32_t brdcst_size;
} DataBrdcst;

typedef struct _DataSlice {
    int      off[5];
    uint32_t dim_size[5];
    uint32_t pad_val;
} DataSlice;

typedef struct _DataDeslice { int off[5]; } DataDeslice;

typedef struct _DataSubSample { uint32_t row_stride; } DataSubSample;

typedef struct _DataSlicePad {
    int      slc_off[5];
    uint32_t slc_size[5];
    uint32_t pad_val;
    uint32_t dim_pad[4][3];  // low, interior, high
} DataSlicePad;

typedef struct _DataSliceDeSlice {
    int      slc_off[5];
    uint32_t slc_size[5];
    int      dsl_off[5];
} DataSliceDeSlice;

typedef struct _DataSliceExpand {
    int      slc_off[5];
    uint32_t slc_size[5];
    uint32_t phase;
    uint32_t ratio;
} DataSliceExpand;

typedef struct _DataHSDC {
    uint32_t src_pkt_type;
    uint32_t dst_pkt_type;
    uint32_t parms_sel;
    uint32_t cmp_size;
} DataHSDC;

typedef struct _DataHMirDsl { int dsl_off[5]; } DataHMirDsl;

typedef struct _DataVMirDsl { int dsl_off[5]; } DataVMirDsl;

typedef struct _DataHMirPad {
    uint32_t pad_val;
    uint32_t dim_pad[4][3];  // low, interior, high
} DataHMirPad;

typedef struct _DataVMirPad {
    uint32_t pad_val;
    uint32_t dim_pad[4][3];  // low, interior, high
} DataVMirPad;

typedef struct _DataCFDsl { int dsl_off[5]; } DataCFDsl;

typedef struct _DataSliceRshp {
    uint32_t slc_off[5];
    uint32_t slc_size[5];
    uint32_t dim_map[5];
    uint32_t pad_val = 0x55555555;
} DataSliceRshp;

typedef struct _DataRshpDeslice {
    int      dsl_off[5];
    uint32_t dim_map[5];
} DataRshpDeslice;

typedef struct _DataShkDeslice {
    int      dsl_off[5];
    uint32_t phase;
    uint32_t ratio;
} DataShkDeslice;

typedef struct _DataSlcBrdcst {
    uint32_t slc_off[5];
    uint32_t slc_size[5];
    uint32_t brdcst_dim;
    uint32_t brdcst_size;
} DataSlcBrdcst;

typedef struct _DteGSync {
    uint32_t gsync_mode;
    uint32_t entry_idx;
    uint32_t slv_base_addr_sel;
    uint64_t wait_entry_data;
    uint32_t wait_entry_addr;
    uint32_t wait_entry_wait;
    uint32_t wait_entry_mode;
    uint32_t wait_entry_tid;
    uint32_t signal_info;
    uint32_t signal_idx;
} DteGSync;

typedef struct _MbxCtrl {
    uint32_t dst_mbx_sel               = 0;
    uint32_t dst_mbx_ref_clean_disable = 1;
    uint32_t dst_mbx_wait_disable      = 1;
    uint32_t src_mbx_sel               = 0;
    uint32_t src_mbx_ref_clean_disable = 1;
    uint32_t src_mbx_wait_disable      = 1;
} MbxCtrl;

typedef struct _QosCtrl {
    uint32_t qos_noc_inc_interval = 0;
    uint32_t qos_arb_inc_interval = 0;
    uint32_t qos_noc_inc_enable   = 0;
    uint32_t qos_arb_inc_enable   = 0;
    uint32_t qos_noc_initial      = 0;
    uint32_t qos_arb_initial      = 0;
    uint32_t arb_dynamic_queue_id = 0;
} QosCtrl;

typedef struct _DataSig {
    uint32_t src_addr    = 0;
    uint32_t src_disable = 1;
    uint32_t src_data    = 0;
    uint32_t dst_addr    = 0;
    uint32_t dst_disable = 1;
    uint32_t dst_data    = 0;
    uint32_t mng_addr    = 0;
    uint32_t mng_disable = 1;
    uint32_t mng_data    = 0;
} DataSig;

typedef struct _CacheCfgExt {
    uint32_t cache_work_mode  = 0;
    uint32_t hw_prefetch_hint = 0;
    uint32_t hit_ratio        = 0xf;
    uint32_t cache_priority1  = 0;
    uint32_t cache_priority0  = 0;
} CacheCfgExt;

typedef struct _CacheCfg {
    uint32_t    arcache = 0;
    uint32_t    awcache = 0;
    CacheCfgExt rd_cfg  = {};
    CacheCfgExt wr_cfg  = {};
} CacheCfg;

typedef struct _AxiCfg {
    // by default, data, non-secure, unpriviledged access
    uint32_t awport = 2;
    uint32_t arport = 2;
    // uint32_t arcache = 0;
    // uint32_t awcache = 0;
} AxiCfg;

typedef struct _ASIDCfg {
    uint32_t asid    = 0;
    uint32_t wr_asid = 0;
    uint32_t rd_asid = 0;
    // AxiCfg   axi_cfg = {};
} ASIDCfg;

typedef struct _HitRatioCfg {
    uint32_t blk_size = 0;
    uint32_t enable   = 0;
    uint32_t hash_mask[4];
} HitRatioCfg;

typedef struct _AtomicCfg {
    uint32_t awatop    = 0;
    uint32_t be_mode   = 0;
    uint32_t data_type = 0;
    uint32_t vec_flag  = 0;
    uint32_t cas_flag  = 0;
} AtomicCfg;

typedef struct _EslCtrlCfg {
    int rd_ctrl = 0;
    int wr_ctrl = 0;
} EslCtrlCfg;

typedef struct _DecryptCtrl {
    uint32_t integrity_on      = 0;
    uint32_t block_size        = 0;
    uint32_t decrypt_on        = 0;
    uint64_t block_start_index = 0;
    uint32_t block_index_step  = 1;
} DecryptCtrl;

typedef struct _DebugMiscCfg {
    int prof_dte_busy_end_event_en   = -1;
    int prof_dte_busy_start_event_en = -1;
    int prof_cmd_trans_done_event_en = -1;
    int prof_cmd_start_event_en      = -1;
    int prof_push_thd_event_en       = -1;
    int prof_en                      = -1;
    int sel                          = -1;
    int err_stop_exe_en              = -1;
    int customized_trace_msg_en      = -1;
} DebugMiscCfg;

typedef struct _L2LossCfg {
    int         l2lc_en        = 0;
    std::string l2lc_data_type = "";
    int         l2lc_dpf_en    = 0;
    int         l2lc_vmax      = 0;
    int         l2lc_vbase     = 0;
} L2LossCfg;

typedef struct _L2LossStats {
    uint32_t l2lc_v_underflow  = 0;
    uint32_t l2lc_v_overflow   = 0;
    uint32_t l2lc_acc_overflow = 0;
    uint32_t l2lc_acc_cnt      = 0;
    uint64_t l2lc_acc          = 0;
} L2LossStats;

typedef struct _MemDesc {
    uint32_t flag             = 0;
    int      src_cbf_inst     = 0;
    int      src_cbf_sub_inst = 0;
    int      dst_cbf_inst     = 0;
    int      dst_cbf_sub_inst = 0;
    int      src_sip_inst     = 0;
    int      src_sip_sub_inst = 0;
    int      dst_sip_inst     = 0;
    int      dst_sip_sub_inst = 0;
    int      src_sic_inst     = 0;
    int      src_dsm_inst     = 0;
    int      dst_sic_inst     = 0;
    int      dst_dsm_inst     = 0;
    bool     no_ext_dst_size  = false;
} MemDesc;

typedef struct _TestOpt {
    bool random_bpe       = false;
    bool random_dse_ratio = false;
    bool random_dse_phase = false;
} TestOpt;

typedef struct _DteVcCtx {
    int      vc_    = 0;
    uint32_t pkt_id = 0;

    /**
     * h2h h2d h2c h2s
     * d2h d2d d2c d2s
     * c2h c2d c2c c2s
     * s2h s2d s2c s2s
     */
    std::string direction = "";

    MemDesc mem_desc;

    DteOpType op_type = InvalidOpType;

    uint64_t src_addr   = 0;
    uint64_t src_offset = 0;
    uint64_t dst_addr   = 0;
    uint64_t dst_offset = 0;
    uint64_t src_size   = 0;
    uint64_t dst_size   = 0;
    uint32_t addr_align = 1;

    HSDC_TYPE compress_src_data = HSDC_NONE;

    uint32_t const_fill_value = 0;

    uint32_t thread_mask        = 0;
    bool     random_thread_mask = false;

    uint32_t ifb_mode = 1;

    uint32_t dynamic_shape = 1;

    uint8_t  split_en   = 0;
    uint32_t split_size = 0;

    uint32_t context_id = 0;
    uint16_t process_id = 0;

    uint8_t bpe    = 1;
    bool    crc_en = false;

    std::vector<uint64_t> src_dim_size       = {0, 0, 0, 0, 0};
    std::vector<uint64_t> dst_dim_size       = {0, 0, 0, 0, 0};
    uint64_t              max_transfer_bytes = 0x1;

    MbxCtrl mbx_ctrl;
    DataSig sig;
    QosCtrl qos;

    DteGSync         gs      = {};
    DataShrinkExpand dse     = {};
    DataPadding      dp      = {};
    DataReshape      rshp    = {};
    DataBrdcst       brdcst  = {};
    DataSlice        slc     = {};
    DataDeslice      dsl     = {};
    DataSubSample    ssmp    = {};
    DataSlicePad     slcpad  = {};
    DataSliceDeSlice slcdsl  = {};
    DataSliceExpand  slcde   = {};
    DataHSDC         hsdc    = {};
    DataHMirDsl      hmirdsl = {};
    DataVMirDsl      vmirdsl = {};
    DataHMirPad      hmirpad = {};
    DataVMirPad      vmirpad = {};
    DataCFDsl        cfdsl   = {};
    DataSliceRshp    slcrshp = {};
    DataRshpDeslice  rshpdsl = {};
    DataShkDeslice   dsdsl   = {};
    DataSlcBrdcst    slcbrd  = {};

    CacheCfg    cache   = {};
    EslCtrlCfg  eslctrl = {};
    ASIDCfg     asid    = {};
    AxiCfg      axi_cfg = {};
    AtomicCfg   atom    = {};
    DecryptCtrl decrypt = {};

    L2LossCfg   l2loss   = {};
    L2LossStats l2lstats = {};

    bool                 skip_mem_alloc = false;
    bool                 skip_mem_set   = false;
    std::shared_ptr<Mem> src_mem;
    std::shared_ptr<Mem> dst_mem;
    std::shared_ptr<Mem> host_src_cache;
    std::shared_ptr<Mem> Host_dst_cache;

    uint8_t *cmodel_dst_data = nullptr;
    uint64_t cmodel_dst_size = 0;

    bool ignore_op_check  = false;
    bool ignore_vc_status = false;

    TestOpt test_op;

    uint64_t wthro      = 0;
    uint64_t rthro      = 0;
    uint64_t busy_cycle = 0;

    uint64_t start_us = 0;
    uint32_t end_us   = 0;

    std::string data_pattern = "";

    bool auto_adjust = false;
} DteVcCtx;

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_GDTE_GDTE_CTX_H_
