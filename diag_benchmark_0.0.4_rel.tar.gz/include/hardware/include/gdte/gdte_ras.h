/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_GDTE_GDTE_RAS_H_
#define HARDWARE_INCLUDE_GDTE_GDTE_RAS_H_

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace gdte {

class GdteRasCfg : public efvf::hardware::RasCfg {
 public:
    uint32_t ill_vc_cfg_check_en = 0;
};

class GdteRasErrInj : public efvf::hardware::RasErrInj {};

class GdteRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t reg_sram_err_index_         = 0;
    uint32_t reg_sram_err_read_addr_     = 0;
    uint32_t data_sram_err_thd_id_       = 0;
    uint32_t data_sram_err_index_        = 0;
    uint32_t data_sram_err_read_addr_    = 0;
    uint32_t ill_vc_cfg_reg_addr_        = 0;
    uint32_t ill_vc_cfg_reg_vc_id_       = 0;
    uint32_t ill_vc_cfg_reg_master_id_   = 0;
    uint32_t timeout_thd_id_             = 0;
    uint32_t timeout_vc_id_              = 0;
    uint32_t ill_prog_vc_id_             = 0;
    uint32_t ill_prog_type_              = 0;
    uint32_t rd_resp_err_thd_id_         = 0;
    uint32_t rd_resp_err_ctxt_id_        = 0;
    uint32_t rd_resp_err_vc_id_          = 0;
    uint32_t rd_resp_err_ruser_          = 0;
    uint32_t rd_resp_err_rresp_          = 0;
    uint32_t wr_resp_err_thd_id_         = 0;
    uint32_t wr_resp_err_ctxt_id_        = 0;
    uint32_t wr_resp_err_vc_id_          = 0;
    uint32_t wr_resp_err_bresp_          = 0;
    uint32_t rd_data_par_err_thd_id_     = 0;
    uint32_t rd_data_par_err_ctxt_id_    = 0;
    uint32_t rd_data_par_err_vc_id_      = 0;
    uint32_t rd_data_par_err_ruser_      = 0;
    uint32_t rd_data_par_err_rresp_      = 0;
    uint32_t mbx_err_type_               = 0;
    uint32_t mbx_upd_mode_               = 0;
    uint32_t mbx_cre_mode_               = 0;
    uint32_t mbx_trg_mode_               = 0;
    uint32_t mbx_inc_mode_               = 0;
    uint32_t mbx_signaling_uniq_id_      = 0;
    uint32_t mbx_uniq_id_                = 0;
    uint32_t mbx_id_                     = 0;
    uint32_t mbx_master_id_              = 0;
    uint32_t mbx_ref_                    = 0;
    uint32_t mbx_counter_                = 0;
    uint32_t cus_trace_mes_loss_counter_ = 0;
    uint32_t cus_trace_mes_loss_ctx_id_  = 0;
    uint32_t cus_trace_mes_loss_vc_id_   = 0;
    uint32_t cus_trace_mes_loss_prcs_id_ = 0;
    uint32_t decrypt_err_log_            = 0;
};

class GdteIntrptCfg : public efvf::hardware::IntrptCfg {
 public:
    uint8_t ill_vc_cfg_int_en_        = 0;
    uint8_t mailbox_err_int_en_       = 0;
    uint8_t ill_prog_int_en_          = 0;
    uint8_t reg_sram_err_par_int_en_  = 0;
    uint8_t data_sram_err_par_int_en_ = 0;
    uint8_t timeout_int_en_           = 0;
    uint8_t wr_resp_err_int_en_       = 0;
    uint8_t rd_data_par_err_int_en_   = 0;
    uint8_t rd_resp_err_int_en_       = 0;
    uint8_t l2loss_err_int_en_        = 0;
    uint8_t cus_trace_msg_err_int_en_ = 0;
    uint8_t sm4_xts_err_int_en_       = 0;
};

class GdteForceIntrptCfg : public efvf::hardware::IntrptCfg {
 public:
    uint8_t  timeout_trigger_mode_             = 0;
    uint32_t timeout_trigger_ctx_id_           = 0;
    uint32_t timeout_trigger_asid_             = 0;
    uint32_t timeout_trigger_en                = 0;
    uint8_t  data_sram_err_par_trigger_mode_   = 0;
    uint32_t data_sram_err_par_trigger_ctx_id_ = 0;
    uint32_t data_sram_err_par_trigger_asid_   = 0;
    uint32_t data_sram_err_par_trigger_en      = 0;
    uint8_t  reg_sram_err_par_trigger_mode_    = 0;
    uint32_t reg_sram_err_par_trigger_ctx_id_  = 0;
    uint32_t reg_sram_err_par_trigger_asid_    = 0;
    uint32_t reg_sram_err_par_trigger_en       = 0;
    uint8_t  ill_prog_trigger_mode_            = 0;
    uint32_t ill_prog_trigger_ctx_id_          = 0;
    uint32_t ill_prog_trigger_asid_            = 0;
    uint32_t ill_prog_trigger_en               = 0;
    uint8_t  mailbox_err_trigger_mode_         = 0;
    uint32_t mailbox_err_trigger_ctx_id_       = 0;
    uint32_t mailbox_err_trigger_asid_         = 0;
    uint32_t mailbox_err_trigger_en            = 0;
    uint8_t  ill_vc_cfg_trigger_mode_          = 0;
    uint32_t ill_vc_cfg_trigger_ctx_id_        = 0;
    uint32_t ill_vc_cfg_trigger_asid_          = 0;
    uint32_t ill_vc_cfg_trigger_en             = 0;
};

class GdteIntrptStat : public efvf::hardware::IntrptStat {
 public:
    uint32_t rd_data_par_err_int_           = 0;
    uint32_t rd_resp_err_int_               = 0;
    uint32_t ill_vc_cfg_int_                = 0;
    uint32_t mailbox_err_int_               = 0;
    uint32_t ill_prog_int_                  = 0;
    uint32_t reg_sram_err_par_int_          = 0;
    uint32_t data_sram_err_par_int_         = 0;
    uint32_t timeout_int_                   = 0;
    uint32_t l2loss_err_int_                = 0;
    uint32_t wr_resp_err_int_               = 0;
    uint32_t customized_trace_msg_loss_int_ = 0;
    uint32_t sm4_xts_err_int                = 0;

    bool IsClean() {
        if (GetIrqValue() != 0) {
            return false;
        }
        return true;
    }

    bool FoundTimeout() {
        return timeout_int_ == 1;
    }

    bool FoundDataSramParErr() {
        return data_sram_err_par_int_ == 1;
    }

    bool FoundRegSramParErr() {
        return reg_sram_err_par_int_ == 1;
    }

    bool FoundIllProg() {
        return ill_prog_int_ == 1;
    }

    bool FoundIllVcCfg() {
        return ill_vc_cfg_int_ == 1;
    }

    bool FoundRdRespErr() {
        return rd_resp_err_int_ == 1;
    }

    bool FoundRdParityErr() {
        return rd_data_par_err_int_ == 1;
    }

    bool FoundL2LossErr() {
        return l2loss_err_int_ == 1;
    }

    bool FoundMbxErr() {
        return mailbox_err_int_ == 1;
    }

    bool FoundWrRespErr() {
        return wr_resp_err_int_ == 1;
    }

    bool FoundCustomTraceLossErr() {
        return customized_trace_msg_loss_int_ == 1;
    }

    bool FoundSm4XtsErr() {
        return sm4_xts_err_int == 1;
    }

    uint32_t GetIrqValue() {
        return (rd_data_par_err_int_ << 0) | (rd_resp_err_int_ << 1) | (ill_vc_cfg_int_ << 2) |
               (mailbox_err_int_ << 3) | (ill_prog_int_ << 4) | (reg_sram_err_par_int_ << 5) |
               (data_sram_err_par_int_ << 6) | (timeout_int_ << 7) | (l2loss_err_int_ << 8) |
               (wr_resp_err_int_ << 9) | (customized_trace_msg_loss_int_ << 10) |
               (sm4_xts_err_int << 11);
    }
};

class GdteRas : public efvf::hardware::IRas {};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_GDTE_GDTE_RAS_H_
