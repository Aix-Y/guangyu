/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_PMON_SSM_PMON_H_
#define HARDWARE_INCLUDE_SSM_PMON_SSM_PMON_H_

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace pmon {

class SsmPmon : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmPmon(Ssm *ssm);
    virtual ~SsmPmon() {}

 public:
    virtual uint32_t get_bus_volt(uint32_t);
    virtual uint32_t get_shunt_volt(uint32_t);
    virtual uint32_t get_power(uint32_t);
    virtual uint32_t get_current(uint32_t);
    virtual uint32_t get_calibration(uint32_t);
};

}  // namespace pmon
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_PMON_SSM_PMON_H_
