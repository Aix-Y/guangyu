/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_FW_IMAGE_INTERFACE_HXX_
#define HARDWARE_INCLUDE_SSM_FW_IMAGE_INTERFACE_HXX_

typedef enum {
  ELEMENT_ROM_STRAP = 0
} ELEMENT_TYPE_T;

typedef enum {
  ELEMENT_BOARD_GPIO = 0,
  ELEMENT_BOARD_LED,
  ELEMENT_BOARD_VRM,
  ELEMENT_BOARD_VRM_BOOT_CONFIG,
  ELEMENT_BOARD_TDC_DAC,
  ELEMENT_BOARD_I2C,
  ELEMENT_BOARD_THM_SENSOR,
  ELEMENT_BOARD_THM_SENSOR_CONFIG,
  ELEMENT_BOARD_CCIX_CARD_ID_GPIO,
  ELEMENT_BOARD_CCIX_BRIDGE_ID_GPIO,
  ELEMENT_BOARD_CCIX_HOTPLUG_GPIO,
  ELEMENT_BOARD_IMAGE_INFO,
  
  ELEMENT_BOARD_MAX,
} ELEMENT_BOARD_T;

typedef enum {
  GRS_PCIE_COMMON = 0,
  GRS_PCIE_30_PRERST,
  GRS_PCIE_30_POSTRST,
  GRS_PCIE_40_PRERST,
  GRS_PCIE_40_POSTRST,
  GRS_DMA,
  GRS_SIC,
  GRS_IH,
  GRS_VM,
  GRS_MC_COMMON,
  GRS_MC_CSR_05,
  GRS_MC_PHY0_05,
  GRS_MC_PHY1_05,
  GRS_MC_CSR_16,
  GRS_MC_PHY0_16,
  GRS_MC_PHY1_16,
  GRS_MC_CSR_18,
  GRS_MC_PHY0_18,
  GRS_MC_PHY1_18,
  GRS_MC_CSR_20,
  GRS_MC_PHY0_20,
  GRS_MC_PHY1_20,
  GRS_CCIX0_COMMON,
  GRS_CCIX1_COMMON,
  GRS_CCIX2_COMMON,
  GRS_CCIX3_COMMON,
  GRS_CCIX0_16_PRERST,
  GRS_CCIX0_16_POSTRST,
  GRS_CCIX0_20_PRERST,
  GRS_CCIX0_20_POSTRST,
  GRS_CCIX0_25_PRERST,
  GRS_CCIX0_25_POSTRST,
  GRS_CCIX1_16_PRERST,
  GRS_CCIX1_16_POSTRST,
  GRS_CCIX1_20_PRERST,
  GRS_CCIX1_20_POSTRST,
  GRS_CCIX1_25_PRERST,
  GRS_CCIX1_25_POSTRST,
  GRS_CCIX2_16_PRERST,
  GRS_CCIX2_16_POSTRST,
  GRS_CCIX2_20_PRERST,
  GRS_CCIX2_20_POSTRST,
  GRS_CCIX2_25_PRERST,
  GRS_CCIX2_25_POSTRST,
  GRS_CCIX3_16_PRERST,
  GRS_CCIX3_16_POSTRST,
  GRS_CCIX3_20_PRERST,
  GRS_CCIX3_20_POSTRST,
  GRS_CCIX3_25_PRERST,
  GRS_CCIX3_25_POSTRST,
  GRS_MAX,
} GRS_T;

typedef enum {
  ELEMENT_GRS_ASIC = 0,
  ELEMENT_GRS_MC_CONF_0,
  ELEMENT_GRS_MC_CONF_1,
  ELEMENT_GRS_MC_CONF_2
} ELEMENT_GRS_T;

typedef enum {
  ELEMENT_FUSE_FUSES = 0
} ELEMENT_FUSE_T;

typedef enum {
  FUSE_DEST_NONE = 0,
  FUSE_DEST_REG,
  FUSE_DEST_CFG
} FUSE_DEST_T;

typedef enum {
    VRM_NAME_IR35215 = 0,
    VRM_NAME_IR38062,
    VRM_NAME_XDPE132G5C,
    VRM_NAME_LTC2635,
    VRM_NAME_MAX16602
} VRM_NAME_T;

typedef enum {
    VRM_VOLTAGE_VDD_DTU = 0,
    VRM_VOLTAGE_VDD_SOC,
    VRM_VOLTAGE_VDD_HBMQC,
    VRM_VOLTAGE_VDD_1V8,
    VRM_VOLTAGE_VDD_VDDP,
    VRM_VOLTAGE_VDD_MCPHY,
    VRM_VOLTAGE_VDD_HBMVPP,
    VRM_VOLTAGE_REF_DAC,
    VRM_VOLTAGE_MCPHY_DAC,

    VRM_VOLTAGE_MAX,
} VRM_VOLTAGE_T;

typedef enum {
    I2C_HOST_VR0 = 0,
    I2C_HOST_VR1,
    I2C_HOST_I2C0,
    I2C_HOST_I2C1
} I2C_HOST_T;

typedef enum {
    I2C_NAME_LTC2635 = 0,
    I2C_NAME_9DBL045,
    I2C_NAME_24LC32
} I2C_NAME_T;

typedef enum {
    I2C_FUNCTION_TDC_DAC = 0,
    I2C_FUNCTION_CCIX_CLK_BUF,
    I2C_FUNCTION_FLASH
} I2C_FUNCTION_T;

typedef enum {
    THM_SENSOR_NAME_EMC1412 = 0
} THM_SENSOR_NAME_T;

typedef enum {
    THM_SENSOR_LOCATION_T0 = 0,
    THM_SENSOR_LOCATION_T1,
    THM_SENSOR_LOCATION_C00,
    THM_SENSOR_LOCATION_C01,
    THM_SENSOR_LOCATION_C10,
    THM_SENSOR_LOCATION_C11,
    THM_SENSOR_LOCATION_C20,
    THM_SENSOR_LOCATION_C21,
    THM_SENSOR_LOCATION_C30,
    THM_SENSOR_LOCATION_C31,

    THM_SENSOR_LOCATION_MAX,
} THM_SENSOR_LOCATION_T;

typedef enum {
    GPIO_NONE = 0,
    GPIO_INPUT,
    GPIO_OUTPUT,
    GPIO_HIGH,
    GPIO_LOW
} GPIO_T;

typedef struct common_header {
    uint32_t type;              // ELEMENT_xxx
    uint32_t version;           //
    uint32_t size;              // how many ellements of "ELEMENT_TYPE_T"
    uint32_t next;              // next element offset (bytes)
} COMMON_HEADER_T;

#define GET_ELEMENT(head) (((char*)head) + sizeof (COMMON_HEADER_T))
#define GET_NEXT_HEAD(head) ((0 == (head)->next) ? (0) : (COMMON_HEADER_T*)(((char*)head) + ((head)->next)))

#define FW_GET_ELEMENT_ADDR_ON_FLASH(head_addr_on_flash) ((head_addr_on_flash) + sizeof (COMMON_HEADER_T))
#define FW_GET_NEXT_ELEMENT_ADDR_ON_FLASH(head, head_addr_on_flash) ((0 == (head)->next) ? (0) : (((head_addr_on_flash) + ((head)->next))))

/*
 * Board Related Definition
 */

//V0
struct board_vrm {
  uint32_t name;                // VRM_NAME_T
  uint32_t voltage;             // VRM_VOLTAGE_T
  uint32_t i2c_addr;
  uint32_t pmbus_addr;
  uint32_t host;                // I2C_HOST_T 
  uint32_t page;                // 0 or 1
};

struct vrm_config_data {
      uint32_t addr;                 // addr
      uint32_t value;                // value
};
//V0
struct board_vrm_boot_config {
  uint8_t voltage;              // VRM_VOLTAGE_T
  uint8_t host;                 // I2C_HOST_T
  uint8_t pmbus_addr;          
  uint8_t num_of_config_data;
  struct vrm_config_data config[0];
};
#define GET_NEXT_VRM_BOOT_CONFIG(current) ( \
        (char*)current + \
        (((current)->num_of_config_data) * sizeof(struct vrm_config_data)) + \
        sizeof (struct board_vrm_boot_config) \
        )

#define FW_GET_NEXT_VRM_BOOT_CONFIG_ON_FLASH(current, current_header_on_flash) ( \
        (current_header_on_flash) + \
        (((current)->num_of_config_data) * sizeof(struct vrm_config_data)) + \
        sizeof (struct board_vrm_boot_config) \
        )

//V0
struct board_i2c {
  uint32_t name;                // VRM_NAME_T
  uint32_t function;            // I2C_FUNCTION_T
  uint32_t i2c_addr;
  uint32_t host;                // I2C_HOST_T 
};

//V0
struct thm_sensor_config_data {
      uint8_t addr;                 // addr
      uint8_t value;                // value
};

//V0
struct board_thm_sensor {
  uint32_t name;                // THM_SENSOR_NAME_T
  uint32_t location;            // THM_SENSOR_LOCATION_T
  uint32_t i2c_addr;
  uint32_t host;                // I2C_HOST_T
};

//V0
struct board_thm_sensor_config {
  uint8_t name;                // THM_SENSOR_NAME_T
  uint8_t location;            // THM_SENSOR_LOCATION_T
  uint8_t i2c_addr;
  uint8_t host;                // I2C_HOST_T
  uint32_t num_of_config_data;
  struct thm_sensor_config_data config[0];
};
#define GET_NEXT_THM_SENSOR_CONFIG(current) ( \
        (char*)current + \
        (((current)->num_of_config_data) * sizeof(struct thm_sensor_config_data)) + \
        sizeof (struct board_thm_sensor_config) \
        )

#define FW_GET_NEXT_THM_SENSOR_CONFIG_ON_FLASH(current, current_header_on_flash) ( \
        (current_header_on_flash) + \
        (((current)->num_of_config_data) * sizeof(struct thm_sensor_config_data)) + \
        sizeof (struct board_thm_sensor_config) \
        )

//V0
struct board_led {
  uint32_t pin;                 // GPIO Number
};

//V0
struct board_ccix_card_id {
  uint32_t pin;                 // GPIO Number
};

//V0
struct board_ccix_bridge_id {
  uint32_t pin;                 // GPIO Number
};

//V0
struct board_ccix_hotplug_id {
  uint32_t pin;                 // GPIO Number
};

//V0
struct board_gpio {
  uint16_t pin;                 // GPIO Number
  uint16_t dir;
  uint16_t value;
  uint16_t reserved;
};

//V0
struct board_image {
  uint32_t ivm_git_rev;
  uint32_t ssm_git_rev;
  uint32_t image_version;
  uint32_t ssm_version;
  uint8_t  boardid[32];       // EFP-00010000
};

/*
 * GRS Related Definition
 */

//#define MAX_GRS_TYPE (64)
struct grs_category_info
{
    uint32_t offset;
    uint32_t size;
} ;

struct grs_header
{
    struct grs_category_info grs_info[64];
} ;

struct grs_reg_pair {
    uint32_t addr;
    uint32_t value;
};

/*
 * Fuse/Rom Strap Table
 */
struct fuse_rom_strap {
    uint8_t size;
    uint8_t row;
    uint8_t fuse_start_bit;
    uint8_t rom_override;
    uint32_t rom_value;
    uint8_t dest;             // FUSE_ROM_DEST_TYPE_T
    uint8_t t_start_bit;
    uint8_t reserve1;
    uint8_t reserve2;
    uint32_t t_addr;          //target addr (either register or pcie config space,...)
};

////////////////////////////////////////////////////////////////

/*
 * Those structure are for testing only,
 */
struct vrms {
    COMMON_HEADER_T head;
    struct board_vrm vrm[];
};

struct THM_SENSORs {
    COMMON_HEADER_T head;
    struct board_thm_sensor thm_sensor[];
};

struct i2cs {
    COMMON_HEADER_T head;
    struct board_i2c i2c[3];
};

#endif  // HARDWARE_INCLUDE_SSM_FW_IMAGE_INTERFACE_HXX_
