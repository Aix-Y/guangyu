/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_CPMU_SSM_CPMU_H_
#define HARDWARE_INCLUDE_SSM_CPMU_SSM_CPMU_H_

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace cpmu {

class SsmCpmu : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmCpmu(Ssm *ssm);
    virtual ~SsmCpmu() {}
};

}  // namespace cpmu
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_CPMU_SSM_CPMU_H_
