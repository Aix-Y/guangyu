/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_RAS_SSM_RAS_H_
#define HARDWARE_INCLUDE_SSM_RAS_SSM_RAS_H_

#include <string>

#include "hardware/include/ras.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace ras {

// clang-format off

class SsmRasCfg : public efvf::hardware::RasCfg {
 public:
    uint32_t par_gen_en_otpm     : 1;
    uint32_t par_gen_en_bank0    : 1;
    uint32_t par_gen_en_bank1    : 1;
    uint32_t par_gen_en_bank2    : 1;
    uint32_t par_gen_en_bank3    : 1;
    uint32_t par_gen_en_bank4    : 1;
    uint32_t par_gen_en_bank5    : 1;
    uint32_t par_gen_en_hash     : 1;
    uint32_t par_gen_en_pke0     : 1;
    uint32_t par_gen_en_pke1     : 1;
    uint32_t par_gen_en_rsvd_0   : 22;

    uint32_t par_chk_en_otpm     : 1;
    uint32_t par_chk_en_bank0    : 1;
    uint32_t par_chk_en_bank1    : 1;
    uint32_t par_chk_en_bank2    : 1;
    uint32_t par_chk_en_bank3    : 1;
    uint32_t par_chk_en_bank4    : 1;
    uint32_t par_chk_en_bank5    : 1;
    uint32_t par_chk_en_hash     : 1;
    uint32_t par_chk_en_pke0     : 1;
    uint32_t par_chk_en_pke1     : 1;
    uint32_t par_chk_en_mcusys_b : 1;
    uint32_t par_chk_en_mcumem_b : 1;
    uint32_t par_chk_en_mdmawp_b : 1;
    uint32_t par_chk_en_mdmanp_b : 1;
    uint32_t par_chk_en_msg_b    : 1;
    uint32_t par_chk_en_ske_b    : 1;
    uint32_t par_chk_en_hash_b   : 1;
    uint32_t par_chk_en_ih_b     : 1;
    uint32_t par_chk_en_mcufp_b  : 1;
    uint32_t par_chk_en_reg_b    : 1;
    uint32_t par_chk_en_seip_b   : 1;
    uint32_t par_chk_en_mcusys_r : 1;
    uint32_t par_chk_en_mcumem_r : 1;
    uint32_t par_chk_en_mdmawp_r : 1;
    uint32_t par_chk_en_mdmanp_r : 1;
    uint32_t par_chk_en_msg_r    : 1;
    uint32_t par_chk_en_ske_r    : 1;
    uint32_t par_chk_en_hash_r   : 1;
    uint32_t par_chk_en_mcufp_r  : 1;
    uint32_t par_chk_en_reg_r    : 1;
    uint32_t par_chk_en_seip_r   : 1;
    uint32_t par_chk_en_rsvd_0   : 1;

 public:
    SsmRasCfg() {
        par_gen_en_otpm     = 0;
        par_gen_en_bank0    = 0;
        par_gen_en_bank1    = 0;
        par_gen_en_bank2    = 0;
        par_gen_en_bank3    = 0;
        par_gen_en_bank4    = 0;
        par_gen_en_bank5    = 0;
        par_gen_en_hash     = 0;
        par_gen_en_pke0     = 0;
        par_gen_en_pke1     = 0;
        par_gen_en_rsvd_0   = 0;

        par_chk_en_otpm     = 0;
        par_chk_en_bank0    = 0;
        par_chk_en_bank1    = 0;
        par_chk_en_bank2    = 0;
        par_chk_en_bank3    = 0;
        par_chk_en_bank4    = 0;
        par_chk_en_bank5    = 0;
        par_chk_en_hash     = 0;
        par_chk_en_pke0     = 0;
        par_chk_en_pke1     = 0;
        par_chk_en_mcusys_b = 0;
        par_chk_en_mcumem_b = 0;
        par_chk_en_mdmawp_b = 0;
        par_chk_en_mdmanp_b = 0;
        par_chk_en_msg_b    = 0;
        par_chk_en_ske_b    = 0;
        par_chk_en_hash_b   = 0;
        par_chk_en_ih_b     = 0;
        par_chk_en_mcufp_b  = 0;
        par_chk_en_reg_b    = 0;
        par_chk_en_seip_b   = 0;
        par_chk_en_mcusys_r = 0;
        par_chk_en_mcumem_r = 0;
        par_chk_en_mdmawp_r = 0;
        par_chk_en_mdmanp_r = 0;
        par_chk_en_msg_r    = 0;
        par_chk_en_ske_r    = 0;
        par_chk_en_hash_r   = 0;
        par_chk_en_mcufp_r  = 0;
        par_chk_en_reg_r    = 0;
        par_chk_en_seip_r   = 0;
        par_chk_en_rsvd_0   = 0;
    }
};

class SsmRasErrInj : public efvf::hardware::RasErrInj {
 public:
    uint32_t ssm_ram_otp    : 1;
    uint32_t ssm_ram_bank_0 : 1;
    uint32_t ssm_ram_bank_1 : 1;
    uint32_t ssm_ram_bank_2 : 1;
    uint32_t ssm_ram_bank_3 : 1;
    uint32_t ssm_ram_bank_4 : 1;
    uint32_t ssm_ram_bank_5 : 1;
    uint32_t ssm_ram_hash   : 1;
    uint32_t ssm_ram_pke_0  : 1;
    uint32_t ssm_ram_pke_1  : 1;
    uint32_t ssm_ram_rsvd_0 : 22;

 public:
    SsmRasErrInj() {
        ssm_ram_otp    = 0;
        ssm_ram_bank_0 = 0;
        ssm_ram_bank_1 = 0;
        ssm_ram_bank_2 = 0;
        ssm_ram_bank_3 = 0;
        ssm_ram_bank_4 = 0;
        ssm_ram_bank_5 = 0;
        ssm_ram_hash   = 0;
        ssm_ram_pke_0  = 0;
        ssm_ram_pke_1  = 0;
        ssm_ram_rsvd_0 = 0;
    }
};

class SsmRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t err_stt_ram_otp    : 1;
    uint32_t err_stt_ram_bank_0 : 1;
    uint32_t err_stt_ram_bank_1 : 1;
    uint32_t err_stt_ram_bank_2 : 1;
    uint32_t err_stt_ram_bank_3 : 1;
    uint32_t err_stt_ram_bank_4 : 1;
    uint32_t err_stt_ram_bank_5 : 1;
    uint32_t err_stt_ram_hash   : 1;
    uint32_t err_stt_ram_pke_0  : 1;
    uint32_t err_stt_ram_pke_1  : 1;
    uint32_t err_stt_mcusys_b   : 1;
    uint32_t err_stt_mcusys_r   : 1;
    uint32_t err_stt_mcumem_b   : 1;
    uint32_t err_stt_mcumem_r   : 1;
    uint32_t err_stt_mdmawp_b   : 1;
    uint32_t err_stt_mdmawp_r   : 1;
    uint32_t err_stt_mdmanp_b   : 1;
    uint32_t err_stt_mdmanp_r   : 1;
    uint32_t err_stt_msg_b      : 1;
    uint32_t err_stt_msg_r      : 1;
    uint32_t err_stt_ske_b      : 1;
    uint32_t err_stt_ske_r      : 1;
    uint32_t err_stt_hash_b     : 1;
    uint32_t err_stt_hash_r     : 1;
    uint32_t err_stt_ih_b       : 1;
    uint32_t err_stt_mcufp_b    : 1;
    uint32_t err_stt_mcufp_r    : 1;
    uint32_t err_stt_reg_b      : 1;
    uint32_t err_stt_reg_r      : 1;
    uint32_t err_stt_seip_b     : 1;
    uint32_t err_stt_seip_r     : 1;
    uint32_t err_stt_rsvd_0     : 1;

 public:
    SsmRasErrStat() {
        err_stt_ram_otp    = 0;
        err_stt_ram_bank_0 = 0;
        err_stt_ram_bank_1 = 0;
        err_stt_ram_bank_2 = 0;
        err_stt_ram_bank_3 = 0;
        err_stt_ram_bank_4 = 0;
        err_stt_ram_bank_5 = 0;
        err_stt_ram_hash   = 0;
        err_stt_ram_pke_0  = 0;
        err_stt_ram_pke_1  = 0;
        err_stt_mcusys_b   = 0;
        err_stt_mcusys_r   = 0;
        err_stt_mcumem_b   = 0;
        err_stt_mcumem_r   = 0;
        err_stt_mdmawp_b   = 0;
        err_stt_mdmawp_r   = 0;
        err_stt_mdmanp_b   = 0;
        err_stt_mdmanp_r   = 0;
        err_stt_msg_b      = 0;
        err_stt_msg_r      = 0;
        err_stt_ske_b      = 0;
        err_stt_ske_r      = 0;
        err_stt_hash_b     = 0;
        err_stt_hash_r     = 0;
        err_stt_ih_b       = 0;
        err_stt_mcufp_b    = 0;
        err_stt_mcufp_r    = 0;
        err_stt_reg_b      = 0;
        err_stt_reg_r      = 0;
        err_stt_seip_b     = 0;
        err_stt_seip_r     = 0;
        err_stt_rsvd_0     = 0;
    }
};

// clang-format on

class SsmRas : public efvf::hardware::IRas {
 public:
    virtual void       Enable(RasCfg *);
    virtual void       Disable(RasCfg *);
    virtual void       StartErrInjection(RasCfg *, RasErrInj *);
    virtual void       StopErrInjection(RasCfg *, RasErrInj *);
    virtual void       QueryErrStatus(RasCfg *, RasErrStat *);
    virtual void       ClearErrStatus(RasCfg *);
    virtual void       PrintErrStatus(RasCfg *);
    virtual void       GetRasCfg(RasCfg *);
    virtual void       EnableInterrupt(IntrptCfg *);
    virtual void       DisableInterrupt(IntrptCfg *);
    virtual void       ClearInterrupt(IntrptCfg *);
    virtual void       QueryInterrupt(IntrptCfg *, IntrptStat *);
    virtual void       PrintInterrupt(IntrptCfg *);
    virtual RasErrInj *GenRasErrInjCfg(const std::string &, bool = false);
};

}  // namespace ras
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_RAS_SSM_RAS_H_
