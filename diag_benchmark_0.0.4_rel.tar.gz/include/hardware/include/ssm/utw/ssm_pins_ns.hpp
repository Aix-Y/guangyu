/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_PINS_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_PINS_NS_HPP_

namespace efvf {
namespace hardware {
namespace ssm {
namespace pins {

// clang-format off
// clang-format on

}  // namespace pins
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_PINS_NS_HPP_
