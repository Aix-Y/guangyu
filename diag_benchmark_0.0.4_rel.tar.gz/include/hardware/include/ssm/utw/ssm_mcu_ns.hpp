/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_MCU_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_MCU_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace mcu {

typedef enum {
    SSM_FEATURE_ID_PID = 0x0,        // added since 1d0 DPM
    SSM_FEATURE_ID_LVDM,             // added since 1d0 DOZE
    SSM_FEATURE_ID_TSENSOR,          // added since 1d0
    SSM_FEATURE_ID_VR,               // added since 1d0
    SSM_FEATURE_ID_HBM_MONITOR,      // added since 1d0
    SSM_FEATURE_ID_BMC,              // added since 1d0
    SSM_FEATURE_ID_PCIE_SERVICE,     // added since 1d0
    SSM_FEATURE_ID_CCIX_SERVICE,     // added since 2d0
    SSM_FEATURE_ID_AVS_BUS,          // added since 2d0
    SSM_FEATURE_ID_AMC_TALK,         // added since 2d0
    SSM_FEATURE_ID_PWR_STOCK,        // added since 2d0
    SSM_FEATURE_ID_PWR_INSUR,        // added since 2d0
    SSM_FEATURE_ID_FAN,              // added since 2d1
    SSM_FEATURE_ID_FIREWALL,         // added since 2d1
    SSM_FEATURE_ID_FW_MONITOR,       // added since 2d1
    SSM_FEATURE_ID_G6_TEMP,          // added since 3d0
    SSM_FEATURE_ID_AASP_SERVICE,     // added since 3d0
    SSM_FEATURE_ID_VF_SERVICE,       // added since 3d0
    SSM_FEATURE_ID_D2D_MSG,          // added since 3d0
    SSM_FEATURE_ID_AASP_DL_MONITOR,  // added since 3d0
    SSM_FEATURE_ID_ALL,
    SSM_FEATURE_ID_NUM,
} SSM_FEATURE_ID;

}  // namespace mcu
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_MCU_NS_HPP_
