/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_UART_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_UART_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace uart {

// clang-format off

enum {
    UART_BLK_00 = 0,
    UART_BLK_01 = 1,
};

enum {
    UART_BAUD_RATE_NONE,
    UART_BAUD_RATE_4800,
    UART_BAUD_RATE_9600,
    UART_BAUD_RATE_19200,
    UART_BAUD_RATE_38400,
    UART_BAUD_RATE_57600,
    UART_BAUD_RATE_115200,
};

enum {
    UART_FIFO_MODE_NONE,
    UART_FIFO_MODE_0000,
    UART_FIFO_MODE_0016,
    UART_FIFO_MODE_0032,
    UART_FIFO_MODE_0064,
    UART_FIFO_MODE_0128,
    UART_FIFO_MODE_0256,
    UART_FIFO_MODE_0512,
    UART_FIFO_MODE_1024,
    UART_FIFO_MODE_2048,
};

inline const char* apb_fifo_mode_str(uint32_t apb_ffm) {
    switch (apb_ffm) {
        case UART_FIFO_MODE_NONE: return "UART_FIFO_MODE_NONE";
        case UART_FIFO_MODE_0000: return "UART_FIFO_MODE_0000";
        case UART_FIFO_MODE_0016: return "UART_FIFO_MODE_0016";
        case UART_FIFO_MODE_0032: return "UART_FIFO_MODE_0032";
        case UART_FIFO_MODE_0064: return "UART_FIFO_MODE_0064";
        case UART_FIFO_MODE_0128: return "UART_FIFO_MODE_0128";
        case UART_FIFO_MODE_0256: return "UART_FIFO_MODE_0256";
        case UART_FIFO_MODE_0512: return "UART_FIFO_MODE_0512";
        case UART_FIFO_MODE_1024: return "UART_FIFO_MODE_1024";
        case UART_FIFO_MODE_2048: return "UART_FIFO_MODE_2048";
        default: break;
    }
    return "UART_FIFO_MODE_UNKNOWN";
}

enum {
    UART_APB_DATA_WIDTH_NONE,
    UART_APB_DATA_WIDTH_08BITS,
    UART_APB_DATA_WIDTH_16BITS,
    UART_APB_DATA_WIDTH_32BITS,
};

inline const char* apb_data_width_str(uint32_t apb_dw) {
    switch (apb_dw) {
        case UART_APB_DATA_WIDTH_NONE:   return "UART_APB_DATA_WIDTH_NONE";
        case UART_APB_DATA_WIDTH_08BITS: return "UART_APB_DATA_WIDTH_08BITS";
        case UART_APB_DATA_WIDTH_16BITS: return "UART_APB_DATA_WIDTH_16BITS";
        case UART_APB_DATA_WIDTH_32BITS: return "UART_APB_DATA_WIDTH_32BITS";
        default: break;
    }
    return "UART_APB_DATA_WIDTH_UNKNOWN";
}

enum {
    AMC_UPDATE_PROTO_XMODE = 0,
    AMC_UPDATE_PROTO_BMODE,
};

inline const char* amc_update_p2str(uint32_t d_path) {
    switch (d_path) {
        case AMC_UPDATE_PROTO_XMODE: return "XMODE";
        case AMC_UPDATE_PROTO_BMODE: return "BMODE";
        default: break;
    }
    return "PROTO_UNKNOWN";
}

/**
 * BELOW SHARED BTW ASIC
 * V1 :: 3D0 :: 4D0
 */
const uint32_t UART_BLK_NUM_3D0            = 2U;   // INSTx LIMITED
const uint32_t UART_BLK_NUM_4D0            = 2U;   // INSTx LIMITED
const uint32_t UART_BLK_00_CIO_BIT_TXD_V1  = 15U;  // UART0 TXD GPIO.15
const uint32_t UART_BLK_00_CIO_BIT_RXD_V1  = 16U;  // UART0 RXD GPIO.16
const uint32_t UART_BLK_01_CIO_BIT_TXD_V1  = 17U;  // UART1 TXD GPIO.17
const uint32_t UART_BLK_01_CIO_BIT_RXD_V1  = 18U;  // UART1 RXD GPIO.18
const uint32_t AMC_CORE_RESET_CIO_BIT_V1   = 3U;   // NRST# AMC GPIO.3 (X1/X2)
const uint32_t AMC_MODE_RESET_CIO_BIT_V1   = 4U;   // BOOT0 AMC GPIO.4 (X1/X2)
const uint32_t AMC_UART_LS_EN_CIO_BIT_3D0  = 2U;   // LS EN AMC GPIO.2 (X1/X2)

enum {
    // XMODEM ASCII CONTROL CODES - IN USE
    AMC_NUL = 0x00,    // String terminator
    AMC_SOH = 0x01,    // Start Of Header
    AMC_EOT = 0x04,    // End Of Transmission
    AMC_ACK = 0x06,    // Acknowledge (positive)
    AMC_NAK = 0x15,    // Negative Acknowledge
    AMC_CAN = 0x18,    // Cancel
    // XMODEM ASCII CONTROL CODES - NOT USED
    AMC_DLE = 0x10,    // Data Link Escape
    AMC_DC1 = 0x11,    // Transmit On  (XON)
    AMC_DC2 = 0x12,    // Transmit On  (DC2)
    AMC_DC3 = 0x13,    // Transmit Off (XOFF)
    AMC_DC4 = 0x14,    // Transmit Off (DC4)
    AMC_SYN = 0x16,    // Synchronous idle
    AMC_SUB = 0x1A,    // Garbled padding
    AMC_ESC = 0x1B,    // Escape character
    AMC_DEL = 0x7F,    // Delete or backspace
    // AMC CUSTOMIZE COMMAND
    AMC_PAT = 0x5A,    // customize padding
    AMC_MDX = 0xFFFF,  // switch amc mode xmodem
};

inline const char* amc_pkg_cc_str(uint32_t amc_x) {
    switch (amc_x) {
        case AMC_NUL: return "NUL";
        case AMC_SOH: return "SOH";
        case AMC_EOT: return "EOT";
        case AMC_ACK: return "ACK";
        case AMC_NAK: return "NAK";
        case AMC_CAN: return "CAN";
        case AMC_DLE: return "DLE";
        case AMC_DC1: return "DC1";
        case AMC_DC2: return "DC2";
        case AMC_DC3: return "DC3";
        case AMC_DC4: return "DC4";
        case AMC_SYN: return "SYN";
        case AMC_SUB: return "SUB";
        case AMC_ESC: return "ESC";
        case AMC_DEL: return "DEL";
        case AMC_PAT: return "PAT";
        case AMC_MDX: return "XMD";
        default: break;
    }

    return "XXX";
}

/*
 * XMODEM PACKAGE FORMAT
 *
 * ISO-646  (ASCII) C0 Set (00H - 1FH)
 * ISO-6429 ECMA-48 C1 Set (80H - 9FH)
 *
 * +--------+----------------+------+------------+-------------------+
 * |  1xBYTE|          2xBYTE|3xBYTE|  4~131xBYTE|           132xByte|
 * +--------+----------------+------+------------+-------------------+
 * |SOH 0x01|SEQ 0x01 .. 0xFF|  ~SEQ|PAYLOAD[128]|PAYLOAD CHECKSUM U8|
 * +--------+----------------+------+------------+-------------------+
 *
 * Block numbering starts with 1 for the first block sent(not 0)
 * Standard suggested any character could be used for payload padding
 */
const uint32_t AMC_PKG_DATA_BYTE_SIZE = 0x80;
const uint32_t AMC_ROM_BYTES_SZ_DENSITY_V1      = SSM_KB(64);
const uint32_t AMC_ROM_BYTES_SZ_ERASE_PER_PAGE  = SSM_KB(1);
typedef struct _amc_pkg_128 {
    uint32_t pkg_blk;
    uint32_t pkg_hdr;
    uint32_t pkg_seq;
    uint32_t pkg_sqr;
    uint32_t pkg_csm;  // u8 checksum for payload
    uint8_t  pkg_pld[AMC_PKG_DATA_BYTE_SIZE];  // payload data
} AMC_PKG_128B;

/*
 * USART PROTOCAL SUPPORT
 * STM32 MICROCONTROLLER BOOTLOADEDR HANDSHAKE
 */
const uint32_t AMC_ROM_ADDR_BASE_3D0     = 0x08000000;
const uint32_t AMC_ROM_OFST_CRIT_PING    = 0xD000;
const uint32_t AMC_ROM_OFST_CRIT_PONG    = 0xD400;
const uint32_t AMC_ROM_OFST_CRIT_SIZE    = SSM_KB(1);
const uint32_t UST_CMD_EER_PAGE_MAX      = 0x100;
const uint32_t UST_PKG_DATA_BYTE_SIZE    = 0x100;
const uint32_t UST_WMM_DATA_BYTE_ALIGN   = 0x4;
typedef struct _ust_pkg_stm32 {
    uint32_t pkg_blk;  // uart instance
    uint32_t pkg_cmd;  // usart protocol cmd
    uint32_t pkg_psz;  // payload data bytes
    uint32_t pkg_adr;  // payload data offset 2-or-f
    uint8_t  pkg_pld[UST_PKG_DATA_BYTE_SIZE];  // payload data
    std::string send;  // store per send raw
    std::string recv;  // store per recv raw
} UST_PKG_STM32;

enum {
    // USART ASCII CONTROL CODES - IN USE
    UST_GET = 0x00,  // get ver and cmds
    UST_GVP = 0x01,  // get ver and read protection status
    UST_GID = 0x02,  // get the chip id
    UST_PID = 0x06,  // get gd pid
    UST_RMM = 0x11,  // read  up to 256 bytes of memory
    UST_WMM = 0x31,  // write up to 256 bytes of memory
    UST_ERS = 0x43,  // erase up to one to all memory pages
    UST_EER = 0x44,  // erase two byte addressing mode 3.0 above
    UST_ACK = 0x79,  // acknowledge (positive)
    UST_NAK = 0x1F,  // acknowledge (negative)
    UST_BDR = 0x7F,  // auto-baud rate train
};

inline const char* ust_pkg_cc_str(uint32_t ust_x) {
    switch (ust_x) {
        case UST_GET: return "GET";
        case UST_GVP: return "GVP";
        case UST_GID: return "GID";
        case UST_PID: return "PID";
        case UST_RMM: return "RMM";
        case UST_WMM: return "WMM";
        case UST_ERS: return "ERS";
        case UST_EER: return "EER";
        case UST_ACK: return "ACK";
        case UST_NAK: return "NAK";
        case UST_BDR: return "BDR";
        default: break;
    }

    return "XXX";
}

inline bool ust_cmd_is_valid(uint32_t ust_x) {
    bool cmd_valid = false;

    switch (ust_x) {
        case UST_BDR: cmd_valid =  true; break;
        case UST_GET: cmd_valid =  true; break;
        case UST_GVP: cmd_valid =  true; break;
        case UST_GID: cmd_valid =  true; break;
        case UST_PID: cmd_valid =  true; break;
        case UST_RMM: cmd_valid =  true; break;
        case UST_WMM: cmd_valid =  true; break;
        case UST_ERS: cmd_valid =  true; break;
        case UST_EER: cmd_valid =  true; break;
        case UST_ACK: cmd_valid = false; break;
        case UST_NAK: cmd_valid = false; break;
        default: break;
    }

    return cmd_valid;
}

typedef struct _AMC_RTC_F {
#if BYTE_ORDER == LITTLE_ENDIAN
    uint32_t s : 6;  // 0 ~ 59
    uint32_t m : 6;  // 0 ~ 59
    uint32_t h : 5;  // 0 ~ 23
    uint32_t d : 5;  // 1 ~ 31
    uint32_t o : 4;  // 1 ~ 12
    uint32_t y : 6;  // 0 ~ 31, 25 means 25 + 2000 = 2025 year
#elif BYTE_ORDER == BIG_ENDIAN
    uint32_t y : 6;  // 0 ~ 31, 25 means 25 + 2000 = 2025 year
    uint32_t o : 4;  // 1 ~ 12
    uint32_t d : 5;  // 1 ~ 31
    uint32_t h : 5;  // 0 ~ 23
    uint32_t m : 6;  // 0 ~ 59
    uint32_t s : 6;  // 0 ~ 59
#endif
} AMC_RTC_FIELDS;

typedef union {
    uint32_t val : 32;
    AMC_RTC_FIELDS  f;
} AMC_RTC_t;

// clang-format on

}  // namespace uart
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_UART_NS_HPP_
