/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_I2C_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_I2C_NS_HPP_

#include <memory>
#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace i2c {

// clang-format off
enum kSsmTdiode {
    kSsmTdiode_0 = 0,
    kSsmTdiode_1 = 1,
    kSsmTdiode_2 = 2,
    kSsmTdiode_3 = 3,
    kSsmTdiode_4 = 4,
    kSsmTdiode_5 = 5,
    kSsmTdiode_6 = 6,
    kSsmTdiode_7 = 7,
    kSsmTdiode_8 = 8,
    kSsmTdiode_9 = 9,
    kSsmTextss_0 = 10,
    kSsmTextss_1 = 11,
    kSsmTextss_2 = 12,
    kSsmTdiode_Max,
    kSsmTdiode_All,  // partial cmd support
};

typedef struct {
    std::string nm;
    std::string loc;
    uint32_t    icpid;
    uint32_t    icmid;
    uint32_t    fwidx;
} ssm_i2c_t;

typedef struct {
    std::string nm;
    std::string loc;
    uint32_t    icpid;
    uint32_t    icmid;
    uint32_t    fwgrp;
    uint32_t    fwidx;
} ssm_i2c_3d0_t;

/**
 * MASTER DRIVING BUS
 *
 * I: IDLE  SDA_1   + SCL_1
 * S: START SDA_1-0 + SCL_1
 * P: STOP  SDA_0-1 + SCL_1
 * C: CHANGE OF DATA ALLOWED
 * D: DATA LINE STABLE DATA VALID
 *
 *       I    S         C            D            C         P    I
 * SDA 1 -----+             +----------------+              +-----
 * SDA 0      +-------------|----------------|--------------+
 * SCL 1 -----------+         +------------+          +-----------
 * SCL 0            +---------+            +----------+
 *       I    S         C            D            C         P    I
 */
typedef struct _ssm_i2c_trans {
    uint32_t    blk;
    uint32_t    slv;
    uint32_t    reg;
    uint32_t    siz;
    uint32_t    txn;
    uint32_t    rxn;
    uint8_t     buf[256];
    std::string log;
    bool        dbl;
    uint64_t    tms;
} ssm_i2c_trans_t;

const uint32_t I2C_BLK_NUM_3D0 = 5U;   // INSTx LIMITED
const uint32_t I2C_BLK_NUM_4D0 = 5U;   // INSTx LIMITED

const uint32_t EMC1412_PID = 0x20;  // Product ID      @FDh
const uint32_t EMC1412_MID = 0x5D;  // Manufacturer ID @FEh

// clang-format on

}  // namespace i2c
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_I2C_NS_HPP_
