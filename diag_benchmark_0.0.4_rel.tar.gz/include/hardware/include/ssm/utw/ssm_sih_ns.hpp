/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_SIH_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_SIH_NS_HPP_

namespace efvf {
namespace hardware {
namespace ssm {
namespace sih {

// clang-format off
const uint32_t ssm_ih_dw         = 14U;
const uint32_t ssm_ih_r_num_x16x = 16U;
// clang-format on

typedef struct {
    uint32_t ring_idx;
    uint32_t ring_ena;
    uint32_t ring_alo;
    uint32_t ring_ahi;
    uint32_t ring_vcs;
    uint32_t ring_vpd;
    uint32_t ring_vsk;
    uint32_t ring_pc0;
    uint32_t ring_pc1;
    uint32_t ring_pcg;
    uint32_t ring_psk;
    uint32_t ring_sms;
    uint32_t ring_pmi;
    uint32_t ring_pdc;
} ssm_ih_a_t;

typedef union {
    uint32_t   v[ssm_ih_dw];
    ssm_ih_a_t a;
} ssm_ih_u;

}  // namespace sih
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_SIH_NS_HPP_
