/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_UTW_H_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_UTW_H_

#include <memory>
#include <string>
#include <vector>

#include "framework/include/cmd_parser.h"
#include "framework/include/mem.h"
#include "framework/include/utils.h"

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/fw/ssm_cmd_cmn.h"
#include "hardware/include/ssm/fw/ssm_cmd_dbg.h"
#include "hardware/include/ssm/fw/ssm_cmd_drv.h"
#include "hardware/include/ssm/fw/ssm_cmd_v1.h"
#include "hardware/include/ssm/utw/ssm_cmn.hpp"

namespace efvf {
namespace hardware {
namespace ssm {
class Ssm;
namespace utw {  // utility wrapper

/**
 * ELIMINATE PROJECT NAMING
 * PICK BELOW NAMING IN USE 1D0: P1A
 * PICK BELOW NAMING IN USE 2D0: P2A
 * PICK BELOW NAMING IN USE 2D1: P2B
 * PICK BELOW NAMING IN USE 3D0: P3A
 */

class SsmUtw : public Hardware {
 public:
    explicit SsmUtw(Ssm *ssm);
    virtual ~SsmUtw() {}

 protected:
    void        SleepMs(uint32_t);
    void        SleepUs(uint32_t);
    uint64_t    ClockMs(void);
    uint64_t    ClockUs(void);
    uint64_t    ClockNs(void);
    uint32_t    RandU08(void);
    uint32_t    RandU16(void);
    uint32_t    RandU32(void);
    uint32_t    RandU32(uint32_t, uint32_t);
    uint32_t    RandU32N0F(void);
    bool        file_execp(const std::string &);
    bool        file_exist(const std::string &);
    void        swbz_delay_ms(uint64_t);
    void        swbz_delay_us(uint64_t);
    bool        is_app_efvs(void);
    bool        is_app_efdt(void);
    bool        is_app_efsmt(void);
    bool        is_asic_a0(void);
    bool        is_asic_a1(void);
    bool        is_asic_a2(void);
    bool        is_asic_a3(void);
    bool        is_1d0(void);
    bool        is_2d0(void);
    bool        is_2d1(void);
    bool        is_3d0(void);
    bool        is_4d0(void);
    bool        is_sku_x1(void);
    bool        is_sku_x2(void);
    bool        is_sku_x2s(void);
    bool        is_3d0_x1(void);
    bool        is_3d0_x1_m16(void);
    bool        is_3d0_x1_m24(void);
    bool        is_3d0_x2(void);
    bool        is_3d0_x2_m24(void);
    bool        is_3d0_x2_m48(void);
    bool        is_3d0_x2s(void);
    bool        is_3d0_x2s_m24(void);
    bool        is_3d0_x2s_m48(void);
    bool        is_4d0_l300(void);
    bool        is_4d0_l600(void);
    bool        is_4d0_l600x(void);
    bool        is_secured(void);
    bool        is_silicon(void);
    bool        is_fpga(void);
    bool        is_edk(void);
    bool        is_mst_die(void);
    bool        is_slv_die(void);
    uint32_t    get_op_dtu(void);
    uint32_t    get_op_die(void);
    std::string get_dtu_x(void);
    std::string get_die_x(void);
    std::string get_ddx_x(void);
    std::string get_die_xup(void);
    std::string get_vp_did(void);
    std::string get_dtu_sku(void);
    std::string get_silicon_rev(void);
    std::string get_chip_rev(void);
    std::string get_pkg_rev(void);
    bool        is_param_exist(const std::string &);
    bool        get_param_bool(const std::string &, bool);                // silence coverity
    double      get_param_double(const std::string &, double);            // silence coverity
    uint32_t    get_param_u32(const std::string &, uint32_t);             // silence coverity
    std::string get_param_str(const std::string &, const std::string &);  // silence coverity
    bool        c_is_d_num(const char &);
    bool        c_is_h_num(const char &);
    bool        c_is_h_upper(const char &);
    bool        c_is_h_lower(const char &);
    bool        c_is_a_num(const char &);
    bool        c_is_a_upolw(const char &);
    bool        c_is_a_upper(const char &);
    bool        c_is_a_lower(const char &);
    bool        u8_2hex_valid(uint8_t &, bool = true);
    std::string u08_2hex_str(uint32_t);
    std::string u16_2hex_str(uint32_t);
    std::string u32_2hex_s(uint32_t);
    std::string u32_2hex_str(uint32_t);
    std::string dbl_2d3str(double);
    std::string b2sel(bool);
    std::string b2selw(bool);
    std::string h2selp(uint32_t &);
    std::string b2selw_ab(const std::string &, bool, const std::string &);
    std::string h2selp_ab(const std::string &, uint32_t, const std::string &);
    std::string b2flag(bool);
    std::string strup(std::string);
    std::string strdn(std::string);
    float       u32_2flt(uint32_t);
    void        show_progress(std::string, uint32_t);
    void        show_calc_speed(uint64_t, uint64_t, std::string);
    void        random_fill_buf(void *, uint32_t);
    void        ptdata_fill_buf(void *, uint32_t, uint8_t);
    void        ptdata_fill_u32(void *, uint32_t, uint32_t);
    void        ptdata_fill_dwidx(void *, uint32_t);
    std::unique_ptr<uint8_t[]> get_bytes_buf(uint32_t);

 protected:
    bool check_average_deviation(std::vector<double> &, double, double ext_exp = -1.0);
    bool check_expectation(std::vector<uint32_t> &, kSsmDefOp, uint32_t);
    bool check_expectation(std::vector<double> &, kSsmDefOp, double);
    void format_dump_array(void *, uint32_t, uint32_t, uint32_t);
    void format_dump_array(
        void *, uint32_t, void *p_cmp = NULL, uint32_t base = 0, uint32_t item = 4);
    void format_dump_array(uint32_t *p_arr, uint32_t arr_sz, uint32_t *p_cmp = NULL,
        uint32_t base = 0, uint32_t item = 4);
    void format_dump_array_tool(void *, uint32_t, uint32_t);
    void format_dump_array_tool(
        uint32_t *p_arr, uint32_t arr_sz, uint32_t base = 0, uint32_t item = 4);
    uint32_t file_size(const std::string &);
    uint32_t file_load(ssm_fload_t &);
    uint32_t file_load_bin(ssm_fload_t &);
    uint32_t file_load_hex(ssm_fload_t &);

 public:
    virtual std::string handle_tool_req_get_str(const std::string &);
    virtual std::string handle_tool_req_get_str(const std::string &, const std::string &);
    virtual std::string handle_tool_req_get_str(
        const std::string &, const std::string &, const std::string &);
    virtual std::string handle_tool_req_get_str(const std::string &, const uint32_t &);
    virtual uint64_t    handle_tool_req_get_u64(const std::string &, const uint32_t &);
    virtual bool        handle_tool_req_set_u64(const std::string &, const uint64_t &);
    virtual bool        handle_tool_req_set_u64(
        const std::string &, const uint64_t &, const uint64_t &);
    virtual bool handle_tool_req_set(const std::string &);
    virtual bool handle_tool_req_set(const std::string &, const std::string &);
    virtual bool handle_tool_req_set(const std::string &, uint32_t &);
    virtual bool handle_tool_req_set(const std::string &, uint32_t &, uint32_t &);
    virtual bool handle_tool_req_set(const std::string &, std::vector<uint32_t> &);
    virtual bool handle_tool_req_set_val(const std::string &, std::string &, uint32_t &);

 public:
    Ssm *       m_ssm;
    Dtu *       m_dtu;
    Hpd *       m_hpd;
    std::string m_sku;
};

}  // namespace utw
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_UTW_H_
