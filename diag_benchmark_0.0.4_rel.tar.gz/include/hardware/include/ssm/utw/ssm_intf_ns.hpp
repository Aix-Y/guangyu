/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_INTF_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_INTF_NS_HPP_

namespace efvf {
namespace hardware {
namespace ssm {
namespace intf {

typedef struct {
    bool     ecc_enabled;  // 1d0 true: enabled               false: disabled
    bool     ecc_pending;  // 1d0 true: pending               false: no pending
    bool     ecc_pdblack;  // 1d0 true: pending blacklist yes false: no
    uint32_t ecc_ecnt_sb;  // 1d0 single bit error count
    uint32_t ecc_ecnt_db;  // 1d0 double bit error count
    uint32_t ecc_ret_raw;  // 1d0 raw data returned from fw
} SSM_ECC_STAT_t;

}  // namespace intf
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_INTF_NS_HPP_
