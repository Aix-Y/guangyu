/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_CMD_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_CMD_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace cmd {

typedef enum {
    SSM_MCU_PORT_DBG,      // intf debug
    SSM_MCU_PORT_DRV,      // intf driver
    SSM_MCU_PORT_DBG_VF,   // intf debug  workaround
    SSM_MCU_PORT_DRV_VF,   // intf driver workaround
    SSM_MCU_PORT_DBG_CQM,  // intf debug  workaround
    SSM_MCU_PORT_DRV_CQM,  // intf driver workaround
    SSM_MCU_PORT_MAX,
    SSM_MCU_PORT_INVAL = ~0U,
} SSM_PORT_TYPE;

inline std::string mcu_port_2str(uint32_t port_id) {
    // clang-format off
    switch (port_id) {
        case SSM_MCU_PORT_DBG:      return "SSM_MCU_PORT_DBG";
        case SSM_MCU_PORT_DRV:      return "SSM_MCU_PORT_DRV";
        case SSM_MCU_PORT_DBG_VF:   return "SSM_MCU_PORT_DBG_VF";
        case SSM_MCU_PORT_DRV_VF:   return "SSM_MCU_PORT_DRV_VF";
        case SSM_MCU_PORT_DBG_CQM:  return "SSM_MCU_PORT_DBG_CQM";
        case SSM_MCU_PORT_DRV_CQM:  return "SSM_MCU_PORT_DRV_CQM";
        case SSM_MCU_PORT_MAX:      return "SSM_MCU_PORT_MAX";
        case SSM_MCU_PORT_INVAL:    return "SSM_MCU_PORT_INVAL";
        default: break;
    }
    // clang-format on

    return "SSM_MCU_PORT_UDEF";
}

typedef enum {
    SSM_CMD_REG_FUNC = 0,
    SSM_CMD_REG_PARAM,
    SSM_CMD_REG_DATA,
    SSM_CMD_REG_MAX,
    SSM_CMD_REG_INVAL = ~0U,
} SSM_CMD_REG_TYPE;

typedef struct {
    uint32_t wval;
    uint32_t addr;
} SSM_REGS_PAIR;

typedef struct {
    void *   dp;
    uint32_t sz;
} SSM_BUFX_PAIR;

typedef struct {
    SSM_PORT_TYPE cmd_port;
    SSM_REGS_PAIR cmd_func;
    SSM_REGS_PAIR cmd_param;
    SSM_REGS_PAIR cmd_data;
    SSM_BUFX_PAIR cmd_dbuf;
    bool          cmd_nowait;
    bool          cmd_pinuse;
    uint64_t      cmd_tout_ms;
    uint64_t      cmd_cost_us;
} SSM_MCU_CMD;

inline static std::string dec_ssm_fw_cmd_v1(uint32_t &fw_cmd) {
    // clang-format off
    switch (fw_cmd) {
        case 1     : return "SSM_CMD_GET_SOCHBM_TEMP";
        case 2     : return "SSM_CMD_GET_FLR_STATUS";
        case 3     : return "SSM_CMD_GET_MAX_DPM_LEVEL";
        case 4     : return "SSM_CMD_GET_DPM_LEVEL";
        case 5     : return "SSM_CMD_GET_CCIX_STATUS";
        case 6     : return "SSM_CMD_PREPARE_UPDATE_FW";
        case 7     : return "SSM_CMD_SET_MAX_DPM_LEVEL";
        case 8     : return "SSM_CMD_SET_DPM_LEVEL";
        case 9     : return "SSM_CMD_PREPARE_UPDATE_RFW";
        case 10    : return "SSM_CMD_SET_DTU_FREQ";
        case 11    : return "SSM_CMD_SET_EDF_FREQ";
        case 12    : return "SSM_CMD_SET_MC_FREQ";
        case 13    : return "SSM_CMD_GET_COMPILE_TIME";
        case 14    : return "SSM_CMD_GET_MANU_DATE";
        case 15    : return "SSM_CMD_SET_MANU_DATE";
        case 16    : return "SSM_CMD_GET_MODEL";
        case 17    : return "SSM_CMD_SET_MODEL";
        case 18    : return "SSM_CMD_UPDATE_OCP_THRESHOLD";
        case 19    : return "SSM_CMD_GET_OCP_THRESHOLD";
        case 20    : return "SSM_CMD_GET_SYS_STATE";
        case 21    : return "SSM_CMD_SWITCH_LOW_POWER";
        case 22    : return "SSM_CMD_SET_LTC2635_VREF";
        case 23    : return "SSM_CMD_SET_MCPHY_VREF";
        case 24    : return "SSM_CMD_GET_RCALIBRATION_PARA";
        case 25    : return "SSM_CMD_EMC1412_I2C";
        case 26    : return "SSM_CMD_EXT_PWR_MONITOR";
        case 27    : return "SSM_CMD_SET_SOC_DOMAIN_FREQ";
        case 28    : return "SSM_CMD_FORCE_SIP_HARVEST";
        case 29    : return "SSM_CMD_GET_REMOTE_ESL_IDX";
        case 30    : return "SSM_CMD_SSM_AVS_CMD";
        case 31    : return "SSM_CMD_SET_SSM_FREQ";
        case 32    : return "SSM_CMD_GET_HBM_ECC";
        case 33    : return "SSM_CMD_SET_HBM_ECC";
        case 34    : return "SSM_CMD_GET_MANU_NAME";
        case 35    : return "SSM_CMD_RFW_LOAD_FINISH";
        case 36    : return "SSM_CMD_WRITE_DRIVER_VERSION";
        case 37    : return "SSM_CMD_GET_FW_VER";
        case 38    : return "SSM_CMD_KFC_LEVEL_SET_GET";
        case 39    : return "SSM_CMD_GET_HBM_ERROR_START_ENTRY";
        case 40    : return "SSM_CMD_SEND_PMBUS_CMD";
        case 41    : return "SSM_CMD_PID_FEED_DATA_CONTROL";
        case 42    : return "SSM_CMD_SSM_REG_READ";
        case 43    : return "SSM_CMD_SSM_REG_WRITE";
        case 44    : return "SSM_CMD_BOARD_TYPE";
        case 45    : return "SSM_CMD_IVM_GIT_REV";
        case 46    : return "SSM_CMD_SSM_GIT_REV";
        case 47    : return "SSM_CMD_FEATURE_VR_ENABLE";
        case 48    : return "SSM_CMD_PWM_CONFIG";
        case 49    : return "SSM_CMD_PID_CONFIG";
        case 50    : return "SSM_CMD_PLL_OBSERVE_ON";
        case 51    : return "SSM_CMD_PLL_OBSERVE_OFF";
        case 52    : return "SSM_CMD_FEATURE_TSENSOR_ENABLE";
        case 53    : return "SSM_CMD_PID_ENABLE";
        case 54    : return "SSM_CMD_PN_WRITE";
        case 55    : return "SSM_CMD_PN_READ";
        case 56    : return "SSM_CMD_SN_WRITE";
        case 57    : return "SSM_CMD_SN_READ";
        case 58    : return "SSM_CMD_PID_POINT_CONFIG";
        case 59    : return "SSM_CMD_PID_STATUS";
        case 60    : return "SSM_CMD_BOOT_HEALTH";
        case 61    : return "SSM_CMD_FEATURE_ENABLE";
        case 62    : return "SSM_CMD_FEATURE_STATUS";
        case 63    : return "SSM_CMD_INTERRUPT_EN";
        case 64    : return "SSM_CMD_CCIX_EN";
        case 65    : return "SSM_CMD_CCIX_DIS";
        case 66    : return "SSM_CMD_CCIX_LS_SWITCH";
        case 67    : return "SSM_CMD_CCIX_GET_UUID";
        case 68    : return "SSM_CMD_OPENFLAG_WRITE";
        case 69    : return "SSM_CMD_OPENFLAG_READ";
        case 70    : return "SSM_CMD_GET_TOTAL_POWER_CAP";
        case 71    : return "SSM_CMD_QDD_READ";
        case 72    : return "SSM_CMD_BLR";
        case 73    : return "SSM_CMD_TOGGLE_AMC";
        case 74    : return "SSM_CMD_GET_IMU_VER";
        case 75    : return "SSM_CMD_CHECK_AMC_ALIVE";
        case 76    : return "SSM_CMD_GET_HBM_RMA_CONFIG";
        case 77    : return "SSM_CMD_GET_AMC_VERSION";
        case 78    : return "SSM_CMD_FORCE_AMC_DEAD";
        case 79    : return "SSM_CMD_UNLOCK_REQ";
        case 80    : return "SSM_CMD_UNLOCK_TRIG";
        case 81    : return "SSM_CMD_FW_UPDATE";
        case 82    : return "SSM_CMD_SEND_DATA_TO_AMC";
        case 83    : return "SSM_CMD_GET_ASIC_VER";
        case 84    : return "SSM_CMD_TRIGGER_AMC_UPDATE";
        case 85    : return "SSM_CMD_GET_AMC_UPDATE_PROGRESS";
        case 86    : return "SSM_CMD_GET_AMC_RESET_STATUS";
        case 87    : return "SSM_CMD_AGING_GB_CONFIG";
        case 88    : return "SSM_CMD_SET_DAC5683R_VREF";
        case 89    : return "SSM_CMD_SET_VDEC_FREQ";
        case 90    : return "SSM_CMD_GET_I2CHUB_TEST_RESULT";
        case 91    : return "SSM_CMD_VERIFY_AMC_FW";
        case 92    : return "SSM_CMD_E2PROM_READ_WRITE";
        case 93    : return "SSM_CMD_GET_AMC_ADC_TEST_RESULT";
        case 94    : return "SSM_CMD_GET_BOARD_AVE_POWER";
        case 95    : return "SSM_CMD_MC_INTERRUPT_CTRL";
        case 96    : return "SSM_CMD_GET_MC_SWIZZLE";
        case 97    : return "SSM_CMD_SET_MC_SWIZZLE";
        case 98    : return "SSM_CMD_12V_EDC_CONTROL";
        case 99    : return "SSM_CMD_VR0_HOT_CONTROL";
        case 100   : return "SSM_CMD_GSYNC_CONTROL";
        case 101   : return "SSM_CMD_AMC_DOWNLOAD_MODE";
        case 102   : return "SSM_CMD_GET_BOARD_REV";
        case 103   : return "SSM_CMD_GET_CHIP_UUID";
        case 104   : return "SSM_CMD_GET_BOOT_ERROR_CODE";
        case 105   : return "SSM_CMD_GET_LP_MODE_STS";
        case 106   : return "SSM_CMD_SET_GLOBAL_TIME";
        case 107   : return "SSM_CMD_GET_FLASH_ID_FROM_AMC";
        case 108   : return "SSM_CMD_GET_E2PROM_READ_DATA";
        case 109   : return "SSM_CMD_GET_LOG_FROM_AMC_FLASH";
        case 110   : return "SSM_CMD_POWER_MODE_CONFIG";
        case 111   : return "SSM_CMD_AASP_LANE_CFG";
        case 112   : return "SSM_CMD_AASP_SPEED_SWITCH";
        case 113   : return "SSM_CMD_AASP_DESIGN_MODE_SWITCH";
        case 114   : return "SSM_CMD_XMC_FAULT_SWITCH";
        case 115   : return "SSM_CMD_XMC_HASH_CFG";
        case 116   : return "SSM_CMD_LDIDT_EDC_CONTROL";
        case 117   : return "SSM_CMD_XMC_ADJUST";
        case 118   : return "SSM_CMD_CLEAR_GLB_TMR";
        case 119   : return "SSM_CMD_ANALOGBITS_GD_CONFIG";
        case 120   : return "SSM_CMD_JIANCHONG_GD_CONFIG";
        case 121   : return "SSM_CMD_ANALOGBITS_GD_UPDATE";
        case 122   : return "SSM_CMD_JIANCHONG_GD_UPDATE";
        case 123   : return "SSM_CMD_SET_HBM_ERROR";
        case 124   : return "SSM_CMD_GET_FW_PROTECT";
        case 125   : return "SSM_CMD_POWER_OP";
        case 126   : return "SSM_CMD_KMD_STATUS";
        case 127   : return "SSM_CMD_VF_CREATE";
        case 128   : return "SSM_CMD_VF_REMOVE";
        case 129   : return "SSM_CMD_DPF_FLUSH";
        case 130   : return "SSM_CMD_RAS_CFG";
        case 131   : return "SSM_CMD_PRE_FLR_CFG";
        case 132   : return "SSM_CMD_PCIE_FLR";
        case 133   : return "SSM_CMD_CRYPTO_OP";
        case 134   : return "SSM_CMD_XMC_L2C_ENABLE";
        case 135   : return "SSM_CMD_GET_CABLE_QUALIFY";
        case 136   : return "SSM_CMD_PWR_STOCK_TH_ADJUST";
        case 137   : return "SSM_CMD_MMU_STATIC_CONFIG";
        case 138   : return "SSM_CMD_CACHE_CONFIG";
        case 139   : return "SSM_CMD_USE_SPECIAL_VF_TABLE";
        case 140   : return "SSM_CMD_GET_HBM_ERROR_NEXT_ENTRY";
        case 141   : return "SSM_CMD_WRITE_PROTECT";
        case 142   : return "SSM_CMD_POWR_MODE_CONFIG_SRIOV";
        case 143   : return "SSM_CMD_ESL_HARVEST";
        case 144   : return "SSM_CMD_ATOMIC_FIREWALL";
        case 145   : return "SSM_CMD_VR_INFO_DUMP_BY_PAGE";
        case 146   : return "SSM_CMD_G6_LOW_POWER_MODE";
        case 147   : return "SSM_CMD_ESL_ADJUST";
        case 148   : return "SSM_CMD_READ_G6_IDCODE";
        case 149   : return "SSM_CMD_PF_FLR_VOLT_FREQ_RESUME";
        case 150   : return "SSM_CMD_TOTAL_COUNT";
        case 0xfffc: return "SSM_CMD_TEST_FUNC";
        case 0xfffd: return "SSM_CMD_BOOT_ERROR";
        case 0xfffe: return "SSM_CMD_BOOT_COMPLETE";
        case 0xffff: return "SSM_CMD_PING";
    }
    // clang-format on

    return std::string("SSM_CMD_TBD_" + std::to_string(fw_cmd));
}

inline static std::string dec_ssm_fw_dbg_cmd(uint32_t &fw_cmd) {
    // clang-format off
    switch (fw_cmd) {
        case 1     : return "DBG_CMD_GET_SOCHBM_TEMP";
        case 2     : return "DBG_CMD_GET_FLR_STATUS";
        case 3     : return "DBG_CMD_GET_MAX_DPM_LEVEL";
        case 4     : return "DBG_CMD_GET_DPM_LEVEL";
        case 5     : return "DBG_CMD_GET_CCIX_STATUS";
        case 6     : return "DBG_CMD_PREPARE_UPDATE_FW";
        case 7     : return "DBG_CMD_SET_MAX_DPM_LEVEL";
        case 8     : return "DBG_CMD_SET_DPM_LEVEL";
        case 9     : return "DBG_CMD_PREPARE_UPDATE_RFW";
        case 10    : return "DBG_CMD_SET_DTU_FREQ";
        case 11    : return "DBG_CMD_SET_EDF_FREQ";
        case 12    : return "DBG_CMD_SET_MC_FREQ";
        case 13    : return "DBG_CMD_GET_COMPILE_TIME";         // NOLINT DBG_CMD_SET_ASIC_CTFE
        case 14    : return "DBG_CMD_GET_MANU_DATE";            // NOLINT DBG_CMD_SET_HBM_CTF
        case 15    : return "DBG_CMD_SET_MANU_DATE";
        case 16    : return "DBG_CMD_GET_MODEL";
        case 17    : return "DBG_CMD_SET_MODEL";
        case 18    : return "DBG_CMD_UPDATE_OCP_THRESHOLD";
        case 19    : return "DBG_CMD_GET_OCP_THRESHOLD";
        case 20    : return "DBG_CMD_GET_SYS_STATE";
        case 21    : return "DBG_CMD_SWITCH_LOW_POWER";
        case 22    : return "DBG_CMD_SET_LTC2635_VREF";
        case 23    : return "DBG_CMD_SET_MCPHY_VREF";
        case 24    : return "DBG_CMD_GET_RCALIBRATION_PARA";
        case 25    : return "DBG_CMD_EMC1412_I2C";
        case 26    : return "DBG_CMD_EXT_PWR_MONITOR";          // NOLINT DBG_CMD_SLT_FEAT_ENABLE
        case 27    : return "DBG_CMD_SET_SOC_DOMAIN_FREQ";      // NOLINT DBG_CMD_SLT_FEAT_STATUS
        case 28    : return "DBG_CMD_FORCE_SIP_HARVEST";        // NOLINT DBG_CMD_SET_ASIC_HYST_TEMP
        case 29    : return "DBG_CMD_GET_REMOTE_ESL_IDX";
        case 30    : return "DBG_CMD_SSM_AVS_CMD";              // NOLINT DBG_CMD_HBM_ERR_SCAN
        case 31    : return "DBG_CMD_SET_SSM_FREQ";             // NOLINT DBG_CMD_HBM_ERR_SCAN_TEST
        case 32    : return "DBG_CMD_GET_HBM_ECC";
        case 33    : return "DBG_CMD_SET_HBM_ECC";
        case 34    : return "DBG_CMD_GET_MANU_NAME";
        case 35    : return "DBG_CMD_RFW_LOAD_FINISH";
        case 37    : return "DBG_CMD_GET_FW_VER";
        case 38    : return "DBG_CMD_KFC_LEVEL_SET_GET";
        case 40    : return "DBG_CMD_SEND_PMBUS_CMD";
        case 41    : return "DBG_CMD_PID_FEED_DATA_CONTROL";    // NOLINT DBG_CMD_DPM_FEED_DATA_CONTROL
        case 42    : return "DBG_CMD_SSM_REG_READ";
        case 43    : return "DBG_CMD_SSM_REG_WRITE";
        case 44    : return "DBG_CMD_BOARD_TYPE";
        case 45    : return "DBG_CMD_IVM_GIT_REV";
        case 46    : return "DBG_CMD_SSM_GIT_REV";
        case 47    : return "DBG_CMD_FEATURE_VR_ENABLE";
        case 48    : return "DBG_CMD_PWM_CONFIG";
        case 49    : return "DBG_CMD_PID_CONFIG";
        case 50    : return "DBG_CMD_PLL_OBSERVE_ON";
        case 51    : return "DBG_CMD_PLL_OBSERVE_OFF";
        case 52    : return "DBG_CMD_FEATURE_TSENSOR_ENABLE";
        case 53    : return "DBG_CMD_PID_ENABLE";               // NOLINT DBG_CMD_DPM_ENABLE
        case 54    : return "DBG_CMD_PN_WRITE";
        case 55    : return "DBG_CMD_PN_READ";
        case 56    : return "DBG_CMD_SN_WRITE";
        case 57    : return "DBG_CMD_SN_READ";
        case 58    : return "DBG_CMD_PID_POINT_CONFIG";         // NOLINT DBG_CMD_DPM_POINT_CONFIG
        case 59    : return "DBG_CMD_PID_STATUS";               // NOLINT DBG_CMD_DPM_STATUS
        case 60    : return "DBG_CMD_BOOT_HEALTH";
        case 61    : return "DBG_CMD_FEATURE_ENABLE";
        case 62    : return "DBG_CMD_FEATURE_STATUS";
        case 63    : return "DBG_CMD_INTERRUPT_EN";
        case 64    : return "DBG_CMD_CCIX_EN";
        case 65    : return "DBG_CMD_CCIX_DIS";
        case 66    : return "DBG_CMD_CCIX_LS_SWITCH";
        case 67    : return "DBG_CMD_CCIX_GET_UUID";
        case 68    : return "DBG_CMD_OPENFLAG_WRITE";
        case 69    : return "DBG_CMD_OPENFLAG_READ";
        case 70    : return "DBG_CMD_GET_TOTAL_POWER_CAP";
        case 71    : return "DBG_CMD_QDD_READ";
        case 72    : return "DBG_CMD_BLR";
        case 73    : return "DBG_CMD_TOGGLE_AMC";
        case 74    : return "DBG_CMD_GET_IMU_VER";
        case 75    : return "DBG_CMD_CHECK_AMC_ALIVE";
        case 76    : return "DBG_CMD_GET_HBM_RMA_CONFIG";
        case 77    : return "DBG_CMD_GET_AMC_VERSION";
        case 78    : return "DBG_CMD_FORCE_AMC_DEAD";
        case 79    : return "DBG_CMD_UNLOCK_REQ";
        case 80    : return "DBG_CMD_UNLOCK_TRIG";
        case 81    : return "DBG_CMD_FW_UPDATE";
        case 82    : return "DBG_CMD_SEND_DATA_TO_AMC";
        case 83    : return "DBG_CMD_GET_ASIC_VER";
        case 84    : return "DBG_CMD_TRIGGER_AMC_UPDATE";
        case 85    : return "DBG_CMD_GET_AMC_UPDATE_PROGRESS";
        case 86    : return "DBG_CMD_GET_AMC_RESET_STATUS";
        case 87    : return "DBG_CMD_AGING_GB_CONFIG";
        case 88    : return "DBG_CMD_SET_DAC5683R_VREF";
        case 89    : return "DBG_CMD_SET_VDEC_FREQ";
        case 90    : return "DBG_CMD_GET_I2CHUB_TEST_RESULT";
        case 91    : return "DBG_CMD_VERIFY_AMC_FW";
        case 92    : return "DBG_CMD_E2PROM_READ_WRITE";
        case 93    : return "DBG_CMD_GET_AMC_ADC_TEST_RESULT";
        case 94    : return "DBG_CMD_GET_BOARD_AVE_POWER";
        case 95    : return "DBG_CMD_MC_INTERRUPT_CTRL";
        case 96    : return "DBG_CMD_GET_MC_SWIZZLE";
        case 97    : return "DBG_CMD_SET_MC_SWIZZLE";
        case 98    : return "DBG_CMD_12V_EDC_CONTROL";
        case 99    : return "DBG_CMD_VR0_HOT_CONTROL";
        case 100   : return "DBG_CMD_GSYNC_CONTROL";
        case 101   : return "DBG_CMD_AMC_DOWNLOAD_MODE";
        case 102   : return "DBG_CMD_GET_BOARD_REV";
        case 103   : return "DBG_CMD_GET_CHIP_UUID";
        case 104   : return "DBG_CMD_GET_BOOT_ERROR_CODE";
        case 105   : return "DBG_CMD_GET_LP_MODE_STS";
        case 106   : return "DBG_CMD_SET_GLOBAL_TIME";
        case 107   : return "DBG_CMD_GET_FLASH_ID_FROM_AMC";
        case 108   : return "DBG_CMD_GET_E2PROM_READ_DATA";
        case 109   : return "DBG_CMD_GET_LOG_FROM_AMC_FLASH";
        case 110   : return "DBG_CMD_POWER_MODE_CONFIG";
        case 111   : return "DBG_CMD_AASP_LANE_CFG";
        case 112   : return "DBG_CMD_AASP_SPEED_SWITCH";
        case 113   : return "DBG_CMD_AASP_DESIGN_MODE_SWITCH";
        case 114   : return "DBG_CMD_XMC_FAULT_SWITCH";
        case 115   : return "DBG_CMD_XMC_HASH_DISABLE";
        case 116   : return "DBG_CMD_LDIDT_EDC_CONTROL";
        case 117   : return "DBG_CMD_REMOVE_VG_HOLE";
        case 118   : return "DBG_CMD_CLEAR_GLB_TMR";
        case 119   : return "DBG_CMD_ANALOGBITS_GD_CONFIG";
        case 120   : return "DBG_CMD_JIANCHONG_GD_CONFIG";
        case 121   : return "DBG_CMD_ANALOGBITS_GD_UPDATE";
        case 122   : return "DBG_CMD_JIANCHONG_GD_UPDATE";
        case 0xfffc: return "DBG_CMD_TEST_FUNC";
        case 0xfffd: return "DBG_CMD_BOOT_ERROR";
        case 0xfffe: return "DBG_CMD_BOOT_COMPLETE";
        case 0xffff: return "DBG_CMD_PING";
        default: break;
    }
    // clang-format on

    return std::string("DBG_CMD_TBD_" + std::to_string(fw_cmd));
}

inline static std::string dec_ssm_fw_drv_cmd(uint32_t &fw_cmd) {
    // clang-format off
    switch (fw_cmd) {
        case 0x1   : return "DRIVER_CMD_GET_SOCHBM_TEMP";
        case 0x2   : return "DRIVER_CMD_GET_VR_TEMP";
        case 0x3   : return "DRIVER_CMD_GET_HARVESTING";
        case 0x4   : return "DRIVER_CMD_INTERRUPT_EN";
        case 0x5   : return "DRIVER_CMD_HBM_ECC_EN";
        case 0x6   : return "DRIVER_CMD_ENABLE_CCIX";
        case 0x7   : return "DRIVER_CMD_DISABLE_CCIX";
        case 0x8   : return "DRIVER_CMD_PREPARE_RFW_UPDATE";
        case 0x9   : return "DRIVER_CMD_GET_DPM_LEVEL";
        case 0xa   : return "DRIVER_CMD_GET_CCIX_STATUS";
        case 0xb   : return "DRIVER_CMD_PN_READ";
        case 0xc   : return "DRIVER_CMD_SN_READ";
        case 0xd   : return "DRIVER_CMD_SET_DPM_LEVEL";
        case 0xe   : return "DRIVER_CMD_RFW_LOAD_FINISH";
        case 0xf   : return "DRIVER_CMD_GET_FW_VER";
        case 0x10  : return "DRIVER_CMD_GET_SYS_STATE";
        case 0x11  : return "DRIVER_CMD_SWITCH_LOW_POWER";
        case 0x12  : return "DRIVER_CMD_PRE_FLR_CFG";
        case 0x13  : return "DRIVER_CMD_SET_GLOBAL_TIME";
        case 0x14  : return "DRIVER_CMD_PREPARE_FW_UPDATE";
        case 0x15  : return "DRIVER_CMD_CCIX_LS_SWITCH";
        case 0x16  : return "DRIVER_CMD_CCIX_GET_UUID";
        case 0x17  : return "DRIVER_CMD_WRITE_REG";
        case 0x18  : return "DRIVER_CMD_READ_REG";
        case 0x19  : return "DRIVER_WRITE_DRIVER_VERSION";
        case 0x1a  : return "DRIVER_GET_HBM_ERROR_START_ENTRY";
        case 0x1b  : return "DRIVER_GET_HBM_ERROR_NEXT_ENTRY";
        case 0x1c  : return "DRIVER_MEMORY_SCAN";
        case 0x1d  : return "DRIVER_SET_HBM_ERROR";
        case 0x1e  : return "DRIVER_GET_FW_PROTECT_STATUS";
        case 0x1f  : return "DRIVER_CMD_GET_REMOTE_ESL_IDX";
        case 0x20  : return "DRIVER_CMD_AVC_UPDATE";
        case 0x21  : return "DRIVER_CMD_GET_ESL_RC_EP";
        case 0x22  : return "DRIVER_CMD_GET_ECC_STATUS";
        case 0x25  : return "DRIVER_CMD_FW_UPDATE";
        case 0x26  : return "DRIVER_CMD_BLR";
        case 0x27  : return "DRIVER_CMD_MC_INTERRUPT_CTRL";
        case 0x28  : return "DRIVER_CMD_GET_CCIX_CABLE_INSERT";
        case 0x29  : return "DRIVER_CMD_GET_FLR_STATUS";
        case 0x2a  : return "DRIVER_CMD_GET_CCIX_SPEED_LP";
        case 0x2b  : return "DRIVER_CMD_GET_AMC_VERSION";
        case 0x2c  : return "DRIVER_CMD_FEATURE_ENABLE";
        case 0x2d  : return "DRIVER_CMD_POWER_OP";
        case 0x2e  : return "DRIVER_CMD_KMD_STATUS";
        case 0x2f  : return "DRIVER_CMD_GET_HBM_RMA_CONFIG";
        case 0x30  : return "DRIVER_CMD_VF_CREATE";
        case 0x31  : return "DRIVER_CMD_VF_REMOVE";
        case 0x32  : return "DRIVER_CMD_GET_MAX_DPM_LEVEL";
        case 0x33  : return "DRIVER_CMD_SET_MAX_DPM_LEVEL";
        case 0x34  : return "DRIVER_CMD_DPF_FLUSH";
        case 0x35  : return "DRIVER_CMD_RAS_CFG";
        case 0x1000: return "DRV_CMD_EFSMI_START";
        case 0x1001: return "DRV_CMD_GET_IMU_VER";
        case 0x1002: return "DRV_CMD_GET_ASIC_VER";
        case 0x1003: return "DRV_CMD_GET_TOTAL_POWER_CAP";
        case 0x1004: return "DRV_CMD_GET_BOARD_AVE_POWER";
        case 0x1005: return "DRV_CMD_GET_MC_SWIZZLE";
        case 0x1006: return "DRV_CMD_BOARD_TYPE";
        case 0x1007: return "DRV_CMD_IVM_GIT_REV";
        case 0x1008: return "DRV_CMD_SSM_GIT_REV";
        case 0x1009: return "DRV_CMD_EMC1412_OPERATION";
        case 0x100A: return "DRV_CMD_PMBUS_OPERATION";
        case 0x100B: return "DRV_CMD_MEM_ECC_GET";
        case 0x100C: return "DRV_CMD_MEM_ECC_SET";
        case 0x100D: return "DRV_CMD_EFSMI_TOTAL";
        case 0xfffc: return "DRIVER_CMD_GET_API_VERSION";
        case 0xfffd: return "DRIVER_CMD_BOOT_ERROR";
        case 0xfffe: return "DRIVER_CMD_BOOT_COMPLETE";
        case 0xffff: return "DRIVER_CMD_PING";
        default: break;
    }
    // clang-format on

    return std::string("DRIVER_CMD_TBD_" + std::to_string(fw_cmd));
}

}  // namespace cmd
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_CMD_NS_HPP_
