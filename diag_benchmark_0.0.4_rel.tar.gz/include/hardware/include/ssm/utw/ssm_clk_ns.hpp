/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_CLK_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_CLK_NS_HPP_

#include <iomanip>
#include <map>
#include <string>
#include <vector>

namespace efvf {
namespace hardware {
namespace ssm {
namespace clk {

enum kSsmClk {
    kClkIdInvalid = 0,
    kPllIdInvalid,
    kBrcIdInvalid,

    kClk0,
    kClk0_T0,
    kClk0_T1,
    kClk1,
    kClk1_T0,
    kClk1_T1,
    kClk2,
    kClk2_T0,
    kClk2_T1,
    kClk2_T2,
    kClk2_T3,
    kClk3,
    kClk3_T0,
    kClk3_T1,
    kClk3_T2,
    kClk4,
    kClk4_T0,
    kClk4_T1,
    kClk5,
    kClk5_T0,
    kClk5_T1,

    kClk_A0,  // branch A
    kClk_A1,
    kClk_A2,
    kClk_A3,
    kClk_A4,
    kClk_A5,
    kClk_A6,
    kClk_B0,  // branch B
    kClk_B1,
    kClk_B2,
    kClk_B3,
    kClk_B4,
    kClk_B5,
    kClk_B6,
    kClk_B7,
    kClk_B8,
    kClk_C0,  // branch C
    kClk_C1,
    kClk_C2,
    kClk_C3,
    kClk_D0,  // branch D
    kClk_D1,
    kClk_D2,
    kClk_D3,
    kClk_R0,  // branch reference
    kClk_R1,
    kClk_R2,

    kMux_L1M0,  // mux output
    kMux_L1M1,

    kPll0,
    kPll1,
    kPll2,
    kPll3,
    kPll4,
    kPll5,
    kPll_HS,

    kClkxPllxTx,

    kClkEcf,
    kClkEcf_L,
    kClkEcf_R,
    kClkEcf_B,
    kClkEcfEdfNet,
    kClkEcfEdfNet_L,
    kClkEcfEdfNet_R,
    kClkEcfEdfNet_B,
    kClkEcfSicio,
    kClkEcfSicio_0,
    kClkEcfSicio_1,
    kClkEcfSicio_2,
    kClkEcfSicio_3,

    kClkEdf,
    kClkEdfFix,
    kClkEdf_L,
    kClkEdf_R,
    kClkEdf_B,
    kClkEdfNocService,
    kClkEdfNocService_L,
    kClkEdfNocService_R,
    kClkEdfNocService_B,
    kClkEdfSicio,
    kClkEdfSicio_0,
    kClkEdfSicio_1,
    kClkEdfSicio_2,
    kClkEdfSicio_3,
    kClkEdfInterChange,

    kClkAxi,
    kClkAxiDft,
    kClkAxiPcie,
    kClkAxiEsl,
    kClkAxiCcix,
    kClkAxiAasp,

    kClkAux,
    kClkAuxPcie,
    kClkAuxEsl,
    kClkAuxCcix,
    kClkAuxAasp,

    kClkCtrl,
    kClkDfd,
    kClkUcie,
    kClkMemRepDft,
    kClkMemRepVpp_0,
    kClkMemRepVpp_1,
    kClkClusterLite,
    kClkBoostPipe,

    kClkSsm,
    kClkSsmSip,
    kClkSip,
    kClkSic_L,
    kClkSic_R,
    kClkSic_T,
    kClkSic_B,
    kClkCcf,
    kClkCcf_T,
    kClkCcf_B,
    kClkDsm,
    kClkDsm_T,
    kClkDsm_B,
    kClkCqm,
    kClkMcu,
    kClkTs,
    kClkHcvg,
    kClkVdec,
    kClkVpp,
    kClkVpp_0,
    kClkVpp_1,
    kClkVpu,
    kClkCva,
    kClkAp,
    kClkApMisc,
    kClkApMisc_0,
    kClkApMisc_1,
    kClkApCore,
    kClkApCore_0,
    kClkApCore_1,
    kClkSp,
    kClkSpCore,
    kClkAaspCpu,
    kClkAaspApb,
    kClkEslCore,
    kClkL2,
    kClkL2_L,
    kClkL2_R,

    kClkEngine,
    kClkCdma,
    kClkOdma,
    kClkSdma,
    kClkCdte,
    kClkOdte,
    kClkEdte,
    kClkCbf,
    kClkGmu,
    kClkDpf,
    kClkLlc,
    kClkMmu,

    kClkMc,
    kClkMc_0,
    kClkMc_1,
    kClkMc_2,
    kClkMc_3,
    kClkMc_L,
    kClkMc_R,
    kClkMcCore,
    kClkMcCore_0,
    kClkMcCore_1,
    kClkMcCore_2,
    kClkMcCore_3,
    kClkMcRef,
    kClkMcRef_L,
    kClkMcRef_R,
    kClkMcRef_0,
    kClkMcRef_1,
    kClkMcRef_2,
    kClkMcRef_3,
    kClkMcReg,
    kClkMcReg_L,
    kClkMcReg_R,
    kClkMemPhy,
    kClkMemPhy_L,
    kClkMemPhy_R,
    kClkMdf,
    kClkMdf_0,
    kClkMdf_1,

    kClkMax,
};

inline std::string top_id_2str(uint32_t top_id) {
    // clang-format off
    switch (top_id) {
        case kClkIdInvalid: return "TOPx_NA";
        case kClk0:         return "CLK0_Tx";
        case kClk0_T0:      return "CLK0_T0";
        case kClk0_T1:      return "CLK0_T1";
        case kClk1:         return "CLK1_Tx";
        case kClk1_T0:      return "CLK1_T0";
        case kClk1_T1:      return "CLK1_T1";
        case kClk2:         return "CLK2_Tx";
        case kClk2_T0:      return "CLK2_T0";
        case kClk2_T1:      return "CLK2_T1";
        case kClk2_T2:      return "CLK2_T2";
        case kClk2_T3:      return "CLK2_T3";
        case kClk3:         return "CLK3_Tx";
        case kClk3_T0:      return "CLK3_T0";
        case kClk3_T1:      return "CLK3_T1";
        case kClk3_T2:      return "CLK3_T2";
        case kClk4:         return "CLK4_Tx";
        case kClk4_T0:      return "CLK4_T0";
        case kClk4_T1:      return "CLK4_T1";
        case kClk5:         return "CLK5_Tx";
        case kClk5_T0:      return "CLK5_T0";
        case kClk5_T1:      return "CLK5_T1";
        default: break;
    }
    // clang-format on

    return "TOP_ID_UDEF";
}

inline uint32_t top_id_2enum(const std::string id) {
    // clang-format off
    if (("clk0"    == id) || ("CLK0"    == id)) return kClk0;
    if (("clk0_tx" == id) || ("CLK0_TX" == id)) return kClk0;
    if (("clk0_t0" == id) || ("CLK0_T0" == id)) return kClk0_T0;
    if (("clk0_t1" == id) || ("CLK0_T1" == id)) return kClk0_T1;
    if (("clk1"    == id) || ("CLK1"    == id)) return kClk1;
    if (("clk1_t0" == id) || ("CLK1_T0" == id)) return kClk1_T0;
    if (("clk1_t1" == id) || ("CLK1_T1" == id)) return kClk1_T1;
    if (("clk2"    == id) || ("CLK2"    == id)) return kClk2;
    if (("clk2_t0" == id) || ("CLK2_T0" == id)) return kClk2_T0;
    if (("clk2_t1" == id) || ("CLK2_T1" == id)) return kClk2_T1;
    if (("clk2_t2" == id) || ("CLK2_T2" == id)) return kClk2_T2;
    if (("clk2_t3" == id) || ("CLK2_T3" == id)) return kClk2_T3;
    if (("clk3"    == id) || ("CLK3"    == id)) return kClk3;
    if (("clk3_t0" == id) || ("CLK3_T0" == id)) return kClk3_T0;
    if (("clk3_t1" == id) || ("CLK3_T1" == id)) return kClk3_T1;
    if (("clk3_t2" == id) || ("CLK3_T2" == id)) return kClk3_T2;
    if (("clk4"    == id) || ("CLK4"    == id)) return kClk4;
    if (("clk4_t0" == id) || ("CLK4_T0" == id)) return kClk4_T0;
    if (("clk4_t1" == id) || ("CLK4_T1" == id)) return kClk4_T1;
    if (("clk5"    == id) || ("CLK5"    == id)) return kClk5;
    if (("clk5_t0" == id) || ("CLK5_T0" == id)) return kClk5_T0;
    if (("clk5_t1" == id) || ("CLK5_T1" == id)) return kClk5_T1;
    // clang-format on

    return kClkIdInvalid;
}

inline std::string branch_id_2str(uint32_t brc_id) {
    // clang-format off
    switch (brc_id) {
        case kBrcIdInvalid: return "BRC_NA";
        case kClk_A0:       return "CLK_A0";
        case kClk_A1:       return "CLK_A1";
        case kClk_A2:       return "CLK_A2";
        case kClk_A3:       return "CLK_A3";
        case kClk_A4:       return "CLK_A4";
        case kClk_A5:       return "CLK_A5";
        case kClk_A6:       return "CLK_A6";
        case kClk_B0:       return "CLK_B0";
        case kClk_B1:       return "CLK_B1";
        case kClk_B2:       return "CLK_B2";
        case kClk_B3:       return "CLK_B3";
        case kClk_B4:       return "CLK_B4";
        case kClk_B5:       return "CLK_B5";
        case kClk_B6:       return "CLK_B6";
        case kClk_B7:       return "CLK_B7";
        case kClk_B8:       return "CLK_B8";
        case kClk_C0:       return "CLK_C0";
        case kClk_C1:       return "CLK_C1";
        case kClk_C2:       return "CLK_C2";
        case kClk_C3:       return "CLK_C3";
        case kClk_D0:       return "CLK_D0";
        case kClk_D1:       return "CLK_D1";
        case kClk_D2:       return "CLK_D2";
        case kClk_D3:       return "CLK_D3";
        case kClk_R0:       return "REF_00";
        case kClk_R1:       return "REF_01";
        case kClk_R2:       return "REF_02";
        case kMux_L1M0:     return "M_L1M0";
        case kMux_L1M1:     return "M_L1M1";
        default: break;
    }
    // clang-format on

    return "BRC_ID_UDEF";
}

inline std::string pll_id_2str(uint32_t pll_id) {
    // clang-format off
    switch (pll_id) {
        case kPllIdInvalid: return "PLL_NA";
        case kPll0:         return "PLL_00";
        case kPll1:         return "PLL_01";
        case kPll2:         return "PLL_02";
        case kPll3:         return "PLL_03";
        case kPll4:         return "PLL_04";
        case kPll5:         return "PLL_05";
        case kPll_HS:       return "PLL_HS";
        default: break;
    }
    // clang-format on

    return "PLL_ID_UDEF";
}

inline std::string clk_id_2str(uint32_t clk_id) {
    // clang-format off
    switch (clk_id) {
        case kClkIdInvalid:         return "CLK_NA";
        case kClkEcf:               return "ECF";
        case kClkEcf_L:             return "ECF_L";
        case kClkEcf_R:             return "ECF_R";
        case kClkEcf_B:             return "ECF_B";
        case kClkEcfEdfNet:         return "ECF_EDF_Net";
        case kClkEcfEdfNet_L:       return "ECF_EDF_Net_L";
        case kClkEcfEdfNet_R:       return "ECF_EDF_Net_R";
        case kClkEcfEdfNet_B:       return "ECF_EDF_Net_B";
        case kClkEcfSicio:          return "ECF_SICIO";
        case kClkEcfSicio_0:        return "ECF_SICIO_0";
        case kClkEcfSicio_1:        return "ECF_SICIO_1";
        case kClkEcfSicio_2:        return "ECF_SICIO_2";
        case kClkEcfSicio_3:        return "ECF_SICIO_3";
        case kClkEdf:               return "EDF";
        case kClkEdfFix:            return "EDF_FIX";
        case kClkEdf_L:             return "EDF_L";
        case kClkEdf_R:             return "EDF_R";
        case kClkEdf_B:             return "EDF_B";
        case kClkEdfNocService:     return "EDF_NOC_SER";
        case kClkEdfNocService_L:   return "EDF_NOC_SER_L";
        case kClkEdfNocService_R:   return "EDF_NOC_SER_R";
        case kClkEdfNocService_B:   return "EDF_NOC_SER_B";
        case kClkEdfSicio:          return "EDF_SICIO";
        case kClkEdfSicio_0:        return "EDF_SICIO_0";
        case kClkEdfSicio_1:        return "EDF_SICIO_1";
        case kClkEdfSicio_2:        return "EDF_SICIO_2";
        case kClkEdfSicio_3:        return "EDF_SICIO_3";
        case kClkEdfInterChange:    return "EDF_INTERCHANGE";
        case kClkAxi:               return "AXI";
        case kClkAxiDft:            return "AXI_DFT";
        case kClkAxiPcie:           return "AXI_PCIE";
        case kClkAxiEsl:            return "AXI_ESL";
        case kClkAxiCcix:           return "AXI_CCIX";
        case kClkAxiAasp:           return "AXI_AASP";
        case kClkAux:               return "AUX";
        case kClkAuxPcie:           return "AUX_PCIE";
        case kClkAuxEsl:            return "AUX_ESL";
        case kClkAuxCcix:           return "AUX_CCIX";
        case kClkAuxAasp:           return "AUX_AASP";
        case kClkCtrl:              return "CTRL";
        case kClkDfd:               return "DFD";
        case kClkUcie:              return "UCIE";
        case kClkMemRepDft:         return "MEM_REP_DFT";
        case kClkMemRepVpp_0:       return "MEM_REP_VPP_0";
        case kClkMemRepVpp_1:       return "MEM_REP_VPP_1";
        case kClkClusterLite:       return "CLUSTERLITE";
        case kClkBoostPipe:         return "BOOST_PIPE";
        case kClkSsm:               return "SSM";
        case kClkSsmSip:            return "SSM_SIP";
        case kClkSip:               return "SIP";
        case kClkSic_L:             return "SIC_L";
        case kClkSic_R:             return "SIC_R";
        case kClkSic_T:             return "SIC_T";
        case kClkSic_B:             return "SIC_B";
        case kClkCcf:               return "CCF";
        case kClkCcf_T:             return "CCF_T";
        case kClkCcf_B:             return "CCF_B";
        case kClkDsm:               return "DSM";
        case kClkDsm_T:             return "DSM_T";
        case kClkDsm_B:             return "DSM_B";
        case kClkCqm:               return "CQM";
        case kClkMcu:               return "MCU";
        case kClkTs:                return "TS";
        case kClkHcvg:              return "HCVG";
        case kClkVdec:              return "VDEC";
        case kClkVpp:               return "VPP";
        case kClkVpp_0:             return "VPP_0";
        case kClkVpp_1:             return "VPP_1";
        case kClkVpu:               return "VPU";
        case kClkCva:               return "CVA";
        case kClkAp:                return "AP";
        case kClkApMisc:            return "AP_MISC";
        case kClkApMisc_0:          return "AP_MISC_0";
        case kClkApMisc_1:          return "AP_MISC_1";
        case kClkApCore:            return "AP_CORE";
        case kClkApCore_0:          return "AP_CORE_0";
        case kClkApCore_1:          return "AP_CORE_1";
        case kClkSp:                return "SP";
        case kClkSpCore:            return "SP_CORE";
        case kClkAaspCpu:           return "AASP_CPU";
        case kClkAaspApb:           return "AASP_APB";
        case kClkEslCore:           return "ESL_CORE";
        case kClkL2:                return "L2";
        case kClkL2_L:              return "L2_L";
        case kClkL2_R:              return "L2_R";
        case kClkEngine:            return "ENGINE";
        case kClkCdma:              return "CDMA";
        case kClkOdma:              return "ODMA";
        case kClkSdma:              return "SDMA";
        case kClkCdte:              return "CDTE";
        case kClkOdte:              return "ODTE";
        case kClkEdte:              return "EDTE";
        case kClkCbf:               return "CBF";
        case kClkGmu:               return "GMU";
        case kClkDpf:               return "DPF";
        case kClkLlc:               return "LLC";
        case kClkMmu:               return "MMU";
        case kClkMc:                return "MC";
        case kClkMc_0:              return "MC_0";
        case kClkMc_1:              return "MC_1";
        case kClkMc_2:              return "MC_2";
        case kClkMc_3:              return "MC_3";
        case kClkMc_L:              return "MC_L";
        case kClkMc_R:              return "MC_R";
        case kClkMcCore:            return "MC_CORE";
        case kClkMcCore_0:          return "MC_CORE_0";
        case kClkMcCore_1:          return "MC_CORE_1";
        case kClkMcCore_2:          return "MC_CORE_2";
        case kClkMcCore_3:          return "MC_CORE_3";
        case kClkMcRef:             return "MC_REF";
        case kClkMcRef_L:           return "MC_REF_L";
        case kClkMcRef_R:           return "MC_REF_R";
        case kClkMcRef_0:           return "MC_REF_0";
        case kClkMcRef_1:           return "MC_REF_1";
        case kClkMcRef_2:           return "MC_REF_2";
        case kClkMcRef_3:           return "MC_REF_3";
        case kClkMcReg:             return "MC_REG";
        case kClkMcReg_L:           return "MC_REG_L";
        case kClkMcReg_R:           return "MC_REG_R";
        case kClkMemPhy:            return "MEMPHY";
        case kClkMemPhy_L:          return "MEMPHY_L";
        case kClkMemPhy_R:          return "MEMPHY_R";
        case kClkMdf:               return "MDF";
        case kClkMdf_0:             return "MDF_0";
        case kClkMdf_1:             return "MDF_1";
        default: break;
    }
    // clang-format on

    return "CLK_ID_UDEF";
}

enum kSsmPllCfg {
    kCfgInvalid = 0,
    kCfg0,
    kCfg1,
    kCfg2,
    kCfg3,
    kCfg4,
    kCfg5,
    kCfgRstb,
    kCfgRefS,
    kCfgDiv,
    kCfgSt,
    kCfgMax,
};

inline std::string pll_cfg_2str(uint32_t pll_cfg) {
    // clang-format off
    switch (pll_cfg) {
        case kCfgInvalid:       return "kCfgInvalid";
        case kCfg0:             return "kCfg0";
        case kCfg1:             return "kCfg1";
        case kCfg2:             return "kCfg2";
        case kCfg3:             return "kCfg3";
        case kCfg4:             return "kCfg4";
        case kCfg5:             return "kCfg5";
        case kCfgRstb:          return "kCfgRstb";
        case kCfgRefS:          return "kCfgRefS";
        case kCfgDiv:           return "kCfgDiv";
        case kCfgSt:            return "kCfgSt";
        case kCfgMax:           return "kCfgMax";
        default: break;
    }
    // clang-format on

    return "PLL_CFG_UDEF";
}

enum kSsmPllVd {
    kPllVdInvalid = 0,
    kPllInno,
    kPllFolik,
    kPllAnlgb,
    kPllAnlgbHs,
    kPllVdMax,
};

inline std::string pll_vd_2str(uint32_t pll_vd) {
    // clang-format off
    switch (pll_vd) {
        case kPllVdInvalid:     return "kPllVdInvalid";
        case kPllInno:          return "INNO.VCO [1~3.5G]";
        case kPllFolik:         return "FOLIK.VCO [3~10G]";
        case kPllAnlgb:         return "ALBS.VCO [4 ~ 8G]";
        case kPllAnlgbHs:       return "ALBH.VCO [10~20G]";
        case kPllVdMax:         return "kPllVdMax";
        default: break;
    }
    // clang-format on

    return "PLL_VD_UDEF";
}

enum kSsmPllMode {
    kPllMdInvalid = 0,
    kPllInnoInteger,
    kPllInnoFraction,
    kPllInnoSsc,  // center spread|down spread
    kPllAlbsInteger,
    kPllAlbsFraction,
    kPllAlbsSs,  // spread spectrum(center/down)
    kPllAlhs4xphase,
    kPllMdMax,
};

inline std::string pll_md_2str(uint32_t pll_mode) {
    // clang-format off
    switch (pll_mode) {
        case kPllMdInvalid:         return "kPllMdInvalid";
        case kPllInnoInteger:       return "INT-Fvco=FrefxNI/M";
        case kPllInnoFraction:      return "FRC-Fvco=Frefx(NI+NF)/M";
        case kPllInnoSsc:           return "SSC-Fssc=Fref/(128xMxS)";
        case kPllAlbsInteger:       return "INT-Fpll=Fref/DIVR*4*DIVFI/DIVQ";
        case kPllAlbsFraction:      return "FRC-Fpll=Fref/DIVR*4*DIVF/DIVQ";
        case kPllAlbsSs:            return "SS-Fss=NA";
        case kPllAlhs4xphase:       return "HS-4xPhase-Fvco=Fref*DIVF+1*5/4";
        case kPllMdMax:             return "kPllMdMax";
        default: break;
    }
    // clang-format on

    return "PLL_MD_UDEF";
}

enum kSsmClkMux {
    kMuxIdInvalid = 0,
    kMux_C0_Tx_L1_M0,
    kMux_C0_Tx_L1_M1,
    kMux_C0_Tx_L2_M0,
    kMux_C0_Tx_L3_M0,
    kMux_C0_Tx_L4_M0,
    kMux_C1_T0_L1_M0,
    kMux_C1_T0_L1_M1,
    kMux_C1_T0_L1_M2,
    kMux_C1_T0_L1_M3,
    kMux_C1_T0_L2_M0,
    kMux_C1_T0_L2_M1,
    kMux_C1_T0_L3_M0,
    kMux_C1_T0_L3_M1,
    kMux_C1_T0_L4_M0,
    kMux_C1_T1_L1_M0,
    kMux_C1_T1_L1_M1,
    kMux_C1_T1_L1_M2,
    kMux_C1_T1_L1_M3,
    kMux_C1_T1_L2_M0,
    kMux_C1_T1_L2_M1,
    kMux_C1_T1_L3_M0,
    kMux_C1_T1_L3_M1,
    kMux_C1_T1_L4_M0,
    kMux_C2_T0_L1_M0,
    kMux_C2_T0_L1_M1,
    kMux_C2_T0_L2_M0,
    kMux_C2_T0_L2_M1,
    kMux_C2_T0_L3_M0,
    kMux_C2_T0_L3_M1,
    kMux_C2_T0_L4_M0,
    kMux_C2_T0_L4_M1,
    kMux_C2_T0_L4_M2,
    kMux_C2_T1_L1_M0,
    kMux_C2_T1_L1_M1,
    kMux_C2_T1_L2_M0,
    kMux_C2_T1_L2_M1,
    kMux_C2_T1_L3_M0,
    kMux_C2_T1_L3_M1,
    kMux_C2_T2_L1_M0,
    kMux_C2_T2_L1_M1,
    kMux_C2_T2_L2_M0,
    kMux_C2_T2_L2_M1,
    kMux_C2_T2_L3_M0,
    kMux_C2_T2_L3_M1,
    kMux_C2_T3_L1_M0,
    kMux_C2_T3_L1_M1,
    kMux_C2_T3_L2_M0,
    kMux_C2_T3_L2_M1,
    kMux_C2_T3_L3_M0,
    kMux_C2_T3_L3_M1,
    kMux_C3_T0_L1_M0,
    kMux_C3_T0_L1_M1,
    kMux_C3_T0_L2_M0,
    kMux_C3_T0_L2_M1,
    kMux_C3_T1_L1_M0,
    kMux_C3_T1_L1_M1,
    kMux_C3_T1_L2_M0,
    kMux_C3_T1_L2_M1,
    kMux_C3_T2_L1_M0,
    kMux_C3_T2_L1_M1,
    kMux_C3_T2_L2_M0,
    kMux_C3_T2_L2_M1,
    kMuxIdMax,
};

inline uint32_t mux_id_2enum(const std::string id) {
    // clang-format off
    if ("clk0_tx_l1m0" == id) return kMux_C0_Tx_L1_M0;
    if ("clk0_tx_l1m1" == id) return kMux_C0_Tx_L1_M1;
    if ("clk0_tx_l2m0" == id) return kMux_C0_Tx_L2_M0;
    if ("clk0_tx_l3m0" == id) return kMux_C0_Tx_L3_M0;
    if ("clk0_tx_l4m0" == id) return kMux_C0_Tx_L4_M0;
    if ("clk1_t0_l1m0" == id) return kMux_C1_T0_L1_M0;
    if ("clk1_t0_l1m1" == id) return kMux_C1_T0_L1_M1;
    if ("clk1_t0_l1m2" == id) return kMux_C1_T0_L1_M2;
    if ("clk1_t0_l1m3" == id) return kMux_C1_T0_L1_M3;
    if ("clk1_t0_l2m0" == id) return kMux_C1_T0_L2_M0;
    if ("clk1_t0_l2m1" == id) return kMux_C1_T0_L2_M1;
    if ("clk1_t0_l3m0" == id) return kMux_C1_T0_L3_M0;
    if ("clk1_t0_l3m1" == id) return kMux_C1_T0_L3_M1;
    if ("clk1_t0_l4m0" == id) return kMux_C1_T0_L4_M0;
    if ("clk1_t1_l1m0" == id) return kMux_C1_T1_L1_M0;
    if ("clk1_t1_l1m1" == id) return kMux_C1_T1_L1_M1;
    if ("clk1_t1_l1m2" == id) return kMux_C1_T1_L1_M2;
    if ("clk1_t1_l1m3" == id) return kMux_C1_T1_L1_M3;
    if ("clk1_t1_l2m0" == id) return kMux_C1_T1_L2_M0;
    if ("clk1_t1_l2m1" == id) return kMux_C1_T1_L2_M1;
    if ("clk1_t1_l3m0" == id) return kMux_C1_T1_L3_M0;
    if ("clk1_t1_l3m1" == id) return kMux_C1_T1_L3_M1;
    if ("clk1_t1_l4m0" == id) return kMux_C1_T1_L4_M0;
    if ("clk2_t0_l1m0" == id) return kMux_C2_T0_L1_M0;
    if ("clk2_t0_l1m1" == id) return kMux_C2_T0_L1_M1;
    if ("clk2_t0_l2m0" == id) return kMux_C2_T0_L2_M0;
    if ("clk2_t0_l2m1" == id) return kMux_C2_T0_L2_M1;
    if ("clk2_t0_l3m0" == id) return kMux_C2_T0_L3_M0;
    if ("clk2_t0_l3m1" == id) return kMux_C2_T0_L3_M1;
    if ("clk2_t0_l4m0" == id) return kMux_C2_T0_L4_M0;
    if ("clk2_t0_l4m1" == id) return kMux_C2_T0_L4_M1;
    if ("clk2_t0_l4m2" == id) return kMux_C2_T0_L4_M2;
    if ("clk2_t1_l1m0" == id) return kMux_C2_T1_L1_M0;
    if ("clk2_t1_l1m1" == id) return kMux_C2_T1_L1_M1;
    if ("clk2_t1_l2m0" == id) return kMux_C2_T1_L2_M0;
    if ("clk2_t1_l2m1" == id) return kMux_C2_T1_L2_M1;
    if ("clk2_t1_l3m0" == id) return kMux_C2_T1_L3_M0;
    if ("clk2_t1_l3m1" == id) return kMux_C2_T1_L3_M1;
    if ("clk2_t2_l1m0" == id) return kMux_C2_T2_L1_M0;
    if ("clk2_t2_l1m1" == id) return kMux_C2_T2_L1_M1;
    if ("clk2_t2_l2m0" == id) return kMux_C2_T2_L2_M0;
    if ("clk2_t2_l2m1" == id) return kMux_C2_T2_L2_M1;
    if ("clk2_t2_l3m0" == id) return kMux_C2_T2_L3_M0;
    if ("clk2_t2_l3m1" == id) return kMux_C2_T2_L3_M1;
    if ("clk2_t3_l1m0" == id) return kMux_C2_T3_L1_M0;
    if ("clk2_t3_l1m1" == id) return kMux_C2_T3_L1_M1;
    if ("clk2_t3_l2m0" == id) return kMux_C2_T3_L2_M0;
    if ("clk2_t3_l2m1" == id) return kMux_C2_T3_L2_M1;
    if ("clk2_t3_l3m0" == id) return kMux_C2_T3_L3_M0;
    if ("clk2_t3_l3m1" == id) return kMux_C2_T3_L3_M1;
    if ("clk3_t0_l1m0" == id) return kMux_C3_T0_L1_M0;
    if ("clk3_t0_l1m1" == id) return kMux_C3_T0_L1_M1;
    if ("clk3_t0_l2m0" == id) return kMux_C3_T0_L2_M0;
    if ("clk3_t0_l2m1" == id) return kMux_C3_T0_L2_M1;
    if ("clk3_t1_l1m0" == id) return kMux_C3_T1_L1_M0;
    if ("clk3_t1_l1m1" == id) return kMux_C3_T1_L1_M1;
    if ("clk3_t1_l2m0" == id) return kMux_C3_T1_L2_M0;
    if ("clk3_t1_l2m1" == id) return kMux_C3_T1_L2_M1;
    if ("clk3_t2_l1m0" == id) return kMux_C3_T2_L1_M0;
    if ("clk3_t2_l1m1" == id) return kMux_C3_T2_L1_M1;
    if ("clk3_t2_l2m0" == id) return kMux_C3_T2_L2_M0;
    if ("clk3_t2_l2m1" == id) return kMux_C3_T2_L2_M1;
    // clang-format on

    return kMuxIdInvalid;
}

enum kSsmClkDiv {
    kDivIdInvalid = 0,
    kDiv_C0_Tx_L1_CD0,  // Clkx_Tx_Levelx_clock/branch-div0/1
    kDiv_C1_T0_L1_CD0,
    kDiv_C1_T0_L1_CD1,
    kDiv_C1_T0_L2_BD0,
    kDiv_C1_T0_L2_BD1,
    kDiv_C1_T1_L1_CD0,
    kDiv_C1_T1_L1_CD1,
    kDiv_C1_T1_L2_BD0,
    kDiv_C1_T1_L2_BD1,
    kDiv_C2_T0_L1_CD0,
    kDiv_C2_T0_L1_CD1,
    kDiv_C2_T0_L2_BD0,
    kDiv_C2_T0_L2_BD1,
    kDiv_C2_T1_L1_CD0,
    kDiv_C2_T1_L1_CD1,
    kDiv_C2_T1_L2_BD0,
    kDiv_C2_T1_L2_BD1,
    kDiv_C2_T2_L1_CD0,
    kDiv_C2_T2_L1_CD1,
    kDiv_C2_T2_L2_BD0,
    kDiv_C2_T2_L2_BD1,
    kDiv_C2_T3_L1_CD0,
    kDiv_C2_T3_L1_CD1,
    kDiv_C2_T3_L2_BD0,
    kDiv_C2_T3_L2_BD1,
    kDiv_C3_T0_L1_CD0,
    kDiv_C3_T0_L1_CD1,
    kDiv_C3_T1_L1_CD0,
    kDiv_C3_T1_L1_CD1,
    kDiv_C3_T2_L1_CD0,
    kDiv_C3_T2_L1_CD1,
    kDivIdMax,
};

inline uint32_t clk_div_2enum(const std::string div) {
    // clang-format off
    if ("clk0_tx_l1_cd0" == div) return kDiv_C0_Tx_L1_CD0;
    if ("clk1_t0_l1_cd0" == div) return kDiv_C1_T0_L1_CD0;
    if ("clk1_t0_l1_cd1" == div) return kDiv_C1_T0_L1_CD1;
    if ("clk1_t0_l2_bd0" == div) return kDiv_C1_T0_L2_BD0;
    if ("clk1_t0_l2_bd1" == div) return kDiv_C1_T0_L2_BD1;
    if ("clk1_t1_l1_cd0" == div) return kDiv_C1_T1_L1_CD0;
    if ("clk1_t1_l1_cd1" == div) return kDiv_C1_T1_L1_CD1;
    if ("clk1_t1_l2_bd0" == div) return kDiv_C1_T1_L2_BD0;
    if ("clk1_t1_l2_bd1" == div) return kDiv_C1_T1_L2_BD1;
    if ("clk2_t0_l1_cd0" == div) return kDiv_C2_T0_L1_CD0;
    if ("clk2_t0_l1_cd1" == div) return kDiv_C2_T0_L1_CD1;
    if ("clk2_t0_l2_bd0" == div) return kDiv_C2_T0_L2_BD0;
    if ("clk2_t0_l2_bd1" == div) return kDiv_C2_T0_L2_BD1;
    if ("clk2_t1_l1_cd0" == div) return kDiv_C2_T1_L1_CD0;
    if ("clk2_t1_l1_cd1" == div) return kDiv_C2_T1_L1_CD1;
    if ("clk2_t1_l2_bd0" == div) return kDiv_C2_T1_L2_BD0;
    if ("clk2_t1_l2_bd1" == div) return kDiv_C2_T1_L2_BD1;
    if ("clk2_t2_l1_cd0" == div) return kDiv_C2_T2_L1_CD0;
    if ("clk2_t2_l1_cd1" == div) return kDiv_C2_T2_L1_CD1;
    if ("clk2_t2_l2_bd0" == div) return kDiv_C2_T2_L2_BD0;
    if ("clk2_t2_l2_bd1" == div) return kDiv_C2_T2_L2_BD1;
    if ("clk2_t3_l1_cd0" == div) return kDiv_C2_T3_L1_CD0;
    if ("clk2_t3_l1_cd1" == div) return kDiv_C2_T3_L1_CD1;
    if ("clk2_t3_l2_bd0" == div) return kDiv_C2_T3_L2_BD0;
    if ("clk2_t3_l2_bd1" == div) return kDiv_C2_T3_L2_BD1;
    if ("clk3_t0_l1_cd0" == div) return kDiv_C3_T0_L1_CD0;
    if ("clk3_t0_l1_cd1" == div) return kDiv_C3_T0_L1_CD1;
    if ("clk3_t1_l1_cd0" == div) return kDiv_C3_T1_L1_CD0;
    if ("clk3_t1_l1_cd1" == div) return kDiv_C3_T1_L1_CD1;
    if ("clk3_t2_l1_cd0" == div) return kDiv_C3_T2_L1_CD0;
    if ("clk3_t2_l1_cd1" == div) return kDiv_C3_T2_L1_CD1;
    // clang-format on

    return kDivIdInvalid;
}

inline std::string div_id_2str(uint32_t div_id) {
    // clang-format off
    if (kDiv_C0_Tx_L1_CD0 == div_id) return "clk0_tx_l1_cd0";
    if (kDiv_C1_T0_L1_CD0 == div_id) return "clk1_t0_l1_cd0";
    if (kDiv_C1_T0_L1_CD1 == div_id) return "clk1_t0_l1_cd1";
    if (kDiv_C1_T0_L2_BD0 == div_id) return "clk1_t0_l2_bd0";
    if (kDiv_C1_T0_L2_BD1 == div_id) return "clk1_t0_l2_bd1";
    if (kDiv_C1_T1_L1_CD0 == div_id) return "clk1_t1_l1_cd0";
    if (kDiv_C1_T1_L1_CD1 == div_id) return "clk1_t1_l1_cd1";
    if (kDiv_C1_T1_L2_BD0 == div_id) return "clk1_t1_l2_bd0";
    if (kDiv_C1_T1_L2_BD1 == div_id) return "clk1_t1_l2_bd1";
    if (kDiv_C2_T0_L1_CD0 == div_id) return "clk2_t0_l1_cd0";
    if (kDiv_C2_T0_L1_CD1 == div_id) return "clk2_t0_l1_cd1";
    if (kDiv_C2_T0_L2_BD0 == div_id) return "clk2_t0_l2_bd0";
    if (kDiv_C2_T0_L2_BD1 == div_id) return "clk2_t0_l2_bd1";
    if (kDiv_C2_T1_L1_CD0 == div_id) return "clk2_t1_l1_cd0";
    if (kDiv_C2_T1_L1_CD1 == div_id) return "clk2_t1_l1_cd1";
    if (kDiv_C2_T1_L2_BD0 == div_id) return "clk2_t1_l2_bd0";
    if (kDiv_C2_T1_L2_BD1 == div_id) return "clk2_t1_l2_bd1";
    if (kDiv_C2_T2_L1_CD0 == div_id) return "clk2_t2_l1_cd0";
    if (kDiv_C2_T2_L1_CD1 == div_id) return "clk2_t2_l1_cd1";
    if (kDiv_C2_T2_L2_BD0 == div_id) return "clk2_t2_l2_bd0";
    if (kDiv_C2_T2_L2_BD1 == div_id) return "clk2_t2_l2_bd1";
    if (kDiv_C2_T3_L1_CD0 == div_id) return "clk2_t3_l1_cd0";
    if (kDiv_C2_T3_L1_CD1 == div_id) return "clk2_t3_l1_cd1";
    if (kDiv_C2_T3_L2_BD0 == div_id) return "clk2_t3_l2_bd0";
    if (kDiv_C2_T3_L2_BD1 == div_id) return "clk2_t3_l2_bd1";
    if (kDiv_C3_T0_L1_CD0 == div_id) return "clk3_t0_l1_cd0";
    if (kDiv_C3_T0_L1_CD1 == div_id) return "clk3_t0_l1_cd1";
    if (kDiv_C3_T1_L1_CD0 == div_id) return "clk3_t1_l1_cd0";
    if (kDiv_C3_T1_L1_CD1 == div_id) return "clk3_t1_l1_cd1";
    if (kDiv_C3_T2_L1_CD0 == div_id) return "clk3_t2_l1_cd0";
    if (kDiv_C3_T2_L1_CD1 == div_id) return "clk3_t2_l1_cd1";
    // clang-format on

    return "clkx_tx_lx_xxx";
}

enum kSsmClkCsc {
    kCscIdInvalid = 0,
    kCsc_C0_Tx_CSC0,
    kCsc_C0_Tx_CSC1,
    kCsc_C3_T0_CSC0,
    kCsc_C3_T0_CSC1,
    kCsc_C3_T1_CSC0,
    kCsc_C3_T1_CSC1,
    kCsc_C3_T2_CSC0,
    kCsc_C3_T2_CSC1,
    kCscIdMax,
};

inline std::string csc_id_2str(uint32_t csc_id) {
    // clang-format off
    switch (csc_id) {
        case kCscIdInvalid:     return "kCscIdInvalid";
        case kCsc_C0_Tx_CSC0:   return "clk0_tx_csc0";
        case kCsc_C0_Tx_CSC1:   return "clk0_tx_csc1";
        case kCsc_C3_T0_CSC0:   return "clk3_t0_csc0";
        case kCsc_C3_T0_CSC1:   return "clk3_t0_csc1";
        case kCsc_C3_T1_CSC0:   return "clk3_t1_csc0";
        case kCsc_C3_T1_CSC1:   return "clk3_t1_csc1";
        case kCsc_C3_T2_CSC0:   return "clk3_t2_csc0";
        case kCsc_C3_T2_CSC1:   return "clk3_t2_csc1";
        case kCscIdMax:         return "kCscIdMax";
        default: break;
    }
    // clang-format on

    return "CSC_ID_UDEF";
}

enum kSsmClkCkb {
    kCkbIdInvalid = 0,
    kCkb_C0_Tx_CKB0,
    kCkb_C0_Tx_CKB1,
    kCkb_C2_T0_CKB0,
    kCkb_C3_T0_CKB0,
    kCkb_C3_T0_CKB1,
    kCkb_C3_T1_CKB0,
    kCkb_C3_T1_CKB1,
    kCkb_C3_T2_CKB0,
    kCkb_C3_T2_CKB1,
    kCkbIdMax,
};

inline std::string ckb_id_2str(uint32_t ckb_id) {
    // clang-format off
    switch (ckb_id) {
        case kCkbIdInvalid:     return "kCkbIdInvalid";
        case kCkb_C0_Tx_CKB0:   return "clk0_tx_ckb0";
        case kCkb_C0_Tx_CKB1:   return "clk0_tx_ckb1";
        case kCkb_C2_T0_CKB0:   return "clk2_t0_ckb0";
        case kCkb_C3_T0_CKB0:   return "clk3_t0_ckb0";
        case kCkb_C3_T0_CKB1:   return "clk3_t0_ckb1";
        case kCkb_C3_T1_CKB0:   return "clk3_t1_ckb0";
        case kCkb_C3_T1_CKB1:   return "clk3_t1_ckb1";
        case kCkb_C3_T2_CKB0:   return "clk3_t2_ckb0";
        case kCkb_C3_T2_CKB1:   return "clk3_t2_ckb1";
        case kCkbIdMax:         return "kCkbIdMax";
        default: break;
    }
    // clang-format on

    return "CKB_ID_UDEF";
}

enum kSsmClkCgd {
    kCgdIdInvalid = 0,
    kCgd_C0_Tx_GD_0,
    kCgd_C0_Tx_GD_1,
    kCgd_C0_Tx_GD_2,
    kCgd_C0_Tx_GD_3,
    kCgd_C3_T0_GD_0,
    kCgd_C3_T0_GD_1,
    kCgd_C3_T1_GD_0,
    kCgd_C3_T1_GD_1,
    kCgd_C3_T2_GD_0,
    kCgd_C3_T2_GD_1,
    kCgdIdMax,
};

inline std::string gd_id_2str(uint32_t cgd_id) {
    // clang-format off
    switch (cgd_id) {
        case kCgdIdInvalid:     return "kCgdIdInvalid";
        case kCgd_C0_Tx_GD_0:   return "clk0_tx_gd_0";
        case kCgd_C0_Tx_GD_1:   return "clk0_tx_gd_1";
        case kCgd_C0_Tx_GD_2:   return "clk0_tx_gd_2";
        case kCgd_C0_Tx_GD_3:   return "clk0_tx_gd_3";
        case kCgd_C3_T0_GD_0:   return "clk3_t0_gd_0";
        case kCgd_C3_T0_GD_1:   return "clk3_t0_gd_1";
        case kCgd_C3_T1_GD_0:   return "clk3_t1_gd_0";
        case kCgd_C3_T1_GD_1:   return "clk3_t1_gd_1";
        case kCgd_C3_T2_GD_0:   return "clk3_t2_gd_0";
        case kCgd_C3_T2_GD_1:   return "clk3_t2_gd_1";
        case kCgdIdMax:         return "kCgdIdMax";
        default: break;
    }
    // clang-format on

    return "CGD_ID_UDEF";
}

inline uint32_t clk_gd_2enum(const std::string cgd) {
    // clang-format off
    if ("clk0_tx_gd_0" == cgd) return kCgd_C0_Tx_GD_0;
    if ("clk0_tx_gd_1" == cgd) return kCgd_C0_Tx_GD_1;
    if ("clk0_tx_gd_2" == cgd) return kCgd_C0_Tx_GD_2;
    if ("clk0_tx_gd_3" == cgd) return kCgd_C0_Tx_GD_3;
    if ("clk3_t0_gd_0" == cgd) return kCgd_C3_T0_GD_0;
    if ("clk3_t0_gd_1" == cgd) return kCgd_C3_T0_GD_1;
    if ("clk3_t1_gd_0" == cgd) return kCgd_C3_T1_GD_0;
    if ("clk3_t1_gd_1" == cgd) return kCgd_C3_T1_GD_1;
    if ("clk3_t2_gd_0" == cgd) return kCgd_C3_T2_GD_0;
    if ("clk3_t2_gd_1" == cgd) return kCgd_C3_T2_GD_1;
    // clang-format on

    return kCgdIdInvalid;
}

enum {
    kClkEvtInvalid = 0,
    kClkEvtDebugReg,
    kClkEvtDebugRegOct,
    kClkEvtDebugRegOtt,
    kClkEvtWatchDog,
    kClkEvtPPWatchDog,
    kClkEvtPPExternal,
    kClkEvtPPInternal,
    kClkEvtExtEdcc,
    kClkEvtExtEdcc_0,
    kClkEvtExtEdcc_1,
    kClkEvtExtVddc_0,
    kClkEvtExtVddc_1,
    kClkEvtIntEdcc_0,
    kClkEvtIntEdcc_1,
    kClkEvtIntVddc_0,
    kClkEvtIntVddc_1,
    kClkEvtIntVddcGd_0,
    kClkEvtIntVddcGd_1,
    kClkEvtIntVddcGd_2,
    kClkEvtIntVddcGd_3,
    kClkEvtExtEdcc2Int_0,
    kClkEvtExtEdcc2Int_1,
    kClkEvtExtVddc2Int_0,
    kClkEvtExtVddc2Int_1,
    kClkEvtIntVddc2Int_0,
    kClkEvtIntVddc2Int_1,
    kClkEvtIntExtMix_0,
    kClkEvtIntExtMix_1,
    kClkEvtMax,
};

inline std::string clk_evt_2str(uint32_t evt_id) {
    // clang-format off
    switch (evt_id) {
        case kClkEvtInvalid:        return "kClkEvtInvalid";
        case kClkEvtDebugReg:       return "kClkEvtDebugReg";
        case kClkEvtDebugRegOct:    return "kClkEvtDebugRegOct";
        case kClkEvtDebugRegOtt:    return "kClkEvtDebugRegOtt";
        case kClkEvtWatchDog:       return "kClkEvtWatchDog";
        case kClkEvtPPWatchDog:     return "kClkEvtPPWatchDog";
        case kClkEvtPPExternal:     return "kClkEvtPPExternal";
        case kClkEvtPPInternal:     return "kClkEvtPPInternal";
        case kClkEvtExtEdcc:        return "kClkEvtExtEdcc";
        case kClkEvtExtEdcc_0:      return "kClkEvtExtEdcc_0";
        case kClkEvtExtEdcc_1:      return "kClkEvtExtEdcc_1";
        case kClkEvtExtVddc_0:      return "kClkEvtExtVddc_0";
        case kClkEvtExtVddc_1:      return "kClkEvtExtVddc_1";
        case kClkEvtIntEdcc_0:      return "kClkEvtIntEdcc_0";
        case kClkEvtIntEdcc_1:      return "kClkEvtIntEdcc_1";
        case kClkEvtIntVddc_0:      return "kClkEvtIntVddc_0";
        case kClkEvtIntVddc_1:      return "kClkEvtIntVddc_1";
        case kClkEvtIntVddcGd_0:    return "kClkEvtIntVddcGd_0";
        case kClkEvtIntVddcGd_1:    return "kClkEvtIntVddcGd_1";
        case kClkEvtIntVddcGd_2:    return "kClkEvtIntVddcGd_2";
        case kClkEvtIntVddcGd_3:    return "kClkEvtIntVddcGd_3";
        case kClkEvtExtEdcc2Int_0:  return "kClkEvtExtEdcc2Int_0";
        case kClkEvtExtEdcc2Int_1:  return "kClkEvtExtEdcc2Int_1";
        case kClkEvtExtVddc2Int_0:  return "kClkEvtExtVddc2Int_0";
        case kClkEvtExtVddc2Int_1:  return "kClkEvtExtVddc2Int_1";
        case kClkEvtIntVddc2Int_0:  return "kClkEvtIntVddc2Int_0";
        case kClkEvtIntVddc2Int_1:  return "kClkEvtIntVddc2Int_1";
        case kClkEvtIntExtMix_0:    return "kClkEvtIntExtMix_0";
        case kClkEvtIntExtMix_1:    return "kClkEvtIntExtMix_1";
        case kClkEvtMax:            return "kClkEvtMax";
        default: break;
    }
    // clang-format on

    return "EVT_ID_UDEF";
}

enum {
    kCscArbInvalid = 0,
    kCscArb_CASE_1_S_A_OCTT_RAMP_UP_T_A_OCTT,
    kCscArb_CASE_2_S_A_OCTT_RAMP_DN_T_B_OCTT,
    kCscArb_CASE_3_S_A_OCTT_RAMP_DN_T_A_OCTT,
    kCscArb_CASE_4_S_B_OCTT_RAMP_UP_T_A_OCTT,
    kCscArb_CASE_5_S_B_OCTT_RAMP_UP_T_B_OCTT,
    kCscArb_CASE_6_S_B_OCTT_RAMP_DN_T_B_OCTT,
    kCscArbMax,
};

enum kSsmObs {
    kObsWpInvalid = 0,
    kObsWp_0,
    kObsWp_1,
    kObsWp_2,
    kObsWp_3,
    kObsWp_4,
    kObsWp_5,
    kObsWp_6,
    kObsWp_7,
    kObsWp_8,
    kObsWp_9,
    kObsWp_10,
    kObsWp_11,
    kObsWp_12,
    kObsWp_13,
    kObsWp_14,
    kObsWp_15,
    kObsWp_Ext_cascaded_clk0,
    kObsWp_Ext_cascaded_clk1,
    kObsWp_Ext_cascaded_clk2,
    kObsWp_Ext_cascaded_clk3,
    kObsWpMax,
};

inline std::string clk_wp_2str(uint32_t obs_wp) {
    // clang-format off
    switch (obs_wp) {
        case kObsWpInvalid:            return "kObsWpInvalid";
        case kObsWp_0:                 return "wp0";
        case kObsWp_1:                 return "wp1";
        case kObsWp_2:                 return "wp2";
        case kObsWp_3:                 return "wp3";
        case kObsWp_4:                 return "wp4";
        case kObsWp_5:                 return "wp5";
        case kObsWp_6:                 return "wp6";
        case kObsWp_7:                 return "wp7";
        case kObsWp_8:                 return "wp8";
        case kObsWp_9:                 return "wp9";
        case kObsWp_10:                return "wp10";
        case kObsWp_11:                return "wp11";
        case kObsWp_12:                return "wp12";
        case kObsWp_13:                return "wp13";
        case kObsWp_14:                return "wp14";
        case kObsWp_15:                return "wp15";
        case kObsWp_Ext_cascaded_clk0: return "wpe0";
        case kObsWp_Ext_cascaded_clk1: return "wpe1";
        case kObsWp_Ext_cascaded_clk2: return "wpe2";
        case kObsWp_Ext_cascaded_clk3: return "wpe3";
        case kObsWpMax:                return "kObsWpMax";
        default: break;
    }
    // clang-format on

    return "OBS_WP_UDEF";
}

inline uint32_t clk_wp_2enum(const std::string wp) {
    // clang-format off
    if (("0"  == wp) || ("wp0"  == wp)) return kObsWp_0;
    if (("1"  == wp) || ("wp1"  == wp)) return kObsWp_1;
    if (("2"  == wp) || ("wp2"  == wp)) return kObsWp_2;
    if (("3"  == wp) || ("wp3"  == wp)) return kObsWp_3;
    if (("4"  == wp) || ("wp4"  == wp)) return kObsWp_4;
    if (("5"  == wp) || ("wp5"  == wp)) return kObsWp_5;
    if (("6"  == wp) || ("wp6"  == wp)) return kObsWp_6;
    if (("7"  == wp) || ("wp7"  == wp)) return kObsWp_7;
    if (("8"  == wp) || ("wp8"  == wp)) return kObsWp_8;
    if (("9"  == wp) || ("wp9"  == wp)) return kObsWp_9;
    if (("10" == wp) || ("wp10" == wp)) return kObsWp_10;
    if (("11" == wp) || ("wp11" == wp)) return kObsWp_11;
    if (("12" == wp) || ("wp12" == wp)) return kObsWp_12;
    if (("13" == wp) || ("wp13" == wp)) return kObsWp_13;
    if (("14" == wp) || ("wp14" == wp)) return kObsWp_14;
    if (("15" == wp) || ("wp15" == wp)) return kObsWp_15;
    if (("e0" == wp) || ("wpe0" == wp)) return kObsWp_Ext_cascaded_clk0;
    if (("e1" == wp) || ("wpe1" == wp)) return kObsWp_Ext_cascaded_clk1;
    if (("e2" == wp) || ("wpe2" == wp)) return kObsWp_Ext_cascaded_clk2;
    if (("e3" == wp) || ("wpe3" == wp)) return kObsWp_Ext_cascaded_clk3;
    // clang-format on

    return kObsWpInvalid;
}

enum {
    kObsReqInvalid = 0,
    kObsReqClkCac_TpA,
    kObsReqMax,
};

const uint32_t OBS_REQ_DW = 8U;
typedef struct {
    uint32_t obs_rtype;
    uint32_t obs_clkid;
    uint32_t obs_clkwp;
    uint32_t obs_div;
    uint32_t obs_ref_cnt;
    uint32_t obs_meas_ms;
    uint32_t obs_rclk_hz;
    uint32_t obs_verbose;
} OBS_REQA_t;

typedef union {
    uint32_t   v[OBS_REQ_DW];
    OBS_REQA_t a;
} OBS_REQ_u;

typedef struct _pair_type_a {
    _pair_type_a(uint32_t _a = ~0, uint32_t _x = ~0) {
        addr = _a;
        xval = _x;
    }
    uint32_t addr;
    uint32_t xval;
} SSM_PA;

const uint32_t PLL_CFG_DW = 18U;
typedef struct {
    uint32_t BYPASS;
    uint32_t RESETN;
    uint32_t DIVFI;
    uint32_t DIVR;
    uint32_t DIVFF;
    uint32_t DIVQ_0;
    uint32_t DIVQ_1;
    uint32_t DIVQ_2;
    uint32_t DIVQ_3;
    uint32_t SSE;
    uint32_t SSMF;
    uint32_t SSMD;
    uint32_t SSDS;
    uint32_t RANGE;
    uint32_t LOCK;
    uint32_t DIVACK;
    uint32_t NEWDIV;
    uint32_t resv[PLL_CFG_DW - 17];
} PLL_ALBS_t;

typedef struct {
    uint32_t RESETN;
    uint32_t REFCLKS;
    uint32_t DIVF;
    uint32_t LOCK;
    uint32_t resv[PLL_CFG_DW - 4];
} PLL_ALHS_t;

typedef union {
    uint32_t   v[PLL_CFG_DW];
    PLL_ALBS_t albs;
    PLL_ALHS_t alhs;
} PLL_CFG_u;

class pll_inst {
 public:
    pll_inst() {
        clear();
    }
    explicit pll_inst(uint32_t pll_id) {
        clear();
        set_pll_id(pll_id);
    }
    pll_inst(const pll_inst &p) {  // copy
        init(p);
    }
    pll_inst &operator=(const pll_inst &p) {  // assign
        init(p);
        return *this;
    }
    void init(const pll_inst &p) {
        set_pll_ready(p.m_pll_ready);
        set_pll_refclk(p.m_pll_refclk);
        set_vendor(p.m_pll_vd);
        set_pll_id(p.m_pll_id);
        set_pll_md(p.m_pll_md);
        set_top_id(p.m_top_id);

        memcpy(m_pll_cfg.v, p.m_pll_cfg.v, SSM_DW2B(PLL_CFG_DW));
        for (auto cfg = p.m_pll_raw.begin(); cfg != p.m_pll_raw.end(); ++cfg) {
            auto &cfg_idx = cfg->first;   // kSsmPllCfg
            auto &cfg_val = cfg->second;  // SSM_PA
            set_pll_raw(cfg_idx, cfg_val);
        }
    }
    void clear(void) {
        set_pll_ready(false);
        set_pll_refclk(0);
        set_vendor(kPllVdInvalid);
        set_pll_id(kPllIdInvalid);
        set_pll_md(kPllMdInvalid);
        set_top_id(kClkIdInvalid);
        memset(m_pll_cfg.v, 0, SSM_DW2B(PLL_CFG_DW));
        m_pll_raw.clear();
    }
    void set_pll_ready(const bool &rdy) {
        m_pll_ready = rdy;
    }
    bool get_pll_ready(void) {
        return m_pll_ready;
    }
    void set_pll_refclk(const double &ref) {
        m_pll_refclk = ref;  // mhz in use
    }
    double get_pll_refclk() {
        return m_pll_refclk;  // mhz in use
    }
    void set_vendor(const uint32_t &vendor) {
        m_pll_vd = vendor;
    }
    uint32_t get_vendor(void) {
        return m_pll_vd;
    }
    bool is_inno(void) {
        return (kPllInno == get_vendor());
    }
    bool is_folik(void) {
        return (kPllFolik == get_vendor());
    }
    bool is_anlgbs(void) {
        return (kPllAnlgb == get_vendor());
    }
    bool is_anlghs(void) {
        return (kPllAnlgbHs == get_vendor());
    }
    void set_pll_id(const uint32_t &pll_id) {
        m_pll_id = pll_id;
    }
    uint32_t get_pll_id(void) {
        return m_pll_id;
    }
    void set_pll_md(const uint32_t &pll_md) {
        m_pll_md = pll_md;
    }
    uint32_t get_pll_md(void) {
        return m_pll_md;
    }
    bool is_integer_md(void) {
        return (kPllAlbsInteger == get_pll_md());
    }
    bool is_fractional_md(void) {
        return (kPllAlbsFraction == get_pll_md());
    }
    uint32_t pll_md_decode(void) {
        if (is_anlgbs()) {
            if (1 == m_pll_cfg.albs.SSE)
                return kPllAlbsSs;  // spread spectrum enable
            else if (0 == m_pll_cfg.albs.RANGE)
                return kPllAlbsFraction;  // frac pll filter
            else
                return kPllAlbsInteger;
        } else if (is_anlghs()) {
            return kPllAlhs4xphase;
        } else {
            return kPllMdInvalid;
        }
    }
    void set_top_id(const uint32_t &top_id) {
        m_top_id = top_id;
    }
    uint32_t get_top_id(void) {
        return m_top_id;
    }
    void set_pll_raw(uint32_t cfg, SSM_PA pa) {
        m_pll_raw[cfg] = pa;
    }
    SSM_PA &get_pll_raw(uint32_t cfg) {
        return m_pll_raw[cfg];
    }
    std::string get_pll_clk_map(void) {
        std::stringstream msg_info("");
        msg_info << top_id_2str(get_top_id()) << "." << pll_id_2str(get_pll_id()) << " "
                 << pll_vd_2str(get_vendor()) << " " << (m_pll_ready ? "OK" : "NG");
        return msg_info.str();
    }
    std::string get_debug_raw(void) {
        std::stringstream msg_info("");
        msg_info << get_pll_clk_map();
        for (auto cfg = m_pll_raw.begin(); cfg != m_pll_raw.end(); ++cfg) {
            auto &cfg_idx = cfg->first;   // kSsmPllCfg
            auto &cfg_val = cfg->second;  // SSM_PA
            msg_info << " " << pll_cfg_2str(cfg_idx) << " " << std::hex << std::setw(8)
                     << std::setfill('0') << cfg_val.xval << "@" << std::hex << std::setw(8)
                     << std::setfill('0') << cfg_val.addr;
        }
        return msg_info.str();
    }
    std::string get_config_anlgbs(void) {
        std::stringstream msg_info("");
        // clang-format off
        msg_info <<    " R " << std::hex << m_pll_cfg.albs.RANGE;
        msg_info <<    " B " << std::hex << m_pll_cfg.albs.BYPASS;
        msg_info <<    " N " << std::hex << m_pll_cfg.albs.RESETN;
        msg_info << " D.FI " << std::hex << m_pll_cfg.albs.DIVFI;
        msg_info <<  " D.R " << std::hex << m_pll_cfg.albs.DIVR;
        msg_info << " D.FF " << std::hex << m_pll_cfg.albs.DIVFF;
        msg_info <<  " D.0 " << std::hex << m_pll_cfg.albs.DIVQ_0;
        msg_info <<  " D.1 " << std::hex << m_pll_cfg.albs.DIVQ_1;
        msg_info <<  " D.2 " << std::hex << m_pll_cfg.albs.DIVQ_2;
        msg_info <<  " D.3 " << std::hex << m_pll_cfg.albs.DIVQ_3;
        msg_info <<  " SSE " << std::hex << m_pll_cfg.albs.SSE;
        msg_info <<   " MF " << std::hex << m_pll_cfg.albs.SSMF;
        msg_info <<   " MD " << std::hex << m_pll_cfg.albs.SSMD;
        msg_info <<   " DS " << std::hex << m_pll_cfg.albs.SSDS;
        msg_info <<    " L " << std::hex << m_pll_cfg.albs.LOCK;
        msg_info <<  " D.A " << std::hex << m_pll_cfg.albs.DIVACK;
        msg_info <<  " D.N " << std::hex << m_pll_cfg.albs.NEWDIV;
        // clang-format on
        return msg_info.str();
    }
    std::string get_config_anlghs(void) {
        std::stringstream msg_info("");
        // clang-format off
        msg_info <<  " RESETN " << std::hex << m_pll_cfg.alhs.RESETN;
        msg_info << " REF.SEL " << std::hex << m_pll_cfg.alhs.REFCLKS;
        msg_info <<    " DIVF " << std::hex << m_pll_cfg.alhs.DIVF;
        msg_info <<    " LOCK " << std::hex << m_pll_cfg.alhs.LOCK;
        // clang-format on
        return msg_info.str();
    }
    std::string get_config_raw(void) {
        std::stringstream msg_info("");
        msg_info << get_pll_clk_map();
        if (is_anlgbs()) {
            msg_info << get_config_anlgbs();
        } else if (is_anlghs()) {
            msg_info << get_config_anlghs();
        } else {
            msg_info << " Not supported yet";
        }
        return msg_info.str();
    }
    double get_calc_anlgbs_vco(void) {
        double refclk    = get_pll_refclk();
        double divr_val  = (m_pll_cfg.albs.DIVR + 1);   // valid 1~128
        double divfi_val = (m_pll_cfg.albs.DIVFI + 1);  // valid 1~1024
        double divff_val = (m_pll_cfg.albs.DIVFF / (1 << 24));
        double divf_val  = divfi_val + divff_val;
        /**
         * Fractional mode:
         * PLLOUT = REF / DIVR_VAL * 4 * DIVF_VAL / DIVQ_VAL
         *  DIVF_VAL = 1 + DIVFI + (DIVFF/2^24)
         *
         * Integer mode:
         * PLLOUT = REF / DIVR_VAL * 4 * DIVFI_VAL / DIVQ_VAL
         */
        double pll_vco = -1;
        if (is_integer_md()) {
            pll_vco = refclk / divr_val * 4 * divfi_val;
        } else if (is_fractional_md()) {
            pll_vco = refclk / divr_val * 4 * divf_val;
        }
        assert(-1 != pll_vco);  // sanity check
        return pll_vco;
    }
    double get_calc_anlgbs_pllout(uint32_t divq) {
        assert(is_anlgbs());  // sanity check
        uint32_t divq_raw = ~0;
        if (0 == divq) {
            divq_raw = m_pll_cfg.albs.DIVQ_0;
        } else if (1 == divq) {
            divq_raw = m_pll_cfg.albs.DIVQ_1;
        } else if (2 == divq) {
            divq_raw = m_pll_cfg.albs.DIVQ_2;
        } else if (3 == divq) {
            divq_raw = m_pll_cfg.albs.DIVQ_3;
        }
        assert(~0 != divq_raw);  // sanity check
        double pll_vco   = get_calc_anlgbs_vco();
        double div_val_a = (divq_raw) ? (4 * divq_raw) : 2;  // O_0|O_1
        double div_val_b = (divq_raw) ? (divq_raw + 1) : 0;  // O_2|O_3

        double div_val = ((0 == divq) || (1 == divq)) ? div_val_a : div_val_b;
        if (0 == div_val) {
            return 0.0;  // div_val zero not allowed
        }
        double pst_div = pll_vco / div_val;  // case.0
        /**
         * spec def fractional-n pll/sscg output
         *        |BYPASS|RESET|PLLOUT|POWER|
         * case.0 |  0   |  0  |Normal| ON  |
         * case.1 |  0   |  1  | Low  | OFF |
         * case.2 |  1   |  X  | REF  | OFF |
         *
         * scorpio.wrapper.reset == !(pll.reset) low active
         */
        if ((0 == m_pll_cfg.albs.BYPASS) && (0 == m_pll_cfg.albs.RESETN))
            pst_div = 0;  // case.1 power off no clock out
        if (1 == m_pll_cfg.albs.BYPASS)
            pst_div = get_pll_refclk();  // case.2 tracks ref input
        return pst_div;
    }
    std::string get_calc_anlgbs(void) {
        std::stringstream msg_info("");
        msg_info << pll_md_2str(get_pll_md());
        msg_info << " REF " << get_pll_refclk() << get_config_anlgbs() << " VCO "
                 << get_calc_anlgbs_vco() << " |" << get_calc_anlgbs_pllout(0) << "|"
                 << get_calc_anlgbs_pllout(1) << "|" << get_calc_anlgbs_pllout(2) << "|"
                 << get_calc_anlgbs_pllout(3);
        return msg_info.str();
    }
    double get_calc_anlghs_pllout(void) {
        assert(is_anlghs());  // sanity check
        double refclk   = get_pll_refclk();
        double divf_val = (m_pll_cfg.alhs.DIVF + 1);  // valid 1~1024

        /**
         * 4-phase clock frequency(Mhz) = (100*(DIVF+1)*5)/4
         *
         * spec post-div [DIVQ 0 = /2] [DIVQ 1 = /4] design tie 1
         *        |RESET|PLLOUT|POWER|
         * case.0 |  0  |Normal| ON  |
         * case.1 |  1  | Low  | OFF |
         *
         * scorpio.wrapper.reset == !(pll.reset) low active
         */
        double pst_div = refclk * divf_val * 5 / 4;  // case.0
        if (0 == m_pll_cfg.alhs.RESETN)
            pst_div = 0;  // case.1 power off no clock out
        return pst_div;
    }
    std::string get_calc_anlghs(void) {
        std::stringstream msg_info("");
        msg_info << pll_md_2str(get_pll_md());
        msg_info << " REF " << get_pll_refclk() << get_config_anlghs()
                 << " 4-phase PLLOUT-0_90_180_270|" << get_calc_anlghs_pllout();
        return msg_info.str();
    }
    std::string get_calc_info(void) {
        std::stringstream msg_info("");
        msg_info << get_pll_clk_map();
        if (is_anlgbs()) {
            msg_info << " " << get_calc_anlgbs();
        } else if (is_anlghs()) {
            msg_info << " " << get_calc_anlghs();
        } else {
            msg_info << " Not supported yet";
        }
        return msg_info.str();
    }

    bool     m_pll_ready;   // ready to use
    double   m_pll_refclk;  // per asic
    uint32_t m_pll_vd;      // kSsmPllvd
    uint32_t m_pll_id;      // kSsmClk
    uint32_t m_pll_md;      // kSsmPllMode
    uint32_t m_top_id;      // kSsmClk

    PLL_CFG_u m_pll_cfg;                   // pll per type cfgs
    std::map<uint32_t, SSM_PA> m_pll_raw;  // kSsmPllCfg, SSM_PA
};

class clk_inst {
 public:
    clk_inst() {
        clear();
    }
    explicit clk_inst(uint32_t top_id) {
        clear();
        set_top_id(top_id);
    }
    clk_inst(const clk_inst &c) {  // copy
        init(c);
    }
    clk_inst &operator=(const clk_inst &c) {  // assign
        init(c);
        return *this;
    }

 public:
    typedef struct {
        uint32_t    b_id;    // branch e.g. kClk_A0
        uint32_t    b_name;  // naming e.g. kClkSsm
        double      b_freq;  // frequency calc
        std::string b_desc;  // branch pipeline
    } branch_t;

    void init(const clk_inst &c) {
        set_top_id(c.m_top_id);
        m_branches = c.m_branches;  // default copy
    }
    void clear(void) {
        set_top_id(kClkIdInvalid);
        m_branches.clear();
    }
    void set_top_id(const uint32_t &top_id) {
        m_top_id = top_id;
    }
    uint32_t get_top_id(void) {
        return m_top_id;
    }
    uint32_t branch_num(void) {
        return m_branches.size();
    }
    bool branch_empty(void) {
        return m_branches.empty();
    }
    bool branch_exist(const uint32_t &b_id) {
        if (branch_empty()) {
            return false;
        }
        if (kBrcIdInvalid == b_id) {
            return false;  // stop services
        }
        for (auto &any_b : m_branches) {
            if (b_id == any_b.b_id) {
                return true;
            }
        }
        return false;  // reaching means not found
    }
    branch_t &get_branch_by_id(const uint32_t &b_id) {
        for (auto &any_b : m_branches) {
            if (b_id == any_b.b_id) {
                return any_b;
            }
        }
        throw std::runtime_error("bgone-" + std::to_string(b_id));
    }
    branch_t &get_branch_by_nm(const uint32_t &b_nm) {
        for (auto &any_b : m_branches) {
            if (b_nm == any_b.b_name) {
                return any_b;
            }
        }
        throw std::runtime_error("bgone-" + std::to_string(b_nm));
    }
    void set_branch_info(const uint32_t &b_id, const double &b_f, const std::string &b_d) {
        branch_t &b = get_branch_by_id(b_id);
        b.b_freq    = b_f;
        b.b_desc    = b_d;
    }
    void set_clk_info(const uint32_t &b_nm, const double &b_f, const std::string &b_d) {
        branch_t &b = get_branch_by_nm(b_nm);
        b.b_freq    = b_f;
        b.b_desc    = b_d;
    }
    std::string get_branch_desc(const uint32_t &b_id) {
        branch_t &b = get_branch_by_id(b_id);
        return b.b_desc;
    }
    std::string get_clk_desc(const uint32_t &b_nm) {
        branch_t &b = get_branch_by_nm(b_nm);
        return b.b_desc;
    }
    double get_branch_freq(const uint32_t &b_id) {
        branch_t &b = get_branch_by_id(b_id);
        return b.b_freq;
    }
    double get_clk_freq(const uint32_t &b_nm) {
        branch_t &b = get_branch_by_nm(b_nm);
        return b.b_freq;
    }
    std::string get_clk_pipe(void) {
        std::stringstream msg_info("");
        for (auto &any_b : m_branches) {
            msg_info << std::endl
                     << top_id_2str(m_top_id) << "." << branch_id_2str(any_b.b_id) << "."
                     << std::setw(15) << std::left << clk_id_2str(any_b.b_name) << " "
                     << any_b.b_desc << " CLK " << std::to_string(any_b.b_freq);
        }
        return msg_info.str();
    }
    void branch(const uint32_t &b_id, const uint32_t &b_nm) {
        if (branch_exist(b_id)) {
            throw std::runtime_error("branch duplicated");
        }

        if (kClkIdInvalid == b_nm) {
            return;  // stop services
        }

        branch_t b_new = {};
        b_new.b_id     = b_id;
        b_new.b_name   = b_nm;
        b_new.b_freq   = 0.0;
        m_branches.push_back(b_new);
    }

    uint32_t              m_top_id;    // clock top id e.g. kClk0
    std::vector<branch_t> m_branches;  // clock branches
};

class clk_tree {
 public:
    clk_tree() {
        clear();
    }
    clk_tree(const clk_tree &t) {  // copy
        init(t);
    }
    clk_tree &operator=(const clk_tree &t) {  // assign
        init(t);
        return *this;
    }
    void init(const clk_tree &t) {
        mp_top_clk = t.mp_top_clk;
        mp_top_pll = t.mp_top_pll;
    }
    void clear(void) {
        mp_top_clk.clear();
        mp_top_pll.clear();
    }
    bool clk_exist(uint32_t top_id) {
        if (0 == top_num()) {
            return false;
        }
        if (kClkIdInvalid == top_id) {
            return false;  // stop services
        }
        auto mp_clk = mp_top_clk.find(top_id);
        return (mp_top_clk.end() != mp_clk);
    }
    bool pll_exist(uint32_t top_id, uint32_t pll_id) {
        if (0 == pll_num(top_id)) {
            return false;
        }
        if (kPllIdInvalid == pll_id) {
            return false;  // stop services
        }

        auto mp_pll = mp_top_pll.find(top_id);
        if (mp_top_pll.end() == mp_pll) {
            return false;
        }

        std::vector<pll_inst> &plls = mp_top_pll[top_id];
        for (uint32_t p = 0; p < plls.size(); p++) {
            if (pll_id == plls[p].m_pll_id)
                return true;
        }
        return false;
    }
    clk_inst &get_top(uint32_t top_id) {
        if (!clk_exist(top_id))
            throw std::runtime_error("req clk before build");

        return mp_top_clk[top_id];
    }
    pll_inst &get_pll(uint32_t top_id, uint32_t pll_id) {
        if (!pll_exist(top_id, pll_id))
            throw std::runtime_error("req pll before build");

        std::vector<pll_inst> &plls = mp_top_pll[top_id];
        for (uint32_t p = 0; p < plls.size(); p++) {
            if (pll_id == plls[p].m_pll_id)
                return plls[p];
        }

        throw std::runtime_error("req pll never reaching");
    }
    void build(uint32_t top_id, uint32_t pll_id) {
        if (!clk_exist(top_id)) {
            mp_top_clk[top_id] = clk_inst(top_id);
        }

        if (!pll_exist(top_id, pll_id)) {
            mp_top_pll[top_id].push_back(pll_inst(pll_id));
        }
    }
    void branch(uint32_t top_id, uint32_t b_id, uint32_t b_name) {
        clk_inst &clk = get_top(top_id);
        clk.branch(b_id, b_name);
    }
    std::string cnode_nxpll(const clk_inst &c) {
        std::stringstream msg_info("");
        msg_info << top_id_2str(c.m_top_id) << " " << pll_num(c.m_top_id) << "xPLL";
        return msg_info.str();
    }
    std::string pll_structure(void) {
        std::stringstream msg_info("");
        for (auto cm = mp_top_clk.begin(); cm != mp_top_clk.end(); ++cm) {
            auto &c_top_id   = cm->first;
            auto &c_top_inst = cm->second;
            msg_info << std::endl << cnode_nxpll(c_top_inst);

            for (auto pm = mp_top_pll.begin(); pm != mp_top_pll.end(); ++pm) {
                auto &p_top_id = pm->first;
                auto &p_pll_vc = pm->second;
                if (c_top_id != p_top_id)
                    continue;
                for (uint32_t p = 0; p < p_pll_vc.size(); p++) {
                    auto &pll = p_pll_vc[p];
                    msg_info << std::endl << "|- " << pll.get_debug_raw();
                }
            }
        }
        return msg_info.str();
    }
    std::string pll_config_raw(void) {
        std::stringstream msg_info("");
        for (auto cm = mp_top_clk.begin(); cm != mp_top_clk.end(); ++cm) {
            auto &c_top_id   = cm->first;
            auto &c_top_inst = cm->second;
            assert(c_top_id == c_top_inst.m_top_id);  // sanity check
            msg_info << std::endl << cnode_nxpll(c_top_inst);

            for (auto pm = mp_top_pll.begin(); pm != mp_top_pll.end(); ++pm) {
                auto &p_top_id = pm->first;
                auto &p_pll_vc = pm->second;
                if (c_top_id != p_top_id)
                    continue;
                for (uint32_t p = 0; p < p_pll_vc.size(); p++) {
                    auto &pll = p_pll_vc[p];
                    msg_info << std::endl << "|- " << pll.get_config_raw();
                }
            }
        }
        return msg_info.str();
    }
    std::string pll_info(void) {
        std::stringstream msg_info("");
        for (auto cm = mp_top_clk.begin(); cm != mp_top_clk.end(); ++cm) {
            auto &c_top_id   = cm->first;
            auto &c_top_inst = cm->second;
            assert(c_top_id == c_top_inst.m_top_id);  // sanity check
            msg_info << std::endl << cnode_nxpll(c_top_inst);

            for (auto pm = mp_top_pll.begin(); pm != mp_top_pll.end(); ++pm) {
                auto &p_top_id = pm->first;
                auto &p_pll_vc = pm->second;
                if (c_top_id != p_top_id)
                    continue;
                for (uint32_t p = 0; p < p_pll_vc.size(); p++) {
                    auto &pll = p_pll_vc[p];
                    msg_info << std::endl << "|- " << pll.get_calc_info();
                }
            }
        }
        return msg_info.str();
    }
    std::string clk_pipe(void) {
        std::stringstream msg_info("");
        for (auto cm = mp_top_clk.begin(); cm != mp_top_clk.end(); ++cm) {
            auto &c_top_id   = cm->first;
            auto &c_top_inst = cm->second;
            assert(c_top_id == c_top_inst.m_top_id);  // sanity check
            msg_info << std::endl << top_id_2str(c_top_id) << c_top_inst.get_clk_pipe();
        }
        return msg_info.str();
    }
    uint32_t top_num(void) {
        return mp_top_clk.size();
    }
    uint32_t pll_num(uint32_t top_id) {
        if (!clk_exist(top_id)) {
            return 0;
        }
        return mp_top_pll[top_id].size();
    }

    std::map<uint32_t, clk_inst>              mp_top_clk;  // build maintain
    std::map<uint32_t, std::vector<pll_inst>> mp_top_pll;  // build maintain
};

}  // namespace clk
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_CLK_NS_HPP_
