/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_DMA_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_DMA_NS_HPP_

#include <memory>
#include <string>

namespace efvf {
namespace framework {
namespace mem {
class Mem;
}  // namespace mem
}  // namespace framework
}  // namespace efvf
using efvf::framework::mem::Mem;

namespace efvf {
namespace hardware {
namespace ssm {
namespace dma {

typedef struct {
    uint32_t type;  // oput kSsmMem
    uint64_t adrs;  // oput ADDR START
    uint64_t adre;  // oput ADDR END
    uint64_t size;  // oput SIZE BYTE

    std::shared_ptr<Mem> pres;
} SsmDmaRes;

typedef struct {
    std::string copy_str;
    SsmDmaRes   copy_src;
    SsmDmaRes   copy_dst;
    SsmDmaRes   ofst_src;
    SsmDmaRes   ofst_dst;
    SsmDmaRes   base_src;
    SsmDmaRes   base_dst;

    void ofst_src_init(const uint64_t &ofst, const uint64_t &size) {
        uint64_t usr_sz = (0 == size) ? (base_src.size) : (size);
        uint64_t usr_st = (0 == ofst) ? (base_src.adrs) : (base_src.adrs + ofst);
        uint64_t usr_ed = usr_st + usr_sz;

        if (usr_st > base_src.adre) {
            usr_st = base_src.adrs;
            usr_ed = usr_st + usr_sz;
        }
        if (usr_ed > base_src.adre) {
            usr_ed = base_src.adre;
        }
        usr_sz = usr_ed - usr_st;

        ofst_src.type = base_src.type;
        ofst_src.adrs = usr_st;
        ofst_src.adre = usr_ed;
        ofst_src.size = usr_sz;
        ofst_src.pres = base_src.pres;
    }

    void ofst_dst_init(const uint64_t &ofst, const uint64_t &size) {
        uint64_t usr_sz = (0 == size) ? (base_dst.size) : (size);
        uint64_t usr_st = (0 == ofst) ? (base_dst.adrs) : (base_dst.adrs + ofst);
        uint64_t usr_ed = usr_st + usr_sz;

        if (usr_st > base_dst.adre) {
            usr_st = base_dst.adrs;
            usr_ed = usr_st + usr_sz;
        }
        if (usr_ed > base_dst.adre) {
            usr_ed = base_dst.adre;
        }
        usr_sz = usr_ed - usr_st;

        ofst_dst.type = base_dst.type;
        ofst_dst.adrs = usr_st;
        ofst_dst.adre = usr_ed;
        ofst_dst.size = usr_sz;
        ofst_dst.pres = base_dst.pres;
    }
} SsmDmaOp;

}  // namespace dma
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_DMA_NS_HPP_
