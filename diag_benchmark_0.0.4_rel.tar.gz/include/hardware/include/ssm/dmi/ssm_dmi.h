/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_DMI_SSM_DMI_H_
#define HARDWARE_INCLUDE_SSM_DMI_SSM_DMI_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace dmi {

class SsmDmi : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmDmi(Ssm *ssm);
    virtual ~SsmDmi() {}

 public:
    virtual bool        is_imu_supported(uint32_t);
    virtual bool        is_dmi_supported(uint32_t);
    virtual uint32_t    get_id_max(void);
    virtual uint32_t    dmi_enum_to_id(uint32_t &);
    virtual uint32_t    dmi_name_to_id(const std::string &);
    virtual std::string dmi_id_to_name(const uint32_t &);
    virtual std::string dmi_id_2str(const uint32_t &);
    virtual bool        chk_tid_valid(uint32_t);
    virtual std::string get_dmi_name(uint32_t);
    virtual std::string get_dmi_phyloc(uint32_t);
    virtual double      get_dmi_temp(const std::string &);
    virtual double      get_dmi_temp(uint32_t);
    virtual double      get_dmi_temp_enum(uint32_t);
    virtual void        get_dmi_rma_status(void *);
    virtual bool        get_dmi_rma_flag(void);
    virtual bool        get_hbm_swizzle_stat(void);
    virtual void        set_hbm_swizzle_stat(bool);
    virtual void        set_thres_alert(uint32_t);
    virtual void        set_thres_ctf(uint32_t);

 public:
    virtual bool test_dmi_each_t_ave_dvi(void);
    virtual bool test_dmi_each_t_ave_dvi_mixed(void);
    virtual bool test_dmi_each_t_in_range(void);

 public:
    virtual bool handle_req_ssm_ecc(const std::string &);
    virtual bool handle_req_ssm_rma(const std::string &, const std::string &);
};

}  // namespace dmi
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_DMI_SSM_DMI_H_
