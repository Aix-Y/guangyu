/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_SIH_SSM_SIH_H_
#define HARDWARE_INCLUDE_SSM_SIH_SSM_SIH_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace sih {

class SsmSih : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmSih(Ssm *ssm);
    virtual ~SsmSih() {}

 public:
    virtual bool test_mih_recv_interrupt(const std::string &);
    virtual bool test_mih_send_interrupt(const std::string &);
};

}  // namespace sih
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_SIH_SSM_SIH_H_
