/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_REG_SSM_REG_H_
#define HARDWARE_INCLUDE_SSM_REG_SSM_REG_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace reg {

class SsmReg : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmReg(Ssm *ssm);
    virtual ~SsmReg() {}

 public:
    virtual bool ssm_reg_path_h2ecf2ssm_r(void);
    virtual bool ssm_reg_path_h2ecf2ssm_wrcr(void);

 public:
    virtual bool handle_req_reg_op(const std::string &, const std::string &);
    virtual void handle_req_range(const std::string &);
};

}  // namespace reg
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_REG_SSM_REG_H_
