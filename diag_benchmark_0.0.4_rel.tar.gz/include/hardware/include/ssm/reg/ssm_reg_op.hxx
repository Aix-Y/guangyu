/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_REG_SSM_REG_OP_HXX_
#define HARDWARE_INCLUDE_SSM_REG_SSM_REG_OP_HXX_

#define __addrx32(_addr)                                          \
({                                                                \
    uint64_t __addrx64_v  = (_addr);                              \
    uint32_t __addrx32_v  = (uint32_t)(__addrx64_v & 0xFFFFFFFF); \
    assert((__addrx64_v) == (__addrx32_v));                       \
    assert((         0U) != (__addrx32_v));                       \
    assert((        ~0U) != (__addrx32_v));                       \
    (__addrx32_v);                                                \
})

#define __reg_f_g(_val, _reg, _f)                                 \
({                                                                \
    _reg##_u u_reg = { .val = _val };                             \
    (u_reg.f._f);                                                 \
})

#define __reg_f_s(_val, _reg, _f, _fv)                            \
({                                                                \
    _reg##_u u_reg = { .val = _val };                             \
    u_reg.f._f = (_fv);                                           \
    (u_reg.val);                                                  \
})

#define __regr32f(_reg, _f, _addr)                                \
(                                                                 \
    __reg_f_g(__regr32(_addr), _reg, _f)                          \
)

#define __regw32f(_reg, _f, _addr, _fv)                           \
(                                                                 \
    __regw32(_addr, __reg_f_s(__regr32(_addr), _reg, _f, (_fv)))  \
)

#define __regr32(_addr)                         (m_ssm->r_r32(__addrx32(_addr)))
#define __regw32(_addr, _val)                   (m_ssm->r_w32(__addrx32(_addr), (_val)))
#define __reg_base(_ip, _id, _sub)              (m_ssm->r_base(__reg_tag((_id), (_sub), _ip)))
#define __reg_tag(_id, _sub, _ip)               (#_ip + std::to_string(_id) + std::to_string(_sub))
#define __reg_o(_reg)                           (_reg##_OFFSET)

// macro mapping address
#define __reg_addr_ssm_base()                   (            0 + __reg_base(ssm_top,     (  0), (   0)))
#define __reg_addr_ssm_top(_reg)                (__reg_o(_reg) + __reg_base(ssm_top,     (  0), (   0)))
#define __reg_addr_ssm(_reg)                    (__reg_o(_reg) + __reg_base(ssm,         (  0), (   0)))
#define __reg_addr_mcu(_reg)                    (__reg_o(_reg) + __reg_base(ssm_mcu,     (  0), (   0)))
#define __reg_addr_fuse(_reg)                   (__reg_o(_reg) + __reg_base(ssm_fuse,    (  0), (   0)))
#define __reg_addr_otp(_reg)                    (__reg_o(_reg) + __reg_base(ssm_otp,     (  0), (   0)))
#define __reg_addr_uart(_reg, _sub)             (__reg_o(_reg) + __reg_base(ssm_uart,    (  0), (_sub)))
#define __reg_addr_se(_reg)                     (__reg_o(_reg) + __reg_base(ssm_se,      (  0), (   0)))
#define __reg_addr_rsa(_reg)                    (__reg_o(_reg) + __reg_base(ssm_rsa,     (  0), (   0)))
#define __reg_addr_sha(_reg)                    (__reg_o(_reg) + __reg_base(ssm_sha,     (  0), (   0)))
#define __reg_addr_aes(_reg)                    (__reg_o(_reg) + __reg_base(ssm_aes,     (  0), (   0)))
#define __reg_addr_xts(_reg)                    (__reg_o(_reg) + __reg_base(ssm_xts,     (  0), (   0)))
#define __reg_addr_tsen(_reg)                   (__reg_o(_reg) + __reg_base(ssm_tsen,    (  0), (   0)))
#define __reg_addr_ssm_vmc(_reg)                (__reg_o(_reg) + __reg_base(ssm_vmc,     (  0), (   0)))
#define __reg_addr_ssm_rmc(_reg)                (__reg_o(_reg) + __reg_base(ssm_rmc,     (  0), (   0)))
#define __reg_addr_smem(_off, _sub)             (       (_off) + __reg_base(ssm_smem,    (  0), (_sub)))
#define __reg_addr_iram(_off)                   (       (_off) + __reg_base(ssm_iram,    (  0), (   0)))
#define __reg_addr_dram(_off)                   (       (_off) + __reg_base(ssm_dram,    (  0), (   0)))
#define __reg_addr_fram(_off)                   (       (_off) + __reg_base(ssm_fram,    (  0), (   0)))
#define __reg_addr_otpm(_off)                   (       (_off) + __reg_base(ssm_otpm,    (  0), (   0)))
#define __reg_addr_boot(_off)                   (       (_off) + __reg_base(ssm_boot,    (  0), (   0)))
#define __reg_addr_ske(_off)                    (       (_off) + __reg_base(ssm_ske,     (  0), (   0)))
#define __reg_addr_hash(_off)                   (       (_off) + __reg_base(ssm_hash,    (  0), (   0)))
#define __reg_addr_pke(_off)                    (       (_off) + __reg_base(ssm_pke,     (  0), (   0)))
#define __reg_addr_trng(_off)                   (       (_off) + __reg_base(ssm_trng,    (  0), (   0)))
#define __reg_addr_dls(_off)                    (       (_off) + __reg_base(ssm_dls,     (  0), (   0)))
#define __reg_addr_ldma(_reg)                   (__reg_o(_reg) + __reg_base(ssm_ldma,    (  0), (   0)))
#define __reg_addr_ldma_vc(_reg, _sub)          (__reg_o(_reg) + __reg_base(ssm_ldmavc,  (  0), (_sub)))
#define __reg_addr_cpmu(_reg)                   (__reg_o(_reg) + __reg_base(ssm_cpmu,    (  0), (   0)))
#define __reg_addr_i2c(_reg, _sub)              (__reg_o(_reg) + __reg_base(ssm_i2c,     (  0), (_sub)))
#define __reg_addr_clk(_reg, _id, _sub)         (__reg_o(_reg) + __reg_base(ssm_clk,     (_id), (_sub)))
#define __reg_addr_ssm_mih(_reg)                (__reg_o(_reg) + __reg_base(ssm_mih,     (  0), (   0)))
#define __reg_addr_ts(_reg)                     (__reg_o(_reg) + __reg_base(ts,          (  0), (   0)))
#define __reg_addr_cqm(_reg, _id)               (__reg_o(_reg) + __reg_base(cqm,         (_id), (   0)))
#define __reg_addr_pcie(_reg)                   (__reg_o(_reg) + __reg_base(pcie,        (  0), (   0)))
#define __reg_addr_pcie_app(_reg)               (__reg_o(_reg) + __reg_base(pcie_app,    (  0), (   0)))
#define __reg_addr_pcie_ih(_reg)                (__reg_o(_reg) + __reg_base(pcie_ih,     (  0), (   0)))
#define __reg_addr_pcie_vm(_reg)                (__reg_o(_reg) + __reg_base(pcie_vm,     (  0), (   0)))
#define __reg_addr_mc(_reg, _id)                (__reg_o(_reg) + __reg_base(mc,          (  0), (   0)))
#define __reg_addr_sip(_reg, _id, _sub)         (__reg_o(_reg) + __reg_base(sip,         (_id), (_sub)))
#define __reg_addr_odma(_reg, _id)              (__reg_o(_reg) + __reg_base(odma,        (_id), (   0)))
#define __reg_addr_cdma(_reg, _id, _sub)        (__reg_o(_reg) + __reg_base(cdma,        (_id), (_sub)))
#define __reg_addr_cdma_lite(_reg, _id, _sub)   (__reg_o(_reg) + __reg_base(cdma_lite,   (_id), (_sub)))
#define __reg_addr_sdma(_reg, _id, _sub)        (__reg_o(_reg) + __reg_base(sdma,        (_id), (_sub)))
#define __reg_addr_vdec(_reg, _id)              (__reg_o(_reg) + __reg_base(vdec,        (_id), (   0)))
#define __reg_addr_hcvg(_reg, _id)              (__reg_o(_reg) + __reg_base(hcvg,        (_id), (   0)))
#define __reg_addr_hcvg_mpi(_reg, _id, _sub)    (__reg_o(_reg) + __reg_base(hcvg_mpi,    (_id), (_sub)))

// macro common wrapper
#define regr32(_addr)                           (__regr32((_addr)))
#define regw32(_addr, _val)                     (__regw32((_addr), (_val)))
#define regr32f(_reg, _f, _addr)                (__regr32f(_reg, _f, (_addr)))
#define regw32f(_reg, _f, _addr, _fv)           (__regw32f(_reg, _f, (_addr), (_fv)))

#define regr32_clk(_id, _sub, _reg)             (regr32(__reg_addr_clk(_reg, (_id), (_sub))))
#define regw32_clk(_id, _sub, _reg, _val)       (regw32(__reg_addr_clk(_reg, (_id), (_sub)), (_val)))
#define regr32f_clk(_id, _sub, _reg, _f)        (regr32f(_reg, _f, __reg_addr_clk(_reg, (_id), (_sub))))
#define regw32f_clk(_id, _sub, _reg, _f, _fv)   (regw32f(_reg, _f, __reg_addr_clk(_reg, (_id), (_sub)), (_fv)))

#define regr32_smem(_id, _off)                  (regr32(__reg_addr_smem(_off, (_id))))
#define regw32_smem(_id, _off, _val)            (regw32(__reg_addr_smem(_off, (_id)), (_val)))
#define regr32_iram(_off)                       (regr32(__reg_addr_iram(_off)))
#define regw32_iram(_off, _val)                 (regw32(__reg_addr_iram(_off), (_val)))
#define regr32_dram(_off)                       (regr32(__reg_addr_dram(_off)))
#define regw32_dram(_off, _val)                 (regw32(__reg_addr_dram(_off), (_val)))
#define regr32_fram(_off)                       (regr32(__reg_addr_fram(_off)))
#define regw32_fram(_off, _val)                 (regw32(__reg_addr_fram(_off), (_val)))
#define regr32_otpm(_off)                       (regr32(__reg_addr_otpm(_off)))
#define regw32_otpm(_off, _val)                 (regw32(__reg_addr_otpm(_off), (_val)))
#define regr32_dls(_off)                        (regr32(__reg_addr_dls(_off)))
#define regw32_dls(_off, _val)                  (regw32(__reg_addr_dls(_off), (_val)))

#define regr32_ssm(_reg)                        (regr32(__reg_addr_ssm(_reg)))
#define regw32_ssm(_reg, _val)                  (regw32(__reg_addr_ssm(_reg), (_val)))
#define regr32f_ssm(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_ssm(_reg)))
#define regw32f_ssm(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_ssm(_reg), (_fv)))

#define regr32_mcu(_reg)                        (regr32(__reg_addr_mcu(_reg)))
#define regw32_mcu(_reg, _val)                  (regw32(__reg_addr_mcu(_reg), (_val)))
#define regr32f_mcu(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_mcu(_reg)))
#define regw32f_mcu(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_mcu(_reg), (_fv)))

#define regr32_ldma(_reg)                       (regr32(__reg_addr_ldma(_reg)))
#define regw32_ldma(_reg, _val)                 (regw32(__reg_addr_ldma(_reg), (_val)))
#define regr32f_ldma(_reg, _f)                  (regr32f(_reg, _f, __reg_addr_ldma(_reg)))
#define regw32f_ldma(_reg, _f, _fv)             (regw32f(_reg, _f, __reg_addr_ldma(_reg), (_fv)))

#define regr32_sih(_reg)                        (regr32(__reg_addr_ssm_mih(_reg)))
#define regw32_sih(_reg, _val)                  (regw32(__reg_addr_ssm_mih(_reg), (_val)))
#define regr32f_sih(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_ssm_mih(_reg)))
#define regw32f_sih(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_ssm_mih(_reg), (_fv)))

#define regr32_ldma_vc(_id, _reg)               (regr32(__reg_addr_ldma_vc(_reg, (_id))))
#define regw32_ldma_vc(_id, _reg, _val)         (regw32(__reg_addr_ldma_vc(_reg, (_id)), (_val)))
#define regr32f_ldma_vc(_id, _reg, _f)          (regr32f(_reg, _f, __reg_addr_ldma_vc(_reg, (_id))))
#define regw32f_ldma_vc(_id, _reg, _f, _fv)     (regw32f(_reg, _f, __reg_addr_ldma_vc(_reg, (_id)), (_fv)))

#define regr32_fuse(_reg)                       (regr32(__reg_addr_fuse(_reg)))
#define regw32_fuse(_reg, _val)                 (regw32(__reg_addr_fuse(_reg), (_val)))
#define regr32f_fuse(_reg, _f)                  (regr32f(_reg, _f, __reg_addr_fuse(_reg)))
#define regw32f_fuse(_reg, _f, _fv)             (regw32f(_reg, _f, __reg_addr_fuse(_reg), (_fv)))

#define regr32_uart(_id, _reg)                  (regr32(__reg_addr_uart(_reg, (_id))))
#define regw32_uart(_id, _reg, _val)            (regw32(__reg_addr_uart(_reg, (_id)), (_val)))
#define regr32f_uart(_id, _reg, _f)             (regr32f(_reg, _f, __reg_addr_uart(_reg, (_id))))
#define regw32f_uart(_id, _reg, _f, _fv)        (regw32f(_reg, _f, __reg_addr_uart(_reg, (_id)), (_fv)))

#define regr32_i2c(_id, _reg)                   (regr32(__reg_addr_i2c(_reg, (_id))))
#define regw32_i2c(_id, _reg, _val)             (regw32(__reg_addr_i2c(_reg, (_id)), (_val)))
#define regr32f_i2c(_id, _reg, _f)              (regr32f(_reg, _f, __reg_addr_i2c(_reg, (_id))))
#define regw32f_i2c(_id, _reg, _f, _fv)         (regw32f(_reg, _f, __reg_addr_i2c(_reg, (_id)), (_fv)))

#define regr32_se(_reg)                         (regr32(__reg_addr_se(_reg)))
#define regw32_se(_reg, _val)                   (regw32(__reg_addr_se(_reg), (_val)))
#define regr32f_se(_reg, _f)                    (regr32f(_reg, _f, __reg_addr_se(_reg)))
#define regw32f_se(_reg, _f, _fv)               (regw32f(_reg, _f, __reg_addr_se(_reg), (_fv)))

#define regr32_rsa(_reg)                        (regr32(__reg_addr_rsa(_reg)))
#define regw32_rsa(_reg, _val)                  (regw32(__reg_addr_rsa(_reg), (_val)))
#define regr32f_rsa(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_rsa(_reg)))
#define regw32f_rsa(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_rsa(_reg), (_fv)))

#define regr32_sha(_reg)                        (regr32(__reg_addr_sha(_reg)))
#define regw32_sha(_reg, _val)                  (regw32(__reg_addr_sha(_reg), (_val)))
#define regr32f_sha(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_sha(_reg)))
#define regw32f_sha(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_sha(_reg), (_fv)))

#define regr32_aes(_reg)                        (regr32(__reg_addr_aes(_reg)))
#define regw32_aes(_reg, _val)                  (regw32(__reg_addr_aes(_reg), (_val)))
#define regr32f_aes(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_aes(_reg)))
#define regw32f_aes(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_aes(_reg), (_fv)))

#define regr32_xts(_reg)                        (regr32(__reg_addr_xts(_reg)))
#define regw32_xts(_reg, _val)                  (regw32(__reg_addr_xts(_reg), (_val)))
#define regr32f_xts(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_xts(_reg)))
#define regw32f_xts(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_xts(_reg), (_fv)))

#define regr32_ske(_reg)                        (regr32(__reg_addr_ske(_reg)))
#define regw32_ske(_reg, _val)                  (regw32(__reg_addr_ske(_reg), (_val)))
#define regr32f_ske(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_ske(_reg)))
#define regw32f_ske(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_ske(_reg), (_fv)))

#define regr32_hash(_reg)                       (regr32(__reg_addr_hash(_reg)))
#define regw32_hash(_reg, _val)                 (regw32(__reg_addr_hash(_reg), (_val)))
#define regr32f_hash(_reg, _f)                  (regr32f(_reg, _f, __reg_addr_hash(_reg)))
#define regw32f_hash(_reg, _f, _fv)             (regw32f(_reg, _f, __reg_addr_hash(_reg), (_fv)))

#define regr32_pke(_reg)                        (regr32(__reg_addr_pke(_reg)))
#define regw32_pke(_reg, _val)                  (regw32(__reg_addr_pke(_reg), (_val)))
#define regr32f_pke(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_pke(_reg)))
#define regw32f_pke(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_pke(_reg), (_fv)))

#define regr32_trng(_reg)                       (regr32(__reg_addr_trng(_reg)))
#define regw32_trng(_reg, _val)                 (regw32(__reg_addr_trng(_reg), (_val)))
#define regr32f_trng(_reg, _f)                  (regr32f(_reg, _f, __reg_addr_trng(_reg)))
#define regw32f_trng(_reg, _f, _fv)             (regw32f(_reg, _f, __reg_addr_trng(_reg), (_fv)))

#define regr32_tsen(_reg)                       (regr32(__reg_addr_tsen(_reg)))
#define regw32_tsen(_reg, _val)                 (regw32(__reg_addr_tsen(_reg), (_val)))
#define regr32f_tsen(_reg, _f)                  (regr32f(_reg, _f, __reg_addr_tsen(_reg)))
#define regw32f_tsen(_reg, _f, _fv)             (regw32f(_reg, _f, __reg_addr_tsen(_reg), (_fv)))

#define regr32_otp(_reg)                        (regr32(__reg_addr_otp(_reg)))
#define regw32_otp(_reg, _val)                  (regw32(__reg_addr_otp(_reg), (_val)))
#define regr32f_otp(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_otp(_reg)))
#define regw32f_otp(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_otp(_reg), (_fv)))

#define regr32_ts(_reg)                         (regr32(__reg_addr_ts(_reg)))
#define regw32_ts(_reg, _val)                   (regw32(__reg_addr_ts(_reg), (_val)))
#define regr32f_ts(_reg, _f)                    (regr32f(_reg, _f, __reg_addr_ts(_reg)))
#define regw32f_ts(_reg, _f, _fv)               (regw32f(_reg, _f, __reg_addr_ts(_reg), (_fv)))

#define regr32_cqm(_id, _reg)                   (regr32(__reg_addr_cqm(_reg, (_id))))
#define regw32_cqm(_id, _reg, _val)             (regw32(__reg_addr_cqm(_reg, (_id)), (_val)))
#define regr32f_cqm(_id, _reg, _f)              (regr32f(_reg, _f, __reg_addr_cqm(_reg, (_id))))
#define regw32f_cqm(_id, _reg, _f, _fv)         (regw32f(_reg, _f, __reg_addr_cqm(_reg, (_id)), (_fv)))

#define regr32_pcie(_reg)                       (regr32(__reg_addr_pcie(_reg)))
#define regw32_pcie(_reg, _val)                 (regw32(__reg_addr_pcie(_reg), (_val)))
#define regr32f_pcie(_reg, _f)                  (regr32f(_reg, _f, __reg_addr_pcie(_reg)))
#define regw32f_pcie(_reg, _f, _fv)             (regw32f(_reg, _f, __reg_addr_pcie(_reg), (_fv)))

#define regr32_pcie_app(_reg)                   (regr32(__reg_addr_pcie_app(_reg)))
#define regw32_pcie_app(_reg, _val)             (regw32(__reg_addr_pcie_app(_reg), (_val)))
#define regr32f_pcie_app(_reg, _f)              (regr32f(_reg, _f, __reg_addr_pcie_app(_reg)))
#define regw32f_pcie_app(_reg, _f, _fv)         (regw32f(_reg, _f, __reg_addr_pcie_app(_reg), (_fv)))

#define regr32_ih(_reg)                         (regr32(__reg_addr_pcie_ih(_reg)))
#define regw32_ih(_reg, _val)                   (regw32(__reg_addr_pcie_ih(_reg), (_val)))
#define regr32f_ih(_reg, _f)                    (regr32f(_reg, _f, __reg_addr_pcie_ih(_reg)))
#define regw32f_ih(_reg, _f, _fv)               (regw32f(_reg, _f, __reg_addr_pcie_ih(_reg), (_fv)))

#define regr32_mc(_id, _reg)                    (regr32(__reg_addr_mc(_reg, (_id))))
#define regw32_mc(_id, _reg, _val)              (regw32(__reg_addr_mc(_reg, (_id)), (_val)))
#define regr32f_mc(_id, _reg, _f)               (regr32f(_reg, _f, __reg_addr_mc(_reg, (_id))))
#define regw32f_mc(_id, _reg, _f, _fv)          (regw32f(_reg, _f, __reg_addr_mc(_reg, (_id)), (_fv)))

#define regr32_sip(_id, _sub, _reg)             (regr32(__reg_addr_sip(_reg, (_id), (_sub))))
#define regw32_sip(_id, _sub, _reg, _val)       (regw32(__reg_addr_sip(_reg, (_id), (_sub)), (_val)))
#define regr32f_sip(_id, _sub, _reg, _f)        (regr32f(_reg, _f, __reg_addr_sip(_reg, (_id), (_sub))))
#define regw32f_sip(_id, _sub, _reg, _f, _fv)   (regw32f(_reg, _f, __reg_addr_sip(_reg, (_id), (_sub)), (_fv)))

#define regr32_odma(_id, _reg)                  (regr32(__reg_addr_odma(_reg, (_id))))
#define regw32_odma(_id, _reg, _val)            (regw32(__reg_addr_odma(_reg, (_id)), (_val)))
#define regr32f_odma(_id, _reg, _f)             (regr32f(_reg, _f, __reg_addr_odma(_reg, (_id))))
#define regw32f_odma(_id, _reg, _f, _fv)        (regw32f(_reg, _f, __reg_addr_odma(_reg, (_id)), (_fv)))

#define regr32_cdma(_id, _sub, _reg)            (regr32(__reg_addr_cdma(_reg, (_id), (_sub))))
#define regw32_cdma(_id, _sub, _reg, _val)      (regw32(__reg_addr_cdma(_reg, (_id), (_sub)), (_val)))
#define regr32f_cdma(_id, _sub, _reg, _f)       (regr32f(_reg, _f, __reg_addr_cdma(_reg, (_id), (_sub))))
#define regw32f_cdma(_id, _sub, _reg, _f, _fv)  (regw32f(_reg, _f, __reg_addr_cdma(_reg, (_id), (_sub)), (_fv)))

#define regr32_sdma(_id, _sub, _reg)            (regr32(__reg_addr_sdma(_reg, (_id), (_sub))))
#define regw32_sdma(_id, _sub, _reg, _val)      (regw32(__reg_addr_sdma(_reg, (_id), (_sub)), (_val)))
#define regr32f_sdma(_id, _sub, _reg, _f)       (regr32f(_reg, _f, __reg_addr_sdma(_reg, (_id), (_sub))))
#define regw32f_sdma(_id, _sub, _reg, _f, _fv)  (regw32f(_reg, _f, __reg_addr_sdma(_reg, (_id), (_sub)), (_fv)))

#define regr32_cpmu(_reg)                       (regr32(__reg_addr_cpmu(_reg)))
#define regw32_cpmu(_reg, _val)                 (regw32(__reg_addr_cpmu(_reg), (_val)))
#define regr32f_cpmu(_reg, _f)                  (regr32f(_reg, _f, __reg_addr_cpmu(_reg)))
#define regw32f_cpmu(_reg, _f, _fv)             (regw32f(_reg, _f, __reg_addr_cpmu(_reg), (_fv)))

#endif  // HARDWARE_INCLUDE_SSM_REG_SSM_REG_OP_HXX_
