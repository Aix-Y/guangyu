/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_INTF_SSM_INTF_H_
#define HARDWARE_INCLUDE_SSM_INTF_SSM_INTF_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace intf {

class SsmIntf : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmIntf(Ssm *ssm);
    virtual ~SsmIntf() {}

 public:
    virtual double xpu_get_v(const std::string &);
    virtual double xpu_get_c(const std::string &);
    virtual double xpu_get_t(const std::string &);
    virtual double xpu_get_f(const std::string &);
    virtual double xpu_get_p(const std::string &);
    virtual bool   ecc_mode_get_ena(void);
    virtual void   ecc_mode_set_ena(bool);
    virtual void   ecc_stat_get(SSM_ECC_STAT_t &);
};

}  // namespace intf
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_INTF_SSM_INTF_H_
