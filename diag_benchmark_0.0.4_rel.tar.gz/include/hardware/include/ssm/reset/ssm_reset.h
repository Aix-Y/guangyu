/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_RESET_SSM_RESET_H_
#define HARDWARE_INCLUDE_SSM_RESET_SSM_RESET_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace reset {

class SsmReset : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmReset(Ssm *ssm);
    virtual ~SsmReset() {}

 public:
    virtual void ip_blr_list_support(void);
    virtual bool ip_blr_check_valid(const std::string &);
    virtual void ip_blr_fw_trigger(const std::string &);
};

}  // namespace reset
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_RESET_SSM_RESET_H_
