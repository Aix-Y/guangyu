/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_PINS_SSM_PINS_H_
#define HARDWARE_INCLUDE_SSM_PINS_SSM_PINS_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace pins {

class SsmPins : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmPins(Ssm *ssm);
    virtual ~SsmPins() {}

 public:
    virtual bool handle_req_edc_op(const std::string &);
    virtual bool handle_req_ldidt_op(const std::string &);
    virtual bool handle_req_pins_set(const std::string &);
    virtual bool handle_req_pins_set(const std::string &, const std::string &);
    virtual bool handle_req_pins_set(const std::string &, uint32_t &, uint32_t &);
};

}  // namespace pins
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_PINS_SSM_PINS_H_
