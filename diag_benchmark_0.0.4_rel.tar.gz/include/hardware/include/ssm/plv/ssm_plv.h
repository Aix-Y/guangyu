/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_PLV_SSM_PLV_H_
#define HARDWARE_INCLUDE_SSM_PLV_SSM_PLV_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

#include "hardware/include/sysm/sys_mon_task_ns.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace plv {

using efvf::hardware::sysm::syst_param_plv_t;
using efvf::hardware::sysm::syst_samplet_v3;

class SsmPlv : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmPlv(Ssm *ssm);
    virtual ~SsmPlv() {}

 public:
    virtual bool     get_plv_feat_ena(syst_param_plv_t &);
    virtual uint32_t get_plv_lv(syst_param_plv_t &);
    virtual uint32_t get_plv_lv_min(syst_param_plv_t &);
    virtual uint32_t get_plv_lv_max(syst_param_plv_t &);
    virtual bool     get_plv_lv_vld(syst_param_plv_t &, uint32_t &);
    virtual uint32_t get_plv_lv_next(syst_param_plv_t &, uint32_t &);
    virtual void     set_plv_lv(syst_param_plv_t &, uint32_t &);
    virtual bool     chk_plv_samplet(syst_param_plv_t &, syst_samplet_v3 &);

 public:
    virtual void     set_doze_ena(bool);
    virtual void     set_doze_delay(uint32_t);
    virtual void     set_cur_ena(bool);
    virtual void     set_dpm_ena(bool);
    virtual void     set_kfc_ena(bool);
    virtual uint32_t get_kfc_lv_dtu(void);
    virtual void     set_kfc_lv_dtu(uint32_t);
    virtual uint32_t get_kfc_lv_soc(void);
    virtual void     set_kfc_lv_soc(uint32_t);
    virtual void     set_dpm_level(uint32_t);
    virtual uint32_t get_dpm_level(void);
    virtual void     set_dpm_max(uint32_t);
    virtual uint32_t get_dpm_max(void);
    virtual void     set_thm_ena(bool, uint32_t);
    virtual void     set_thm_pid_cfg(uint32_t, uint32_t, uint32_t, uint32_t);
    virtual void     set_thm_pid_point(uint32_t, uint32_t, uint32_t);
    virtual void     set_thm_fan_pwm(uint32_t);
    virtual void     set_vr_ena(bool);
    virtual void     set_int_ena(bool);
    virtual void     set_tsen_ena(bool);
    virtual double   get_ocp_threshold(void);
    virtual void     set_ocp_threshold(double);

 public:
    virtual void handle_req_dpm_status(void);
    virtual void handle_req_kfc_status(void);
    virtual bool handle_req_kfc_lv_op(const std::string &, const std::string &);
};

}  // namespace plv
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_PLV_SSM_PLV_H_
