/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_CLK_SSM_CLK_H_
#define HARDWARE_INCLUDE_SSM_CLK_SSM_CLK_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace clk {

class SsmClk : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmClk(Ssm *ssm);
    virtual ~SsmClk() {}

 protected:
    std::string mhz_l0(std::string);
    std::string mhz_l1(std::string);
    std::string mhz_l1(std::string, uint32_t);
    std::string mbs_l1(std::string, uint32_t);
    std::string gbs_l1(std::string, uint32_t);
    std::string gbs_l1(std::string, double);
    std::string mhz_l2(std::string, uint32_t);
    std::string mhz_l3(std::string, uint32_t);

 public:
    virtual void     ssm_clk_set(uint32_t, uint32_t);
    virtual uint32_t ssm_clk_get(uint32_t);
    virtual void     ssm_clk_get_list(uint32_t *);
    virtual bool     ssm_clk_ckb_in_use(void);
    virtual uint32_t ssm_clk_ckb_lv_get(uint32_t);
    virtual void     ssm_clk_gcu_2ref(void);
    virtual double   ssm_clk_obs(uint32_t, uint32_t);

 public:
    virtual bool test_pll_mpll_bpll_switch(void);
    virtual bool test_clk_obs_freq_dump(void);
    virtual void test_clk_obs_freq_dump_all(void);
    virtual bool test_clk_obs_vs_obs_div_sweep(void);
    virtual bool test_clk_obs_vs_clk_div_freq(void);
    virtual bool test_clk_obs_vs_clk_div_freq_sweep(void);
    virtual bool test_clk_obs_vs_clk_csc_fw_tt_sweep(void);
    virtual bool test_clk_obs_vs_clk_mux_switch(void);
    virtual bool test_clk_csc_fw_tt_sweep(void);
    virtual bool test_clk_csc_fw_tt_random(void);
    virtual bool test_clk_csc_oct_verify(void);
    virtual bool test_clk_csc_oct_random(void);
    virtual bool test_clk_csc_oct_random_all(void);
    virtual bool test_clk_csc_oct_fw_tt_shadow(void);
    virtual bool test_clk_csc_oct_ceiling(void);
    virtual bool test_clk_csc_oct_step_verify(void);
    virtual bool test_clk_gd_toggle_single(void);
    virtual bool test_clk_gd_toggle_random(void);
    virtual bool test_clk_gd_toggle_vs_csc_oct(void);
    virtual void test_pll_info_dump(void);
    virtual void test_clk_info_dump(void);
    virtual void test_clk_pipe_dump(void);

 public:
    virtual bool test_clk_golden_range(void);

 public:
    virtual std::string handle_req_csc_get_str(const std::string &);
    virtual bool        handle_req_csc_set(const std::string &);
    virtual bool        handle_req_csc_set(const std::string &, uint32_t &);
    virtual bool        handle_req_csc_set(const std::string &, const std::string &);
    virtual bool handle_req_csc_set(const std::string &, const std::string &, uint32_t &);
    virtual std::string handle_req_ckb_get_str(const std::string &);
    virtual bool        handle_req_ckb_set(const std::string &);
    virtual bool        handle_req_ckb_set(const std::string &, uint32_t &);
    virtual bool handle_req_ckb_set(const std::string &, const std::string &, uint32_t &);
    virtual std::string handle_req_obs_wp(const std::string &, const std::string &);
    virtual std::string handle_req_obs_cfg(const std::string &);
    virtual std::string handle_req_obs_list(const std::string &, uint32_t &, uint32_t &);
    virtual bool        handle_req_clk_list(const std::string &);
    virtual bool        handle_req_clk_lobs(const std::string &);
    virtual void        handle_req_clk_event_status(const std::string &);
    virtual void        handle_req_clk_event_op(bool, const std::string &);
    virtual bool        handle_req_clk_test(const std::string &, const std::string &);
    virtual bool        handle_req_clk_op(const std::string &);
};

}  // namespace clk
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_CLK_SSM_CLK_H_
