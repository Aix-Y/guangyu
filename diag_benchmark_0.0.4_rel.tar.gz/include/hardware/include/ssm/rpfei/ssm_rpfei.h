/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_RPFEI_SSM_RPFEI_H_
#define HARDWARE_INCLUDE_SSM_RPFEI_SSM_RPFEI_H_

#include <string>

#include "hardware/include/ras.h"

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace rpfei {

class SsmRpfei : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmRpfei(Ssm *ssm);
    virtual ~SsmRpfei() {}

 public:
    virtual bool     get_int_arv(uint32_t);
    virtual bool     get_int_ena(uint32_t);
    virtual void     set_int_ena(uint32_t);
    virtual void     set_int_dis(uint32_t);
    virtual void     set_int_clr(uint32_t);
    virtual void     set_axuser(const std::string &);
    virtual uint32_t get_axuser(const std::string &);

 public:
    virtual bool test_rpfei_ssm_as_ecf_slv_r(const std::string &);
    virtual bool test_rpfei_ssm_as_ecf_slv_w(const std::string &);
    virtual bool test_rpfei_ssm_as_ecf_mst_r(const std::string &);
    virtual bool test_rpfei_ssm_as_ecf_mst_w(const std::string &);
    virtual bool test_rpfei_ssm_as_edf_mst_r(const std::string &);
    virtual bool test_rpfei_ssm_as_edf_mst_w(const std::string &);
    virtual bool test_rpfei_ibound_interrupt(const std::string &);
    virtual bool test_rpfei_obound_fatal_error(const std::string &);
    virtual bool test_rpfei_ram_nxwnxr_check(const std::string &);
    virtual bool test_rpfei_ram_1xw1xr_check(const std::string &);
    virtual bool test_rpfei_ram_no_gen_check(const std::string &);
    virtual bool test_rpfei_ram_err_scan(const std::string &);
    virtual bool test_rpfei_sanity_check(const std::string &);

 public:
    virtual void       handle_ras_req(const std::string &, std::string = "");
    virtual void       handle_ras_ena(RasCfg *);
    virtual void       handle_ras_dis(RasCfg *);
    virtual void       handle_ras_clr(RasCfg *);
    virtual void       handle_ras_query(RasErrStat *);
    virtual void       handle_ras_inj_stop(RasErrInj *);
    virtual void       handle_ras_inj_start(RasErrInj *);
    virtual RasErrInj *handle_ras_inj_cfg_gen(const std::string &, bool);
};

}  // namespace rpfei
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_RPFEI_SSM_RPFEI_H_
