/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_HWSYNC_HWSYNC_NEW_H_
#define HARDWARE_INCLUDE_HWSYNC_HWSYNC_NEW_H_
#include <sys/types.h>
#include <cstdint>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace hwsync {

struct HwSyncVgResource {
    uint32_t vg_id;
    // mutex
    uint32_t mutex_num     = 0;
    uint32_t sta_mutex_num = 0;
    // cnt
    uint32_t cnt_num     = 0;
    uint32_t sta_cnt_num = 0;
    // entry
    uint32_t entry_num = 0;
};

struct HwSyncVgInitParam {
    uint32_t                      vg_num = 0;
    std::vector<HwSyncVgResource> vg_desc;
};

struct HwSyncCtxInitParam {
    std::vector<uint32_t> ctx_vg_map;
};

struct HwSyncLutInfo {
    uint32_t lut_id;
    uint32_t addr;
    uint32_t axi_id;
    HwSyncLutInfo(uint32_t lut_id, uint32_t addr, uint32_t axi_id)
        : lut_id(lut_id), addr(addr), axi_id(axi_id) {}
};

struct HwSyncLutInitParam {
    std::vector<HwSyncLutInfo> lut_info;
};

struct HwSyncNotifyInfo {
    uint32_t lut_id;
    uint32_t notify_data;
    HwSyncNotifyInfo() {}
    HwSyncNotifyInfo(uint32_t lut_id, uint32_t notify_data)
        : lut_id(lut_id), notify_data(notify_data) {}
};

struct HwSyncRegisterInfo {
    uint32_t         cnt_alloc_id;
    uint32_t         uniq_id;
    HwSyncNotifyInfo notify_info;
    HwSyncRegisterInfo() {}
    HwSyncRegisterInfo(
        uint32_t cnt_alloc_id, uint32_t uniq_id, uint32_t lut_id, uint32_t notify_data)
        : cnt_alloc_id(cnt_alloc_id), uniq_id(uniq_id), notify_info(lut_id, notify_data) {}
};

struct HwSyncCntInitInfo {
    uint32_t config_uniq_id;
    uint32_t threshold;
    uint32_t cnt_alloc_id;
    HwSyncCntInitInfo() {}
    HwSyncCntInitInfo(uint32_t config_uniq_id, uint32_t threshold, uint32_t cnt_alloc_id)
        : config_uniq_id(config_uniq_id), threshold(threshold), cnt_alloc_id(cnt_alloc_id) {}
};

enum HwSyncSyncType : uint32_t {
    kBarrier   = 0,
    kEvent     = 1,
    kLatch     = 2,
    kQueueProd = 3,
    kQueueCons = 4,
    kDefault   = 7,
};

struct HwSyncStaCntAllocInfo {
    uint32_t       res_id;
    uint32_t       static_alloc_id;
    HwSyncSyncType sync_type;
    // uint32_t       cnt_uniq_id;
    // uint32_t       cnt_value;
    HwSyncStaCntAllocInfo() {}
    HwSyncStaCntAllocInfo(uint32_t res_id, uint32_t static_alloc_id, HwSyncSyncType sync_type)
        : res_id(res_id), static_alloc_id(static_alloc_id), sync_type(sync_type) {}
};

struct HwSyncStaCntAllocParam {
    std::vector<HwSyncStaCntAllocInfo> cnt_sta_alloc_info;
};

struct HwSyncUnRegisterInfo {
    uint32_t       cnt_alloc_id;
    uint32_t       uniq_id;
    HwSyncSyncType sync_type;
    HwSyncUnRegisterInfo() {}
    HwSyncUnRegisterInfo(uint32_t cnt_alloc_id, uint32_t uniq_id, HwSyncSyncType sync_type)
        : cnt_alloc_id(cnt_alloc_id), uniq_id(uniq_id), sync_type(sync_type) {}
};

static const std::map<uint32_t, std::string> kHwSyncStatus = {
    {0, "register entry error"}, {1, "bresp error"}, {2, "unlock a unlocked mutex"},
    {3, "deallocate a locked mutex"}, {4, "mutex allocate error"}, {5, "cnt allocate error"},
    {6, "mutex deallocate error"}, {7, "cnt deallocate error"},
    {8, "cnt init a not available cnt resource"}, {9, "cnt signal uniq id mismatch"},
    {10, "cnt signal type error"}, {11, "cnt signal value error"},
    {12, "barrier arrive_and_drop error(thres underflow)"},
    {13, "register a not initialized region(VG not allocated resource)"},
    {14, "register sequence error"}, {15, "register a not available cnt"},
    {16, "register alloc_id/uniq_id mismatch"}, {17, "register lut id overflow"},
    {18, "unregister a entry that has not been notified"},
    {19, "unregister id mismatch(is not a onehot)"}, {20, "unregister id mismatch(no match)"},
    {21, "unregister a not available cnt"},
    {22, "lut axi id is greater than the specified value"}, {23, "context error"},
};

class HwSyncInt {
 private:
    uint32_t    id;
    std::string desc;

    HwSyncInt(uint32_t id, const std::string &desc) : id(id), desc(desc) {}

 public:
    explicit HwSyncInt(uint32_t id) : HwSyncInt(id, kHwSyncStatus.at(id)) {}

    std::string What() const {
        return desc;
    }

    uint32_t Id() const {
        return id;
    }

    bool operator==(const HwSyncInt &excp) const {
        return id == excp.id && desc == excp.desc;
    }

    static uint32_t ToMask(const std::vector<HwSyncInt> &excp) {
        std::bitset<32> bs(0);
        for (auto &e : excp) {
            bs.set(e.id);
        }
        return bs.to_ulong();
    }

    static std::vector<HwSyncInt> GetAllExcp(uint32_t sts) {
        std::vector<HwSyncInt> res;
        std::bitset<32>        bs(sts);
        for (uint32_t i = 0; i < 32; i++) {
            if (bs.test(i)) {
                res.emplace_back(i);
            }
        }
        return res;
    }

    static HwSyncInt RegisterErr() {
        return HwSyncInt(0);
    }
    static HwSyncInt BrespErr() {
        return HwSyncInt(1);
    }
    static HwSyncInt UnlockUnlockedMutexErr() {
        return HwSyncInt(2);
    }
    static HwSyncInt DeallocLockedMutexErr() {
        return HwSyncInt(3);
    }
    static HwSyncInt AllocMutexErr() {
        return HwSyncInt(4);
    }
    static HwSyncInt AllocCntErr() {
        return HwSyncInt(5);
    }
    static HwSyncInt DeallocMutexErr() {
        return HwSyncInt(6);
    }
    static HwSyncInt DeallocCntErr() {
        return HwSyncInt(7);
    }
    static HwSyncInt InitNonAvailCntErr() {
        return HwSyncInt(8);
    }
    static HwSyncInt SignalUniqIdMismatchErr() {
        return HwSyncInt(9);
    }
    static HwSyncInt SignalTypeErr() {
        return HwSyncInt(10);
    }
    static HwSyncInt SignalValueErr() {
        return HwSyncInt(11);
    }
    static HwSyncInt BarrierArriveAndDropErr() {
        return HwSyncInt(12);
    }
    static HwSyncInt RegisterNonInitRegionErr() {
        return HwSyncInt(13);
    }
    static HwSyncInt RegisterSequenceErr() {
        return HwSyncInt(14);
    }
    static HwSyncInt RegisterNonAvailCntErr() {
        return HwSyncInt(15);
    }
    static HwSyncInt RegisterAllocIdOrUniqIdMismatchErr() {
        return HwSyncInt(16);
    }
    static HwSyncInt RegisterLutIdOverflowErr() {
        return HwSyncInt(17);
    }
    static HwSyncInt UnregisterEntryNotNotifiedErr() {
        return HwSyncInt(18);
    }
    static HwSyncInt UnregisterIdMismatchNonOnehotErr() {
        return HwSyncInt(19);
    }
    static HwSyncInt UnregisterIdMismatchErr() {
        return HwSyncInt(20);
    }
    static HwSyncInt UnregisterNonAvailCntErr() {
        return HwSyncInt(21);
    }
    static HwSyncInt LutAxiIdGtSpecValueErr() {
        return HwSyncInt(22);
    }
    static HwSyncInt ContextErr() {
        return HwSyncInt(23);
    }
};

struct HwSyncCntSelfClrCfg {
    bool barrier_self_clr = true;
    bool event_self_clr   = true;
    bool latch_self_clr   = false;
    bool queue_self_clr   = true;

    uint32_t value() const {
        std::bitset<32> bs(0);
        if (barrier_self_clr) {
            bs.set(0);
        } else {
            bs.reset(0);
        }
        if (event_self_clr) {
            bs.set(1);
        } else {
            bs.reset(1);
        }
        if (latch_self_clr) {
            bs.set(2);
        } else {
            bs.reset(2);
        }
        if (queue_self_clr) {
            bs.set(3);
        } else {
            bs.reset(3);
        }
        return bs.to_ulong();
    }
};

struct HwSyncEntryVldSelfClrCfg {
    bool barrier_self_clr = true;
    bool event_self_clr   = true;
    bool latch_self_clr   = true;
    bool queue_self_clr   = true;

    uint32_t value() const {
        std::bitset<32> bs(0);
        if (barrier_self_clr) {
            bs.set(0);
        } else {
            bs.reset(0);
        }
        if (event_self_clr) {
            bs.set(1);
        } else {
            bs.reset(1);
        }
        if (latch_self_clr) {
            bs.set(2);
        } else {
            bs.reset(2);
        }
        if (queue_self_clr) {
            bs.set(3);
        } else {
            bs.reset(3);
        }
        return bs.to_ulong();
    }
};

struct HwSyncCntTrigSelfClrCfg {
    bool barrier_self_clr = true;
    bool event_self_clr   = true;
    bool latch_self_clr   = false;
    bool queue_self_clr   = true;

    uint32_t value() const {
        std::bitset<32> bs(0);
        if (barrier_self_clr) {
            bs.set(0);
        } else {
            bs.reset(0);
        }
        if (event_self_clr) {
            bs.set(1);
        } else {
            bs.reset(1);
        }
        if (latch_self_clr) {
            bs.set(2);
        } else {
            bs.reset(2);
        }
        if (queue_self_clr) {
            bs.set(3);
        } else {
            bs.reset(3);
        }
        return bs.to_ulong();
    }
};

struct HwSyncInterruptCfg {
    uint32_t              sp_mih_base_addr;
    uint32_t              host_mih_base_addr;
    uint32_t              sp_int_mask;
    uint32_t              host_int_mask;
    std::vector<uint32_t> int_wdata;
};

struct HwSyncInterruptLog {
    uint32_t              int_sts;
    std::vector<uint32_t> int_err_log;

    bool operator==(const HwSyncInterruptLog &log) const {
        return log.int_err_log == int_err_log && log.int_sts == int_sts;
    }

    bool Cmp(const HwSyncInterruptLog &log, std::stringstream &ss) {
        bool ret = true;
        if (log.int_sts != int_sts) {
            ss << "hwsync interrupt log cmp, expect sts " << std::hex << int_sts;
            ss << " real sts " << log.int_sts << std::endl;
            ret = false;
        }
        if (log.int_err_log != int_err_log) {
            ss << "hwsync interrupt log cmp, expect logs:" << std::endl;
            for (uint32_t idx = 0; idx < int_err_log.size(); idx++) {
                auto &l = int_err_log[idx];
                ss << std::hex << idx << ": " << l << std::endl;
            }
            ss << "real logs:" << std::endl;
            for (uint32_t idx = 0; idx < log.int_err_log.size(); idx++) {
                auto &l = log.int_err_log[idx];
                ss << std::hex << idx << ": " << l << std::endl;
            }
            ret = false;
        }
        return ret;
    }
};

struct HwSyncInterruptSts {
    uint32_t               int_sts;
    std::vector<HwSyncInt> interrupt;

    bool operator==(const HwSyncInterruptSts &sts) const {
        return sts.interrupt == interrupt && sts.int_sts == int_sts;
    }

    bool Cmp(const HwSyncInterruptSts &sts, std::stringstream &ss) {
        bool ret = true;
        if (sts.int_sts != int_sts) {
            ss << "hwsync interrupt sts cmp, expect sts " << std::hex << int_sts;
            ss << " real sts " << sts.int_sts << std::endl;
            ret = false;
        }
        if (sts.interrupt != interrupt) {
            ss << "hwsync interrupt sts cmp, expect interrupts:" << std::endl;
            for (auto &l : interrupt) {
                ss << std::hex << l.Id() << ":" << l.What() << std::endl;
            }
            ss << "real interrupts:" << std::endl;
            for (auto &l : sts.interrupt) {
                ss << std::hex << l.Id() << ":" << l.What() << std::endl;
            }
            ret = false;
        }
        return ret;
    }
};

/**
 * @brief HwSync Basic Hardware Interface
 */
class HwSync : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit HwSync(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~HwSync() {}

 public:
    virtual void InitVgResource(const HwSyncVgInitParam &res_param)           = 0;
    virtual void InitCtx(const HwSyncCtxInitParam &ctx_param)                 = 0;
    virtual void InitLut(const HwSyncLutInitParam &lut_param)                 = 0;
    virtual void InitAllocStaCnt(const HwSyncStaCntAllocParam &cnt_sta_param) = 0;

    virtual void SetLut(const HwSyncLutInfo &lut_info) = 0;
    virtual void SetLut(uint32_t lut_id, uint32_t addr, uint32_t axi_id) = 0;
    virtual void SetRegister(const HwSyncRegisterInfo &register_info)       = 0;
    virtual void ResetRegister(const HwSyncUnRegisterInfo &unregister_info) = 0;
    virtual void InitCnt(const HwSyncCntInitInfo &cnt_info)                 = 0;

    virtual void AllocStaCnt(const HwSyncStaCntAllocInfo &alloc_info) = 0;

 public:
    virtual uint32_t GetMaxMutex() = 0;
    virtual uint32_t GetMaxCnt()   = 0;
    virtual uint32_t GetMaxEntry() = 0;

    virtual uint32_t GetStaMutexNum(uint32_t vg_id) = 0;
    virtual uint32_t GetStaCntNum(uint32_t vg_id)   = 0;
    virtual uint32_t GetDynMutexNum(uint32_t vg_id) = 0;
    virtual uint32_t GetDynCntNum(uint32_t vg_id)   = 0;
    virtual uint32_t GetEntryNum(uint32_t vg_id)    = 0;

    virtual void ForceClearEntry(uint32_t entry_id)     = 0;
    virtual void ForceClearAllEntries()                 = 0;
    virtual void ForceClearCounter(uint32_t counter_id) = 0;
    virtual void ForceClearAllCounters()                = 0;
    virtual void ForceClearMutex(uint32_t mutex_id)     = 0;
    virtual void ForceClearAllMutex()                   = 0;

 public:
    // MUTEX
    virtual uint32_t AllocMutex()                = 0;
    virtual void DeallocMutex(uint32_t mutex_id) = 0;
    virtual bool TryLockMutex(uint32_t mutex_id) = 0;
    virtual void UnlockMutex(uint32_t mutex_id)  = 0;
    // BARRIER
    virtual uint32_t AllocBarrier()                  = 0;
    virtual void DeallocBarrier(uint32_t barrier_id) = 0;
    virtual void SetBarrierCount(uint32_t barrier_id, uint32_t count, uint32_t uniq_id) = 0;
    virtual void RegisterBarrierWait(
        uint32_t barrier_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info) = 0;
    virtual void ArriveBarrier(uint32_t barrier_id, uint32_t uniq_id)         = 0;
    virtual void ArriveAndDropBarrier(uint32_t barrier_id, uint32_t uniq_id)  = 0;
    virtual void UnRegisterBarrierWait(uint32_t barrier_id, uint32_t uniq_id) = 0;
    // LATCH
    virtual uint32_t AllocLatch()                = 0;
    virtual void DeallocLatch(uint32_t latch_id) = 0;
    virtual void SetLatchCount(uint32_t latch_id, uint32_t count, uint32_t uniq_id) = 0;
    virtual void RegisterLatchWait(
        uint32_t latch_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info) = 0;
    virtual void ArriveLatch(uint32_t latch_id, uint32_t count, uint32_t uniq_id) = 0;
    virtual void UnRegisterLatchWait(uint32_t latch_id, uint32_t uniq_id) = 0;
    virtual bool TryWaitLatch(uint32_t latch_id) = 0;
    // QUEUE
    virtual std::tuple<uint32_t, uint32_t> AllocQueue() = 0;
    virtual void DeallocQueue(uint32_t queue_producer_id) = 0;
    virtual void SetQueueProducerCount(
        uint32_t queue_producer_id, uint32_t count, uint32_t uniq_id) = 0;
    virtual void SetQueueConsumerCount(
        uint32_t queue_consumer_id, uint32_t count, uint32_t uniq_id) = 0;
    virtual void RegisterQueueProducer(
        uint32_t queue_producer_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info) = 0;
    virtual void RegisterQueueConsumer(
        uint32_t queue_consumer_id, uint32_t uniq_id, const HwSyncNotifyInfo &notify_info) = 0;
    virtual void AdvanceWriteFar(uint32_t queue_producer_id, uint32_t uniq_id)         = 0;
    virtual void AdvanceReadFar(uint32_t queue_consumer_id, uint32_t uniq_id)          = 0;
    virtual void UnregisterQueueProducer(uint32_t queue_producer_id, uint32_t uniq_id) = 0;
    virtual void UnregisterQueueConsumer(uint32_t queue_consumer_id, uint32_t uniq_id) = 0;
    // AtomicInc
    virtual uint32_t ReadSelfIncrMem(uint32_t id) = 0;
    virtual void IncSelfIncrMem(uint32_t id)      = 0;
    virtual void ClrSelfIncrMem(uint32_t id)      = 0;

 public:
    // Reset
    virtual void ResetAllVg()           = 0;
    virtual void ResetVg(uint8_t vg_id) = 0;
    // MISC
    virtual void SetCfMstOts(uint32_t ostd)   = 0;
    virtual uint32_t GetMaxCfMstOts()         = 0;
    virtual void SetLutAxidMax(uint32_t v)    = 0;
    virtual void SetCfMstQos(uint32_t qos)    = 0;
    virtual void SetIrqMifAxid(uint32_t axid) = 0;
    // Idle
    virtual bool WaitIdle(int timeout_ms) = 0;
    virtual bool     AllIdle()            = 0;
    virtual uint32_t CtxIdle()            = 0;
    virtual bool CtxIdle(uint32_t ctx)    = 0;
    // Clock
    virtual void EnableClkGating()  = 0;
    virtual void DisableClkGating() = 0;
    // Self clr
    virtual void SetCntSelfClr(const HwSyncCntSelfClrCfg &cfg)           = 0;
    virtual void SetEntryVldSelfClr(const HwSyncEntryVldSelfClrCfg &cfg) = 0;
    virtual void SetCntTrigSelfClr(const HwSyncCntTrigSelfClrCfg &cfg)   = 0;
    // Dbg
    virtual void EnableErrorHang()  = 0;
    virtual void DisableErrorHang() = 0;
    // Interrupt
    virtual void ConfigInterrupt(const HwSyncInterruptCfg &cfg)          = 0;
    virtual bool               HasInterrupt()                            = 0;
    virtual HwSyncInterruptSts GetInterruptSts()                         = 0;
    virtual HwSyncInterruptLog GetInterruptLog()                         = 0;
    virtual void ClearInterrupt(const std::vector<HwSyncInt> &interrupt) = 0;
    virtual void ClearAllInterrupt()                                     = 0;
    virtual void ClearInterrupt(uint32_t mask)                           = 0;
    virtual void ClearInterruptLog()                                     = 0;
    virtual void ClearInterruptWdata()                                   = 0;

 private:
};

}  // namespace hwsync
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_HWSYNC_HWSYNC_NEW_H_
