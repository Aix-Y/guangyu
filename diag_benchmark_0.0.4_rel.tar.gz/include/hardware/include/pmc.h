/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_PMC_H_
#define HARDWARE_INCLUDE_PMC_H_

#include <map>
#include <memory>
#include <string>
#include <vector>
#include "hardware/include/config.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace pmc {
class Pmc : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Pmc(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~Pmc() {}

    /**
     * @brief      Resets the given identifier.
     *
     * @param[in]  id    -1 measn reset all counter
     */
    virtual void Reset(int id = -1) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  id    The identifier
     */
    virtual void Start(int id = -1) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  id    The identifier
     */
    virtual void Stop(int id = -1) {}

    //!
    //! @brief send extra profiling statistics to flush dpf fifo
    //!
    void Flush() {
        for (int i = 0; i < 4; i++) {
            Reset();
            Start();
            get_hpd()->SleepMs(1);
            Stop();
            get_hpd()->SleepMs(1);
        }
    }

    /**
     * @brief      Gets the result.
     *
     * @return     The result.
     */
    virtual std::vector<uint64_t> GetResult() = 0;

    /**
     * @brief      Loads a setting.
     *
     * @param      ss    { parameter_description }
     */
    virtual void LoadSetting2(const std::string &cfg) {}

    /**
     * @brief      Loads a setting.
     *
     * @param      ss    { parameter_description }
     */
    virtual void LoadWithOutSel(const std::string &cfg) {}

    /**
     * @brief      Loads a setting.
     *
     * @param      ss    { parameter_description }
     */
    virtual void LoadSetting(std::stringstream &ss) {}

    /**
     * @brief      Loads a setting.
     *
     * @param      json_filename   { the file name of a json file, which contains pmc setting }
     */
    virtual void LoadSetting(const std::string &json_filename) {}

    /**
     * @brief      Gets the events description.
     *
     * @return     The events description.
     */
    virtual std::vector<std::string> &GetEventsDesc() = 0;

    /**
     * @brief      Gets the counter.
     *
     * @return     The counter.
     */
    virtual std::vector<int> &GetCounter() = 0;

    /**
     * @brief      Prints a result.
     */
    virtual void PrintResult() {}

    /**
     * @brief      { function_description }
     */
    virtual void SelSetting() {}
};

}  // namespace pmc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_PMC_H_
