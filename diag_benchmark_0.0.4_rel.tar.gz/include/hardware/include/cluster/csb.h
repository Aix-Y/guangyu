/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CLUSTER_CSB_H_
#define HARDWARE_INCLUDE_CLUSTER_CSB_H_

#include <memory>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace cluster {
namespace csb {
class Csb : public Hardware {
 public:
    Csb() : Hardware() {}
    explicit Csb(std::shared_ptr<spdlog::logger> logger);
    virtual ~Csb();

    // Basic function
    virtual bool WaitCsbIdle(uint32_t timeout);
    virtual bool     IsCsbIdle()              = 0;
    virtual uint32_t GetCsbSize()             = 0;
    virtual void SetCsbHash(uint8_t hash_val) = 0;
    virtual uint32_t GetCsbHashAddr(uint32_t addr, uint8_t hash_val) = 0;
};

}  // namespace csb
}  // namespace cluster
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CLUSTER_CSB_H_
