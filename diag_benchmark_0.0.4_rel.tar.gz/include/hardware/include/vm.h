/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_VM_H_
#define HARDWARE_INCLUDE_VM_H_

#include <memory>
#include <vector>
#include "hardware/include/absp.h"
#include "hardware/include/hardware.h"
#include "hardware/include/pmc.h"
#include "hardware/include/xmc/xmc.h"

using efvf::hardware::absp::Absp;
using efvf::hardware::pmc::Pmc;
using efvf::hardware::xmc::Xmc;

namespace efvf {
namespace hardware {
namespace vm {
typedef struct _PteMapCfg {
    uint32_t set_id;
    uint64_t dev_addr;  // dev addr of system memeory
    uint64_t pte_base;
    uint64_t size;
    uint64_t page_size;  // bytes
    uint8_t  pte_in_sys;
    uint32_t index;
    uint8_t  pte_ctx_en;
    uint32_t pte_ctx_index;
} PteMapCfg;

typedef struct _DirectMapCfg {
    uint64_t dev_addr;
    uint64_t host_phy_addr;
    uint64_t size;
} DirectMapCfg;

typedef struct _SpecialMapCfg {
    uint64_t dev_addr;
    uint64_t host_phy_addr;
    uint64_t size;
    uint8_t  mst_en;
    uint32_t mst_id[4];
} SpecialMapCfg;

class VmRasCfg : public efvf::hardware::RasCfg {};

class VmRasErrInj : public efvf::hardware::RasErrInj {};

class VmRasErrStat : public efvf::hardware::RasErrStat {
 public:
    bool parity_err_[4] = {
        false,
    };
    uint64_t err_page_[4] = {
        0,
    };
};

class VmIntrptCfg : public efvf::hardware::IntrptCfg {
 public:
    uint8_t reg_write_fault_ = 0;
    uint8_t pte_rtn_fault_   = 0;
    uint8_t write_buff_par_  = 0;
    uint8_t invalid_pte_     = 0;
    uint8_t win_check_       = 0;
};

class VmIntrptStat : public efvf::hardware::IntrptStat {};

enum VmSnoopMode {
    Bypass   = 0,
    Pte      = 1,
    SnoopOff = 3,
    SnoopOn  = 4,
};

class Vm : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    Vm() : Hardware() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Vm(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~Vm() {}

    /**
     * @brief      Sets the initialize configuration.
     *
     * @param      cfg   The new value
     */
    virtual void set_init_cfg(void *cfg) {}

    virtual void EnClkGating(bool on) {}
    /**
     * @brief      { function_description }
     */
    virtual void Bypass() {}

    /**
     * @brief      Disables all map.
     */
    virtual void DisableAllMap() {}

    /**
     * @brief      Determines if direct map en.
     *
     * @return     True if direct map en, False otherwise.
     */
    virtual bool IsDirectMapEn() {
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  id    The identifier
     */
    virtual void TlbForceUpdate(int id) {}

    /**
     * @brief      Sets the direct map.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetDirectMap(DirectMapCfg cfg) {}

    /**
     * @brief      Sets the direct map en.
     *
     * @param[in]  status  The status
     */
    virtual void SetDirectMapEn(uint32_t status) {}

    /**
     * @brief      Sets the special map.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetSpecialMap(SpecialMapCfg cfg) {}

    /**
     * @brief      Disables the special map.
     */
    virtual void SetSpecialMapEn(uint32_t status) {}

    /**
     * @brief      Sets the pte map.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetPteMap(PteMapCfg cfg) {}

    /**
     * @brief      Sets the pte set en.
     *
     * @param[in]  id      The new value
     * @param[in]  status  The status
     */
    virtual void SetPteSetEn(int id, uint32_t status) {}

    /**
     * @brief      Sets the pte location.
     *
     * @param[in]  id      The new value
     * @param[in]  in_sys  In system
     */
    virtual void SetPteLocation(int id, uint32_t in_sys) {}

    /**
     * @brief      Sets the pte page size.
     *
     * @param[in]  id    The new value
     * @param[in]  size  The size
     */
    virtual void SetPtePageSize(int id, uint64_t size) {}

    virtual void SetPteSnoop(int id, VmSnoopMode mode) {}

    /**
     * @brief      Sets the pte usage en.
     *
     * @param[in]  id      The new value
     * @param[in]  status  The status
     */
    virtual void SetPteUsageEn(int id, uint32_t status) {}

    /**
     * @brief      Sets the pte usage window address.
     *
     * @param[in]  id    The new value
     * @param[in]  addr  The address
     */
    virtual void SetPteUsageWinAddr(int id, uint64_t addr) {}

    /**
     * @brief      Sets the pte usage window size.
     *
     * @param[in]  id    The new value
     * @param[in]  size  The size
     */
    virtual void SetPteUsageWinSize(int id, uint64_t size) {}

    /**
     * @brief      the address to save pte
     *
     * @param[in]  id    The new value
     * @param[in]  addr  The address
     */
    virtual void SetPteUsageBaseAddr(int id, uint64_t addr) {}

    /**
     * @brief      Sets the pte usage invalidate tlb.
     *
     * @param[in]  id      The new value
     * @param[in]  status  The status
     */
    virtual void SetPteUsageInvalidateTlb(int id) {}

    /**
     * @brief      Sets the pte burst fetch.
     *
     * @param[in]  id    The new value
     * @param[in]  val   The new value
     */
    virtual void SetPteBurstFetch(int id, uint32_t val) {}

    /**
     * @brief      Sets the cause address.
     */
    virtual void SetCauseAddr(uint64_t addr) {}

    /* @brief Set the Pte Forecast config
     *
     * @param[in] id    The pte set id
     * @param[in] step  The forecast step which control cacheline
     * @param[in] index When to do forecast which is invalid if value >7.
     */
    virtual void SetPteForecastCfg(int id, uint32_t step, uint32_t index) {}

    /**
     * @brief      Gets the absp.
     *
     * @return     The absp.
     */
    virtual Absp *GetAbsp() {
        return nullptr;
    }

    /**
     * @brief      Gets the pmc.
     *
     * @return     The pmc.
     */
    virtual Pmc *GetPmc() {
        return nullptr;
    }

    virtual Xmc *GetDfXmc() {
        return nullptr;
    }

    /**
     * @brief      Gets the pcie edf start.
     *
     * @return     The pcie edf start.
     */
    virtual uint64_t GetPcieEdfStart() {
        return 0;
    }

    /**
     * @brief      { function_description }
     *
     * @param      pte_base     The pte base
     * @param[in]  map_to_addr  The map to address
     * @param[in]  page_size    The page size
     * @param[in]  map_order    The map order page no list
     */
    virtual void FillPteContent(uint8_t *pte_base, uint64_t map_to_addr, uint32_t page_size,
        const std::vector<uint32_t> &map_order, uint32_t local = 0, uint32_t snoop = 1,
        uint32_t valid = 1) {}

    /**
     * @brief      Sets the rd fault address.
     *
     * @param[in]  ecf_addr  The ecf address
     */
    virtual void SetRdFaultAddr(uint64_t ecf_addr) {}

    /**
     * @brief      Sets the wr fault address.
     *
     * @param[in]  ecf_addr  The ecf address
     */
    virtual void SetWrFaultAddr(uint64_t ecf_addr) {}

    /**
     * @brief      Finds a mapping error.
     *
     * @param      err_addr  The error address
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FindMappingError(uint64_t &err_addr) {
        return false;
    }
};

}  // namespace vm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_VM_H_
