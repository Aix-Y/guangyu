/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_GDMA_GDMA_H_
#define HARDWARE_INCLUDE_GDMA_GDMA_H_

#include <memory>
#include <vector>
#include "hardware/include/gdma/gdma_ctx.h"
#include "hardware/include/hardware.h"
#include "hardware/include/pmc.h"

namespace efvf {
namespace hardware {
namespace gdma {

class Gdma : public Hardware {
 public:
    Gdma() {}
    explicit Gdma(std::shared_ptr<spdlog::logger> logger);
    virtual ~Gdma() {}

    /**
     * set cmd packet
     */
    virtual bool SetCmdPkt(const DmaCtx &ctx) = 0;

    /**
     * launche gdma
     */
    virtual bool LaunchGdma(const DmaCtx &ctx) = 0;

    /**
     * is vc busy
     */
    virtual bool IsVcBusy(const DmaCtx &ctx) = 0;

    /**
     * is vc occupy
     */
    virtual bool IsVcOccupy(const DmaCtx &ctx) = 0;

    /**
     * is engine busy
     */
    virtual bool IsEngineBusy() = 0;

    /**
     * wait vc busy
     */
    virtual bool WaitVcIdle(const DmaCtx &ctx, uint32_t timeout) = 0;

    /**
     * wait engine idle
     */
    virtual bool WaitEngineIdle(uint32_t timeout, uint32_t interval_us) = 0;

    /**
     * not always dma has crc feature
     */
    virtual uint32_t GetCrcResult(int timeout = 100) {
        LOG_ASSERT(0, "{} has no crc function", this->name_);
        return 0;
    }

    /**
     * linear copy
     */
    virtual bool LinearCopy(uint64_t src_df_addr, uint64_t dest_df_addr, DmaDir dir,
        uint32_t size, uint64_t offset = 0, int vc_id = 0) = 0;

    /**
     * constant fill
     */
    virtual bool ConstantFill(uint64_t df_addr, DmaDir dir, uint32_t pattern, uint64_t size,
        uint64_t offset = 0) = 0;

    /**
     * slice
     */
    virtual bool Slice(uint64_t src_df_addr, uint64_t dest_df_addr, DmaDir dir,
        const std::vector<uint64_t> &src_dim, const std::vector<uint64_t> &src_dim_slice_off,
        const std::vector<uint64_t> &src_dim_slice_size, uint8_t bpe) = 0;
};

}  // namespace gdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_GDMA_GDMA_H_
