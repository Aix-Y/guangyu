/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_GDMA_GDMA_RAS_H_
#define HARDWARE_INCLUDE_GDMA_GDMA_RAS_H_
#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace gdma {

// typedef enum _DmaInterrupt {
//    DMA_MAILBOX_ERR_INT       = 1UL << 0,
//    DMA_FINISH_INT            = 1UL << 1,
//    DMA_ILL_PROG_INT          = 1UL << 2,
//    DMA_AXI_DF_ERR_PAR_INT    = 1UL << 3,
//    DMA_AXI_CF_ERR_RESP_INT   = 1UL << 4,
//    DMA_AXI_DF_ERR_RESP_INT   = 1UL << 5,
//    DMA_REG_SRAM_ERR_PAR_INT  = 1UL << 6,
//    DMA_DATA_SRAM_ERR_PAR_INT = 1UL << 7,
//    DMA_TIMEOUT_INT           = 1UL << 8,
//    ALL_INT                   = ~0U,
//} DmaInterrupt;

typedef struct _DmaInterrupt_f {
    unsigned int DMA_MAILBOX_ERR_INT : 1;
    unsigned int DMA_FINISH_INT : 1;
    unsigned int DMA_ILL_PROG_INT : 1;
    unsigned int DMA_AXI_DF_ERR_PAR_INT : 1;
    unsigned int DMA_AXI_CF_ERR_RESP_INT : 1;
    unsigned int DMA_AXI_DF_ERR_RESP_INT : 1;
    unsigned int DMA_REG_SRAM_ERR_PAR_INT : 1;
    unsigned int DMA_DATA_SRAM_ERR_PAR_INT : 1;
    unsigned int DMA_TIMEOUT_INT : 1;
} DmaInterrupt_f;

typedef union {
    unsigned int   val : 32;
    DmaInterrupt_f f;
} DmaInterrupt;

class GdmaRasCfg : public efvf::hardware::RasCfg {
 public:
    bool en_interrupt_;  // remove this don't combin interrup and ras
    // TODO(wade.chen) use union variable
};

class GdmaRasErrInj : public efvf::hardware::RasErrInj {
 public:
    // TODO(wade.chen) use union variable
    bool hml_wr_par_err_inj_en_;
    bool lml_wr_par_err_inj_en_;
};

class GdmaRasErrStat : public efvf::hardware::RasErrStat {
    // TODO(wade.chen) use union variable
};

class GdmaIntrptCfg : public efvf::hardware::IntrptCfg {
    // TODO(wade.chen) use union variable
};

class GdmaRas : public efvf::hardware::IRas {
 public:
    DmaInterrupt intrpt_;
};

}  // namespace gdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_GDMA_GDMA_RAS_H_
