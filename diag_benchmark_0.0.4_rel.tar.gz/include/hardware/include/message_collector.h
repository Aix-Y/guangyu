/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MESSAGE_COLLECTOR_H_
#define HARDWARE_INCLUDE_MESSAGE_COLLECTOR_H_

#include <memory>
#include <vector>

#include "hardware/include/hardware.h"
#include "hardware/include/message_agent.h"

namespace efvf {
namespace hardware {
namespace message_collector {

//!
//! @brief Message collector base lib
//!
//! It provides interfaces to get agents
//!
class MessageCollector : public Hardware {
 public:
    MessageCollector(std::shared_ptr<spdlog::logger> logger, int agent_num)
        : Hardware(logger), agents_(agent_num) {}
    virtual ~MessageCollector() = default;

    //!
    //! @brief enable/disable override master id
    //!
    virtual void EnableMasterIDOverride()  = 0;
    virtual void DisableMasterIDOverride() = 0;

    //!
    //! @brief accessor for all interrupt agents
    //!
    //! @param id: message agent index
    //!         0: exeception interrupt to SP
    //!         1: exeception interrupt to PCIe
    //!         2: normal interrupt to PCIe
    //!
    virtual InterruptAgent *interrupt_agent(uint8_t id = 2) = 0;
    virtual InterruptAgent *int_excp_to_sp()                = 0;
    virtual InterruptAgent *int_excp_to_pcie()              = 0;
    virtual InterruptAgent *int_normal_to_pcie()            = 0;

    //!
    //! @brief accessor to profiling agent
    //!
    //! profiling agent is the 3rd message agent
    //!
    virtual ProfilingAgent *profiling_agent() = 0;

    //!
    //! @brief accessor to trace event agent
    //!
    //! trace event agent is the 4th message agent
    //!
    virtual TraceEventAgent *trace_event_agent() = 0;

    //!
    //! @brief accessor to customized event agent
    //!
    //! customized event agent is the 5th message agent
    //!
    virtual CustomizedEventAgent *customized_event_agent() = 0;

    //!
    //! @brief accessor to log buffer agent
    //!
    //! log buffer agent is the 6th message agent
    //!
    virtual LogBufferAgent *log_buffer_agent() = 0;

 protected:
    MessageAgent *agent(uint8_t idx) {
        return agents_[idx].get();
    }

 protected:
    std::vector<std::shared_ptr<MessageAgent>> agents_;
};
}  // namespace message_collector
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MESSAGE_COLLECTOR_H_"
