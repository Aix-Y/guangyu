/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_AMC_H_
#define HARDWARE_INCLUDE_AMC_H_

#include <memory>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace amc {
typedef enum {
    ROUTER_LEFT = 0,
    ROUTER_RIGHT,
    ROUTER_2,
    ROUTER_3,
    ROUTER_OFF,
} AmcRouterDir;

typedef enum {
    LOCAL_CSB = 0,
    LOCAL_HBM,
    LOCAL_IBN,
} AmcMapType;

typedef struct _AmcAperParam {
    uint32_t     index;
    uint32_t     ctx_id;
    uint32_t     ctx_enable;
    uint64_t     physic_base;
    uint64_t     virt_base;
    uint64_t     size;
    AmcRouterDir router_dir;
    AmcMapType   map_type;
} AmcAperParam;

class AmClient : public Hardware {
 public:
    AmClient() : Hardware() {}
    explicit AmClient(std::shared_ptr<spdlog::logger> logger);
    virtual ~AmClient() {}

    virtual void WinCfg(uint64_t physic_addr, uint64_t virt_addr, uint64_t size) = 0;
    virtual void AperCfg(const AmcAperParam &param) = 0;
};

#define DefineAmc(chip, cls_name, ...)                                                \
    class cls_name : public AmClient {                                                \
     public:                                                                          \
        cls_name() : AmClient() {}                                                    \
        explicit cls_name(std::shared_ptr<spdlog::logger> logger);                    \
        virtual ~cls_name();                                                          \
        virtual void WinCfg(uint64_t physic_addr, uint64_t virt_addr, uint64_t size); \
        virtual void AperCfg(const AmcAperParam &param);                              \
                                                                                      \
     private:                                                                         \
        virtual bool HwInit();                                                        \
        virtual bool HwDeinit();                                                      \
    }

}  // namespace amc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_AMC_H_
