/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_ESL_ESL_CONNECT_H_
#define HARDWARE_INCLUDE_ESL_ESL_CONNECT_H_
#include <map>
#include <memory>
#include <set>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using efvf::framework::mem::Mem;

namespace efvf {
namespace hardware {
namespace esl {

enum CMDKEY {
    QPC_CFG = 1,
    QPC_CFG_DONE,
    QLR_REQUEST,
    QLR_DONE,
    ALLOCATE_BUFF,
    ALLOCATE_BUFF_DONE,
    TEST,
    CTX_INIT_REQ,
    CTX_REMOTE_READY_RES,
    CTX_REMOTE_N_READY_RES,
    CPCTX_REMOTE_GET_REQ,
    CPCTX_REMOTE_READY_RES,
    CPCTX_REMOTE_N_READY_RES,
    LOCAL_SYNC_READY_REQ,
    REMOTE_SYNC_READY_RES,
    REMOTE_SYNC_N_READY_RES,
    REMOTE_MEM_CMP_REQ,
    REMOTE_MEM_CMP_PASS,
    REMOTE_MEM_CMP_FAIL,
    REMOTE_MEM_CLEAR_REQ,
    REMOTE_MEM_CLEAR_RES,
    EOF_MESSAGE,
    REMOTE_FIN,
    REMOTE_NOT_FIN,
    CMD_KEY_MAX
};

const std::map<int, const std::string> CMDKEY_MAP = {{QPC_CFG, "QPC CFG"},
    {QPC_CFG_DONE, "QPC CFG DONE"}, {QLR_REQUEST, "QLR REQUEST"}, {QLR_DONE, "QLR DONE"},
    {ALLOCATE_BUFF, "ALLOCATE BUFFER"}, {ALLOCATE_BUFF_DONE, "ALLOCATE BUFFER DONE"},
    {TEST, "TEST CMD"}, {CTX_INIT_REQ, "CTX_INIT_REQ"},
    {CTX_REMOTE_READY_RES, "CTX_REMOTE_READY_RES"},
    {CTX_REMOTE_N_READY_RES, "CTX_REMOTE_N_READY_RES"},
    {CPCTX_REMOTE_GET_REQ, "CPCTX_REMOTE_GET_REQ"},
    {CPCTX_REMOTE_READY_RES, "CPCTX_REMOTE_READY_RES"},
    {CPCTX_REMOTE_N_READY_RES, "CPCTX_REMOTE_N_READY_RES"},
    {LOCAL_SYNC_READY_REQ, "LOCAL_SYNC_READY_REQ"},
    {REMOTE_SYNC_READY_RES, "REMOTE_SYNC_READY_RES"},
    {REMOTE_SYNC_N_READY_RES, "REMOTE_SYNC_N_READY_RES"},
    {REMOTE_MEM_CMP_REQ, "REMOTE_MEM_CMP_REQ"}, {REMOTE_MEM_CMP_PASS, "REMOTE_MEM_CMP_PASS"},
    {REMOTE_MEM_CMP_FAIL, "REMOTE_MEM_CMP_FAIL"},
    {REMOTE_MEM_CLEAR_REQ, "REMOTE_MEM_CLEAR_REQ"},
    {REMOTE_MEM_CLEAR_RES, "REMOTE_MEM_CLEAR_RES"}, {EOF_MESSAGE, "EOF_MESSAGE"},
    {REMOTE_FIN, "REMOTE_FIN"}, {REMOTE_NOT_FIN, "REMOTE_NOT_FIN"},
    {CMD_KEY_MAX, "INVALID CMD KEY"}, {0, "UNKNOWN"}};

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}  // extern "C"
#endif

typedef struct _ClientInfo {
    uint32_t    index = 0;
    std::string name  = "";
    std::string ip    = "0.0.0.0";
    uint32_t    port  = 0;
} ClientInfo;

}  // namespace esl
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_ESL_ESL_CONNECT_H_
