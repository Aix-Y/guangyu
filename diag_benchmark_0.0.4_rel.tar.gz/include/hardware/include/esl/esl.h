/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_ESL_ESL_H_
#define HARDWARE_INCLUDE_ESL_ESL_H_
#include <yaml-cpp/yaml.h>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <tuple>
#include <utility>
#include <vector>
#include "framework/include/mem.h"
#include "hardware/include/esl/esl_connect.h"
#include "hardware/include/hardware.h"

using efvf::framework::mem::Mem;
#define ESL_L3_MEM_OFFSET (0xc00000000ULL)

namespace efvf {
namespace hardware {
namespace esl {

#define ESL_CONST_8T (0x80000000000ULL)
#define ESL_CONST_128T (0x800000000000ULL)
#define ESL_CONST_5T (0x50000000000ULL)
#define ESL_CONST_96T (0x600000000000ULL)
#define ESL_CONST_124T (0x7C0000000000ULL)

typedef struct _EslGlbCfg { uint32_t queue_counts; } EslGlbCfg;

const std::map<const std::string, uint32_t> RATE_SEL = {
    {"10G", 0}, {"25G", 1}, {"40G", 2}, {"50G", 3}, {"100G", 4}, {"200G", 5}, {"400G", 6},
    {"800G", 7},
};

const std::map<const std::string, uint32_t> FEC_MODE = {
    {"FECNONE", 0}, {"FECRS528", 1}, {"FECRS544", 2}, {"FECRS272", 3}, {"FECBASER", 4}};

const std::map<const std::string, uint32_t> R_MODE = {
    {"R1", 0}, {"R2", 1}, {"R4", 2}, {"R8", 3}, {"R16", 4}};

typedef struct _EslNetCfg {
    uint8_t mac[4][6]      = {};
    uint8_t ip_addr[4][4]  = {};
    uint8_t udp_port[4][2] = {};
} EslNetCfg;

typedef struct _EslQpc {
    uint32_t src_mac_idx    = 0;
    uint32_t src_ip_idx     = 0;
    uint8_t  src_mac[6]     = {};
    uint64_t src_mac_u64    = 0;
    uint8_t  src_ip_addr[4] = {};
    uint16_t src_udp_port   = 4791;

    uint8_t  dst_mac[6]     = {};
    uint64_t dst_mac_u64    = 0;
    uint8_t  dst_ip_addr[4] = {};
    uint16_t dst_udp_port   = 4791;
    uint32_t packet_ttl     = 255;
    uint32_t remote_qid     = 0;

    bool ip_route = false;
} EslQpc;

typedef struct _EslSq {
    uint32_t             sq_ptr_wb_en       = 0;
    uint32_t             sq_ptr_wb_thd      = 8;
    uint64_t             sq_mem_addr        = 0;
    uint64_t             sq_ptr_wb_mem_addr = 0;
    volatile uint32_t    prod_ptr           = 0;
    volatile uint32_t    cons_ptr           = 0;
    uint32_t             fetch_ptr          = 0;
    uint32_t             sq_size_idx        = 6;
    std::shared_ptr<Mem> sq_mem             = nullptr;
    std::shared_ptr<Mem> sq_ptr_wb_mem      = nullptr;
} EslSq;

typedef struct _MttMsg {
    uint32_t al_qp;
    uint32_t ah_qp;
    uint32_t truncate_n_qp;
    uint32_t qpn_qp;
} MttMsg;
typedef struct _EslMtt {
    uint32_t idx         = 0;
    uint64_t remapp_addr = 0;
    uint32_t src_qpn     = 0;
} EslMtt;

typedef struct _EslQpSlvModeCfg {
} EslQpSlvModeCfg;

typedef struct _EslQCfg {
    uint32_t asid        = 0;
    uint32_t pfc_buff_id = 0;
    bool     need_qlr    = false;
} EslQCfg;

typedef struct _EslQpCfg {
    uint32_t qid = 0;
    EslQpc   qpc = {};
    EslSq    sq  = {};
    EslMtt   mtt = {};  // slave mode
} EslQpCfg;

enum {
    WQE_FLAG_EOP          = 0,
    WQE_FLAG_STRONG_ORDER = 1,
    WQE_FLAG_MSI_EN       = 2,
    WQE_FLAG_NNC_EN       = 4,
};

typedef struct _Wqe {
    uint32_t op_code : 8;
    uint32_t flag : 8;
    uint32_t atomic_user_bits : 16;
    uint32_t msn : 16;
    uint32_t dest_qp : 16;
    uint32_t len : 32;
    uint32_t local_addr_lo : 32;
    uint32_t local_addr_hi : 32;
    uint32_t remote_addr_lo : 32;
    uint32_t remote_addr_hi : 32;
    uint32_t inline_data0 : 32;
    uint32_t inline_data1 : 32;
    uint32_t msi_addr_lo : 32;
    uint32_t msi_addr_hi : 32;
    uint32_t msi_data : 32;
    uint32_t rd_resp_psn : 32;
    uint32_t data_type : 32;
    uint32_t reserve0 : 32;
    uint32_t reserve1 : 32;
} Wqe;

typedef struct _WqeCopyCtx {
    bool     msi_en           = false;
    bool     eop              = false;
    bool     fence_en         = false;
    uint8_t  op_code          = 2;
    uint8_t  data_type        = 0;
    uint64_t msi_ecf_addr     = 0;
    uint64_t msi_ecf_data     = 0;
    uint64_t local_buff_addr  = 0;
    uint64_t remote_buff_addr = 0;
    uint64_t size             = 0;
    uint8_t  atomic_data_type = 0;
    uint8_t  atomic_type      = 0;
} WqeCopyCtx;

typedef struct _NicDesc {
    uint32_t addr_lo     = 0;
    uint32_t addr_hi     = 0;
    uint32_t buffer_size = 0;
    uint32_t info        = 0;
} NicDesc;

typedef struct _EslCtx {
    bool                 mstr_mode            = true;
    uint32_t             mstr_dev_id          = 0;
    uint32_t             mstr_port_id         = 0;
    EslQpCfg             mstr_qpcfg           = {};
    uint32_t             mstr_pfc_buff_id     = 0;
    uint32_t             mstr_asid            = 0;
    uint32_t             mstr_retry_buff_size = 0x800000;
    uint32_t             mstr_retry_count     = 0xa;
    std::shared_ptr<Mem> mstr_retry_buff      = nullptr;

    uint32_t             slv_dev_id          = 0;
    uint32_t             slv_port_id         = 0;
    EslQpCfg             slv_qpcfg           = {};
    uint32_t             slv_pfc_buff_id     = 0;
    uint32_t             slv_asid            = 0;
    uint32_t             slv_retry_buff_size = 0x800000;
    uint32_t             slv_retry_count     = 0xa;
    std::shared_ptr<Mem> slv_retry_buff      = nullptr;

    // remote control interface
    bool     remote_connect_enabled = false;
    uint8_t  remote_connect_ip[6]   = {};
    uint16_t remote_connect_port    = {};
} EslCtx;

typedef std::tuple<std::string, uint64_t, std::string> EslSsField;
typedef struct _EslSnapShotInfo {
    uint64_t                val             = 0;
    std::string             title           = "";
    std::vector<EslSsField> field_value_vec = {};
} EslSnapShotInfo;

enum NncBypassMode {
    NNC_ENABLE = 0,
    NNC_NOT_IN_DATA_PATHBYPASS,    // disable, nnc NOT in data path
    NNC_IN_DATA_PATH_BYPASS,       // enabled, nnc in data path
    NNC_NOT_IN_DATA_PATHBYPASS_2,  // disable, nnc NOT in data path
};

#define SIP_CMD_REG (0x440)         // APP16
#define SIP_PARAM_REG_HIGH (0x444)  // APP16
#define SIP_PARAM_REG_LOW (0x448)   // APP16
typedef struct {
    uint32_t sip_id     = 0;
    uint32_t cmd        = 0;
    uint32_t param_high = 0;
    uint32_t param_low  = 0;
} SIP_CMD;

typedef struct _LatSeg {
    uint32_t seg1 = 200;  // 200 cyc
    uint32_t seg2 = 400;  // 400 cyc
    uint32_t seg3 = 600;  // 600 cyc
    uint32_t seg4 = 800;  // 800 cyc
} LatSeg;

// typedef struct _EslLatCfg {
//     EslLatSeg axi_lat_seg = {};
//     EslLatSeg eth_lat_seg = {};
// } EslLatCfg;

typedef enum _LatMoniotrMask {
    AXI_LAT_MON_RDMA_R_EN = 0,
    AXI_LAT_MON_RDMA_W_EN,
    AXI_LAT_MON_WQE_R_EN,
    AXI_LAT_MON_PTR_W_EN,
    AXI_LAT_MON_RXD_W_EN,
    AXI_LAT_MON_TXD_W_EN,
    AXI_LAT_MON_RETRY_R_EN,
    AXI_LAT_MON_RETRY_W_EN,
    AXI_LAT_MON_MAX,
} LatMoniotrMask;

typedef enum _QueueStubMoniotrMask {
    QUEUE_MON_0_EN = 0,
    QUEUE_MON_1_EN,
    QUEUE_MON_2_EN,
    QUEUE_MON_3_EN,
    QUEUE_MON_MAX,
} QueueStubMoniotrMask;

typedef enum _WinMonitorMask {
    WIN_MON_MAC_TXRX_EN = 0,
    WIN_MON_RDMA_EN,
    WIN_MON_WQE_EN,
    WIN_MON_RETRY_EN,
    WIN_MON_SRXD_EN,
    WIN_MON_STXD_EN,
    WIN_MON_PFC_EN,
    WIN_MON_MAX,
} WinMonitorMask;

typedef struct _EslStPktMonitor {
    uint32_t slv_trans_ctrl[8];
    uint32_t tx[8];
    uint32_t rxtm[8];
    uint32_t mac_app_tx[8];
} EslStPktMonitor;

typedef enum _StPktMask {
    ST_PKT_SLV_TRANS_CTRL = 0,
    ST_PKT_TX,
    ST_PKT_RXTM,
    ST_PKT_MAC_APP,
    ST_PKT_MAX,
} StPktMask;

typedef struct _EslAxiLatMonitor {
    uint32_t axi_lat_rdma_w[5];
    uint32_t axi_lat_txd_w[5];
    uint32_t axi_lat_rxd_w[5];
    uint32_t axi_lat_ptr_w[5];
    uint32_t axi_lat_retry_w[5];
    uint32_t axi_lat_rdma_r[5];
    uint32_t axi_lat_wqe_r[5];
    uint32_t axi_lat_retry_r[5];
} EslAxiLatMonitor;

typedef struct _EslEthLatMonitor {
    uint32_t eth_q_stub0_lat[5];
    uint32_t eth_q_stub1_lat[5];
    uint32_t eth_q_stub2_lat[5];
    uint32_t eth_q_stub3_lat[5];
} EslEthLatMonitor;

typedef struct _EslQueueEthLatMonitor {
    uint32_t eth_queue_lat_stub_0[5];
    uint32_t eth_queue_lat_stub_1[5];
    uint32_t eth_queue_lat_stub_2[5];
    uint32_t eth_queue_lat_stub_3[5];
} EslQueueEthLatMonitor;

typedef struct _EslQueueRateMonitor {
    uint32_t esl_queue_rate_stub_0[4];
    uint32_t esl_queue_rate_stub_1[4];
    uint32_t esl_queue_rate_stub_2[4];
    uint32_t esl_queue_rate_stub_3[4];
} EslQueueRateMonitor;

typedef struct _EslPortPktMonitor {
    uint32_t mac_tx_pps;
    uint32_t mac_rx_pps;
    uint32_t mac_tx_kbps;
    uint32_t mac_rx_kbps;
    uint32_t esl_tx_pps;
    uint32_t esl_rx_pps;
    uint32_t esl_tx_kbps;
    uint32_t esl_rx_kbps;
    uint32_t mac_tx_vld_rdy;
    uint32_t mac_rx_vld_rdy;
    uint32_t total_tx_pkt;
    uint32_t total_rx_pkt;
    float    nnc_cr_rate;
} EslPortPktMonitor;

typedef struct _WinCntMonitor {
    uint32_t win_cnt;
    uint32_t axi_rdy_retry_r;
    uint32_t axi_rdy_retry_ar;
    uint32_t axi_rdy_retry_b;
    uint32_t axi_rdy_retry_w;
    uint32_t axi_rdy_retry_aw;
    uint32_t axi_rdy_wqe_r;
    uint32_t axi_rdy_wqe_ar;
    uint32_t axi_rdy_wqe_b;
    uint32_t axi_rdy_wqe_w;
    uint32_t axi_rdy_wqe_aw;
    uint32_t axi_rdy_srxd_b;
    uint32_t axi_rdy_srxd_w;
    uint32_t axi_rdy_srxd_aw;
    uint32_t axi_rdy_stxd_b;
    uint32_t axi_rdy_stxd_w;
    uint32_t axi_rdy_stxd_aw;
    uint32_t axi_rdy_rdma_r;
    uint32_t axi_rdy_rdma_ar;
    uint32_t axi_rdy_rdma_b;
    uint32_t axi_rdy_rdma_w;
    uint32_t axi_rdy_rdma_aw;
    // --------------------- //
    uint32_t axi_vld_rdy_retry_r;
    uint32_t axi_vld_rdy_retry_ar;
    uint32_t axi_vld_rdy_retry_b;
    uint32_t axi_vld_rdy_retry_w;
    uint32_t axi_vld_rdy_retry_aw;
    uint32_t axi_vld_rdy_wqe_r;
    uint32_t axi_vld_rdy_wqe_ar;
    uint32_t axi_vld_rdy_wqe_b;
    uint32_t axi_vld_rdy_wqe_w;
    uint32_t axi_vld_rdy_wqe_aw;
    uint32_t axi_vld_rdy_srxd_b;
    uint32_t axi_vld_rdy_srxd_w;
    uint32_t axi_vld_rdy_srxd_aw;
    uint32_t axi_vld_rdy_stxd_b;
    uint32_t axi_vld_rdy_stxd_w;
    uint32_t axi_vld_rdy_stxd_aw;
    uint32_t axi_vld_rdy_rdma_r;
    uint32_t axi_vld_rdy_rdma_ar;
    uint32_t axi_vld_rdy_rdma_b;
    uint32_t axi_vld_rdy_rdma_w;
    uint32_t axi_vld_rdy_rdma_aw;
    //-------------------------//
    uint32_t pause_cnt_rx0;
    uint32_t pause_cnt_rx1;
    uint32_t pause_cnt_rx2;
    uint32_t pause_cnt_rx3;
    uint32_t pause_cnt_rx4;
    uint32_t pause_cnt_rx5;
    uint32_t pause_cnt_rx6;
    uint32_t pause_cnt_rx7;
    uint32_t pause_cnt_rxfc;
    uint32_t pause_cnt_tx0;
    uint32_t pause_cnt_tx1;
    uint32_t pause_cnt_tx2;
    uint32_t pause_cnt_tx3;
    uint32_t pause_cnt_tx4;
    uint32_t pause_cnt_tx5;
    uint32_t pause_cnt_tx6;
    uint32_t pause_cnt_tx7;
    uint32_t pause_cnt_txfc;
    //-------------------------//
    uint32_t mac_tx_rdy;
    uint32_t mac_tx_vld_rdy;
    uint32_t mac_rx_vld_rdy;
} WinCntMonitor;

typedef struct _QueueStubMonitor {
    uint32_t axi_rdy_retry_r;
    uint32_t axi_rdy_retry_ar;
    uint32_t axi_rdy_retry_b;
    uint32_t axi_rdy_retry_w;
    uint32_t axi_rdy_retry_aw;
    uint32_t axi_rdy_wqe_r;
    uint32_t axi_rdy_wqe_ar;
    uint32_t axi_rdy_wqe_b;
    uint32_t axi_rdy_wqe_w;
    uint32_t axi_rdy_wqe_aw;
    uint32_t axi_rdy_srxd_b;
    uint32_t axi_rdy_srxd_w;
    uint32_t axi_rdy_srxd_aw;
    uint32_t axi_rdy_stxd_b;
    uint32_t axi_rdy_stxd_w;
    uint32_t axi_rdy_stxd_aw;
    uint32_t axi_rdy_rdma_r;
    uint32_t axi_rdy_rdma_ar;
    uint32_t axi_rdy_rdma_b;
    uint32_t axi_rdy_rdma_w;
    uint32_t axi_rdy_rdma_aw;
    // --------------------- //
    uint32_t axi_vld_rdy_retry_r;
    uint32_t axi_vld_rdy_retry_ar;
    uint32_t axi_vld_rdy_retry_b;
    uint32_t axi_vld_rdy_retry_w;
    uint32_t axi_vld_rdy_retry_aw;
    uint32_t axi_vld_rdy_wqe_r;
    uint32_t axi_vld_rdy_wqe_ar;
    uint32_t axi_vld_rdy_wqe_b;
    uint32_t axi_vld_rdy_wqe_w;
    uint32_t axi_vld_rdy_wqe_aw;
    uint32_t axi_vld_rdy_srxd_b;
    uint32_t axi_vld_rdy_srxd_w;
    uint32_t axi_vld_rdy_srxd_aw;
    uint32_t axi_vld_rdy_stxd_b;
    uint32_t axi_vld_rdy_stxd_w;
    uint32_t axi_vld_rdy_stxd_aw;
    uint32_t axi_vld_rdy_rdma_r;
    uint32_t axi_vld_rdy_rdma_ar;
    uint32_t axi_vld_rdy_rdma_b;
    uint32_t axi_vld_rdy_rdma_w;
    uint32_t axi_vld_rdy_rdma_aw;
} QueueStubMonitor;

typedef struct _EslInjEccCrcErr {
    uint32_t type;
    bool     bu_ecc;
    bool     bu_crc;
    uint32_t match_num;
    uint32_t bu_num;
    uint32_t bu_interval;
    uint32_t bu_seq_num;
    uint32_t bu_seq_limit;
    uint32_t ecc_dw0_index;
    uint32_t ecc_dw1_index;
    uint32_t ecc_dw2_index;
    uint32_t ecc_dw0_vector;
    uint32_t ecc_dw1_vector;
    uint32_t ecc_dw2_vector;
    uint32_t crc_dw0_index;
    uint32_t crc_dw1_index;
    uint32_t crc_dw2_index;
    uint32_t crc_dw0_vector;
    uint32_t crc_dw1_vector;
    uint32_t crc_dw2_vector;
} EslInjEccCrcErr;

typedef union _EslRateCfg {
    struct {
        uint32_t rate_sel : 3;
        uint32_t fec_mode : 3;
        uint32_t reserve1 : 2;
        uint32_t r_mode : 3;
        uint32_t reserve2 : 21;
    } f;
    uint32_t val;
} EslRateCfg;

typedef struct _NicCfg {
    bool                 nic_tx_enable      = false;
    std::shared_ptr<Mem> nic_tx_desc_buff   = nullptr;
    uint64_t             nic_tx_desc_addr   = 0;
    std::shared_ptr<Mem> nic_tx_buff        = nullptr;
    uint64_t             nic_tx_buff_addr   = 0;
    uint32_t             nic_tx_sq_size_idx = 0xa;
    bool                 nic_rx_enable      = false;
    std::shared_ptr<Mem> nic_rx_desc_buff   = nullptr;
    uint64_t             nic_rx_desc_addr   = 0;
    std::shared_ptr<Mem> nic_rx_buff        = nullptr;
    uint64_t             nic_rx_buff_addr   = 0;
    uint32_t             nic_rx_sq_size_idx = 0xa;
    std::shared_ptr<Mem> nic_cq_buff        = nullptr;
    uint64_t             nic_cq_addr        = 0;
    uint32_t             nic_cq_size_idx    = 0xa;
    uint64_t             nic_cq_int_addr    = 0x0;
    uint32_t             nic_cq_int_data    = 0x1234;
    uint32_t             nic_cq_int_mask    = 0;

    uint64_t nic_src_mac = 0x0ULL;
    uint64_t nic_dst_mac = 0x0ULL;

    std::function<void()> nic_rx_function = {};
} NicCfg;

enum ErrInjTypeMask {
    HEADER_INJ = 0,
    DATA_INJ,
    L2_HEADER_INJ,
    L2_DATA_INJ,
    L3_HEADER_INJ,
    L3_DATA_INJ,
    ROUND_MODE_INJ,
    CRC_INJ,
    L2_CRC_INJ,
    L3_CRC_INJ,
    ROUND_MODE_CRC_INJ,
    ERR_INJ_MAX,
};

const std::map<const std::string, ErrInjTypeMask> ErrInJTypeMap{
    {"header", HEADER_INJ}, {"data", DATA_INJ}, {"l2_header", L2_HEADER_INJ},
    {"l2_data", L2_DATA_INJ}, {"l3_header", L3_HEADER_INJ}, {"l3_data", L3_DATA_INJ},
    {"round_mode", ROUND_MODE_INJ}, {"crc", CRC_INJ}, {"l2_crc", L2_CRC_INJ},
    {"l3_crc", L3_CRC_INJ}, {"round_mode_crc", ROUND_MODE_CRC_INJ},
};

// const std::map<const std::string, uint32_t> ErrInJAddrMap {
//     {"header_inj", 0x124},{"data_inj", 0x148},
//     {"l2_header_inj", 0x160},{"l2_data_inj", 0x180},
//     {"l3_header_inj", 0x190},{"l3_data_inj", 0x1b0},
//     {"round_mode_inj", ROUND_MODE_INJ},{"crc_inj", CRC_INJ},
//     {"l2_crc_inj", L2_CRC_INJ},{"l3_crc_inj", L3_CRC_INJ},
//     {"round_mode_crc_inj", ROUND_MODE_CRC_INJ},
// };

struct ErrInjCfg {
    bool     enable        = false;
    bool     infinite_mode = false;
    uint32_t infinite_num  = 1;
    uint32_t bit_sel       = 0;
    uint32_t cust_mask     = 0;
    uint32_t dw_ptr        = 0;
    uint32_t flit_num      = 0;
    bool     start_psn_en  = false;
    bool     range_psn_en  = false;
    uint32_t start_psn     = 0;
    bool     start_cfg_qpn_en;
    uint32_t start_cfg_qpn = 0;
    bool     inj_done      = false;
    uint32_t pkt_type      = 0;

    bool     round_mode_inj_en  = false;
    uint32_t round_mode_inj_num = 0;
    uint32_t round_mode_inj_gap = 0;
};

typedef struct _EslErrInj { ErrInjCfg err_inj[ERR_INJ_MAX]; } EslErrInj;

typedef enum _RasQIntBit {
    RAS_AXI_SLV_RETRY_BRESP_ERR = 0,
    RAS_AXI_SLV_RX_BRESP_ERR,
    RAS_AXI_MST_DMA_BRESP_ERR,
    RAS_AXI_MST_SQ_BRESP_ERR,
    RAS_AXI_MST_MSI_BRESP_ERR,
    RAS_AXI_SLV_RETRY_RRESP_ERR,
    RAS_AXI_MST_DMA_RRESP_ERR,
    RAS_AXI_MST_SQ_RRESP_ERR,
    RAS_SLV_QUEUE_RETRY_FAIL,
    RAS_MST_QUEUE_RETRY_FAIL,
    RAS_ILLEGAL_WQE,
    RAS_WQE_PARITY_ERR,
    RAS_SQ_SIZE_CONFIG_ERR,
    RAS_TX_MOVER_ERR,
    RAS_TX_MOVER_LEN_ERR,
    RAS_Q_DISABLE_DROP_ERR,
    RAS_SLV_TRANS_BACKUP_DIS_ERR,
    RAS_BIT_INVALID,
} RasQIntBit;

typedef struct {
    std::string int_sts_name      = "";
    uint32_t    int_sts_bit       = 0;
    uint32_t    q_int_mask_bit    = 0;
    uint32_t    q_bitmap_w1c_addr = 0;
} RasQBitMapInfo;

typedef struct {
    std::string err_name           = "";
    uint32_t    int_sts_bit        = 0;
    int         q_int_mask_bit     = 0;
    int         err_log_reg_offset = -1;
    int         err_log_reg_len    = -1;
} RasErrLog;

typedef union {
    struct {
        uint32_t bresp = 0;
        uint32_t bid   = 0;
        uint32_t buser = 0;
    } mst_wr;

    struct {
        uint32_t rresp         = 0;
        uint32_t rid           = 0;
        uint32_t ruser_parity_ = 0;
    } mst_rd;

    struct {
        uint64_t addr = 0;
    } slv_wr;
} RasErrLogDesc;

typedef struct _EslCpCtxTran {
    pthread_t thread_id  = 0;
    uint32_t  ctx_id     = 0;
    EslCtx    qp_ctx     = {};
    EslQpCfg  local_qpc  = {};
    EslQpCfg  remote_qpc = {};
    uint32_t  nnc_mode   = NNC_ENABLE;
    uint32_t  fence_mode = 0;

    uint32_t             eng_id           = 0;
    uint64_t             traffic_size     = 0;
    uint32_t             pattern          = 0x5a5a5a5a;
    uint64_t             total_loop       = 0;
    std::shared_ptr<Mem> src_mem          = nullptr;
    std::shared_ptr<Mem> dst_mem          = nullptr;
    std::shared_ptr<Mem> dst_esl_mem      = nullptr;
    uint64_t             esl_l3_offset    = 0;
    uint64_t             src_edf_addr     = 0;
    uint64_t             dst_edf_addr     = 0;
    uint64_t             dst_esl_edf_addr = 0;
    // std::vector<uint32_t> test_regs        = {};
    uint32_t wqe_num = 1;
    // std::vector<Wqe>      wqe_vec          = {};
} EslCpCtxTran;

typedef struct _TransAddr {
    uint64_t src_edf_addr;
    uint64_t dst_edf_addr;
    uint64_t dst_esl_edf_addr;
    uint32_t mem_pattern;
} TransAddr;

struct PortPair {
    uint32_t dev_l  = UINT32_MAX;
    uint32_t port_l = UINT32_MAX;
    uint32_t dev_r  = UINT32_MAX;
    uint32_t port_r = UINT32_MAX;
};

typedef struct _InteractCmd {
    struct {
        uint32_t cmd_type;
        uint32_t serial_num;
        uint32_t len;
        PortPair pair;
    } cmd_inf;

    struct {
        // uint32_t reserv0;
        // uint32_t reserv1;
        // uint32_t reserv2;
        bool   mstr_side;
        EslCtx ctx;
        // uint32_t fill_pattern;
        // uint64_t buff_addr;
    } trans_ctx;

    TransAddr trans_addr;
    uint32_t  mem_cmp_res;
    uint32_t  tail_flag;
} InteractCmd;

typedef struct _EslTrafficFSM {
    PortPair      pair                = {};
    EslCtx        local_ctx           = {};
    EslCtx        remote_ctx          = {};
    EslCpCtxTran  local_cpctx         = {};
    EslCpCtxTran  remote_cpctx        = {};
    TransAddr     local_trans_addr    = {};
    TransAddr     remote_trans_addr   = {};
    volatile bool local_qpcfg_done    = false;
    volatile bool remote_qpcfg_done   = false;
    volatile bool local_cpctx_done    = false;
    volatile bool remote_cpctx_done   = false;
    volatile bool local_sync_ready    = false;
    volatile bool remote_sync_ready   = false;
    volatile bool local_cmp_done      = false;
    volatile bool local_cmp_result    = false;
    volatile bool cmp_req_recv        = false;
    volatile bool remote_cmp_done     = false;
    volatile bool remote_cmp_result   = false;
    volatile bool local_traffic_done  = false;
    volatile bool remote_traffic_done = false;
    volatile bool clear_req_recv      = false;
    volatile bool local_mem_cleared   = false;
    volatile bool remote_mem_cleared  = false;
    int           message_seq         = 0;
    int           p_s_cmd             = 0;
    int           f_s_cmd             = 0;
    int           p_s_ack             = 0;
    int           f_s_ack             = 0;
    int           p_r_cmd             = 0;
    int           f_r_cmd             = 0;
    int           p_r_ack             = 0;
    int           f_r_ack             = 0;
} EslTrafficFSM;

typedef struct _ConnectInfo {
    _ConnectInfo(uint32_t index, std::string name, std::string ip, uint32_t esl_ports,
        uint32_t esl_devs = 1, uint32_t port = 9900, int client_fd = -1)
        : index(index),
          name(name),
          ip(ip),
          esl_ports(esl_ports),
          esl_devs(esl_devs),
          port(port + 1),
          client_hdl(client_fd),
          server_port(port),
          server_hdl(client_fd) {}

    uint32_t                           index       = 0;
    std::string                        name        = "";
    std::string                        ip          = "";
    uint32_t                           port        = 9901;
    int                                client_hdl  = -1;
    uint16_t                           server_port = 9900;
    int                                server_hdl  = -1;
    int                                server_cdl  = -1;
    uint32_t                           esl_ports   = 0;
    uint32_t                           esl_devs    = 0;
    std::vector<std::vector<uint32_t>> esl_matrix  = {};
    std::map<std::string, EslTrafficFSM> conn_fsm = {};
    EslCtx        local_ctx           = {};
    EslCtx        remote_ctx          = {};
    EslCpCtxTran  local_cpctx         = {};
    EslCpCtxTran  remote_cpctx        = {};
    TransAddr     local_trans_addr    = {};
    TransAddr     remote_trans_addr   = {};
    volatile bool local_qpcfg_done    = false;
    volatile bool remote_qpcfg_done   = false;
    volatile bool local_sync_ready    = false;
    volatile bool remote_sync_ready   = false;
    volatile bool local_traffic_done  = false;
    volatile bool remote_traffic_done = false;
    int           message_seq         = 0;
    int           p_s_cmd             = 0;
    int           f_s_cmd             = 0;
    int           p_s_ack             = 0;
    int           f_s_ack             = 0;
    int           p_r_cmd             = 0;
    int           f_r_cmd             = 0;
    int           p_r_ack             = 0;
    int           f_r_ack             = 0;
} ConnectInfo;

struct QpCfg {
    bool             enable;
    std::string      queue_mode_mask;
    std::vector<int> queue_id;

    static QpCfg LoadFromYAML(const YAML::Node &node) {
        QpCfg qp;

        qp.enable          = node["enable"].as<bool>();
        qp.queue_mode_mask = node["queue_mode_mask"].as<std::string>();
        for (const auto &id : node["queue_id"]) {
            qp.queue_id.push_back(id.as<int>());
        }

        return qp;
    }
};

// Structure for WinMonitor
struct WinMonitor {
    bool        enable;
    int         cyc;
    std::string mask;  // Mask is a hexadecimal string

    static WinMonitor LoadFromYAML(const YAML::Node &node) {
        WinMonitor win_monitor;
        win_monitor.enable = node["enable"].as<bool>();
        win_monitor.cyc    = node["cyc"].as<int>();
        win_monitor.mask   = node["mask"].as<std::string>();
        return win_monitor;
    }
};

// Structure for PortCfg
struct PortCfg {
    int        id;
    WinMonitor win_monitor;
    QpCfg      qp;

    static PortCfg LoadFromYAML(const YAML::Node &node) {
        PortCfg port;
        port.id          = node["id"].as<int>();
        port.win_monitor = WinMonitor::LoadFromYAML(node["win_monitor"]);
        port.qp          = QpCfg::LoadFromYAML(node["qp"]);

        return port;
    }
};

// Structure for DeviceCfg
struct DeviceCfg {
    int                  id;
    std::vector<PortCfg> ports;

    static DeviceCfg LoadFromYAML(const YAML::Node &node) {
        DeviceCfg device;
        device.id = node["id"].as<int>();
        for (const auto &port_node : node["ports"]) {
            device.ports.push_back(PortCfg::LoadFromYAML(port_node));
        }
        return device;
    }
};

// Structure for MonitorCfg Configuration
struct MonitorCfg {
    int refresh_period_ms;
    bool overwrite;
    std::vector<DeviceCfg> devices;

    static MonitorCfg LoadFromYAML(const YAML::Node &node) {
        MonitorCfg monitorCfg;
        monitorCfg.refresh_period_ms = node["refresh_period_ms"].as<int>();
        monitorCfg.overwrite         = node["overwrite"].as<bool>();
        for (const auto &device_node : node["devices"]) {
            monitorCfg.devices.push_back(DeviceCfg::LoadFromYAML(device_node));
        }
        return monitorCfg;
    }
};

class Esl : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    Esl() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Esl(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~Esl() {}

    virtual bool GlobalInit() {
        return true;
    }

    virtual bool MacInit(uint32_t rate, uint32_t fec, uint32_t rmode) = 0;
    virtual bool SetLoopback(const std::string &lb_type, bool enable) = 0;
    virtual bool     IsLinkUp() = 0;
    virtual uint32_t LineRate() = 0;

    // test registers
    virtual std::vector<uint32_t> GetTestRegisters()    = 0;
    virtual std::vector<uint32_t> GetInternalTestRegs() = 0;
    virtual uint32_t              GetEslEcfObOffset()   = 0;

    virtual void BypassNnc(bool bypass)        = 0;
    virtual void BypassNnc(uint32_t st)        = 0;
    virtual void GetNncBypassSta(uint32_t &st) = 0;
    virtual uint32_t GetNncCrSts()             = 0;
    virtual void InitNncDict(uint32_t val1, uint32_t val2, uint32_t val3) = 0;
    virtual void StartNncCr(uint32_t range) = 0;
    virtual void CfgCrRange(uint32_t range) = 0;
    virtual uint32_t GetNncRawSize()        = 0;
    virtual uint32_t GetNncCmpSize()        = 0;
    virtual float    CalCompRate()          = 0;

    virtual void QpcConfig(const EslQpCfg &cfg) = 0;
    virtual void SetQpcDestMac(const uint32_t qid, uint64_t mac) = 0;
    virtual void SetQpcDestIp(const uint32_t qid, uint32_t ip)   = 0;
    virtual void UpdateProdPtr(EslQpCfg &cfg, uint32_t inc_val)  = 0;
    virtual uint32_t ProdPtr(uint32_t qid) = 0;
    virtual uint32_t ConsPtr(uint32_t qid) = 0;

    virtual uint64_t GetMacAddr(uint32_t idx) = 0;
    virtual void GetMacAddr(uint32_t idx, uint8_t *ptr)     = 0;
    virtual void SetMacAddr(uint32_t idx, uint64_t mac)     = 0;
    virtual void SetMacAddr(uint32_t idx, uint8_t *mac_ptr) = 0;

    virtual uint32_t GetIpAddr(uint32_t idx) = 0;
    virtual void GetIpAddr(uint32_t idx, uint8_t *ptr)     = 0;
    virtual void SetIpAddr(uint32_t idx, uint32_t ip_addr) = 0;
    virtual void SetIpAddr(uint32_t idx, uint8_t *ip_ptr)  = 0;

    virtual bool GetMacCheck(bool val) = 0;
    virtual void SetMacCheck(bool val) = 0;
    virtual bool GetIpCheck(bool val)  = 0;
    virtual void SetIpCheck(bool val)  = 0;

    virtual const std::vector<uint32_t> GetBlockRegisters() = 0;

    virtual void SetTxdPfcBuffDscp(uint32_t buff_id, uint32_t dscp_val) = 0;
    virtual void SetTxcPfcBuffDscp(uint32_t buff_id, uint32_t dscp_val) = 0;
    virtual uint32_t GetTxdPfcBuffDscp(uint32_t buff_id) = 0;
    virtual uint32_t GetTxcPfcBuffDscp(uint32_t buff_id) = 0;
    virtual void SetPfcMapTxBuff(uint32_t buff_id, uint32_t pause_bit) = 0;
    virtual uint32_t GetPfcMapTxBuff(uint32_t buff_id) = 0;

    virtual void SetPfcMapAckCnp(uint32_t buff_id, uint32_t pause_bit) = 0;

    virtual bool QLR(uint32_t qid) = 0;
    virtual bool QLR(uint32_t qid, const EslQpCfg &cfg) = 0;
    virtual bool QLR(const EslCtx &ctx, bool mstr_queue = true) = 0;
    virtual void QDisable(uint32_t qid) = 0;
    virtual void QEnable(uint32_t qid, uint32_t tx_buff_id = 0, uint32_t asid = 0) = 0;
    virtual void QIntHandle(uint32_t qid, uint32_t int_pos, const EslQpCfg &cfg)   = 0;
    virtual void EslErrHandle() = 0;

    virtual void SetRetryTimerThd(uint32_t qid, uint32_t val, uint32_t to_ms = 1000,
        uint32_t timer_src = 0, uint32_t retry_mode = 0) = 0;
    virtual bool SqConfig(const EslQpCfg &qpc) = 0;
    virtual void RetryBufferConfig(const uint64_t addr, const uint32_t size) = 0;

    // slave mode
    virtual uint32_t GetMttMbit()              = 0;
    virtual void SetMttMbit(uint32_t mbit_val) = 0;
    virtual void SetMtte(
        uint64_t in_addr, uint64_t out_addr, uint32_t trans_bitN, uint32_t source_qid) = 0;
    virtual void UpdateMtteAddr(uint64_t in_addr, uint64_t out_addr) = 0;
    virtual void UpdateMtteQid(uint64_t in_addr, uint32_t queue_id)  = 0;

    virtual uint32_t GetAvaliableQueue(bool rand_queue = false) = 0;
    virtual bool GetQueue(uint32_t qid)                         = 0;
    virtual void ReleaseQueue(const uint32_t qid)               = 0;
    virtual bool QueueOccupied(const uint32_t qid)              = 0;
    virtual bool QueueInited(const uint32_t qid)                = 0;
    virtual void SetQueueInit(const uint32_t qid, bool val) = 0;

    virtual bool Submit(EslQpCfg &qpc, Wqe *src_wqe, uint32_t wqe_num, bool launch) = 0;
    virtual bool Submit(EslQpCfg &qpc, std::vector<Wqe> &src_wqe, bool launch) = 0;
    virtual void Launch(EslQpCfg &qpc, uint32_t wqe_num) = 0;
    virtual bool WaitForIdle(EslQpCfg &qpc, uint32_t timeout_s = 0) = 0;
    virtual void WqeDump(Wqe *wqe) = 0;
    virtual void PortPktDump(EslPortPktMonitor *port_pkt_monitor = nullptr) = 0;

    virtual void WinCntConfig(uint32_t cyc_val = 1000000U) = 0;
    virtual void WinCntDump(
        const uint32_t sel_mask, WinCntMonitor *win_cnt_monitor = nullptr) = 0;
    virtual void AxiLatDump(const uint32_t axi_lat_mask_sel = 0x3U) = 0;
    virtual void AxiLatCfg(const LatSeg seg)                        = 0;
    virtual void EthLatCfg(const LatSeg seg)                        = 0;
    virtual void QStubCfg(const std::map<int, uint32_t> stub_cfg, const uint32_t stub_mask,
        uint32_t mode_mask = 0xf)                              = 0;
    virtual void EthLatDump(const uint32_t eth_lat_q_mask_sel) = 0;
    virtual void QueueRateDump(const uint32_t q_stub_mask_sel,
        EslQueueRateMonitor *q_rate_monitor_p = nullptr, uint32_t *qpn_stub_p = nullptr) = 0;

    // ST PKT
    virtual void StPktClear(const uint32_t st_pkt_mask) = 0;
    virtual void StPktDump(const uint32_t st_pkt_mask)  = 0;

    // wcb
    virtual void WcbEnable(bool enable) = 0;

    // xoff/xon thd
    virtual void SetXoffThd(uint32_t val) = 0;
    virtual uint32_t GetXoffThd(void)     = 0;
    virtual void SetXonThd(uint32_t val)  = 0;
    virtual uint32_t GetXonThd(void)      = 0;

    // rx cc  ctrl
    virtual void SetTxCcCtrl(bool val) = 0;
    virtual void CcConfig(uint32_t qid, bool val) = 0;

    // basic nic
    virtual bool NicEnable(NicCfg &cfg)  = 0;
    virtual bool NicDisable(NicCfg &cfg) = 0;
    virtual void NicSubmit(std::vector<NicDesc> &desc_v, bool launch) = 0;
    virtual void NicUpdateTxPtr(uint32_t val)                = 0;
    virtual bool NicRxValid()                                = 0;
    virtual void NicGetRxDesc(std::vector<NicDesc> &rx_desc) = 0;
    virtual bool NicWaitForIdle(uint32_t timeout_s)          = 0;
    virtual void NicCopy(uint8_t *mem_ptr, uint64_t base, uint64_t size, bool lunch) = 0;

    // RAS interface
    virtual void SetEslRespChkEn(bool val)   = 0;
    virtual void SetEslParityChkEn(bool val) = 0;
    virtual bool GetEslParityChkEn()         = 0;
    virtual bool GetEslRespCheckEn()         = 0;
    virtual bool CheckErrorValid()           = 0;
    virtual void ClearEslErrorStatus()       = 0;
    virtual void SramMiscErrInj(bool val)    = 0;
    virtual void MacFcsErrInj(bool val)      = 0;
    virtual bool FindRasQBitMap(uint32_t int_pos, RasQBitMapInfo &map) = 0;
    virtual void EslErrInj(const std::string type, ErrInjCfg &inj_cfg, bool wait_done) = 0;
    virtual void ClearErrCnt()          = 0;
    virtual void ClearBlackHoleErrCnt() = 0;
    virtual void ErrCntDump(bool clr_cnt = true) = 0;

    virtual void ErrorSnapshot(uint32_t qid) = 0;
    std::mutex  glb_mtx                      = {};
    virtual int GetNicRasErr(uint32_t index, EslSnapShotInfo &info)                  = 0;
    virtual int GetNicOversizeDropCnt(uint32_t index, EslSnapShotInfo &info)         = 0;
    virtual int GetNicSopEopErrCnt(uint32_t index, EslSnapShotInfo &info)            = 0;
    virtual int GetICrcErrCnt(uint32_t index, EslSnapShotInfo &info)                 = 0;
    virtual int GetIpTotLenErrCnt(uint32_t index, EslSnapShotInfo &info)             = 0;
    virtual int GetIpTotCheckSumErrCnt(uint32_t index, EslSnapShotInfo &info)        = 0;
    virtual int GetIpAddrErrCnt(uint32_t index, EslSnapShotInfo &info)               = 0;
    virtual int GetMacAddrErrCnt(uint32_t index, EslSnapShotInfo &info)              = 0;
    virtual int GetMacErrCodeCnt(uint32_t index, EslSnapShotInfo &info)              = 0;
    virtual int GetDecapErrCntThreshold(uint32_t index, EslSnapShotInfo &info)       = 0;
    virtual int GetOversizeErrCnt(uint32_t index, EslSnapShotInfo &info)             = 0;
    virtual int GetRasRxtmReqErrCnt(uint32_t index, EslSnapShotInfo &info)           = 0;
    virtual int GetRasRxtmRspErrCnt(uint32_t index, EslSnapShotInfo &info)           = 0;
    virtual int GetRasEslRdmaOpErrCnt(uint32_t index, EslSnapShotInfo &info)         = 0;
    virtual int GetRasReqCommErrCnt(uint32_t index, EslSnapShotInfo &info)           = 0;
    virtual int GetRasRspCommErrCnt(uint32_t index, EslSnapShotInfo &info)           = 0;
    virtual int GetRasRxPauseBufferDropErrCnt(uint32_t index, EslSnapShotInfo &info) = 0;
    virtual int GetEslPerfRxErrCntMacFcsTotal(uint32_t index, EslSnapShotInfo &info) = 0;
    virtual int GetEslPerfRxErrCntMacFcsRdma(uint32_t index, EslSnapShotInfo &info)  = 0;
    virtual int GetEslPerfRxErrCntRdmaIcrc(uint32_t index, EslSnapShotInfo &info)    = 0;
    virtual int GetBlackHoleRocev2ErrCnt(uint32_t index, EslSnapShotInfo &info)      = 0;
    virtual int GetBlackHoleUdpErrCnt(uint32_t index, EslSnapShotInfo &info)         = 0;
    virtual int GetBlackHoleIpv4ErrCnt(uint32_t index, EslSnapShotInfo &info)        = 0;
    virtual int GetQpSrcIp(uint32_t index, EslSnapShotInfo &info)                    = 0;
    virtual int GetQpSrcMac(uint32_t index, EslSnapShotInfo &info)                   = 0;
    virtual int GetQpDstIp(uint32_t index, EslSnapShotInfo &info)                    = 0;
    virtual int GetQpDstMac(uint32_t index, EslSnapShotInfo &info)                   = 0;
    virtual int GetQpSrcUdpPort(uint32_t index, EslSnapShotInfo &info)               = 0;
    virtual int GetQpDstUdpPort(uint32_t index, EslSnapShotInfo &info)               = 0;
    virtual int GetQpTtl(uint32_t index, EslSnapShotInfo &info)                      = 0;
    virtual int GetQpRemoteQp(uint32_t index, EslSnapShotInfo &info)                 = 0;
    virtual int GetNncCmpRate(uint32_t index, EslSnapShotInfo &info)                 = 0;
    virtual int GetSqWqe(uint32_t index, EslSnapShotInfo &info)                      = 0;
    virtual int GetWinCntMonPauseLastTx(uint32_t index, EslSnapShotInfo &info)       = 0;
    virtual int GetWinCntMonPauseLastRx(uint32_t index, EslSnapShotInfo &info)       = 0;
    virtual int GetWinCntMonPauseCntTx(uint32_t index, EslSnapShotInfo &info)        = 0;
    virtual int GetWinCntMonPauseCntRx(uint32_t index, EslSnapShotInfo &info)        = 0;
    virtual int GetQpRxTm(uint32_t index, EslSnapShotInfo &info)                     = 0;
    virtual int GetMacTxRdy(uint32_t index, EslSnapShotInfo &info)                   = 0;
    virtual int GetMacTxVldRdy(uint32_t index, EslSnapShotInfo &info)                = 0;
    virtual int GetMacRxVldRdy(uint32_t index, EslSnapShotInfo &info)                = 0;
    virtual int GetMacTxPps(uint32_t index, EslSnapShotInfo &info)                   = 0;
    virtual int GetMacTxKbps(uint32_t index, EslSnapShotInfo &info)                  = 0;
    virtual int GetMacRxPps(uint32_t index, EslSnapShotInfo &info)                   = 0;
    virtual int GetMacRxKbps(uint32_t index, EslSnapShotInfo &info)                  = 0;
    virtual int GetEslTxPps(uint32_t index, EslSnapShotInfo &info)                   = 0;
    virtual int GetEslTxKbps(uint32_t index, EslSnapShotInfo &info)                  = 0;
    virtual int GetEslRxPps(uint32_t index, EslSnapShotInfo &info)                   = 0;
    virtual int GetEslRxKbps(uint32_t index, EslSnapShotInfo &info)                  = 0;
    virtual int GetTotalTxPktCnt(uint32_t index, EslSnapShotInfo &info)              = 0;
    virtual int GetTotalRxPktCnt(uint32_t index, EslSnapShotInfo &info)              = 0;

 public:
    bool retry_buff_enabled = false;

 private:
    virtual void MacInit200GR4Rs544() = 0;
    virtual void MacInit100GR2Rs544() = 0;
    virtual void MacInit100GR4Rs528() = 0;
    virtual void MacInit50GR1Rs544()  = 0;
};

class EslMgr {
 public:
    explicit EslMgr(std::shared_ptr<spdlog::logger> logger);
    virtual ~EslMgr() {}

    virtual Dtu *GetDtu(int dev_id) = 0;
    virtual bool Init()             = 0;
    virtual bool Init(uint32_t server_id, bool over_net) = 0;
    virtual bool Deinit()                                = 0;
    virtual bool Deinit(uint32_t server_id)              = 0;
    virtual bool Bind(const EslCtx &ctx)                 = 0;
    virtual bool IsConnected(const EslCtx &ctx)          = 0;
    virtual void ConnectionInfo(const EslCtx &ctx)       = 0;
    virtual bool QueueLevelReset(const EslQpCfg &qp_cfg) = 0;
    virtual bool GlobalInit(Dtu *esl_dtu)                = 0;

    virtual Esl *GetEslHw(int dev_id, uint32_t port_id) = 0;

    virtual bool CtxInit(EslCtx &ctx) = 0;
    virtual bool CtxInit(EslCtx &ctx, bool mstr_side, uint32_t client_idx, Esl *local_esl) = 0;
    virtual bool Bind(const EslCtx &ctx, bool mstr_side) = 0;
    virtual bool CtxDeInit(EslCtx &ctx) = 0;

    virtual bool SendSipCmd(uint32_t dev_id, SIP_CMD &cmd) = 0;

    // all2all mesh api
    virtual bool StartSC() = 0;
    virtual bool StopSC()  = 0;

    virtual void SetNonBlocking(int fd) = 0;
    virtual void StatisticPrint()       = 0;

    virtual std::string GetPortPairKey(PortPair &pair)          = 0;
    virtual PortPair GetKeyPortPair(const std::string &key_str) = 0;

    virtual bool TrySendCmd(uint32_t client_id, uint32_t msg_type, PortPair dev_port_pair,
        bool mstr_side = false) = 0;

    virtual bool TriggerRemoteCmp(uint32_t client_idx, bool mstr_side, bool qp_mstr,
        std::shared_ptr<EslCtx> l_qpctx, bool remote_clear = true) = 0;
    virtual bool ReplyCmpRes(uint32_t client_idx, bool mstr_side, bool qp_mstr,
        std::shared_ptr<EslCtx> l_qpctx, uint64_t loop) = 0;
    virtual bool ReplyClearRes(uint32_t client_idx, bool mstr_side, bool qp_mstr,
        std::shared_ptr<EslCtx> l_qpctx) = 0;
    virtual bool SetMem(EslCpCtxTran &ctx, uint32_t client_idx, bool mstr_side, bool qp_mstr,
        std::shared_ptr<EslCtx> l_qpctx) = 0;
    virtual bool SyncReady(uint32_t client_idx, bool mstr_side = true, uint32_t interval = 200,
        uint32_t timeout_l = 60) = 0;
    virtual bool SyncTrafficEnd(uint32_t client_idx, uint32_t timeout_l = 60) = 0;

    virtual void ClientFunc(uint32_t client_idx) = 0;
    virtual void ServerFunc()                    = 0;
    virtual void ServerInner(struct sockaddr_in clientaddr, int clientfd) = 0;
    virtual bool SendCmd(uint32_t client_idx, InteractCmd &cmd)           = 0;
    virtual void ProcessRData(char *ptr) = 0;
    virtual void TrafficCount(uint32_t client_idx, int send, int cmd_ack, int succeed) = 0;
    virtual uint32_t GetIpIdx(std::string ip) = 0;
    virtual bool FilterIp(const std::string &line, std::vector<std::string> &res) = 0;
    virtual bool GetServerCfg(const std::string &fn) = 0;

    virtual void CmdHandler(InteractCmd &cmd, uint32_t client_idx) = 0;

    // Slave mode api
    virtual void InitMtt(uint32_t mtt_idx) = 0;

    virtual std::map<int, std::vector<Esl *>> GetAllEslDevMap() = 0;

    virtual uint64_t DevAddrToEslOB(uint64_t ipa, uint32_t port_id) {
        return 0;
    }
    virtual uint64_t EslOBToDevAddr(uint64_t ob_addr, uint32_t port_id) {
        return 0;
    }
    virtual uint64_t EslOBToElsIntAddr(uint64_t ob_addr, uint32_t port_id) {
        return 0;
    }

    virtual void CtxDump(EslCtx &ctx) = 0;
    virtual std::string FormatString(const uint8_t *in_char, uint8_t len,
        const std::string deli, const std::string format = "hex") {
        return "";
    }

    virtual uint32_t GetMttEntryNum() = 0;
    virtual int Dump(MonitorCfg &cfg) = 0;

    std::vector<ConnectInfo>                  m_connections     = {};
    std::vector<std::thread>                  m_server_inner_ts = {};
    std::vector<std::unique_ptr<std::thread>> m_remote_clients  = {};
    std::map<std::string, uint32_t> ip_to_cid_map;
    uint32_t                     m_server_idx    = 0;
    bool                         over_network    = false;
    volatile bool                server_exit     = false;
    std::unique_ptr<std::thread> m_server_thread = nullptr;
    std::unique_ptr<std::thread> m_client_thread = nullptr;

 protected:
    uint64_t m_l3_mem_offset = 0;  // for EMU

 protected:
    std::shared_ptr<spdlog::logger> logger_;
};

}  // namespace esl
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_ESL_ESL_H_
