/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_NOC_NOC_MGR_H_
#define HARDWARE_INCLUDE_NOC_NOC_MGR_H_

#include <memory>
#include <string>
#include <vector>

#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_error.h"
#include "hardware/include/noc/noc_qos.h"
#include "hardware/include/noc/noc_ras.h"

namespace efvf {
namespace hardware {
namespace noc {

class NocMgr {
 public:
    NocMgr(std::shared_ptr<spdlog::logger> logger, const Dtu &dtu);
    virtual ~NocMgr() {}

 public:
    virtual int DumpAllErrorLogger(int die_id, std::vector<NOC_Err_Info> &errors) = 0;
    virtual int DumpAllBstpChnl(int die_id, std::vector<std::string> &infos)      = 0;
    virtual int GetDumpLimitation(std::string &limitation) = 0;
    virtual int ClearAllErrorLogger(int die_id)            = 0;
    virtual NocErr *GetErrLogger(int inst, int die_id, const std::string &alias) = 0;
    virtual NocQos *GetQos(int inst, int die_id, const std::string &alias)       = 0;
    virtual NocQos *GetQosRead(int inst, int die_id) = 0;

 protected:
    std::shared_ptr<spdlog::logger> logger_;
    const Dtu &                     dtu_;
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_NOC_NOC_MGR_H_
