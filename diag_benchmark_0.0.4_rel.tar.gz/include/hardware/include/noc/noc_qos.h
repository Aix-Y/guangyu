/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_NOC_NOC_QOS_H_
#define HARDWARE_INCLUDE_NOC_NOC_QOS_H_

#include <memory>
#include <set>
#include <string>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace noc {

typedef enum {
    NOC_QOS_MODE_FIXED     = 0,
    NOC_QOS_MODE_LIMITER   = 1,
    NOC_QOS_MODE_BYPASS    = 2,
    NOC_QOS_MODE_REGULATOR = 3,
} NOC_QOS_MODE;

typedef enum _NOC_QOS_PRI_LEVEL {
    NOC_QOS_LEVEL_0 = 0,
    NOC_QOS_LEVEL_1 = 1,
    NOC_QOS_LEVEL_2 = 2,
    NOC_QOS_LEVEL_3 = 3,
} NOC_QOS_PRI_LEVEL;

typedef struct {
    uint32_t write_pri;
    uint32_t read_pri;
    uint32_t saturation;
    uint32_t bandwidth;
} NOC_QOS_READ_CFG;

typedef struct {
    uint32_t read_pri;
    uint32_t write_pri;
    uint32_t saturation;
    uint32_t bandwidth;
} NOC_QOS_WRITE_CFG;

class NocQos : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocQos(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocQos() {}

    virtual bool SetNocQosReadGen(const NOC_QOS_READ_CFG &noc_qos_read_cfg)    = 0;
    virtual bool SetNocQosWriteGen(const NOC_QOS_WRITE_CFG &noc_qos_write_cfg) = 0;
    virtual void QosMode(uint32_t qos_mode)                                    = 0;
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_NOC_NOC_QOS_H_
