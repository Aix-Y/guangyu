/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/**
 * @file  ecmo.h
 * @brief hardware ECMO module description file
 * @date  28th July 2022
 */

#ifndef HARDWARE_INCLUDE_ECMO_H_
#define HARDWARE_INCLUDE_ECMO_H_

#include <memory>
#include <vector>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace ecmo {

enum ECMO_FABIC { ECF_ECMO = 0, EDF_ECMO = 1, INVALID_ECMO = 0xf };

enum ECMO_INTERFACE { SLV_ECMO = 0, MST_ECMO = 1, INVALID_INTERFACE_ECMO = 0xf };

enum ECMO_IP {
    SIP_ECMO = 0,
    CBF_ECMO,
    AASP_ECMO,
    MEM_ECMO,
    SP_ECMO,
    CVA_ECMO,
    GMU_ECMO,
    CDTE_ECMO,
    DPF_ECMO,
    PCIE_ECMO,
    AP_ECMO,
    SSM_ECMO,
    VPP_ECMO,
    ODTE_ECMO,
    CDFT_ECMO,
    INVALID_ECMO_IP = 0xFF
};

typedef struct {
    uint8_t  tiemout_buser    = 5;
    uint8_t  tiemout_bresp    = 2;
    uint8_t  tiemout_ruser    = 5;
    uint8_t  tiemout_rresp    = 2;
    uint32_t wr_timeout_thd   = 16;
    uint32_t rd_timeout_thd   = 16;
    bool     wr_auto_reply_en = false;
    bool     rd_auto_reply_en = false;
} EcmoSlvTimeoutCfg;

typedef struct {
    bool exit_wr_auto_reply = false;
    bool exit_rd_auto_reply = false;
} EcmoSlvExitAutoReplyCfg;

typedef struct {
    uint8_t blr_buser = 8;
    uint8_t blr_bresp = 2;
    uint8_t blr_ruser = 8;
    uint8_t blr_rresp = 2;
} EcmoSlvBlrCfg;

typedef struct {
    uint16_t timeout_wr_cnt = {};
    uint16_t timeout_rd_cnt = {};
} EcmoSlvTimeoutCnt;

typedef struct {
    bool wr_timeout_irq = {};
    bool rd_timeout_irq = {};
} EcmoSlvTimeoutIrq;

typedef struct {
    bool rd_timeout_irq_mask = false;
    bool wr_timeout_irq_mask = false;
} EcmoSlvTimeoutIrqMaskCfg;

typedef struct {
    uint32_t w_outstd_cnt = {};
    uint32_t r_outstd_cnt = {};
    bool     widle        = {};
    bool     ridle        = {};
    bool     idle         = {};
    void *   user_data    = nullptr;
} EcmoMstSts;

typedef struct {
    bool              wbogus = {};
    bool              rbogus = {};
    bool              widle  = {};
    bool              ridle  = {};
    bool              idle   = {};
    EcmoSlvTimeoutCnt timeout_cnt;
    EcmoSlvTimeoutIrq timeout_irq;
    void *            user_data = nullptr;
} EcmoSlvSts;

typedef struct {
    EcmoSlvTimeoutCfg        timeout_cfg;
    EcmoSlvBlrCfg            blr_cfg;
    EcmoSlvTimeoutIrqMaskCfg irq_mask_cfg;
    EcmoSlvExitAutoReplyCfg  auto_reply_cfg;
    void *                   user_data = nullptr;
} EcmoSlvCfg;

typedef struct {
    bool  bypass    = false;
    bool  stop      = false;
    void *user_data = nullptr;
} EcmoMstCfg;

/**
 * @brief definition of EcmoInst structure
 * this structure defines ecmo instance
 */
typedef struct {
    uint32_t       inst_id   = 0;  /**< ecmo instance id */
    uint32_t       ecf_base  = 0;  /**< ecmo block register ecf base address */
    ECMO_FABIC     fabic     = {}; /**< ecmo ECF or EDF */
    ECMO_INTERFACE interface = {}; /**< ecmo master or slave interface */
} EcmoInst;

/**
 * @brief definition of EcmoSts structure
 * this structure stores ecmo master/slave status
 */
typedef struct {
    EcmoMstSts mst_sts; /**< master ecmo status */
    EcmoSlvSts slv_sts; /**< slave ecmo status */
} EcmoSts;
/**
 * @brief definition of EcmoCfg structure
 * this structure stores ecmo master/slave config
 * info
 */
typedef struct {
    EcmoMstCfg mst_cfg; /**< master ecmo configuration */
    EcmoSlvCfg slv_cfg; /**< slave ecmo configuration */
} EcmoCfg;

/**
 * @brief definition of Ecmo
 *
 */
class Ecmo : public Hardware {
 public:
    explicit Ecmo(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}
    virtual ~Ecmo() = default;

    /**
    * @brief sigle ecmo instance stop operation
    *        this operation stops single ecmo inst
    *        no matter master/slave or ecf/edf ecmos
    * @param[in] val: stop or enable inst ecmo
    */
    virtual void Stop(bool val) = 0;
    /** @brief check ecmo inst idle */
    virtual bool Idle() = 0;

    /**
    * @brief configuration for single ecmo instance
    * @param[in] cfg: ecmo configuration structure
    */
    virtual void Config(const EcmoCfg &cfg) = 0;

    /**
    * @brief status check for single ecmo instance
    * @param[in] sts: ecmo status structure
    */
    virtual void Status(EcmoSts &sts) = 0;
    /** @brief dump single ecmo instance status*/
    virtual void StatusDump(const EcmoSts &sts) = 0;
};

/**
 * @brief definition of MstrEcmo
 *
 */
class MstrEcmo : public Ecmo {
 public:
    explicit MstrEcmo(std::shared_ptr<spdlog::logger> logger) : Ecmo(logger) {}
    virtual ~MstrEcmo() = default;
    /**
    * @brief sigle ecmo instance stop operation
    *        this operation stops single ecmo inst
    *        no matter master/slave or ecf/edf ecmos
    * @param[in] val: stop or enable inst ecmo
    */
    virtual void SetStop(bool val);
    virtual bool GetStop();
    /** @brief check ecmo inst idle */
    virtual bool Idle();

    /**
    * @brief configuration for single ecmo instance
    * @param[in] cfg: ecmo configuration structure
    */
    virtual void Config(const EcmoCfg &cfg);

    /**
    * @brief status check for single ecmo instance
    * @param[in] sts: ecmo status structure
    */
    virtual void Status(EcmoSts &sts);
    /** @brief dump single ecmo instance status*/
    virtual void StatusDump(const EcmoSts &sts);
};

/**
 * @brief definition of SlvEcmo
 *
 */
class SlvEcmo : public Ecmo {
 public:
    explicit SlvEcmo(std::shared_ptr<spdlog::logger> logger) : Ecmo(logger) {}
    virtual ~SlvEcmo() = default;
    /**
    * @brief sigle ecmo instance stop operation
    *        this operation stops single ecmo inst
    *        no matter master/slave or ecf/edf ecmos
    * @param[in] val: stop or enable inst ecmo
    */
    virtual void SetStop(bool val);
    virtual bool GetStop();
    /** @brief check ecmo inst idle */
    virtual bool Idle();

    /**
    * @brief configuration for single ecmo instance
    * @param[in] cfg: ecmo configuration structure
    */
    virtual void Config(const EcmoCfg &cfg);

    /**
    * @brief status check for single ecmo instance
    * @param[in] sts: ecmo status structure
    */
    virtual void Status(EcmoSts &sts);
    /** @brief dump single ecmo instance status*/
    virtual void StatusDump(const EcmoSts &sts);
};

}  // namespace ecmo
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_ECMO_H_
