/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_RAS_H_
#define HARDWARE_INCLUDE_RAS_H_

#include <memory>
#include <string>
#include <vector>
#include "customize/customize.h"
#include "framework/include/log.h"

namespace efvf {
namespace hardware {

class RasCfg {
 public:
    virtual ~RasCfg() {}
};

class RasErrInj {
 public:
    virtual ~RasErrInj() {}
};

class RasErrStat {
 public:
    virtual ~RasErrStat() {}
    bool is_err_ = false;
};

class IntrptCfg {
 public:
    virtual ~IntrptCfg() {}
};

class IntrptStat {
 public:
    virtual ~IntrptStat() {}
};

class IRas {
 public:
    /**
     * @brief      could set multi config by setting next_
     *
     * @param      cfg   The configuration
     */
    virtual void Enable(RasCfg *cfg) = 0;

    /**
     * @brief      { function_description }
     */
    virtual void Disable(RasCfg *cfg) = 0;

    /**
     * @brief      Starts an error injection.
     *
     * @param      cfg      The configuration
     * @param      err_inj  The error inj
     */
    virtual void StartErrInjection(RasCfg *cfg, RasErrInj *err_inj) = 0;

    /**
     * @brief      Stops an error injection.
     *
     * @param      cfg      The configuration
     * @param      err_inj  The error inj
     */
    virtual void StopErrInjection(RasCfg *cfg, RasErrInj *err_inj) = 0;

    /**
     * @brief      Queries an error status.
     *
     * @param      cfg       The configuration
     * @param      err_stat  The error stat
     */
    virtual void QueryErrStatus(RasCfg *cfg, RasErrStat *err_stat) = 0;

    /**
     * @brief      { function_description }
     *
     * @param      cfg   The configuration
     */
    virtual void ClearErrStatus(RasCfg *cfg) = 0;

    /**
     * @brief      Prints an error status.
     *
     * @param      cfg   The configuration
     */
    virtual void PrintErrStatus(RasCfg *cfg) = 0;

    /**
     * @berif get ras cfg
     *
     * @param      cfg   The configuration
     */
    virtual void GetRasCfg(RasCfg *cfg) = 0;

    /**
     * @brief      Enables the interrupt.
     *
     * @param      cfg   The configuration
     */
    virtual void EnableInterrupt(IntrptCfg *cfg) = 0;

    /**
     * @brief      Disables the interrupt.
     *
     * @param      cfg   The configuration
     */
    virtual void DisableInterrupt(IntrptCfg *cfg) = 0;

    /**
     * @brief      { function_description }
     *
     * @param      cfg   The configuration
     */
    virtual void ClearInterrupt(IntrptCfg *cfg) = 0;

    /**
     * @brief      Queries an interrupt.
     *
     * @param      cfg    The configuration
     * @param      stats  The statistics
     */
    virtual void QueryInterrupt(IntrptCfg *cfg, IntrptStat *stats) = 0;

    /**
     * @brief      Prints an interrupt.
     *
     * @param      cfg   The configuration
     */
    virtual void PrintInterrupt(IntrptCfg *cfg) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  type  The type
     * @param[in]  is_stop  is stopping err inj?
     *
     * @return     { description_of_the_return_value }
     */
    virtual RasErrInj *GenRasErrInjCfg(const std::string &type, bool is_stop = false) {
        return nullptr;
    }

 protected:
    std::shared_ptr<spdlog::logger> logger_;
};

}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_RAS_H_
