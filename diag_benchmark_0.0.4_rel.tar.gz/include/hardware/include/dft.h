/////////////////////////////////////////////////////////////////////////////
//
//  @file dft_lib.h
//
//  @brief This file describes the dft library interface declaration
//
//  Enflame Tech, All Rights Reserved. 2024 Copyright (C)
//
/////////////////////////////////////////////////////////////////////////////
#ifndef HARDWARE_INCLUDE_DFT_H_
#define HARDWARE_INCLUDE_DFT_H_

#include <memory>
#include <string>
#include "framework/include/log.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace dft {

// MTAP IRs
#define CDFT_IDCODE 0x8
#define CDFT_BYPASS 0xFF
#define ALTTAP_EN 0x13
#define SW_DECODE 0x14
#define HBMPHY0_EN_IR 0x15
#define HBMPHY1_EN_IR 0x16
// const int DRAM0_EN_IR        = 0x17;
// const int DRAM1_EN_IR        = 0x18;
// const int DRAM0BIT_EN_IR     = 0x19;
// const int DRAM1BIT_EN_IR     = 0x20;
// const int HBMPHY0_WIR_EN_IR  = 0x21;
// const int HBMPHY1_WIR_EN_IR  = 0x22;
// const int DRAM0_WIR_EN       = 0x23;
// const int DRAM1_WIR_EN       = 0x24;
#define HBMPHY0BIT_EN_IR 0x25
#define HBMPHY1BIT_EN_IR 0x26
// const int AXI_CONFIG        = 0x33;

typedef struct _BitsNumValue {
    int len;
    int data[1024];
    int idata;
} BitsNumValue;

class Dft : public Hardware {
 public:
    Dft() : Hardware() {}
    explicit Dft(std::shared_ptr<spdlog::logger> logger);
    virtual ~Dft();

    // functional interfaces
    virtual bool ReadTDR(std::string tdr, uint32_t &outValue) = 0;
    virtual bool WriteTDR(char *tdr, uint32_t value)          = 0;

    virtual int ShiftIR(uint32_t sizeInBits, uint32_t IR)       = 0;
    virtual int ShiftDR(uint32_t sizeInBits, uint32_t DR)       = 0;
    virtual int ShiftDR(uint32_t sizeInBits, uint32_t buffer[]) = 0;

    virtual int ReadTDO(int sizeInBits, uint32_t &TDO)     = 0;
    virtual int ReadTDO(int sizeInBits, uint32_t buffer[]) = 0;

    virtual bool TestJTAG()   = 0;
    virtual bool ReadIDCode() = 0;

    virtual void JTAG_Reset() = 0;

    // Access registers via jtag2axi
    virtual int ReadReg(uint32_t addr, uint32_t &outValue) = 0;
    virtual int WriteReg(uint32_t addr, uint32_t value)    = 0;

    // Access registers via LTAP jtag2axi
    virtual int ReadLtapReg(std::string ip, uint32_t addr, uint32_t &outValue) = 0;
    virtual int WriteLtapReg(std::string ip, uint32_t addr, uint32_t value)    = 0;

    // SSM register access methods
    virtual int ReadSSMReg(int offset, uint32_t &outValue) = 0;
    virtual int WriteSSMReg(int offset, uint32_t value)    = 0;

    virtual void SwitchAltTAP() = 0;

    // MC related functional interfaces
    virtual int MC_SetApbOwnTap(int mc_index, bool enable) = 0;
    virtual int MC_WriteIR(int mc_index, int sizeInBits, uint32_t IR)        = 0;
    virtual int MC_ReadDR(int mc_index, int sizeInBits, uint32_t outValue[]) = 0;
    virtual int MC_WriteDR(int mc_index, int sizeInBits, uint32_t value[])   = 0;

    virtual bool ReadMcLtapIDCode(int mc_index) = 0;

    // HBM Phy register access methods
    virtual bool ReadHBMPhyReg(
        int phy_index, int channel_index, int dword_index, int offset, uint32_t &outValue) = 0;
    virtual bool WriteHBMPhyReg(
        int phy_index, int channel_index, int dword_index, int offset, uint32_t value) = 0;

    // PCIE/CCIX Phy register access methods
    virtual bool ReadPCIePhyReg(int phy_index, int address, uint32_t &outValue) = 0;
    virtual bool WritePCIePhyReg(int phy_index, int address, uint32_t value)    = 0;

    virtual bool ReadCCIXPhyReg(int phy_index, int address, uint32_t &outValue) = 0;
    virtual bool WriteCCIXPhyReg(int phy_index, int address, uint32_t value)    = 0;

    // Scan setup TDR for Pavo cluster reset workaround
    virtual int ReadScanSetupTDR(int cluster_id, uint32_t &outValue) = 0;
    virtual int WriteScanSetupTDR(int cluster_id) = 0;

    virtual int MemoryRepairWorkaround(void)        = 0;
    virtual int ReadMemoryRepairWorkaroundTDR(void) = 0;

    virtual int SampleCode(void) = 0;

protected:
};

}  // namespace dft
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_DFT_H_
