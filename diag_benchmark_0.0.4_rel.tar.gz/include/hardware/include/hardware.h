/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_HARDWARE_H_
#define HARDWARE_INCLUDE_HARDWARE_H_

#include <stdint.h>
#include <sys/cdefs.h>
#include <bitset>
#include <memory>
#include <string>
#include <vector>
#include "customize/customize.h"
#include "framework/include/ef_object.h"
#include "hardware/include/ras.h"
#include "hpd/include/hpd.h"
#include "native/include/registry.h"

#define HW_MAX_BIT 128

using efvf::hpd::Hpd;

namespace efvf {
namespace device {
class Dtu;
}  // namespace device
}  // namespace efvf

using efvf::device::Dtu;

using efvf::hardware::IRas;

namespace efvf {
namespace hardware {

typedef struct _reset_range {
    uint64_t s_off;
    uint64_t e_off;
} reset_range;

/**
 *
 */
class Hardware : public efvf::framework::EfObject {
 public:
    Hardware *        parent_  = nullptr;
    Hardware *        brother_ = nullptr;
    Hardware *        child_   = nullptr;
    Hardware *        brdcast_ = nullptr;
    Dtu *             dtu_     = nullptr;
    std::string       name_{};
    std::string       alias_{};
    uint64_t          offset_       = 0;
    uint16_t          num_          = 0;
    uint16_t          inst_         = 0;
    uint16_t          phy_inst_     = 0;
    uint64_t          ecf_addr_     = 0;  // could have multi ecf_addr
    uint64_t          ecf_host_ptr_ = 0;  // virtual bar addr of ecf_addr
    uint64_t          ccf_addr_     = 0;  // could have multi ccf_addr
    uint64_t          size_         = 0;
    uint32_t          master_id_    = 0;  // could have multi master id
    uint32_t          die_id_       = 0;  // master die(0) or slave die(1)
    std::atomic<bool> disable_;
    std::atomic<bool> inited_;

    Hpd *hpd_ = nullptr;

    bool disable_restore_ = false;

    uint8_t card_index_ = 0;

    std::bitset<HW_MAX_BIT>  mask_ = 0;
    std::vector<reset_range> reset_addr_range_;
    std::vector<uint32_t>    reset_addr_;
    std::vector<uint32_t>    reset_val_;

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger    The logger
     * @param[in]  ecf_addr  The ecf address
     */
    Hardware(std::shared_ptr<spdlog::logger> logger, uint64_t ecf_addr);

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Hardware(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Constructs a new instance.
     */
    Hardware();

    /**
     * @brief      Destroys the object.
     */
    virtual ~Hardware();

    /**
     * @brief      will drop do not use.
     *
     * @param      cfg   The new value
     */
    virtual void set_init_cfg(void *cfg) {}

    /**
     * @brief      Initializes the object.
     *
     * @return     { description_of_the_return_value }
     */
    bool Init();

    /**
     * @brief      Initializes the mini.
     *
     * @return     { description_of_the_return_value }
     */
    bool InitMini();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    bool Deinit();

    /**
     * @brief      Sets the hpd.
     *
     * @param[in]  hpd   The new value
     */
    void set_hpd(Hpd *hpd) {
        hpd_ = hpd;
    }

    /**
     * @brief      Gets the hpd.
     *
     * @return     The hpd.
     */
    Hpd *get_hpd() const {
        return hpd_;
    }

    /**
     * @brief      Gets the child count.
     *
     * @return     The child count.
     */
    int get_child_cnt() {
        return child_cnt_;
    }

    /**
     * @brief      Sets the hardware soc.
     *
     * @param      hw_soc  The hardware soc
     */
    void set_hw_soc(Hardware *hw_soc) {
        hw_soc_ = hw_soc;
    }

    /**
     * @brief      Sets the mask.
     *
     * @param[in]  mask  The mask
     */
    virtual void set_mask(const std::bitset<HW_MAX_BIT> &mask);

    /**
     * @brief      Gets the ras.
     *
     * @return     The ras.
     */
    std::shared_ptr<IRas> get_ras() {
        return ras_;
    }

    /**
     * @brief      Gets the die identifier.
     *
     * @return     The die identifier.
     */
    uint32_t get_die_id(void) {
        if (die_id_ > 1) {  // sanity check
            throw std::runtime_error("get invalid die id");
        }
        return die_id_;
    }

    /**
     * @brief      Gets the die identifier.
     *
     * @return     The die identifier.
     */
    void set_die_id(int die_x) {
        if (0 == die_x) {
            die_id_ = 0;
        } else if (1 == die_x) {
            die_id_ = 1;
        } else {
            throw std::runtime_error("set invalid die id");
        }
    }

    /**
     * @brief      Determines if master die.
     *
     * @return     True if master die, False otherwise.
     */
    bool IsMasterDie(void) {
        return (0 == die_id_);
    }

    /**
     * @brief      Determines if slave die.
     *
     * @return     True if slave die, False otherwise.
     */
    bool IsSlaveDie(void) {
        return (1 == die_id_);
    }

    /**
     * @brief      { function_description }
     */
    void Disable() {
        this->disable_ = true;
    }

    /**
     * @brief      Gets the pmc.
     *
     * @param[in]  name  The name
     *
     * @return     The pmc.
     */
    virtual Hardware *GetPmc(std::string name) {
        return nullptr;
    }

    /**
     * @brief      Gets the rmc
     *
     * @param[in]  inst  The instance
     *
     * @return     The rmc.
     */
    virtual Hardware *GetRmc(int inst) {
        return nullptr;
    }

    /**
     * @brief      { function_description }
     */
    virtual void Snapshot() {
        // do nothing by default
    }

    /**
     * @remark     you can get hw what you want by
     *             root->Get("pcie_sys")->Get("vm_sys")
     *
     * @brief      { function_description }
     *
     * @param[in]  name  The name
     * @param[in]  inst  The instance
     *
     * @return     { description_of_the_return_value }
     */
    Hardware *Get(std::string name, int inst = 0);

    /**
     * @brief      Saves a register.
     */
    virtual void SaveReg();

    /**
     * @brief      { function_description }
     */
    virtual void Restore();

    static int s_hw_obj_cnt;

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint64_t offset);

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint64_t RegRead64(uint64_t offset);

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     * @param[in]  val     The value
     */
    virtual void RegWrite(uint64_t offset, uint32_t val);

    /**
     * @berif      used by Task, return non-zero means fail
     *
     * @param[in]  task_id  The task identifier
     * @param      param    The parameter
     *
     * @return     { description_of_the_return_value }
     */
    virtual int Deamon(int task_id, void *param) {
        return 1;
    }

 private:
    /**
     * @brief      do software init
     */
    virtual void LibInit() {}

    /**
     * @brief      do software deinit
     */
    virtual void LibDeinit() {}

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInitMini() {
        return true;
    }

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit() {
        return true;
    }

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit() {
        return true;
    }

 protected:
    Hardware *hw_soc_ = nullptr;

    std::shared_ptr<IRas> ras_;

 private:
    ///< counter total child hw objects
    int child_cnt_ = 0;
};

using HwRegisterFunc = std::function<Hardware *(std::shared_ptr<spdlog::logger> logger)>;

struct HardwareRegistration {
    explicit HardwareRegistration(
        const std::string &chip, const std::string &registry, HwRegisterFunc register_func);
};

#define HARDWARE_REGISTRATION(chip, class_name, module_name)                            \
    static HardwareRegistration chip##module_name##class_name(                          \
        #chip, #module_name, [](std::shared_ptr<spdlog::logger> logger) -> Hardware * { \
            return new class_name(logger);                                              \
        })

Hardware *GetHardware2(const std::string &chip, const std::string &module_name,
    std::shared_ptr<spdlog::logger> logger, bool is_vf);

}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_HARDWARE_H_
