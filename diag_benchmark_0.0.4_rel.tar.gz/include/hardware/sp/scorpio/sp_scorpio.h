/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_SP_SCORPIO_SP_SCORPIO_H_
#define HARDWARE_SP_SCORPIO_SP_SCORPIO_H_

#include <map>
#include <memory>
#include <string>
#include <tuple>
#include <utility>
#include <vector>
#include "device/dtus/scorpio/data_fabric.h"
#include "device/include/dtu.h"
#include "framework/include/mem.h"
#include "hardware/include/sp/sp.h"
#include "hardware/sp/scorpio/amos_protocol.h"
#include "hardware/sp/scorpio/custom_mem_mgr.h"

namespace efvf {
namespace hardware {
namespace sp {

using efvf::framework::mem::Mem;
using efvf::framework::mem::MemType;
#define HI32_LO32_U64(hi, lo) ((((uint64_t)(hi)) << 32) | (lo))
#define U64_HI32(v) ((uint32_t)((v) >> 32))
#define U64_LO32(v) ((uint32_t)((v)&0xffffffffLLU))
#define SQ_ADDR_ALIGN 0x100  // 0x40
#define SQ_MAX_NUM 128
#define HQS_TOTAL_NUM 128
#define HDR_ATG_MODULE_NUM 4
#define HDR_ATG_ENTRY_NUM 128
#define HDR_ATG_ENTRY_GROUP_SIZE 32
#define HWS_MODULE_NUM HDR_ATG_MODULE_NUM
#define HRM_MODULE_NUM 6
#define HWS_SIP_DPE_ENTRY_SIZE 0x80
#define HWS_SIP_DPE_PRE_DEFINED_SIZE 4  // can assign 4 dpe in Task Descriptor
#define HWS_SIP_TASK_SLOT_NUM 20
#define HWS_SIP_DPE_GROUP_SIZE 16  // max 8 dpe in each atg_grp, and ping-pong
#define HWS_SIP_DPE_TOTAL 256      // 4 hws share all dpe
#define VC_TOTAL_NUM 16
#define CMDQ_TOTAL_NUM 16
#define CMDQ_RESERVED_NUM (HWS_MODULE_NUM * 2)
#define SQ_NAKED_MAX_NUM HQS_TOTAL_NUM
#define SQ_LOCAL_SIZE 0x200
#define SQ_NAKED_HOST_SIZE 0x100000   // Host SQ size
#define SQ_NAKED_LOCAL_SIZE 0x400     // Local SQ size in share mem
#define SQ_NAKED_CMD_BUF_SIZE 0x2000  // Cmd Buf size for CmdQ in share mem
#define SQ_NAKED_CMD_BUF_NUM 16       // Cmd Buf num for CmdQ in share mem
#define SQ_NAKED_TDP_BUF_SIZE 0x100
#define SQ_NAKED_TEMPLATE_BUF_SIZE 0x10000
#define SQ_NAKED_SMEM_RESV_BASE 0x70000
#define SP_LOCAL_SMEM_BASE 0x800000
#define SP_LOCAL_SMEM_SIZE 0x80000
#define SP_WRITE_SMEM_SPLIT_SIZE 0x800
/* NEED Release mcu soft-reset signal before access L1/L2 in mcu.
 * Need more config to access all space of L2,
 * http://wiki.enflame.cn/pages/viewpage.action?pageId=114668612 */
#define SP_L2_ZERO_DEV_BASE 0xA0000000
#define SP_L2_ZERO_DEV_SIZE (32 * 32 * 1024)  // 0x8000
#define SP_L1_ZERO_DEV_BASE 0xA0800000
#define SP_L1_ZERO_DEV_SIZE (6 * 64 * 1024)
#define SP_L2_REG_BASE_ADDR 0xA2010000
#define SP_L2_REG_BASE_SIZE 0x4000
#define SP_MCP_ADDR_ALIGN 0x40
#define SP_MCU_NUM 0x6
/* Layout in sp share mem
 * Address       | Size           | Desc
 * 0x0           | 0x400*128=128K | SQ[0~127]
 * 0x20000=128K  | 0x100*128=32K  | TDP[0~127] for ATG/HDR Module[0]
 * 0x28000=160K  | 0x100*128=32K  | TDP[0~127] for ATG/HDR Module[1]
 * 0x30000=192K  | 0x100*128=32K  | TDP[0~127] for ATG/HDR Module[2]
 * 0x38000=224K  | 0x100*128=32K  | TDP[0~127] for ATG/HDR Module[3]
 * 0x40000=256K  | 0x2000*16=128K | CmdBuf[0~15] for MCP in CmdQ
 * 0x60000=384K  | 0x10000=64K    | Template descriptor
 * 0x70000=448K  | 0x10000=64K    | Reserved
*/

// #define HOST_QUEUE_MEM_TYPE MemType::MEM_TYPE_DMEM
#define HOST_QUEUE_MEM_TYPE MemType::MEM_TYPE_HOST
#define SWITCH_TO_LOCAL_VIEW(addr) (addr >= 0x2800000 ? addr - 0x800000 : addr)
#define UseCustomMemMgr 1
template <uint32_t  TOTAL>
class SpResourceMgr final {
 public:
    SpResourceMgr();
    ~SpResourceMgr() {}
#define InvalidSpResId 0x0badbeef
    uint32_t Acquire(bool preempt = false, uint32_t nested_id = TOTAL);
    void Release(uint32_t id, uint32_t nested_id = TOTAL);
    bool QueryPreempt(uint32_t id);
    void SetActiveNum(uint32_t num);
    uint32_t GetActiveNum();

 private:
    std::mutex         m_lock;
    std::bitset<TOTAL> flag;
    uint32_t           start_idx;
    uint32_t           valid_num;
    std::array<std::atomic<bool>, TOTAL> preempted_flag;
    std::array<std::atomic<bool>, TOTAL> exclusive_flag;
};
using SpScorpioHQSMgr     = SpResourceMgr<HQS_TOTAL_NUM>;
using SpScorpioVCMgr      = SpResourceMgr<VC_TOTAL_NUM>;
using SpScorpioCmdQueMgr  = SpResourceMgr<CMDQ_TOTAL_NUM - CMDQ_RESERVED_NUM>;
using SpScorpioCmdBufMgr  = SpResourceMgr<SQ_NAKED_CMD_BUF_NUM>;
using SpScorpioTaskGrpMgr = SpResourceMgr<HDR_ATG_ENTRY_NUM / HDR_ATG_ENTRY_GROUP_SIZE>;
using SpScorpioSipDpeMgr  = SpResourceMgr<HWS_SIP_DPE_TOTAL / HWS_SIP_DPE_GROUP_SIZE>;

class SpScorpio : public Sp {
 public:
    SpScorpio() = delete;
    explicit SpScorpio(std::shared_ptr<spdlog::logger> logger);
    virtual ~SpScorpio();
    void SetHqsActiveNum(uint32_t active_num) override;
    bool SetFirmwareAlive(bool alive) override;
    bool SetBlcgCtrl(bool cg) override;
    void HardwareSchedulerEnable(bool enable, uint32_t vf_num) override;
    void SmemParityEnable(bool enable) override;
    void SmemParityInj(bool inj) override;
    void SmemParitySts(bool &err) override;
    Mdma *GetMdma() override;
    Ih *  GetMih() override;
    /**
     * @brief   get sp df master bpm
     *
     * @return  sp bpm or nullptr
     */
    Bpm *GetDfMasterBpm() override;

    /**
     * @brief   get sp df slave bpm
     *
     * @return  sp bpm or nullptr
     */
    Bpm *GetDfSlaveBpm() override;

    /**
     * @brief   get sp gsync
     *
     * @return  sp gsync or nullptr
     */
    Gsync *GetGsync() override;
    bool GetSpShareAvlMem(uint64_t &mem_start_addr, uint32_t &mem_size) override;
    bool GetSpShareAllMem(uint64_t &mem_start_addr, uint32_t &mem_size) override;
    bool GetSpMcuL1AvlMem(uint64_t &mem_start_addr, uint32_t &mem_size) override;
    bool GetSpMcuL2AvlMem(uint64_t &mem_start_addr, uint32_t &mem_size) override;
    SystemAdapter *GetSa() override;
    Pmc *          GetPmc() override;
    bool GetSpIdleReg(std::vector<std::pair<uint64_t, uint32_t>> &idle_reg) override;
    uint32_t GetSlaverDieCfOffset() override;
    uint32_t GetSlaverDieDfOffset() override;
    uint64_t GetOtherIpTestReg(const std::string &ip) override;
    std::pair<uint64_t, uint32_t> ConfigEcfSlaverRemap(SpEcfRemapType type,
        uint64_t expected_mem_offset, uint32_t expected_mem_size) override;
    bool GetHardwareSchedulerConfig(_SpTaskEngType type,
        std::vector<std::vector<std::tuple<uint32_t, uint32_t, uint32_t>>> &hws_cfg) override;
    bool FlushAxiConfig(uint64_t axi_axuser, uint32_t axi_axcache) override;
    Hardware *GetHws(uint32_t id) {
        return m_hws[id % m_hws.size()];
    }
    Hardware *GetHdr(uint32_t id) {
        return m_hdr[id % m_hdr.size()];
    }
    Hardware *GetAtg(uint32_t id) {
        return m_atg[id % m_atg.size()];
    }
    Hardware *GetHrm(uint32_t id, uint32_t subid) {
        return m_hrm[id % m_hrm.size()][subid % m_hrm[0].size()];
    }
    SpScorpioHQSMgr *GetHqsMgr() {
        return m_hqs_mgr.get();
    }
    SpScorpioVCMgr *GetVcMgr() {
        return m_vc_mgr.get();
    }
    SpScorpioCmdQueMgr *GetCmdQueMgr() {
        return m_cmd_que_mgr.get();
    }
    SpScorpioCmdBufMgr *GetCmdBufMgr() {
        return m_cmd_buf_mgr.get();
    }
    SpScorpioTaskGrpMgr *GetTaskGrpMgr(uint32_t id) {
        return m_task_grp_mgr[id % m_task_grp_mgr.size()].get();
    }
    SpScorpioSipDpeMgr *GetSipDpeMgr() {
        return m_sip_dpe_mgr.get();
    }
#if UseCustomMemMgr
    CustomMemMgr *GetCustomMemMgr() {
        return m_sq_mem_mgr.get();
    }
    Mem *GetSqMem() {
        return m_sq_mem.get();
    }
#endif

 private:
    bool     HwInit() override;
    bool     HwDeinit() override;
    bool     m_hws_enable{true};
    uint32_t m_vf_total_num{0};
    std::array<Hardware *, HWS_MODULE_NUM>     m_hws{};
    std::array<Hardware *, HDR_ATG_MODULE_NUM> m_hdr{};
    std::array<Hardware *, HDR_ATG_MODULE_NUM> m_atg{};
    std::array<std::array<Hardware *, HRM_MODULE_NUM>, HWS_MODULE_NUM> m_hrm{};
    std::unique_ptr<SpScorpioHQSMgr>    m_hqs_mgr;
    std::unique_ptr<SpScorpioVCMgr>     m_vc_mgr;
    std::unique_ptr<SpScorpioCmdQueMgr> m_cmd_que_mgr;
    std::unique_ptr<SpScorpioCmdBufMgr> m_cmd_buf_mgr;
    std::array<std::unique_ptr<SpScorpioTaskGrpMgr>, HDR_ATG_MODULE_NUM> m_task_grp_mgr;
    std::unique_ptr<SpScorpioSipDpeMgr> m_sip_dpe_mgr;
#if UseCustomMemMgr
    std::unique_ptr<Mem>          m_sq_mem;
    std::unique_ptr<CustomMemMgr> m_sq_mem_mgr;
#endif
    std::map<uint32_t, std::tuple<uint32_t, uint32_t, uint32_t, uint32_t>>
        m_mcu_fport_remap_scene;
};

/* SQ is thread unsafe due to fench of WriteMem.
*  Ensure: A thread has a SQ all of itself.
*/
struct ScorpioSQ : public SubmitQueue {
    ScorpioSQ() = delete;
    explicit ScorpioSQ(Hardware *hqs) : SubmitQueue(), m_hqs(hqs) {}
    virtual ~ScorpioSQ() {}
    bool Init() override;
    bool Emit(bool preempt, bool pending) override;
    bool WriteRegs(const SpWriteRegsParam &param, bool, bool) override;
    bool FillMemory(const SpFillMemParam &param, bool, bool) override;

 protected:  // "protected" for LibraSQ override Init()
    bool PushCmd(uint32_t *cmd, uint32_t len);
    uint32_t *           m_buf{nullptr};
    uint32_t             m_buf_dw_max{0};
    uint32_t             m_wptr{0};
    uint32_t             m_rptr{0};
    std::unique_ptr<Mem> m_buf_mem;
    std::unique_ptr<Mem> m_fench_mem;
    uint32_t *           m_fench{nullptr};
    Hardware *           m_hqs;
};

struct ScorpioNakedSQ : public SubmitQueue {
    ScorpioNakedSQ() = delete;
    ScorpioNakedSQ(uint32_t id, SpScorpio *sp) : SubmitQueue(), m_id(id), m_sp(sp) {
        m_hws_module_id = id % HWS_MODULE_NUM;
        m_hqs_mgr       = sp->GetHqsMgr();
        m_vc_mgr        = sp->GetVcMgr();
        m_cmd_que_mgr   = sp->GetCmdQueMgr();
        m_cmd_buf_mgr   = sp->GetCmdBufMgr();
        m_task_grp_mgr  = sp->GetTaskGrpMgr(m_hws_module_id);
        m_sip_dpe_mgr   = sp->GetSipDpeMgr();
        m_hws           = sp->GetHws(m_hws_module_id);
        m_hdr           = sp->GetHdr(m_hws_module_id);
        m_atg           = sp->GetAtg(m_hws_module_id);
        for (uint32_t i = 0; i < m_hrm.size(); ++i) {
            m_hrm[i] = sp->GetHrm(m_hws_module_id, i);
        }
        m_context_id = m_hws_module_id;
    }
    virtual ~ScorpioNakedSQ() {}
    void ResetQueue(bool host_queue, bool sp_queue) override;
    bool Init() override;
    bool Emit(bool preempt, bool pending) override;
    bool AsyncCmdListBegin() override;
    bool AsyncCmdListEnd() override;
    bool RandomPattern(bool echo) override;
    bool MemCopy(
        uint64_t src_addr, uint64_t dst_addr, uint32_t size, bool fence, bool block) override;
    bool DumpShareMem(uint64_t dst_addr, uint32_t src_offset, uint32_t size, bool fence,
        bool block) override;
    bool WriteShareMem(uint64_t src_addr, uint32_t dst_offset, uint32_t size, bool fence,
        bool block) override;
    bool DumpMcuL2Mem(uint64_t dst_addr, uint32_t src_offset, uint32_t size, bool fence,
        bool block) override;
    bool WriteMcuL2Mem(uint64_t src_addr, uint32_t dst_offset, uint32_t size, bool fence,
        bool block) override;
    bool DumpMcuL1Mem(uint64_t dst_addr, uint32_t src_offset, uint32_t size, bool fence,
        bool block) override;
    bool WriteMcuL1Mem(uint64_t src_addr, uint32_t dst_offset, uint32_t size, bool fence,
        bool block) override;
    bool EnableMcuL2Mem() override;
    bool GetSpMcuL2RegSpace(uint64_t &reg_start_addr, uint32_t &reg_size) override;
    bool FillMemory(const SpFillMemParam &param, bool fence, bool block) override;
    bool WriteRegs(const SpWriteRegsParam &param, bool fence, bool block) override;
    bool ReadRegs(const SpReadRegsParam &param, bool fence, bool block) override;
    bool WriteMem(const SpWriteMemParam &param, bool fence, bool block) override;
    bool ReadMem(const SpReadMemParam &param, bool fence, bool block) override;
    bool FakeWriteForPrefetch(uint64_t dst_addr, std::string desc_info) override;
    bool DteTask(const SpDteTaskParam &param) override;
    bool SipTask(const SpSipTaskParam &param) override;

 private:
    void SetQueueSize(uint32_t host_size, uint32_t sp_size) override;

 protected:
#define DUMP_SHARE_MEM_TO_HOST() LinearCopy(0x800000, 0x4020000000, 0x80000)
    struct hqs_config_param {
        uint64_t src_base;
        uint32_t src_size;
        uint32_t src_wptr;
        uint32_t src_rptr;
        uint64_t dst_base;
        uint32_t dst_size;
        uint32_t dst_wptr;
        uint32_t dst_rptr;
        uint64_t sig0_addr;
        uint32_t sig0_data;
        uint64_t sig1_addr;
        uint32_t sig1_data;
    };
    enum sp_pkt_type {
        sp_pkt_type_discard = 0,
        sp_pkt_type_echo,
        sp_pkt_type_mem_const_fill,
        sp_pkt_type_mem_copy,
        sp_pkt_type_scatter,
        sp_pkt_type_scatter_derived,
        sp_pkt_type_gather,
        sp_pkt_type_async_cmd_list,
        sp_pkt_type_dte_task,
        sp_pkt_type_sip_task,
        sp_pkt_type_async_task_group,
        sp_pkt_type_invalid
    };
    enum sp_cmd_err_type {
        sp_cmd_err_type_unsupport = 0,
        sp_cmd_err_type_mismatch,
        sp_cmd_err_type_no_hqs,
        sp_cmd_err_type_invalid
    };
    struct sp_tdp_dte_header {
        uint32_t mcp;
        uint32_t lsca;
        uint32_t id{0};
        uint32_t rsvd{0};
    };
    struct sp_tdp_sip_header {
        uint32_t prepare_mcp_fence : 1;
        uint32_t prepare_mcp_dep : 1;
        uint32_t prepare_mcp : 23;
        uint32_t enable_prepare_mcp : 1;
        uint32_t reserved_0 : 6;
        uint32_t launch_mcp_fence : 1;
        uint32_t launch_mcp_dep : 1;
        uint32_t launch_mcp : 24;
        uint32_t reserved_1 : 6;
        uint32_t task_id;
        uint32_t reserved_2;
        uint32_t affinity_sip_mask;
        uint32_t kernel_offline_priority;
        uint32_t kernel_dag_tag : 16;
        uint32_t start_block_id : 16;
        uint32_t block_dim_x : 16;
        uint32_t grid_dim_x : 16;
        uint32_t kernel_estimated_execution_time;
        uint32_t kernel_offline_priority_reciprocal;
        uint8_t  dynamic_param_entry_idx[4];
        uint32_t cluster_idx_0 : 4;
        uint32_t cluster_idx_1 : 4;
        uint32_t cluster_idx_2 : 4;
        uint32_t cluster_idx_3 : 4;
        uint32_t dynamic_param_entry_idx_valid : 4;
        uint32_t kernel_on_critical_path : 1;
        uint32_t cooperative_kernel : 1;
        uint32_t reserved_3 : 10;
        uint32_t template_desc_addr_for_sip_launch;
        uint32_t reserved_4[3];
    };
    virtual bool PushCmd(uint32_t *cmd, uint32_t len);
    virtual void ConfigHQS(Hardware *hqs, const struct hqs_config_param &);
    virtual bool DealCmd(uint32_t *cmd);
    virtual bool     InitAllTemplateDesc();
    virtual uint32_t ReGroupCmds();
    virtual bool LinearCopy(uint64_t src, uint64_t dst, uint32_t size, bool block = true);
    virtual bool LinearCopyViaHqs(uint64_t src, uint64_t dst, uint32_t size);
    virtual bool Scatter(const SpWriteRegsParam &param, bool fence, bool block, bool templat,
        std::vector<uint64_t> &dynamic_sr_addr);
    virtual bool AsyncCmdListAddLcCmd(uint64_t, uint64_t, uint32_t, bool, bool = false);
    virtual bool AsyncCmdListAddScCmd(std::vector<std::pair<uint64_t, uint32_t>> &, uint64_t,
        std::vector<bool> &, bool, bool = false);
    virtual bool AsyncCmdListAddDScCmd(std::vector<std::pair<uint64_t, uint32_t>> &,
        std::vector<bool> &, std::vector<uint32_t> &, uint64_t, std::vector<bool> &, bool,
        bool = false);
    virtual bool BuildTdpDte(const SpDteTaskParam &, uint32_t *, uint32_t &);
    virtual bool BuildTdpSip(const SpSipTaskParam &, uint32_t *, uint32_t &);
#define CHECK_IS_ASYNC_CMD_LIST_OVERFLOW(append_desc, append_cmd)               \
    do {                                                                        \
        if (m_async_buf_desc_ptr + (append_desc) > m_async_buf_size / 2 ||      \
            m_async_buf_cmd_ptr + (append_cmd) > m_async_buf_size ||            \
            m_async_buf_desc_ptr + m_async_buf_cmd_ptr - m_async_buf_size / 2 + \
                    (append_cmd) + (append_desc) + SP_MCP_ADDR_ALIGN >          \
                SQ_NAKED_CMD_BUF_SIZE) {                                        \
            LOG_ERROR("Async cmd buf overflow!!!");                             \
            return false;                                                       \
        }                                                                       \
    } while (0)
    uint32_t             m_id;
    uint32_t             m_pkt_unit_size{0};  // each cmd in SQ will always occupy a fixed size
    SpScorpioHQSMgr *    m_hqs_mgr;
    SpScorpioVCMgr *     m_vc_mgr;
    SpScorpioCmdQueMgr * m_cmd_que_mgr;
    SpScorpioCmdBufMgr * m_cmd_buf_mgr;
    SpScorpioTaskGrpMgr *m_task_grp_mgr;
    SpScorpioSipDpeMgr * m_sip_dpe_mgr;
    SpScorpio *          m_sp;
    Mdma *               m_mdma{nullptr};
    Hardware *           m_mdma_common{nullptr};
    uint32_t             m_hws_module_id;
    uint32_t             m_context_id;
    uint32_t             m_cmd_buf_base_addr{0};
    uint32_t             m_tdp_buf_base_addr{0};
    uint32_t             m_template_desc_base_addr{0};
    /* dynamic resource */
    Hardware *m_hqs{nullptr};
    uint32_t  m_hqs_id{0};
    uint32_t  m_echo_hqs_id{0};
    uint32_t  m_cmd_err_code{0};
    uint32_t  m_cmd_buf_idx{0};
    uint32_t  m_cmd_buf_addr{0};
    bool      m_in_async_cmd_list{false};
#define IS_IN_ASYNC_CMD_LIST() (m_in_async_cmd_list)
#define CHECK_IS_IN_ASYNC_CMD_LIST()                                      \
    do {                                                                  \
        if (IS_IN_ASYNC_CMD_LIST()) {                                     \
            LOG_ERROR("This cmd is not supported in async cmd queue!!!"); \
            return false;                                                 \
        }                                                                 \
    } while (0)
    uint32_t m_cmd_que_idx{InvalidSpResId};
    // Hardware * m_queue;
    uint32_t m_vc_idx{InvalidSpResId};
    // Hardware * m_vc;
    Hardware *m_hws;
    Hardware *m_hdr;
    Hardware *m_atg;
    std::array<Hardware *, HRM_MODULE_NUM> m_hrm{};
    uint32_t m_task_grp_idx{InvalidSpResId};
    uint32_t m_sip_dpe_grp_idx{InvalidSpResId};
    uint32_t m_template_addr_cfg_atg{0};
    uint32_t m_template_size_cfg_atg{0};
    uint32_t m_template_addr_cfg_hdr_pre{0};
    uint32_t m_template_size_cfg_hdr_pre{0};
    uint32_t m_template_addr_cfg_hdr{0};
    uint32_t m_template_size_cfg_hdr{0};
    uint32_t m_template_addr_odte_lc{0};
    uint32_t m_template_size_odte_lc{0};
    uint32_t m_template_addr_odte_slice{0};
    uint32_t m_template_size_odte_slice{0};
    uint32_t m_template_addr_odte_deslice{0};
    uint32_t m_template_size_odte_deslice{0};
    uint32_t m_template_addr_cdte_lc{0};
    uint32_t m_template_size_cdte_lc{0};
    uint32_t m_template_addr_cdte_slice{0};
    uint32_t m_template_size_cdte_slice{0};
    uint32_t m_template_addr_cdte_deslice{0};
    uint32_t m_template_size_cdte_deslice{0};
    uint32_t m_template_addr_sip_launch_cmd{0};
    uint32_t m_template_size_sip_launch_cmd{0};
    uint32_t m_template_size_sip_launch_cmd_per{0};
    uint32_t m_template_addr_sip_trig_generic{0};
    uint32_t m_template_size_sip_trig_generic{0};
    uint32_t m_template_addr_sip_dpe{0};
    uint32_t m_template_size_sip_dpe{0};
#define TASK_TYPE_2_HWS_RES_TYPE(engine, mask) \
    ((engine) == sp_task_engine_odte           \
            ? ((mask) == 0b10 ? 3 : 2)         \
            : ((engine) == sp_task_engine_cdte ? ((mask) == 0b10 ? 5 : 4) : (7)))
/* Alloc mem for remote/local SQ */
#if UseCustomMemMgr
    std::unique_ptr<CustomMemBlock> m_host_sq_mem;
#else
    std::unique_ptr<Mem> m_host_sq_mem;
#endif
    uint64_t  m_host_sq_phy_addr{0};
    uint32_t *m_host_sq_vir_addr{nullptr};
    uint32_t  m_host_sq_size{0};
    uint32_t  m_host_sq_wptr{0};
    uint32_t  m_host_sq_rptr{0};
#if UseCustomMemMgr
    std::unique_ptr<CustomMemBlock> m_sp_sq_mem;
#else
    std::unique_ptr<Mem> m_sp_sq_mem;
#endif
    uint64_t  m_sp_sq_phy_addr{0};
    uint32_t *m_sp_sq_vir_addr{nullptr};
    uint64_t  m_sp_sq_addr{0};
    uint32_t  m_sp_sq_size{0};
    uint32_t  m_sp_sq_wptr{0};
    uint32_t  m_sp_sq_rptr{0};
/* Note: CQ is only for pkt echo. Not real CQ for recving msg from SP. */
#if UseCustomMemMgr
    std::unique_ptr<CustomMemBlock> m_host_cq_mem;
#else
    std::unique_ptr<Mem> m_host_cq_mem;
#endif
    uint64_t  m_host_cq_phy_addr{0};
    uint32_t *m_host_cq_vir_addr{nullptr};
    uint32_t  m_host_cq_size{0};
    uint32_t  m_host_cq_wptr{0};
    uint32_t  m_host_cq_rptr{0};
    /* Note: CQ will reuse SQ mem for pkt echo. */
    uint64_t m_sp_cq_addr{0};
    uint32_t m_sp_cq_size{0};
    uint32_t m_sp_cq_wptr{0};
    uint32_t m_sp_cq_rptr{0};
/* All flags for sync */
#define SQ_PKT_DONE_FLAG_SIG_ADDR (m_sq_pkt_done_flag_phy_addr)
#define SQ_PKT_DONE_FLAG_SIG_DATA (0x89abcdef)
#define SQ_PKT_DONE_FLAG_CLEAR()          \
    do {                                  \
        *m_sq_pkt_done_flag_vir_addr = 0; \
    } while (0)
#define SQ_PKT_DONE_FLAG_IS_SET() (*m_sq_pkt_done_flag_vir_addr == SQ_PKT_DONE_FLAG_SIG_DATA)
#define SQ_PKT_DONE_FLAG_WAIT(ret, fence)                                        \
    do {                                                                         \
        uint32_t loop_cnt = 0;                                                   \
        while ((ret) && !SQ_PKT_DONE_FLAG_IS_SET()) {                            \
            if (fence) {                                                         \
                (ret) = false;                                                   \
                LOG_ERROR("Should not be here with FENCE enabled!!!");           \
            } else {                                                             \
                loop_cnt += 1;                                                   \
            }                                                                    \
        }                                                                        \
        if (!(fence)) {                                                          \
            LOG_TRACE("loop cnt for checking done without fence: {}", loop_cnt); \
        }                                                                        \
    } while (0)
#if UseCustomMemMgr
    std::unique_ptr<CustomMemBlock> m_host_flag_mem;
#else
    std::unique_ptr<Mem> m_host_flag_mem;
#endif
    uint64_t  m_sq_sync_src_rptr_phy_addr{0};
    uint64_t  m_sq_sync_dst_wptr_phy_addr{0};
    uint64_t  m_cq_sync_src_rptr_phy_addr{0};
    uint64_t  m_cq_sync_dst_wptr_phy_addr{0};
    uint64_t  m_sq_pkt_done_flag_phy_addr{0};
    uint64_t  m_atg_done_flag_0_phy_addr{0};
    uint64_t  m_atg_done_flag_1_phy_addr{0};
    uint32_t *m_sq_sync_src_rptr_vir_addr{nullptr};
    uint32_t *m_sq_sync_dst_wptr_vir_addr{nullptr};
    uint32_t *m_cq_sync_src_rptr_vir_addr{nullptr};
    uint32_t *m_cq_sync_dst_wptr_vir_addr{nullptr};
    uint32_t *m_sq_pkt_done_flag_vir_addr{nullptr};
    uint32_t *m_atg_done_flag_0_vir_addr{nullptr};
    uint32_t *m_atg_done_flag_1_vir_addr{nullptr};
/* Alloc async cmd list buffer in host */
#if UseCustomMemMgr
    std::unique_ptr<CustomMemBlock> m_async_buf_mem;
#else
    std::unique_ptr<Mem> m_async_buf_mem;
#endif
    uint64_t  m_async_buf_phy_addr{0};
    uint32_t *m_async_buf_vir_addr{nullptr};
    uint32_t  m_async_buf_size{0};
    uint32_t  m_async_buf_desc_ptr{0};
    uint32_t  m_async_buf_cmd_ptr{0};
/* Alloc async task desc (TDP&CMD) buffer in host */
#if UseCustomMemMgr
    std::unique_ptr<CustomMemBlock> m_atg_tdp_cmd_buf_mem;
#else
    std::unique_ptr<Mem> m_atg_tdp_cmd_buf_mem;
#endif
    uint64_t  m_atg_tdp_cmd_buf_phy_addr{0};
    uint32_t *m_atg_tdp_cmd_buf_vir_addr{nullptr};
    uint32_t  m_atg_tdp_cmd_buf_size{0};
    uint32_t  m_atg_tdp_cmd_buf_wptr{0};
    uint32_t  m_atg_tdp_cmd_buf_rptr{0};
    uint32_t  m_atg_sequence_id{0};
    uint32_t  m_atg_task_id_in_grp{0};
    uint64_t  m_atg_sip_dpe_buf_phy_addr{0};
    uint32_t *m_atg_sip_dpe_buf_vir_addr{nullptr};
    uint32_t  m_atg_sip_dpe_buf_size{0};
    uint32_t  m_atg_sip_dpe_buf_id{0};
    uint32_t  m_atg_sip_dpe_buf_id_in_grp{0};
};

}  // namespace sp
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SP_SCORPIO_SP_SCORPIO_H_
