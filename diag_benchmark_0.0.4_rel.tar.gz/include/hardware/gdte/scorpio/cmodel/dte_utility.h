#ifndef _C_MODEL_UTILS_H_
#define _C_MODEL_UTILS_H_

#include <iostream>
#include "log_interface.h"
#include "common_defines.h"
#include <string.h>
#include <fstream>
#include <utility>
#include <map>
#include <vector>
#include <stdexcept>
#include <arpa/inet.h>

typedef struct data_describe {
    uint32_t data_size = 0;
    uint32_t dim0_bytes = 0;
    uint8_t* data = NULL;
} data_desc;

typedef struct size {
    uint32_t dst_total_size =0;
} size_desc;

class array_t
{
public:
    static void shuffle(void *array, size_t n, size_t size);
    static void rand_data(uint8_t* data, uint32_t len);
    static void diff(uint8_t* exp_data, uint8_t* act_data, uint32_t len, uint8_t wrap_size = 8);
    static void display(uint8_t* data, uint32_t len);
};

class tile_t : public log_wrapper_t
{
protected:
    uint8_t* data_u8=NULL;
    uint16_t* data_u16=NULL;
    uint32_t* data_u32=NULL;

    uint8_t bpe;
    uint32_t size_dim4,size_dim3,size_dim2,size_dim1,size_dim0;

    uint32_t total_unit_size;
    uint32_t unit_dim4;
    uint32_t unit_dim3;
    uint32_t unit_dim2;
    uint32_t unit_dim1;

public:
    void init(uint8_t* data, uint8_t bpe, uint32_t size_dim4,uint32_t size_dim3,uint32_t size_dim2,uint32_t size_dim1,uint32_t size_dim0);
    void display();
    uint32_t retrieve_element(uint32_t idx_dim4,uint32_t idx_dim3,uint32_t idx_dim2,uint32_t idx_dim1,uint32_t idx_dim0);
    void fill_elements(uint32_t val, uint32_t idx, uint32_t len);
    void fill_all(uint32_t val);
    void fill_dim4(uint32_t val, uint32_t idx_dim4);
    void fill_dim3(uint32_t val, uint32_t idx_dim4, uint32_t idx_dim3);
    void fill_dim2(uint32_t val, uint32_t idx_dim4, uint32_t idx_dim3, uint32_t idx_dim2);
    void fill_dim1(uint32_t val, uint32_t idx_dim4, uint32_t idx_dim3, uint32_t idx_dim2, uint32_t idx_dim1);
    void fill_dim0(uint32_t val, uint32_t idx_dim4, uint32_t idx_dim3, uint32_t idx_dim2, uint32_t idx_dim1, uint32_t idx_dim0);
    inline uint32_t get_total_unit_size() {return total_unit_size;}
    inline uint32_t get_unit_dim4() {return unit_dim4;}
    inline uint32_t get_unit_dim3() {return unit_dim3;}
    inline uint32_t get_unit_dim2() {return unit_dim2;}
    inline uint32_t get_unit_dim1() {return unit_dim1;}
};

typedef std::pair<uint64_t, uint32_t> addr_data_pair;
typedef std::vector<addr_data_pair> addr_data_vct;
typedef std::map<uint32_t, addr_data_vct> addr_data_map;

class file_handler
{
public:
    static bool parse_data_from_str(uint8_t mode, std::string line_str, addr_data_pair &pair); // mode: 0-src data, 1-cfg data, 2-mail data
    static addr_data_vct get_data_from_file(uint8_t mode, std::string file_name);
    static addr_data_vct get_src_data_from_file(std::string file_name);
    static addr_data_vct get_cfg_data_from_file(std::string file_name);
    static addr_data_vct get_mail_data_from_file(std::string file_name);
};

typedef uint8_t mask_t[MASK_BITS/8];

typedef struct scp_describe {
    uint32_t payload_size; // hdr
    std::vector<uint8_t> sum;
    std::vector<mask_t> mask;
    std::vector<uint8_t*> nz_data;
    uint32_t bytes_size = 0;
    uint8_t* bytes = NULL;
} scp_desc;

typedef struct gscp_describe {
    uint32_t payload_size; // hdr[47:16]
    uint32_t scp_num; // hdr[15:0]
    std::vector<uint8_t*> scp;
    uint32_t bytes_size = 0;
    uint8_t* bytes = NULL;
} gscp_desc;

typedef struct gscpc_describe {
    uint32_t payload_size; // hdr[47:16]
    uint32_t scp_num; // hdr[15:0]
    std::vector<uint8_t*> gscp;
    uint32_t bytes_size = 0;
    uint8_t* bytes = NULL;
} gscpc_desc;

typedef std::vector<data_desc> data_desc_q;

class hsdc_decompressor
{
public:
    data_desc gen_scp2raw(data_desc scp);
    data_desc_q gen_gscp2scp(data_desc gscp);
    data_desc_q gen_gscpc2gscp(data_desc gscpc);
    data_desc decompress(hsdc_type_e hsdc_type, data_desc src_desc);
};

#endif
