/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_GDTE_SCORPIO_CMODEL_HSDC_H_
#define HARDWARE_GDTE_SCORPIO_CMODEL_HSDC_H_

#include <stdint.h>
#include <stdio.h>

#include "hardware/include/gdte/gdte_ctx.h"

#define GSCPC_HDR_BITS 48
#define GSCP_HDR_BITS 48
#define SCP_HDR_BITS 16
#define SUM_BITS 8
#define MASK_BITS 128
#define GSCPC_RD_MIN_SIZE 144
#define GSCP_RD_MIN_SIZE 138
#define SCP_RD_MIN_SIZE 136

namespace efvf {
namespace hardware {
namespace gdte {

/**
 * @brief      { function_description }
 *
 * @param      p     { parameter_description }
 */
void gen_raw2compress(HsdcPkt &p);

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_SCORPIO_CMODEL_HSDC_H_
