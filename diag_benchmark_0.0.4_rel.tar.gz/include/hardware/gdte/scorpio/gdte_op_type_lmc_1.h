/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_SCORPIO_GDTE_OP_TYPE_LMC_1_H_
#define HARDWARE_GDTE_SCORPIO_GDTE_OP_TYPE_LMC_1_H_

// clang-format off

#pragma pack(push, 1)
#define BRDCST_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _BRDCST_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} BRDCST_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    BRDCST_REGS_DTE_SRC_DIM0_SIZE_t f;
} BRDCST_REGS_DTE_SRC_DIM0_SIZE_u;

#define BRDCST_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _BRDCST_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} BRDCST_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    BRDCST_REGS_DTE_SRC_DIM1_SIZE_t f;
} BRDCST_REGS_DTE_SRC_DIM1_SIZE_u;

#define BRDCST_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _BRDCST_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} BRDCST_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    BRDCST_REGS_DTE_SRC_DIM2_SIZE_t f;
} BRDCST_REGS_DTE_SRC_DIM2_SIZE_u;

#define BRDCST_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _BRDCST_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} BRDCST_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    BRDCST_REGS_DTE_SRC_DIM3_SIZE_t f;
} BRDCST_REGS_DTE_SRC_DIM3_SIZE_u;

#define BRDCST_REGS_DTE_BRDCST_CTRL_OFFSET 0x006c
typedef struct _BRDCST_REGS_DTE_BRDCST_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int BRDCST_DIM:2;
    unsigned int :6;
    unsigned int BRDCST_SIZE:24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int BRDCST_SIZE:24;
    unsigned int :6;
    unsigned int BRDCST_DIM:2;
#endif
} BRDCST_REGS_DTE_BRDCST_CTRL_t;

typedef union {
    unsigned int val : 32;
    BRDCST_REGS_DTE_BRDCST_CTRL_t f;
} BRDCST_REGS_DTE_BRDCST_CTRL_u;

#define CF_REGS_DTE_CONSTANT_DATA_OFFSET 0x0058
typedef struct _CF_REGS_DTE_CONSTANT_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CONSTANT_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CONSTANT_DATA:32;
#endif
} CF_REGS_DTE_CONSTANT_DATA_t;

typedef union {
    unsigned int val : 32;
    CF_REGS_DTE_CONSTANT_DATA_t f;
} CF_REGS_DTE_CONSTANT_DATA_u;

#define CFDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x0004
typedef struct _CFDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} CFDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DSL_START_DIM3_t f;
} CFDSL_REGS_DTE_DSL_START_DIM3_u;

#define CFDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _CFDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} CFDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} CFDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define CFDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _CFDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} CFDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} CFDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define CFDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _CFDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} CFDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} CFDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define CFDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _CFDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} CFDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} CFDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define CFDSL_REGS_DTE_CONSTANT_DATA_OFFSET 0x0058
typedef struct _CFDSL_REGS_DTE_CONSTANT_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CONSTANT_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CONSTANT_DATA:32;
#endif
} CFDSL_REGS_DTE_CONSTANT_DATA_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_CONSTANT_DATA_t f;
} CFDSL_REGS_DTE_CONSTANT_DATA_u;

#define CFDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _CFDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} CFDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} CFDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define CFDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _CFDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} CFDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} CFDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define CFDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _CFDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} CFDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} CFDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define CFDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _CFDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} CFDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} CFDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define CFDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _CFDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} CFDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DSL_START_DIM0_t f;
} CFDSL_REGS_DTE_DSL_START_DIM0_u;

#define CFDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _CFDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} CFDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DSL_START_DIM1_t f;
} CFDSL_REGS_DTE_DSL_START_DIM1_u;

#define CFDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _CFDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} CFDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DSL_START_DIM2_t f;
} CFDSL_REGS_DTE_DSL_START_DIM2_u;

#define DE_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _DE_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} DE_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DE_REGS_DTE_SRC_DIM0_SIZE_t f;
} DE_REGS_DTE_SRC_DIM0_SIZE_u;

#define DE_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _DE_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} DE_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DE_REGS_DTE_SRC_DIM1_SIZE_t f;
} DE_REGS_DTE_SRC_DIM1_SIZE_u;

#define DE_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _DE_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} DE_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DE_REGS_DTE_SRC_DIM2_SIZE_t f;
} DE_REGS_DTE_SRC_DIM2_SIZE_u;

#define DE_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _DE_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} DE_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DE_REGS_DTE_SRC_DIM3_SIZE_t f;
} DE_REGS_DTE_SRC_DIM3_SIZE_u;

#define DE_REGS_DTE_EXP_CTRL_OFFSET 0x006c
typedef struct _DE_REGS_DTE_EXP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EXP_PHASE:2;
    unsigned int EXP_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int EXP_RATIO:2;
    unsigned int EXP_PHASE:2;
#endif
} DE_REGS_DTE_EXP_CTRL_t;

typedef union {
    unsigned int val : 32;
    DE_REGS_DTE_EXP_CTRL_t f;
} DE_REGS_DTE_EXP_CTRL_u;

#define DS_REGS_DTE_SHR_CTRL_OFFSET 0x0058
typedef struct _DS_REGS_DTE_SHR_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SHR_PHASE:2;
    unsigned int SHR_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int SHR_RATIO:2;
    unsigned int SHR_PHASE:2;
#endif
} DS_REGS_DTE_SHR_CTRL_t;

typedef union {
    unsigned int val : 32;
    DS_REGS_DTE_SHR_CTRL_t f;
} DS_REGS_DTE_SHR_CTRL_u;

#define DSDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x0004
typedef struct _DSDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} DSDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DSL_START_DIM3_t f;
} DSDSL_REGS_DTE_DSL_START_DIM3_u;

#define DSDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _DSDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} DSDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} DSDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define DSDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _DSDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} DSDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} DSDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define DSDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _DSDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} DSDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} DSDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define DSDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _DSDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} DSDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} DSDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define DSDSL_REGS_DTE_SHR_CTRL_OFFSET 0x0058
typedef struct _DSDSL_REGS_DTE_SHR_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SHR_PHASE:2;
    unsigned int SHR_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int SHR_RATIO:2;
    unsigned int SHR_PHASE:2;
#endif
} DSDSL_REGS_DTE_SHR_CTRL_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_SHR_CTRL_t f;
} DSDSL_REGS_DTE_SHR_CTRL_u;

#define DSDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _DSDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} DSDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} DSDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define DSDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _DSDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} DSDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} DSDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define DSDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _DSDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} DSDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} DSDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define DSDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _DSDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} DSDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} DSDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define DSDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _DSDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} DSDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DSL_START_DIM0_t f;
} DSDSL_REGS_DTE_DSL_START_DIM0_u;

#define DSDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _DSDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} DSDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DSL_START_DIM1_t f;
} DSDSL_REGS_DTE_DSL_START_DIM1_u;

#define DSDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _DSDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} DSDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DSL_START_DIM2_t f;
} DSDSL_REGS_DTE_DSL_START_DIM2_u;

#define DSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x0004
typedef struct _DSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} DSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DSL_START_DIM3_t f;
} DSL_REGS_DTE_DSL_START_DIM3_u;

#define DSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _DSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} DSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} DSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define DSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _DSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} DSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} DSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define DSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _DSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} DSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} DSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define DSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _DSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} DSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} DSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define DSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _DSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} DSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DST_DIM0_SIZE_t f;
} DSL_REGS_DTE_DST_DIM0_SIZE_u;

#define DSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _DSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} DSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DST_DIM1_SIZE_t f;
} DSL_REGS_DTE_DST_DIM1_SIZE_u;

#define DSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _DSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} DSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DST_DIM2_SIZE_t f;
} DSL_REGS_DTE_DST_DIM2_SIZE_u;

#define DSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _DSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} DSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DST_DIM3_SIZE_t f;
} DSL_REGS_DTE_DST_DIM3_SIZE_u;

#define DSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _DSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} DSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DSL_START_DIM0_t f;
} DSL_REGS_DTE_DSL_START_DIM0_u;

#define DSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _DSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} DSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DSL_START_DIM1_t f;
} DSL_REGS_DTE_DSL_START_DIM1_u;

#define DSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _DSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} DSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DSL_START_DIM2_t f;
} DSL_REGS_DTE_DSL_START_DIM2_u;

#define GS_REGS_DTE_GSYNC_CTRL_OFFSET 0x0040
typedef struct _GS_REGS_DTE_GSYNC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_MODE:1;
    unsigned int REG_ENTRY_IDX:8;
    unsigned int GSYNC_SLV_BASE_ADDR_SEL:3;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int GSYNC_SLV_BASE_ADDR_SEL:3;
    unsigned int REG_ENTRY_IDX:8;
    unsigned int GSYNC_MODE:1;
#endif
} GS_REGS_DTE_GSYNC_CTRL_t;

typedef union {
    unsigned int val : 32;
    GS_REGS_DTE_GSYNC_CTRL_t f;
} GS_REGS_DTE_GSYNC_CTRL_u;

#define GS_REGS_DTE_GSYNC_REGISTER_DATA0_OFFSET 0x0044
typedef struct _GS_REGS_DTE_GSYNC_REGISTER_DATA0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_DATA:32;
#endif
} GS_REGS_DTE_GSYNC_REGISTER_DATA0_t;

typedef union {
    unsigned int val : 32;
    GS_REGS_DTE_GSYNC_REGISTER_DATA0_t f;
} GS_REGS_DTE_GSYNC_REGISTER_DATA0_u;

#define GS_REGS_DTE_GSYNC_REGISTER_DATA1_OFFSET 0x0048
typedef struct _GS_REGS_DTE_GSYNC_REGISTER_DATA1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_ADDR:30;
    unsigned int WAIT_ENTRY_RSVD:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_RSVD:2;
    unsigned int WAIT_ENTRY_ADDR:30;
#endif
} GS_REGS_DTE_GSYNC_REGISTER_DATA1_t;

typedef union {
    unsigned int val : 32;
    GS_REGS_DTE_GSYNC_REGISTER_DATA1_t f;
} GS_REGS_DTE_GSYNC_REGISTER_DATA1_u;

#define GS_REGS_DTE_GSYNC_REGISTER_DATA2_OFFSET 0x004c
typedef struct _GS_REGS_DTE_GSYNC_REGISTER_DATA2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_WAIT:24;
    unsigned int WAIT_ENTRY_MODE:2;
    unsigned int WAIT_ENTRY_TID:6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_TID:6;
    unsigned int WAIT_ENTRY_MODE:2;
    unsigned int WAIT_ENTRY_WAIT:24;
#endif
} GS_REGS_DTE_GSYNC_REGISTER_DATA2_t;

typedef union {
    unsigned int val : 32;
    GS_REGS_DTE_GSYNC_REGISTER_DATA2_t f;
} GS_REGS_DTE_GSYNC_REGISTER_DATA2_u;

#define GS_REGS_DTE_GSYNC_SIGNAL_INFO_OFFSET 0x0050
typedef struct _GS_REGS_DTE_GSYNC_SIGNAL_INFO_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIGNAL_INFO:26;
    unsigned int SIGNAL_IDX:6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIGNAL_IDX:6;
    unsigned int SIGNAL_INFO:26;
#endif
} GS_REGS_DTE_GSYNC_SIGNAL_INFO_t;

typedef union {
    unsigned int val : 32;
    GS_REGS_DTE_GSYNC_SIGNAL_INFO_t f;
} GS_REGS_DTE_GSYNC_SIGNAL_INFO_u;

#define HMIR_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _HMIR_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} HMIR_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIR_REGS_DTE_SRC_DIM0_SIZE_t f;
} HMIR_REGS_DTE_SRC_DIM0_SIZE_u;

#define HMIR_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _HMIR_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} HMIR_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIR_REGS_DTE_SRC_DIM1_SIZE_t f;
} HMIR_REGS_DTE_SRC_DIM1_SIZE_u;

#define HMIR_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _HMIR_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} HMIR_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIR_REGS_DTE_SRC_DIM2_SIZE_t f;
} HMIR_REGS_DTE_SRC_DIM2_SIZE_u;

#define HMIR_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _HMIR_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} HMIR_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIR_REGS_DTE_SRC_DIM3_SIZE_t f;
} HMIR_REGS_DTE_SRC_DIM3_SIZE_u;

#define HMIRDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x0004
typedef struct _HMIRDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} HMIRDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DSL_START_DIM3_t f;
} HMIRDSL_REGS_DTE_DSL_START_DIM3_u;

#define HMIRDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _HMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} HMIRDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define HMIRDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _HMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} HMIRDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define HMIRDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _HMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} HMIRDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define HMIRDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _HMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} HMIRDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define HMIRDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _HMIRDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} HMIRDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define HMIRDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _HMIRDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} HMIRDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define HMIRDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _HMIRDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} HMIRDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define HMIRDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _HMIRDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} HMIRDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define HMIRDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _HMIRDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} HMIRDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DSL_START_DIM0_t f;
} HMIRDSL_REGS_DTE_DSL_START_DIM0_u;

#define HMIRDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _HMIRDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} HMIRDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DSL_START_DIM1_t f;
} HMIRDSL_REGS_DTE_DSL_START_DIM1_u;

#define HMIRDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _HMIRDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} HMIRDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DSL_START_DIM2_t f;
} HMIRDSL_REGS_DTE_DSL_START_DIM2_u;

#define HMIRPAD_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _HMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} HMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t f;
} HMIRPAD_REGS_DTE_SRC_DIM0_SIZE_u;

#define HMIRPAD_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _HMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} HMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t f;
} HMIRPAD_REGS_DTE_SRC_DIM1_SIZE_u;

#define HMIRPAD_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _HMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} HMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t f;
} HMIRPAD_REGS_DTE_SRC_DIM2_SIZE_u;

#define HMIRPAD_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _HMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} HMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t f;
} HMIRPAD_REGS_DTE_SRC_DIM3_SIZE_u;

#define HMIRPAD_REGS_DTE_PAD_VALUE_OFFSET 0x006c
typedef struct _HMIRPAD_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} HMIRPAD_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_PAD_VALUE_t f;
} HMIRPAD_REGS_DTE_PAD_VALUE_u;

#define HMIRPAD_REGS_DTE_PAD_CTRL_DIM0_OFFSET 0x0070
typedef struct _HMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM0_LOW:11;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int PAD_DIM0_LOW:11;
#endif
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t f;
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM0_u;

#define HMIRPAD_REGS_DTE_PAD_CTRL_DIM1_OFFSET 0x0074
typedef struct _HMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM1_LOW:11;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM1_INTERIOR:10;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_LOW:11;
#endif
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t f;
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM1_u;

#define HMIRPAD_REGS_DTE_PAD_CTRL_DIM2_OFFSET 0x0078
typedef struct _HMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM2_LOW:11;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM2_INTERIOR:10;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_LOW:11;
#endif
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t f;
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM2_u;

#define HMIRPAD_REGS_DTE_PAD_CTRL_DIM3_OFFSET 0x007c
typedef struct _HMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM3_LOW:11;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM3_INTERIOR:10;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_LOW:11;
#endif
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t f;
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM3_u;

#define HSDC_REGS_DTE_HSDC_CTRL_OFFSET 0x0040
typedef struct _HSDC_REGS_DTE_HSDC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int HSDC_SRC_PKT_TYPE:2;
    unsigned int HSDC_DST_PKT_TYPE:2;
    unsigned int HSDC_PARMS_SEL:2;
    unsigned int HSDC_CMP_SIZE:1;
    unsigned int :25;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :25;
    unsigned int HSDC_CMP_SIZE:1;
    unsigned int HSDC_PARMS_SEL:2;
    unsigned int HSDC_DST_PKT_TYPE:2;
    unsigned int HSDC_SRC_PKT_TYPE:2;
#endif
} HSDC_REGS_DTE_HSDC_CTRL_t;

typedef union {
    unsigned int val : 32;
    HSDC_REGS_DTE_HSDC_CTRL_t f;
} HSDC_REGS_DTE_HSDC_CTRL_u;

#define PAD_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _PAD_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} PAD_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_SRC_DIM0_SIZE_t f;
} PAD_REGS_DTE_SRC_DIM0_SIZE_u;

#define PAD_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _PAD_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} PAD_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_SRC_DIM1_SIZE_t f;
} PAD_REGS_DTE_SRC_DIM1_SIZE_u;

#define PAD_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _PAD_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} PAD_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_SRC_DIM2_SIZE_t f;
} PAD_REGS_DTE_SRC_DIM2_SIZE_u;

#define PAD_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _PAD_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} PAD_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_SRC_DIM3_SIZE_t f;
} PAD_REGS_DTE_SRC_DIM3_SIZE_u;

#define PAD_REGS_DTE_PAD_VALUE_OFFSET 0x006c
typedef struct _PAD_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} PAD_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_PAD_VALUE_t f;
} PAD_REGS_DTE_PAD_VALUE_u;

#define PAD_REGS_DTE_PAD_CTRL_DIM0_OFFSET 0x0070
typedef struct _PAD_REGS_DTE_PAD_CTRL_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM0_LOW:11;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int PAD_DIM0_LOW:11;
#endif
} PAD_REGS_DTE_PAD_CTRL_DIM0_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_PAD_CTRL_DIM0_t f;
} PAD_REGS_DTE_PAD_CTRL_DIM0_u;

#define PAD_REGS_DTE_PAD_CTRL_DIM1_OFFSET 0x0074
typedef struct _PAD_REGS_DTE_PAD_CTRL_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM1_LOW:11;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM1_INTERIOR:10;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_LOW:11;
#endif
} PAD_REGS_DTE_PAD_CTRL_DIM1_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_PAD_CTRL_DIM1_t f;
} PAD_REGS_DTE_PAD_CTRL_DIM1_u;

#define PAD_REGS_DTE_PAD_CTRL_DIM2_OFFSET 0x0078
typedef struct _PAD_REGS_DTE_PAD_CTRL_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM2_LOW:11;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM2_INTERIOR:10;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_LOW:11;
#endif
} PAD_REGS_DTE_PAD_CTRL_DIM2_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_PAD_CTRL_DIM2_t f;
} PAD_REGS_DTE_PAD_CTRL_DIM2_u;

#define PAD_REGS_DTE_PAD_CTRL_DIM3_OFFSET 0x007c
typedef struct _PAD_REGS_DTE_PAD_CTRL_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM3_LOW:11;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM3_INTERIOR:10;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_LOW:11;
#endif
} PAD_REGS_DTE_PAD_CTRL_DIM3_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_PAD_CTRL_DIM3_t f;
} PAD_REGS_DTE_PAD_CTRL_DIM3_u;

#define RSHP_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _RSHP_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} RSHP_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHP_REGS_DTE_SRC_DIM0_SIZE_t f;
} RSHP_REGS_DTE_SRC_DIM0_SIZE_u;

#define RSHP_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _RSHP_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} RSHP_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHP_REGS_DTE_SRC_DIM1_SIZE_t f;
} RSHP_REGS_DTE_SRC_DIM1_SIZE_u;

#define RSHP_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _RSHP_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} RSHP_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHP_REGS_DTE_SRC_DIM2_SIZE_t f;
} RSHP_REGS_DTE_SRC_DIM2_SIZE_u;

#define RSHP_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _RSHP_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} RSHP_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHP_REGS_DTE_SRC_DIM3_SIZE_t f;
} RSHP_REGS_DTE_SRC_DIM3_SIZE_u;

#define RSHP_REGS_DTE_RESHAPE_CTRL_OFFSET 0x006c
typedef struct _RSHP_REGS_DTE_RESHAPE_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESHAPE_DIM0_MAP:2;
    unsigned int RESHAPE_DIM1_MAP:2;
    unsigned int RESHAPE_DIM2_MAP:2;
    unsigned int RESHAPE_DIM3_MAP:2;
    unsigned int ENHANCE_RESHAPE_MODE:1;
    unsigned int :23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :23;
    unsigned int ENHANCE_RESHAPE_MODE:1;
    unsigned int RESHAPE_DIM3_MAP:2;
    unsigned int RESHAPE_DIM2_MAP:2;
    unsigned int RESHAPE_DIM1_MAP:2;
    unsigned int RESHAPE_DIM0_MAP:2;
#endif
} RSHP_REGS_DTE_RESHAPE_CTRL_t;

typedef union {
    unsigned int val : 32;
    RSHP_REGS_DTE_RESHAPE_CTRL_t f;
} RSHP_REGS_DTE_RESHAPE_CTRL_u;

#define RSHPDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x0004
typedef struct _RSHPDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} RSHPDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DSL_START_DIM3_t f;
} RSHPDSL_REGS_DTE_DSL_START_DIM3_u;

#define RSHPDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _RSHPDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} RSHPDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define RSHPDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _RSHPDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} RSHPDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define RSHPDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _RSHPDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} RSHPDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define RSHPDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _RSHPDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} RSHPDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define RSHPDSL_REGS_DTE_RESHAPE_DSL_CTRL_OFFSET 0x0058
typedef struct _RSHPDSL_REGS_DTE_RESHAPE_DSL_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESHAPE_DSL_DIM0_MAP:2;
    unsigned int RESHAPE_DSL_DIM1_MAP:2;
    unsigned int RESHAPE_DSL_DIM2_MAP:2;
    unsigned int RESHAPE_DSL_DIM3_MAP:2;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int RESHAPE_DSL_DIM3_MAP:2;
    unsigned int RESHAPE_DSL_DIM2_MAP:2;
    unsigned int RESHAPE_DSL_DIM1_MAP:2;
    unsigned int RESHAPE_DSL_DIM0_MAP:2;
#endif
} RSHPDSL_REGS_DTE_RESHAPE_DSL_CTRL_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_RESHAPE_DSL_CTRL_t f;
} RSHPDSL_REGS_DTE_RESHAPE_DSL_CTRL_u;

#define RSHPDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _RSHPDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} RSHPDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define RSHPDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _RSHPDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} RSHPDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define RSHPDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _RSHPDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} RSHPDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define RSHPDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _RSHPDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} RSHPDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define RSHPDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _RSHPDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} RSHPDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DSL_START_DIM0_t f;
} RSHPDSL_REGS_DTE_DSL_START_DIM0_u;

#define RSHPDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _RSHPDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} RSHPDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DSL_START_DIM1_t f;
} RSHPDSL_REGS_DTE_DSL_START_DIM1_u;

#define RSHPDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _RSHPDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} RSHPDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DSL_START_DIM2_t f;
} RSHPDSL_REGS_DTE_DSL_START_DIM2_u;

#define SLC_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0000
typedef struct _SLC_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int SLICE_DIM3_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM3_START_DIR:1;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLC_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_START_DIM3_t f;
} SLC_REGS_DTE_SLICE_START_DIM3_u;

#define SLC_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLC_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLC_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLC_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLC_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLC_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLC_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLC_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLC_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLC_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLC_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLC_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLC_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLC_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLC_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLC_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLC_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLC_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLC_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLC_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLC_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLC_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLC_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLC_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLC_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLC_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLC_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLC_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLC_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLC_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLC_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLC_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLC_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLC_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int SLICE_DIM0_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM0_START_DIR:1;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLC_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_START_DIM0_t f;
} SLC_REGS_DTE_SLICE_START_DIM0_u;

#define SLC_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLC_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int SLICE_DIM1_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM1_START_DIR:1;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLC_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_START_DIM1_t f;
} SLC_REGS_DTE_SLICE_START_DIM1_u;

#define SLC_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLC_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int SLICE_DIM2_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM2_START_DIR:1;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLC_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_START_DIM2_t f;
} SLC_REGS_DTE_SLICE_START_DIM2_u;

#define SLC_REGS_DTE_PAD_VALUE_OFFSET 0x006c
typedef struct _SLC_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} SLC_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_PAD_VALUE_t f;
} SLC_REGS_DTE_PAD_VALUE_u;

#define SLCBRDCST_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0000
typedef struct _SLCBRDCST_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_START_DIM3_t f;
} SLCBRDCST_REGS_DTE_SLICE_START_DIM3_u;

#define SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLCBRDCST_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLCBRDCST_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLCBRDCST_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLCBRDCST_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLCBRDCST_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLCBRDCST_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLCBRDCST_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLCBRDCST_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLCBRDCST_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLCBRDCST_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLCBRDCST_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLCBRDCST_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLCBRDCST_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLCBRDCST_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_START_DIM0_t f;
} SLCBRDCST_REGS_DTE_SLICE_START_DIM0_u;

#define SLCBRDCST_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLCBRDCST_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_START_DIM1_t f;
} SLCBRDCST_REGS_DTE_SLICE_START_DIM1_u;

#define SLCBRDCST_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLCBRDCST_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_START_DIM2_t f;
} SLCBRDCST_REGS_DTE_SLICE_START_DIM2_u;

#define SLCBRDCST_REGS_DTE_BRDCST_CTRL_OFFSET 0x006c
typedef struct _SLCBRDCST_REGS_DTE_BRDCST_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int BRDCST_DIM:2;
    unsigned int :6;
    unsigned int BRDCST_SIZE:24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int BRDCST_SIZE:24;
    unsigned int :6;
    unsigned int BRDCST_DIM:2;
#endif
} SLCBRDCST_REGS_DTE_BRDCST_CTRL_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_BRDCST_CTRL_t f;
} SLCBRDCST_REGS_DTE_BRDCST_CTRL_u;

#define SLCDE_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0000
typedef struct _SLCDE_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLCDE_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_START_DIM3_t f;
} SLCDE_REGS_DTE_SLICE_START_DIM3_u;

#define SLCDE_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLCDE_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLCDE_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLCDE_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLCDE_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLCDE_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLCDE_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLCDE_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLCDE_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLCDE_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLCDE_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLCDE_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLCDE_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLCDE_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLCDE_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLCDE_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLCDE_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLCDE_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLCDE_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLCDE_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLCDE_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLCDE_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLCDE_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLCDE_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLCDE_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLCDE_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLCDE_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLCDE_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLCDE_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLCDE_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLCDE_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLCDE_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLCDE_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLCDE_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLCDE_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_START_DIM0_t f;
} SLCDE_REGS_DTE_SLICE_START_DIM0_u;

#define SLCDE_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLCDE_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLCDE_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_START_DIM1_t f;
} SLCDE_REGS_DTE_SLICE_START_DIM1_u;

#define SLCDE_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLCDE_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLCDE_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_START_DIM2_t f;
} SLCDE_REGS_DTE_SLICE_START_DIM2_u;

#define SLCDE_REGS_DTE_EXP_CTRL_OFFSET 0x006c
typedef struct _SLCDE_REGS_DTE_EXP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EXP_PHASE:2;
    unsigned int EXP_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int EXP_RATIO:2;
    unsigned int EXP_PHASE:2;
#endif
} SLCDE_REGS_DTE_EXP_CTRL_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_EXP_CTRL_t f;
} SLCDE_REGS_DTE_EXP_CTRL_u;

#define SLCDSL_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0000
typedef struct _SLCDSL_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLCDSL_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_START_DIM3_t f;
} SLCDSL_REGS_DTE_SLICE_START_DIM3_u;

#define SLCDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x0004
typedef struct _SLCDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} SLCDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DSL_START_DIM3_t f;
} SLCDSL_REGS_DTE_DSL_START_DIM3_u;

#define SLCDSL_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLCDSL_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLCDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLCDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLCDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLCDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLCDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLCDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLCDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLCDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLCDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLCDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLCDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLCDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLCDSL_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLCDSL_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLCDSL_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLCDSL_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLCDSL_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLCDSL_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLCDSL_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLCDSL_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLCDSL_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_START_DIM0_t f;
} SLCDSL_REGS_DTE_SLICE_START_DIM0_u;

#define SLCDSL_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLCDSL_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLCDSL_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_START_DIM1_t f;
} SLCDSL_REGS_DTE_SLICE_START_DIM1_u;

#define SLCDSL_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLCDSL_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLCDSL_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_START_DIM2_t f;
} SLCDSL_REGS_DTE_SLICE_START_DIM2_u;

#define SLCDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _SLCDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} SLCDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} SLCDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define SLCDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _SLCDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} SLCDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} SLCDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define SLCDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _SLCDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} SLCDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} SLCDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define SLCDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _SLCDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} SLCDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} SLCDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define SLCDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _SLCDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} SLCDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DSL_START_DIM0_t f;
} SLCDSL_REGS_DTE_DSL_START_DIM0_u;

#define SLCDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _SLCDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} SLCDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DSL_START_DIM1_t f;
} SLCDSL_REGS_DTE_DSL_START_DIM1_u;

#define SLCDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _SLCDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} SLCDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DSL_START_DIM2_t f;
} SLCDSL_REGS_DTE_DSL_START_DIM2_u;

#define SLCPAD_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0000
typedef struct _SLCPAD_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLCPAD_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_START_DIM3_t f;
} SLCPAD_REGS_DTE_SLICE_START_DIM3_u;

#define SLCPAD_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLCPAD_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLCPAD_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLCPAD_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLCPAD_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLCPAD_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLCPAD_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLCPAD_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLCPAD_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLCPAD_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLCPAD_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLCPAD_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLCPAD_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLCPAD_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLCPAD_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLCPAD_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLCPAD_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLCPAD_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLCPAD_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLCPAD_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLCPAD_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLCPAD_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLCPAD_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_START_DIM0_t f;
} SLCPAD_REGS_DTE_SLICE_START_DIM0_u;

#define SLCPAD_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLCPAD_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLCPAD_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_START_DIM1_t f;
} SLCPAD_REGS_DTE_SLICE_START_DIM1_u;

#define SLCPAD_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLCPAD_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLCPAD_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_START_DIM2_t f;
} SLCPAD_REGS_DTE_SLICE_START_DIM2_u;

#define SLCPAD_REGS_DTE_PAD_VALUE_OFFSET 0x006c
typedef struct _SLCPAD_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} SLCPAD_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_PAD_VALUE_t f;
} SLCPAD_REGS_DTE_PAD_VALUE_u;

#define SLCPAD_REGS_DTE_PAD_CTRL_DIM0_OFFSET 0x0070
typedef struct _SLCPAD_REGS_DTE_PAD_CTRL_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM0_LOW:11;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int PAD_DIM0_LOW:11;
#endif
} SLCPAD_REGS_DTE_PAD_CTRL_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_PAD_CTRL_DIM0_t f;
} SLCPAD_REGS_DTE_PAD_CTRL_DIM0_u;

#define SLCPAD_REGS_DTE_PAD_CTRL_DIM1_OFFSET 0x0074
typedef struct _SLCPAD_REGS_DTE_PAD_CTRL_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM1_LOW:11;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM1_INTERIOR:10;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_LOW:11;
#endif
} SLCPAD_REGS_DTE_PAD_CTRL_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_PAD_CTRL_DIM1_t f;
} SLCPAD_REGS_DTE_PAD_CTRL_DIM1_u;

#define SLCPAD_REGS_DTE_PAD_CTRL_DIM2_OFFSET 0x0078
typedef struct _SLCPAD_REGS_DTE_PAD_CTRL_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM2_LOW:11;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM2_INTERIOR:10;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_LOW:11;
#endif
} SLCPAD_REGS_DTE_PAD_CTRL_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_PAD_CTRL_DIM2_t f;
} SLCPAD_REGS_DTE_PAD_CTRL_DIM2_u;

#define SLCPAD_REGS_DTE_PAD_CTRL_DIM3_OFFSET 0x007c
typedef struct _SLCPAD_REGS_DTE_PAD_CTRL_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM3_LOW:11;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM3_INTERIOR:10;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_LOW:11;
#endif
} SLCPAD_REGS_DTE_PAD_CTRL_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_PAD_CTRL_DIM3_t f;
} SLCPAD_REGS_DTE_PAD_CTRL_DIM3_u;

#define SLCRSHP_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0000
typedef struct _SLCRSHP_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_START_DIM3_t f;
} SLCRSHP_REGS_DTE_SLICE_START_DIM3_u;

#define SLCRSHP_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLCRSHP_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLCRSHP_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLCRSHP_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLCRSHP_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLCRSHP_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLCRSHP_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLCRSHP_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLCRSHP_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLCRSHP_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLCRSHP_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLCRSHP_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLCRSHP_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLCRSHP_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLCRSHP_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLCRSHP_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLCRSHP_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLCRSHP_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLCRSHP_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLCRSHP_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLCRSHP_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLCRSHP_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_START_DIM0_t f;
} SLCRSHP_REGS_DTE_SLICE_START_DIM0_u;

#define SLCRSHP_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLCRSHP_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_START_DIM1_t f;
} SLCRSHP_REGS_DTE_SLICE_START_DIM1_u;

#define SLCRSHP_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLCRSHP_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_START_DIM2_t f;
} SLCRSHP_REGS_DTE_SLICE_START_DIM2_u;

#define SLCRSHP_REGS_DTE_SLC_RESHAPE_CTRL_OFFSET 0x006c
typedef struct _SLCRSHP_REGS_DTE_SLC_RESHAPE_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLC_RESHAPE_DIM0_MAP:2;
    unsigned int SLC_RESHAPE_DIM1_MAP:2;
    unsigned int SLC_RESHAPE_DIM2_MAP:2;
    unsigned int SLC_RESHAPE_DIM3_MAP:2;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int SLC_RESHAPE_DIM3_MAP:2;
    unsigned int SLC_RESHAPE_DIM2_MAP:2;
    unsigned int SLC_RESHAPE_DIM1_MAP:2;
    unsigned int SLC_RESHAPE_DIM0_MAP:2;
#endif
} SLCRSHP_REGS_DTE_SLC_RESHAPE_CTRL_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLC_RESHAPE_CTRL_t f;
} SLCRSHP_REGS_DTE_SLC_RESHAPE_CTRL_u;

#define SSMP_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SSMP_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SSMP_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SSMP_REGS_DTE_SRC_DIM0_SIZE_t f;
} SSMP_REGS_DTE_SRC_DIM0_SIZE_u;

#define SSMP_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SSMP_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SSMP_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SSMP_REGS_DTE_SRC_DIM1_SIZE_t f;
} SSMP_REGS_DTE_SRC_DIM1_SIZE_u;

#define SSMP_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SSMP_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SSMP_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SSMP_REGS_DTE_SRC_DIM2_SIZE_t f;
} SSMP_REGS_DTE_SRC_DIM2_SIZE_u;

#define SSMP_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SSMP_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SSMP_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SSMP_REGS_DTE_SRC_DIM3_SIZE_t f;
} SSMP_REGS_DTE_SRC_DIM3_SIZE_u;

#define SSMP_REGS_DTE_SSMP_CTRL_OFFSET 0x006c
typedef struct _SSMP_REGS_DTE_SSMP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SSMP_ROW_STRIDE:11;
    unsigned int :21;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :21;
    unsigned int SSMP_ROW_STRIDE:11;
#endif
} SSMP_REGS_DTE_SSMP_CTRL_t;

typedef union {
    unsigned int val : 32;
    SSMP_REGS_DTE_SSMP_CTRL_t f;
} SSMP_REGS_DTE_SSMP_CTRL_u;

#define SVSDEC_REGS_DTE_SVS_DECMP_MIN_PKT_SIZE_OFFSET 0x0044
typedef struct _SVSDEC_REGS_DTE_SVS_DECMP_MIN_PKT_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DECMP_MIN_PKT_SIZE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DECMP_MIN_PKT_SIZE:32;
#endif
} SVSDEC_REGS_DTE_SVS_DECMP_MIN_PKT_SIZE_t;

typedef union {
    unsigned int val : 32;
    SVSDEC_REGS_DTE_SVS_DECMP_MIN_PKT_SIZE_t f;
} SVSDEC_REGS_DTE_SVS_DECMP_MIN_PKT_SIZE_u;

#define SVSDEC_REGS_DTE_SVS_DECMP_SRC_ADDR_INC_OFFSET 0x0048
typedef struct _SVSDEC_REGS_DTE_SVS_DECMP_SRC_ADDR_INC_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_ADDR_INC:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SRC_ADDR_INC:32;
#endif
} SVSDEC_REGS_DTE_SVS_DECMP_SRC_ADDR_INC_t;

typedef union {
    unsigned int val : 32;
    SVSDEC_REGS_DTE_SVS_DECMP_SRC_ADDR_INC_t f;
} SVSDEC_REGS_DTE_SVS_DECMP_SRC_ADDR_INC_u;

#define SVSDEC_REGS_DTE_SVS_DECMP_CTRL_OFFSET 0x006c
typedef struct _SVSDEC_REGS_DTE_SVS_DECMP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SVS_DECMP_EN:1;
    unsigned int SVS_DECMP_HEADER_MODE:1;
    unsigned int :2;
    unsigned int SVS_DECMP_N_PKT_NUM:5;
    unsigned int :23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :23;
    unsigned int SVS_DECMP_N_PKT_NUM:5;
    unsigned int :2;
    unsigned int SVS_DECMP_HEADER_MODE:1;
    unsigned int SVS_DECMP_EN:1;
#endif
} SVSDEC_REGS_DTE_SVS_DECMP_CTRL_t;

typedef union {
    unsigned int val : 32;
    SVSDEC_REGS_DTE_SVS_DECMP_CTRL_t f;
} SVSDEC_REGS_DTE_SVS_DECMP_CTRL_u;

#define SVSDEC_REGS_DTE_SVS_DECMP_DST_ADDR_INC_OFFSET 0x0070
typedef struct _SVSDEC_REGS_DTE_SVS_DECMP_DST_ADDR_INC_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_ADDR_INC:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DST_ADDR_INC:32;
#endif
} SVSDEC_REGS_DTE_SVS_DECMP_DST_ADDR_INC_t;

typedef union {
    unsigned int val : 32;
    SVSDEC_REGS_DTE_SVS_DECMP_DST_ADDR_INC_t f;
} SVSDEC_REGS_DTE_SVS_DECMP_DST_ADDR_INC_u;

#define VMIR_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _VMIR_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} VMIR_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIR_REGS_DTE_SRC_DIM0_SIZE_t f;
} VMIR_REGS_DTE_SRC_DIM0_SIZE_u;

#define VMIR_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _VMIR_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} VMIR_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIR_REGS_DTE_SRC_DIM1_SIZE_t f;
} VMIR_REGS_DTE_SRC_DIM1_SIZE_u;

#define VMIR_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _VMIR_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} VMIR_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIR_REGS_DTE_SRC_DIM2_SIZE_t f;
} VMIR_REGS_DTE_SRC_DIM2_SIZE_u;

#define VMIR_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _VMIR_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} VMIR_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIR_REGS_DTE_SRC_DIM3_SIZE_t f;
} VMIR_REGS_DTE_SRC_DIM3_SIZE_u;

#define VMIRDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x0004
typedef struct _VMIRDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} VMIRDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DSL_START_DIM3_t f;
} VMIRDSL_REGS_DTE_DSL_START_DIM3_u;

#define VMIRDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _VMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} VMIRDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define VMIRDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _VMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} VMIRDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define VMIRDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _VMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} VMIRDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define VMIRDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _VMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} VMIRDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define VMIRDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _VMIRDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} VMIRDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define VMIRDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _VMIRDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} VMIRDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define VMIRDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _VMIRDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} VMIRDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define VMIRDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _VMIRDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} VMIRDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define VMIRDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _VMIRDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} VMIRDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DSL_START_DIM0_t f;
} VMIRDSL_REGS_DTE_DSL_START_DIM0_u;

#define VMIRDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _VMIRDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} VMIRDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DSL_START_DIM1_t f;
} VMIRDSL_REGS_DTE_DSL_START_DIM1_u;

#define VMIRDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _VMIRDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} VMIRDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DSL_START_DIM2_t f;
} VMIRDSL_REGS_DTE_DSL_START_DIM2_u;

#define VMIRPAD_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _VMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} VMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t f;
} VMIRPAD_REGS_DTE_SRC_DIM0_SIZE_u;

#define VMIRPAD_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _VMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} VMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t f;
} VMIRPAD_REGS_DTE_SRC_DIM1_SIZE_u;

#define VMIRPAD_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _VMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} VMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t f;
} VMIRPAD_REGS_DTE_SRC_DIM2_SIZE_u;

#define VMIRPAD_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _VMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} VMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t f;
} VMIRPAD_REGS_DTE_SRC_DIM3_SIZE_u;

#define VMIRPAD_REGS_DTE_PAD_VALUE_OFFSET 0x006c
typedef struct _VMIRPAD_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} VMIRPAD_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_PAD_VALUE_t f;
} VMIRPAD_REGS_DTE_PAD_VALUE_u;

#define VMIRPAD_REGS_DTE_PAD_CTRL_DIM0_OFFSET 0x0070
typedef struct _VMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM0_LOW:11;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int PAD_DIM0_LOW:11;
#endif
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t f;
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM0_u;

#define VMIRPAD_REGS_DTE_PAD_CTRL_DIM1_OFFSET 0x0074
typedef struct _VMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM1_LOW:11;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM1_INTERIOR:10;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_LOW:11;
#endif
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t f;
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM1_u;

#define VMIRPAD_REGS_DTE_PAD_CTRL_DIM2_OFFSET 0x0078
typedef struct _VMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM2_LOW:11;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM2_INTERIOR:10;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_LOW:11;
#endif
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t f;
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM2_u;

#define VMIRPAD_REGS_DTE_PAD_CTRL_DIM3_OFFSET 0x007c
typedef struct _VMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM3_LOW:11;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM3_INTERIOR:10;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_LOW:11;
#endif
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t f;
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM3_u;


#pragma pack(pop)

// clang-format on

#endif  // HARDWARE_GDTE_SCORPIO_GDTE_OP_TYPE_LMC_1_H_
