/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_SCORPIO_GDTE_VC_H_
#define HARDWARE_GDTE_SCORPIO_GDTE_VC_H_

#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include "framework/include/log.h"
#include "hardware/include/gdte/gdte_ctx.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace gdte {

class GdteVcScorpio {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  vc      { parameter_description }
     * @param      dte     The dte
     * @param[in]  logger  The logger
     */
    GdteVcScorpio(int vc, Hardware *dte, std::shared_ptr<spdlog::logger> logger)
        : vc_(vc), dte_(dte), logger_(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~GdteVcScorpio() {}

    /**
     * @brief      Initializes the register handle.
     */
    virtual void InitRegHandle() {}

    /**
     * @brief      Sets the command packet.
     *
     * @param[in]  ctx   The new value
     */
    virtual void SetCmdPkt(const DteVcCtx &ctx) {}

    /**
     * @brief      trigger vc
     */
    virtual void Trigger() {}

    /**
     * @brief      { function_description }
     */
    virtual void Invalidate() {}

    /**
     * @brief      check vc busy
     *
     * @return     True if busy, False otherwise.
     */
    virtual bool IsBusy() {
        return false;
    }

    /**
     * @brief      check vc occupy
     *
     * @return     True if occupy, False otherwise.
     */
    virtual bool IsOccupy() {
        return false;
    }

    /**
     * @brief      Gets the operation type.
     *
     * @return     The operation type.
     */
    virtual uint32_t GetOpType() {
        return 0;
    }

    /**
     * @brief      Gets the sram register address.
     *
     * @param[in]  index  The index
     *
     * @return     The sram register address.
     */
    virtual uint64_t GetSramRegAddr(uint32_t index) {
        return sram_reg_->ecf_addr_ + index * 4;
    }

    /**
     * @brief      Gets the l 2 loss status.
     *
     * @param      ctx   The context
     */
    virtual void GetL2LossStatus(DteVcCtx *ctx) {}

    /**
     * @brief      Dumps a vc information.
     *
     * @param      data  The data
     */
    virtual std::vector<std::string> DumpVcInfo() {
        return {};
    }

    /**
     * @brief      Sets the signal.
     *
     * @param[in]  addr  The address
     * @param[in]  data  The data
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetSignalSrc(uint32_t addr, uint32_t data) {
        return false;
    }

    /**
     * @brief      Sets the signal sts.
     *
     * @param[in]  type  The type
     * @param[in]  sts   The new value
     */
    virtual void SetSignalSts(const std::string &type, int sts) {}

    /**
     * @brief      Gets the trigger address.
     *
     * @return     The trigger address.
     */
    virtual uint32_t GetTriggerAddr() {
        return 0;
    }

    /**
     * @brief      direct reg access
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t DirectRegRead(uint32_t addr) {
        return 0;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void DirectRegWrite(uint32_t addr, uint32_t val) = 0;

    /**
     * @brief      op access
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t SramRegRead(uint32_t addr) {
        return 0;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void SramRegWrite(uint32_t addr, uint32_t val) {}

    /**
     * \brief lock vc
     */
    void Lock() {
        vc_obj_mut_.lock();
    }

    /**
     * \brief unlock vc
     */
    void UnLock() {
        vc_obj_mut_.unlock();
    }

 protected:
    int       vc_         = -1;
    Hardware *dte_        = nullptr;
    Hardware *direct_reg_ = nullptr;
    Hardware *sram_reg_   = nullptr;

    std::mutex vc_obj_mut_;

    std::shared_ptr<spdlog::logger> logger_;
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_SCORPIO_GDTE_VC_H_
