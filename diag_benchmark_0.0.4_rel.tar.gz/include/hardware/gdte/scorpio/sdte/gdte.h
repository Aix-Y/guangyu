/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_SCORPIO_SDTE_GDTE_H_
#define HARDWARE_GDTE_SCORPIO_SDTE_GDTE_H_

#include <memory>
#include <set>
#include <string>
#include "hardware/gdte/scorpio/cdte/gdte.h"
#include "hardware/gdte/scorpio/sdte/gdte_vc.h"

namespace efvf {
namespace hardware {
namespace gdte {
class SdteScorpio : public CdteScorpio {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit SdteScorpio(std::shared_ptr<spdlog::logger> logger) : CdteScorpio(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~SdteScorpio() {}

    /**
     * @brief      Gets the debug position.
     *
     * @return     The debug position.
     */
    virtual uint32_t GetDbgPos();

    /**
     * @brief      Gets the eng name.
     *
     * @return     The eng name.
     */
    virtual std::string GetEngName() {
        return "sdte";
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitEngineIdle(int timeout);

    /**
     * @brief      Gets the thread mask.
     *
     * @return     The thread mask.
     */
    virtual uint32_t GetThreadMask();

    /**
     * @brief      Gets the sa.
     *
     * @return     The sa.
     */
    virtual SystemAdapter *GetSa();

    /**
     * @brief      { function_description }
     */
    virtual void EnCrc(uint32_t port, int vc) {}

    /**
     * @brief      Gets the crc value.
     *
     * @return     The crc value.
     */
    virtual uint32_t GetCrcVal() {
        return 0;
    }

    /**
     * @brief      Gets the bpm number.
     *
     * @return     The bpm number.
     */
    virtual uint32_t GetPortNum() {
        return 0;
    }

    /**
     * @brief      Gets the bpm.
     *
     * @param[in]  index  The index
     *
     * @return     The bpm.
     */
    virtual Bpm *GetBpm(int index);

    /**
     * @brief      Gets the dvfs.
     *
     * @param[in]  index  The index
     *
     * @return     The dvfs.
     */
    virtual Pmc *GetDvfs(int index);

    /**
     * @brief      Calc data crc value.
     *
     * @param[in]  src_addr     The src buffer address
     * @param[in]  dst_addr     The dst buffer address
     * @param[in]  size         Calc crc data size
     * @param[in]  timeout      timeout value
     * @return     The crc value.
     */
    virtual uint32_t CalcDataCrc(
        uint64_t src_addr, uint64_t dst_addr, uint64_t size, int timeout);

    /**
     * @brief      { function_description }
     */
    virtual void DvfsPmcStart();

    /**
     * @brief      { function_description }
     */
    virtual void DvfsPmcStop();

    /**
     * @brief      Gets the dvfs result.
     *
     * @param      result  The result
     */
    virtual void GetDvfsResult(DvfsResult &result);

    /**
     * @brief      Gets the performance pmc.
     *
     * @return     The performance pmc.
     */
    virtual Pmc *GetPerfPmc();

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStart();

    /**
     * @brief      Enables the bpm.
     */
    virtual void EnableBpm(uint64_t cycle);

    /**
     * @brief      Gets the bpm w thro.
     *
     * @param[in]  idex  The idex
     * @param      res   The resource
     */
    virtual void GetBpmResult(int index, BpmResult *res);

    /**
     * @brief      Prints a bpm status.
     */
    virtual void PrintBpmStatus() {}

    /**
     * @brief      Sets the reorder.
     *
     * @param[in]  status  The status
     */
    virtual void SetReorder(bool status) {}

    /**
     * @brief      Sets the throttle.
     *
     * @param[in]  percent  The percent
     * @param[in]  status   The status
     */
    virtual void SetThrottle(
        uint32_t window, uint32_t rd_bw, uint32_t wr_bw, uint32_t rd_os, uint32_t wr_os);

    /**
     * @brief      Gets the clock m hz.
     *
     * @return     The clock m hz.
     */
    virtual uint64_t GetClkMHz() {
        return dtu_->GetSsm()->GetClk()->ssm_clk_get(ssm::clk::kClkEdf);
    }

    /**
     * @brief      { function_description }
     */
    virtual void EnClkGate();

    /**
     * @brief      Determines if optimize en.
     *
     * @return     True if optimize en, False otherwise.
     */
    virtual bool IsOptimizeEn();

    virtual void ShowOpDesc();

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint64_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void RegWrite(uint64_t addr, uint32_t val);

    /**
     * @brief      { function_description }
     */
    virtual void LibInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit();

 private:
    std::mutex mutex_;

 private:
    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void FillShrinkParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void FillExpandParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void FillSliceExpandParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void FillShkDlsParam(DteVcCtx *ctx);

    // friend class SdteVfScorpio;
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_SCORPIO_SDTE_GDTE_H_
