/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_SCORPIO_CDTE_GDTE_RAS_H_
#define HARDWARE_GDTE_SCORPIO_CDTE_GDTE_RAS_H_

#include "hardware/include/gdte/gdte_ras.h"

namespace efvf {
namespace hardware {
namespace gdte {

class GdteScorpio;
class CdteRasScorpio : public GdteRas {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param      mc    { parameter_description }
     */
    explicit CdteRasScorpio(GdteScorpio *dte);

    /**
     * @brief      Destroys the object.
     */
    virtual ~CdteRasScorpio() {}

    /**
     * @brief      could set multi config by setting next_
     *
     * @param      cfg   The configuration
     */
    virtual void Enable(RasCfg *cfg);

    /**
     * @brief      { function_description }
     */
    virtual void Disable(RasCfg *cfg) {}

    /**
     * @brief      Starts an error injection.
     *
     * @param      cfg      The configuration
     * @param      err_inj  The error inj
     */
    virtual void StartErrInjection(RasCfg *cfg, RasErrInj *err_inj) {}

    /**
     * @brief      Stops an error injection.
     *
     * @param      cfg      The configuration
     * @param      err_inj  The error inj
     */
    virtual void StopErrInjection(RasCfg *cfg, RasErrInj *err_inj) {}

    /**
     * @brief      Queries an error status.
     *
     * @param      cfg       The configuration
     * @param      err_stat  The error stat
     */
    virtual void QueryErrStatus(RasCfg *cfg, RasErrStat *err_stat);

    /**
     * @brief      { function_description }
     *
     * @param      cfg   The configuration
     */
    virtual void ClearErrStatus(RasCfg *cfg) {}

    /**
     * @brief      Prints an error status.
     *
     * @param      cfg   The configuration
     */
    virtual void PrintErrStatus(RasCfg *cfg) {}

    /**
     * @berif get ras cfg
     *
     * @param      cfg   The configuration
     */
    virtual void GetRasCfg(RasCfg *cfg) {}

    /**
     * @brief      Enables the interrupt.
     *
     * @param      cfg   The configuration
     */
    virtual void EnableInterrupt(IntrptCfg *cfg);

    /**
     * @brief      Disables the interrupt.
     *
     * @param      cfg   The configuration
     */
    virtual void DisableInterrupt(IntrptCfg *cfg);

    /**
     * @brief      { function_description }
     *
     * @param      cfg   The configuration
     */
    virtual void ClearInterrupt(IntrptCfg *cfg);

    /**
     * @brief      Queries an interrupt.
     *
     * @param      cfg    The configuration
     * @param      stats  The statistics
     */
    virtual void QueryInterrupt(IntrptCfg *cfg, IntrptStat *stats);

    /**
     * @brief      Prints an interrupt.
     *
     * @param      cfg   The configuration
     */
    virtual void PrintInterrupt(IntrptCfg *cfg);

 private:
    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint32_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void RegWrite(uint32_t addr, uint32_t val);

 protected:
    GdteScorpio *dte_ = nullptr;

 private:
    bool ign_ill_vc_cfg_ = false;
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_SCORPIO_CDTE_GDTE_RAS_H_
