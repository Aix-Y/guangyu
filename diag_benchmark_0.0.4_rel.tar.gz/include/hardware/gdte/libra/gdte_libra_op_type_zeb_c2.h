/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_LIBRA_GDTE_LIBRA_OP_TYPE_ZEB_C2_H_
#define HARDWARE_GDTE_LIBRA_GDTE_LIBRA_OP_TYPE_ZEB_C2_H_

// clang-format off

#pragma pack(push, 1)
#define DTE_COMMON_REGS_DTE_ENGINE_CTRL_OFFSET 0x0000
typedef struct _DTE_COMMON_REGS_DTE_ENGINE_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ENGINE_ENABLE:1;
    unsigned int DYNAMIC_CLK_GATE_EN:1;
    unsigned int CLK_GATE_EN:1;
    unsigned int REG_BRIDGE_CLK_EN:1;
    unsigned int THD_CLK_GATE_EN:1;
    unsigned int RSHP_CLK_GATE_EN:1;
    unsigned int CLK_GATE_DLY:4;
    unsigned int SW_STOP:1;
    unsigned int STOP_SIG_EN:1;
    unsigned int :2;
    unsigned int ORDER_LIST_PRI_EN:1;
    unsigned int ORDER_LIST_FILTER_EN:1;
    unsigned int :2;
    unsigned int ULTRA_OP_PRI_EN:1;
    unsigned int INVLD_VC_CLR_MBX_EN:1;
    unsigned int RD_REQ_P_CLK_GATE_EN:1;
    unsigned int RD_RESP_P_CLK_GATE_EN:1;
    unsigned int WR_REQ_P_CLK_GATE_EN:1;
    unsigned int WR_BRDCST_OP_CLK_GATE_EN:1;
    unsigned int WR_DSL_OP_CLK_GATE_EN:1;
    unsigned int WR_PAD_OP_CLK_GATE_EN:1;
    unsigned int :1;
    unsigned int CRC_CLK_GATE_EN:1;
    unsigned int :1;
    unsigned int DYNAMIC_QUEUE_EN:1;
    unsigned int RSHP_IFB_MODE:1;
    unsigned int :1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :1;
    unsigned int RSHP_IFB_MODE:1;
    unsigned int DYNAMIC_QUEUE_EN:1;
    unsigned int :1;
    unsigned int CRC_CLK_GATE_EN:1;
    unsigned int :1;
    unsigned int WR_PAD_OP_CLK_GATE_EN:1;
    unsigned int WR_DSL_OP_CLK_GATE_EN:1;
    unsigned int WR_BRDCST_OP_CLK_GATE_EN:1;
    unsigned int WR_REQ_P_CLK_GATE_EN:1;
    unsigned int RD_RESP_P_CLK_GATE_EN:1;
    unsigned int RD_REQ_P_CLK_GATE_EN:1;
    unsigned int INVLD_VC_CLR_MBX_EN:1;
    unsigned int ULTRA_OP_PRI_EN:1;
    unsigned int :2;
    unsigned int ORDER_LIST_FILTER_EN:1;
    unsigned int ORDER_LIST_PRI_EN:1;
    unsigned int :2;
    unsigned int STOP_SIG_EN:1;
    unsigned int SW_STOP:1;
    unsigned int CLK_GATE_DLY:4;
    unsigned int RSHP_CLK_GATE_EN:1;
    unsigned int THD_CLK_GATE_EN:1;
    unsigned int REG_BRIDGE_CLK_EN:1;
    unsigned int CLK_GATE_EN:1;
    unsigned int DYNAMIC_CLK_GATE_EN:1;
    unsigned int ENGINE_ENABLE:1;
#endif
} DTE_COMMON_REGS_DTE_ENGINE_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ENGINE_CTRL_t f;
} DTE_COMMON_REGS_DTE_ENGINE_CTRL_u;

#define DTE_COMMON_REGS_DTE_DATA_SRAMMISC_CTRL_OFFSET 0x0004
typedef struct _DTE_COMMON_REGS_DTE_DATA_SRAMMISC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DATA_SRAMMISC:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DATA_SRAMMISC:32;
#endif
} DTE_COMMON_REGS_DTE_DATA_SRAMMISC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DATA_SRAMMISC_CTRL_t f;
} DTE_COMMON_REGS_DTE_DATA_SRAMMISC_CTRL_u;

#define DTE_COMMON_REGS_DTE_ULTRA_DATA_SRAMMISC_CTRL_OFFSET 0x0008
typedef struct _DTE_COMMON_REGS_DTE_ULTRA_DATA_SRAMMISC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ULTRA_DATA_SRAMMISC:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ULTRA_DATA_SRAMMISC:32;
#endif
} DTE_COMMON_REGS_DTE_ULTRA_DATA_SRAMMISC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ULTRA_DATA_SRAMMISC_CTRL_t f;
} DTE_COMMON_REGS_DTE_ULTRA_DATA_SRAMMISC_CTRL_u;

#define DTE_COMMON_REGS_DTE_REG_SRAMMISC_CTRL_OFFSET 0x000c
typedef struct _DTE_COMMON_REGS_DTE_REG_SRAMMISC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int REG_SRAMMISC:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int REG_SRAMMISC:32;
#endif
} DTE_COMMON_REGS_DTE_REG_SRAMMISC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_REG_SRAMMISC_CTRL_t f;
} DTE_COMMON_REGS_DTE_REG_SRAMMISC_CTRL_u;

#define DTE_COMMON_REGS_DTE_BURST_LEN_CTRL_OFFSET 0x0010
typedef struct _DTE_COMMON_REGS_DTE_BURST_LEN_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WPORT_MAX_BURST:3;
    unsigned int :1;
    unsigned int RPORT_MAX_BURST:3;
    unsigned int :25;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :25;
    unsigned int RPORT_MAX_BURST:3;
    unsigned int :1;
    unsigned int WPORT_MAX_BURST:3;
#endif
} DTE_COMMON_REGS_DTE_BURST_LEN_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_BURST_LEN_CTRL_t f;
} DTE_COMMON_REGS_DTE_BURST_LEN_CTRL_u;

#define DTE_COMMON_REGS_DTE_DEFAULT_ID_OFFSET 0x0014
typedef struct _DTE_COMMON_REGS_DTE_DEFAULT_ID_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DEFAULT_CTXT_ID:4;
    unsigned int DEFAULT_ASID:4;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int DEFAULT_ASID:4;
    unsigned int DEFAULT_CTXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_DEFAULT_ID_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DEFAULT_ID_t f;
} DTE_COMMON_REGS_DTE_DEFAULT_ID_u;

#define DTE_COMMON_REGS_DTE_TIMEOUT_CTRL_OFFSET 0x0018
typedef struct _DTE_COMMON_REGS_DTE_TIMEOUT_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_THRESHOLD:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int TIMEOUT_THRESHOLD:32;
#endif
} DTE_COMMON_REGS_DTE_TIMEOUT_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_TIMEOUT_CTRL_t f;
} DTE_COMMON_REGS_DTE_TIMEOUT_CTRL_u;

#define DTE_COMMON_REGS_DTE_REG_SRAM_INIT_OFFSET 0x001c
typedef struct _DTE_COMMON_REGS_DTE_REG_SRAM_INIT_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int REG_SRAM_INIT_EN:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int REG_SRAM_INIT_EN:1;
#endif
} DTE_COMMON_REGS_DTE_REG_SRAM_INIT_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_REG_SRAM_INIT_t f;
} DTE_COMMON_REGS_DTE_REG_SRAM_INIT_u;

#define DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR0_OFFSET 0x0020
typedef struct _DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR0:32;
#endif
} DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR0_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR0_t f;
} DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR0_u;

#define DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR1_OFFSET 0x0024
typedef struct _DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR1:32;
#endif
} DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR1_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR1_t f;
} DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR1_u;

#define DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR2_OFFSET 0x0028
typedef struct _DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR2:32;
#endif
} DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR2_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR2_t f;
} DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR2_u;

#define DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR3_OFFSET 0x002c
typedef struct _DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR3:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR3:32;
#endif
} DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR3_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR3_t f;
} DTE_COMMON_REGS_DTE_GSYNC_SLV_BASE_ADDR3_u;

#define DTE_COMMON_REGS_DTE_CRC_CTRL_OFFSET 0x0030
typedef struct _DTE_COMMON_REGS_DTE_CRC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CRC_EN:1;
    unsigned int CRC_CHN_EN:1;
    unsigned int CRC_RESULT_VALID:1;
    unsigned int :1;
    unsigned int CRC_CHN_NUM:8;
    unsigned int :1;
    unsigned int CRC_WPORT_SEL:3;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int CRC_WPORT_SEL:3;
    unsigned int :1;
    unsigned int CRC_CHN_NUM:8;
    unsigned int :1;
    unsigned int CRC_RESULT_VALID:1;
    unsigned int CRC_CHN_EN:1;
    unsigned int CRC_EN:1;
#endif
} DTE_COMMON_REGS_DTE_CRC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_CRC_CTRL_t f;
} DTE_COMMON_REGS_DTE_CRC_CTRL_u;

#define DTE_COMMON_REGS_DTE_CRC_RESULT_OFFSET 0x0034
typedef struct _DTE_COMMON_REGS_DTE_CRC_RESULT_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CRC_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CRC_VALUE:32;
#endif
} DTE_COMMON_REGS_DTE_CRC_RESULT_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_CRC_RESULT_t f;
} DTE_COMMON_REGS_DTE_CRC_RESULT_u;

#define DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_0_OFFSET 0x0038
typedef struct _DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE0_QOS:2;
    unsigned int ARB_QUEUE1_QOS:2;
    unsigned int ARB_QUEUE2_QOS:2;
    unsigned int ARB_QUEUE3_QOS:2;
    unsigned int ARB_QUEUE4_QOS:2;
    unsigned int ARB_QUEUE5_QOS:2;
    unsigned int ARB_QUEUE6_QOS:2;
    unsigned int ARB_QUEUE7_QOS:2;
    unsigned int ARB_QUEUE8_QOS:2;
    unsigned int ARB_QUEUE9_QOS:2;
    unsigned int ARB_QUEUE10_QOS:2;
    unsigned int ARB_QUEUE11_QOS:2;
    unsigned int ARB_QUEUE12_QOS:2;
    unsigned int ARB_QUEUE13_QOS:2;
    unsigned int ARB_QUEUE14_QOS:2;
    unsigned int ARB_QUEUE15_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE15_QOS:2;
    unsigned int ARB_QUEUE14_QOS:2;
    unsigned int ARB_QUEUE13_QOS:2;
    unsigned int ARB_QUEUE12_QOS:2;
    unsigned int ARB_QUEUE11_QOS:2;
    unsigned int ARB_QUEUE10_QOS:2;
    unsigned int ARB_QUEUE9_QOS:2;
    unsigned int ARB_QUEUE8_QOS:2;
    unsigned int ARB_QUEUE7_QOS:2;
    unsigned int ARB_QUEUE6_QOS:2;
    unsigned int ARB_QUEUE5_QOS:2;
    unsigned int ARB_QUEUE4_QOS:2;
    unsigned int ARB_QUEUE3_QOS:2;
    unsigned int ARB_QUEUE2_QOS:2;
    unsigned int ARB_QUEUE1_QOS:2;
    unsigned int ARB_QUEUE0_QOS:2;
#endif
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_0_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_0_t f;
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_0_u;

#define DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_1_OFFSET 0x003c
typedef struct _DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE16_QOS:2;
    unsigned int ARB_QUEUE17_QOS:2;
    unsigned int ARB_QUEUE18_QOS:2;
    unsigned int ARB_QUEUE19_QOS:2;
    unsigned int ARB_QUEUE20_QOS:2;
    unsigned int ARB_QUEUE21_QOS:2;
    unsigned int ARB_QUEUE22_QOS:2;
    unsigned int ARB_QUEUE23_QOS:2;
    unsigned int ARB_QUEUE24_QOS:2;
    unsigned int ARB_QUEUE25_QOS:2;
    unsigned int ARB_QUEUE26_QOS:2;
    unsigned int ARB_QUEUE27_QOS:2;
    unsigned int ARB_QUEUE28_QOS:2;
    unsigned int ARB_QUEUE29_QOS:2;
    unsigned int ARB_QUEUE30_QOS:2;
    unsigned int ARB_QUEUE31_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE31_QOS:2;
    unsigned int ARB_QUEUE30_QOS:2;
    unsigned int ARB_QUEUE29_QOS:2;
    unsigned int ARB_QUEUE28_QOS:2;
    unsigned int ARB_QUEUE27_QOS:2;
    unsigned int ARB_QUEUE26_QOS:2;
    unsigned int ARB_QUEUE25_QOS:2;
    unsigned int ARB_QUEUE24_QOS:2;
    unsigned int ARB_QUEUE23_QOS:2;
    unsigned int ARB_QUEUE22_QOS:2;
    unsigned int ARB_QUEUE21_QOS:2;
    unsigned int ARB_QUEUE20_QOS:2;
    unsigned int ARB_QUEUE19_QOS:2;
    unsigned int ARB_QUEUE18_QOS:2;
    unsigned int ARB_QUEUE17_QOS:2;
    unsigned int ARB_QUEUE16_QOS:2;
#endif
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_1_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_1_t f;
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_1_u;

#define DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_2_OFFSET 0x0040
typedef struct _DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE32_QOS:2;
    unsigned int ARB_QUEUE33_QOS:2;
    unsigned int ARB_QUEUE34_QOS:2;
    unsigned int ARB_QUEUE35_QOS:2;
    unsigned int ARB_QUEUE36_QOS:2;
    unsigned int ARB_QUEUE37_QOS:2;
    unsigned int ARB_QUEUE38_QOS:2;
    unsigned int ARB_QUEUE39_QOS:2;
    unsigned int ARB_QUEUE40_QOS:2;
    unsigned int ARB_QUEUE41_QOS:2;
    unsigned int ARB_QUEUE42_QOS:2;
    unsigned int ARB_QUEUE43_QOS:2;
    unsigned int ARB_QUEUE44_QOS:2;
    unsigned int ARB_QUEUE45_QOS:2;
    unsigned int ARB_QUEUE46_QOS:2;
    unsigned int ARB_QUEUE47_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE47_QOS:2;
    unsigned int ARB_QUEUE46_QOS:2;
    unsigned int ARB_QUEUE45_QOS:2;
    unsigned int ARB_QUEUE44_QOS:2;
    unsigned int ARB_QUEUE43_QOS:2;
    unsigned int ARB_QUEUE42_QOS:2;
    unsigned int ARB_QUEUE41_QOS:2;
    unsigned int ARB_QUEUE40_QOS:2;
    unsigned int ARB_QUEUE39_QOS:2;
    unsigned int ARB_QUEUE38_QOS:2;
    unsigned int ARB_QUEUE37_QOS:2;
    unsigned int ARB_QUEUE36_QOS:2;
    unsigned int ARB_QUEUE35_QOS:2;
    unsigned int ARB_QUEUE34_QOS:2;
    unsigned int ARB_QUEUE33_QOS:2;
    unsigned int ARB_QUEUE32_QOS:2;
#endif
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_2_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_2_t f;
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_2_u;

#define DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_3_OFFSET 0x0044
typedef struct _DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE48_QOS:2;
    unsigned int ARB_QUEUE49_QOS:2;
    unsigned int ARB_QUEUE50_QOS:2;
    unsigned int ARB_QUEUE51_QOS:2;
    unsigned int ARB_QUEUE52_QOS:2;
    unsigned int ARB_QUEUE53_QOS:2;
    unsigned int ARB_QUEUE54_QOS:2;
    unsigned int ARB_QUEUE55_QOS:2;
    unsigned int ARB_QUEUE56_QOS:2;
    unsigned int ARB_QUEUE57_QOS:2;
    unsigned int ARB_QUEUE58_QOS:2;
    unsigned int ARB_QUEUE59_QOS:2;
    unsigned int ARB_QUEUE60_QOS:2;
    unsigned int ARB_QUEUE61_QOS:2;
    unsigned int ARB_QUEUE62_QOS:2;
    unsigned int ARB_QUEUE63_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE63_QOS:2;
    unsigned int ARB_QUEUE62_QOS:2;
    unsigned int ARB_QUEUE61_QOS:2;
    unsigned int ARB_QUEUE60_QOS:2;
    unsigned int ARB_QUEUE59_QOS:2;
    unsigned int ARB_QUEUE58_QOS:2;
    unsigned int ARB_QUEUE57_QOS:2;
    unsigned int ARB_QUEUE56_QOS:2;
    unsigned int ARB_QUEUE55_QOS:2;
    unsigned int ARB_QUEUE54_QOS:2;
    unsigned int ARB_QUEUE53_QOS:2;
    unsigned int ARB_QUEUE52_QOS:2;
    unsigned int ARB_QUEUE51_QOS:2;
    unsigned int ARB_QUEUE50_QOS:2;
    unsigned int ARB_QUEUE49_QOS:2;
    unsigned int ARB_QUEUE48_QOS:2;
#endif
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_3_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_3_t f;
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_3_u;

#define DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_4_OFFSET 0x0048
typedef struct _DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_4_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE64_QOS:2;
    unsigned int ARB_QUEUE65_QOS:2;
    unsigned int ARB_QUEUE66_QOS:2;
    unsigned int ARB_QUEUE67_QOS:2;
    unsigned int ARB_QUEUE68_QOS:2;
    unsigned int ARB_QUEUE69_QOS:2;
    unsigned int ARB_QUEUE70_QOS:2;
    unsigned int ARB_QUEUE71_QOS:2;
    unsigned int ARB_QUEUE72_QOS:2;
    unsigned int ARB_QUEUE73_QOS:2;
    unsigned int ARB_QUEUE74_QOS:2;
    unsigned int ARB_QUEUE75_QOS:2;
    unsigned int ARB_QUEUE76_QOS:2;
    unsigned int ARB_QUEUE77_QOS:2;
    unsigned int ARB_QUEUE78_QOS:2;
    unsigned int ARB_QUEUE79_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE79_QOS:2;
    unsigned int ARB_QUEUE78_QOS:2;
    unsigned int ARB_QUEUE77_QOS:2;
    unsigned int ARB_QUEUE76_QOS:2;
    unsigned int ARB_QUEUE75_QOS:2;
    unsigned int ARB_QUEUE74_QOS:2;
    unsigned int ARB_QUEUE73_QOS:2;
    unsigned int ARB_QUEUE72_QOS:2;
    unsigned int ARB_QUEUE71_QOS:2;
    unsigned int ARB_QUEUE70_QOS:2;
    unsigned int ARB_QUEUE69_QOS:2;
    unsigned int ARB_QUEUE68_QOS:2;
    unsigned int ARB_QUEUE67_QOS:2;
    unsigned int ARB_QUEUE66_QOS:2;
    unsigned int ARB_QUEUE65_QOS:2;
    unsigned int ARB_QUEUE64_QOS:2;
#endif
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_4_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_4_t f;
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_4_u;

#define DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_5_OFFSET 0x004c
typedef struct _DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_5_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE80_QOS:2;
    unsigned int ARB_QUEUE81_QOS:2;
    unsigned int ARB_QUEUE82_QOS:2;
    unsigned int ARB_QUEUE83_QOS:2;
    unsigned int ARB_QUEUE84_QOS:2;
    unsigned int ARB_QUEUE85_QOS:2;
    unsigned int ARB_QUEUE86_QOS:2;
    unsigned int ARB_QUEUE87_QOS:2;
    unsigned int ARB_QUEUE88_QOS:2;
    unsigned int ARB_QUEUE89_QOS:2;
    unsigned int ARB_QUEUE90_QOS:2;
    unsigned int ARB_QUEUE91_QOS:2;
    unsigned int ARB_QUEUE92_QOS:2;
    unsigned int ARB_QUEUE93_QOS:2;
    unsigned int ARB_QUEUE94_QOS:2;
    unsigned int ARB_QUEUE95_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE95_QOS:2;
    unsigned int ARB_QUEUE94_QOS:2;
    unsigned int ARB_QUEUE93_QOS:2;
    unsigned int ARB_QUEUE92_QOS:2;
    unsigned int ARB_QUEUE91_QOS:2;
    unsigned int ARB_QUEUE90_QOS:2;
    unsigned int ARB_QUEUE89_QOS:2;
    unsigned int ARB_QUEUE88_QOS:2;
    unsigned int ARB_QUEUE87_QOS:2;
    unsigned int ARB_QUEUE86_QOS:2;
    unsigned int ARB_QUEUE85_QOS:2;
    unsigned int ARB_QUEUE84_QOS:2;
    unsigned int ARB_QUEUE83_QOS:2;
    unsigned int ARB_QUEUE82_QOS:2;
    unsigned int ARB_QUEUE81_QOS:2;
    unsigned int ARB_QUEUE80_QOS:2;
#endif
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_5_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_5_t f;
} DTE_COMMON_REGS_DTE_ARB_QUEUE_QOS_5_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_0_OFFSET 0x0050
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC0_CONTEXT_ID:4;
    unsigned int VC1_CONTEXT_ID:4;
    unsigned int VC2_CONTEXT_ID:4;
    unsigned int VC3_CONTEXT_ID:4;
    unsigned int VC4_CONTEXT_ID:4;
    unsigned int VC5_CONTEXT_ID:4;
    unsigned int VC6_CONTEXT_ID:4;
    unsigned int VC7_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC7_CONTEXT_ID:4;
    unsigned int VC6_CONTEXT_ID:4;
    unsigned int VC5_CONTEXT_ID:4;
    unsigned int VC4_CONTEXT_ID:4;
    unsigned int VC3_CONTEXT_ID:4;
    unsigned int VC2_CONTEXT_ID:4;
    unsigned int VC1_CONTEXT_ID:4;
    unsigned int VC0_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_0_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_0_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_0_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_1_OFFSET 0x0054
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC8_CONTEXT_ID:4;
    unsigned int VC9_CONTEXT_ID:4;
    unsigned int VC10_CONTEXT_ID:4;
    unsigned int VC11_CONTEXT_ID:4;
    unsigned int VC12_CONTEXT_ID:4;
    unsigned int VC13_CONTEXT_ID:4;
    unsigned int VC14_CONTEXT_ID:4;
    unsigned int VC15_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC15_CONTEXT_ID:4;
    unsigned int VC14_CONTEXT_ID:4;
    unsigned int VC13_CONTEXT_ID:4;
    unsigned int VC12_CONTEXT_ID:4;
    unsigned int VC11_CONTEXT_ID:4;
    unsigned int VC10_CONTEXT_ID:4;
    unsigned int VC9_CONTEXT_ID:4;
    unsigned int VC8_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_1_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_1_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_1_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_2_OFFSET 0x0058
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC16_CONTEXT_ID:4;
    unsigned int VC17_CONTEXT_ID:4;
    unsigned int VC18_CONTEXT_ID:4;
    unsigned int VC19_CONTEXT_ID:4;
    unsigned int VC20_CONTEXT_ID:4;
    unsigned int VC21_CONTEXT_ID:4;
    unsigned int VC22_CONTEXT_ID:4;
    unsigned int VC23_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC23_CONTEXT_ID:4;
    unsigned int VC22_CONTEXT_ID:4;
    unsigned int VC21_CONTEXT_ID:4;
    unsigned int VC20_CONTEXT_ID:4;
    unsigned int VC19_CONTEXT_ID:4;
    unsigned int VC18_CONTEXT_ID:4;
    unsigned int VC17_CONTEXT_ID:4;
    unsigned int VC16_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_2_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_2_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_2_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_3_OFFSET 0x005c
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC24_CONTEXT_ID:4;
    unsigned int VC25_CONTEXT_ID:4;
    unsigned int VC26_CONTEXT_ID:4;
    unsigned int VC27_CONTEXT_ID:4;
    unsigned int VC28_CONTEXT_ID:4;
    unsigned int VC29_CONTEXT_ID:4;
    unsigned int VC30_CONTEXT_ID:4;
    unsigned int VC31_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC31_CONTEXT_ID:4;
    unsigned int VC30_CONTEXT_ID:4;
    unsigned int VC29_CONTEXT_ID:4;
    unsigned int VC28_CONTEXT_ID:4;
    unsigned int VC27_CONTEXT_ID:4;
    unsigned int VC26_CONTEXT_ID:4;
    unsigned int VC25_CONTEXT_ID:4;
    unsigned int VC24_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_3_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_3_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_3_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_4_OFFSET 0x0060
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_4_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC32_CONTEXT_ID:4;
    unsigned int VC33_CONTEXT_ID:4;
    unsigned int VC34_CONTEXT_ID:4;
    unsigned int VC35_CONTEXT_ID:4;
    unsigned int VC36_CONTEXT_ID:4;
    unsigned int VC37_CONTEXT_ID:4;
    unsigned int VC38_CONTEXT_ID:4;
    unsigned int VC39_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC39_CONTEXT_ID:4;
    unsigned int VC38_CONTEXT_ID:4;
    unsigned int VC37_CONTEXT_ID:4;
    unsigned int VC36_CONTEXT_ID:4;
    unsigned int VC35_CONTEXT_ID:4;
    unsigned int VC34_CONTEXT_ID:4;
    unsigned int VC33_CONTEXT_ID:4;
    unsigned int VC32_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_4_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_4_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_4_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_5_OFFSET 0x0064
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_5_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC40_CONTEXT_ID:4;
    unsigned int VC41_CONTEXT_ID:4;
    unsigned int VC42_CONTEXT_ID:4;
    unsigned int VC43_CONTEXT_ID:4;
    unsigned int VC44_CONTEXT_ID:4;
    unsigned int VC45_CONTEXT_ID:4;
    unsigned int VC46_CONTEXT_ID:4;
    unsigned int VC47_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC47_CONTEXT_ID:4;
    unsigned int VC46_CONTEXT_ID:4;
    unsigned int VC45_CONTEXT_ID:4;
    unsigned int VC44_CONTEXT_ID:4;
    unsigned int VC43_CONTEXT_ID:4;
    unsigned int VC42_CONTEXT_ID:4;
    unsigned int VC41_CONTEXT_ID:4;
    unsigned int VC40_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_5_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_5_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_5_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_6_OFFSET 0x0068
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_6_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC48_CONTEXT_ID:4;
    unsigned int VC49_CONTEXT_ID:4;
    unsigned int VC50_CONTEXT_ID:4;
    unsigned int VC51_CONTEXT_ID:4;
    unsigned int VC52_CONTEXT_ID:4;
    unsigned int VC53_CONTEXT_ID:4;
    unsigned int VC54_CONTEXT_ID:4;
    unsigned int VC55_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC55_CONTEXT_ID:4;
    unsigned int VC54_CONTEXT_ID:4;
    unsigned int VC53_CONTEXT_ID:4;
    unsigned int VC52_CONTEXT_ID:4;
    unsigned int VC51_CONTEXT_ID:4;
    unsigned int VC50_CONTEXT_ID:4;
    unsigned int VC49_CONTEXT_ID:4;
    unsigned int VC48_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_6_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_6_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_6_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_7_OFFSET 0x006c
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_7_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC56_CONTEXT_ID:4;
    unsigned int VC57_CONTEXT_ID:4;
    unsigned int VC58_CONTEXT_ID:4;
    unsigned int VC59_CONTEXT_ID:4;
    unsigned int VC60_CONTEXT_ID:4;
    unsigned int VC61_CONTEXT_ID:4;
    unsigned int VC62_CONTEXT_ID:4;
    unsigned int VC63_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC63_CONTEXT_ID:4;
    unsigned int VC62_CONTEXT_ID:4;
    unsigned int VC61_CONTEXT_ID:4;
    unsigned int VC60_CONTEXT_ID:4;
    unsigned int VC59_CONTEXT_ID:4;
    unsigned int VC58_CONTEXT_ID:4;
    unsigned int VC57_CONTEXT_ID:4;
    unsigned int VC56_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_7_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_7_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_7_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_8_OFFSET 0x0070
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_8_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC64_CONTEXT_ID:4;
    unsigned int VC65_CONTEXT_ID:4;
    unsigned int VC66_CONTEXT_ID:4;
    unsigned int VC67_CONTEXT_ID:4;
    unsigned int VC68_CONTEXT_ID:4;
    unsigned int VC69_CONTEXT_ID:4;
    unsigned int VC70_CONTEXT_ID:4;
    unsigned int VC71_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC71_CONTEXT_ID:4;
    unsigned int VC70_CONTEXT_ID:4;
    unsigned int VC69_CONTEXT_ID:4;
    unsigned int VC68_CONTEXT_ID:4;
    unsigned int VC67_CONTEXT_ID:4;
    unsigned int VC66_CONTEXT_ID:4;
    unsigned int VC65_CONTEXT_ID:4;
    unsigned int VC64_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_8_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_8_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_8_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_9_OFFSET 0x0074
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_9_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC72_CONTEXT_ID:4;
    unsigned int VC73_CONTEXT_ID:4;
    unsigned int VC74_CONTEXT_ID:4;
    unsigned int VC75_CONTEXT_ID:4;
    unsigned int VC76_CONTEXT_ID:4;
    unsigned int VC77_CONTEXT_ID:4;
    unsigned int VC78_CONTEXT_ID:4;
    unsigned int VC79_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC79_CONTEXT_ID:4;
    unsigned int VC78_CONTEXT_ID:4;
    unsigned int VC77_CONTEXT_ID:4;
    unsigned int VC76_CONTEXT_ID:4;
    unsigned int VC75_CONTEXT_ID:4;
    unsigned int VC74_CONTEXT_ID:4;
    unsigned int VC73_CONTEXT_ID:4;
    unsigned int VC72_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_9_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_9_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_9_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_10_OFFSET 0x0078
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_10_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC80_CONTEXT_ID:4;
    unsigned int VC81_CONTEXT_ID:4;
    unsigned int VC82_CONTEXT_ID:4;
    unsigned int VC83_CONTEXT_ID:4;
    unsigned int VC84_CONTEXT_ID:4;
    unsigned int VC85_CONTEXT_ID:4;
    unsigned int VC86_CONTEXT_ID:4;
    unsigned int VC87_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC87_CONTEXT_ID:4;
    unsigned int VC86_CONTEXT_ID:4;
    unsigned int VC85_CONTEXT_ID:4;
    unsigned int VC84_CONTEXT_ID:4;
    unsigned int VC83_CONTEXT_ID:4;
    unsigned int VC82_CONTEXT_ID:4;
    unsigned int VC81_CONTEXT_ID:4;
    unsigned int VC80_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_10_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_10_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_10_u;

#define DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_11_OFFSET 0x007c
typedef struct _DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_11_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC88_CONTEXT_ID:4;
    unsigned int VC89_CONTEXT_ID:4;
    unsigned int VC90_CONTEXT_ID:4;
    unsigned int VC91_CONTEXT_ID:4;
    unsigned int VC92_CONTEXT_ID:4;
    unsigned int VC93_CONTEXT_ID:4;
    unsigned int VC94_CONTEXT_ID:4;
    unsigned int VC95_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC95_CONTEXT_ID:4;
    unsigned int VC94_CONTEXT_ID:4;
    unsigned int VC93_CONTEXT_ID:4;
    unsigned int VC92_CONTEXT_ID:4;
    unsigned int VC91_CONTEXT_ID:4;
    unsigned int VC90_CONTEXT_ID:4;
    unsigned int VC89_CONTEXT_ID:4;
    unsigned int VC88_CONTEXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_11_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_11_t f;
} DTE_COMMON_REGS_DTE_VC_CONTEXT_ID_11_u;

#define DTE_COMMON_REGS_DTE_WR_COMB_CTRL_OFFSET 0x0080
typedef struct _DTE_COMMON_REGS_DTE_WR_COMB_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WR_COMB_WAIT_NUM:4;
    unsigned int WR_COMB_EN:1;
    unsigned int :27;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :27;
    unsigned int WR_COMB_EN:1;
    unsigned int WR_COMB_WAIT_NUM:4;
#endif
} DTE_COMMON_REGS_DTE_WR_COMB_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_WR_COMB_CTRL_t f;
} DTE_COMMON_REGS_DTE_WR_COMB_CTRL_u;

#define DTE_COMMON_REGS_DTE_WR_COMB_UP_ADDR_OFFSET 0x0084
typedef struct _DTE_COMMON_REGS_DTE_WR_COMB_UP_ADDR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WR_COMB_UP_ADDR_LOW:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_COMB_UP_ADDR_LOW:32;
#endif
} DTE_COMMON_REGS_DTE_WR_COMB_UP_ADDR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_WR_COMB_UP_ADDR_t f;
} DTE_COMMON_REGS_DTE_WR_COMB_UP_ADDR_u;

#define DTE_COMMON_REGS_DTE_WR_COMB_BOTTOM_ADDR_OFFSET 0x0088
typedef struct _DTE_COMMON_REGS_DTE_WR_COMB_BOTTOM_ADDR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WR_COMB_BOTTOM_ADDR_LOW:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_COMB_BOTTOM_ADDR_LOW:32;
#endif
} DTE_COMMON_REGS_DTE_WR_COMB_BOTTOM_ADDR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_WR_COMB_BOTTOM_ADDR_t f;
} DTE_COMMON_REGS_DTE_WR_COMB_BOTTOM_ADDR_u;

#define DTE_COMMON_REGS_DTE_WR_COMB_ADDR_HIGH_OFFSET 0x008c
typedef struct _DTE_COMMON_REGS_DTE_WR_COMB_ADDR_HIGH_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WR_COMB_UP_ADDR_HIGH:16;
    unsigned int WR_COMB_BOTTOM_ADDR_HIGH:16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_COMB_BOTTOM_ADDR_HIGH:16;
    unsigned int WR_COMB_UP_ADDR_HIGH:16;
#endif
} DTE_COMMON_REGS_DTE_WR_COMB_ADDR_HIGH_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_WR_COMB_ADDR_HIGH_t f;
} DTE_COMMON_REGS_DTE_WR_COMB_ADDR_HIGH_u;

#define DTE_COMMON_REGS_DTE_MAILBOX_OFFSET 0x0100
typedef struct _DTE_COMMON_REGS_DTE_MAILBOX_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_WR_ID:9;
    unsigned int MBX_UNIQ_ID:7;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int MBX_UNIQ_ID:7;
    unsigned int MBX_WR_ID:9;
#endif
} DTE_COMMON_REGS_DTE_MAILBOX_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_MAILBOX_t f;
} DTE_COMMON_REGS_DTE_MAILBOX_u;

#define DTE_COMMON_REGS_DTE_MBX_CFG_OFFSET 0x0104
typedef struct _DTE_COMMON_REGS_DTE_MBX_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_CFG_ID:9;
    unsigned int MBX_CFG_UNIQ_ID:7;
    unsigned int MBX_CFG_REF:11;
    unsigned int MBX_INC_MODE:1;
    unsigned int MBX_TRG_MODE:1;
    unsigned int MBX_CRE_MODE:1;
    unsigned int MBX_UPD_MODE:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_UPD_MODE:2;
    unsigned int MBX_CRE_MODE:1;
    unsigned int MBX_TRG_MODE:1;
    unsigned int MBX_INC_MODE:1;
    unsigned int MBX_CFG_REF:11;
    unsigned int MBX_CFG_UNIQ_ID:7;
    unsigned int MBX_CFG_ID:9;
#endif
} DTE_COMMON_REGS_DTE_MBX_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_MBX_CFG_t f;
} DTE_COMMON_REGS_DTE_MBX_CFG_u;

#define DTE_COMMON_REGS_DTE_MBX_GLB_CONFIG_OFFSET 0x0108
typedef struct _DTE_COMMON_REGS_DTE_MBX_GLB_CONFIG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_GLB_CONFIG:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int MBX_GLB_CONFIG:1;
#endif
} DTE_COMMON_REGS_DTE_MBX_GLB_CONFIG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_MBX_GLB_CONFIG_t f;
} DTE_COMMON_REGS_DTE_MBX_GLB_CONFIG_u;

#define DTE_COMMON_REGS_MBX_STATUS_SEL_OFFSET 0x010c
typedef struct _DTE_COMMON_REGS_MBX_STATUS_SEL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_STATUS_ID:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int MBX_STATUS_ID:16;
#endif
} DTE_COMMON_REGS_MBX_STATUS_SEL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_MBX_STATUS_SEL_t f;
} DTE_COMMON_REGS_MBX_STATUS_SEL_u;

#define DTE_COMMON_REGS_DTE_MBX_STATUS0_OFFSET 0x0110
typedef struct _DTE_COMMON_REGS_DTE_MBX_STATUS0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_STATUS0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_STATUS0:32;
#endif
} DTE_COMMON_REGS_DTE_MBX_STATUS0_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_MBX_STATUS0_t f;
} DTE_COMMON_REGS_DTE_MBX_STATUS0_u;

#define DTE_COMMON_REGS_DTE_MBX_STATUS1_OFFSET 0x0114
typedef struct _DTE_COMMON_REGS_DTE_MBX_STATUS1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_STATUS1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_STATUS1:32;
#endif
} DTE_COMMON_REGS_DTE_MBX_STATUS1_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_MBX_STATUS1_t f;
} DTE_COMMON_REGS_DTE_MBX_STATUS1_u;

#define DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_0_OFFSET 0x0118
typedef struct _DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BUS_CNTL_0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DBUS_BUS_CNTL_0:32;
#endif
} DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_0_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_0_t f;
} DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_0_u;

#define DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_1_OFFSET 0x011c
typedef struct _DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BUS_CNTL_1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DBUS_BUS_CNTL_1:32;
#endif
} DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_1_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_1_t f;
} DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_1_u;

#define DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_2_OFFSET 0x0120
typedef struct _DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BUS_CNTL_2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DBUS_BUS_CNTL_2:32;
#endif
} DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_2_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_2_t f;
} DTE_COMMON_REGS_DTE_DBUS_BUS_CNTL_2_u;

#define DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_0_OFFSET 0x0124
typedef struct _DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BIT_CNTL_0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DBUS_BIT_CNTL_0:32;
#endif
} DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_0_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_0_t f;
} DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_0_u;

#define DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_1_OFFSET 0x0128
typedef struct _DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BIT_CNTL_1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DBUS_BIT_CNTL_1:32;
#endif
} DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_1_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_1_t f;
} DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_1_u;

#define DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_2_OFFSET 0x012c
typedef struct _DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BIT_CNTL_2:31;
    unsigned int REG_DBUS_EN:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int REG_DBUS_EN:1;
    unsigned int DBUS_BIT_CNTL_2:31;
#endif
} DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_2_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_2_t f;
} DTE_COMMON_REGS_DTE_DBUS_BIT_CNTL_2_u;

#define DTE_COMMON_REGS_DTE_RESERVED_REG0_OFFSET 0x0130
typedef struct _DTE_COMMON_REGS_DTE_RESERVED_REG0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESERVED_REG0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RESERVED_REG0:32;
#endif
} DTE_COMMON_REGS_DTE_RESERVED_REG0_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_RESERVED_REG0_t f;
} DTE_COMMON_REGS_DTE_RESERVED_REG0_u;

#define DTE_COMMON_REGS_DTE_ENGINE_STATUS_OFFSET 0x0200
typedef struct _DTE_COMMON_REGS_DTE_ENGINE_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ENGINE_STATUS:1;
    unsigned int REG_SRAM_INIT_DONE:1;
    unsigned int STOP_STATUS:1;
    unsigned int :29;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :29;
    unsigned int STOP_STATUS:1;
    unsigned int REG_SRAM_INIT_DONE:1;
    unsigned int ENGINE_STATUS:1;
#endif
} DTE_COMMON_REGS_DTE_ENGINE_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ENGINE_STATUS_t f;
} DTE_COMMON_REGS_DTE_ENGINE_STATUS_u;

#define DTE_COMMON_REGS_DTE_INTERRUPT_STATUS_OFFSET 0x0204
typedef struct _DTE_COMMON_REGS_DTE_INTERRUPT_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_INT:1;
    unsigned int DATA_SRAM_ERR_PAR_INT:1;
    unsigned int REG_SRAM_ERR_PAR_INT:1;
    unsigned int ILL_PROG_INT:1;
    unsigned int MAILBOX_ERR_INT:1;
    unsigned int ILL_VC_CFG_INT:1;
    unsigned int :1;
    unsigned int RD_RESP_ERR_INT:1;
    unsigned int RD_DATA_PAR_ERR_INT:1;
    unsigned int :1;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_LOSS_INT:1;
    unsigned int SM4_XTS_ERR_INT:1;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int SM4_XTS_ERR_INT:1;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_LOSS_INT:1;
    unsigned int :1;
    unsigned int RD_DATA_PAR_ERR_INT:1;
    unsigned int RD_RESP_ERR_INT:1;
    unsigned int :1;
    unsigned int ILL_VC_CFG_INT:1;
    unsigned int MAILBOX_ERR_INT:1;
    unsigned int ILL_PROG_INT:1;
    unsigned int REG_SRAM_ERR_PAR_INT:1;
    unsigned int DATA_SRAM_ERR_PAR_INT:1;
    unsigned int TIMEOUT_INT:1;
#endif
} DTE_COMMON_REGS_DTE_INTERRUPT_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_INTERRUPT_STATUS_t f;
} DTE_COMMON_REGS_DTE_INTERRUPT_STATUS_u;

#define DTE_COMMON_REGS_DTE_INTERRUPT_CTRL_OFFSET 0x0208
typedef struct _DTE_COMMON_REGS_DTE_INTERRUPT_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_INT_EN:1;
    unsigned int DATA_SRAM_ERR_PAR_INT_EN:1;
    unsigned int REG_SRAM_ERR_PAR_INT_EN:1;
    unsigned int ILL_PROG_INT_EN:1;
    unsigned int MAILBOX_ERR_INT_EN:1;
    unsigned int ILL_VC_CFG_INT_EN:1;
    unsigned int :4;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_LOSS_INT_EN:1;
    unsigned int SM4_XTS_ERR_INT_EN:1;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int SM4_XTS_ERR_INT_EN:1;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_LOSS_INT_EN:1;
    unsigned int :4;
    unsigned int ILL_VC_CFG_INT_EN:1;
    unsigned int MAILBOX_ERR_INT_EN:1;
    unsigned int ILL_PROG_INT_EN:1;
    unsigned int REG_SRAM_ERR_PAR_INT_EN:1;
    unsigned int DATA_SRAM_ERR_PAR_INT_EN:1;
    unsigned int TIMEOUT_INT_EN:1;
#endif
} DTE_COMMON_REGS_DTE_INTERRUPT_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_INTERRUPT_CTRL_t f;
} DTE_COMMON_REGS_DTE_INTERRUPT_CTRL_u;

#define DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS_OFFSET 0x020c
typedef struct _DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS:32;
#endif
} DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS_t f;
} DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS_u;

#define DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS2_OFFSET 0x0210
typedef struct _DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS2:32;
#endif
} DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS2_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS2_t f;
} DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS2_u;

#define DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS_OFFSET 0x0214
typedef struct _DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS:32;
#endif
} DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS_t f;
} DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS_u;

#define DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS2_OFFSET 0x0218
typedef struct _DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS2:32;
#endif
} DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS2_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS2_t f;
} DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS2_u;

#define DTE_COMMON_REGS_DTE_DEBUG_MISC_CTRL_OFFSET 0x021c
typedef struct _DTE_COMMON_REGS_DTE_DEBUG_MISC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ERR_STOP_EXE_EN:1;
    unsigned int :3;
    unsigned int DBG_PROF_EN:1;
    unsigned int :1;
    unsigned int DBG_PROF_CMD_START_EVENT_EN:1;
    unsigned int DBG_PROF_CMD_TRANS_DONE_EVENT_EN:1;
    unsigned int :2;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_EN:1;
    unsigned int :21;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :21;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_EN:1;
    unsigned int :2;
    unsigned int DBG_PROF_CMD_TRANS_DONE_EVENT_EN:1;
    unsigned int DBG_PROF_CMD_START_EVENT_EN:1;
    unsigned int :1;
    unsigned int DBG_PROF_EN:1;
    unsigned int :3;
    unsigned int ERR_STOP_EXE_EN:1;
#endif
} DTE_COMMON_REGS_DTE_DEBUG_MISC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DEBUG_MISC_CTRL_t f;
} DTE_COMMON_REGS_DTE_DEBUG_MISC_CTRL_u;

#define DTE_COMMON_REGS_DTE_MAILBOX_ERR_RPT0_OFFSET 0x0220
typedef struct _DTE_COMMON_REGS_DTE_MAILBOX_ERR_RPT0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_ERR_CODE0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_ERR_CODE0:32;
#endif
} DTE_COMMON_REGS_DTE_MAILBOX_ERR_RPT0_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_MAILBOX_ERR_RPT0_t f;
} DTE_COMMON_REGS_DTE_MAILBOX_ERR_RPT0_u;

#define DTE_COMMON_REGS_DTE_MAILBOX_ERR_RPT1_OFFSET 0x0224
typedef struct _DTE_COMMON_REGS_DTE_MAILBOX_ERR_RPT1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_ERR_CODE1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_ERR_CODE1:32;
#endif
} DTE_COMMON_REGS_DTE_MAILBOX_ERR_RPT1_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_MAILBOX_ERR_RPT1_t f;
} DTE_COMMON_REGS_DTE_MAILBOX_ERR_RPT1_u;

#define DTE_COMMON_REGS_DTE_RESERVED_REG1_OFFSET 0x0228
typedef struct _DTE_COMMON_REGS_DTE_RESERVED_REG1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESERVED_REG1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RESERVED_REG1:32;
#endif
} DTE_COMMON_REGS_DTE_RESERVED_REG1_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_RESERVED_REG1_t f;
} DTE_COMMON_REGS_DTE_RESERVED_REG1_u;

#define DTE_COMMON_REGS_DTE_REG_SRAM_PARITY_ERR_LOG_OFFSET 0x022c
typedef struct _DTE_COMMON_REGS_DTE_REG_SRAM_PARITY_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int REG_SRAM_ERR_READ_ADDR:12;
    unsigned int REG_SRAM_ERR_INDEX:16;
    unsigned int :4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :4;
    unsigned int REG_SRAM_ERR_INDEX:16;
    unsigned int REG_SRAM_ERR_READ_ADDR:12;
#endif
} DTE_COMMON_REGS_DTE_REG_SRAM_PARITY_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_REG_SRAM_PARITY_ERR_LOG_t f;
} DTE_COMMON_REGS_DTE_REG_SRAM_PARITY_ERR_LOG_u;

#define DTE_COMMON_REGS_DTE_DATA_SRAM_PARITY_ERR_LOG_OFFSET 0x0230
typedef struct _DTE_COMMON_REGS_DTE_DATA_SRAM_PARITY_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DATA_SRAM_TYPE:1;
    unsigned int DATA_SRAM_ERR_READ_ADDR:11;
    unsigned int DATA_SRAM_ERR_INDEX:16;
    unsigned int DATA_SRAM_ERR_THD_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DATA_SRAM_ERR_THD_ID:4;
    unsigned int DATA_SRAM_ERR_INDEX:16;
    unsigned int DATA_SRAM_ERR_READ_ADDR:11;
    unsigned int DATA_SRAM_TYPE:1;
#endif
} DTE_COMMON_REGS_DTE_DATA_SRAM_PARITY_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DATA_SRAM_PARITY_ERR_LOG_t f;
} DTE_COMMON_REGS_DTE_DATA_SRAM_PARITY_ERR_LOG_u;

#define DTE_COMMON_REGS_DTE_ILL_VC_CFG_ERR_LOG0_OFFSET 0x0234
typedef struct _DTE_COMMON_REGS_DTE_ILL_VC_CFG_ERR_LOG0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ILL_VC_CFG_REG_ADDR:30;
    unsigned int :2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :2;
    unsigned int ILL_VC_CFG_REG_ADDR:30;
#endif
} DTE_COMMON_REGS_DTE_ILL_VC_CFG_ERR_LOG0_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ILL_VC_CFG_ERR_LOG0_t f;
} DTE_COMMON_REGS_DTE_ILL_VC_CFG_ERR_LOG0_u;

#define DTE_COMMON_REGS_DTE_ILL_VC_CFG_ERR_LOG1_OFFSET 0x0238
typedef struct _DTE_COMMON_REGS_DTE_ILL_VC_CFG_ERR_LOG1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ILL_VC_CFG_REG_MASTER_ID:20;
    unsigned int ILL_VC_CFG_REG_VC_ID:8;
    unsigned int :4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :4;
    unsigned int ILL_VC_CFG_REG_VC_ID:8;
    unsigned int ILL_VC_CFG_REG_MASTER_ID:20;
#endif
} DTE_COMMON_REGS_DTE_ILL_VC_CFG_ERR_LOG1_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ILL_VC_CFG_ERR_LOG1_t f;
} DTE_COMMON_REGS_DTE_ILL_VC_CFG_ERR_LOG1_u;

#define DTE_COMMON_REGS_DTE_TIMEOUT_ERR_LOG_OFFSET 0x023c
typedef struct _DTE_COMMON_REGS_DTE_TIMEOUT_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_VC_ID:8;
    unsigned int TIMEOUT_THD_ID:3;
    unsigned int :21;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :21;
    unsigned int TIMEOUT_THD_ID:3;
    unsigned int TIMEOUT_VC_ID:8;
#endif
} DTE_COMMON_REGS_DTE_TIMEOUT_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_TIMEOUT_ERR_LOG_t f;
} DTE_COMMON_REGS_DTE_TIMEOUT_ERR_LOG_u;

#define DTE_COMMON_REGS_DTE_ILL_PROG_ERR_LOG_OFFSET 0x0240
typedef struct _DTE_COMMON_REGS_DTE_ILL_PROG_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ILL_PROG_TYPE:4;
    unsigned int ILL_PROG_VC_ID:8;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int ILL_PROG_VC_ID:8;
    unsigned int ILL_PROG_TYPE:4;
#endif
} DTE_COMMON_REGS_DTE_ILL_PROG_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ILL_PROG_ERR_LOG_t f;
} DTE_COMMON_REGS_DTE_ILL_PROG_ERR_LOG_u;

#define DTE_COMMON_REGS_DTE_DBG_THD0_POSITION_OFFSET 0x0244
typedef struct _DTE_COMMON_REGS_DTE_DBG_THD0_POSITION_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int THD0_POSITION:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int THD0_POSITION:32;
#endif
} DTE_COMMON_REGS_DTE_DBG_THD0_POSITION_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBG_THD0_POSITION_t f;
} DTE_COMMON_REGS_DTE_DBG_THD0_POSITION_u;

#define DTE_COMMON_REGS_DTE_DBG_THD1_POSITION_OFFSET 0x0248
typedef struct _DTE_COMMON_REGS_DTE_DBG_THD1_POSITION_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int THD1_POSITION:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int THD1_POSITION:32;
#endif
} DTE_COMMON_REGS_DTE_DBG_THD1_POSITION_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBG_THD1_POSITION_t f;
} DTE_COMMON_REGS_DTE_DBG_THD1_POSITION_u;

#define DTE_COMMON_REGS_DTE_DBG_THD2_POSITION_OFFSET 0x024c
typedef struct _DTE_COMMON_REGS_DTE_DBG_THD2_POSITION_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int THD2_POSITION:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int THD2_POSITION:32;
#endif
} DTE_COMMON_REGS_DTE_DBG_THD2_POSITION_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBG_THD2_POSITION_t f;
} DTE_COMMON_REGS_DTE_DBG_THD2_POSITION_u;

#define DTE_COMMON_REGS_DTE_DBG_THD3_POSITION_OFFSET 0x0250
typedef struct _DTE_COMMON_REGS_DTE_DBG_THD3_POSITION_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int THD3_POSITION:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int THD3_POSITION:32;
#endif
} DTE_COMMON_REGS_DTE_DBG_THD3_POSITION_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBG_THD3_POSITION_t f;
} DTE_COMMON_REGS_DTE_DBG_THD3_POSITION_u;

#define DTE_COMMON_REGS_DTE_DBG_THD_POSITION_H_OFFSET 0x0254
typedef struct _DTE_COMMON_REGS_DTE_DBG_THD_POSITION_H_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int THD0_POSITION_H:2;
    unsigned int THD1_POSITION_H:2;
    unsigned int THD2_POSITION_H:2;
    unsigned int THD3_POSITION_H:2;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int THD3_POSITION_H:2;
    unsigned int THD2_POSITION_H:2;
    unsigned int THD1_POSITION_H:2;
    unsigned int THD0_POSITION_H:2;
#endif
} DTE_COMMON_REGS_DTE_DBG_THD_POSITION_H_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_DBG_THD_POSITION_H_t f;
} DTE_COMMON_REGS_DTE_DBG_THD_POSITION_H_u;

#define DTE_COMMON_REGS_DTE_RD_RESP_ERR_LOG_OFFSET 0x0258
typedef struct _DTE_COMMON_REGS_DTE_RD_RESP_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_RESP_ERR_THD_ID:4;
    unsigned int RD_RESP_ERR_CTXT_ID:4;
    unsigned int RD_RESP_ERR_VC_ID:8;
    unsigned int RD_RESP_ERR_RUSER:4;
    unsigned int RD_RESP_ERR_RRESP:2;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int RD_RESP_ERR_RRESP:2;
    unsigned int RD_RESP_ERR_RUSER:4;
    unsigned int RD_RESP_ERR_VC_ID:8;
    unsigned int RD_RESP_ERR_CTXT_ID:4;
    unsigned int RD_RESP_ERR_THD_ID:4;
#endif
} DTE_COMMON_REGS_DTE_RD_RESP_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_RD_RESP_ERR_LOG_t f;
} DTE_COMMON_REGS_DTE_RD_RESP_ERR_LOG_u;

#define DTE_COMMON_REGS_DTE_RD_DATA_PAR_ERR_LOG_OFFSET 0x025c
typedef struct _DTE_COMMON_REGS_DTE_RD_DATA_PAR_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_DATA_PAR_ERR_THD_ID:4;
    unsigned int RD_DATA_PAR_ERR_CTXT_ID:4;
    unsigned int RD_DATA_PAR_ERR_VC_ID:8;
    unsigned int RD_DATA_PAR_ERR_RUSER:4;
    unsigned int RD_DATA_PAR_ERR_RRESP:2;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int RD_DATA_PAR_ERR_RRESP:2;
    unsigned int RD_DATA_PAR_ERR_RUSER:4;
    unsigned int RD_DATA_PAR_ERR_VC_ID:8;
    unsigned int RD_DATA_PAR_ERR_CTXT_ID:4;
    unsigned int RD_DATA_PAR_ERR_THD_ID:4;
#endif
} DTE_COMMON_REGS_DTE_RD_DATA_PAR_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_RD_DATA_PAR_ERR_LOG_t f;
} DTE_COMMON_REGS_DTE_RD_DATA_PAR_ERR_LOG_u;

#define DTE_COMMON_REGS_DTE_VC_DECRYPT_ERR_LOG_OFFSET 0x0260
typedef struct _DTE_COMMON_REGS_DTE_VC_DECRYPT_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_DECRYPT_ERR_LOG:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC_DECRYPT_ERR_LOG:32;
#endif
} DTE_COMMON_REGS_DTE_VC_DECRYPT_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_VC_DECRYPT_ERR_LOG_t f;
} DTE_COMMON_REGS_DTE_VC_DECRYPT_ERR_LOG_u;

#define DTE_COMMON_REGS_DTE_SIG_SEND_STATUS_OFFSET 0x0264
typedef struct _DTE_COMMON_REGS_DTE_SIG_SEND_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DTE2SA_SIG_REQ:1;
    unsigned int SA2DTE_SIG_RCVD_BUSY:1;
    unsigned int SIG_FIFO_NOT_FULL:1;
    unsigned int SIG_FIFO_NOT_EMPTY:1;
    unsigned int SIG_CUR_STATE:2;
    unsigned int DTE2SA_GSYNC_REQ:1;
    unsigned int SA2DTE_GSYNC_RCVD_BUSY:1;
    unsigned int GSYNC_WORK_STATUS:1;
    unsigned int :23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :23;
    unsigned int GSYNC_WORK_STATUS:1;
    unsigned int SA2DTE_GSYNC_RCVD_BUSY:1;
    unsigned int DTE2SA_GSYNC_REQ:1;
    unsigned int SIG_CUR_STATE:2;
    unsigned int SIG_FIFO_NOT_EMPTY:1;
    unsigned int SIG_FIFO_NOT_FULL:1;
    unsigned int SA2DTE_SIG_RCVD_BUSY:1;
    unsigned int DTE2SA_SIG_REQ:1;
#endif
} DTE_COMMON_REGS_DTE_SIG_SEND_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_SIG_SEND_STATUS_t f;
} DTE_COMMON_REGS_DTE_SIG_SEND_STATUS_u;

#define DTE_COMMON_REGS_DTE_RESERVED_REG2_OFFSET 0x0268
typedef struct _DTE_COMMON_REGS_DTE_RESERVED_REG2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESERVED_REG2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RESERVED_REG2:32;
#endif
} DTE_COMMON_REGS_DTE_RESERVED_REG2_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_RESERVED_REG2_t f;
} DTE_COMMON_REGS_DTE_RESERVED_REG2_u;

#define DTE_COMMON_REGS_DTE_THD0_RD_STATUS_OFFSET 0x026c
typedef struct _DTE_COMMON_REGS_DTE_THD0_RD_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int BUF_OVFL:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_RREADY:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RPIPE_RREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int BUF_OVFL:1;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
#endif
} DTE_COMMON_REGS_DTE_THD0_RD_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD0_RD_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD0_RD_STATUS_u;

#define DTE_COMMON_REGS_DTE_THD0_WR_STATUS_OFFSET 0x0270
typedef struct _DTE_COMMON_REGS_DTE_THD0_WR_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WPIPE_PEND_CMD_NUM:3;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_WREADY:1;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WPIPE_WREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_PEND_CMD_NUM:3;
#endif
} DTE_COMMON_REGS_DTE_THD0_WR_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD0_WR_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD0_WR_STATUS_u;

#define DTE_COMMON_REGS_DTE_THD1_RD_STATUS_OFFSET 0x0274
typedef struct _DTE_COMMON_REGS_DTE_THD1_RD_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int BUF_OVFL:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_RREADY:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RPIPE_RREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int BUF_OVFL:1;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
#endif
} DTE_COMMON_REGS_DTE_THD1_RD_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD1_RD_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD1_RD_STATUS_u;

#define DTE_COMMON_REGS_DTE_THD1_WR_STATUS_OFFSET 0x0278
typedef struct _DTE_COMMON_REGS_DTE_THD1_WR_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WPIPE_PEND_CMD_NUM:3;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_WREADY:1;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WPIPE_WREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_PEND_CMD_NUM:3;
#endif
} DTE_COMMON_REGS_DTE_THD1_WR_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD1_WR_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD1_WR_STATUS_u;

#define DTE_COMMON_REGS_DTE_THD2_RD_STATUS_OFFSET 0x027c
typedef struct _DTE_COMMON_REGS_DTE_THD2_RD_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int BUF_OVFL:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_RREADY:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RPIPE_RREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int BUF_OVFL:1;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
#endif
} DTE_COMMON_REGS_DTE_THD2_RD_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD2_RD_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD2_RD_STATUS_u;

#define DTE_COMMON_REGS_DTE_THD2_WR_STATUS_OFFSET 0x0280
typedef struct _DTE_COMMON_REGS_DTE_THD2_WR_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WPIPE_PEND_CMD_NUM:3;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_WREADY:1;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WPIPE_WREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_PEND_CMD_NUM:3;
#endif
} DTE_COMMON_REGS_DTE_THD2_WR_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD2_WR_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD2_WR_STATUS_u;

#define DTE_COMMON_REGS_DTE_THD3_RD_STATUS_OFFSET 0x0284
typedef struct _DTE_COMMON_REGS_DTE_THD3_RD_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int BUF_OVFL:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_RREADY:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RPIPE_RREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int BUF_OVFL:1;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
#endif
} DTE_COMMON_REGS_DTE_THD3_RD_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD3_RD_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD3_RD_STATUS_u;

#define DTE_COMMON_REGS_DTE_THD3_WR_STATUS_OFFSET 0x0288
typedef struct _DTE_COMMON_REGS_DTE_THD3_WR_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WPIPE_PEND_CMD_NUM:3;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_WREADY:1;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WPIPE_WREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_PEND_CMD_NUM:3;
#endif
} DTE_COMMON_REGS_DTE_THD3_WR_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD3_WR_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD3_WR_STATUS_u;

#define DTE_COMMON_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_CNT_OFFSET 0x028c
typedef struct _DTE_COMMON_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_CNT_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CUS_TRACE_ME_LOSS_CNT:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CUS_TRACE_ME_LOSS_CNT:32;
#endif
} DTE_COMMON_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_CNT_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_CNT_t f;
} DTE_COMMON_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_CNT_u;

#define DTE_COMMON_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_ERR_LOG_OFFSET 0x0290
typedef struct _DTE_COMMON_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CUS_TRACE_MES_LOSS_INT_PRCS_ID:16;
    unsigned int CUS_TRACE_MES_LOSS_INT_VC_ID:8;
    unsigned int CUS_TRACE_MES_LOSS_INT_CTXT_ID:4;
    unsigned int :4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :4;
    unsigned int CUS_TRACE_MES_LOSS_INT_CTXT_ID:4;
    unsigned int CUS_TRACE_MES_LOSS_INT_VC_ID:8;
    unsigned int CUS_TRACE_MES_LOSS_INT_PRCS_ID:16;
#endif
} DTE_COMMON_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_ERR_LOG_t f;
} DTE_COMMON_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_ERR_LOG_u;

#define DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_CFG_OFFSET 0x0294
typedef struct _DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_FORCE_TRIG:1;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG:1;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG:1;
    unsigned int ILL_PROG_FORCE_TRIG:1;
    unsigned int MAILBOX_ERR_FORCE_TRIG:1;
    unsigned int ILL_VC_CFG_FORCE_TRIG:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int ILL_VC_CFG_FORCE_TRIG:1;
    unsigned int MAILBOX_ERR_FORCE_TRIG:1;
    unsigned int ILL_PROG_FORCE_TRIG:1;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG:1;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG:1;
    unsigned int TIMEOUT_FORCE_TRIG:1;
#endif
} DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_CFG_t f;
} DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_CFG_u;

#define DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_CTXT_ID_CFG_OFFSET 0x0298
typedef struct _DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_CTXT_ID_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_FORCE_TRIG_CTXT_ID:4;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_CTXT_ID:4;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_CTXT_ID:4;
    unsigned int ILL_PROG_FORCE_TRIG_CTXT_ID:4;
    unsigned int MAILBOX_ERR_FORCE_TRIG_CTXT_ID:4;
    unsigned int ILL_VC_CFG_FORCE_TRIG_CTXT_ID:4;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int ILL_VC_CFG_FORCE_TRIG_CTXT_ID:4;
    unsigned int MAILBOX_ERR_FORCE_TRIG_CTXT_ID:4;
    unsigned int ILL_PROG_FORCE_TRIG_CTXT_ID:4;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_CTXT_ID:4;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_CTXT_ID:4;
    unsigned int TIMEOUT_FORCE_TRIG_CTXT_ID:4;
#endif
} DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_CTXT_ID_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_CTXT_ID_CFG_t f;
} DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_CTXT_ID_CFG_u;

#define DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_ASID_CFG_OFFSET 0x029c
typedef struct _DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_ASID_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_FORCE_TRIG_ASID:4;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_ASID:4;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_ASID:4;
    unsigned int ILL_PROG_FORCE_TRIG_ASID:4;
    unsigned int MAILBOX_ERR_FORCE_TRIG_ASID:4;
    unsigned int ILL_VC_CFG_FORCE_TRIG_ASID:4;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int ILL_VC_CFG_FORCE_TRIG_ASID:4;
    unsigned int MAILBOX_ERR_FORCE_TRIG_ASID:4;
    unsigned int ILL_PROG_FORCE_TRIG_ASID:4;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_ASID:4;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_ASID:4;
    unsigned int TIMEOUT_FORCE_TRIG_ASID:4;
#endif
} DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_ASID_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_ASID_CFG_t f;
} DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_ASID_CFG_u;

#define DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_MODE_CFG_OFFSET 0x02a0
typedef struct _DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_MODE_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_FORCE_TRIG_MODE:1;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_MODE:1;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_MODE:1;
    unsigned int ILL_PROG_FORCE_TRIG_MODE:1;
    unsigned int MAILBOX_ERR_FORCE_TRIG_MODE:1;
    unsigned int ILL_VC_CFG_FORCE_TRIG_MODE:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int ILL_VC_CFG_FORCE_TRIG_MODE:1;
    unsigned int MAILBOX_ERR_FORCE_TRIG_MODE:1;
    unsigned int ILL_PROG_FORCE_TRIG_MODE:1;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_MODE:1;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_MODE:1;
    unsigned int TIMEOUT_FORCE_TRIG_MODE:1;
#endif
} DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_MODE_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_MODE_CFG_t f;
} DTE_COMMON_REGS_DTE_FORCE_TRIG_INT_MODE_CFG_u;

#define DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS3_OFFSET 0x02a4
typedef struct _DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS3:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS3:32;
#endif
} DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS3_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS3_t f;
} DTE_COMMON_REGS_DTE_ALL_VC_BUSY_STATUS3_u;

#define DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS3_OFFSET 0x02a8
typedef struct _DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS3:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS3:32;
#endif
} DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS3_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS3_t f;
} DTE_COMMON_REGS_DTE_ALL_VC_OCCUPY_STATUS3_u;

#define DTE_COMMON_REGS_DTE_THD0_RSHP_STATUS_OFFSET 0x02ac
typedef struct _DTE_COMMON_REGS_DTE_THD0_RSHP_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
#endif
} DTE_COMMON_REGS_DTE_THD0_RSHP_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD0_RSHP_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD0_RSHP_STATUS_u;

#define DTE_COMMON_REGS_DTE_THD1_RSHP_STATUS_OFFSET 0x02b0
typedef struct _DTE_COMMON_REGS_DTE_THD1_RSHP_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
#endif
} DTE_COMMON_REGS_DTE_THD1_RSHP_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD1_RSHP_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD1_RSHP_STATUS_u;

#define DTE_COMMON_REGS_DTE_THD2_RSHP_STATUS_OFFSET 0x02b4
typedef struct _DTE_COMMON_REGS_DTE_THD2_RSHP_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
#endif
} DTE_COMMON_REGS_DTE_THD2_RSHP_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD2_RSHP_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD2_RSHP_STATUS_u;

#define DTE_COMMON_REGS_DTE_THD3_RSHP_STATUS_OFFSET 0x02b8
typedef struct _DTE_COMMON_REGS_DTE_THD3_RSHP_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
#endif
} DTE_COMMON_REGS_DTE_THD3_RSHP_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_THD3_RSHP_STATUS_t f;
} DTE_COMMON_REGS_DTE_THD3_RSHP_STATUS_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_EN_WR_OFFSET 0x0400
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_EN_WR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_EN_WR:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int PORT0_THROTTLE_EN_WR:1;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_EN_WR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_EN_WR_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_EN_WR_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_EN_OFFSET 0x0404
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_EN_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_W_OST_EN:1;
    unsigned int PORT0_THROTTLE_W_BW_EN:1;
    unsigned int PORT0_THROTTLE_R_OST_EN:1;
    unsigned int PORT0_THROTTLE_R_BW_EN:1;
    unsigned int PORT0_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT0_THROTTLE_R_OSTLEN_EN:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int PORT0_THROTTLE_R_OSTLEN_EN:1;
    unsigned int PORT0_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT0_THROTTLE_R_BW_EN:1;
    unsigned int PORT0_THROTTLE_R_OST_EN:1;
    unsigned int PORT0_THROTTLE_W_BW_EN:1;
    unsigned int PORT0_THROTTLE_W_OST_EN:1;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_EN_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_EN_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_EN_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_W_OST_THR_OFFSET 0x0408
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_W_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_W_OST_THR:10;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int PORT0_THROTTLE_W_OST_THR:10;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_W_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_W_OST_THR_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_W_OST_THR_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_W_BW_THR_OFFSET 0x040c
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_W_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_W_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT0_THROTTLE_W_BW_THR:25;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_W_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_W_BW_THR_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_W_BW_THR_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_R_OST_THR_OFFSET 0x0410
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_R_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_R_OST_THR:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int PORT0_THROTTLE_R_OST_THR:16;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_R_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_R_OST_THR_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_R_OST_THR_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_R_BW_THR_OFFSET 0x0414
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_R_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_R_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT0_THROTTLE_R_BW_THR:25;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_R_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_R_BW_THR_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_R_BW_THR_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_TW_OFFSET 0x0418
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_TW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_TW:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT0_THROTTLE_TW:25;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_TW_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_TW_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_TW_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_OST_NUM_OFFSET 0x041c
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_OST_NUM_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_W_OST_NUM:10;
    unsigned int PORT0_R_OST_NUM:16;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT0_R_OST_NUM:16;
    unsigned int PORT0_W_OST_NUM:10;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_OST_NUM_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_OST_NUM_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_OST_NUM_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_OST_UDFL_OVFL_OFFSET 0x0420
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_OST_UDFL_OVFL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_W_OST_UDFL:1;
    unsigned int PORT0_W_OST_OVFL:1;
    unsigned int PORT0_R_OST_UDFL:1;
    unsigned int PORT0_R_OST_OVFL:1;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int PORT0_R_OST_OVFL:1;
    unsigned int PORT0_R_OST_UDFL:1;
    unsigned int PORT0_W_OST_OVFL:1;
    unsigned int PORT0_W_OST_UDFL:1;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_OST_UDFL_OVFL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_OST_UDFL_OVFL_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_OST_UDFL_OVFL_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_AW_OFFSET 0x0424
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_AW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_W_BW_NUM_AW:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT0_W_BW_NUM_AW:26;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_AW_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_AW_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_AW_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_W_OFFSET 0x0428
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_W_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_W_BW_NUM_W:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT0_W_BW_NUM_W:26;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_W_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_W_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_W_u;

#define DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_R_OFFSET 0x042c
typedef struct _DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_R_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_R_BW_NUM_AR:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT0_R_BW_NUM_AR:26;
#endif
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_R_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_R_t f;
} DTE_COMMON_REGS_DTE_PORT0_THROTTLE_BW_NUM_R_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_EN_WR_OFFSET 0x0430
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_EN_WR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_EN_WR:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int PORT1_THROTTLE_EN_WR:1;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_EN_WR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_EN_WR_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_EN_WR_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_EN_OFFSET 0x0434
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_EN_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_W_OST_EN:1;
    unsigned int PORT1_THROTTLE_W_BW_EN:1;
    unsigned int PORT1_THROTTLE_R_OST_EN:1;
    unsigned int PORT1_THROTTLE_R_BW_EN:1;
    unsigned int PORT1_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT1_THROTTLE_R_OSTLEN_EN:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int PORT1_THROTTLE_R_OSTLEN_EN:1;
    unsigned int PORT1_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT1_THROTTLE_R_BW_EN:1;
    unsigned int PORT1_THROTTLE_R_OST_EN:1;
    unsigned int PORT1_THROTTLE_W_BW_EN:1;
    unsigned int PORT1_THROTTLE_W_OST_EN:1;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_EN_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_EN_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_EN_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_W_OST_THR_OFFSET 0x0438
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_W_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_W_OST_THR:10;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int PORT1_THROTTLE_W_OST_THR:10;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_W_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_W_OST_THR_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_W_OST_THR_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_W_BW_THR_OFFSET 0x043c
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_W_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_W_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT1_THROTTLE_W_BW_THR:25;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_W_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_W_BW_THR_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_W_BW_THR_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_R_OST_THR_OFFSET 0x0440
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_R_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_R_OST_THR:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int PORT1_THROTTLE_R_OST_THR:16;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_R_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_R_OST_THR_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_R_OST_THR_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_R_BW_THR_OFFSET 0x0444
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_R_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_R_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT1_THROTTLE_R_BW_THR:25;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_R_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_R_BW_THR_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_R_BW_THR_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_TW_OFFSET 0x0448
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_TW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_TW:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT1_THROTTLE_TW:25;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_TW_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_TW_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_TW_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_OST_NUM_OFFSET 0x044c
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_OST_NUM_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_W_OST_NUM:10;
    unsigned int PORT1_R_OST_NUM:16;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT1_R_OST_NUM:16;
    unsigned int PORT1_W_OST_NUM:10;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_OST_NUM_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_OST_NUM_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_OST_NUM_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_OST_UDFL_OVFL_OFFSET 0x0450
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_OST_UDFL_OVFL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_W_OST_UDFL:1;
    unsigned int PORT1_W_OST_OVFL:1;
    unsigned int PORT1_R_OST_UDFL:1;
    unsigned int PORT1_R_OST_OVFL:1;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int PORT1_R_OST_OVFL:1;
    unsigned int PORT1_R_OST_UDFL:1;
    unsigned int PORT1_W_OST_OVFL:1;
    unsigned int PORT1_W_OST_UDFL:1;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_OST_UDFL_OVFL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_OST_UDFL_OVFL_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_OST_UDFL_OVFL_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_AW_OFFSET 0x0454
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_AW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_W_BW_NUM_AW:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT1_W_BW_NUM_AW:26;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_AW_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_AW_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_AW_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_W_OFFSET 0x0458
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_W_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_W_BW_NUM_W:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT1_W_BW_NUM_W:26;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_W_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_W_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_W_u;

#define DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_R_OFFSET 0x045c
typedef struct _DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_R_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_R_BW_NUM_AR:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT1_R_BW_NUM_AR:26;
#endif
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_R_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_R_t f;
} DTE_COMMON_REGS_DTE_PORT1_THROTTLE_BW_NUM_R_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_EN_WR_OFFSET 0x0460
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_EN_WR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_EN_WR:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int PORT2_THROTTLE_EN_WR:1;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_EN_WR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_EN_WR_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_EN_WR_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_EN_OFFSET 0x0464
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_EN_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_W_OST_EN:1;
    unsigned int PORT2_THROTTLE_W_BW_EN:1;
    unsigned int PORT2_THROTTLE_R_OST_EN:1;
    unsigned int PORT2_THROTTLE_R_BW_EN:1;
    unsigned int PORT2_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT2_THROTTLE_R_OSTLEN_EN:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int PORT2_THROTTLE_R_OSTLEN_EN:1;
    unsigned int PORT2_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT2_THROTTLE_R_BW_EN:1;
    unsigned int PORT2_THROTTLE_R_OST_EN:1;
    unsigned int PORT2_THROTTLE_W_BW_EN:1;
    unsigned int PORT2_THROTTLE_W_OST_EN:1;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_EN_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_EN_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_EN_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_W_OST_THR_OFFSET 0x0468
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_W_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_W_OST_THR:10;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int PORT2_THROTTLE_W_OST_THR:10;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_W_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_W_OST_THR_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_W_OST_THR_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_W_BW_THR_OFFSET 0x046c
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_W_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_W_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT2_THROTTLE_W_BW_THR:25;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_W_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_W_BW_THR_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_W_BW_THR_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_R_OST_THR_OFFSET 0x0470
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_R_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_R_OST_THR:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int PORT2_THROTTLE_R_OST_THR:16;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_R_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_R_OST_THR_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_R_OST_THR_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_R_BW_THR_OFFSET 0x0474
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_R_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_R_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT2_THROTTLE_R_BW_THR:25;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_R_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_R_BW_THR_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_R_BW_THR_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_TW_OFFSET 0x0478
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_TW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_TW:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT2_THROTTLE_TW:25;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_TW_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_TW_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_TW_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_OST_NUM_OFFSET 0x047c
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_OST_NUM_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_W_OST_NUM:10;
    unsigned int PORT2_R_OST_NUM:16;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT2_R_OST_NUM:16;
    unsigned int PORT2_W_OST_NUM:10;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_OST_NUM_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_OST_NUM_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_OST_NUM_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_OST_UDFL_OVFL_OFFSET 0x0480
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_OST_UDFL_OVFL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_W_OST_UDFL:1;
    unsigned int PORT2_W_OST_OVFL:1;
    unsigned int PORT2_R_OST_UDFL:1;
    unsigned int PORT2_R_OST_OVFL:1;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int PORT2_R_OST_OVFL:1;
    unsigned int PORT2_R_OST_UDFL:1;
    unsigned int PORT2_W_OST_OVFL:1;
    unsigned int PORT2_W_OST_UDFL:1;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_OST_UDFL_OVFL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_OST_UDFL_OVFL_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_OST_UDFL_OVFL_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_AW_OFFSET 0x0484
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_AW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_W_BW_NUM_AW:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT2_W_BW_NUM_AW:26;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_AW_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_AW_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_AW_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_W_OFFSET 0x0488
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_W_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_W_BW_NUM_W:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT2_W_BW_NUM_W:26;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_W_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_W_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_W_u;

#define DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_R_OFFSET 0x048c
typedef struct _DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_R_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_R_BW_NUM_AR:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT2_R_BW_NUM_AR:26;
#endif
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_R_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_R_t f;
} DTE_COMMON_REGS_DTE_PORT2_THROTTLE_BW_NUM_R_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_EN_WR_OFFSET 0x0490
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_EN_WR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_EN_WR:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int PORT3_THROTTLE_EN_WR:1;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_EN_WR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_EN_WR_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_EN_WR_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_EN_OFFSET 0x0494
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_EN_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_W_OST_EN:1;
    unsigned int PORT3_THROTTLE_W_BW_EN:1;
    unsigned int PORT3_THROTTLE_R_OST_EN:1;
    unsigned int PORT3_THROTTLE_R_BW_EN:1;
    unsigned int PORT3_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT3_THROTTLE_R_OSTLEN_EN:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int PORT3_THROTTLE_R_OSTLEN_EN:1;
    unsigned int PORT3_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT3_THROTTLE_R_BW_EN:1;
    unsigned int PORT3_THROTTLE_R_OST_EN:1;
    unsigned int PORT3_THROTTLE_W_BW_EN:1;
    unsigned int PORT3_THROTTLE_W_OST_EN:1;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_EN_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_EN_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_EN_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_W_OST_THR_OFFSET 0x0498
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_W_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_W_OST_THR:10;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int PORT3_THROTTLE_W_OST_THR:10;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_W_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_W_OST_THR_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_W_OST_THR_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_W_BW_THR_OFFSET 0x049c
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_W_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_W_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT3_THROTTLE_W_BW_THR:25;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_W_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_W_BW_THR_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_W_BW_THR_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_R_OST_THR_OFFSET 0x04a0
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_R_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_R_OST_THR:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int PORT3_THROTTLE_R_OST_THR:16;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_R_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_R_OST_THR_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_R_OST_THR_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_R_BW_THR_OFFSET 0x04a4
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_R_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_R_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT3_THROTTLE_R_BW_THR:25;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_R_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_R_BW_THR_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_R_BW_THR_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_TW_OFFSET 0x04a8
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_TW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_TW:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT3_THROTTLE_TW:25;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_TW_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_TW_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_TW_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_OST_NUM_OFFSET 0x04ac
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_OST_NUM_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_W_OST_NUM:10;
    unsigned int PORT3_R_OST_NUM:16;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT3_R_OST_NUM:16;
    unsigned int PORT3_W_OST_NUM:10;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_OST_NUM_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_OST_NUM_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_OST_NUM_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_OST_UDFL_OVFL_OFFSET 0x04b0
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_OST_UDFL_OVFL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_W_OST_UDFL:1;
    unsigned int PORT3_W_OST_OVFL:1;
    unsigned int PORT3_R_OST_UDFL:1;
    unsigned int PORT3_R_OST_OVFL:1;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int PORT3_R_OST_OVFL:1;
    unsigned int PORT3_R_OST_UDFL:1;
    unsigned int PORT3_W_OST_OVFL:1;
    unsigned int PORT3_W_OST_UDFL:1;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_OST_UDFL_OVFL_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_OST_UDFL_OVFL_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_OST_UDFL_OVFL_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_AW_OFFSET 0x04b4
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_AW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_W_BW_NUM_AW:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT3_W_BW_NUM_AW:26;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_AW_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_AW_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_AW_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_W_OFFSET 0x04b8
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_W_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_W_BW_NUM_W:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT3_W_BW_NUM_W:26;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_W_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_W_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_W_u;

#define DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_R_OFFSET 0x04bc
typedef struct _DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_R_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_R_BW_NUM_AR:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT3_R_BW_NUM_AR:26;
#endif
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_R_t;

typedef union {
    unsigned int val : 32;
    DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_R_t f;
} DTE_COMMON_REGS_DTE_PORT3_THROTTLE_BW_NUM_R_u;

#define DTE_REGS_DTE_ENGINE_CTRL_OFFSET 0x0000
typedef struct _DTE_REGS_DTE_ENGINE_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ENGINE_ENABLE:1;
    unsigned int DYNAMIC_CLK_GATE_EN:1;
    unsigned int CLK_GATE_EN:1;
    unsigned int REG_BRIDGE_CLK_EN:1;
    unsigned int THD_CLK_GATE_EN:1;
    unsigned int RSHP_CLK_GATE_EN:1;
    unsigned int CLK_GATE_DLY:4;
    unsigned int SW_STOP:1;
    unsigned int STOP_SIG_EN:1;
    unsigned int :2;
    unsigned int ORDER_LIST_PRI_EN:1;
    unsigned int ORDER_LIST_FILTER_EN:1;
    unsigned int :2;
    unsigned int ULTRA_OP_PRI_EN:1;
    unsigned int INVLD_VC_CLR_MBX_EN:1;
    unsigned int RD_REQ_P_CLK_GATE_EN:1;
    unsigned int RD_RESP_P_CLK_GATE_EN:1;
    unsigned int WR_REQ_P_CLK_GATE_EN:1;
    unsigned int WR_BRDCST_OP_CLK_GATE_EN:1;
    unsigned int WR_DSL_OP_CLK_GATE_EN:1;
    unsigned int WR_PAD_OP_CLK_GATE_EN:1;
    unsigned int :1;
    unsigned int CRC_CLK_GATE_EN:1;
    unsigned int :1;
    unsigned int DYNAMIC_QUEUE_EN:1;
    unsigned int RSHP_IFB_MODE:1;
    unsigned int :1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :1;
    unsigned int RSHP_IFB_MODE:1;
    unsigned int DYNAMIC_QUEUE_EN:1;
    unsigned int :1;
    unsigned int CRC_CLK_GATE_EN:1;
    unsigned int :1;
    unsigned int WR_PAD_OP_CLK_GATE_EN:1;
    unsigned int WR_DSL_OP_CLK_GATE_EN:1;
    unsigned int WR_BRDCST_OP_CLK_GATE_EN:1;
    unsigned int WR_REQ_P_CLK_GATE_EN:1;
    unsigned int RD_RESP_P_CLK_GATE_EN:1;
    unsigned int RD_REQ_P_CLK_GATE_EN:1;
    unsigned int INVLD_VC_CLR_MBX_EN:1;
    unsigned int ULTRA_OP_PRI_EN:1;
    unsigned int :2;
    unsigned int ORDER_LIST_FILTER_EN:1;
    unsigned int ORDER_LIST_PRI_EN:1;
    unsigned int :2;
    unsigned int STOP_SIG_EN:1;
    unsigned int SW_STOP:1;
    unsigned int CLK_GATE_DLY:4;
    unsigned int RSHP_CLK_GATE_EN:1;
    unsigned int THD_CLK_GATE_EN:1;
    unsigned int REG_BRIDGE_CLK_EN:1;
    unsigned int CLK_GATE_EN:1;
    unsigned int DYNAMIC_CLK_GATE_EN:1;
    unsigned int ENGINE_ENABLE:1;
#endif
} DTE_REGS_DTE_ENGINE_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ENGINE_CTRL_t f;
} DTE_REGS_DTE_ENGINE_CTRL_u;

#define DTE_REGS_DTE_DATA_SRAMMISC_CTRL_OFFSET 0x0004
typedef struct _DTE_REGS_DTE_DATA_SRAMMISC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DATA_SRAMMISC:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DATA_SRAMMISC:32;
#endif
} DTE_REGS_DTE_DATA_SRAMMISC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DATA_SRAMMISC_CTRL_t f;
} DTE_REGS_DTE_DATA_SRAMMISC_CTRL_u;

#define DTE_REGS_DTE_ULTRA_DATA_SRAMMISC_CTRL_OFFSET 0x0008
typedef struct _DTE_REGS_DTE_ULTRA_DATA_SRAMMISC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ULTRA_DATA_SRAMMISC:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ULTRA_DATA_SRAMMISC:32;
#endif
} DTE_REGS_DTE_ULTRA_DATA_SRAMMISC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ULTRA_DATA_SRAMMISC_CTRL_t f;
} DTE_REGS_DTE_ULTRA_DATA_SRAMMISC_CTRL_u;

#define DTE_REGS_DTE_REG_SRAMMISC_CTRL_OFFSET 0x000c
typedef struct _DTE_REGS_DTE_REG_SRAMMISC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int REG_SRAMMISC:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int REG_SRAMMISC:32;
#endif
} DTE_REGS_DTE_REG_SRAMMISC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_REG_SRAMMISC_CTRL_t f;
} DTE_REGS_DTE_REG_SRAMMISC_CTRL_u;

#define DTE_REGS_DTE_BURST_LEN_CTRL_OFFSET 0x0010
typedef struct _DTE_REGS_DTE_BURST_LEN_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WPORT_MAX_BURST:3;
    unsigned int :1;
    unsigned int RPORT_MAX_BURST:3;
    unsigned int :25;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :25;
    unsigned int RPORT_MAX_BURST:3;
    unsigned int :1;
    unsigned int WPORT_MAX_BURST:3;
#endif
} DTE_REGS_DTE_BURST_LEN_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_BURST_LEN_CTRL_t f;
} DTE_REGS_DTE_BURST_LEN_CTRL_u;

#define DTE_REGS_DTE_DEFAULT_ID_OFFSET 0x0014
typedef struct _DTE_REGS_DTE_DEFAULT_ID_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DEFAULT_CTXT_ID:4;
    unsigned int DEFAULT_ASID:4;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int DEFAULT_ASID:4;
    unsigned int DEFAULT_CTXT_ID:4;
#endif
} DTE_REGS_DTE_DEFAULT_ID_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DEFAULT_ID_t f;
} DTE_REGS_DTE_DEFAULT_ID_u;

#define DTE_REGS_DTE_TIMEOUT_CTRL_OFFSET 0x0018
typedef struct _DTE_REGS_DTE_TIMEOUT_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_THRESHOLD:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int TIMEOUT_THRESHOLD:32;
#endif
} DTE_REGS_DTE_TIMEOUT_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_TIMEOUT_CTRL_t f;
} DTE_REGS_DTE_TIMEOUT_CTRL_u;

#define DTE_REGS_DTE_REG_SRAM_INIT_OFFSET 0x001c
typedef struct _DTE_REGS_DTE_REG_SRAM_INIT_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int REG_SRAM_INIT_EN:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int REG_SRAM_INIT_EN:1;
#endif
} DTE_REGS_DTE_REG_SRAM_INIT_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_REG_SRAM_INIT_t f;
} DTE_REGS_DTE_REG_SRAM_INIT_u;

#define DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR0_OFFSET 0x0020
typedef struct _DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR0:32;
#endif
} DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR0_t f;
} DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR0_u;

#define DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR1_OFFSET 0x0024
typedef struct _DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR1:32;
#endif
} DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR1_t f;
} DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR1_u;

#define DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR2_OFFSET 0x0028
typedef struct _DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR2:32;
#endif
} DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR2_t f;
} DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR2_u;

#define DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR3_OFFSET 0x002c
typedef struct _DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR3:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int GSYNC_SLV_BASE_ADDR3:32;
#endif
} DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR3_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR3_t f;
} DTE_REGS_DTE_GSYNC_SLV_BASE_ADDR3_u;

#define DTE_REGS_DTE_CRC_CTRL_OFFSET 0x0030
typedef struct _DTE_REGS_DTE_CRC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CRC_EN:1;
    unsigned int CRC_CHN_EN:1;
    unsigned int CRC_RESULT_VALID:1;
    unsigned int :1;
    unsigned int CRC_CHN_NUM:8;
    unsigned int :1;
    unsigned int CRC_WPORT_SEL:3;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int CRC_WPORT_SEL:3;
    unsigned int :1;
    unsigned int CRC_CHN_NUM:8;
    unsigned int :1;
    unsigned int CRC_RESULT_VALID:1;
    unsigned int CRC_CHN_EN:1;
    unsigned int CRC_EN:1;
#endif
} DTE_REGS_DTE_CRC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_CRC_CTRL_t f;
} DTE_REGS_DTE_CRC_CTRL_u;

#define DTE_REGS_DTE_CRC_RESULT_OFFSET 0x0034
typedef struct _DTE_REGS_DTE_CRC_RESULT_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CRC_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CRC_VALUE:32;
#endif
} DTE_REGS_DTE_CRC_RESULT_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_CRC_RESULT_t f;
} DTE_REGS_DTE_CRC_RESULT_u;

#define DTE_REGS_DTE_ARB_QUEUE_QOS_0_OFFSET 0x0038
typedef struct _DTE_REGS_DTE_ARB_QUEUE_QOS_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE0_QOS:2;
    unsigned int ARB_QUEUE1_QOS:2;
    unsigned int ARB_QUEUE2_QOS:2;
    unsigned int ARB_QUEUE3_QOS:2;
    unsigned int ARB_QUEUE4_QOS:2;
    unsigned int ARB_QUEUE5_QOS:2;
    unsigned int ARB_QUEUE6_QOS:2;
    unsigned int ARB_QUEUE7_QOS:2;
    unsigned int ARB_QUEUE8_QOS:2;
    unsigned int ARB_QUEUE9_QOS:2;
    unsigned int ARB_QUEUE10_QOS:2;
    unsigned int ARB_QUEUE11_QOS:2;
    unsigned int ARB_QUEUE12_QOS:2;
    unsigned int ARB_QUEUE13_QOS:2;
    unsigned int ARB_QUEUE14_QOS:2;
    unsigned int ARB_QUEUE15_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE15_QOS:2;
    unsigned int ARB_QUEUE14_QOS:2;
    unsigned int ARB_QUEUE13_QOS:2;
    unsigned int ARB_QUEUE12_QOS:2;
    unsigned int ARB_QUEUE11_QOS:2;
    unsigned int ARB_QUEUE10_QOS:2;
    unsigned int ARB_QUEUE9_QOS:2;
    unsigned int ARB_QUEUE8_QOS:2;
    unsigned int ARB_QUEUE7_QOS:2;
    unsigned int ARB_QUEUE6_QOS:2;
    unsigned int ARB_QUEUE5_QOS:2;
    unsigned int ARB_QUEUE4_QOS:2;
    unsigned int ARB_QUEUE3_QOS:2;
    unsigned int ARB_QUEUE2_QOS:2;
    unsigned int ARB_QUEUE1_QOS:2;
    unsigned int ARB_QUEUE0_QOS:2;
#endif
} DTE_REGS_DTE_ARB_QUEUE_QOS_0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ARB_QUEUE_QOS_0_t f;
} DTE_REGS_DTE_ARB_QUEUE_QOS_0_u;

#define DTE_REGS_DTE_ARB_QUEUE_QOS_1_OFFSET 0x003c
typedef struct _DTE_REGS_DTE_ARB_QUEUE_QOS_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE16_QOS:2;
    unsigned int ARB_QUEUE17_QOS:2;
    unsigned int ARB_QUEUE18_QOS:2;
    unsigned int ARB_QUEUE19_QOS:2;
    unsigned int ARB_QUEUE20_QOS:2;
    unsigned int ARB_QUEUE21_QOS:2;
    unsigned int ARB_QUEUE22_QOS:2;
    unsigned int ARB_QUEUE23_QOS:2;
    unsigned int ARB_QUEUE24_QOS:2;
    unsigned int ARB_QUEUE25_QOS:2;
    unsigned int ARB_QUEUE26_QOS:2;
    unsigned int ARB_QUEUE27_QOS:2;
    unsigned int ARB_QUEUE28_QOS:2;
    unsigned int ARB_QUEUE29_QOS:2;
    unsigned int ARB_QUEUE30_QOS:2;
    unsigned int ARB_QUEUE31_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE31_QOS:2;
    unsigned int ARB_QUEUE30_QOS:2;
    unsigned int ARB_QUEUE29_QOS:2;
    unsigned int ARB_QUEUE28_QOS:2;
    unsigned int ARB_QUEUE27_QOS:2;
    unsigned int ARB_QUEUE26_QOS:2;
    unsigned int ARB_QUEUE25_QOS:2;
    unsigned int ARB_QUEUE24_QOS:2;
    unsigned int ARB_QUEUE23_QOS:2;
    unsigned int ARB_QUEUE22_QOS:2;
    unsigned int ARB_QUEUE21_QOS:2;
    unsigned int ARB_QUEUE20_QOS:2;
    unsigned int ARB_QUEUE19_QOS:2;
    unsigned int ARB_QUEUE18_QOS:2;
    unsigned int ARB_QUEUE17_QOS:2;
    unsigned int ARB_QUEUE16_QOS:2;
#endif
} DTE_REGS_DTE_ARB_QUEUE_QOS_1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ARB_QUEUE_QOS_1_t f;
} DTE_REGS_DTE_ARB_QUEUE_QOS_1_u;

#define DTE_REGS_DTE_ARB_QUEUE_QOS_2_OFFSET 0x0040
typedef struct _DTE_REGS_DTE_ARB_QUEUE_QOS_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE32_QOS:2;
    unsigned int ARB_QUEUE33_QOS:2;
    unsigned int ARB_QUEUE34_QOS:2;
    unsigned int ARB_QUEUE35_QOS:2;
    unsigned int ARB_QUEUE36_QOS:2;
    unsigned int ARB_QUEUE37_QOS:2;
    unsigned int ARB_QUEUE38_QOS:2;
    unsigned int ARB_QUEUE39_QOS:2;
    unsigned int ARB_QUEUE40_QOS:2;
    unsigned int ARB_QUEUE41_QOS:2;
    unsigned int ARB_QUEUE42_QOS:2;
    unsigned int ARB_QUEUE43_QOS:2;
    unsigned int ARB_QUEUE44_QOS:2;
    unsigned int ARB_QUEUE45_QOS:2;
    unsigned int ARB_QUEUE46_QOS:2;
    unsigned int ARB_QUEUE47_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE47_QOS:2;
    unsigned int ARB_QUEUE46_QOS:2;
    unsigned int ARB_QUEUE45_QOS:2;
    unsigned int ARB_QUEUE44_QOS:2;
    unsigned int ARB_QUEUE43_QOS:2;
    unsigned int ARB_QUEUE42_QOS:2;
    unsigned int ARB_QUEUE41_QOS:2;
    unsigned int ARB_QUEUE40_QOS:2;
    unsigned int ARB_QUEUE39_QOS:2;
    unsigned int ARB_QUEUE38_QOS:2;
    unsigned int ARB_QUEUE37_QOS:2;
    unsigned int ARB_QUEUE36_QOS:2;
    unsigned int ARB_QUEUE35_QOS:2;
    unsigned int ARB_QUEUE34_QOS:2;
    unsigned int ARB_QUEUE33_QOS:2;
    unsigned int ARB_QUEUE32_QOS:2;
#endif
} DTE_REGS_DTE_ARB_QUEUE_QOS_2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ARB_QUEUE_QOS_2_t f;
} DTE_REGS_DTE_ARB_QUEUE_QOS_2_u;

#define DTE_REGS_DTE_ARB_QUEUE_QOS_3_OFFSET 0x0044
typedef struct _DTE_REGS_DTE_ARB_QUEUE_QOS_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE48_QOS:2;
    unsigned int ARB_QUEUE49_QOS:2;
    unsigned int ARB_QUEUE50_QOS:2;
    unsigned int ARB_QUEUE51_QOS:2;
    unsigned int ARB_QUEUE52_QOS:2;
    unsigned int ARB_QUEUE53_QOS:2;
    unsigned int ARB_QUEUE54_QOS:2;
    unsigned int ARB_QUEUE55_QOS:2;
    unsigned int ARB_QUEUE56_QOS:2;
    unsigned int ARB_QUEUE57_QOS:2;
    unsigned int ARB_QUEUE58_QOS:2;
    unsigned int ARB_QUEUE59_QOS:2;
    unsigned int ARB_QUEUE60_QOS:2;
    unsigned int ARB_QUEUE61_QOS:2;
    unsigned int ARB_QUEUE62_QOS:2;
    unsigned int ARB_QUEUE63_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE63_QOS:2;
    unsigned int ARB_QUEUE62_QOS:2;
    unsigned int ARB_QUEUE61_QOS:2;
    unsigned int ARB_QUEUE60_QOS:2;
    unsigned int ARB_QUEUE59_QOS:2;
    unsigned int ARB_QUEUE58_QOS:2;
    unsigned int ARB_QUEUE57_QOS:2;
    unsigned int ARB_QUEUE56_QOS:2;
    unsigned int ARB_QUEUE55_QOS:2;
    unsigned int ARB_QUEUE54_QOS:2;
    unsigned int ARB_QUEUE53_QOS:2;
    unsigned int ARB_QUEUE52_QOS:2;
    unsigned int ARB_QUEUE51_QOS:2;
    unsigned int ARB_QUEUE50_QOS:2;
    unsigned int ARB_QUEUE49_QOS:2;
    unsigned int ARB_QUEUE48_QOS:2;
#endif
} DTE_REGS_DTE_ARB_QUEUE_QOS_3_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ARB_QUEUE_QOS_3_t f;
} DTE_REGS_DTE_ARB_QUEUE_QOS_3_u;

#define DTE_REGS_DTE_ARB_QUEUE_QOS_4_OFFSET 0x0048
typedef struct _DTE_REGS_DTE_ARB_QUEUE_QOS_4_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE64_QOS:2;
    unsigned int ARB_QUEUE65_QOS:2;
    unsigned int ARB_QUEUE66_QOS:2;
    unsigned int ARB_QUEUE67_QOS:2;
    unsigned int ARB_QUEUE68_QOS:2;
    unsigned int ARB_QUEUE69_QOS:2;
    unsigned int ARB_QUEUE70_QOS:2;
    unsigned int ARB_QUEUE71_QOS:2;
    unsigned int ARB_QUEUE72_QOS:2;
    unsigned int ARB_QUEUE73_QOS:2;
    unsigned int ARB_QUEUE74_QOS:2;
    unsigned int ARB_QUEUE75_QOS:2;
    unsigned int ARB_QUEUE76_QOS:2;
    unsigned int ARB_QUEUE77_QOS:2;
    unsigned int ARB_QUEUE78_QOS:2;
    unsigned int ARB_QUEUE79_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE79_QOS:2;
    unsigned int ARB_QUEUE78_QOS:2;
    unsigned int ARB_QUEUE77_QOS:2;
    unsigned int ARB_QUEUE76_QOS:2;
    unsigned int ARB_QUEUE75_QOS:2;
    unsigned int ARB_QUEUE74_QOS:2;
    unsigned int ARB_QUEUE73_QOS:2;
    unsigned int ARB_QUEUE72_QOS:2;
    unsigned int ARB_QUEUE71_QOS:2;
    unsigned int ARB_QUEUE70_QOS:2;
    unsigned int ARB_QUEUE69_QOS:2;
    unsigned int ARB_QUEUE68_QOS:2;
    unsigned int ARB_QUEUE67_QOS:2;
    unsigned int ARB_QUEUE66_QOS:2;
    unsigned int ARB_QUEUE65_QOS:2;
    unsigned int ARB_QUEUE64_QOS:2;
#endif
} DTE_REGS_DTE_ARB_QUEUE_QOS_4_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ARB_QUEUE_QOS_4_t f;
} DTE_REGS_DTE_ARB_QUEUE_QOS_4_u;

#define DTE_REGS_DTE_ARB_QUEUE_QOS_5_OFFSET 0x004c
typedef struct _DTE_REGS_DTE_ARB_QUEUE_QOS_5_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ARB_QUEUE80_QOS:2;
    unsigned int ARB_QUEUE81_QOS:2;
    unsigned int ARB_QUEUE82_QOS:2;
    unsigned int ARB_QUEUE83_QOS:2;
    unsigned int ARB_QUEUE84_QOS:2;
    unsigned int ARB_QUEUE85_QOS:2;
    unsigned int ARB_QUEUE86_QOS:2;
    unsigned int ARB_QUEUE87_QOS:2;
    unsigned int ARB_QUEUE88_QOS:2;
    unsigned int ARB_QUEUE89_QOS:2;
    unsigned int ARB_QUEUE90_QOS:2;
    unsigned int ARB_QUEUE91_QOS:2;
    unsigned int ARB_QUEUE92_QOS:2;
    unsigned int ARB_QUEUE93_QOS:2;
    unsigned int ARB_QUEUE94_QOS:2;
    unsigned int ARB_QUEUE95_QOS:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ARB_QUEUE95_QOS:2;
    unsigned int ARB_QUEUE94_QOS:2;
    unsigned int ARB_QUEUE93_QOS:2;
    unsigned int ARB_QUEUE92_QOS:2;
    unsigned int ARB_QUEUE91_QOS:2;
    unsigned int ARB_QUEUE90_QOS:2;
    unsigned int ARB_QUEUE89_QOS:2;
    unsigned int ARB_QUEUE88_QOS:2;
    unsigned int ARB_QUEUE87_QOS:2;
    unsigned int ARB_QUEUE86_QOS:2;
    unsigned int ARB_QUEUE85_QOS:2;
    unsigned int ARB_QUEUE84_QOS:2;
    unsigned int ARB_QUEUE83_QOS:2;
    unsigned int ARB_QUEUE82_QOS:2;
    unsigned int ARB_QUEUE81_QOS:2;
    unsigned int ARB_QUEUE80_QOS:2;
#endif
} DTE_REGS_DTE_ARB_QUEUE_QOS_5_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ARB_QUEUE_QOS_5_t f;
} DTE_REGS_DTE_ARB_QUEUE_QOS_5_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_0_OFFSET 0x0050
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC0_CONTEXT_ID:4;
    unsigned int VC1_CONTEXT_ID:4;
    unsigned int VC2_CONTEXT_ID:4;
    unsigned int VC3_CONTEXT_ID:4;
    unsigned int VC4_CONTEXT_ID:4;
    unsigned int VC5_CONTEXT_ID:4;
    unsigned int VC6_CONTEXT_ID:4;
    unsigned int VC7_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC7_CONTEXT_ID:4;
    unsigned int VC6_CONTEXT_ID:4;
    unsigned int VC5_CONTEXT_ID:4;
    unsigned int VC4_CONTEXT_ID:4;
    unsigned int VC3_CONTEXT_ID:4;
    unsigned int VC2_CONTEXT_ID:4;
    unsigned int VC1_CONTEXT_ID:4;
    unsigned int VC0_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_0_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_0_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_1_OFFSET 0x0054
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC8_CONTEXT_ID:4;
    unsigned int VC9_CONTEXT_ID:4;
    unsigned int VC10_CONTEXT_ID:4;
    unsigned int VC11_CONTEXT_ID:4;
    unsigned int VC12_CONTEXT_ID:4;
    unsigned int VC13_CONTEXT_ID:4;
    unsigned int VC14_CONTEXT_ID:4;
    unsigned int VC15_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC15_CONTEXT_ID:4;
    unsigned int VC14_CONTEXT_ID:4;
    unsigned int VC13_CONTEXT_ID:4;
    unsigned int VC12_CONTEXT_ID:4;
    unsigned int VC11_CONTEXT_ID:4;
    unsigned int VC10_CONTEXT_ID:4;
    unsigned int VC9_CONTEXT_ID:4;
    unsigned int VC8_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_1_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_1_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_2_OFFSET 0x0058
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC16_CONTEXT_ID:4;
    unsigned int VC17_CONTEXT_ID:4;
    unsigned int VC18_CONTEXT_ID:4;
    unsigned int VC19_CONTEXT_ID:4;
    unsigned int VC20_CONTEXT_ID:4;
    unsigned int VC21_CONTEXT_ID:4;
    unsigned int VC22_CONTEXT_ID:4;
    unsigned int VC23_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC23_CONTEXT_ID:4;
    unsigned int VC22_CONTEXT_ID:4;
    unsigned int VC21_CONTEXT_ID:4;
    unsigned int VC20_CONTEXT_ID:4;
    unsigned int VC19_CONTEXT_ID:4;
    unsigned int VC18_CONTEXT_ID:4;
    unsigned int VC17_CONTEXT_ID:4;
    unsigned int VC16_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_2_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_2_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_3_OFFSET 0x005c
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC24_CONTEXT_ID:4;
    unsigned int VC25_CONTEXT_ID:4;
    unsigned int VC26_CONTEXT_ID:4;
    unsigned int VC27_CONTEXT_ID:4;
    unsigned int VC28_CONTEXT_ID:4;
    unsigned int VC29_CONTEXT_ID:4;
    unsigned int VC30_CONTEXT_ID:4;
    unsigned int VC31_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC31_CONTEXT_ID:4;
    unsigned int VC30_CONTEXT_ID:4;
    unsigned int VC29_CONTEXT_ID:4;
    unsigned int VC28_CONTEXT_ID:4;
    unsigned int VC27_CONTEXT_ID:4;
    unsigned int VC26_CONTEXT_ID:4;
    unsigned int VC25_CONTEXT_ID:4;
    unsigned int VC24_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_3_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_3_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_3_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_4_OFFSET 0x0060
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_4_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC32_CONTEXT_ID:4;
    unsigned int VC33_CONTEXT_ID:4;
    unsigned int VC34_CONTEXT_ID:4;
    unsigned int VC35_CONTEXT_ID:4;
    unsigned int VC36_CONTEXT_ID:4;
    unsigned int VC37_CONTEXT_ID:4;
    unsigned int VC38_CONTEXT_ID:4;
    unsigned int VC39_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC39_CONTEXT_ID:4;
    unsigned int VC38_CONTEXT_ID:4;
    unsigned int VC37_CONTEXT_ID:4;
    unsigned int VC36_CONTEXT_ID:4;
    unsigned int VC35_CONTEXT_ID:4;
    unsigned int VC34_CONTEXT_ID:4;
    unsigned int VC33_CONTEXT_ID:4;
    unsigned int VC32_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_4_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_4_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_4_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_5_OFFSET 0x0064
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_5_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC40_CONTEXT_ID:4;
    unsigned int VC41_CONTEXT_ID:4;
    unsigned int VC42_CONTEXT_ID:4;
    unsigned int VC43_CONTEXT_ID:4;
    unsigned int VC44_CONTEXT_ID:4;
    unsigned int VC45_CONTEXT_ID:4;
    unsigned int VC46_CONTEXT_ID:4;
    unsigned int VC47_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC47_CONTEXT_ID:4;
    unsigned int VC46_CONTEXT_ID:4;
    unsigned int VC45_CONTEXT_ID:4;
    unsigned int VC44_CONTEXT_ID:4;
    unsigned int VC43_CONTEXT_ID:4;
    unsigned int VC42_CONTEXT_ID:4;
    unsigned int VC41_CONTEXT_ID:4;
    unsigned int VC40_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_5_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_5_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_5_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_6_OFFSET 0x0068
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_6_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC48_CONTEXT_ID:4;
    unsigned int VC49_CONTEXT_ID:4;
    unsigned int VC50_CONTEXT_ID:4;
    unsigned int VC51_CONTEXT_ID:4;
    unsigned int VC52_CONTEXT_ID:4;
    unsigned int VC53_CONTEXT_ID:4;
    unsigned int VC54_CONTEXT_ID:4;
    unsigned int VC55_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC55_CONTEXT_ID:4;
    unsigned int VC54_CONTEXT_ID:4;
    unsigned int VC53_CONTEXT_ID:4;
    unsigned int VC52_CONTEXT_ID:4;
    unsigned int VC51_CONTEXT_ID:4;
    unsigned int VC50_CONTEXT_ID:4;
    unsigned int VC49_CONTEXT_ID:4;
    unsigned int VC48_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_6_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_6_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_6_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_7_OFFSET 0x006c
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_7_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC56_CONTEXT_ID:4;
    unsigned int VC57_CONTEXT_ID:4;
    unsigned int VC58_CONTEXT_ID:4;
    unsigned int VC59_CONTEXT_ID:4;
    unsigned int VC60_CONTEXT_ID:4;
    unsigned int VC61_CONTEXT_ID:4;
    unsigned int VC62_CONTEXT_ID:4;
    unsigned int VC63_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC63_CONTEXT_ID:4;
    unsigned int VC62_CONTEXT_ID:4;
    unsigned int VC61_CONTEXT_ID:4;
    unsigned int VC60_CONTEXT_ID:4;
    unsigned int VC59_CONTEXT_ID:4;
    unsigned int VC58_CONTEXT_ID:4;
    unsigned int VC57_CONTEXT_ID:4;
    unsigned int VC56_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_7_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_7_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_7_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_8_OFFSET 0x0070
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_8_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC64_CONTEXT_ID:4;
    unsigned int VC65_CONTEXT_ID:4;
    unsigned int VC66_CONTEXT_ID:4;
    unsigned int VC67_CONTEXT_ID:4;
    unsigned int VC68_CONTEXT_ID:4;
    unsigned int VC69_CONTEXT_ID:4;
    unsigned int VC70_CONTEXT_ID:4;
    unsigned int VC71_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC71_CONTEXT_ID:4;
    unsigned int VC70_CONTEXT_ID:4;
    unsigned int VC69_CONTEXT_ID:4;
    unsigned int VC68_CONTEXT_ID:4;
    unsigned int VC67_CONTEXT_ID:4;
    unsigned int VC66_CONTEXT_ID:4;
    unsigned int VC65_CONTEXT_ID:4;
    unsigned int VC64_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_8_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_8_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_8_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_9_OFFSET 0x0074
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_9_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC72_CONTEXT_ID:4;
    unsigned int VC73_CONTEXT_ID:4;
    unsigned int VC74_CONTEXT_ID:4;
    unsigned int VC75_CONTEXT_ID:4;
    unsigned int VC76_CONTEXT_ID:4;
    unsigned int VC77_CONTEXT_ID:4;
    unsigned int VC78_CONTEXT_ID:4;
    unsigned int VC79_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC79_CONTEXT_ID:4;
    unsigned int VC78_CONTEXT_ID:4;
    unsigned int VC77_CONTEXT_ID:4;
    unsigned int VC76_CONTEXT_ID:4;
    unsigned int VC75_CONTEXT_ID:4;
    unsigned int VC74_CONTEXT_ID:4;
    unsigned int VC73_CONTEXT_ID:4;
    unsigned int VC72_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_9_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_9_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_9_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_10_OFFSET 0x0078
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_10_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC80_CONTEXT_ID:4;
    unsigned int VC81_CONTEXT_ID:4;
    unsigned int VC82_CONTEXT_ID:4;
    unsigned int VC83_CONTEXT_ID:4;
    unsigned int VC84_CONTEXT_ID:4;
    unsigned int VC85_CONTEXT_ID:4;
    unsigned int VC86_CONTEXT_ID:4;
    unsigned int VC87_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC87_CONTEXT_ID:4;
    unsigned int VC86_CONTEXT_ID:4;
    unsigned int VC85_CONTEXT_ID:4;
    unsigned int VC84_CONTEXT_ID:4;
    unsigned int VC83_CONTEXT_ID:4;
    unsigned int VC82_CONTEXT_ID:4;
    unsigned int VC81_CONTEXT_ID:4;
    unsigned int VC80_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_10_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_10_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_10_u;

#define DTE_REGS_DTE_VC_CONTEXT_ID_11_OFFSET 0x007c
typedef struct _DTE_REGS_DTE_VC_CONTEXT_ID_11_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC88_CONTEXT_ID:4;
    unsigned int VC89_CONTEXT_ID:4;
    unsigned int VC90_CONTEXT_ID:4;
    unsigned int VC91_CONTEXT_ID:4;
    unsigned int VC92_CONTEXT_ID:4;
    unsigned int VC93_CONTEXT_ID:4;
    unsigned int VC94_CONTEXT_ID:4;
    unsigned int VC95_CONTEXT_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC95_CONTEXT_ID:4;
    unsigned int VC94_CONTEXT_ID:4;
    unsigned int VC93_CONTEXT_ID:4;
    unsigned int VC92_CONTEXT_ID:4;
    unsigned int VC91_CONTEXT_ID:4;
    unsigned int VC90_CONTEXT_ID:4;
    unsigned int VC89_CONTEXT_ID:4;
    unsigned int VC88_CONTEXT_ID:4;
#endif
} DTE_REGS_DTE_VC_CONTEXT_ID_11_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CONTEXT_ID_11_t f;
} DTE_REGS_DTE_VC_CONTEXT_ID_11_u;

#define DTE_REGS_DTE_WR_COMB_CTRL_OFFSET 0x0080
typedef struct _DTE_REGS_DTE_WR_COMB_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WR_COMB_WAIT_NUM:4;
    unsigned int WR_COMB_EN:1;
    unsigned int :27;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :27;
    unsigned int WR_COMB_EN:1;
    unsigned int WR_COMB_WAIT_NUM:4;
#endif
} DTE_REGS_DTE_WR_COMB_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_WR_COMB_CTRL_t f;
} DTE_REGS_DTE_WR_COMB_CTRL_u;

#define DTE_REGS_DTE_WR_COMB_UP_ADDR_OFFSET 0x0084
typedef struct _DTE_REGS_DTE_WR_COMB_UP_ADDR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WR_COMB_UP_ADDR_LOW:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_COMB_UP_ADDR_LOW:32;
#endif
} DTE_REGS_DTE_WR_COMB_UP_ADDR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_WR_COMB_UP_ADDR_t f;
} DTE_REGS_DTE_WR_COMB_UP_ADDR_u;

#define DTE_REGS_DTE_WR_COMB_BOTTOM_ADDR_OFFSET 0x0088
typedef struct _DTE_REGS_DTE_WR_COMB_BOTTOM_ADDR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WR_COMB_BOTTOM_ADDR_LOW:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_COMB_BOTTOM_ADDR_LOW:32;
#endif
} DTE_REGS_DTE_WR_COMB_BOTTOM_ADDR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_WR_COMB_BOTTOM_ADDR_t f;
} DTE_REGS_DTE_WR_COMB_BOTTOM_ADDR_u;

#define DTE_REGS_DTE_WR_COMB_ADDR_HIGH_OFFSET 0x008c
typedef struct _DTE_REGS_DTE_WR_COMB_ADDR_HIGH_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WR_COMB_UP_ADDR_HIGH:16;
    unsigned int WR_COMB_BOTTOM_ADDR_HIGH:16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_COMB_BOTTOM_ADDR_HIGH:16;
    unsigned int WR_COMB_UP_ADDR_HIGH:16;
#endif
} DTE_REGS_DTE_WR_COMB_ADDR_HIGH_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_WR_COMB_ADDR_HIGH_t f;
} DTE_REGS_DTE_WR_COMB_ADDR_HIGH_u;

#define DTE_REGS_DTE_MAILBOX_OFFSET 0x0100
typedef struct _DTE_REGS_DTE_MAILBOX_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_WR_ID:9;
    unsigned int MBX_UNIQ_ID:7;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int MBX_UNIQ_ID:7;
    unsigned int MBX_WR_ID:9;
#endif
} DTE_REGS_DTE_MAILBOX_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_MAILBOX_t f;
} DTE_REGS_DTE_MAILBOX_u;

#define DTE_REGS_DTE_MBX_CFG_OFFSET 0x0104
typedef struct _DTE_REGS_DTE_MBX_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_CFG_ID:9;
    unsigned int MBX_CFG_UNIQ_ID:7;
    unsigned int MBX_CFG_REF:11;
    unsigned int MBX_INC_MODE:1;
    unsigned int MBX_TRG_MODE:1;
    unsigned int MBX_CRE_MODE:1;
    unsigned int MBX_UPD_MODE:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_UPD_MODE:2;
    unsigned int MBX_CRE_MODE:1;
    unsigned int MBX_TRG_MODE:1;
    unsigned int MBX_INC_MODE:1;
    unsigned int MBX_CFG_REF:11;
    unsigned int MBX_CFG_UNIQ_ID:7;
    unsigned int MBX_CFG_ID:9;
#endif
} DTE_REGS_DTE_MBX_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_MBX_CFG_t f;
} DTE_REGS_DTE_MBX_CFG_u;

#define DTE_REGS_DTE_MBX_GLB_CONFIG_OFFSET 0x0108
typedef struct _DTE_REGS_DTE_MBX_GLB_CONFIG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_GLB_CONFIG:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int MBX_GLB_CONFIG:1;
#endif
} DTE_REGS_DTE_MBX_GLB_CONFIG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_MBX_GLB_CONFIG_t f;
} DTE_REGS_DTE_MBX_GLB_CONFIG_u;

#define DTE_REGS_MBX_STATUS_SEL_OFFSET 0x010c
typedef struct _DTE_REGS_MBX_STATUS_SEL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_STATUS_ID:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int MBX_STATUS_ID:16;
#endif
} DTE_REGS_MBX_STATUS_SEL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_MBX_STATUS_SEL_t f;
} DTE_REGS_MBX_STATUS_SEL_u;

#define DTE_REGS_DTE_MBX_STATUS0_OFFSET 0x0110
typedef struct _DTE_REGS_DTE_MBX_STATUS0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_STATUS0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_STATUS0:32;
#endif
} DTE_REGS_DTE_MBX_STATUS0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_MBX_STATUS0_t f;
} DTE_REGS_DTE_MBX_STATUS0_u;

#define DTE_REGS_DTE_MBX_STATUS1_OFFSET 0x0114
typedef struct _DTE_REGS_DTE_MBX_STATUS1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_STATUS1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_STATUS1:32;
#endif
} DTE_REGS_DTE_MBX_STATUS1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_MBX_STATUS1_t f;
} DTE_REGS_DTE_MBX_STATUS1_u;

#define DTE_REGS_DTE_DBUS_BUS_CNTL_0_OFFSET 0x0118
typedef struct _DTE_REGS_DTE_DBUS_BUS_CNTL_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BUS_CNTL_0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DBUS_BUS_CNTL_0:32;
#endif
} DTE_REGS_DTE_DBUS_BUS_CNTL_0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBUS_BUS_CNTL_0_t f;
} DTE_REGS_DTE_DBUS_BUS_CNTL_0_u;

#define DTE_REGS_DTE_DBUS_BUS_CNTL_1_OFFSET 0x011c
typedef struct _DTE_REGS_DTE_DBUS_BUS_CNTL_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BUS_CNTL_1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DBUS_BUS_CNTL_1:32;
#endif
} DTE_REGS_DTE_DBUS_BUS_CNTL_1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBUS_BUS_CNTL_1_t f;
} DTE_REGS_DTE_DBUS_BUS_CNTL_1_u;

#define DTE_REGS_DTE_DBUS_BUS_CNTL_2_OFFSET 0x0120
typedef struct _DTE_REGS_DTE_DBUS_BUS_CNTL_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BUS_CNTL_2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DBUS_BUS_CNTL_2:32;
#endif
} DTE_REGS_DTE_DBUS_BUS_CNTL_2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBUS_BUS_CNTL_2_t f;
} DTE_REGS_DTE_DBUS_BUS_CNTL_2_u;

#define DTE_REGS_DTE_DBUS_BIT_CNTL_0_OFFSET 0x0124
typedef struct _DTE_REGS_DTE_DBUS_BIT_CNTL_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BIT_CNTL_0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DBUS_BIT_CNTL_0:32;
#endif
} DTE_REGS_DTE_DBUS_BIT_CNTL_0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBUS_BIT_CNTL_0_t f;
} DTE_REGS_DTE_DBUS_BIT_CNTL_0_u;

#define DTE_REGS_DTE_DBUS_BIT_CNTL_1_OFFSET 0x0128
typedef struct _DTE_REGS_DTE_DBUS_BIT_CNTL_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BIT_CNTL_1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DBUS_BIT_CNTL_1:32;
#endif
} DTE_REGS_DTE_DBUS_BIT_CNTL_1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBUS_BIT_CNTL_1_t f;
} DTE_REGS_DTE_DBUS_BIT_CNTL_1_u;

#define DTE_REGS_DTE_DBUS_BIT_CNTL_2_OFFSET 0x012c
typedef struct _DTE_REGS_DTE_DBUS_BIT_CNTL_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DBUS_BIT_CNTL_2:31;
    unsigned int REG_DBUS_EN:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int REG_DBUS_EN:1;
    unsigned int DBUS_BIT_CNTL_2:31;
#endif
} DTE_REGS_DTE_DBUS_BIT_CNTL_2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBUS_BIT_CNTL_2_t f;
} DTE_REGS_DTE_DBUS_BIT_CNTL_2_u;

#define DTE_REGS_DTE_RESERVED_REG0_OFFSET 0x0130
typedef struct _DTE_REGS_DTE_RESERVED_REG0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESERVED_REG0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RESERVED_REG0:32;
#endif
} DTE_REGS_DTE_RESERVED_REG0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_RESERVED_REG0_t f;
} DTE_REGS_DTE_RESERVED_REG0_u;

#define DTE_REGS_DTE_ENGINE_STATUS_OFFSET 0x0200
typedef struct _DTE_REGS_DTE_ENGINE_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ENGINE_STATUS:1;
    unsigned int REG_SRAM_INIT_DONE:1;
    unsigned int STOP_STATUS:1;
    unsigned int :29;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :29;
    unsigned int STOP_STATUS:1;
    unsigned int REG_SRAM_INIT_DONE:1;
    unsigned int ENGINE_STATUS:1;
#endif
} DTE_REGS_DTE_ENGINE_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ENGINE_STATUS_t f;
} DTE_REGS_DTE_ENGINE_STATUS_u;

#define DTE_REGS_DTE_INTERRUPT_STATUS_OFFSET 0x0204
typedef struct _DTE_REGS_DTE_INTERRUPT_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_INT:1;
    unsigned int DATA_SRAM_ERR_PAR_INT:1;
    unsigned int REG_SRAM_ERR_PAR_INT:1;
    unsigned int ILL_PROG_INT:1;
    unsigned int MAILBOX_ERR_INT:1;
    unsigned int ILL_VC_CFG_INT:1;
    unsigned int :1;
    unsigned int RD_RESP_ERR_INT:1;
    unsigned int RD_DATA_PAR_ERR_INT:1;
    unsigned int :1;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_LOSS_INT:1;
    unsigned int SM4_XTS_ERR_INT:1;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int SM4_XTS_ERR_INT:1;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_LOSS_INT:1;
    unsigned int :1;
    unsigned int RD_DATA_PAR_ERR_INT:1;
    unsigned int RD_RESP_ERR_INT:1;
    unsigned int :1;
    unsigned int ILL_VC_CFG_INT:1;
    unsigned int MAILBOX_ERR_INT:1;
    unsigned int ILL_PROG_INT:1;
    unsigned int REG_SRAM_ERR_PAR_INT:1;
    unsigned int DATA_SRAM_ERR_PAR_INT:1;
    unsigned int TIMEOUT_INT:1;
#endif
} DTE_REGS_DTE_INTERRUPT_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_INTERRUPT_STATUS_t f;
} DTE_REGS_DTE_INTERRUPT_STATUS_u;

#define DTE_REGS_DTE_INTERRUPT_CTRL_OFFSET 0x0208
typedef struct _DTE_REGS_DTE_INTERRUPT_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_INT_EN:1;
    unsigned int DATA_SRAM_ERR_PAR_INT_EN:1;
    unsigned int REG_SRAM_ERR_PAR_INT_EN:1;
    unsigned int ILL_PROG_INT_EN:1;
    unsigned int MAILBOX_ERR_INT_EN:1;
    unsigned int ILL_VC_CFG_INT_EN:1;
    unsigned int :4;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_LOSS_INT_EN:1;
    unsigned int SM4_XTS_ERR_INT_EN:1;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int SM4_XTS_ERR_INT_EN:1;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_LOSS_INT_EN:1;
    unsigned int :4;
    unsigned int ILL_VC_CFG_INT_EN:1;
    unsigned int MAILBOX_ERR_INT_EN:1;
    unsigned int ILL_PROG_INT_EN:1;
    unsigned int REG_SRAM_ERR_PAR_INT_EN:1;
    unsigned int DATA_SRAM_ERR_PAR_INT_EN:1;
    unsigned int TIMEOUT_INT_EN:1;
#endif
} DTE_REGS_DTE_INTERRUPT_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_INTERRUPT_CTRL_t f;
} DTE_REGS_DTE_INTERRUPT_CTRL_u;

#define DTE_REGS_DTE_ALL_VC_BUSY_STATUS_OFFSET 0x020c
typedef struct _DTE_REGS_DTE_ALL_VC_BUSY_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS:32;
#endif
} DTE_REGS_DTE_ALL_VC_BUSY_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ALL_VC_BUSY_STATUS_t f;
} DTE_REGS_DTE_ALL_VC_BUSY_STATUS_u;

#define DTE_REGS_DTE_ALL_VC_BUSY_STATUS2_OFFSET 0x0210
typedef struct _DTE_REGS_DTE_ALL_VC_BUSY_STATUS2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS2:32;
#endif
} DTE_REGS_DTE_ALL_VC_BUSY_STATUS2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ALL_VC_BUSY_STATUS2_t f;
} DTE_REGS_DTE_ALL_VC_BUSY_STATUS2_u;

#define DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS_OFFSET 0x0214
typedef struct _DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS:32;
#endif
} DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS_t f;
} DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS_u;

#define DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS2_OFFSET 0x0218
typedef struct _DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS2:32;
#endif
} DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS2_t f;
} DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS2_u;

#define DTE_REGS_DTE_DEBUG_MISC_CTRL_OFFSET 0x021c
typedef struct _DTE_REGS_DTE_DEBUG_MISC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ERR_STOP_EXE_EN:1;
    unsigned int :3;
    unsigned int DBG_PROF_EN:1;
    unsigned int :1;
    unsigned int DBG_PROF_CMD_START_EVENT_EN:1;
    unsigned int DBG_PROF_CMD_TRANS_DONE_EVENT_EN:1;
    unsigned int :2;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_EN:1;
    unsigned int :21;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :21;
    unsigned int CUSTOMIZED_TRACE_MESSAGE_EN:1;
    unsigned int :2;
    unsigned int DBG_PROF_CMD_TRANS_DONE_EVENT_EN:1;
    unsigned int DBG_PROF_CMD_START_EVENT_EN:1;
    unsigned int :1;
    unsigned int DBG_PROF_EN:1;
    unsigned int :3;
    unsigned int ERR_STOP_EXE_EN:1;
#endif
} DTE_REGS_DTE_DEBUG_MISC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DEBUG_MISC_CTRL_t f;
} DTE_REGS_DTE_DEBUG_MISC_CTRL_u;

#define DTE_REGS_DTE_MAILBOX_ERR_RPT0_OFFSET 0x0220
typedef struct _DTE_REGS_DTE_MAILBOX_ERR_RPT0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_ERR_CODE0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_ERR_CODE0:32;
#endif
} DTE_REGS_DTE_MAILBOX_ERR_RPT0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_MAILBOX_ERR_RPT0_t f;
} DTE_REGS_DTE_MAILBOX_ERR_RPT0_u;

#define DTE_REGS_DTE_MAILBOX_ERR_RPT1_OFFSET 0x0224
typedef struct _DTE_REGS_DTE_MAILBOX_ERR_RPT1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_ERR_CODE1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_ERR_CODE1:32;
#endif
} DTE_REGS_DTE_MAILBOX_ERR_RPT1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_MAILBOX_ERR_RPT1_t f;
} DTE_REGS_DTE_MAILBOX_ERR_RPT1_u;

#define DTE_REGS_DTE_RESERVED_REG1_OFFSET 0x0228
typedef struct _DTE_REGS_DTE_RESERVED_REG1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESERVED_REG1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RESERVED_REG1:32;
#endif
} DTE_REGS_DTE_RESERVED_REG1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_RESERVED_REG1_t f;
} DTE_REGS_DTE_RESERVED_REG1_u;

#define DTE_REGS_DTE_REG_SRAM_PARITY_ERR_LOG_OFFSET 0x022c
typedef struct _DTE_REGS_DTE_REG_SRAM_PARITY_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int REG_SRAM_ERR_READ_ADDR:12;
    unsigned int REG_SRAM_ERR_INDEX:16;
    unsigned int :4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :4;
    unsigned int REG_SRAM_ERR_INDEX:16;
    unsigned int REG_SRAM_ERR_READ_ADDR:12;
#endif
} DTE_REGS_DTE_REG_SRAM_PARITY_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_REG_SRAM_PARITY_ERR_LOG_t f;
} DTE_REGS_DTE_REG_SRAM_PARITY_ERR_LOG_u;

#define DTE_REGS_DTE_DATA_SRAM_PARITY_ERR_LOG_OFFSET 0x0230
typedef struct _DTE_REGS_DTE_DATA_SRAM_PARITY_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DATA_SRAM_TYPE:1;
    unsigned int DATA_SRAM_ERR_READ_ADDR:11;
    unsigned int DATA_SRAM_ERR_INDEX:16;
    unsigned int DATA_SRAM_ERR_THD_ID:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DATA_SRAM_ERR_THD_ID:4;
    unsigned int DATA_SRAM_ERR_INDEX:16;
    unsigned int DATA_SRAM_ERR_READ_ADDR:11;
    unsigned int DATA_SRAM_TYPE:1;
#endif
} DTE_REGS_DTE_DATA_SRAM_PARITY_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DATA_SRAM_PARITY_ERR_LOG_t f;
} DTE_REGS_DTE_DATA_SRAM_PARITY_ERR_LOG_u;

#define DTE_REGS_DTE_ILL_VC_CFG_ERR_LOG0_OFFSET 0x0234
typedef struct _DTE_REGS_DTE_ILL_VC_CFG_ERR_LOG0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ILL_VC_CFG_REG_ADDR:30;
    unsigned int :2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :2;
    unsigned int ILL_VC_CFG_REG_ADDR:30;
#endif
} DTE_REGS_DTE_ILL_VC_CFG_ERR_LOG0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ILL_VC_CFG_ERR_LOG0_t f;
} DTE_REGS_DTE_ILL_VC_CFG_ERR_LOG0_u;

#define DTE_REGS_DTE_ILL_VC_CFG_ERR_LOG1_OFFSET 0x0238
typedef struct _DTE_REGS_DTE_ILL_VC_CFG_ERR_LOG1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ILL_VC_CFG_REG_MASTER_ID:20;
    unsigned int ILL_VC_CFG_REG_VC_ID:8;
    unsigned int :4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :4;
    unsigned int ILL_VC_CFG_REG_VC_ID:8;
    unsigned int ILL_VC_CFG_REG_MASTER_ID:20;
#endif
} DTE_REGS_DTE_ILL_VC_CFG_ERR_LOG1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ILL_VC_CFG_ERR_LOG1_t f;
} DTE_REGS_DTE_ILL_VC_CFG_ERR_LOG1_u;

#define DTE_REGS_DTE_TIMEOUT_ERR_LOG_OFFSET 0x023c
typedef struct _DTE_REGS_DTE_TIMEOUT_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_VC_ID:8;
    unsigned int TIMEOUT_THD_ID:3;
    unsigned int :21;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :21;
    unsigned int TIMEOUT_THD_ID:3;
    unsigned int TIMEOUT_VC_ID:8;
#endif
} DTE_REGS_DTE_TIMEOUT_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_TIMEOUT_ERR_LOG_t f;
} DTE_REGS_DTE_TIMEOUT_ERR_LOG_u;

#define DTE_REGS_DTE_ILL_PROG_ERR_LOG_OFFSET 0x0240
typedef struct _DTE_REGS_DTE_ILL_PROG_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ILL_PROG_TYPE:4;
    unsigned int ILL_PROG_VC_ID:8;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int ILL_PROG_VC_ID:8;
    unsigned int ILL_PROG_TYPE:4;
#endif
} DTE_REGS_DTE_ILL_PROG_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ILL_PROG_ERR_LOG_t f;
} DTE_REGS_DTE_ILL_PROG_ERR_LOG_u;

#define DTE_REGS_DTE_DBG_THD0_POSITION_OFFSET 0x0244
typedef struct _DTE_REGS_DTE_DBG_THD0_POSITION_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int THD0_POSITION:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int THD0_POSITION:32;
#endif
} DTE_REGS_DTE_DBG_THD0_POSITION_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBG_THD0_POSITION_t f;
} DTE_REGS_DTE_DBG_THD0_POSITION_u;

#define DTE_REGS_DTE_DBG_THD1_POSITION_OFFSET 0x0248
typedef struct _DTE_REGS_DTE_DBG_THD1_POSITION_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int THD1_POSITION:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int THD1_POSITION:32;
#endif
} DTE_REGS_DTE_DBG_THD1_POSITION_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBG_THD1_POSITION_t f;
} DTE_REGS_DTE_DBG_THD1_POSITION_u;

#define DTE_REGS_DTE_DBG_THD2_POSITION_OFFSET 0x024c
typedef struct _DTE_REGS_DTE_DBG_THD2_POSITION_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int THD2_POSITION:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int THD2_POSITION:32;
#endif
} DTE_REGS_DTE_DBG_THD2_POSITION_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBG_THD2_POSITION_t f;
} DTE_REGS_DTE_DBG_THD2_POSITION_u;

#define DTE_REGS_DTE_DBG_THD3_POSITION_OFFSET 0x0250
typedef struct _DTE_REGS_DTE_DBG_THD3_POSITION_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int THD3_POSITION:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int THD3_POSITION:32;
#endif
} DTE_REGS_DTE_DBG_THD3_POSITION_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBG_THD3_POSITION_t f;
} DTE_REGS_DTE_DBG_THD3_POSITION_u;

#define DTE_REGS_DTE_DBG_THD_POSITION_H_OFFSET 0x0254
typedef struct _DTE_REGS_DTE_DBG_THD_POSITION_H_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int THD0_POSITION_H:2;
    unsigned int THD1_POSITION_H:2;
    unsigned int THD2_POSITION_H:2;
    unsigned int THD3_POSITION_H:2;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int THD3_POSITION_H:2;
    unsigned int THD2_POSITION_H:2;
    unsigned int THD1_POSITION_H:2;
    unsigned int THD0_POSITION_H:2;
#endif
} DTE_REGS_DTE_DBG_THD_POSITION_H_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DBG_THD_POSITION_H_t f;
} DTE_REGS_DTE_DBG_THD_POSITION_H_u;

#define DTE_REGS_DTE_RD_RESP_ERR_LOG_OFFSET 0x0258
typedef struct _DTE_REGS_DTE_RD_RESP_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_RESP_ERR_THD_ID:4;
    unsigned int RD_RESP_ERR_CTXT_ID:4;
    unsigned int RD_RESP_ERR_VC_ID:8;
    unsigned int RD_RESP_ERR_RUSER:4;
    unsigned int RD_RESP_ERR_RRESP:2;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int RD_RESP_ERR_RRESP:2;
    unsigned int RD_RESP_ERR_RUSER:4;
    unsigned int RD_RESP_ERR_VC_ID:8;
    unsigned int RD_RESP_ERR_CTXT_ID:4;
    unsigned int RD_RESP_ERR_THD_ID:4;
#endif
} DTE_REGS_DTE_RD_RESP_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_RD_RESP_ERR_LOG_t f;
} DTE_REGS_DTE_RD_RESP_ERR_LOG_u;

#define DTE_REGS_DTE_RD_DATA_PAR_ERR_LOG_OFFSET 0x025c
typedef struct _DTE_REGS_DTE_RD_DATA_PAR_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_DATA_PAR_ERR_THD_ID:4;
    unsigned int RD_DATA_PAR_ERR_CTXT_ID:4;
    unsigned int RD_DATA_PAR_ERR_VC_ID:8;
    unsigned int RD_DATA_PAR_ERR_RUSER:4;
    unsigned int RD_DATA_PAR_ERR_RRESP:2;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int RD_DATA_PAR_ERR_RRESP:2;
    unsigned int RD_DATA_PAR_ERR_RUSER:4;
    unsigned int RD_DATA_PAR_ERR_VC_ID:8;
    unsigned int RD_DATA_PAR_ERR_CTXT_ID:4;
    unsigned int RD_DATA_PAR_ERR_THD_ID:4;
#endif
} DTE_REGS_DTE_RD_DATA_PAR_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_RD_DATA_PAR_ERR_LOG_t f;
} DTE_REGS_DTE_RD_DATA_PAR_ERR_LOG_u;

#define DTE_REGS_DTE_VC_DECRYPT_ERR_LOG_OFFSET 0x0260
typedef struct _DTE_REGS_DTE_VC_DECRYPT_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_DECRYPT_ERR_LOG:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC_DECRYPT_ERR_LOG:32;
#endif
} DTE_REGS_DTE_VC_DECRYPT_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_DECRYPT_ERR_LOG_t f;
} DTE_REGS_DTE_VC_DECRYPT_ERR_LOG_u;

#define DTE_REGS_DTE_SIG_SEND_STATUS_OFFSET 0x0264
typedef struct _DTE_REGS_DTE_SIG_SEND_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DTE2SA_SIG_REQ:1;
    unsigned int SA2DTE_SIG_RCVD_BUSY:1;
    unsigned int SIG_FIFO_NOT_FULL:1;
    unsigned int SIG_FIFO_NOT_EMPTY:1;
    unsigned int SIG_CUR_STATE:2;
    unsigned int DTE2SA_GSYNC_REQ:1;
    unsigned int SA2DTE_GSYNC_RCVD_BUSY:1;
    unsigned int GSYNC_WORK_STATUS:1;
    unsigned int :23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :23;
    unsigned int GSYNC_WORK_STATUS:1;
    unsigned int SA2DTE_GSYNC_RCVD_BUSY:1;
    unsigned int DTE2SA_GSYNC_REQ:1;
    unsigned int SIG_CUR_STATE:2;
    unsigned int SIG_FIFO_NOT_EMPTY:1;
    unsigned int SIG_FIFO_NOT_FULL:1;
    unsigned int SA2DTE_SIG_RCVD_BUSY:1;
    unsigned int DTE2SA_SIG_REQ:1;
#endif
} DTE_REGS_DTE_SIG_SEND_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SIG_SEND_STATUS_t f;
} DTE_REGS_DTE_SIG_SEND_STATUS_u;

#define DTE_REGS_DTE_RESERVED_REG2_OFFSET 0x0268
typedef struct _DTE_REGS_DTE_RESERVED_REG2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESERVED_REG2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RESERVED_REG2:32;
#endif
} DTE_REGS_DTE_RESERVED_REG2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_RESERVED_REG2_t f;
} DTE_REGS_DTE_RESERVED_REG2_u;

#define DTE_REGS_DTE_THD0_RD_STATUS_OFFSET 0x026c
typedef struct _DTE_REGS_DTE_THD0_RD_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int BUF_OVFL:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_RREADY:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RPIPE_RREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int BUF_OVFL:1;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
#endif
} DTE_REGS_DTE_THD0_RD_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD0_RD_STATUS_t f;
} DTE_REGS_DTE_THD0_RD_STATUS_u;

#define DTE_REGS_DTE_THD0_WR_STATUS_OFFSET 0x0270
typedef struct _DTE_REGS_DTE_THD0_WR_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WPIPE_PEND_CMD_NUM:3;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_WREADY:1;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WPIPE_WREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_PEND_CMD_NUM:3;
#endif
} DTE_REGS_DTE_THD0_WR_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD0_WR_STATUS_t f;
} DTE_REGS_DTE_THD0_WR_STATUS_u;

#define DTE_REGS_DTE_THD1_RD_STATUS_OFFSET 0x0274
typedef struct _DTE_REGS_DTE_THD1_RD_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int BUF_OVFL:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_RREADY:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RPIPE_RREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int BUF_OVFL:1;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
#endif
} DTE_REGS_DTE_THD1_RD_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD1_RD_STATUS_t f;
} DTE_REGS_DTE_THD1_RD_STATUS_u;

#define DTE_REGS_DTE_THD1_WR_STATUS_OFFSET 0x0278
typedef struct _DTE_REGS_DTE_THD1_WR_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WPIPE_PEND_CMD_NUM:3;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_WREADY:1;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WPIPE_WREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_PEND_CMD_NUM:3;
#endif
} DTE_REGS_DTE_THD1_WR_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD1_WR_STATUS_t f;
} DTE_REGS_DTE_THD1_WR_STATUS_u;

#define DTE_REGS_DTE_THD2_RD_STATUS_OFFSET 0x027c
typedef struct _DTE_REGS_DTE_THD2_RD_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int BUF_OVFL:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_RREADY:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RPIPE_RREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int BUF_OVFL:1;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
#endif
} DTE_REGS_DTE_THD2_RD_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD2_RD_STATUS_t f;
} DTE_REGS_DTE_THD2_RD_STATUS_u;

#define DTE_REGS_DTE_THD2_WR_STATUS_OFFSET 0x0280
typedef struct _DTE_REGS_DTE_THD2_WR_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WPIPE_PEND_CMD_NUM:3;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_WREADY:1;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WPIPE_WREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_PEND_CMD_NUM:3;
#endif
} DTE_REGS_DTE_THD2_WR_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD2_WR_STATUS_t f;
} DTE_REGS_DTE_THD2_WR_STATUS_u;

#define DTE_REGS_DTE_THD3_RD_STATUS_OFFSET 0x0284
typedef struct _DTE_REGS_DTE_THD3_RD_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int BUF_OVFL:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_RREADY:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int RPIPE_RREADY:1;
    unsigned int RPIPE_RVALID:1;
    unsigned int RPIPE_ARREADY:1;
    unsigned int RPIPE_ARWALID:1;
    unsigned int BUF_OVFL:1;
    unsigned int DATA_BUF_VLD_ENTRY_NUM:8;
    unsigned int RD_RESP_PIPE_CMD_VC_ID:7;
    unsigned int RD_REQ_PIPE_CMD_VC_ID:7;
    unsigned int RD_RESP_PIPE_PEND_CMD_NUM:3;
    unsigned int RD_REQ_PIPE_PEND_CMD_NUM:2;
#endif
} DTE_REGS_DTE_THD3_RD_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD3_RD_STATUS_t f;
} DTE_REGS_DTE_THD3_RD_STATUS_u;

#define DTE_REGS_DTE_THD3_WR_STATUS_OFFSET 0x0288
typedef struct _DTE_REGS_DTE_THD3_WR_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WPIPE_PEND_CMD_NUM:3;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_WREADY:1;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WR_REQ_PIPE_RD_MEM_END:1;
    unsigned int WR_REQ_PIPE_WR_MEM_END:1;
    unsigned int WR_REQ_PIPE_EMPTY_PENDING:1;
    unsigned int WR_REQ_PIPE_WORK:1;
    unsigned int WR_RESP_PIPE_SEND:1;
    unsigned int WR_RESP_PIPE_VC_ID:8;
    unsigned int WR_RESP_PIPE_PEND_NUM:4;
    unsigned int WR_REQ_PIPE_CMD_VC_ID:8;
    unsigned int WPIPE_WREADY:1;
    unsigned int WPIPE_WVALID:1;
    unsigned int WPIPE_AWREADY:1;
    unsigned int WPIPE_AWWALID:1;
    unsigned int WPIPE_PEND_CMD_NUM:3;
#endif
} DTE_REGS_DTE_THD3_WR_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD3_WR_STATUS_t f;
} DTE_REGS_DTE_THD3_WR_STATUS_u;

#define DTE_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_CNT_OFFSET 0x028c
typedef struct _DTE_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_CNT_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CUS_TRACE_ME_LOSS_CNT:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CUS_TRACE_ME_LOSS_CNT:32;
#endif
} DTE_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_CNT_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_CNT_t f;
} DTE_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_CNT_u;

#define DTE_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_ERR_LOG_OFFSET 0x0290
typedef struct _DTE_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_ERR_LOG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CUS_TRACE_MES_LOSS_INT_PRCS_ID:16;
    unsigned int CUS_TRACE_MES_LOSS_INT_VC_ID:8;
    unsigned int CUS_TRACE_MES_LOSS_INT_CTXT_ID:4;
    unsigned int :4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :4;
    unsigned int CUS_TRACE_MES_LOSS_INT_CTXT_ID:4;
    unsigned int CUS_TRACE_MES_LOSS_INT_VC_ID:8;
    unsigned int CUS_TRACE_MES_LOSS_INT_PRCS_ID:16;
#endif
} DTE_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_ERR_LOG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_ERR_LOG_t f;
} DTE_REGS_DTE_CUSTOMIZED_TRACE_MESSAGE_LOSS_ERR_LOG_u;

#define DTE_REGS_DTE_FORCE_TRIG_INT_CFG_OFFSET 0x0294
typedef struct _DTE_REGS_DTE_FORCE_TRIG_INT_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_FORCE_TRIG:1;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG:1;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG:1;
    unsigned int ILL_PROG_FORCE_TRIG:1;
    unsigned int MAILBOX_ERR_FORCE_TRIG:1;
    unsigned int ILL_VC_CFG_FORCE_TRIG:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int ILL_VC_CFG_FORCE_TRIG:1;
    unsigned int MAILBOX_ERR_FORCE_TRIG:1;
    unsigned int ILL_PROG_FORCE_TRIG:1;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG:1;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG:1;
    unsigned int TIMEOUT_FORCE_TRIG:1;
#endif
} DTE_REGS_DTE_FORCE_TRIG_INT_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_FORCE_TRIG_INT_CFG_t f;
} DTE_REGS_DTE_FORCE_TRIG_INT_CFG_u;

#define DTE_REGS_DTE_FORCE_TRIG_INT_CTXT_ID_CFG_OFFSET 0x0298
typedef struct _DTE_REGS_DTE_FORCE_TRIG_INT_CTXT_ID_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_FORCE_TRIG_CTXT_ID:4;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_CTXT_ID:4;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_CTXT_ID:4;
    unsigned int ILL_PROG_FORCE_TRIG_CTXT_ID:4;
    unsigned int MAILBOX_ERR_FORCE_TRIG_CTXT_ID:4;
    unsigned int ILL_VC_CFG_FORCE_TRIG_CTXT_ID:4;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int ILL_VC_CFG_FORCE_TRIG_CTXT_ID:4;
    unsigned int MAILBOX_ERR_FORCE_TRIG_CTXT_ID:4;
    unsigned int ILL_PROG_FORCE_TRIG_CTXT_ID:4;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_CTXT_ID:4;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_CTXT_ID:4;
    unsigned int TIMEOUT_FORCE_TRIG_CTXT_ID:4;
#endif
} DTE_REGS_DTE_FORCE_TRIG_INT_CTXT_ID_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_FORCE_TRIG_INT_CTXT_ID_CFG_t f;
} DTE_REGS_DTE_FORCE_TRIG_INT_CTXT_ID_CFG_u;

#define DTE_REGS_DTE_FORCE_TRIG_INT_ASID_CFG_OFFSET 0x029c
typedef struct _DTE_REGS_DTE_FORCE_TRIG_INT_ASID_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_FORCE_TRIG_ASID:4;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_ASID:4;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_ASID:4;
    unsigned int ILL_PROG_FORCE_TRIG_ASID:4;
    unsigned int MAILBOX_ERR_FORCE_TRIG_ASID:4;
    unsigned int ILL_VC_CFG_FORCE_TRIG_ASID:4;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int ILL_VC_CFG_FORCE_TRIG_ASID:4;
    unsigned int MAILBOX_ERR_FORCE_TRIG_ASID:4;
    unsigned int ILL_PROG_FORCE_TRIG_ASID:4;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_ASID:4;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_ASID:4;
    unsigned int TIMEOUT_FORCE_TRIG_ASID:4;
#endif
} DTE_REGS_DTE_FORCE_TRIG_INT_ASID_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_FORCE_TRIG_INT_ASID_CFG_t f;
} DTE_REGS_DTE_FORCE_TRIG_INT_ASID_CFG_u;

#define DTE_REGS_DTE_FORCE_TRIG_INT_MODE_CFG_OFFSET 0x02a0
typedef struct _DTE_REGS_DTE_FORCE_TRIG_INT_MODE_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int TIMEOUT_FORCE_TRIG_MODE:1;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_MODE:1;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_MODE:1;
    unsigned int ILL_PROG_FORCE_TRIG_MODE:1;
    unsigned int MAILBOX_ERR_FORCE_TRIG_MODE:1;
    unsigned int ILL_VC_CFG_FORCE_TRIG_MODE:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int ILL_VC_CFG_FORCE_TRIG_MODE:1;
    unsigned int MAILBOX_ERR_FORCE_TRIG_MODE:1;
    unsigned int ILL_PROG_FORCE_TRIG_MODE:1;
    unsigned int REG_SRAM_ERR_PAR_FORCE_TRIG_MODE:1;
    unsigned int DATA_SRAM_ERR_PAR_FORCE_TRIG_MODE:1;
    unsigned int TIMEOUT_FORCE_TRIG_MODE:1;
#endif
} DTE_REGS_DTE_FORCE_TRIG_INT_MODE_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_FORCE_TRIG_INT_MODE_CFG_t f;
} DTE_REGS_DTE_FORCE_TRIG_INT_MODE_CFG_u;

#define DTE_REGS_DTE_ALL_VC_BUSY_STATUS3_OFFSET 0x02a4
typedef struct _DTE_REGS_DTE_ALL_VC_BUSY_STATUS3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS3:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_BUSY_STATUS3:32;
#endif
} DTE_REGS_DTE_ALL_VC_BUSY_STATUS3_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ALL_VC_BUSY_STATUS3_t f;
} DTE_REGS_DTE_ALL_VC_BUSY_STATUS3_u;

#define DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS3_OFFSET 0x02a8
typedef struct _DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS3:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int ALL_VC_OCCUPY_STATUS3:32;
#endif
} DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS3_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS3_t f;
} DTE_REGS_DTE_ALL_VC_OCCUPY_STATUS3_u;

#define DTE_REGS_DTE_THD0_RSHP_STATUS_OFFSET 0x02ac
typedef struct _DTE_REGS_DTE_THD0_RSHP_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
#endif
} DTE_REGS_DTE_THD0_RSHP_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD0_RSHP_STATUS_t f;
} DTE_REGS_DTE_THD0_RSHP_STATUS_u;

#define DTE_REGS_DTE_THD1_RSHP_STATUS_OFFSET 0x02b0
typedef struct _DTE_REGS_DTE_THD1_RSHP_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
#endif
} DTE_REGS_DTE_THD1_RSHP_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD1_RSHP_STATUS_t f;
} DTE_REGS_DTE_THD1_RSHP_STATUS_u;

#define DTE_REGS_DTE_THD2_RSHP_STATUS_OFFSET 0x02b4
typedef struct _DTE_REGS_DTE_THD2_RSHP_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
#endif
} DTE_REGS_DTE_THD2_RSHP_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD2_RSHP_STATUS_t f;
} DTE_REGS_DTE_THD2_RSHP_STATUS_u;

#define DTE_REGS_DTE_THD3_RSHP_STATUS_OFFSET 0x02b8
typedef struct _DTE_REGS_DTE_THD3_RSHP_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int RSHP_BUF_OVFL:1;
    unsigned int RSHP_DATA_BUF_VLD_ENTRY_NUM:9;
#endif
} DTE_REGS_DTE_THD3_RSHP_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_THD3_RSHP_STATUS_t f;
} DTE_REGS_DTE_THD3_RSHP_STATUS_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_EN_WR_OFFSET 0x0400
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_EN_WR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_EN_WR:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int PORT0_THROTTLE_EN_WR:1;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_EN_WR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_EN_WR_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_EN_WR_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_EN_OFFSET 0x0404
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_EN_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_W_OST_EN:1;
    unsigned int PORT0_THROTTLE_W_BW_EN:1;
    unsigned int PORT0_THROTTLE_R_OST_EN:1;
    unsigned int PORT0_THROTTLE_R_BW_EN:1;
    unsigned int PORT0_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT0_THROTTLE_R_OSTLEN_EN:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int PORT0_THROTTLE_R_OSTLEN_EN:1;
    unsigned int PORT0_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT0_THROTTLE_R_BW_EN:1;
    unsigned int PORT0_THROTTLE_R_OST_EN:1;
    unsigned int PORT0_THROTTLE_W_BW_EN:1;
    unsigned int PORT0_THROTTLE_W_OST_EN:1;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_EN_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_EN_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_EN_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_W_OST_THR_OFFSET 0x0408
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_W_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_W_OST_THR:10;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int PORT0_THROTTLE_W_OST_THR:10;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_W_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_W_OST_THR_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_W_OST_THR_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_W_BW_THR_OFFSET 0x040c
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_W_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_W_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT0_THROTTLE_W_BW_THR:25;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_W_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_W_BW_THR_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_W_BW_THR_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_R_OST_THR_OFFSET 0x0410
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_R_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_R_OST_THR:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int PORT0_THROTTLE_R_OST_THR:16;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_R_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_R_OST_THR_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_R_OST_THR_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_R_BW_THR_OFFSET 0x0414
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_R_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_R_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT0_THROTTLE_R_BW_THR:25;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_R_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_R_BW_THR_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_R_BW_THR_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_TW_OFFSET 0x0418
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_TW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_THROTTLE_TW:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT0_THROTTLE_TW:25;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_TW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_TW_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_TW_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_OST_NUM_OFFSET 0x041c
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_OST_NUM_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_W_OST_NUM:10;
    unsigned int PORT0_R_OST_NUM:16;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT0_R_OST_NUM:16;
    unsigned int PORT0_W_OST_NUM:10;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_OST_NUM_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_OST_NUM_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_OST_NUM_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_OST_UDFL_OVFL_OFFSET 0x0420
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_OST_UDFL_OVFL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_W_OST_UDFL:1;
    unsigned int PORT0_W_OST_OVFL:1;
    unsigned int PORT0_R_OST_UDFL:1;
    unsigned int PORT0_R_OST_OVFL:1;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int PORT0_R_OST_OVFL:1;
    unsigned int PORT0_R_OST_UDFL:1;
    unsigned int PORT0_W_OST_OVFL:1;
    unsigned int PORT0_W_OST_UDFL:1;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_OST_UDFL_OVFL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_OST_UDFL_OVFL_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_OST_UDFL_OVFL_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_AW_OFFSET 0x0424
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_AW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_W_BW_NUM_AW:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT0_W_BW_NUM_AW:26;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_AW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_AW_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_AW_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_W_OFFSET 0x0428
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_W_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_W_BW_NUM_W:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT0_W_BW_NUM_W:26;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_W_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_W_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_W_u;

#define DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_R_OFFSET 0x042c
typedef struct _DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_R_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT0_R_BW_NUM_AR:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT0_R_BW_NUM_AR:26;
#endif
} DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_R_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_R_t f;
} DTE_REGS_DTE_PORT0_THROTTLE_BW_NUM_R_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_EN_WR_OFFSET 0x0430
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_EN_WR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_EN_WR:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int PORT1_THROTTLE_EN_WR:1;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_EN_WR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_EN_WR_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_EN_WR_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_EN_OFFSET 0x0434
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_EN_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_W_OST_EN:1;
    unsigned int PORT1_THROTTLE_W_BW_EN:1;
    unsigned int PORT1_THROTTLE_R_OST_EN:1;
    unsigned int PORT1_THROTTLE_R_BW_EN:1;
    unsigned int PORT1_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT1_THROTTLE_R_OSTLEN_EN:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int PORT1_THROTTLE_R_OSTLEN_EN:1;
    unsigned int PORT1_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT1_THROTTLE_R_BW_EN:1;
    unsigned int PORT1_THROTTLE_R_OST_EN:1;
    unsigned int PORT1_THROTTLE_W_BW_EN:1;
    unsigned int PORT1_THROTTLE_W_OST_EN:1;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_EN_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_EN_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_EN_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_W_OST_THR_OFFSET 0x0438
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_W_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_W_OST_THR:10;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int PORT1_THROTTLE_W_OST_THR:10;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_W_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_W_OST_THR_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_W_OST_THR_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_W_BW_THR_OFFSET 0x043c
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_W_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_W_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT1_THROTTLE_W_BW_THR:25;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_W_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_W_BW_THR_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_W_BW_THR_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_R_OST_THR_OFFSET 0x0440
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_R_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_R_OST_THR:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int PORT1_THROTTLE_R_OST_THR:16;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_R_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_R_OST_THR_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_R_OST_THR_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_R_BW_THR_OFFSET 0x0444
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_R_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_R_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT1_THROTTLE_R_BW_THR:25;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_R_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_R_BW_THR_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_R_BW_THR_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_TW_OFFSET 0x0448
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_TW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_THROTTLE_TW:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT1_THROTTLE_TW:25;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_TW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_TW_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_TW_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_OST_NUM_OFFSET 0x044c
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_OST_NUM_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_W_OST_NUM:10;
    unsigned int PORT1_R_OST_NUM:16;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT1_R_OST_NUM:16;
    unsigned int PORT1_W_OST_NUM:10;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_OST_NUM_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_OST_NUM_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_OST_NUM_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_OST_UDFL_OVFL_OFFSET 0x0450
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_OST_UDFL_OVFL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_W_OST_UDFL:1;
    unsigned int PORT1_W_OST_OVFL:1;
    unsigned int PORT1_R_OST_UDFL:1;
    unsigned int PORT1_R_OST_OVFL:1;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int PORT1_R_OST_OVFL:1;
    unsigned int PORT1_R_OST_UDFL:1;
    unsigned int PORT1_W_OST_OVFL:1;
    unsigned int PORT1_W_OST_UDFL:1;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_OST_UDFL_OVFL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_OST_UDFL_OVFL_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_OST_UDFL_OVFL_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_AW_OFFSET 0x0454
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_AW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_W_BW_NUM_AW:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT1_W_BW_NUM_AW:26;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_AW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_AW_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_AW_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_W_OFFSET 0x0458
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_W_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_W_BW_NUM_W:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT1_W_BW_NUM_W:26;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_W_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_W_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_W_u;

#define DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_R_OFFSET 0x045c
typedef struct _DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_R_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT1_R_BW_NUM_AR:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT1_R_BW_NUM_AR:26;
#endif
} DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_R_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_R_t f;
} DTE_REGS_DTE_PORT1_THROTTLE_BW_NUM_R_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_EN_WR_OFFSET 0x0460
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_EN_WR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_EN_WR:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int PORT2_THROTTLE_EN_WR:1;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_EN_WR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_EN_WR_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_EN_WR_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_EN_OFFSET 0x0464
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_EN_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_W_OST_EN:1;
    unsigned int PORT2_THROTTLE_W_BW_EN:1;
    unsigned int PORT2_THROTTLE_R_OST_EN:1;
    unsigned int PORT2_THROTTLE_R_BW_EN:1;
    unsigned int PORT2_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT2_THROTTLE_R_OSTLEN_EN:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int PORT2_THROTTLE_R_OSTLEN_EN:1;
    unsigned int PORT2_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT2_THROTTLE_R_BW_EN:1;
    unsigned int PORT2_THROTTLE_R_OST_EN:1;
    unsigned int PORT2_THROTTLE_W_BW_EN:1;
    unsigned int PORT2_THROTTLE_W_OST_EN:1;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_EN_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_EN_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_EN_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_W_OST_THR_OFFSET 0x0468
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_W_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_W_OST_THR:10;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int PORT2_THROTTLE_W_OST_THR:10;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_W_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_W_OST_THR_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_W_OST_THR_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_W_BW_THR_OFFSET 0x046c
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_W_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_W_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT2_THROTTLE_W_BW_THR:25;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_W_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_W_BW_THR_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_W_BW_THR_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_R_OST_THR_OFFSET 0x0470
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_R_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_R_OST_THR:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int PORT2_THROTTLE_R_OST_THR:16;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_R_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_R_OST_THR_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_R_OST_THR_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_R_BW_THR_OFFSET 0x0474
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_R_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_R_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT2_THROTTLE_R_BW_THR:25;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_R_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_R_BW_THR_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_R_BW_THR_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_TW_OFFSET 0x0478
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_TW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_THROTTLE_TW:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT2_THROTTLE_TW:25;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_TW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_TW_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_TW_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_OST_NUM_OFFSET 0x047c
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_OST_NUM_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_W_OST_NUM:10;
    unsigned int PORT2_R_OST_NUM:16;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT2_R_OST_NUM:16;
    unsigned int PORT2_W_OST_NUM:10;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_OST_NUM_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_OST_NUM_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_OST_NUM_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_OST_UDFL_OVFL_OFFSET 0x0480
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_OST_UDFL_OVFL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_W_OST_UDFL:1;
    unsigned int PORT2_W_OST_OVFL:1;
    unsigned int PORT2_R_OST_UDFL:1;
    unsigned int PORT2_R_OST_OVFL:1;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int PORT2_R_OST_OVFL:1;
    unsigned int PORT2_R_OST_UDFL:1;
    unsigned int PORT2_W_OST_OVFL:1;
    unsigned int PORT2_W_OST_UDFL:1;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_OST_UDFL_OVFL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_OST_UDFL_OVFL_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_OST_UDFL_OVFL_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_AW_OFFSET 0x0484
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_AW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_W_BW_NUM_AW:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT2_W_BW_NUM_AW:26;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_AW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_AW_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_AW_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_W_OFFSET 0x0488
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_W_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_W_BW_NUM_W:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT2_W_BW_NUM_W:26;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_W_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_W_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_W_u;

#define DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_R_OFFSET 0x048c
typedef struct _DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_R_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT2_R_BW_NUM_AR:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT2_R_BW_NUM_AR:26;
#endif
} DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_R_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_R_t f;
} DTE_REGS_DTE_PORT2_THROTTLE_BW_NUM_R_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_EN_WR_OFFSET 0x0490
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_EN_WR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_EN_WR:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int PORT3_THROTTLE_EN_WR:1;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_EN_WR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_EN_WR_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_EN_WR_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_EN_OFFSET 0x0494
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_EN_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_W_OST_EN:1;
    unsigned int PORT3_THROTTLE_W_BW_EN:1;
    unsigned int PORT3_THROTTLE_R_OST_EN:1;
    unsigned int PORT3_THROTTLE_R_BW_EN:1;
    unsigned int PORT3_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT3_THROTTLE_R_OSTLEN_EN:1;
    unsigned int :26;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :26;
    unsigned int PORT3_THROTTLE_R_OSTLEN_EN:1;
    unsigned int PORT3_THROTTLE_CRE_ACCUM_EN:1;
    unsigned int PORT3_THROTTLE_R_BW_EN:1;
    unsigned int PORT3_THROTTLE_R_OST_EN:1;
    unsigned int PORT3_THROTTLE_W_BW_EN:1;
    unsigned int PORT3_THROTTLE_W_OST_EN:1;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_EN_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_EN_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_EN_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_W_OST_THR_OFFSET 0x0498
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_W_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_W_OST_THR:10;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int PORT3_THROTTLE_W_OST_THR:10;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_W_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_W_OST_THR_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_W_OST_THR_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_W_BW_THR_OFFSET 0x049c
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_W_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_W_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT3_THROTTLE_W_BW_THR:25;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_W_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_W_BW_THR_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_W_BW_THR_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_R_OST_THR_OFFSET 0x04a0
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_R_OST_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_R_OST_THR:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int PORT3_THROTTLE_R_OST_THR:16;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_R_OST_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_R_OST_THR_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_R_OST_THR_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_R_BW_THR_OFFSET 0x04a4
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_R_BW_THR_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_R_BW_THR:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT3_THROTTLE_R_BW_THR:25;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_R_BW_THR_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_R_BW_THR_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_R_BW_THR_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_TW_OFFSET 0x04a8
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_TW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_THROTTLE_TW:25;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int PORT3_THROTTLE_TW:25;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_TW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_TW_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_TW_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_OST_NUM_OFFSET 0x04ac
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_OST_NUM_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_W_OST_NUM:10;
    unsigned int PORT3_R_OST_NUM:16;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT3_R_OST_NUM:16;
    unsigned int PORT3_W_OST_NUM:10;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_OST_NUM_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_OST_NUM_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_OST_NUM_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_OST_UDFL_OVFL_OFFSET 0x04b0
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_OST_UDFL_OVFL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_W_OST_UDFL:1;
    unsigned int PORT3_W_OST_OVFL:1;
    unsigned int PORT3_R_OST_UDFL:1;
    unsigned int PORT3_R_OST_OVFL:1;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int PORT3_R_OST_OVFL:1;
    unsigned int PORT3_R_OST_UDFL:1;
    unsigned int PORT3_W_OST_OVFL:1;
    unsigned int PORT3_W_OST_UDFL:1;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_OST_UDFL_OVFL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_OST_UDFL_OVFL_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_OST_UDFL_OVFL_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_AW_OFFSET 0x04b4
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_AW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_W_BW_NUM_AW:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT3_W_BW_NUM_AW:26;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_AW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_AW_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_AW_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_W_OFFSET 0x04b8
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_W_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_W_BW_NUM_W:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT3_W_BW_NUM_W:26;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_W_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_W_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_W_u;

#define DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_R_OFFSET 0x04bc
typedef struct _DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_R_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PORT3_R_BW_NUM_AR:26;
    unsigned int :6;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :6;
    unsigned int PORT3_R_BW_NUM_AR:26;
#endif
} DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_R_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_R_t f;
} DTE_REGS_DTE_PORT3_THROTTLE_BW_NUM_R_u;

#define DTE_REGS_DTE_MBX_CTRL_OFFSET 0x0000
typedef struct _DTE_REGS_DTE_MBX_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_MBX_WAIT_DISABLE:1;
    unsigned int SRC_MBX_REF_CLEAN_DISABLE:1;
    unsigned int :6;
    unsigned int SRC_MBX_SEL:8;
    unsigned int :1;
    unsigned int DST_MBX_WAIT_DISABLE:1;
    unsigned int DST_MBX_REF_CLEAN_DISABLE:1;
    unsigned int :4;
    unsigned int DST_MBX_SEL:8;
    unsigned int :1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :1;
    unsigned int DST_MBX_SEL:8;
    unsigned int :4;
    unsigned int DST_MBX_REF_CLEAN_DISABLE:1;
    unsigned int DST_MBX_WAIT_DISABLE:1;
    unsigned int :1;
    unsigned int SRC_MBX_SEL:8;
    unsigned int :6;
    unsigned int SRC_MBX_REF_CLEAN_DISABLE:1;
    unsigned int SRC_MBX_WAIT_DISABLE:1;
#endif
} DTE_REGS_DTE_MBX_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_MBX_CTRL_t f;
} DTE_REGS_DTE_MBX_CTRL_u;

#define DTE_REGS_DTE_QOS_CTRL_OFFSET 0x0004
typedef struct _DTE_REGS_DTE_QOS_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int QOS_ARB_INC_INTERVAL:16;
    unsigned int QOS_NOC_INC_INTERVAL:16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int QOS_NOC_INC_INTERVAL:16;
    unsigned int QOS_ARB_INC_INTERVAL:16;
#endif
} DTE_REGS_DTE_QOS_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_QOS_CTRL_t f;
} DTE_REGS_DTE_QOS_CTRL_u;

#define DTE_REGS_DTE_VC_CTRL_OFFSET 0x0008
typedef struct _DTE_REGS_DTE_VC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int QOS_ARB_INITIAL:4;
    unsigned int QOS_NOC_INITIAL:4;
    unsigned int QOS_ARB_INC_ENABLE:1;
    unsigned int QOS_NOC_INC_ENABLE:1;
    unsigned int ARB_DYNAMIC_QUEUE_ID:7;
    unsigned int :15;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :15;
    unsigned int ARB_DYNAMIC_QUEUE_ID:7;
    unsigned int QOS_NOC_INC_ENABLE:1;
    unsigned int QOS_ARB_INC_ENABLE:1;
    unsigned int QOS_NOC_INITIAL:4;
    unsigned int QOS_ARB_INITIAL:4;
#endif
} DTE_REGS_DTE_VC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_CTRL_t f;
} DTE_REGS_DTE_VC_CTRL_u;

#define DTE_REGS_DTE_VC_STATUS_OFFSET 0x0010
typedef struct _DTE_REGS_DTE_VC_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_BUSY_STATUS:1;
    unsigned int VC_OCCUPY_STATUS:1;
    unsigned int VC_READY_STATUS:1;
    unsigned int SPMD_CMD:1;
    unsigned int SPMD_EXE_TIMES:28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPMD_EXE_TIMES:28;
    unsigned int SPMD_CMD:1;
    unsigned int VC_READY_STATUS:1;
    unsigned int VC_OCCUPY_STATUS:1;
    unsigned int VC_BUSY_STATUS:1;
#endif
} DTE_REGS_DTE_VC_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_STATUS_t f;
} DTE_REGS_DTE_VC_STATUS_u;

#define DTE_REGS_DTE_CMD_CONTROL_OFFSET 0x0014
typedef struct _DTE_REGS_DTE_CMD_CONTROL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int OP_TYPE:8;
    unsigned int DATA_BPE:2;
    unsigned int :11;
    unsigned int TASK_SPLIT_EN:1;
    unsigned int :2;
    unsigned int VC_THD_MASK:6;
    unsigned int IFB_MODE_DIS:1;
    unsigned int CMD_OPT_EN:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CMD_OPT_EN:1;
    unsigned int IFB_MODE_DIS:1;
    unsigned int VC_THD_MASK:6;
    unsigned int :2;
    unsigned int TASK_SPLIT_EN:1;
    unsigned int :11;
    unsigned int DATA_BPE:2;
    unsigned int OP_TYPE:8;
#endif
} DTE_REGS_DTE_CMD_CONTROL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_CMD_CONTROL_t f;
} DTE_REGS_DTE_CMD_CONTROL_u;

#define DTE_REGS_DTE_SRC_ADDR_HI_OFFSET 0x0018
typedef struct _DTE_REGS_DTE_SRC_ADDR_HI_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_ADDR_HI:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int SRC_ADDR_HI:16;
#endif
} DTE_REGS_DTE_SRC_ADDR_HI_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SRC_ADDR_HI_t f;
} DTE_REGS_DTE_SRC_ADDR_HI_u;

#define DTE_REGS_DTE_SRC_ADDR_LOW_OFFSET 0x001c
typedef struct _DTE_REGS_DTE_SRC_ADDR_LOW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_ADDR_LOW:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SRC_ADDR_LOW:32;
#endif
} DTE_REGS_DTE_SRC_ADDR_LOW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SRC_ADDR_LOW_t f;
} DTE_REGS_DTE_SRC_ADDR_LOW_u;

#define DTE_REGS_DTE_DST_ADDR_HI_OFFSET 0x0020
typedef struct _DTE_REGS_DTE_DST_ADDR_HI_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_ADDR_HI:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int DST_ADDR_HI:16;
#endif
} DTE_REGS_DTE_DST_ADDR_HI_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DST_ADDR_HI_t f;
} DTE_REGS_DTE_DST_ADDR_HI_u;

#define DTE_REGS_DTE_DST_ADDR_LOW_OFFSET 0x0024
typedef struct _DTE_REGS_DTE_DST_ADDR_LOW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_ADDR_LOW:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DST_ADDR_LOW:32;
#endif
} DTE_REGS_DTE_DST_ADDR_LOW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DST_ADDR_LOW_t f;
} DTE_REGS_DTE_DST_ADDR_LOW_u;

#define DTE_REGS_DTE_SPLIT_SIZE_OFFSET 0x0028
typedef struct _DTE_REGS_DTE_SPLIT_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPLIT_SIZE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPLIT_SIZE:32;
#endif
} DTE_REGS_DTE_SPLIT_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SPLIT_SIZE_t f;
} DTE_REGS_DTE_SPLIT_SIZE_u;

#define DTE_REGS_DTE_SPLIT_SIZE_H_OFFSET 0x002c
typedef struct _DTE_REGS_DTE_SPLIT_SIZE_H_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPLIT_SIZE_H:8;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int SPLIT_SIZE_H:8;
#endif
} DTE_REGS_DTE_SPLIT_SIZE_H_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SPLIT_SIZE_H_t f;
} DTE_REGS_DTE_SPLIT_SIZE_H_u;

#define DTE_REGS_DTE_DIM4_SIZE_OFFSET 0x0030
typedef struct _DTE_REGS_DTE_DIM4_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DIM4_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DIM4_SIZE:24;
#endif
} DTE_REGS_DTE_DIM4_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DIM4_SIZE_t f;
} DTE_REGS_DTE_DIM4_SIZE_u;

#define DTE_REGS_DTE_SRC_TOTAL_SIZE_OFFSET 0x0034
typedef struct _DTE_REGS_DTE_SRC_TOTAL_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_TOTAL_SIZE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SRC_TOTAL_SIZE:32;
#endif
} DTE_REGS_DTE_SRC_TOTAL_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SRC_TOTAL_SIZE_t f;
} DTE_REGS_DTE_SRC_TOTAL_SIZE_u;

#define DTE_REGS_DTE_SRC_TOTAL_SIZE_H_OFFSET 0x0038
typedef struct _DTE_REGS_DTE_SRC_TOTAL_SIZE_H_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_TOTAL_SIZE_H:8;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int SRC_TOTAL_SIZE_H:8;
#endif
} DTE_REGS_DTE_SRC_TOTAL_SIZE_H_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SRC_TOTAL_SIZE_H_t f;
} DTE_REGS_DTE_SRC_TOTAL_SIZE_H_u;

#define DTE_REGS_DTE_CMD_START_TRIGGER_OFFSET 0x003c
typedef struct _DTE_REGS_DTE_CMD_START_TRIGGER_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int START_TRIGGER:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int START_TRIGGER:1;
#endif
} DTE_REGS_DTE_CMD_START_TRIGGER_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_CMD_START_TRIGGER_t f;
} DTE_REGS_DTE_CMD_START_TRIGGER_u;

#define DTE_REGS_DTE_VC_ASID_OFFSET 0x0040
typedef struct _DTE_REGS_DTE_VC_ASID_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_ASID:4;
    unsigned int WR_ASID:4;
    unsigned int ASID_SEL:1;
    unsigned int :23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :23;
    unsigned int ASID_SEL:1;
    unsigned int WR_ASID:4;
    unsigned int RD_ASID:4;
#endif
} DTE_REGS_DTE_VC_ASID_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_ASID_t f;
} DTE_REGS_DTE_VC_ASID_u;

#define DTE_REGS_DTE_PKT_INFO_OFFSET 0x0044
typedef struct _DTE_REGS_DTE_PKT_INFO_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PKT_ID:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PKT_ID:32;
#endif
} DTE_REGS_DTE_PKT_INFO_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PKT_INFO_t f;
} DTE_REGS_DTE_PKT_INFO_u;

#define DTE_REGS_DTE_VC_PROCESS_ID_OFFSET 0x0048
typedef struct _DTE_REGS_DTE_VC_PROCESS_ID_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PROCESS_ID:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int PROCESS_ID:16;
#endif
} DTE_REGS_DTE_VC_PROCESS_ID_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_PROCESS_ID_t f;
} DTE_REGS_DTE_VC_PROCESS_ID_u;

#define DTE_REGS_DTE_DECRYPT_CTRL_OFFSET 0x004c
typedef struct _DTE_REGS_DTE_DECRYPT_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_DECRYPT_ON:1;
    unsigned int VC_BLOCK_SIZE:8;
    unsigned int VC_INTEGRITY_ON:1;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int VC_INTEGRITY_ON:1;
    unsigned int VC_BLOCK_SIZE:8;
    unsigned int VC_DECRYPT_ON:1;
#endif
} DTE_REGS_DTE_DECRYPT_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DECRYPT_CTRL_t f;
} DTE_REGS_DTE_DECRYPT_CTRL_u;

#define DTE_REGS_DTE_DECRYPT_BLOCK_START_INDEX_LOW_OFFSET 0x0050
typedef struct _DTE_REGS_DTE_DECRYPT_BLOCK_START_INDEX_LOW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_BLOCK_START_INDEX_LOW:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC_BLOCK_START_INDEX_LOW:32;
#endif
} DTE_REGS_DTE_DECRYPT_BLOCK_START_INDEX_LOW_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DECRYPT_BLOCK_START_INDEX_LOW_t f;
} DTE_REGS_DTE_DECRYPT_BLOCK_START_INDEX_LOW_u;

#define DTE_REGS_DTE_DECRYPT_BLOCK_START_INDEX_HIGH_OFFSET 0x0054
typedef struct _DTE_REGS_DTE_DECRYPT_BLOCK_START_INDEX_HIGH_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_BLOCK_START_INDEX_HIGH:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC_BLOCK_START_INDEX_HIGH:32;
#endif
} DTE_REGS_DTE_DECRYPT_BLOCK_START_INDEX_HIGH_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DECRYPT_BLOCK_START_INDEX_HIGH_t f;
} DTE_REGS_DTE_DECRYPT_BLOCK_START_INDEX_HIGH_u;

#define DTE_REGS_DTE_DECRYPT_BLOCK_INDEX_STEP_OFFSET 0x0058
typedef struct _DTE_REGS_DTE_DECRYPT_BLOCK_INDEX_STEP_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_BLOCK_INDEX_STEP:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC_BLOCK_INDEX_STEP:32;
#endif
} DTE_REGS_DTE_DECRYPT_BLOCK_INDEX_STEP_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DECRYPT_BLOCK_INDEX_STEP_t f;
} DTE_REGS_DTE_DECRYPT_BLOCK_INDEX_STEP_u;

#define DTE_REGS_DTE_DECRYPT_KEY_SCHEDULE_DONE_OFFSET 0x005c
typedef struct _DTE_REGS_DTE_DECRYPT_KEY_SCHEDULE_DONE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_KEY_SCHEDULE_DONE:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int VC_KEY_SCHEDULE_DONE:1;
#endif
} DTE_REGS_DTE_DECRYPT_KEY_SCHEDULE_DONE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DECRYPT_KEY_SCHEDULE_DONE_t f;
} DTE_REGS_DTE_DECRYPT_KEY_SCHEDULE_DONE_u;

#define DTE_REGS_DTE_RD_ARUSER_CFG_OFFSET 0x0000
typedef struct _DTE_REGS_DTE_RD_ARUSER_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_ESL_ORDER_CONTROL:1;
    unsigned int RD_HW_PF_HINT:1;
    unsigned int :30;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :30;
    unsigned int RD_HW_PF_HINT:1;
    unsigned int RD_ESL_ORDER_CONTROL:1;
#endif
} DTE_REGS_DTE_RD_ARUSER_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_RD_ARUSER_CFG_t f;
} DTE_REGS_DTE_RD_ARUSER_CFG_u;

#define DTE_REGS_DTE_WR_AWUSER_CFG_OFFSET 0x0004
typedef struct _DTE_REGS_DTE_WR_AWUSER_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WR_ESL_ORDER_CONTROL:1;
    unsigned int WR_HW_PF_HINT:1;
    unsigned int :30;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :30;
    unsigned int WR_HW_PF_HINT:1;
    unsigned int WR_ESL_ORDER_CONTROL:1;
#endif
} DTE_REGS_DTE_WR_AWUSER_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_WR_AWUSER_CFG_t f;
} DTE_REGS_DTE_WR_AWUSER_CFG_u;

#define DTE_REGS_DTE_SPARE_SRAM_REG0_OFFSET 0x0008
typedef struct _DTE_REGS_DTE_SPARE_SRAM_REG0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPARE_SRAM_REG0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPARE_SRAM_REG0:32;
#endif
} DTE_REGS_DTE_SPARE_SRAM_REG0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SPARE_SRAM_REG0_t f;
} DTE_REGS_DTE_SPARE_SRAM_REG0_u;

#define DTE_REGS_DTE_AXI_CFG_OFFSET 0x000c
typedef struct _DTE_REGS_DTE_AXI_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int AXI_AWPROT:3;
    unsigned int :1;
    unsigned int AXI_ARPROT:3;
    unsigned int :1;
    unsigned int AXI_ARCACHE:4;
    unsigned int AXI_AWCACHE:4;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int AXI_AWCACHE:4;
    unsigned int AXI_ARCACHE:4;
    unsigned int :1;
    unsigned int AXI_ARPROT:3;
    unsigned int :1;
    unsigned int AXI_AWPROT:3;
#endif
} DTE_REGS_DTE_AXI_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_AXI_CFG_t f;
} DTE_REGS_DTE_AXI_CFG_u;

#define DTE_REGS_DTE_SIG_SRC_CTRL_OFFSET 0x0010
typedef struct _DTE_REGS_DTE_SIG_SRC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_SRC_DISABLE:1;
    unsigned int SIG_SRC_ADDR:31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_SRC_ADDR:31;
    unsigned int SIG_SRC_DISABLE:1;
#endif
} DTE_REGS_DTE_SIG_SRC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SIG_SRC_CTRL_t f;
} DTE_REGS_DTE_SIG_SRC_CTRL_u;

#define DTE_REGS_DTE_SIG_SRC_DATA_OFFSET 0x0014
typedef struct _DTE_REGS_DTE_SIG_SRC_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_SRC_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_SRC_DATA:32;
#endif
} DTE_REGS_DTE_SIG_SRC_DATA_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SIG_SRC_DATA_t f;
} DTE_REGS_DTE_SIG_SRC_DATA_u;

#define DTE_REGS_DTE_SIG_DST_CTRL_OFFSET 0x0018
typedef struct _DTE_REGS_DTE_SIG_DST_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_DST_DISABLE:1;
    unsigned int SIG_DST_ADDR:31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_DST_ADDR:31;
    unsigned int SIG_DST_DISABLE:1;
#endif
} DTE_REGS_DTE_SIG_DST_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SIG_DST_CTRL_t f;
} DTE_REGS_DTE_SIG_DST_CTRL_u;

#define DTE_REGS_DTE_SIG_DST_DATA_OFFSET 0x001c
typedef struct _DTE_REGS_DTE_SIG_DST_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_DST_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_DST_DATA:32;
#endif
} DTE_REGS_DTE_SIG_DST_DATA_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SIG_DST_DATA_t f;
} DTE_REGS_DTE_SIG_DST_DATA_u;

#define DTE_REGS_DTE_SIG_MNG_CTRL_OFFSET 0x0020
typedef struct _DTE_REGS_DTE_SIG_MNG_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_MNG_DISABLE:1;
    unsigned int SIG_MNG_ADDR:31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_MNG_ADDR:31;
    unsigned int SIG_MNG_DISABLE:1;
#endif
} DTE_REGS_DTE_SIG_MNG_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SIG_MNG_CTRL_t f;
} DTE_REGS_DTE_SIG_MNG_CTRL_u;

#define DTE_REGS_DTE_SIG_MNG_DATA_OFFSET 0x0024
typedef struct _DTE_REGS_DTE_SIG_MNG_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_MNG_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_MNG_DATA:32;
#endif
} DTE_REGS_DTE_SIG_MNG_DATA_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SIG_MNG_DATA_t f;
} DTE_REGS_DTE_SIG_MNG_DATA_u;

#define DTE_REGS_DTE_SPARE_SRAM_REG1_OFFSET 0x0028
typedef struct _DTE_REGS_DTE_SPARE_SRAM_REG1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPARE_SRAM_REG1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPARE_SRAM_REG1:32;
#endif
} DTE_REGS_DTE_SPARE_SRAM_REG1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SPARE_SRAM_REG1_t f;
} DTE_REGS_DTE_SPARE_SRAM_REG1_u;

#define DTE_REGS_DTE_SPARE_SRAM_REG2_OFFSET 0x002c
typedef struct _DTE_REGS_DTE_SPARE_SRAM_REG2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPARE_SRAM_REG2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPARE_SRAM_REG2:32;
#endif
} DTE_REGS_DTE_SPARE_SRAM_REG2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SPARE_SRAM_REG2_t f;
} DTE_REGS_DTE_SPARE_SRAM_REG2_u;

#define DTE_REGS_DTE_WTMK_CTRL_OFFSET 0x0030
typedef struct _DTE_REGS_DTE_WTMK_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WTMK_CTRL_EN:1;
    unsigned int :3;
    unsigned int IFB_WTMK_THRSHLD:10;
    unsigned int :18;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :18;
    unsigned int IFB_WTMK_THRSHLD:10;
    unsigned int :3;
    unsigned int WTMK_CTRL_EN:1;
#endif
} DTE_REGS_DTE_WTMK_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_WTMK_CTRL_t f;
} DTE_REGS_DTE_WTMK_CTRL_u;

#define DTE_REGS_DTE_SPARE_SRAM_REG3_OFFSET 0x0034
typedef struct _DTE_REGS_DTE_SPARE_SRAM_REG3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPARE_SRAM_REG3:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPARE_SRAM_REG3:32;
#endif
} DTE_REGS_DTE_SPARE_SRAM_REG3_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SPARE_SRAM_REG3_t f;
} DTE_REGS_DTE_SPARE_SRAM_REG3_u;

#define DTE_REGS_DTE_VC_ATOMIC_CFG_OFFSET 0x0038
typedef struct _DTE_REGS_DTE_VC_ATOMIC_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ATOMIC_DATA_TYPE:4;
    unsigned int ATOMIC_CAS_FLAG:1;
    unsigned int ATOMIC_SCA_VEC_SEL:1;
    unsigned int ATOMIC_MODE:1;
    unsigned int ATOMIC_AWATOP:5;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int ATOMIC_AWATOP:5;
    unsigned int ATOMIC_MODE:1;
    unsigned int ATOMIC_SCA_VEC_SEL:1;
    unsigned int ATOMIC_CAS_FLAG:1;
    unsigned int ATOMIC_DATA_TYPE:4;
#endif
} DTE_REGS_DTE_VC_ATOMIC_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_VC_ATOMIC_CFG_t f;
} DTE_REGS_DTE_VC_ATOMIC_CFG_u;

#define DTE_REGS_DTE_SPARE_SRAM_REG4_OFFSET 0x003c
typedef struct _DTE_REGS_DTE_SPARE_SRAM_REG4_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPARE_SRAM_REG4:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPARE_SRAM_REG4:32;
#endif
} DTE_REGS_DTE_SPARE_SRAM_REG4_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SPARE_SRAM_REG4_t f;
} DTE_REGS_DTE_SPARE_SRAM_REG4_u;

#define DTE_REGS_DTE_GSYNC_CTRL_OFFSET 0x0040
typedef struct _DTE_REGS_DTE_GSYNC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_MODE:1;
    unsigned int REG_ENTRY_IDX:8;
    unsigned int GSYNC_SLV_BASE_ADDR_SEL:3;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int GSYNC_SLV_BASE_ADDR_SEL:3;
    unsigned int REG_ENTRY_IDX:8;
    unsigned int GSYNC_MODE:1;
#endif
} DTE_REGS_DTE_GSYNC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_GSYNC_CTRL_t f;
} DTE_REGS_DTE_GSYNC_CTRL_u;

#define DTE_REGS_DTE_GSYNC_REGISTER_DATA0_OFFSET 0x0044
typedef struct _DTE_REGS_DTE_GSYNC_REGISTER_DATA0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_DATA:32;
#endif
} DTE_REGS_DTE_GSYNC_REGISTER_DATA0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_GSYNC_REGISTER_DATA0_t f;
} DTE_REGS_DTE_GSYNC_REGISTER_DATA0_u;

#define DTE_REGS_DTE_GSYNC_REGISTER_DATA1_OFFSET 0x0048
typedef struct _DTE_REGS_DTE_GSYNC_REGISTER_DATA1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_ADDR:30;
    unsigned int WAIT_ENTRY_RSVD:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_RSVD:2;
    unsigned int WAIT_ENTRY_ADDR:30;
#endif
} DTE_REGS_DTE_GSYNC_REGISTER_DATA1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_GSYNC_REGISTER_DATA1_t f;
} DTE_REGS_DTE_GSYNC_REGISTER_DATA1_u;

#define DTE_REGS_DTE_GSYNC_REGISTER_DATA2_OFFSET 0x004c
typedef struct _DTE_REGS_DTE_GSYNC_REGISTER_DATA2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_WAIT:23;
    unsigned int WAIT_ENTRY_MODE:2;
    unsigned int WAIT_ENTRY_TID:7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_TID:7;
    unsigned int WAIT_ENTRY_MODE:2;
    unsigned int WAIT_ENTRY_WAIT:23;
#endif
} DTE_REGS_DTE_GSYNC_REGISTER_DATA2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_GSYNC_REGISTER_DATA2_t f;
} DTE_REGS_DTE_GSYNC_REGISTER_DATA2_u;

#define DTE_REGS_DTE_GSYNC_SIGNAL_INFO_OFFSET 0x0050
typedef struct _DTE_REGS_DTE_GSYNC_SIGNAL_INFO_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIGNAL_INFO:25;
    unsigned int SIGNAL_IDX:7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIGNAL_IDX:7;
    unsigned int SIGNAL_INFO:25;
#endif
} DTE_REGS_DTE_GSYNC_SIGNAL_INFO_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_GSYNC_SIGNAL_INFO_t f;
} DTE_REGS_DTE_GSYNC_SIGNAL_INFO_u;

#define DTE_REGS_DTE_SHR_CTRL_OFFSET 0x0058
typedef struct _DTE_REGS_DTE_SHR_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SHR_PHASE:2;
    unsigned int SHR_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int SHR_RATIO:2;
    unsigned int SHR_PHASE:2;
#endif
} DTE_REGS_DTE_SHR_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SHR_CTRL_t f;
} DTE_REGS_DTE_SHR_CTRL_u;

#define DTE_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _DTE_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} DTE_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SRC_DIM0_SIZE_t f;
} DTE_REGS_DTE_SRC_DIM0_SIZE_u;

#define DTE_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _DTE_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} DTE_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SRC_DIM1_SIZE_t f;
} DTE_REGS_DTE_SRC_DIM1_SIZE_u;

#define DTE_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _DTE_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} DTE_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SRC_DIM2_SIZE_t f;
} DTE_REGS_DTE_SRC_DIM2_SIZE_u;

#define DTE_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _DTE_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} DTE_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SRC_DIM3_SIZE_t f;
} DTE_REGS_DTE_SRC_DIM3_SIZE_u;

#define DTE_REGS_DTE_EXP_CTRL_OFFSET 0x006c
typedef struct _DTE_REGS_DTE_EXP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EXP_PHASE:2;
    unsigned int EXP_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int EXP_RATIO:2;
    unsigned int EXP_PHASE:2;
#endif
} DTE_REGS_DTE_EXP_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_EXP_CTRL_t f;
} DTE_REGS_DTE_EXP_CTRL_u;

#define DTE_REGS_DTE_CONSTANT_DATA_OFFSET 0x0058
typedef struct _DTE_REGS_DTE_CONSTANT_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CONSTANT_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CONSTANT_DATA:32;
#endif
} DTE_REGS_DTE_CONSTANT_DATA_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_CONSTANT_DATA_t f;
} DTE_REGS_DTE_CONSTANT_DATA_u;

#define DTE_REGS_DTE_PAD_CTRL_DIM0_OFFSET 0x0070
typedef struct _DTE_REGS_DTE_PAD_CTRL_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM0_LOW:11;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int PAD_DIM0_LOW:11;
#endif
} DTE_REGS_DTE_PAD_CTRL_DIM0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PAD_CTRL_DIM0_t f;
} DTE_REGS_DTE_PAD_CTRL_DIM0_u;

#define DTE_REGS_DTE_PAD_CTRL_DIM1_OFFSET 0x0074
typedef struct _DTE_REGS_DTE_PAD_CTRL_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM1_LOW:11;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM1_INTERIOR:10;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_LOW:11;
#endif
} DTE_REGS_DTE_PAD_CTRL_DIM1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PAD_CTRL_DIM1_t f;
} DTE_REGS_DTE_PAD_CTRL_DIM1_u;

#define DTE_REGS_DTE_PAD_CTRL_DIM2_OFFSET 0x0078
typedef struct _DTE_REGS_DTE_PAD_CTRL_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM2_LOW:11;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM2_INTERIOR:10;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_LOW:11;
#endif
} DTE_REGS_DTE_PAD_CTRL_DIM2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PAD_CTRL_DIM2_t f;
} DTE_REGS_DTE_PAD_CTRL_DIM2_u;

#define DTE_REGS_DTE_PAD_CTRL_DIM3_OFFSET 0x007c
typedef struct _DTE_REGS_DTE_PAD_CTRL_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM3_LOW:11;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM3_INTERIOR:10;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_LOW:11;
#endif
} DTE_REGS_DTE_PAD_CTRL_DIM3_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PAD_CTRL_DIM3_t f;
} DTE_REGS_DTE_PAD_CTRL_DIM3_u;

#define DTE_REGS_DTE_PAD_VALUE_OFFSET 0x0080
typedef struct _DTE_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} DTE_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_PAD_VALUE_t f;
} DTE_REGS_DTE_PAD_VALUE_u;

#define DTE_REGS_DTE_RESHAPE_CTRL_OFFSET 0x006c
typedef struct _DTE_REGS_DTE_RESHAPE_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESHAPE_DIM0_MAP:2;
    unsigned int RESHAPE_DIM1_MAP:2;
    unsigned int RESHAPE_DIM2_MAP:2;
    unsigned int RESHAPE_DIM3_MAP:2;
    unsigned int ENHANCE_RESHAPE_MODE:1;
    unsigned int :23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :23;
    unsigned int ENHANCE_RESHAPE_MODE:1;
    unsigned int RESHAPE_DIM3_MAP:2;
    unsigned int RESHAPE_DIM2_MAP:2;
    unsigned int RESHAPE_DIM1_MAP:2;
    unsigned int RESHAPE_DIM0_MAP:2;
#endif
} DTE_REGS_DTE_RESHAPE_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_RESHAPE_CTRL_t f;
} DTE_REGS_DTE_RESHAPE_CTRL_u;

#define DTE_REGS_DTE_BRDCST_CTRL_OFFSET 0x006c
typedef struct _DTE_REGS_DTE_BRDCST_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int BRDCST_DIM:2;
    unsigned int :6;
    unsigned int BRDCST_SIZE:24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int BRDCST_SIZE:24;
    unsigned int :6;
    unsigned int BRDCST_DIM:2;
#endif
} DTE_REGS_DTE_BRDCST_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_BRDCST_CTRL_t f;
} DTE_REGS_DTE_BRDCST_CTRL_u;

#define DTE_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _DTE_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} DTE_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SLICE_SIZE_DIM0_t f;
} DTE_REGS_DTE_SLICE_SIZE_DIM0_u;

#define DTE_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _DTE_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} DTE_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SLICE_SIZE_DIM1_t f;
} DTE_REGS_DTE_SLICE_SIZE_DIM1_u;

#define DTE_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _DTE_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} DTE_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SLICE_SIZE_DIM2_t f;
} DTE_REGS_DTE_SLICE_SIZE_DIM2_u;

#define DTE_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _DTE_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} DTE_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SLICE_SIZE_DIM3_t f;
} DTE_REGS_DTE_SLICE_SIZE_DIM3_u;

#define DTE_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _DTE_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int SLICE_DIM0_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM0_START_DIR:1;
    unsigned int SLICE_DIM0_START:24;
#endif
} DTE_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SLICE_START_DIM0_t f;
} DTE_REGS_DTE_SLICE_START_DIM0_u;

#define DTE_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _DTE_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int SLICE_DIM1_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM1_START_DIR:1;
    unsigned int SLICE_DIM1_START:24;
#endif
} DTE_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SLICE_START_DIM1_t f;
} DTE_REGS_DTE_SLICE_START_DIM1_u;

#define DTE_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _DTE_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int SLICE_DIM2_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM2_START_DIR:1;
    unsigned int SLICE_DIM2_START:24;
#endif
} DTE_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SLICE_START_DIM2_t f;
} DTE_REGS_DTE_SLICE_START_DIM2_u;

#define DTE_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0088
typedef struct _DTE_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int SLICE_DIM3_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM3_START_DIR:1;
    unsigned int SLICE_DIM3_START:24;
#endif
} DTE_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SLICE_START_DIM3_t f;
} DTE_REGS_DTE_SLICE_START_DIM3_u;

#define DTE_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _DTE_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} DTE_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DST_DIM0_SIZE_t f;
} DTE_REGS_DTE_DST_DIM0_SIZE_u;

#define DTE_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _DTE_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} DTE_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DST_DIM1_SIZE_t f;
} DTE_REGS_DTE_DST_DIM1_SIZE_u;

#define DTE_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _DTE_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} DTE_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DST_DIM2_SIZE_t f;
} DTE_REGS_DTE_DST_DIM2_SIZE_u;

#define DTE_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _DTE_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} DTE_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DST_DIM3_SIZE_t f;
} DTE_REGS_DTE_DST_DIM3_SIZE_u;

#define DTE_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _DTE_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} DTE_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DSL_START_DIM0_t f;
} DTE_REGS_DTE_DSL_START_DIM0_u;

#define DTE_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _DTE_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} DTE_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DSL_START_DIM1_t f;
} DTE_REGS_DTE_DSL_START_DIM1_u;

#define DTE_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _DTE_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} DTE_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DSL_START_DIM2_t f;
} DTE_REGS_DTE_DSL_START_DIM2_u;

#define DTE_REGS_DTE_DSL_START_DIM3_OFFSET 0x008c
typedef struct _DTE_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} DTE_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_DSL_START_DIM3_t f;
} DTE_REGS_DTE_DSL_START_DIM3_u;

#define DTE_REGS_DTE_SSMP_CTRL_OFFSET 0x006c
typedef struct _DTE_REGS_DTE_SSMP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SSMP_ROW_STRIDE:11;
    unsigned int :21;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :21;
    unsigned int SSMP_ROW_STRIDE:11;
#endif
} DTE_REGS_DTE_SSMP_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SSMP_CTRL_t f;
} DTE_REGS_DTE_SSMP_CTRL_u;

#define DTE_REGS_DTE_SLC_RESHAPE_CTRL_OFFSET 0x006c
typedef struct _DTE_REGS_DTE_SLC_RESHAPE_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLC_RESHAPE_DIM0_MAP:2;
    unsigned int SLC_RESHAPE_DIM1_MAP:2;
    unsigned int SLC_RESHAPE_DIM2_MAP:2;
    unsigned int SLC_RESHAPE_DIM3_MAP:2;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int SLC_RESHAPE_DIM3_MAP:2;
    unsigned int SLC_RESHAPE_DIM2_MAP:2;
    unsigned int SLC_RESHAPE_DIM1_MAP:2;
    unsigned int SLC_RESHAPE_DIM0_MAP:2;
#endif
} DTE_REGS_DTE_SLC_RESHAPE_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_SLC_RESHAPE_CTRL_t f;
} DTE_REGS_DTE_SLC_RESHAPE_CTRL_u;

#define DTE_REGS_DTE_RESHAPE_DSL_CTRL_OFFSET 0x0058
typedef struct _DTE_REGS_DTE_RESHAPE_DSL_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESHAPE_DSL_DIM0_MAP:2;
    unsigned int RESHAPE_DSL_DIM1_MAP:2;
    unsigned int RESHAPE_DSL_DIM2_MAP:2;
    unsigned int RESHAPE_DSL_DIM3_MAP:2;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int RESHAPE_DSL_DIM3_MAP:2;
    unsigned int RESHAPE_DSL_DIM2_MAP:2;
    unsigned int RESHAPE_DSL_DIM1_MAP:2;
    unsigned int RESHAPE_DSL_DIM0_MAP:2;
#endif
} DTE_REGS_DTE_RESHAPE_DSL_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_REGS_DTE_RESHAPE_DSL_CTRL_t f;
} DTE_REGS_DTE_RESHAPE_DSL_CTRL_u;

#define DTE_VC_DIRECT_REGS_DTE_MBX_CTRL_OFFSET 0x0000
typedef struct _DTE_VC_DIRECT_REGS_DTE_MBX_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_MBX_WAIT_DISABLE:1;
    unsigned int SRC_MBX_REF_CLEAN_DISABLE:1;
    unsigned int :6;
    unsigned int SRC_MBX_SEL:8;
    unsigned int :1;
    unsigned int DST_MBX_WAIT_DISABLE:1;
    unsigned int DST_MBX_REF_CLEAN_DISABLE:1;
    unsigned int :4;
    unsigned int DST_MBX_SEL:8;
    unsigned int :1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :1;
    unsigned int DST_MBX_SEL:8;
    unsigned int :4;
    unsigned int DST_MBX_REF_CLEAN_DISABLE:1;
    unsigned int DST_MBX_WAIT_DISABLE:1;
    unsigned int :1;
    unsigned int SRC_MBX_SEL:8;
    unsigned int :6;
    unsigned int SRC_MBX_REF_CLEAN_DISABLE:1;
    unsigned int SRC_MBX_WAIT_DISABLE:1;
#endif
} DTE_VC_DIRECT_REGS_DTE_MBX_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_MBX_CTRL_t f;
} DTE_VC_DIRECT_REGS_DTE_MBX_CTRL_u;

#define DTE_VC_DIRECT_REGS_DTE_QOS_CTRL_OFFSET 0x0004
typedef struct _DTE_VC_DIRECT_REGS_DTE_QOS_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int QOS_ARB_INC_INTERVAL:16;
    unsigned int QOS_NOC_INC_INTERVAL:16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int QOS_NOC_INC_INTERVAL:16;
    unsigned int QOS_ARB_INC_INTERVAL:16;
#endif
} DTE_VC_DIRECT_REGS_DTE_QOS_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_QOS_CTRL_t f;
} DTE_VC_DIRECT_REGS_DTE_QOS_CTRL_u;

#define DTE_VC_DIRECT_REGS_DTE_VC_CTRL_OFFSET 0x0008
typedef struct _DTE_VC_DIRECT_REGS_DTE_VC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int QOS_ARB_INITIAL:4;
    unsigned int QOS_NOC_INITIAL:4;
    unsigned int QOS_ARB_INC_ENABLE:1;
    unsigned int QOS_NOC_INC_ENABLE:1;
    unsigned int ARB_DYNAMIC_QUEUE_ID:7;
    unsigned int :15;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :15;
    unsigned int ARB_DYNAMIC_QUEUE_ID:7;
    unsigned int QOS_NOC_INC_ENABLE:1;
    unsigned int QOS_ARB_INC_ENABLE:1;
    unsigned int QOS_NOC_INITIAL:4;
    unsigned int QOS_ARB_INITIAL:4;
#endif
} DTE_VC_DIRECT_REGS_DTE_VC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_VC_CTRL_t f;
} DTE_VC_DIRECT_REGS_DTE_VC_CTRL_u;

#define DTE_VC_DIRECT_REGS_DTE_VC_STATUS_OFFSET 0x0010
typedef struct _DTE_VC_DIRECT_REGS_DTE_VC_STATUS_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_BUSY_STATUS:1;
    unsigned int VC_OCCUPY_STATUS:1;
    unsigned int VC_READY_STATUS:1;
    unsigned int SPMD_CMD:1;
    unsigned int SPMD_EXE_TIMES:28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPMD_EXE_TIMES:28;
    unsigned int SPMD_CMD:1;
    unsigned int VC_READY_STATUS:1;
    unsigned int VC_OCCUPY_STATUS:1;
    unsigned int VC_BUSY_STATUS:1;
#endif
} DTE_VC_DIRECT_REGS_DTE_VC_STATUS_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_VC_STATUS_t f;
} DTE_VC_DIRECT_REGS_DTE_VC_STATUS_u;

#define DTE_VC_DIRECT_REGS_DTE_CMD_CONTROL_OFFSET 0x0014
typedef struct _DTE_VC_DIRECT_REGS_DTE_CMD_CONTROL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int OP_TYPE:8;
    unsigned int DATA_BPE:2;
    unsigned int :11;
    unsigned int TASK_SPLIT_EN:1;
    unsigned int :2;
    unsigned int VC_THD_MASK:6;
    unsigned int IFB_MODE_DIS:1;
    unsigned int CMD_OPT_EN:1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CMD_OPT_EN:1;
    unsigned int IFB_MODE_DIS:1;
    unsigned int VC_THD_MASK:6;
    unsigned int :2;
    unsigned int TASK_SPLIT_EN:1;
    unsigned int :11;
    unsigned int DATA_BPE:2;
    unsigned int OP_TYPE:8;
#endif
} DTE_VC_DIRECT_REGS_DTE_CMD_CONTROL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_CMD_CONTROL_t f;
} DTE_VC_DIRECT_REGS_DTE_CMD_CONTROL_u;

#define DTE_VC_DIRECT_REGS_DTE_SRC_ADDR_HI_OFFSET 0x0018
typedef struct _DTE_VC_DIRECT_REGS_DTE_SRC_ADDR_HI_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_ADDR_HI:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int SRC_ADDR_HI:16;
#endif
} DTE_VC_DIRECT_REGS_DTE_SRC_ADDR_HI_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_SRC_ADDR_HI_t f;
} DTE_VC_DIRECT_REGS_DTE_SRC_ADDR_HI_u;

#define DTE_VC_DIRECT_REGS_DTE_SRC_ADDR_LOW_OFFSET 0x001c
typedef struct _DTE_VC_DIRECT_REGS_DTE_SRC_ADDR_LOW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_ADDR_LOW:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SRC_ADDR_LOW:32;
#endif
} DTE_VC_DIRECT_REGS_DTE_SRC_ADDR_LOW_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_SRC_ADDR_LOW_t f;
} DTE_VC_DIRECT_REGS_DTE_SRC_ADDR_LOW_u;

#define DTE_VC_DIRECT_REGS_DTE_DST_ADDR_HI_OFFSET 0x0020
typedef struct _DTE_VC_DIRECT_REGS_DTE_DST_ADDR_HI_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_ADDR_HI:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int DST_ADDR_HI:16;
#endif
} DTE_VC_DIRECT_REGS_DTE_DST_ADDR_HI_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_DST_ADDR_HI_t f;
} DTE_VC_DIRECT_REGS_DTE_DST_ADDR_HI_u;

#define DTE_VC_DIRECT_REGS_DTE_DST_ADDR_LOW_OFFSET 0x0024
typedef struct _DTE_VC_DIRECT_REGS_DTE_DST_ADDR_LOW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_ADDR_LOW:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DST_ADDR_LOW:32;
#endif
} DTE_VC_DIRECT_REGS_DTE_DST_ADDR_LOW_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_DST_ADDR_LOW_t f;
} DTE_VC_DIRECT_REGS_DTE_DST_ADDR_LOW_u;

#define DTE_VC_DIRECT_REGS_DTE_SPLIT_SIZE_OFFSET 0x0028
typedef struct _DTE_VC_DIRECT_REGS_DTE_SPLIT_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPLIT_SIZE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPLIT_SIZE:32;
#endif
} DTE_VC_DIRECT_REGS_DTE_SPLIT_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_SPLIT_SIZE_t f;
} DTE_VC_DIRECT_REGS_DTE_SPLIT_SIZE_u;

#define DTE_VC_DIRECT_REGS_DTE_SPLIT_SIZE_H_OFFSET 0x002c
typedef struct _DTE_VC_DIRECT_REGS_DTE_SPLIT_SIZE_H_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPLIT_SIZE_H:8;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int SPLIT_SIZE_H:8;
#endif
} DTE_VC_DIRECT_REGS_DTE_SPLIT_SIZE_H_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_SPLIT_SIZE_H_t f;
} DTE_VC_DIRECT_REGS_DTE_SPLIT_SIZE_H_u;

#define DTE_VC_DIRECT_REGS_DTE_DIM4_SIZE_OFFSET 0x0030
typedef struct _DTE_VC_DIRECT_REGS_DTE_DIM4_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DIM4_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DIM4_SIZE:24;
#endif
} DTE_VC_DIRECT_REGS_DTE_DIM4_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_DIM4_SIZE_t f;
} DTE_VC_DIRECT_REGS_DTE_DIM4_SIZE_u;

#define DTE_VC_DIRECT_REGS_DTE_SRC_TOTAL_SIZE_OFFSET 0x0034
typedef struct _DTE_VC_DIRECT_REGS_DTE_SRC_TOTAL_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_TOTAL_SIZE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SRC_TOTAL_SIZE:32;
#endif
} DTE_VC_DIRECT_REGS_DTE_SRC_TOTAL_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_SRC_TOTAL_SIZE_t f;
} DTE_VC_DIRECT_REGS_DTE_SRC_TOTAL_SIZE_u;

#define DTE_VC_DIRECT_REGS_DTE_SRC_TOTAL_SIZE_H_OFFSET 0x0038
typedef struct _DTE_VC_DIRECT_REGS_DTE_SRC_TOTAL_SIZE_H_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_TOTAL_SIZE_H:8;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int SRC_TOTAL_SIZE_H:8;
#endif
} DTE_VC_DIRECT_REGS_DTE_SRC_TOTAL_SIZE_H_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_SRC_TOTAL_SIZE_H_t f;
} DTE_VC_DIRECT_REGS_DTE_SRC_TOTAL_SIZE_H_u;

#define DTE_VC_DIRECT_REGS_DTE_CMD_START_TRIGGER_OFFSET 0x003c
typedef struct _DTE_VC_DIRECT_REGS_DTE_CMD_START_TRIGGER_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int START_TRIGGER:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int START_TRIGGER:1;
#endif
} DTE_VC_DIRECT_REGS_DTE_CMD_START_TRIGGER_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_CMD_START_TRIGGER_t f;
} DTE_VC_DIRECT_REGS_DTE_CMD_START_TRIGGER_u;

#define DTE_VC_DIRECT_REGS_DTE_VC_ASID_OFFSET 0x0040
typedef struct _DTE_VC_DIRECT_REGS_DTE_VC_ASID_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_ASID:4;
    unsigned int WR_ASID:4;
    unsigned int ASID_SEL:1;
    unsigned int :23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :23;
    unsigned int ASID_SEL:1;
    unsigned int WR_ASID:4;
    unsigned int RD_ASID:4;
#endif
} DTE_VC_DIRECT_REGS_DTE_VC_ASID_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_VC_ASID_t f;
} DTE_VC_DIRECT_REGS_DTE_VC_ASID_u;

#define DTE_VC_DIRECT_REGS_DTE_PKT_INFO_OFFSET 0x0044
typedef struct _DTE_VC_DIRECT_REGS_DTE_PKT_INFO_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PKT_ID:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PKT_ID:32;
#endif
} DTE_VC_DIRECT_REGS_DTE_PKT_INFO_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_PKT_INFO_t f;
} DTE_VC_DIRECT_REGS_DTE_PKT_INFO_u;

#define DTE_VC_DIRECT_REGS_DTE_VC_PROCESS_ID_OFFSET 0x0048
typedef struct _DTE_VC_DIRECT_REGS_DTE_VC_PROCESS_ID_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PROCESS_ID:16;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int PROCESS_ID:16;
#endif
} DTE_VC_DIRECT_REGS_DTE_VC_PROCESS_ID_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_VC_PROCESS_ID_t f;
} DTE_VC_DIRECT_REGS_DTE_VC_PROCESS_ID_u;

#define DTE_VC_DIRECT_REGS_DTE_DECRYPT_CTRL_OFFSET 0x004c
typedef struct _DTE_VC_DIRECT_REGS_DTE_DECRYPT_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_DECRYPT_ON:1;
    unsigned int VC_BLOCK_SIZE:8;
    unsigned int VC_INTEGRITY_ON:1;
    unsigned int :22;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :22;
    unsigned int VC_INTEGRITY_ON:1;
    unsigned int VC_BLOCK_SIZE:8;
    unsigned int VC_DECRYPT_ON:1;
#endif
} DTE_VC_DIRECT_REGS_DTE_DECRYPT_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_DECRYPT_CTRL_t f;
} DTE_VC_DIRECT_REGS_DTE_DECRYPT_CTRL_u;

#define DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_START_INDEX_LOW_OFFSET 0x0050
typedef struct _DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_START_INDEX_LOW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_BLOCK_START_INDEX_LOW:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC_BLOCK_START_INDEX_LOW:32;
#endif
} DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_START_INDEX_LOW_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_START_INDEX_LOW_t f;
} DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_START_INDEX_LOW_u;

#define DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_START_INDEX_HIGH_OFFSET 0x0054
typedef struct _DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_START_INDEX_HIGH_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_BLOCK_START_INDEX_HIGH:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC_BLOCK_START_INDEX_HIGH:32;
#endif
} DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_START_INDEX_HIGH_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_START_INDEX_HIGH_t f;
} DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_START_INDEX_HIGH_u;

#define DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_INDEX_STEP_OFFSET 0x0058
typedef struct _DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_INDEX_STEP_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_BLOCK_INDEX_STEP:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int VC_BLOCK_INDEX_STEP:32;
#endif
} DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_INDEX_STEP_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_INDEX_STEP_t f;
} DTE_VC_DIRECT_REGS_DTE_DECRYPT_BLOCK_INDEX_STEP_u;

#define DTE_VC_DIRECT_REGS_DTE_DECRYPT_KEY_SCHEDULE_DONE_OFFSET 0x005c
typedef struct _DTE_VC_DIRECT_REGS_DTE_DECRYPT_KEY_SCHEDULE_DONE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int VC_KEY_SCHEDULE_DONE:1;
    unsigned int :31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :31;
    unsigned int VC_KEY_SCHEDULE_DONE:1;
#endif
} DTE_VC_DIRECT_REGS_DTE_DECRYPT_KEY_SCHEDULE_DONE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_DIRECT_REGS_DTE_DECRYPT_KEY_SCHEDULE_DONE_t f;
} DTE_VC_DIRECT_REGS_DTE_DECRYPT_KEY_SCHEDULE_DONE_u;

#define DTE_VC_SRAM_REGS_DTE_RD_ARUSER_CFG_OFFSET 0x0000
typedef struct _DTE_VC_SRAM_REGS_DTE_RD_ARUSER_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RD_ESL_ORDER_CONTROL:1;
    unsigned int RD_HW_PF_HINT:1;
    unsigned int :30;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :30;
    unsigned int RD_HW_PF_HINT:1;
    unsigned int RD_ESL_ORDER_CONTROL:1;
#endif
} DTE_VC_SRAM_REGS_DTE_RD_ARUSER_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_RD_ARUSER_CFG_t f;
} DTE_VC_SRAM_REGS_DTE_RD_ARUSER_CFG_u;

#define DTE_VC_SRAM_REGS_DTE_WR_AWUSER_CFG_OFFSET 0x0004
typedef struct _DTE_VC_SRAM_REGS_DTE_WR_AWUSER_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WR_ESL_ORDER_CONTROL:1;
    unsigned int WR_HW_PF_HINT:1;
    unsigned int :30;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :30;
    unsigned int WR_HW_PF_HINT:1;
    unsigned int WR_ESL_ORDER_CONTROL:1;
#endif
} DTE_VC_SRAM_REGS_DTE_WR_AWUSER_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_WR_AWUSER_CFG_t f;
} DTE_VC_SRAM_REGS_DTE_WR_AWUSER_CFG_u;

#define DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG0_OFFSET 0x0008
typedef struct _DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPARE_SRAM_REG0:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPARE_SRAM_REG0:32;
#endif
} DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG0_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG0_t f;
} DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG0_u;

#define DTE_VC_SRAM_REGS_DTE_AXI_CFG_OFFSET 0x000c
typedef struct _DTE_VC_SRAM_REGS_DTE_AXI_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int AXI_AWPROT:3;
    unsigned int :1;
    unsigned int AXI_ARPROT:3;
    unsigned int :1;
    unsigned int AXI_ARCACHE:4;
    unsigned int AXI_AWCACHE:4;
    unsigned int :16;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :16;
    unsigned int AXI_AWCACHE:4;
    unsigned int AXI_ARCACHE:4;
    unsigned int :1;
    unsigned int AXI_ARPROT:3;
    unsigned int :1;
    unsigned int AXI_AWPROT:3;
#endif
} DTE_VC_SRAM_REGS_DTE_AXI_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_AXI_CFG_t f;
} DTE_VC_SRAM_REGS_DTE_AXI_CFG_u;

#define DTE_VC_SRAM_REGS_DTE_SIG_SRC_CTRL_OFFSET 0x0010
typedef struct _DTE_VC_SRAM_REGS_DTE_SIG_SRC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_SRC_DISABLE:1;
    unsigned int SIG_SRC_ADDR:31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_SRC_ADDR:31;
    unsigned int SIG_SRC_DISABLE:1;
#endif
} DTE_VC_SRAM_REGS_DTE_SIG_SRC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SIG_SRC_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_SIG_SRC_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_SIG_SRC_DATA_OFFSET 0x0014
typedef struct _DTE_VC_SRAM_REGS_DTE_SIG_SRC_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_SRC_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_SRC_DATA:32;
#endif
} DTE_VC_SRAM_REGS_DTE_SIG_SRC_DATA_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SIG_SRC_DATA_t f;
} DTE_VC_SRAM_REGS_DTE_SIG_SRC_DATA_u;

#define DTE_VC_SRAM_REGS_DTE_SIG_DST_CTRL_OFFSET 0x0018
typedef struct _DTE_VC_SRAM_REGS_DTE_SIG_DST_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_DST_DISABLE:1;
    unsigned int SIG_DST_ADDR:31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_DST_ADDR:31;
    unsigned int SIG_DST_DISABLE:1;
#endif
} DTE_VC_SRAM_REGS_DTE_SIG_DST_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SIG_DST_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_SIG_DST_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_SIG_DST_DATA_OFFSET 0x001c
typedef struct _DTE_VC_SRAM_REGS_DTE_SIG_DST_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_DST_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_DST_DATA:32;
#endif
} DTE_VC_SRAM_REGS_DTE_SIG_DST_DATA_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SIG_DST_DATA_t f;
} DTE_VC_SRAM_REGS_DTE_SIG_DST_DATA_u;

#define DTE_VC_SRAM_REGS_DTE_SIG_MNG_CTRL_OFFSET 0x0020
typedef struct _DTE_VC_SRAM_REGS_DTE_SIG_MNG_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_MNG_DISABLE:1;
    unsigned int SIG_MNG_ADDR:31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_MNG_ADDR:31;
    unsigned int SIG_MNG_DISABLE:1;
#endif
} DTE_VC_SRAM_REGS_DTE_SIG_MNG_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SIG_MNG_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_SIG_MNG_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_SIG_MNG_DATA_OFFSET 0x0024
typedef struct _DTE_VC_SRAM_REGS_DTE_SIG_MNG_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIG_MNG_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIG_MNG_DATA:32;
#endif
} DTE_VC_SRAM_REGS_DTE_SIG_MNG_DATA_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SIG_MNG_DATA_t f;
} DTE_VC_SRAM_REGS_DTE_SIG_MNG_DATA_u;

#define DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG1_OFFSET 0x0028
typedef struct _DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPARE_SRAM_REG1:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPARE_SRAM_REG1:32;
#endif
} DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG1_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG1_t f;
} DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG1_u;

#define DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG2_OFFSET 0x002c
typedef struct _DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPARE_SRAM_REG2:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPARE_SRAM_REG2:32;
#endif
} DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG2_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG2_t f;
} DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG2_u;

#define DTE_VC_SRAM_REGS_DTE_WTMK_CTRL_OFFSET 0x0030
typedef struct _DTE_VC_SRAM_REGS_DTE_WTMK_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WTMK_CTRL_EN:1;
    unsigned int :3;
    unsigned int IFB_WTMK_THRSHLD:10;
    unsigned int :18;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :18;
    unsigned int IFB_WTMK_THRSHLD:10;
    unsigned int :3;
    unsigned int WTMK_CTRL_EN:1;
#endif
} DTE_VC_SRAM_REGS_DTE_WTMK_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_WTMK_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_WTMK_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG3_OFFSET 0x0034
typedef struct _DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPARE_SRAM_REG3:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPARE_SRAM_REG3:32;
#endif
} DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG3_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG3_t f;
} DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG3_u;

#define DTE_VC_SRAM_REGS_DTE_VC_ATOMIC_CFG_OFFSET 0x0038
typedef struct _DTE_VC_SRAM_REGS_DTE_VC_ATOMIC_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ATOMIC_DATA_TYPE:4;
    unsigned int ATOMIC_CAS_FLAG:1;
    unsigned int ATOMIC_SCA_VEC_SEL:1;
    unsigned int ATOMIC_MODE:1;
    unsigned int ATOMIC_AWATOP:5;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int ATOMIC_AWATOP:5;
    unsigned int ATOMIC_MODE:1;
    unsigned int ATOMIC_SCA_VEC_SEL:1;
    unsigned int ATOMIC_CAS_FLAG:1;
    unsigned int ATOMIC_DATA_TYPE:4;
#endif
} DTE_VC_SRAM_REGS_DTE_VC_ATOMIC_CFG_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_VC_ATOMIC_CFG_t f;
} DTE_VC_SRAM_REGS_DTE_VC_ATOMIC_CFG_u;

#define DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG4_OFFSET 0x003c
typedef struct _DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG4_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SPARE_SRAM_REG4:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SPARE_SRAM_REG4:32;
#endif
} DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG4_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG4_t f;
} DTE_VC_SRAM_REGS_DTE_SPARE_SRAM_REG4_u;

#define DTE_VC_SRAM_REGS_DTE_GSYNC_CTRL_OFFSET 0x0040
typedef struct _DTE_VC_SRAM_REGS_DTE_GSYNC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_MODE:1;
    unsigned int REG_ENTRY_IDX:8;
    unsigned int GSYNC_SLV_BASE_ADDR_SEL:3;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int GSYNC_SLV_BASE_ADDR_SEL:3;
    unsigned int REG_ENTRY_IDX:8;
    unsigned int GSYNC_MODE:1;
#endif
} DTE_VC_SRAM_REGS_DTE_GSYNC_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_GSYNC_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_GSYNC_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA0_OFFSET 0x0044
typedef struct _DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_DATA:32;
#endif
} DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA0_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA0_t f;
} DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA0_u;

#define DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA1_OFFSET 0x0048
typedef struct _DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_ADDR:30;
    unsigned int WAIT_ENTRY_RSVD:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_RSVD:2;
    unsigned int WAIT_ENTRY_ADDR:30;
#endif
} DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA1_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA1_t f;
} DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA1_u;

#define DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA2_OFFSET 0x004c
typedef struct _DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_WAIT:23;
    unsigned int WAIT_ENTRY_MODE:2;
    unsigned int WAIT_ENTRY_TID:7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_TID:7;
    unsigned int WAIT_ENTRY_MODE:2;
    unsigned int WAIT_ENTRY_WAIT:23;
#endif
} DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA2_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA2_t f;
} DTE_VC_SRAM_REGS_DTE_GSYNC_REGISTER_DATA2_u;

#define DTE_VC_SRAM_REGS_DTE_GSYNC_SIGNAL_INFO_OFFSET 0x0050
typedef struct _DTE_VC_SRAM_REGS_DTE_GSYNC_SIGNAL_INFO_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIGNAL_INFO:25;
    unsigned int SIGNAL_IDX:7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIGNAL_IDX:7;
    unsigned int SIGNAL_INFO:25;
#endif
} DTE_VC_SRAM_REGS_DTE_GSYNC_SIGNAL_INFO_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_GSYNC_SIGNAL_INFO_t f;
} DTE_VC_SRAM_REGS_DTE_GSYNC_SIGNAL_INFO_u;

#define DTE_VC_SRAM_REGS_DTE_SHR_CTRL_OFFSET 0x0058
typedef struct _DTE_VC_SRAM_REGS_DTE_SHR_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SHR_PHASE:2;
    unsigned int SHR_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int SHR_RATIO:2;
    unsigned int SHR_PHASE:2;
#endif
} DTE_VC_SRAM_REGS_DTE_SHR_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SHR_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_SHR_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _DTE_VC_SRAM_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SRC_DIM0_SIZE_t f;
} DTE_VC_SRAM_REGS_DTE_SRC_DIM0_SIZE_u;

#define DTE_VC_SRAM_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _DTE_VC_SRAM_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SRC_DIM1_SIZE_t f;
} DTE_VC_SRAM_REGS_DTE_SRC_DIM1_SIZE_u;

#define DTE_VC_SRAM_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _DTE_VC_SRAM_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SRC_DIM2_SIZE_t f;
} DTE_VC_SRAM_REGS_DTE_SRC_DIM2_SIZE_u;

#define DTE_VC_SRAM_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _DTE_VC_SRAM_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SRC_DIM3_SIZE_t f;
} DTE_VC_SRAM_REGS_DTE_SRC_DIM3_SIZE_u;

#define DTE_VC_SRAM_REGS_DTE_EXP_CTRL_OFFSET 0x006c
typedef struct _DTE_VC_SRAM_REGS_DTE_EXP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EXP_PHASE:2;
    unsigned int EXP_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int EXP_RATIO:2;
    unsigned int EXP_PHASE:2;
#endif
} DTE_VC_SRAM_REGS_DTE_EXP_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_EXP_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_EXP_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_CONSTANT_DATA_OFFSET 0x0058
typedef struct _DTE_VC_SRAM_REGS_DTE_CONSTANT_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CONSTANT_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CONSTANT_DATA:32;
#endif
} DTE_VC_SRAM_REGS_DTE_CONSTANT_DATA_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_CONSTANT_DATA_t f;
} DTE_VC_SRAM_REGS_DTE_CONSTANT_DATA_u;

#define DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM0_OFFSET 0x0070
typedef struct _DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM0_LOW:11;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int PAD_DIM0_LOW:11;
#endif
} DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM0_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM0_t f;
} DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM0_u;

#define DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM1_OFFSET 0x0074
typedef struct _DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM1_LOW:11;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM1_INTERIOR:10;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_LOW:11;
#endif
} DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM1_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM1_t f;
} DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM1_u;

#define DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM2_OFFSET 0x0078
typedef struct _DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM2_LOW:11;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM2_INTERIOR:10;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_LOW:11;
#endif
} DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM2_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM2_t f;
} DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM2_u;

#define DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM3_OFFSET 0x007c
typedef struct _DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM3_LOW:11;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM3_INTERIOR:10;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_LOW:11;
#endif
} DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM3_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM3_t f;
} DTE_VC_SRAM_REGS_DTE_PAD_CTRL_DIM3_u;

#define DTE_VC_SRAM_REGS_DTE_PAD_VALUE_OFFSET 0x0080
typedef struct _DTE_VC_SRAM_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} DTE_VC_SRAM_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_PAD_VALUE_t f;
} DTE_VC_SRAM_REGS_DTE_PAD_VALUE_u;

#define DTE_VC_SRAM_REGS_DTE_RESHAPE_CTRL_OFFSET 0x006c
typedef struct _DTE_VC_SRAM_REGS_DTE_RESHAPE_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESHAPE_DIM0_MAP:2;
    unsigned int RESHAPE_DIM1_MAP:2;
    unsigned int RESHAPE_DIM2_MAP:2;
    unsigned int RESHAPE_DIM3_MAP:2;
    unsigned int ENHANCE_RESHAPE_MODE:1;
    unsigned int :23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :23;
    unsigned int ENHANCE_RESHAPE_MODE:1;
    unsigned int RESHAPE_DIM3_MAP:2;
    unsigned int RESHAPE_DIM2_MAP:2;
    unsigned int RESHAPE_DIM1_MAP:2;
    unsigned int RESHAPE_DIM0_MAP:2;
#endif
} DTE_VC_SRAM_REGS_DTE_RESHAPE_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_RESHAPE_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_RESHAPE_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_BRDCST_CTRL_OFFSET 0x006c
typedef struct _DTE_VC_SRAM_REGS_DTE_BRDCST_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int BRDCST_DIM:2;
    unsigned int :6;
    unsigned int BRDCST_SIZE:24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int BRDCST_SIZE:24;
    unsigned int :6;
    unsigned int BRDCST_DIM:2;
#endif
} DTE_VC_SRAM_REGS_DTE_BRDCST_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_BRDCST_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_BRDCST_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM0_t f;
} DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM0_u;

#define DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM1_t f;
} DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM1_u;

#define DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM2_t f;
} DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM2_u;

#define DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM3_t f;
} DTE_VC_SRAM_REGS_DTE_SLICE_SIZE_DIM3_u;

#define DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int SLICE_DIM0_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM0_START_DIR:1;
    unsigned int SLICE_DIM0_START:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM0_t f;
} DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM0_u;

#define DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int SLICE_DIM1_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM1_START_DIR:1;
    unsigned int SLICE_DIM1_START:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM1_t f;
} DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM1_u;

#define DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int SLICE_DIM2_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM2_START_DIR:1;
    unsigned int SLICE_DIM2_START:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM2_t f;
} DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM2_u;

#define DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0088
typedef struct _DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int SLICE_DIM3_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM3_START_DIR:1;
    unsigned int SLICE_DIM3_START:24;
#endif
} DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM3_t f;
} DTE_VC_SRAM_REGS_DTE_SLICE_START_DIM3_u;

#define DTE_VC_SRAM_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _DTE_VC_SRAM_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_DST_DIM0_SIZE_t f;
} DTE_VC_SRAM_REGS_DTE_DST_DIM0_SIZE_u;

#define DTE_VC_SRAM_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _DTE_VC_SRAM_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_DST_DIM1_SIZE_t f;
} DTE_VC_SRAM_REGS_DTE_DST_DIM1_SIZE_u;

#define DTE_VC_SRAM_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _DTE_VC_SRAM_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_DST_DIM2_SIZE_t f;
} DTE_VC_SRAM_REGS_DTE_DST_DIM2_SIZE_u;

#define DTE_VC_SRAM_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _DTE_VC_SRAM_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} DTE_VC_SRAM_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_DST_DIM3_SIZE_t f;
} DTE_VC_SRAM_REGS_DTE_DST_DIM3_SIZE_u;

#define DTE_VC_SRAM_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _DTE_VC_SRAM_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} DTE_VC_SRAM_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_DSL_START_DIM0_t f;
} DTE_VC_SRAM_REGS_DTE_DSL_START_DIM0_u;

#define DTE_VC_SRAM_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _DTE_VC_SRAM_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} DTE_VC_SRAM_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_DSL_START_DIM1_t f;
} DTE_VC_SRAM_REGS_DTE_DSL_START_DIM1_u;

#define DTE_VC_SRAM_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _DTE_VC_SRAM_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} DTE_VC_SRAM_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_DSL_START_DIM2_t f;
} DTE_VC_SRAM_REGS_DTE_DSL_START_DIM2_u;

#define DTE_VC_SRAM_REGS_DTE_DSL_START_DIM3_OFFSET 0x008c
typedef struct _DTE_VC_SRAM_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} DTE_VC_SRAM_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_DSL_START_DIM3_t f;
} DTE_VC_SRAM_REGS_DTE_DSL_START_DIM3_u;

#define DTE_VC_SRAM_REGS_DTE_SSMP_CTRL_OFFSET 0x006c
typedef struct _DTE_VC_SRAM_REGS_DTE_SSMP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SSMP_ROW_STRIDE:11;
    unsigned int :21;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :21;
    unsigned int SSMP_ROW_STRIDE:11;
#endif
} DTE_VC_SRAM_REGS_DTE_SSMP_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SSMP_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_SSMP_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_SLC_RESHAPE_CTRL_OFFSET 0x006c
typedef struct _DTE_VC_SRAM_REGS_DTE_SLC_RESHAPE_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLC_RESHAPE_DIM0_MAP:2;
    unsigned int SLC_RESHAPE_DIM1_MAP:2;
    unsigned int SLC_RESHAPE_DIM2_MAP:2;
    unsigned int SLC_RESHAPE_DIM3_MAP:2;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int SLC_RESHAPE_DIM3_MAP:2;
    unsigned int SLC_RESHAPE_DIM2_MAP:2;
    unsigned int SLC_RESHAPE_DIM1_MAP:2;
    unsigned int SLC_RESHAPE_DIM0_MAP:2;
#endif
} DTE_VC_SRAM_REGS_DTE_SLC_RESHAPE_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_SLC_RESHAPE_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_SLC_RESHAPE_CTRL_u;

#define DTE_VC_SRAM_REGS_DTE_RESHAPE_DSL_CTRL_OFFSET 0x0058
typedef struct _DTE_VC_SRAM_REGS_DTE_RESHAPE_DSL_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESHAPE_DSL_DIM0_MAP:2;
    unsigned int RESHAPE_DSL_DIM1_MAP:2;
    unsigned int RESHAPE_DSL_DIM2_MAP:2;
    unsigned int RESHAPE_DSL_DIM3_MAP:2;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int RESHAPE_DSL_DIM3_MAP:2;
    unsigned int RESHAPE_DSL_DIM2_MAP:2;
    unsigned int RESHAPE_DSL_DIM1_MAP:2;
    unsigned int RESHAPE_DSL_DIM0_MAP:2;
#endif
} DTE_VC_SRAM_REGS_DTE_RESHAPE_DSL_CTRL_t;

typedef union {
    unsigned int val : 32;
    DTE_VC_SRAM_REGS_DTE_RESHAPE_DSL_CTRL_t f;
} DTE_VC_SRAM_REGS_DTE_RESHAPE_DSL_CTRL_u;

#define BRDCST_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _BRDCST_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} BRDCST_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    BRDCST_REGS_DTE_SRC_DIM0_SIZE_t f;
} BRDCST_REGS_DTE_SRC_DIM0_SIZE_u;

#define BRDCST_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _BRDCST_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} BRDCST_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    BRDCST_REGS_DTE_SRC_DIM1_SIZE_t f;
} BRDCST_REGS_DTE_SRC_DIM1_SIZE_u;

#define BRDCST_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _BRDCST_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} BRDCST_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    BRDCST_REGS_DTE_SRC_DIM2_SIZE_t f;
} BRDCST_REGS_DTE_SRC_DIM2_SIZE_u;

#define BRDCST_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _BRDCST_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} BRDCST_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    BRDCST_REGS_DTE_SRC_DIM3_SIZE_t f;
} BRDCST_REGS_DTE_SRC_DIM3_SIZE_u;

#define BRDCST_REGS_DTE_BRDCST_CTRL_OFFSET 0x006c
typedef struct _BRDCST_REGS_DTE_BRDCST_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int BRDCST_DIM:2;
    unsigned int :6;
    unsigned int BRDCST_SIZE:24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int BRDCST_SIZE:24;
    unsigned int :6;
    unsigned int BRDCST_DIM:2;
#endif
} BRDCST_REGS_DTE_BRDCST_CTRL_t;

typedef union {
    unsigned int val : 32;
    BRDCST_REGS_DTE_BRDCST_CTRL_t f;
} BRDCST_REGS_DTE_BRDCST_CTRL_u;

#define CF_REGS_DTE_CONSTANT_DATA_OFFSET 0x0058
typedef struct _CF_REGS_DTE_CONSTANT_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CONSTANT_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CONSTANT_DATA:32;
#endif
} CF_REGS_DTE_CONSTANT_DATA_t;

typedef union {
    unsigned int val : 32;
    CF_REGS_DTE_CONSTANT_DATA_t f;
} CF_REGS_DTE_CONSTANT_DATA_u;

#define CFDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _CFDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} CFDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} CFDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define CFDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _CFDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} CFDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} CFDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define CFDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _CFDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} CFDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} CFDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define CFDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _CFDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} CFDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} CFDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define CFDSL_REGS_DTE_CONSTANT_DATA_OFFSET 0x0058
typedef struct _CFDSL_REGS_DTE_CONSTANT_DATA_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CONSTANT_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int CONSTANT_DATA:32;
#endif
} CFDSL_REGS_DTE_CONSTANT_DATA_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_CONSTANT_DATA_t f;
} CFDSL_REGS_DTE_CONSTANT_DATA_u;

#define CFDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _CFDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} CFDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} CFDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define CFDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _CFDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} CFDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} CFDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define CFDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _CFDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} CFDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} CFDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define CFDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _CFDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} CFDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} CFDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define CFDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _CFDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} CFDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DSL_START_DIM0_t f;
} CFDSL_REGS_DTE_DSL_START_DIM0_u;

#define CFDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _CFDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} CFDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DSL_START_DIM1_t f;
} CFDSL_REGS_DTE_DSL_START_DIM1_u;

#define CFDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _CFDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} CFDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DSL_START_DIM2_t f;
} CFDSL_REGS_DTE_DSL_START_DIM2_u;

#define CFDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x008c
typedef struct _CFDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} CFDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    CFDSL_REGS_DTE_DSL_START_DIM3_t f;
} CFDSL_REGS_DTE_DSL_START_DIM3_u;

#define DE_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _DE_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} DE_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DE_REGS_DTE_SRC_DIM0_SIZE_t f;
} DE_REGS_DTE_SRC_DIM0_SIZE_u;

#define DE_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _DE_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} DE_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DE_REGS_DTE_SRC_DIM1_SIZE_t f;
} DE_REGS_DTE_SRC_DIM1_SIZE_u;

#define DE_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _DE_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} DE_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DE_REGS_DTE_SRC_DIM2_SIZE_t f;
} DE_REGS_DTE_SRC_DIM2_SIZE_u;

#define DE_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _DE_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} DE_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DE_REGS_DTE_SRC_DIM3_SIZE_t f;
} DE_REGS_DTE_SRC_DIM3_SIZE_u;

#define DE_REGS_DTE_EXP_CTRL_OFFSET 0x006c
typedef struct _DE_REGS_DTE_EXP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EXP_PHASE:2;
    unsigned int EXP_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int EXP_RATIO:2;
    unsigned int EXP_PHASE:2;
#endif
} DE_REGS_DTE_EXP_CTRL_t;

typedef union {
    unsigned int val : 32;
    DE_REGS_DTE_EXP_CTRL_t f;
} DE_REGS_DTE_EXP_CTRL_u;

#define DS_REGS_DTE_SHR_CTRL_OFFSET 0x0058
typedef struct _DS_REGS_DTE_SHR_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SHR_PHASE:2;
    unsigned int SHR_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int SHR_RATIO:2;
    unsigned int SHR_PHASE:2;
#endif
} DS_REGS_DTE_SHR_CTRL_t;

typedef union {
    unsigned int val : 32;
    DS_REGS_DTE_SHR_CTRL_t f;
} DS_REGS_DTE_SHR_CTRL_u;

#define DSDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _DSDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} DSDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} DSDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define DSDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _DSDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} DSDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} DSDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define DSDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _DSDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} DSDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} DSDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define DSDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _DSDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} DSDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} DSDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define DSDSL_REGS_DTE_SHR_CTRL_OFFSET 0x0058
typedef struct _DSDSL_REGS_DTE_SHR_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SHR_PHASE:2;
    unsigned int SHR_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int SHR_RATIO:2;
    unsigned int SHR_PHASE:2;
#endif
} DSDSL_REGS_DTE_SHR_CTRL_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_SHR_CTRL_t f;
} DSDSL_REGS_DTE_SHR_CTRL_u;

#define DSDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _DSDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} DSDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} DSDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define DSDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _DSDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} DSDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} DSDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define DSDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _DSDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} DSDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} DSDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define DSDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _DSDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} DSDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} DSDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define DSDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _DSDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} DSDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DSL_START_DIM0_t f;
} DSDSL_REGS_DTE_DSL_START_DIM0_u;

#define DSDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _DSDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} DSDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DSL_START_DIM1_t f;
} DSDSL_REGS_DTE_DSL_START_DIM1_u;

#define DSDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _DSDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} DSDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DSL_START_DIM2_t f;
} DSDSL_REGS_DTE_DSL_START_DIM2_u;

#define DSDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x008c
typedef struct _DSDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} DSDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    DSDSL_REGS_DTE_DSL_START_DIM3_t f;
} DSDSL_REGS_DTE_DSL_START_DIM3_u;

#define DSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _DSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} DSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} DSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define DSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _DSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} DSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} DSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define DSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _DSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} DSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} DSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define DSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _DSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} DSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} DSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define DSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _DSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} DSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DST_DIM0_SIZE_t f;
} DSL_REGS_DTE_DST_DIM0_SIZE_u;

#define DSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _DSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} DSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DST_DIM1_SIZE_t f;
} DSL_REGS_DTE_DST_DIM1_SIZE_u;

#define DSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _DSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} DSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DST_DIM2_SIZE_t f;
} DSL_REGS_DTE_DST_DIM2_SIZE_u;

#define DSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _DSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} DSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DST_DIM3_SIZE_t f;
} DSL_REGS_DTE_DST_DIM3_SIZE_u;

#define DSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _DSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} DSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DSL_START_DIM0_t f;
} DSL_REGS_DTE_DSL_START_DIM0_u;

#define DSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _DSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} DSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DSL_START_DIM1_t f;
} DSL_REGS_DTE_DSL_START_DIM1_u;

#define DSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _DSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} DSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DSL_START_DIM2_t f;
} DSL_REGS_DTE_DSL_START_DIM2_u;

#define DSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x008c
typedef struct _DSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} DSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    DSL_REGS_DTE_DSL_START_DIM3_t f;
} DSL_REGS_DTE_DSL_START_DIM3_u;

#define GS_REGS_DTE_GSYNC_CTRL_OFFSET 0x0040
typedef struct _GS_REGS_DTE_GSYNC_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int GSYNC_MODE:1;
    unsigned int REG_ENTRY_IDX:8;
    unsigned int GSYNC_SLV_BASE_ADDR_SEL:3;
    unsigned int :20;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :20;
    unsigned int GSYNC_SLV_BASE_ADDR_SEL:3;
    unsigned int REG_ENTRY_IDX:8;
    unsigned int GSYNC_MODE:1;
#endif
} GS_REGS_DTE_GSYNC_CTRL_t;

typedef union {
    unsigned int val : 32;
    GS_REGS_DTE_GSYNC_CTRL_t f;
} GS_REGS_DTE_GSYNC_CTRL_u;

#define GS_REGS_DTE_GSYNC_REGISTER_DATA0_OFFSET 0x0044
typedef struct _GS_REGS_DTE_GSYNC_REGISTER_DATA0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_DATA:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_DATA:32;
#endif
} GS_REGS_DTE_GSYNC_REGISTER_DATA0_t;

typedef union {
    unsigned int val : 32;
    GS_REGS_DTE_GSYNC_REGISTER_DATA0_t f;
} GS_REGS_DTE_GSYNC_REGISTER_DATA0_u;

#define GS_REGS_DTE_GSYNC_REGISTER_DATA1_OFFSET 0x0048
typedef struct _GS_REGS_DTE_GSYNC_REGISTER_DATA1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_ADDR:30;
    unsigned int WAIT_ENTRY_RSVD:2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_RSVD:2;
    unsigned int WAIT_ENTRY_ADDR:30;
#endif
} GS_REGS_DTE_GSYNC_REGISTER_DATA1_t;

typedef union {
    unsigned int val : 32;
    GS_REGS_DTE_GSYNC_REGISTER_DATA1_t f;
} GS_REGS_DTE_GSYNC_REGISTER_DATA1_u;

#define GS_REGS_DTE_GSYNC_REGISTER_DATA2_OFFSET 0x004c
typedef struct _GS_REGS_DTE_GSYNC_REGISTER_DATA2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int WAIT_ENTRY_WAIT:23;
    unsigned int WAIT_ENTRY_MODE:2;
    unsigned int WAIT_ENTRY_TID:7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int WAIT_ENTRY_TID:7;
    unsigned int WAIT_ENTRY_MODE:2;
    unsigned int WAIT_ENTRY_WAIT:23;
#endif
} GS_REGS_DTE_GSYNC_REGISTER_DATA2_t;

typedef union {
    unsigned int val : 32;
    GS_REGS_DTE_GSYNC_REGISTER_DATA2_t f;
} GS_REGS_DTE_GSYNC_REGISTER_DATA2_u;

#define GS_REGS_DTE_GSYNC_SIGNAL_INFO_OFFSET 0x0050
typedef struct _GS_REGS_DTE_GSYNC_SIGNAL_INFO_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SIGNAL_INFO:25;
    unsigned int SIGNAL_IDX:7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SIGNAL_IDX:7;
    unsigned int SIGNAL_INFO:25;
#endif
} GS_REGS_DTE_GSYNC_SIGNAL_INFO_t;

typedef union {
    unsigned int val : 32;
    GS_REGS_DTE_GSYNC_SIGNAL_INFO_t f;
} GS_REGS_DTE_GSYNC_SIGNAL_INFO_u;

#define HMIR_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _HMIR_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} HMIR_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIR_REGS_DTE_SRC_DIM0_SIZE_t f;
} HMIR_REGS_DTE_SRC_DIM0_SIZE_u;

#define HMIR_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _HMIR_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} HMIR_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIR_REGS_DTE_SRC_DIM1_SIZE_t f;
} HMIR_REGS_DTE_SRC_DIM1_SIZE_u;

#define HMIR_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _HMIR_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} HMIR_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIR_REGS_DTE_SRC_DIM2_SIZE_t f;
} HMIR_REGS_DTE_SRC_DIM2_SIZE_u;

#define HMIR_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _HMIR_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} HMIR_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIR_REGS_DTE_SRC_DIM3_SIZE_t f;
} HMIR_REGS_DTE_SRC_DIM3_SIZE_u;

#define HMIRDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _HMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} HMIRDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define HMIRDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _HMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} HMIRDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define HMIRDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _HMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} HMIRDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define HMIRDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _HMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} HMIRDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define HMIRDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _HMIRDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} HMIRDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define HMIRDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _HMIRDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} HMIRDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define HMIRDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _HMIRDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} HMIRDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define HMIRDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _HMIRDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} HMIRDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} HMIRDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define HMIRDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _HMIRDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} HMIRDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DSL_START_DIM0_t f;
} HMIRDSL_REGS_DTE_DSL_START_DIM0_u;

#define HMIRDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _HMIRDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} HMIRDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DSL_START_DIM1_t f;
} HMIRDSL_REGS_DTE_DSL_START_DIM1_u;

#define HMIRDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _HMIRDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} HMIRDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DSL_START_DIM2_t f;
} HMIRDSL_REGS_DTE_DSL_START_DIM2_u;

#define HMIRDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x008c
typedef struct _HMIRDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} HMIRDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    HMIRDSL_REGS_DTE_DSL_START_DIM3_t f;
} HMIRDSL_REGS_DTE_DSL_START_DIM3_u;

#define HMIRPAD_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _HMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} HMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t f;
} HMIRPAD_REGS_DTE_SRC_DIM0_SIZE_u;

#define HMIRPAD_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _HMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} HMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t f;
} HMIRPAD_REGS_DTE_SRC_DIM1_SIZE_u;

#define HMIRPAD_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _HMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} HMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t f;
} HMIRPAD_REGS_DTE_SRC_DIM2_SIZE_u;

#define HMIRPAD_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _HMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} HMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t f;
} HMIRPAD_REGS_DTE_SRC_DIM3_SIZE_u;

#define HMIRPAD_REGS_DTE_PAD_CTRL_DIM0_OFFSET 0x0070
typedef struct _HMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM0_LOW:11;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int PAD_DIM0_LOW:11;
#endif
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t f;
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM0_u;

#define HMIRPAD_REGS_DTE_PAD_CTRL_DIM1_OFFSET 0x0074
typedef struct _HMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM1_LOW:11;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM1_INTERIOR:10;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_LOW:11;
#endif
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t f;
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM1_u;

#define HMIRPAD_REGS_DTE_PAD_CTRL_DIM2_OFFSET 0x0078
typedef struct _HMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM2_LOW:11;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM2_INTERIOR:10;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_LOW:11;
#endif
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t f;
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM2_u;

#define HMIRPAD_REGS_DTE_PAD_CTRL_DIM3_OFFSET 0x007c
typedef struct _HMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM3_LOW:11;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM3_INTERIOR:10;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_LOW:11;
#endif
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t f;
} HMIRPAD_REGS_DTE_PAD_CTRL_DIM3_u;

#define HMIRPAD_REGS_DTE_PAD_VALUE_OFFSET 0x0080
typedef struct _HMIRPAD_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} HMIRPAD_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    HMIRPAD_REGS_DTE_PAD_VALUE_t f;
} HMIRPAD_REGS_DTE_PAD_VALUE_u;

#define PAD_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _PAD_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} PAD_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_SRC_DIM0_SIZE_t f;
} PAD_REGS_DTE_SRC_DIM0_SIZE_u;

#define PAD_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _PAD_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} PAD_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_SRC_DIM1_SIZE_t f;
} PAD_REGS_DTE_SRC_DIM1_SIZE_u;

#define PAD_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _PAD_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} PAD_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_SRC_DIM2_SIZE_t f;
} PAD_REGS_DTE_SRC_DIM2_SIZE_u;

#define PAD_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _PAD_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} PAD_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_SRC_DIM3_SIZE_t f;
} PAD_REGS_DTE_SRC_DIM3_SIZE_u;

#define PAD_REGS_DTE_PAD_CTRL_DIM0_OFFSET 0x0070
typedef struct _PAD_REGS_DTE_PAD_CTRL_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM0_LOW:11;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int PAD_DIM0_LOW:11;
#endif
} PAD_REGS_DTE_PAD_CTRL_DIM0_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_PAD_CTRL_DIM0_t f;
} PAD_REGS_DTE_PAD_CTRL_DIM0_u;

#define PAD_REGS_DTE_PAD_CTRL_DIM1_OFFSET 0x0074
typedef struct _PAD_REGS_DTE_PAD_CTRL_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM1_LOW:11;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM1_INTERIOR:10;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_LOW:11;
#endif
} PAD_REGS_DTE_PAD_CTRL_DIM1_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_PAD_CTRL_DIM1_t f;
} PAD_REGS_DTE_PAD_CTRL_DIM1_u;

#define PAD_REGS_DTE_PAD_CTRL_DIM2_OFFSET 0x0078
typedef struct _PAD_REGS_DTE_PAD_CTRL_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM2_LOW:11;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM2_INTERIOR:10;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_LOW:11;
#endif
} PAD_REGS_DTE_PAD_CTRL_DIM2_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_PAD_CTRL_DIM2_t f;
} PAD_REGS_DTE_PAD_CTRL_DIM2_u;

#define PAD_REGS_DTE_PAD_CTRL_DIM3_OFFSET 0x007c
typedef struct _PAD_REGS_DTE_PAD_CTRL_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM3_LOW:11;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM3_INTERIOR:10;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_LOW:11;
#endif
} PAD_REGS_DTE_PAD_CTRL_DIM3_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_PAD_CTRL_DIM3_t f;
} PAD_REGS_DTE_PAD_CTRL_DIM3_u;

#define PAD_REGS_DTE_PAD_VALUE_OFFSET 0x0080
typedef struct _PAD_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} PAD_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    PAD_REGS_DTE_PAD_VALUE_t f;
} PAD_REGS_DTE_PAD_VALUE_u;

#define RSHP_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _RSHP_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} RSHP_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHP_REGS_DTE_SRC_DIM0_SIZE_t f;
} RSHP_REGS_DTE_SRC_DIM0_SIZE_u;

#define RSHP_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _RSHP_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} RSHP_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHP_REGS_DTE_SRC_DIM1_SIZE_t f;
} RSHP_REGS_DTE_SRC_DIM1_SIZE_u;

#define RSHP_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _RSHP_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} RSHP_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHP_REGS_DTE_SRC_DIM2_SIZE_t f;
} RSHP_REGS_DTE_SRC_DIM2_SIZE_u;

#define RSHP_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _RSHP_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} RSHP_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHP_REGS_DTE_SRC_DIM3_SIZE_t f;
} RSHP_REGS_DTE_SRC_DIM3_SIZE_u;

#define RSHP_REGS_DTE_RESHAPE_CTRL_OFFSET 0x006c
typedef struct _RSHP_REGS_DTE_RESHAPE_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESHAPE_DIM0_MAP:2;
    unsigned int RESHAPE_DIM1_MAP:2;
    unsigned int RESHAPE_DIM2_MAP:2;
    unsigned int RESHAPE_DIM3_MAP:2;
    unsigned int ENHANCE_RESHAPE_MODE:1;
    unsigned int :23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :23;
    unsigned int ENHANCE_RESHAPE_MODE:1;
    unsigned int RESHAPE_DIM3_MAP:2;
    unsigned int RESHAPE_DIM2_MAP:2;
    unsigned int RESHAPE_DIM1_MAP:2;
    unsigned int RESHAPE_DIM0_MAP:2;
#endif
} RSHP_REGS_DTE_RESHAPE_CTRL_t;

typedef union {
    unsigned int val : 32;
    RSHP_REGS_DTE_RESHAPE_CTRL_t f;
} RSHP_REGS_DTE_RESHAPE_CTRL_u;

#define RSHPDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _RSHPDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} RSHPDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define RSHPDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _RSHPDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} RSHPDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define RSHPDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _RSHPDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} RSHPDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define RSHPDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _RSHPDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} RSHPDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define RSHPDSL_REGS_DTE_RESHAPE_DSL_CTRL_OFFSET 0x0058
typedef struct _RSHPDSL_REGS_DTE_RESHAPE_DSL_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int RESHAPE_DSL_DIM0_MAP:2;
    unsigned int RESHAPE_DSL_DIM1_MAP:2;
    unsigned int RESHAPE_DSL_DIM2_MAP:2;
    unsigned int RESHAPE_DSL_DIM3_MAP:2;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int RESHAPE_DSL_DIM3_MAP:2;
    unsigned int RESHAPE_DSL_DIM2_MAP:2;
    unsigned int RESHAPE_DSL_DIM1_MAP:2;
    unsigned int RESHAPE_DSL_DIM0_MAP:2;
#endif
} RSHPDSL_REGS_DTE_RESHAPE_DSL_CTRL_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_RESHAPE_DSL_CTRL_t f;
} RSHPDSL_REGS_DTE_RESHAPE_DSL_CTRL_u;

#define RSHPDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _RSHPDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} RSHPDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define RSHPDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _RSHPDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} RSHPDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define RSHPDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _RSHPDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} RSHPDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define RSHPDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _RSHPDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} RSHPDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} RSHPDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define RSHPDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _RSHPDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} RSHPDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DSL_START_DIM0_t f;
} RSHPDSL_REGS_DTE_DSL_START_DIM0_u;

#define RSHPDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _RSHPDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} RSHPDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DSL_START_DIM1_t f;
} RSHPDSL_REGS_DTE_DSL_START_DIM1_u;

#define RSHPDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _RSHPDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} RSHPDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DSL_START_DIM2_t f;
} RSHPDSL_REGS_DTE_DSL_START_DIM2_u;

#define RSHPDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x008c
typedef struct _RSHPDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} RSHPDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    RSHPDSL_REGS_DTE_DSL_START_DIM3_t f;
} RSHPDSL_REGS_DTE_DSL_START_DIM3_u;

#define SLC_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLC_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLC_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLC_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLC_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLC_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLC_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLC_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLC_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLC_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLC_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLC_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLC_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLC_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLC_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLC_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLC_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLC_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLC_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLC_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLC_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLC_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLC_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLC_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLC_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLC_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLC_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLC_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLC_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLC_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLC_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLC_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLC_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLC_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int SLICE_DIM0_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM0_START_DIR:1;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLC_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_START_DIM0_t f;
} SLC_REGS_DTE_SLICE_START_DIM0_u;

#define SLC_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLC_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int SLICE_DIM1_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM1_START_DIR:1;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLC_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_START_DIM1_t f;
} SLC_REGS_DTE_SLICE_START_DIM1_u;

#define SLC_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLC_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int SLICE_DIM2_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM2_START_DIR:1;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLC_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_START_DIM2_t f;
} SLC_REGS_DTE_SLICE_START_DIM2_u;

#define SLC_REGS_DTE_PAD_VALUE_OFFSET 0x0080
typedef struct _SLC_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} SLC_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_PAD_VALUE_t f;
} SLC_REGS_DTE_PAD_VALUE_u;

#define SLC_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0088
typedef struct _SLC_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int SLICE_DIM3_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM3_START_DIR:1;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLC_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLC_REGS_DTE_SLICE_START_DIM3_t f;
} SLC_REGS_DTE_SLICE_START_DIM3_u;

#define SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLCBRDCST_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLCBRDCST_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLCBRDCST_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLCBRDCST_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLCBRDCST_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLCBRDCST_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLCBRDCST_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLCBRDCST_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLCBRDCST_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLCBRDCST_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLCBRDCST_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLCBRDCST_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLCBRDCST_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLCBRDCST_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLCBRDCST_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_START_DIM0_t f;
} SLCBRDCST_REGS_DTE_SLICE_START_DIM0_u;

#define SLCBRDCST_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLCBRDCST_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_START_DIM1_t f;
} SLCBRDCST_REGS_DTE_SLICE_START_DIM1_u;

#define SLCBRDCST_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLCBRDCST_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_START_DIM2_t f;
} SLCBRDCST_REGS_DTE_SLICE_START_DIM2_u;

#define SLCBRDCST_REGS_DTE_BRDCST_CTRL_OFFSET 0x006c
typedef struct _SLCBRDCST_REGS_DTE_BRDCST_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int BRDCST_DIM:2;
    unsigned int :6;
    unsigned int BRDCST_SIZE:24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int BRDCST_SIZE:24;
    unsigned int :6;
    unsigned int BRDCST_DIM:2;
#endif
} SLCBRDCST_REGS_DTE_BRDCST_CTRL_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_BRDCST_CTRL_t f;
} SLCBRDCST_REGS_DTE_BRDCST_CTRL_u;

#define SLCBRDCST_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0088
typedef struct _SLCBRDCST_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLCBRDCST_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCBRDCST_REGS_DTE_SLICE_START_DIM3_t f;
} SLCBRDCST_REGS_DTE_SLICE_START_DIM3_u;

#define SLCDE_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLCDE_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLCDE_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLCDE_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLCDE_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLCDE_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLCDE_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLCDE_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLCDE_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLCDE_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLCDE_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLCDE_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLCDE_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLCDE_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLCDE_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLCDE_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLCDE_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLCDE_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLCDE_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLCDE_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLCDE_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLCDE_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLCDE_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLCDE_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLCDE_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLCDE_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLCDE_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLCDE_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLCDE_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLCDE_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLCDE_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLCDE_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLCDE_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLCDE_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLCDE_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_START_DIM0_t f;
} SLCDE_REGS_DTE_SLICE_START_DIM0_u;

#define SLCDE_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLCDE_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLCDE_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_START_DIM1_t f;
} SLCDE_REGS_DTE_SLICE_START_DIM1_u;

#define SLCDE_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLCDE_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLCDE_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_START_DIM2_t f;
} SLCDE_REGS_DTE_SLICE_START_DIM2_u;

#define SLCDE_REGS_DTE_EXP_CTRL_OFFSET 0x006c
typedef struct _SLCDE_REGS_DTE_EXP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EXP_PHASE:2;
    unsigned int EXP_RATIO:2;
    unsigned int :28;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :28;
    unsigned int EXP_RATIO:2;
    unsigned int EXP_PHASE:2;
#endif
} SLCDE_REGS_DTE_EXP_CTRL_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_EXP_CTRL_t f;
} SLCDE_REGS_DTE_EXP_CTRL_u;

#define SLCDE_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0088
typedef struct _SLCDE_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLCDE_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCDE_REGS_DTE_SLICE_START_DIM3_t f;
} SLCDE_REGS_DTE_SLICE_START_DIM3_u;

#define SLCDSL_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLCDSL_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLCDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLCDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLCDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLCDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLCDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLCDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLCDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLCDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLCDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLCDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLCDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLCDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLCDSL_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLCDSL_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLCDSL_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLCDSL_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLCDSL_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLCDSL_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLCDSL_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLCDSL_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLCDSL_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLCDSL_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_START_DIM0_t f;
} SLCDSL_REGS_DTE_SLICE_START_DIM0_u;

#define SLCDSL_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLCDSL_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLCDSL_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_START_DIM1_t f;
} SLCDSL_REGS_DTE_SLICE_START_DIM1_u;

#define SLCDSL_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLCDSL_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLCDSL_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_START_DIM2_t f;
} SLCDSL_REGS_DTE_SLICE_START_DIM2_u;

#define SLCDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _SLCDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} SLCDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} SLCDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define SLCDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _SLCDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} SLCDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} SLCDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define SLCDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _SLCDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} SLCDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} SLCDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define SLCDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _SLCDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} SLCDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} SLCDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define SLCDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _SLCDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} SLCDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DSL_START_DIM0_t f;
} SLCDSL_REGS_DTE_DSL_START_DIM0_u;

#define SLCDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _SLCDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} SLCDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DSL_START_DIM1_t f;
} SLCDSL_REGS_DTE_DSL_START_DIM1_u;

#define SLCDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _SLCDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} SLCDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DSL_START_DIM2_t f;
} SLCDSL_REGS_DTE_DSL_START_DIM2_u;

#define SLCDSL_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0088
typedef struct _SLCDSL_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLCDSL_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_SLICE_START_DIM3_t f;
} SLCDSL_REGS_DTE_SLICE_START_DIM3_u;

#define SLCDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x008c
typedef struct _SLCDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} SLCDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCDSL_REGS_DTE_DSL_START_DIM3_t f;
} SLCDSL_REGS_DTE_DSL_START_DIM3_u;

#define SLCPAD_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLCPAD_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLCPAD_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLCPAD_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLCPAD_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLCPAD_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLCPAD_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLCPAD_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLCPAD_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLCPAD_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLCPAD_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLCPAD_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLCPAD_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLCPAD_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLCPAD_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLCPAD_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLCPAD_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLCPAD_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLCPAD_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLCPAD_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLCPAD_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLCPAD_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLCPAD_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLCPAD_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_START_DIM0_t f;
} SLCPAD_REGS_DTE_SLICE_START_DIM0_u;

#define SLCPAD_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLCPAD_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLCPAD_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_START_DIM1_t f;
} SLCPAD_REGS_DTE_SLICE_START_DIM1_u;

#define SLCPAD_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLCPAD_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLCPAD_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_START_DIM2_t f;
} SLCPAD_REGS_DTE_SLICE_START_DIM2_u;

#define SLCPAD_REGS_DTE_PAD_CTRL_DIM0_OFFSET 0x0070
typedef struct _SLCPAD_REGS_DTE_PAD_CTRL_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM0_LOW:11;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int PAD_DIM0_LOW:11;
#endif
} SLCPAD_REGS_DTE_PAD_CTRL_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_PAD_CTRL_DIM0_t f;
} SLCPAD_REGS_DTE_PAD_CTRL_DIM0_u;

#define SLCPAD_REGS_DTE_PAD_CTRL_DIM1_OFFSET 0x0074
typedef struct _SLCPAD_REGS_DTE_PAD_CTRL_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM1_LOW:11;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM1_INTERIOR:10;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_LOW:11;
#endif
} SLCPAD_REGS_DTE_PAD_CTRL_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_PAD_CTRL_DIM1_t f;
} SLCPAD_REGS_DTE_PAD_CTRL_DIM1_u;

#define SLCPAD_REGS_DTE_PAD_CTRL_DIM2_OFFSET 0x0078
typedef struct _SLCPAD_REGS_DTE_PAD_CTRL_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM2_LOW:11;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM2_INTERIOR:10;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_LOW:11;
#endif
} SLCPAD_REGS_DTE_PAD_CTRL_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_PAD_CTRL_DIM2_t f;
} SLCPAD_REGS_DTE_PAD_CTRL_DIM2_u;

#define SLCPAD_REGS_DTE_PAD_CTRL_DIM3_OFFSET 0x007c
typedef struct _SLCPAD_REGS_DTE_PAD_CTRL_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM3_LOW:11;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM3_INTERIOR:10;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_LOW:11;
#endif
} SLCPAD_REGS_DTE_PAD_CTRL_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_PAD_CTRL_DIM3_t f;
} SLCPAD_REGS_DTE_PAD_CTRL_DIM3_u;

#define SLCPAD_REGS_DTE_PAD_VALUE_OFFSET 0x0080
typedef struct _SLCPAD_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} SLCPAD_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_PAD_VALUE_t f;
} SLCPAD_REGS_DTE_PAD_VALUE_u;

#define SLCPAD_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0088
typedef struct _SLCPAD_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLCPAD_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCPAD_REGS_DTE_SLICE_START_DIM3_t f;
} SLCPAD_REGS_DTE_SLICE_START_DIM3_u;

#define SLCRSHP_REGS_DTE_SLICE_SIZE_DIM0_OFFSET 0x0040
typedef struct _SLCRSHP_REGS_DTE_SLICE_SIZE_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM0_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_SIZE_DIM0_t f;
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM0_u;

#define SLCRSHP_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SLCRSHP_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SRC_DIM0_SIZE_t f;
} SLCRSHP_REGS_DTE_SRC_DIM0_SIZE_u;

#define SLCRSHP_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SLCRSHP_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SRC_DIM1_SIZE_t f;
} SLCRSHP_REGS_DTE_SRC_DIM1_SIZE_u;

#define SLCRSHP_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SLCRSHP_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SRC_DIM2_SIZE_t f;
} SLCRSHP_REGS_DTE_SRC_DIM2_SIZE_u;

#define SLCRSHP_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SLCRSHP_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SRC_DIM3_SIZE_t f;
} SLCRSHP_REGS_DTE_SRC_DIM3_SIZE_u;

#define SLCRSHP_REGS_DTE_SLICE_SIZE_DIM1_OFFSET 0x0054
typedef struct _SLCRSHP_REGS_DTE_SLICE_SIZE_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM1_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_SIZE_DIM1_t f;
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM1_u;

#define SLCRSHP_REGS_DTE_SLICE_SIZE_DIM2_OFFSET 0x0058
typedef struct _SLCRSHP_REGS_DTE_SLICE_SIZE_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM2_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_SIZE_DIM2_t f;
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM2_u;

#define SLCRSHP_REGS_DTE_SLICE_SIZE_DIM3_OFFSET 0x005c
typedef struct _SLCRSHP_REGS_DTE_SLICE_SIZE_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SLICE_DIM3_SIZE:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_SIZE_DIM3_t f;
} SLCRSHP_REGS_DTE_SLICE_SIZE_DIM3_u;

#define SLCRSHP_REGS_DTE_SLICE_START_DIM0_OFFSET 0x0060
typedef struct _SLCRSHP_REGS_DTE_SLICE_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM0_START:24;
    unsigned int SLICE_DIM0_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM0_START_DIR:1;
    unsigned int SLICE_DIM0_START:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_START_DIM0_t f;
} SLCRSHP_REGS_DTE_SLICE_START_DIM0_u;

#define SLCRSHP_REGS_DTE_SLICE_START_DIM1_OFFSET 0x0064
typedef struct _SLCRSHP_REGS_DTE_SLICE_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM1_START:24;
    unsigned int SLICE_DIM1_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM1_START_DIR:1;
    unsigned int SLICE_DIM1_START:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_START_DIM1_t f;
} SLCRSHP_REGS_DTE_SLICE_START_DIM1_u;

#define SLCRSHP_REGS_DTE_SLICE_START_DIM2_OFFSET 0x0068
typedef struct _SLCRSHP_REGS_DTE_SLICE_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM2_START:24;
    unsigned int SLICE_DIM2_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM2_START_DIR:1;
    unsigned int SLICE_DIM2_START:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_START_DIM2_t f;
} SLCRSHP_REGS_DTE_SLICE_START_DIM2_u;

#define SLCRSHP_REGS_DTE_SLC_RESHAPE_CTRL_OFFSET 0x006c
typedef struct _SLCRSHP_REGS_DTE_SLC_RESHAPE_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLC_RESHAPE_DIM0_MAP:2;
    unsigned int SLC_RESHAPE_DIM1_MAP:2;
    unsigned int SLC_RESHAPE_DIM2_MAP:2;
    unsigned int SLC_RESHAPE_DIM3_MAP:2;
    unsigned int :24;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :24;
    unsigned int SLC_RESHAPE_DIM3_MAP:2;
    unsigned int SLC_RESHAPE_DIM2_MAP:2;
    unsigned int SLC_RESHAPE_DIM1_MAP:2;
    unsigned int SLC_RESHAPE_DIM0_MAP:2;
#endif
} SLCRSHP_REGS_DTE_SLC_RESHAPE_CTRL_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLC_RESHAPE_CTRL_t f;
} SLCRSHP_REGS_DTE_SLC_RESHAPE_CTRL_u;

#define SLCRSHP_REGS_DTE_PAD_VALUE_OFFSET 0x0080
typedef struct _SLCRSHP_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} SLCRSHP_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_PAD_VALUE_t f;
} SLCRSHP_REGS_DTE_PAD_VALUE_u;

#define SLCRSHP_REGS_DTE_SLICE_START_DIM3_OFFSET 0x0088
typedef struct _SLCRSHP_REGS_DTE_SLICE_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SLICE_DIM3_START:24;
    unsigned int SLICE_DIM3_START_DIR:1;
    unsigned int :7;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :7;
    unsigned int SLICE_DIM3_START_DIR:1;
    unsigned int SLICE_DIM3_START:24;
#endif
} SLCRSHP_REGS_DTE_SLICE_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    SLCRSHP_REGS_DTE_SLICE_START_DIM3_t f;
} SLCRSHP_REGS_DTE_SLICE_START_DIM3_u;

#define SSMP_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _SSMP_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} SSMP_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    SSMP_REGS_DTE_SRC_DIM0_SIZE_t f;
} SSMP_REGS_DTE_SRC_DIM0_SIZE_u;

#define SSMP_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _SSMP_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} SSMP_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    SSMP_REGS_DTE_SRC_DIM1_SIZE_t f;
} SSMP_REGS_DTE_SRC_DIM1_SIZE_u;

#define SSMP_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _SSMP_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} SSMP_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    SSMP_REGS_DTE_SRC_DIM2_SIZE_t f;
} SSMP_REGS_DTE_SRC_DIM2_SIZE_u;

#define SSMP_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _SSMP_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} SSMP_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    SSMP_REGS_DTE_SRC_DIM3_SIZE_t f;
} SSMP_REGS_DTE_SRC_DIM3_SIZE_u;

#define SSMP_REGS_DTE_SSMP_CTRL_OFFSET 0x006c
typedef struct _SSMP_REGS_DTE_SSMP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SSMP_ROW_STRIDE:11;
    unsigned int :21;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :21;
    unsigned int SSMP_ROW_STRIDE:11;
#endif
} SSMP_REGS_DTE_SSMP_CTRL_t;

typedef union {
    unsigned int val : 32;
    SSMP_REGS_DTE_SSMP_CTRL_t f;
} SSMP_REGS_DTE_SSMP_CTRL_u;

#define SVSDEC_REGS_DTE_SVS_DECMP_MIN_PKT_SIZE_OFFSET 0x0044
typedef struct _SVSDEC_REGS_DTE_SVS_DECMP_MIN_PKT_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DECMP_MIN_PKT_SIZE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DECMP_MIN_PKT_SIZE:32;
#endif
} SVSDEC_REGS_DTE_SVS_DECMP_MIN_PKT_SIZE_t;

typedef union {
    unsigned int val : 32;
    SVSDEC_REGS_DTE_SVS_DECMP_MIN_PKT_SIZE_t f;
} SVSDEC_REGS_DTE_SVS_DECMP_MIN_PKT_SIZE_u;

#define SVSDEC_REGS_DTE_SVS_DECMP_SRC_ADDR_INC_OFFSET 0x0048
typedef struct _SVSDEC_REGS_DTE_SVS_DECMP_SRC_ADDR_INC_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_ADDR_INC:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SRC_ADDR_INC:32;
#endif
} SVSDEC_REGS_DTE_SVS_DECMP_SRC_ADDR_INC_t;

typedef union {
    unsigned int val : 32;
    SVSDEC_REGS_DTE_SVS_DECMP_SRC_ADDR_INC_t f;
} SVSDEC_REGS_DTE_SVS_DECMP_SRC_ADDR_INC_u;

#define SVSDEC_REGS_DTE_SVS_DECMP_CTRL_OFFSET 0x006c
typedef struct _SVSDEC_REGS_DTE_SVS_DECMP_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SVS_DECMP_EN:1;
    unsigned int SVS_DECMP_HEADER_MODE:1;
    unsigned int :2;
    unsigned int SVS_DECMP_N_PKT_NUM:5;
    unsigned int :23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :23;
    unsigned int SVS_DECMP_N_PKT_NUM:5;
    unsigned int :2;
    unsigned int SVS_DECMP_HEADER_MODE:1;
    unsigned int SVS_DECMP_EN:1;
#endif
} SVSDEC_REGS_DTE_SVS_DECMP_CTRL_t;

typedef union {
    unsigned int val : 32;
    SVSDEC_REGS_DTE_SVS_DECMP_CTRL_t f;
} SVSDEC_REGS_DTE_SVS_DECMP_CTRL_u;

#define SVSDEC_REGS_DTE_SVS_DECMP_DST_ADDR_INC_OFFSET 0x0070
typedef struct _SVSDEC_REGS_DTE_SVS_DECMP_DST_ADDR_INC_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_ADDR_INC:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int DST_ADDR_INC:32;
#endif
} SVSDEC_REGS_DTE_SVS_DECMP_DST_ADDR_INC_t;

typedef union {
    unsigned int val : 32;
    SVSDEC_REGS_DTE_SVS_DECMP_DST_ADDR_INC_t f;
} SVSDEC_REGS_DTE_SVS_DECMP_DST_ADDR_INC_u;

#define VMIR_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _VMIR_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} VMIR_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIR_REGS_DTE_SRC_DIM0_SIZE_t f;
} VMIR_REGS_DTE_SRC_DIM0_SIZE_u;

#define VMIR_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _VMIR_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} VMIR_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIR_REGS_DTE_SRC_DIM1_SIZE_t f;
} VMIR_REGS_DTE_SRC_DIM1_SIZE_u;

#define VMIR_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _VMIR_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} VMIR_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIR_REGS_DTE_SRC_DIM2_SIZE_t f;
} VMIR_REGS_DTE_SRC_DIM2_SIZE_u;

#define VMIR_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _VMIR_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} VMIR_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIR_REGS_DTE_SRC_DIM3_SIZE_t f;
} VMIR_REGS_DTE_SRC_DIM3_SIZE_u;

#define VMIRDSL_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _VMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_SRC_DIM0_SIZE_t f;
} VMIRDSL_REGS_DTE_SRC_DIM0_SIZE_u;

#define VMIRDSL_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _VMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_SRC_DIM1_SIZE_t f;
} VMIRDSL_REGS_DTE_SRC_DIM1_SIZE_u;

#define VMIRDSL_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _VMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_SRC_DIM2_SIZE_t f;
} VMIRDSL_REGS_DTE_SRC_DIM2_SIZE_u;

#define VMIRDSL_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _VMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_SRC_DIM3_SIZE_t f;
} VMIRDSL_REGS_DTE_SRC_DIM3_SIZE_u;

#define VMIRDSL_REGS_DTE_DST_DIM0_SIZE_OFFSET 0x006c
typedef struct _VMIRDSL_REGS_DTE_DST_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM0_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_DST_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DST_DIM0_SIZE_t f;
} VMIRDSL_REGS_DTE_DST_DIM0_SIZE_u;

#define VMIRDSL_REGS_DTE_DST_DIM1_SIZE_OFFSET 0x0070
typedef struct _VMIRDSL_REGS_DTE_DST_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM1_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_DST_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DST_DIM1_SIZE_t f;
} VMIRDSL_REGS_DTE_DST_DIM1_SIZE_u;

#define VMIRDSL_REGS_DTE_DST_DIM2_SIZE_OFFSET 0x0074
typedef struct _VMIRDSL_REGS_DTE_DST_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM2_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_DST_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DST_DIM2_SIZE_t f;
} VMIRDSL_REGS_DTE_DST_DIM2_SIZE_u;

#define VMIRDSL_REGS_DTE_DST_DIM3_SIZE_OFFSET 0x0078
typedef struct _VMIRDSL_REGS_DTE_DST_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DST_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DST_DIM3_SIZE:24;
#endif
} VMIRDSL_REGS_DTE_DST_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DST_DIM3_SIZE_t f;
} VMIRDSL_REGS_DTE_DST_DIM3_SIZE_u;

#define VMIRDSL_REGS_DTE_DSL_START_DIM0_OFFSET 0x007c
typedef struct _VMIRDSL_REGS_DTE_DSL_START_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM0_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM0_START:24;
#endif
} VMIRDSL_REGS_DTE_DSL_START_DIM0_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DSL_START_DIM0_t f;
} VMIRDSL_REGS_DTE_DSL_START_DIM0_u;

#define VMIRDSL_REGS_DTE_DSL_START_DIM1_OFFSET 0x0080
typedef struct _VMIRDSL_REGS_DTE_DSL_START_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM1_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM1_START:24;
#endif
} VMIRDSL_REGS_DTE_DSL_START_DIM1_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DSL_START_DIM1_t f;
} VMIRDSL_REGS_DTE_DSL_START_DIM1_u;

#define VMIRDSL_REGS_DTE_DSL_START_DIM2_OFFSET 0x0084
typedef struct _VMIRDSL_REGS_DTE_DSL_START_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM2_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM2_START:24;
#endif
} VMIRDSL_REGS_DTE_DSL_START_DIM2_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DSL_START_DIM2_t f;
} VMIRDSL_REGS_DTE_DSL_START_DIM2_u;

#define VMIRDSL_REGS_DTE_DSL_START_DIM3_OFFSET 0x008c
typedef struct _VMIRDSL_REGS_DTE_DSL_START_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int DSL_DIM3_START:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int DSL_DIM3_START:24;
#endif
} VMIRDSL_REGS_DTE_DSL_START_DIM3_t;

typedef union {
    unsigned int val : 32;
    VMIRDSL_REGS_DTE_DSL_START_DIM3_t f;
} VMIRDSL_REGS_DTE_DSL_START_DIM3_u;

#define VMIRPAD_REGS_DTE_SRC_DIM0_SIZE_OFFSET 0x0044
typedef struct _VMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM0_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM0_SIZE:24;
#endif
} VMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_SRC_DIM0_SIZE_t f;
} VMIRPAD_REGS_DTE_SRC_DIM0_SIZE_u;

#define VMIRPAD_REGS_DTE_SRC_DIM1_SIZE_OFFSET 0x0048
typedef struct _VMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM1_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM1_SIZE:24;
#endif
} VMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_SRC_DIM1_SIZE_t f;
} VMIRPAD_REGS_DTE_SRC_DIM1_SIZE_u;

#define VMIRPAD_REGS_DTE_SRC_DIM2_SIZE_OFFSET 0x004c
typedef struct _VMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM2_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM2_SIZE:24;
#endif
} VMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_SRC_DIM2_SIZE_t f;
} VMIRPAD_REGS_DTE_SRC_DIM2_SIZE_u;

#define VMIRPAD_REGS_DTE_SRC_DIM3_SIZE_OFFSET 0x0050
typedef struct _VMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SRC_DIM3_SIZE:24;
    unsigned int :8;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :8;
    unsigned int SRC_DIM3_SIZE:24;
#endif
} VMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_SRC_DIM3_SIZE_t f;
} VMIRPAD_REGS_DTE_SRC_DIM3_SIZE_u;

#define VMIRPAD_REGS_DTE_PAD_CTRL_DIM0_OFFSET 0x0070
typedef struct _VMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM0_LOW:11;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int :10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int :10;
    unsigned int PAD_DIM0_HIGH:11;
    unsigned int PAD_DIM0_LOW:11;
#endif
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_PAD_CTRL_DIM0_t f;
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM0_u;

#define VMIRPAD_REGS_DTE_PAD_CTRL_DIM1_OFFSET 0x0074
typedef struct _VMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM1_LOW:11;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM1_INTERIOR:10;
    unsigned int PAD_DIM1_HIGH:11;
    unsigned int PAD_DIM1_LOW:11;
#endif
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_PAD_CTRL_DIM1_t f;
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM1_u;

#define VMIRPAD_REGS_DTE_PAD_CTRL_DIM2_OFFSET 0x0078
typedef struct _VMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM2_LOW:11;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM2_INTERIOR:10;
    unsigned int PAD_DIM2_HIGH:11;
    unsigned int PAD_DIM2_LOW:11;
#endif
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_PAD_CTRL_DIM2_t f;
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM2_u;

#define VMIRPAD_REGS_DTE_PAD_CTRL_DIM3_OFFSET 0x007c
typedef struct _VMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_DIM3_LOW:11;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_INTERIOR:10;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_DIM3_INTERIOR:10;
    unsigned int PAD_DIM3_HIGH:11;
    unsigned int PAD_DIM3_LOW:11;
#endif
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_PAD_CTRL_DIM3_t f;
} VMIRPAD_REGS_DTE_PAD_CTRL_DIM3_u;

#define VMIRPAD_REGS_DTE_PAD_VALUE_OFFSET 0x0080
typedef struct _VMIRPAD_REGS_DTE_PAD_VALUE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int PAD_VALUE:32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int PAD_VALUE:32;
#endif
} VMIRPAD_REGS_DTE_PAD_VALUE_t;

typedef union {
    unsigned int val : 32;
    VMIRPAD_REGS_DTE_PAD_VALUE_t f;
} VMIRPAD_REGS_DTE_PAD_VALUE_u;


#pragma pack(pop)

// clang-format on

#endif  // HARDWARE_GDTE_LIBRA_GDTE_LIBRA_OP_TYPE_ZEB_C2_H_
