
#ifndef _SM4_USER_DEFS_H_
#define _SM4_USER_DEFS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
//#include "svdpi.h"
//#include "vpi_user.h"


#if defined(_MSC_VER) && (defined(_M_IX86) || defined(_M_AMD64) || defined(_M_X64))
# define SWAP(x) (_lrotl(x, 8) & 0x00ff00ff | _lrotr(x, 8) & 0xff00ff00)
# define GETU32(p) SWAP(*((u32 *)(p)))
# define PUTU32(ct, st) { *((u32 *)(ct)) = SWAP((st)); }
#else
# define GETU32(pt) (((u32)(pt)[0] << 24) ^ ((u32)(pt)[1] << 16) ^ ((u32)(pt)[2] <<  8) ^ ((u32)(pt)[3]))
#endif

#define GETB0(w)  (u8)((w & 0xff000000) >> 24);  
#define GETB1(w)  (u8)((w & 0x00ff0000) >> 16); 
#define GETB2(w)  (u8)((w & 0x0000ff00) >> 8 ); 
#define GETB3(w)  (u8)((w & 0x000000ff) >> 0 ); 

#define GET32UNIT(w0,w1,w2,w3) ((u32)w0) << 24 | ((u32)w1) << 16 | ((u32)w2) << 8 | ((u32)w3) ;

typedef unsigned int u32;
typedef unsigned short u16;
typedef unsigned char u8;

typedef unsigned int   *u32_p;
typedef unsigned short *u16_p;
typedef unsigned char  *u8_p;

#endif //_SM4_USER_DEFS_H_
