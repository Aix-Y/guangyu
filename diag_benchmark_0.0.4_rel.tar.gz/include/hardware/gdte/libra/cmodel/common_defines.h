#ifndef _C_MODEL_COMMON_DEFINES_H_
#define _C_MODEL_COMMON_DEFINES_H_

#define OP_TYPE_LNC                0x01
#define OP_TYPE_SS                 0x02
#define OP_TYPE_GS                 0x03
#define OP_TYPE_DS                 0x06
#define OP_TYPE_DE                 0x07
#define OP_TYPE_CF                 0x08
#define OP_TYPE_PAD                0x10
#define OP_TYPE_RSHP               0x12
#define OP_TYPE_BRDCST             0x13
#define OP_TYPE_SLC                0x14
#define OP_TYPE_DSL                0x15
#define OP_TYPE_SSMP               0x16
#define OP_TYPE_HMIR               0x17
#define OP_TYPE_VMIR               0x18
#define OP_TYPE_HSDC               0x25
#define OP_TYPE_SLCPAD             0x30
#define OP_TYPE_SLCDSL             0x31
#define OP_TYPE_SLCDE              0x32
#define OP_TYPE_HMIRDSL            0x33
#define OP_TYPE_VMIRDSL            0x34
#define OP_TYPE_HMIRPAD            0x35
#define OP_TYPE_VMIRPAD            0x36
#define OP_TYPE_CFDSL              0x37
#define OP_TYPE_SLCRSHP            0x38
#define OP_TYPE_RSHPDSL            0x39 
#define OP_TYPE_DSDSL              0x3a
#define OP_TYPE_SLCBRDCST          0x3b

inline const char* get_op_type_name(int v)
{
    switch (v)
    {
        case OP_TYPE_LNC            : return "LNC";         
        case OP_TYPE_SS             : return "SS";          
        case OP_TYPE_GS             : return "GS";          
        case OP_TYPE_DS             : return "DS";          
        case OP_TYPE_DE             : return "DE";      
        case OP_TYPE_CF             : return "CF";          
        case OP_TYPE_PAD            : return "PAD";         
        case OP_TYPE_RSHP           : return "RSHP";        
        case OP_TYPE_BRDCST         : return "BRDCST";      
        case OP_TYPE_SLC            : return "SLC";         
        case OP_TYPE_DSL            : return "DSL";         
        case OP_TYPE_SSMP           : return "SSMP";        
        case OP_TYPE_HMIR           : return "HMIR";        
        case OP_TYPE_VMIR           : return "VMIR";        
        case OP_TYPE_HSDC           : return "HSDC";      
        case OP_TYPE_SLCPAD         : return "SLCPAD";      
        case OP_TYPE_SLCDSL         : return "SLCDSL";      
        case OP_TYPE_SLCDE          : return "SLCDE";       
        case OP_TYPE_HMIRDSL        : return "HMIRDSL";     
        case OP_TYPE_VMIRDSL        : return "VMIRDSL";     
        case OP_TYPE_HMIRPAD        : return "HMIRPAD";     
        case OP_TYPE_VMIRPAD        : return "VMIRPAD";    
        case OP_TYPE_CFDSL          : return "CFDSL";       
        case OP_TYPE_SLCRSHP        : return "SLCRSHP";     
        case OP_TYPE_RSHPDSL        : return "RSHPDSL";     
        case OP_TYPE_DSDSL          : return "DSDSL";
        case OP_TYPE_SLCBRDCST      : return "SLCBRDCST";
        default                     : return "UNKNOWN";
    }
}

#define BPE_CODE(bpe) (1<<bpe)
#define DSE_RATIO_CODE(ratio) (1<<(ratio+1))

#define GSCPC_HDR_BITS      48
#define GSCP_HDR_BITS       48
#define SCP_HDR_BITS        16
#define SUM_BITS            8
#define MASK_BITS           128
#define GSCPC_RD_MIN_SIZE   144
#define GSCP_RD_MIN_SIZE    138
#define SCP_RD_MIN_SIZE     136

typedef enum hsdc_type_enum {
    HSDC_SCP2RAW = 0,
    HSDC_GSCP2RAW = 1,
    HSDC_GSCP2SCP = 2,
    HSDC_GSCPC2GSCP = 3,
    HSDC_SCP2SCP = 4,
    HSDC_GSCP2GSCP = 5,
    HSDC_GSCPC2GSCPC = 6
} hsdc_type_e;

#endif
