#ifndef LOG_WRAPPER_T
#define LOG_WRAPPER_T

#define log_error(...) (void)0
#define log_info(...) (void)0

#define verbosity 0
#define EF_VERBOSITY_FULL 3

class log_wrapper_t {};

#endif
