/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_LIBRA_CDTE_GDTE_H_
#define HARDWARE_GDTE_LIBRA_CDTE_GDTE_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "hardware/gdte/libra/cdte/gdte_vc.h"
#include "hardware/gdte/libra/gdte.h"

namespace efvf {
namespace hardware {
namespace gdte {
class CdteLibra : public GdteLibra {
 public:
    /**
    * @brief      Constructs a new instance.
    *
    * @param[in]  logger  The logger
    */
    explicit CdteLibra(std::shared_ptr<spdlog::logger> logger) : GdteLibra(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~CdteLibra() {}

    /**
     * @brief      Gets the vc status.
     *
     * @param      status  The status
     */
    virtual void GetVcStatus(std::vector<int> &status);

    /**
     * @brief      Gets the debug position.
     *
     * @return     The debug position.
     */
    virtual uint64_t GetDbgThdPos();

    /**
     * @brief Dump each thread position.
     *
     */
    virtual void DumpThdPos();

    /**
     * @brief      Gets the eng name.
     *
     * @return     The eng name.
     */
    virtual std::string GetEngName() {
        return "cdte";
    }

    /**
     * @brief      Sets the hit ratio.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetHitRatio(const HitRatioCfg &cfg) {}

    /**
     * @brief      Sets the partial wr.
     *
     * @param[in]  val   The new value 0 or 1
     */
    virtual void SetPartialWr(uint32_t val) {
        LOG_WARN("{} do not support partial write.", this->GetEngName());
    }

    /**
     * @brief      { function_description }
     */
    virtual bool WaitEngineIdle(int timeout);

    /**
     * @brief      { function_description }
     */
    virtual void EnClkGate();

    /**
     * @brief Enable or disable rshp ifb mode
     *
     * @param enable
     */
    virtual void EnRshpIfbMode(bool enable);

    /**
     * @brief Enable or disable dynamic queue
     *
     * @param enable
     */
    virtual void EnDynamicQueue(bool enable);

    /**
     * @brief      Determines if engine busy.
     *
     * @return     True if engine busy, False otherwise.
     */
    virtual bool IsEngineBusy();

    /**
     * @brief
     *
     * @return True if initialization done, False otherwise.
     */
    virtual bool IsEngineSramInitDone();

    /**
     * @brief      Determines if stop.
     *
     * @return     True if stop, False otherwise.
     */
    virtual bool IsEngineStop();

    /**
     * @brief      Sets the wr combine.
     *
     * @param[in]  status    The status
     * @param[in]  wait_num  The wait number
     */
    virtual void SetWrCombine(uint32_t status, uint32_t wait_num);

    /**
     * @brief      DTE time out threshold value; unit is 128 DTE clock cycles.
     *
     * @param[in]  val   The new value
     */
    virtual void SetTimeout(uint32_t val);

    /**
    * @brief      Sets the error stop.
    *
    * @param[in]  val   The new value
    */
    virtual void SetErrStop(uint32_t val);

    /**
     * @brief Set the Customized Trace Message Enable or not.
     *
     * @param val
     */
    virtual void SetCusTraceMesg(uint32_t val);

    /**
     * @brief      Sets the software stop.
     *
     * @param[in]  val   The new value
     */
    virtual void SetSwStop(uint32_t val, uint32_t stop_sig);

    /**
     * @brief      Sets the invld vc clr mbx en.
     *
     * @param[in]  status  The status
     */
    virtual void SetInvldVcClrMbxEn(uint32_t status);

    /**
     * @brief      Determines if write combine en.
     *
     * @return     True if write combine en, False otherwise.
     */
    virtual bool IsWriteCombineEn();

    /**
     * @brief      Sets the ih cause address.
     *
     * @param[in]  addr  The address
     */
    virtual void SetIhCauseAddr(uint32_t addr);

    /**
     * @brief Set the customized event agent cause address.
     *
     * @param addr
     */
    virtual void SetCusEvntAgentCauseAddr(uint32_t addr);

    /**
     * @brief      Sets the data sram parity error.
     *
     * @param[in]  status  The status
     */
    virtual void SetDataSramParityErr(bool status);

    /**
     * @brief      { function_description }
     */
    virtual void SetRegSramParityErr(bool status);

    /**
     * @brief      Sets the order list pri.
     *
     * @param[in]  status  The status
     */
    virtual void SetOrderListPri(int status);

    /**
     * @brief      Gets the eng control address.
     */
    virtual uint64_t GetEngCtrlAddr();

    /**
     * @brief      Gets the eng control value.
     */
    virtual uint32_t GetEngCtrlVal();

    /**
     * @brief      Gets the timeout control address.
     *
     * @return     The timeout control address.
     */
    virtual uint64_t GetTimeoutCtrlAddr();

    /**
     * @brief      Gets the thread mask.
     *
     * @return     The thread mask.
     */
    virtual uint32_t GetThreadMask();

    /**
     * @brief Get the random Noc Qos Initial Value.
     *
     * @return uint32_t
     */
    virtual uint32_t GetNocQosIniValue();

    /**
     * @brief      Gets the clock m hz.
     *
     * @return     The clock m hz.
     */
    virtual uint64_t GetClkMHz();

    /**
     * @brief      Gets the sa.
     *
     * @return     The sa.
     */
    virtual SystemAdapter *GetSa();

    /**
     * @brief      Shows the operation description.
     */
    virtual void ShowOpDesc();

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  bl_list  {RPORT, WPORT}
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetBL(const DteBurstLen &bl);

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  burstlen  The burstlen
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetBL(uint32_t burstlen);

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  burstlen  The burstlen
     *
     * @return     { description_of_the_return_value }
     */
    virtual void SetMaxBL();

    /**
     * @brief      Gets the bl.
     *
     * @return     The bl.
     */
    virtual DteBurstLen GetBL();

    /**
     * @brief      Sets the debug misc.
     *
     * @param[in]  cfg   The new value
     *
     * @return     { description_of_the_return_value }
     */
    virtual void SetDbgMisc(const DebugMiscCfg &cfg);

    /**
     * @brief      Sets the reorder.
     *
     * @param[in]  status  The status
     */
    virtual void SetReorder(bool status);

    /**
     * @brief      Gets the bpm number.
     *
     * @return     The bpm number.
     */
    virtual uint32_t GetPortNum() {
        return 4;
    }

    /**
      * @brief      Gets the performance pmc.
      *
      * @return     The performance pmc.
      */
    virtual Pmc *GetPerfPmc();

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStart();

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStop();

    /**
     * @brief      Gets the busy cycle.
     */
    virtual uint64_t GetBusyCycle();

    /**
     * @brief Get the Busy Rate
     *
     * @return double
     */
    virtual double GetBusyRate();

    /**
     * @brief      { function_description }
     */
    virtual void EnCrc(uint32_t port, int vc);

    /**
     * @brief      Gets the crc value.
     *
     * @return     The crc value.
     */
    virtual uint32_t GetCrcVal();

    /**
     * @brief      Calc data crc value.
     *
     * @param[in]  src_addr     The src buffer address
     * @param[in]  dst_addr     The dst buffer address
     * @param[in]  size         Calc crc data size
     * @param[in]  timeout      timeout value
     * @return     The crc value.
     */
    virtual uint32_t CalcDataCrc(
        uint64_t src_addr, uint64_t dst_addr, uint64_t size, int timeout);

    /**
     * @brief      Sets the throttle.
     *
     * @param[in]  window  The window
     * @param[in]  rd_bw   The rd bd
     * @param[in]  wr_bw   The wr bd
     * @param[in]  rd_os   The rd operating system
     * @param[in]  wr_os   The wr operating system
     * @param[in]  percent  The percent
     */
    virtual void SetThrottle(
        uint32_t window, uint32_t rd_bw, uint32_t wr_bw, uint32_t rd_os, uint32_t wr_os);

    /**
     * @brief      Sets the port throttle.
     *
     * @param[in]  port    The port
     * @param[in]  window  The window
     * @param[in]  rd_bw   The rd bd
     * @param[in]  wr_bw   The wr bd
     * @param[in]  rd_os   The rd operating system
     * @param[in]  wr_os   The wr operating system
     */
    virtual void SetPortThrottle(int port, uint32_t window, uint32_t rd_bw, uint32_t wr_bw,
        uint32_t rd_os, uint32_t wr_os);

    /**
     * @brief Set whether enable register sram initialization.
     *
     * @param enbale
     */
    virtual void SetSramInit(bool enable);

    /**
     * @brief Force trigger interrupt.
     *
     * @param cfg
     */
    virtual void ForceTriggerInterrupt(IntrptCfg *cfg);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint64_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void RegWrite(uint64_t addr, uint32_t val);

 private:
    std::mutex mutex_;

 private:
    /**
     * @brief      { function_description }
     */
    virtual void LibInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInitMini();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit();
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  //  HARDWARE_GDTE_LIBRA_CDTE_GDTE_H_
