/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SYSM_3D0_SYS_MON_TASK_3D0_GST_H_
#define HARDWARE_SYSM_3D0_SYS_MON_TASK_3D0_GST_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"

#include "hardware/sysm/3d0/sys_mon_task_3d0.h"

namespace efvf {
namespace hardware {
namespace sysm {

class SysMonTask3d0Gst : public SysMonTask3d0 {
 public:
    explicit SysMonTask3d0Gst(const Dtu &dtu) : SysMonTask3d0(dtu) {}
    virtual ~SysMonTask3d0Gst() {}

 public:
    void     syst_notify_create(void);
    void     syst_notify_created(void);
    void     syst_notify_delete(void);
    void     syst_notify_deleted(void);
    uint32_t syst_get_dlms(void);

 public:
    void Execute(void *);  // refer efvf::framework::service_mgr::Task
};

}  // namespace sysm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SYSM_3D0_SYS_MON_TASK_3D0_GST_H_
