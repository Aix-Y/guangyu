/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SYSM_4D0_SYS_MON_4D0_H_
#define HARDWARE_SYSM_4D0_SYS_MON_4D0_H_

#include <map>
#include <memory>
#include <string>

#include "framework/include/service_mgr.h"

#include "hardware/include/sysm/sys_mon.h"
#include "hardware/sysm/4d0/sys_mon_task_4d0.h"

namespace efvf {
namespace hardware {
namespace sysm {

using efvf::framework::service_mgr::Task;

class SysMon4d0 : public SysMon {
 public:
    explicit SysMon4d0(const Dtu &);
    virtual ~SysMon4d0() {
        Destroy();  // avoid exception
    }

 public:
    void Create(void);
    void Destroy(void);

 private:
    typedef struct _task_info {
        _task_info() : sysm_task(nullptr), scheduler(nullptr) {}

        std::unique_ptr<SysMonTask4d0>       sysm_task;
        std::unique_ptr<Task<SysMonTask4d0>> scheduler;
    } task_info;

 private:
    void                       sysm_task_create(uint32_t);
    void                       sysm_task_delete(uint32_t);
    bool                       sysm_task_param_ena(void);
    std::string                sysm_task_param_list(void);
    std::string                sysm_task_param_off(void);
    std::shared_ptr<task_info> sysm_task_info_get(uint32_t);
    std::string                sysm_task_info_name(uint32_t);
    uint32_t                   sysm_task_info_id(uint32_t);

 private:
    bool       m_sysm_ena;
    std::mutex m_task_info_lk;
    std::map<uint32_t, std::shared_ptr<task_info>> m_task_info;
};

}  // namespace sysm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SYSM_4D0_SYS_MON_4D0_H_
