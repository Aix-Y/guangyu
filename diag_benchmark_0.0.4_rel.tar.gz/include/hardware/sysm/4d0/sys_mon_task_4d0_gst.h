/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SYSM_4D0_SYS_MON_TASK_4D0_GST_H_
#define HARDWARE_SYSM_4D0_SYS_MON_TASK_4D0_GST_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"

#include "hardware/sysm/4d0/sys_mon_task_4d0.h"

namespace efvf {
namespace hardware {
namespace sysm {

class SysMonTask4d0Gst : public SysMonTask4d0 {
 public:
    explicit SysMonTask4d0Gst(const Dtu &dtu) : SysMonTask4d0(dtu) {}
    virtual ~SysMonTask4d0Gst() {}

 public:
    void     syst_notify_create(void);
    void     syst_notify_created(void);
    void     syst_notify_delete(void);
    void     syst_notify_deleted(void);
    uint32_t syst_get_dlms(void);

 public:
    void Execute(void *);  // refer efvf::framework::service_mgr::Task
};

}  // namespace sysm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SYSM_4D0_SYS_MON_TASK_4D0_GST_H_
