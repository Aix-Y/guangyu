/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_XMC_LIBRA_XMC_RAS_H_
#define HARDWARE_XMC_LIBRA_XMC_RAS_H_

#include <string>

#include "hardware/include/xmc/xmc_ras.h"

namespace efvf {
namespace hardware {
namespace xmc {

class XmcLibra;
class XmcRasLibra : public XmcRas {
 public:
    /**
     * @brief Construct a new Xmc Ras Libra
     *
     * @param xmc
     */
    explicit XmcRasLibra(XmcLibra *xmc);

    /**
     * @brief Destroy the Xmc Ras Libra
     *
     */
    virtual ~XmcRasLibra() {}

    /**
     * @brief      could set multi config by setting next_
     *
     * @param      cfg   The configuration
     */
    virtual void Enable(RasCfg *cfg);

    /**
     * @brief      { function_description }
     */
    virtual void Disable(RasCfg *cfg);

    /**
     * @brief      Starts an error injection.
     *
     * @param      cfg      The configuration
     * @param      err_inj  The error inj
     */
    virtual void StartErrInjection(RasCfg *cfg, RasErrInj *err_inj);

    /**
     * @brief      Stops an error injection.
     *
     * @param      cfg      The configuration
     * @param      err_inj  The error inj
     */
    virtual void StopErrInjection(RasCfg *cfg, RasErrInj *err_inj) {}

    /**
     * @brief      Queries an error status.
     *
     * @param      cfg       The configuration
     * @param      err_stat  The error stat
     */
    virtual void QueryErrStatus(RasCfg *cfg, RasErrStat *err_stat);

    /**
     * @brief      { function_description }
     *
     * @param      cfg   The configuration
     */
    virtual void ClearErrStatus(RasCfg *cfg);

    /**
     * @brief      Prints an error status.
     *
     * @param      cfg   The configuration
     */
    virtual void PrintErrStatus(RasCfg *cfg) {}

    /**
     * @berif get ras cfg
     *
     * @param      cfg   The configuration
     */
    virtual void GetRasCfg(RasCfg *cfg) {}

    /**
     * @brief      Enables the interrupt.
     *
     * @param      cfg   The configuration
     */
    virtual void EnableInterrupt(IntrptCfg *cfg);

    /**
     * @brief      Disables the interrupt.
     *
     * @param      cfg   The configuration
     */
    virtual void DisableInterrupt(IntrptCfg *cfg);

    /**
     * @brief      { function_description }
     *
     * @param      cfg   The configuration
     */
    virtual void ClearInterrupt(IntrptCfg *cfg);

    /**
     * @brief      Queries an interrupt.
     *
     * @param      cfg    The configuration
     * @param      stats  The statistics
     */
    virtual void QueryInterrupt(IntrptCfg *cfg, IntrptStat *stats);

    /**
     * @brief      Prints an interrupt.
     *
     * @param      cfg   The configuration
     */
    virtual void PrintInterrupt(IntrptCfg *cfg);

    /**
     * @brief     generate error injection cfg
     *
     * @param[in]  type     The type
     * @param[in]  is_stop  is stopping err inj?
     *
     * @return     error injection cfg
     */
    virtual RasErrInj *GenRasErrInjCfg(const std::string &type, bool is_stop = false);

 private:
    /**
    * @brief      { function_description }
    *
    * @param[in]  addr  The address
    *
    * @return     { description_of_the_return_value }
    */
    virtual uint32_t RegRead(uint32_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void RegWrite(uint32_t addr, uint32_t val);

 protected:
    XmcLibra *xmc_;
};

}  //  namespace xmc
}  //  namespace hardware
}  //  namespace efvf

#endif  //  HARDWARE_XMC_LIBRA_XMC_RAS_H_
