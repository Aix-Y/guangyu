/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_ESL_LIBRA_CMODEL_NNC_H_
#define HARDWARE_ESL_LIBRA_CMODEL_NNC_H_
#include "hardware/esl/libra/cmodel/config.h"
#include "hardware/esl/libra/cmodel/dynamic_dict.h"

class dpi_nnc {
    public:
        cmp_dst_data_desc* nnc_compression(uint8_t* src_data,
                        uint8_t* raw_strb,
                        uint8_t* init_dict,
                        uint8_t blen, 
                        uint8_t data_type,
                        uint8_t null,
                        uint8_t* full_strb);

        decmp_dst_data_desc* nnc_decompression(uint8_t* src_data, uint8_t* init_dict);
};

cmp_dst_data_desc* dpi_nnc::nnc_compression(uint8_t* src_data, uint8_t* raw_strb, uint8_t* init_dict, uint8_t blen, uint8_t data_type, uint8_t null, uint8_t* full_strb)
{
     
    DynDict* dyn_dict = new DynDict();
    uint8_t* fp8_data = src_data; 
    uint16_t* fp16_data = (uint16_t*)src_data; 
    uint16_t* bf16_data = (uint16_t*)src_data; 
    uint32_t* fp32_data = (uint32_t*)src_data; 

    string header = "0000"; // rsv bit
    string is_full = "";
    string a; 
    string str;
    string fp16_mantissa;
    string mantissa2str;
    uint8_t whether_init;
    int dst_data_size = 6; // reserve space for header
    int dst_data_len = 0;
    int last_data_size = 0;
    uint8_t* per_data_packet = NULL;
    uint8_t per_packet_size = 0;

    uint8_t* uncmp_data = new uint8_t[32]();
    uint8_t* dst_data = new uint8_t[2694](); //2691 Byte = Header 6 Byte + max uncmp_data_size 768Byte(3 Byte*8 fp32 *32 transfer) + max blen wstrb 128 Byte + max cmp_data_size 1792 Byte

    data_desc* uncmp_data_desc = new data_desc();
    data_desc* cmp_data_desc = new data_desc();
    cmp_dst_data_desc* dst_data_desc = new cmp_dst_data_desc();
    
    if(null == 1){
        //printf("=========we get null burst data=========\n");
        for(int i=3; i>=0; i--){
            a= DecToBin(full_strb[i]);
            while(a.length() < 8){
                a = "0" + a;
            }
            is_full += a;
        }
        for(int i=0; i<blen; i++ ){
            str = is_full.substr(31-i,1);
            if(str == "0"){
                for(int j=0; j<4; j++){
                    dst_data[dst_data_size] = raw_strb[i*4+j];
                    dst_data_size += 1;
                }
            }
        }
        header += DecToBin(null);
        dst_data_len = (dst_data_size%32) ? (dst_data_size/32 + 1) : dst_data_size/32;
        last_data_size = (dst_data_size%32) ? (dst_data_size%32) : 32;
        a = DecToBin(blen-1);
        while(a.length() < 8){
            a = "0" + a;
        }
        header += a;
        if(data_type == SINT8 || data_type == UINT8){
            header += "000";
        } else if(data_type == FP8){
            header += "001";
        } else if(data_type == FP16){
            header += "010";
        } else if(data_type == BF16){
            header += "011";
        } else if(data_type == FP32){
            header += "100";
        }
        dst_data[0] = BinToDec(header.substr(8));
        dst_data[1] = BinToDec(header.substr(0,8));
        for(int i=0; i<4; i++){
            dst_data[i+2] = full_strb[i];
        }

    } else {
        if (data_type == SINT8 ||  data_type == UINT8) {
            //printf("=========we get INT8 data=========\n");
            for(int i=3; i>=0; i--){
                a= DecToBin(full_strb[i]);
                while(a.length() < 8){
                    a = "0" + a;
                }
                is_full += a;
            }
            for(int i=0; i<blen; i++ ){
                if(i==0)
                    whether_init = 1; //only the first transfer use init_dict
                else
                    whether_init = 0;
                str = is_full.substr(31-i,1);
                if(str == "0"){
                    for(int j=0; j<4; j++){
                        dst_data[dst_data_size] = raw_strb[i*4+j];
                        dst_data_size += 1;
                    }
                }
                for(int j=0; j<32; j++){
                    uncmp_data[j] = src_data[i*32+j];
                }
                uncmp_data_desc->data_size = 32;
                uncmp_data_desc->data_type = data_type;
                uncmp_data_desc->data = uncmp_data;
                cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict);
                
                per_data_packet = cmp_data_desc->data;
                per_packet_size = cmp_data_desc->data_size;
                //printf("per_packet_size is:%d\n", per_packet_size);
                for(int k=0; k<per_packet_size; k++){
                    dst_data[dst_data_size+k] = per_data_packet[k];
                }
                dst_data_size += per_packet_size;
                //printf("dst_data_size is:%d\n", dst_data_size);
            }
            header += DecToBin(null);
            dst_data_len = (dst_data_size%32) ? (dst_data_size/32 + 1) : dst_data_size/32;
            last_data_size = (dst_data_size%32) ? (dst_data_size%32) : 32;
            a = DecToBin(blen-1);
            while(a.length() < 8){
                a = "0" + a;
            }
            header += a;
            header += "000";
            dst_data[0] = BinToDec(header.substr(8));
            dst_data[1] = BinToDec(header.substr(0,8));
            for(int i=0; i<4; i++){
                dst_data[i+2] = full_strb[i];
            }

        }
        else if(data_type == FP8){
            //printf("=========we get FP8 data=========\n");
            for(int i=3; i>=0; i--){
                a= DecToBin(full_strb[i]);
                while(a.length() < 8){
                    a = "0" + a;
                }
                is_full += a;
            }
            for(int i=0; i<blen; i++){  
                if(i==0)
                    whether_init = 1; //only the first transfer use init_dict
                else
                    whether_init = 0;
                //extract expontent and mantissa
                for(int j=0; j<32; j++){
                    uncmp_data[j] = (fp8_data[i*32+j] >> 3) & 0xF;
                    mantissa2str += to_string((fp8_data[i*32+j] >> 7) & 1);
                    for(int m=2; m>=0; m--){
                        mantissa2str += to_string((fp8_data[i*32+j] >> m) & 1);
                    }
                }
                //write mantissa into consecutive address, wait packing
                for(int j=0; j<16; j++){
                    a = mantissa2str.substr(0,4);
                    a= mantissa2str.substr(4,4)+ a;
                    dst_data[dst_data_size] = BinToDec(a);
                    dst_data_size += 1;
                    mantissa2str.erase(0,8);
                }

                str = is_full.substr(31-i,1);
                if(str == "0"){
                    for(int j=0; j<4; j++){
                        dst_data[dst_data_size] = raw_strb[i*4+j];
                        dst_data_size += 1;
                    }
                }
                uncmp_data_desc->data_size = 32;
                uncmp_data_desc->data_type = data_type;
                uncmp_data_desc->data = uncmp_data;
                cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict);
                
                per_data_packet = cmp_data_desc->data;
                per_packet_size = cmp_data_desc->data_size;
                //printf("per_packet_size is:%d\n", per_packet_size);
                for(int k=0; k<per_packet_size; k++){
                    dst_data[dst_data_size+k] = per_data_packet[k];
                }
                dst_data_size += per_packet_size;
                //printf("dst_data_size is:%d\n", dst_data_size);
            }
            
            header += DecToBin(null);
            dst_data_len = (dst_data_size%32) ? (dst_data_size/32 + 1) : dst_data_size/32;
            last_data_size = (dst_data_size%32) ? (dst_data_size%32) : 32;
            a = DecToBin(blen-1);
            while(a.length() < 8){
                a = "0" + a;
            }
            header += a;
            header += "001";
            dst_data[0] = BinToDec(header.substr(8));
            dst_data[1] = BinToDec(header.substr(0,8));
            for(int i=0; i<4; i++){
                dst_data[i+2] = full_strb[i];
            }
        }
        else if(data_type == FP16){
           //printf("=========we get FP16 data=========\n");
           for(int i=3; i>=0; i--){
                a= DecToBin(full_strb[i]);
                while(a.length() < 8){
                    a = "0" + a;
                }
                is_full += a;
            }
           fp16_mantissa = ""; 
           for(int i=0; i<blen; i+=2){     
               if(i==0)
                   whether_init = 1; //only the first transfer use init_dict
               else
                   whether_init = 0;
               //extract expontent and mantissa
               if(blen%2 == 0){ 
                   for(int k=0; k<2; k++){
                       for(int j=0; j<16; j++){
                           uncmp_data[k*16+j] = (fp16_data[i*16+k*16+j] >> 10) & 0x1F;
                           fp16_mantissa += to_string((fp16_data[i*16+k*16+j] >> 15) & 1);
                           for(int m=9;m>=0;m--){
                                fp16_mantissa += to_string((fp16_data[i*16+k*16+j] >> m) & 1);
                           }
                           mantissa2str = fp16_mantissa + mantissa2str;
                           fp16_mantissa = "";
                       }
                       //write mantissa into consecutive address, wait packing
                       for(int j=21; j>=0; j--){//16 transfer x 11bit per transfer /8bit
                           string a = mantissa2str.substr(8*j,8);
                           dst_data[dst_data_size] = BinToDec(a);
                           dst_data_size += 1;
                           mantissa2str.erase(8*j,8);
                       }

                       str = is_full.substr(31-(i+k),1);
                       if(str == "0"){
                           for(int j=0; j<4; j++){
                               dst_data[dst_data_size] = raw_strb[(i+k)*4+j];
                               dst_data_size += 1;
                           }
                       }
                   }
                   uncmp_data_desc->data_size = 32;
                   uncmp_data_desc->data_type = data_type;
                   uncmp_data_desc->data = uncmp_data;
                   cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict);

                   per_data_packet = cmp_data_desc->data;
                   per_packet_size = cmp_data_desc->data_size;
                   for(int k=0; k<per_packet_size; k++){
                       dst_data[dst_data_size+k] = per_data_packet[k];
                   }
                   dst_data_size += per_packet_size;
               } else {
                   if((blen-i)>2){
                       for(int k=0; k<2; k++){
                           for(int j=0; j<16; j++){
                               uncmp_data[k*16+j] = (fp16_data[i*16+k*16+j] >> 10) & 0x1F;
                               fp16_mantissa += to_string((fp16_data[i*16+k*16+j] >> 15) & 1);
                               for(int m=9;m>=0;m--){
                                    fp16_mantissa += to_string((fp16_data[i*16+k*16+j] >> m) & 1);
                               }
                               mantissa2str = fp16_mantissa + mantissa2str;
                               fp16_mantissa = "";
                           }
                           //write mantissa into consecutive address, wait packing
                           for(int j=21; j>=0; j--){
                               string a = mantissa2str.substr(8*j,8);
                               dst_data[dst_data_size] = BinToDec(a);
                               dst_data_size += 1;
                               mantissa2str.erase(8*j,8);
                           }

                           str = is_full.substr(31-(i+k),1);
                           if(str == "0"){
                               for(int j=0; j<4; j++){
                                   dst_data[dst_data_size] = raw_strb[(i+k)*4+j];
                                   dst_data_size += 1;
                               }
                           }
                       }
                       uncmp_data_desc->data_size = 32;
                       uncmp_data_desc->data_type = data_type;
                       uncmp_data_desc->data = uncmp_data;
                       cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict); 

                       per_data_packet = cmp_data_desc->data;
                       per_packet_size = cmp_data_desc->data_size;
                       for(int k=0; k<per_packet_size; k++){
                           dst_data[dst_data_size+k] = per_data_packet[k];
                       }
                       dst_data_size += per_packet_size;

                   } else {
                       for(int j=0; j<16; j++){
                            uncmp_data[j] = (fp16_data[i*16+j] >> 10) & 0x1F;
                            fp16_mantissa += to_string((fp16_data[i*16+j] >> 15) & 1);
                            for(int m=9;m>=0;m--){
                                fp16_mantissa += to_string((fp16_data[i*16+j] >> m) & 1);
                            }
                            mantissa2str = fp16_mantissa + mantissa2str;
                            fp16_mantissa = "";
                       }
                       //write mantissa into consecutive address, wait packing
                       for(int j=21; j>=0; j--){
                           string a = mantissa2str.substr(j*8,8);
                           dst_data[dst_data_size] = BinToDec(a);
                           dst_data_size += 1;
                           mantissa2str.erase(j*8,8);
                       }
                       str = is_full.substr(31-i,1);
                       if(str == "0"){
                           for(int j=0; j<4; j++){
                               dst_data[dst_data_size] = raw_strb[i*4+j];
                               dst_data_size += 1;
                           }
                       }
                       uncmp_data_desc->data_size = 16;
                       uncmp_data_desc->data_type = data_type;
                       uncmp_data_desc->data = uncmp_data;
                       cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict);

                       per_data_packet = cmp_data_desc->data;
                       per_packet_size = cmp_data_desc->data_size;
                       for(int k=0; k<per_packet_size; k++){
                           dst_data[dst_data_size+k] = per_data_packet[k];
                       }
                       dst_data_size += per_packet_size;
                   }
               }
           }
           
           header += DecToBin(null);
           dst_data_len = (dst_data_size%32) ? (dst_data_size/32 + 1) : dst_data_size/32;
           last_data_size = (dst_data_size%32) ? (dst_data_size%32) : 32;
           a = DecToBin(blen-1);
           while(a.length() < 8){
               a = "0" + a;
           }
           header += a;
           header += "010";
           dst_data[0] = BinToDec(header.substr(8));
           dst_data[1] = BinToDec(header.substr(0,8));
           for(int i=0; i<4; i++){
               dst_data[i+2] = full_strb[i];
           }
        }
        else if(data_type == BF16){
          //printf("=========we get BF16 data=========\n");
          for(int i=3; i>=0; i--){
              a= DecToBin(full_strb[i]);
              while(a.length() < 8){
                  a = "0" + a;
              }
              is_full += a;
          }
          
          for(int i=0; i<blen; i+=2){ 
              if(i==0)
                  whether_init = 1; //only the first transfer use init_dict
              else
                  whether_init = 0;
              //extract expontent and mantissa
              if(blen%2 == 0){ 
                  for(int k=0; k<2; k++){
                      for(int j=0; j<16; j++){
                          uncmp_data[k*16+j] = (bf16_data[i*16+k*16+j] >> 7) & 0xFF;
                          mantissa2str += to_string((bf16_data[i*16+k*16+j] >> 15) & 1);
                          for(int m=6;m>=0;m--){
                              mantissa2str += to_string((bf16_data[i*16+k*16+j] >> m) & 1);
                          }
                      }
                      //write mantissa into consecutive address, wait packing
                      for(int j=0; j<16; j++){//16 transfer x 8bit per transfer /8bit
                          string a = mantissa2str.substr(0,8);
                          dst_data[dst_data_size] = BinToDec(a);
                          dst_data_size += 1;
                          mantissa2str.erase(0,8);
                      }

                      str = is_full.substr(31-(i+k),1);
                      if(str == "0"){
                          for(int j=0; j<4; j++){
                              dst_data[dst_data_size] = raw_strb[(i+k)*4+j];
                              dst_data_size += 1;
                          }
                      }
                  }
                  uncmp_data_desc->data_size = 32;
                  uncmp_data_desc->data_type = data_type;
                  uncmp_data_desc->data = uncmp_data;
                  cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict);

                  per_data_packet = cmp_data_desc->data;
                  per_packet_size = cmp_data_desc->data_size;
                  for(int k=0; k<per_packet_size; k++){
                      dst_data[dst_data_size+k] = per_data_packet[k];
                  }
                  dst_data_size += per_packet_size;
              } else {
                  if((blen-i)>2){
                      for(int k=0; k<2; k++){
                          for(int j=0; j<16; j++){
                              uncmp_data[k*16+j] = (bf16_data[i*16+k*16+j] >> 7) & 0xFF;
                              mantissa2str += to_string((bf16_data[i*16+k*16+j] >> 15) & 1);
                              for(int m=6;m>=0;m--){
                                  mantissa2str += to_string((bf16_data[i*16+k*16+j] >> m) & 1);
                              }
                          }
                          //write mantissa into consecutive address, wait packing
                          for(int j=0; j<16; j++){
                              string a = mantissa2str.substr(0,8);
                              dst_data[dst_data_size] = BinToDec(a);
                              dst_data_size += 1;
                              mantissa2str.erase(0,8);
                          }

                          str = is_full.substr(31-(i+k),1);
                          if(str == "0"){
                              for(int j=0; j<4; j++){
                                  dst_data[dst_data_size] = raw_strb[(i+k)*4+j];
                                  dst_data_size += 1;
                              }
                          }
                      }
                      uncmp_data_desc->data_size = 32;
                      uncmp_data_desc->data_type = data_type;
                      uncmp_data_desc->data = uncmp_data;
                      cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict); 

                      per_data_packet = cmp_data_desc->data;
                      per_packet_size = cmp_data_desc->data_size;
                      for(int k=0; k<per_packet_size; k++){
                          dst_data[dst_data_size+k] = per_data_packet[k];
                      }
                      dst_data_size += per_packet_size;
                  } else {
                      for(int j=0; j<16; j++){
                          uncmp_data[j] = (bf16_data[i*16+j] >> 7) & 0xFF;
                          mantissa2str += to_string((bf16_data[i*16+j] >> 15) & 1);
                          for(int m=6;m>=0;m--){
                              mantissa2str += to_string((bf16_data[i*16+j] >> m) & 1);
                          }
                      }
                      //write mantissa into consecutive address, wait packing
                      for(int j=0; j<16; j++){
                          string a = mantissa2str.substr(0,8);
                          dst_data[dst_data_size] = BinToDec(a);
                          dst_data_size += 1;
                          mantissa2str.erase(0,8);
                      }

                      str = is_full.substr(31-i,1);
                      if(str == "0"){
                          for(int j=0; j<4; j++){
                              dst_data[dst_data_size] = raw_strb[i*4+j];
                              dst_data_size += 1;
                          }
                      }
                      uncmp_data_desc->data_size = 16;
                      uncmp_data_desc->data_type = data_type;
                      uncmp_data_desc->data = uncmp_data;
                      cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict);

                      per_data_packet = cmp_data_desc->data;
                      per_packet_size = cmp_data_desc->data_size;
                      for(int k=0; k<per_packet_size; k++){
                          dst_data[dst_data_size+k] = per_data_packet[k];
                      }
                      dst_data_size += per_packet_size;
                  }
              }
          }
          
          header += DecToBin(null);
          dst_data_len = (dst_data_size%32) ? (dst_data_size/32 + 1) : dst_data_size/32;
          last_data_size = (dst_data_size%32) ? (dst_data_size%32) : 32;
          a = DecToBin(blen-1);
          while(a.length() < 8){
              a = "0" + a;
          }
          header += a;
          header += "011";
          dst_data[0] = BinToDec(header.substr(8));
          dst_data[1] = BinToDec(header.substr(0,8));
          for(int i=0; i<4; i++){
              dst_data[i+2] = full_strb[i];
          }
        }
        else if(data_type == FP32){
            //printf("=========we get FP32 data=========\n");
            for(int i=3; i>=0; i--){
                a= DecToBin(full_strb[i]);
                while(a.length() < 8){
                    a = "0" + a;
                }
                is_full += a;
            }
            for(int i=0; i<blen; i+=4){ 
                if(i==0)
                   whether_init = 1; //only the first transfer use init_dict
                else
                   whether_init = 0;
                //extract expontent and mantissa
                if(blen%4 == 0){
                    for(int k=0; k<4; k++){
                        for(int j=0; j<8; j++){
                            uncmp_data[k*8+j] = (fp32_data[i*8+k*8+j] >> 23) & 0xFF;
                            for(int m=7;m>=0;m--){
                                mantissa2str += to_string((fp32_data[i*8+k*8+j] >> m) & 1);
                            }
                            for(int m=15;m>=8;m--){
                                mantissa2str += to_string((fp32_data[i*8+k*8+j] >> m) & 1);
                            }
                            mantissa2str += to_string((fp32_data[i*8+k*8+j] >> 31) & 1);
                            for(int m=22;m>=16;m--){
                                mantissa2str += to_string((fp32_data[i*8+k*8+j] >> m) & 1);
                            }
                        }
                        //write mantissa into consecutive address, wait packing
                        for(int j=0; j<24; j++){//8 transfer x 24bit per transfer /8bit
                            string a = mantissa2str.substr(0,8);
                            dst_data[dst_data_size] = BinToDec(a);
                            dst_data_size += 1;
                            mantissa2str.erase(0,8);
                        }

                        str = is_full.substr(31-(i+k),1);
                        if(str == "0"){
                            for(int j=0; j<4; j++){
                                dst_data[dst_data_size] = raw_strb[(i+k)*4+j];
                                dst_data_size += 1;
                            }
                        }
                    }
                    uncmp_data_desc->data_size = 32;
                    uncmp_data_desc->data_type = data_type;
                    uncmp_data_desc->data = uncmp_data;
                    cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict);

                    per_data_packet = cmp_data_desc->data;
                    per_packet_size = cmp_data_desc->data_size;
                    for(int k=0; k<per_packet_size; k++){
                        dst_data[dst_data_size+k] = per_data_packet[k];
                    }
                    dst_data_size += per_packet_size;
                } else {
                    if((blen-i)>4){
                        for(int k=0; k<4; k++){
                            for(int j=0; j<8; j++){
                                uncmp_data[k*8+j] = (fp32_data[i*8+k*8+j] >> 23) & 0xFF;
                                for(int m=7;m>=0;m--){
                                    mantissa2str += to_string((fp32_data[i*8+k*8+j] >> m) & 1);
                                }
                                for(int m=15;m>=8;m--){
                                    mantissa2str += to_string((fp32_data[i*8+k*8+j] >> m) & 1);
                                }
                                mantissa2str += to_string((fp32_data[i*8+k*8+j] >> 31) & 1);
                                for(int m=22;m>=16;m--){
                                    mantissa2str += to_string((fp32_data[i*8+k*8+j] >> m) & 1);
                                }
                            }
                            //write mantissa into consecutive address, wait packing
                            for(int j=0; j<24; j++){
                                string a = mantissa2str.substr(0,8);
                                dst_data[dst_data_size] = BinToDec(a);
                                dst_data_size += 1;
                                mantissa2str.erase(0,8);
                            }

                            str = is_full.substr(31-(i+k),1);
                            if(str == "0"){
                                for(int j=0; j<4; j++){
                                    dst_data[dst_data_size] = raw_strb[(i+k)*4+j];
                                    dst_data_size += 1;
                                }
                            }
                        }
                        uncmp_data_desc->data_size = 32;
                        uncmp_data_desc->data_type = data_type;
                        uncmp_data_desc->data = uncmp_data;
                        cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict); 

                        per_data_packet = cmp_data_desc->data;
                        per_packet_size = cmp_data_desc->data_size;
                        for(int k=0; k<per_packet_size; k++){
                           dst_data[dst_data_size+k] = per_data_packet[k];
                        }
                        dst_data_size += per_packet_size;
                    } else {
                        for(int k=0; k<(blen-i); k++){
                            for(int j=0; j<8; j++){
                                uncmp_data[k*8+j] = (fp32_data[i*8+k*8+j] >> 23) & 0xFF;
                                for(int m=7;m>=0;m--){
                                    mantissa2str += to_string((fp32_data[i*8+k*8+j] >> m) & 1);
                                }
                                for(int m=15;m>=8;m--){
                                    mantissa2str += to_string((fp32_data[i*8+k*8+j] >> m) & 1);
                                }
                                mantissa2str += to_string((fp32_data[i*8+k*8+j] >> 31) & 1);
                                for(int m=22;m>=16;m--){
                                    mantissa2str += to_string((fp32_data[i*8+k*8+j] >> m) & 1);
                                }
                            }
                            //write mantissa into consecutive address, wait packing
                            for(int j=0; j<24; j++){
                                string a = mantissa2str.substr(0,8);
                                dst_data[dst_data_size] = BinToDec(a);
                                dst_data_size += 1;
                                mantissa2str.erase(0,8);
                            }

                            str = is_full.substr(31-(i+k),1);
                            if(str == "0"){
                                for(int j=0; j<4; j++){
                                    dst_data[dst_data_size] = raw_strb[(i+k)*4+j];
                                    dst_data_size += 1;
                                }
                            }
                        }
                        uncmp_data_desc->data_size = (blen-i)*8;
                        uncmp_data_desc->data_type = data_type;
                        uncmp_data_desc->data = uncmp_data;
                        cmp_data_desc = DynDict_compression(dyn_dict, uncmp_data_desc, whether_init, init_dict);

                        per_data_packet = cmp_data_desc->data;
                        per_packet_size = cmp_data_desc->data_size;
                        for(int k=0; k<per_packet_size; k++){
                           dst_data[dst_data_size+k] = per_data_packet[k];
                        }
                        dst_data_size += per_packet_size;
                    }
                }
            }
            header += DecToBin(null);
            dst_data_len = (dst_data_size%32) ? (dst_data_size/32 + 1) : dst_data_size/32;
            last_data_size = (dst_data_size%32) ? (dst_data_size%32) : 32;
            a = DecToBin(blen-1);
            while(a.length() < 8){
                a = "0" + a;
            }
            header += a;
            header += "100";
            dst_data[0] = BinToDec(header.substr(8));
            dst_data[1] = BinToDec(header.substr(0,8));
            for(int i=0; i<4; i++){
                dst_data[i+2] = full_strb[i];
            }
        }
    }
    delete dyn_dict;
    delete[] uncmp_data;
    delete uncmp_data_desc;
    delete cmp_data_desc;
    // print dst_data
    //printf("we get return dst_data!!!!!!!!!!!!dst_data_size is:%d\n",dst_data_size);
    dst_data_desc->dst_data = dst_data;
    dst_data_desc->dst_data_len = dst_data_len;
    dst_data_desc->dst_data_size = dst_data_size;
    dst_data_desc->last_data_size = last_data_size;
    
    return dst_data_desc;
}

decmp_dst_data_desc* dpi_nnc::nnc_decompression(uint8_t* src_data, uint8_t* init_dict){
    DynDict* dyn_dict = new DynDict(); 
    uint8_t* uncmp_data;
    uint8_t* raw_strb = new uint8_t[128];
    uint8_t* decmp_data = new uint8_t[1024]();
    uint8_t* decmp_strb = new uint8_t[128]();
    uint8_t* mantissa_array = new uint8_t[96];
    decmp_dst_data_desc* decmp_data_desc = new decmp_dst_data_desc();
    string cmp_data;
    string a;
    string b;
    string header;
    string str;
    string misc;
    string whole_mantissa;
    string per_mantissa;
    string sign;
    string exponent;
    string per_data;
    uint8_t whether_init;
    uint8_t cmp_data_size;
    uint32_t read_size = 6;
    uint8_t strb_size = 0;
    uint32_t decmp_data_size = 0;
    uint8_t decmp_strb_size = 0;
    uint8_t mantissa_size = 0;

    a = DecToBin(src_data[1]);
    while(a.length() < 8){
        a = "0" + a;
    }
    b = DecToBin(src_data[0]);
    while(b.length() < 8){
        b = "0" + b;
    }
    header = a+b;
    uint8_t data_type = BinToDec(header.substr(13,3));
    uint8_t blen = BinToDec(header.substr(5,8)) + 1;
    uint8_t null = BinToDec(header.substr(4,1));
    //printf("we get data_type is:%d\n", data_type);
    //printf("we get burst length is:%d\n", blen);

    string full_strb = "";
    for(int i=0; i<4; i++){
        b = DecToBin(src_data[i+2]);
        while(b.length() < 8){
            b = "0" + b;
        }
        full_strb = b + full_strb;
    }
    if(null == 1){
        //printf("now we get NULL data\n");
        for(int i=0; i<blen; i++){
            str = full_strb.substr(31-i,1);
            for(int i=0; i<4; i++){
                if(str == "0"){
                    decmp_strb[decmp_strb_size] = src_data[read_size];
                    read_size += 1;
                    decmp_strb_size +=1;
                }
                else{ 
                    decmp_strb[decmp_strb_size] = 0xFF;
                    decmp_strb_size +=1;
                }
            }
            for(int j=0; j<32; j++){
                decmp_data[decmp_data_size] = 0;
                decmp_data_size += 1;
            }
        }

    }
    else if(data_type == 0){
        //printf("now we get INT8\n");
        for(int i=0; i<blen; i++){
            if(i==0)
                whether_init = 1;
            else
                whether_init = 0;
            str = full_strb.substr(31-i,1);
            for(int i=0; i<4; i++){
                if(str == "0"){
                    raw_strb[strb_size] = src_data[read_size];
                    read_size += 1;
                }
                else{ 
                    raw_strb[strb_size] = 0xFF;
                }
                strb_size += 1;
            }
            strb_size = 0;
            misc = DecToBin(src_data[read_size]);
            read_size += 1;
            while(misc.length()<8){
                misc = "0" + misc;    
            }
            cmp_data = misc.substr(0,2);
            cmp_data_size = BinToDec(misc.substr(2,6));
            
            for(int i=0; i<(cmp_data_size-1); i++){
                a = DecToBin(src_data[read_size]);
                while(a.length() < 8){
                    a = "0" + a; 
                }
                cmp_data = a + cmp_data;
                read_size += 1;
            }
            reverse(cmp_data.begin(), cmp_data.end());
            uint8_t dst_data_num = 32;
            uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
            for(int j=0; j<32; j++){
                decmp_data[decmp_data_size+j] = uncmp_data[j];
            }
            delete[] uncmp_data;
            decmp_data_size += 32; 
            
            for(int k=0; k<4; k++){
                decmp_strb[decmp_strb_size+k] = raw_strb[k];
            }
            decmp_strb_size += 4;
        }
    }
    else if(data_type == 1){
        //printf("now we get FP8\n");
        for(int i=0; i<blen; i++){
            if(i==0)
                whether_init = 1;
            else
                whether_init = 0;
            for(int j=0; j<16; j++){
                mantissa_array[mantissa_size] = src_data[read_size];
                read_size += 1;
                mantissa_size += 1;
            }
            str = full_strb.substr(31-i,1);
            for(int i=0; i<4; i++){
                if(str == "0"){
                    raw_strb[strb_size] = src_data[read_size];
                    read_size += 1;
                }
                else{ 
                    raw_strb[strb_size] = 0xFF;
                }
                strb_size += 1;
            }
            strb_size = 0;
            mantissa_size = 0;
            misc = DecToBin(src_data[read_size]);
            read_size += 1;
            while(misc.length()<8){
                misc = "0" + misc;    
            }
            cmp_data = misc.substr(0,2);
            cmp_data_size = BinToDec(misc.substr(2,6));
            
            for(int i=0; i<(cmp_data_size-1); i++){
                a = DecToBin(src_data[read_size]);
                while(a.length() < 8){
                    a = "0" + a; 
                }
                cmp_data = a + cmp_data;
                read_size += 1;
            }
            reverse(cmp_data.begin(), cmp_data.end());
            uint8_t dst_data_num = 32;
            uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
            //data rebuild
            for(int i=0; i<16; i++){
                b = DecToBin(mantissa_array[i]);
                while(b.length() < 8){
                    b = "0" + b; 
                }
                for(int j=0; j<2; j++){
                    sign = b.substr(4*(1-j),1);
                    per_mantissa = b.substr(4*(1-j)+1,3);
                    exponent = DecToBin(uncmp_data[i*2+j]);
                    while(exponent.length() < 4){
                        exponent = "0" + exponent; 
                    }
                    per_data = sign + exponent + per_mantissa;
                    decmp_data[decmp_data_size+i*2+j] = BinToDec(per_data);
                    b.erase(4*(1-j),4);
                }
            }
            delete[] uncmp_data;
            decmp_data_size += 32; 
            for(int k=0; k<4; k++){
                decmp_strb[decmp_strb_size+k] = raw_strb[k];
            }
            decmp_strb_size += 4;
        }
    }
    else if(data_type == 2){
        //printf("now we get FP16\n");
        for(int i=0; i<blen; i+=2){
            if(i==0)
                whether_init = 1;
            else
                whether_init = 0;
            if(blen%2 == 0){
                for(int j=0; j<2; j++){
                    for(int k=0; k<22; k++){
                        mantissa_array[mantissa_size] = src_data[read_size];
                        read_size += 1;
                        mantissa_size += 1;
                    }
                    
                    str = full_strb.substr(31-(i+j),1);
                    for(int i=0; i<4; i++){
                        if(str == "0"){
                            raw_strb[strb_size] = src_data[read_size];
                            read_size += 1;
                        }
                        else{ 
                            raw_strb[strb_size] = 0xFF;
                        }
                        strb_size += 1;
                    }
                }
                strb_size = 0;
                mantissa_size = 0;
                misc = DecToBin(src_data[read_size]);
                read_size += 1;
                while(misc.length()<8){
                    misc = "0" + misc;    
                }
                cmp_data = misc.substr(0,2);
                cmp_data_size = BinToDec(misc.substr(2,6));
                for(int i=0; i<(cmp_data_size-1); i++){
                    a = DecToBin(src_data[read_size]);
                    while(a.length() < 8){
                        a = "0" + a; 
                    }
                    cmp_data = a + cmp_data;
                    read_size += 1;
                }
                reverse(cmp_data.begin(), cmp_data.end());
                uint8_t dst_data_num = 32;
                uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
                //data rebuild
                whole_mantissa = "";
                for(int i=0; i<44; i++){
                    b = DecToBin(mantissa_array[i]);
                    while(b.length() < 8){
                        b = "0" + b; 
                    }
                    whole_mantissa = b + whole_mantissa;
                }

                for(int i=0; i<32; i++){
                    per_mantissa = whole_mantissa.substr((31-i)*11,11);
                    sign = per_mantissa.substr(0,1);
                    per_mantissa.erase(0,1);

                    exponent = DecToBin(uncmp_data[i]);
                    while(exponent.length() < 5){
                        exponent = "0" + exponent; 
                    }
                    per_data = sign + exponent + per_mantissa;

                    for(int k=0; k<2; k++){
                        decmp_data[decmp_data_size+i*2+k] = BinToDec(per_data.substr((1-k)*8,8));
                    }

                }
                delete[] uncmp_data;
                decmp_data_size += 64; 
                for(int k=0; k<8; k++){
                    decmp_strb[decmp_strb_size+k] = raw_strb[k];
                }
                decmp_strb_size += 8;
            }
            else{
                if((blen-i)>2){
                    for(int j=0; j<2; j++){
                        for(int k=0; k<22; k++){
                            mantissa_array[mantissa_size] = src_data[read_size];
                            read_size += 1;
                            mantissa_size += 1;
                        }
                    
                        str = full_strb.substr(31-(i+j),1);
                        for(int i=0; i<4; i++){
                            if(str == "0"){
                                raw_strb[strb_size] = src_data[read_size];
                                read_size += 1;
                            }
                            else{ 
                                raw_strb[strb_size] = 0xFF;
                            }
                            strb_size += 1;
                        }
                    }
                    strb_size = 0;
                    mantissa_size = 0;
                    misc = DecToBin(src_data[read_size]);
                    read_size += 1;
                    while(misc.length()<8){
                        misc = "0" + misc;    
                    }
                    cmp_data = misc.substr(0,2);
                    cmp_data_size = BinToDec(misc.substr(2,6));
                    for(int i=0; i<(cmp_data_size-1); i++){
                        a = DecToBin(src_data[read_size]);
                        while(a.length() < 8){
                            a = "0" + a; 
                        }
                        cmp_data = a + cmp_data;
                        read_size += 1;
                    }
                    reverse(cmp_data.begin(), cmp_data.end());
                    uint8_t dst_data_num = 32;
                    uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
                    //data rebuild
                    whole_mantissa = "";
                    for(int i=0; i<44; i++){
                        b = DecToBin(mantissa_array[i]);
                        while(b.length() < 8){
                            b = "0" + b; 
                        }
                        whole_mantissa = b + whole_mantissa;
                    }

                    for(int i=0; i<32; i++){
                        per_mantissa = whole_mantissa.substr((31-i)*11,11);
                        sign = per_mantissa.substr(0,1);
                        per_mantissa.erase(0,1);

                        exponent = DecToBin(uncmp_data[i]);
                        while(exponent.length() < 5){
                            exponent = "0" + exponent; 
                        }
                        per_data = sign + exponent + per_mantissa;
                        for(int k=0; k<2; k++){
                            decmp_data[decmp_data_size+i*2+k] = BinToDec(per_data.substr((1-k)*8,8));
                        }

                    }
                    delete[] uncmp_data;
                    decmp_data_size += 64; 
                    for(int k=0; k<8; k++){
                        decmp_strb[decmp_strb_size+k] = raw_strb[k];
                    }
                    decmp_strb_size += 8;
                }
                else{
                    for(int k=0; k<22; k++){
                        mantissa_array[mantissa_size] = src_data[read_size];
                        read_size += 1;
                        mantissa_size += 1;
                    }
                    
                    str = full_strb.substr(31-i,1);
                    for(int i=0; i<4; i++){
                        if(str == "0"){
                            raw_strb[strb_size] = src_data[read_size];
                            read_size += 1;
                        }
                        else{ 
                            raw_strb[strb_size] = 0xFF;
                        }
                        strb_size += 1;
                    }
                    strb_size = 0;
                    mantissa_size = 0;
                    misc = DecToBin(src_data[read_size]);
                    read_size += 1;
                    while(misc.length()<8){
                        misc = "0" + misc;    
                    }
                    cmp_data = misc.substr(0,2);
                    cmp_data_size = BinToDec(misc.substr(2,6));
                    for(int i=0; i<(cmp_data_size-1); i++){
                        a = DecToBin(src_data[read_size]);
                        while(a.length() < 8){
                            a = "0" + a; 
                        }
                        cmp_data = a + cmp_data;
                        read_size += 1;
                    }
                    reverse(cmp_data.begin(), cmp_data.end());
                    uint8_t dst_data_num = 16;
                    uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
                    //data rebuild
                    whole_mantissa = "";
                    for(int i=0; i<22; i++){
                        b = DecToBin(mantissa_array[i]);
                        while(b.length() < 8){
                            b = "0" + b; 
                        }
                        whole_mantissa = b + whole_mantissa;
                    }

                    for(int i=0; i<16; i++){
                        per_mantissa = whole_mantissa.substr((15-i)*11,11);
                        sign = per_mantissa.substr(0,1);
                        per_mantissa.erase(0,1);

                        exponent = DecToBin(uncmp_data[i]);
                        while(exponent.length() < 5){
                            exponent = "0" + exponent; 
                        }
                        per_data = sign + exponent + per_mantissa;

                        for(int k=0; k<2; k++){
                            decmp_data[decmp_data_size+i*2+k] = BinToDec(per_data.substr((1-k)*8,8));
                        }

                    }
                    delete[] uncmp_data;
                    decmp_data_size += 32; 
                    for(int k=0; k<4; k++){
                        decmp_strb[decmp_strb_size+k] = raw_strb[k];
                    }
                    decmp_strb_size += 4;
                }
            }
        }
    }
    else if(data_type == 3){
        //printf("now we get BF16\n");
        for(int i=0; i<blen; i+=2){
            if(i==0)
                whether_init = 1;
            else
                whether_init = 0;
            if(blen%2 == 0){
                for(int j=0; j<2; j++){
                    for(int i=0; i<16; i++){
                        mantissa_array[mantissa_size] = src_data[read_size];
                        read_size += 1;
                        mantissa_size += 1;
                    }
                    str = full_strb.substr(31-(i+j),1);
                    for(int i=0; i<4; i++){
                        if(str == "0"){
                            raw_strb[strb_size] = src_data[read_size];
                            read_size += 1;
                        }
                        else{ 
                            raw_strb[strb_size] = 0xFF;
                        }
                        strb_size += 1;
                    }
                }
                strb_size = 0;
                mantissa_size = 0;
                misc = DecToBin(src_data[read_size]);
                read_size += 1;
                while(misc.length()<8){
                    misc = "0" + misc;    
                }
                cmp_data = misc.substr(0,2);
                cmp_data_size = BinToDec(misc.substr(2,6));
                for(int i=0; i<(cmp_data_size-1); i++){
                    a = DecToBin(src_data[read_size]);
                    while(a.length() < 8){
                        a = "0" + a; 
                    }
                    cmp_data = a + cmp_data;
                    read_size += 1;
                }
                reverse(cmp_data.begin(), cmp_data.end());
                uint8_t dst_data_num = 32;
                uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
                //data rebuild
                for(int i=0; i<32; i++){
                    per_mantissa= DecToBin(mantissa_array[i]);
                    while(per_mantissa.length() < 8){
                        per_mantissa = "0" + per_mantissa; 
                    }
                    sign = per_mantissa.substr(0,1);
                    per_mantissa.erase(0,1);

                    exponent = DecToBin(uncmp_data[i]);
                    while(exponent.length() < 8){
                        exponent = "0" + exponent; 
                    }
                    per_data = sign + exponent + per_mantissa;
                    per_mantissa = "";

                    for(int k=0; k<2; k++){
                        decmp_data[decmp_data_size+i*2+k] = BinToDec(per_data.substr((1-k)*8,8));
                    }

                }
                delete[] uncmp_data;
                decmp_data_size += 64; 
                for(int k=0; k<8; k++){
                    decmp_strb[decmp_strb_size+k] = raw_strb[k];
                }
                decmp_strb_size += 8;
            } 
            else{
                if((blen-i)>2){
                    for(int j=0; j<2; j++){
                        for(int i=0; i<16; i++){
                            mantissa_array[mantissa_size] = src_data[read_size];
                            read_size += 1;
                            mantissa_size += 1;
                        }
                        str = full_strb.substr(31-(i+j),1);
                        for(int i=0; i<4; i++){
                            if(str == "0"){
                                raw_strb[strb_size] = src_data[read_size];
                                read_size += 1;
                            }
                            else{ 
                                raw_strb[strb_size] = 0xFF;
                            }
                            strb_size += 1;
                        }
                    }
                    strb_size = 0;
                    mantissa_size = 0;
                    misc = DecToBin(src_data[read_size]);
                    read_size += 1;
                    while(misc.length()<8){
                        misc = "0" + misc;    
                    }
                    cmp_data = misc.substr(0,2);
                    cmp_data_size = BinToDec(misc.substr(2,6));
                    for(int i=0; i<(cmp_data_size-1); i++){
                        a = DecToBin(src_data[read_size]);
                        while(a.length() < 8){
                            a = "0" + a; 
                        }
                        cmp_data = a + cmp_data;
                        read_size += 1;
                    }
                    reverse(cmp_data.begin(), cmp_data.end());
                    uint8_t dst_data_num = 32;
                    uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
                    //data rebuild
                    for(int i=0; i<32; i++){
                        per_mantissa= DecToBin(mantissa_array[i]);
                        while(per_mantissa.length() < 8){
                            per_mantissa = "0" + per_mantissa; 
                        }
                        sign = per_mantissa.substr(0,1);
                        per_mantissa.erase(0,1);

                        exponent = DecToBin(uncmp_data[i]);
                        while(exponent.length() < 8){
                            exponent = "0" + exponent; 
                        }
                        per_data = sign + exponent + per_mantissa;
                        per_mantissa = "";

                        for(int k=0; k<2; k++){
                            decmp_data[decmp_data_size+i*2+k] = BinToDec(per_data.substr((1-k)*8,8));
                        }

                    }
                    delete[] uncmp_data;
                    decmp_data_size += 64; 
                    for(int k=0; k<8; k++){
                        decmp_strb[decmp_strb_size+k] = raw_strb[k];
                    }
                    decmp_strb_size += 8;
                }
                else {
                    for(int j=0; j<16; j++){
                        mantissa_array[mantissa_size] = src_data[read_size]; 
                        read_size += 1;
                        mantissa_size += 1;
                    }
                    str = full_strb.substr(31-i,1);
                    for(int i=0; i<4; i++){
                        if(str == "0"){
                            raw_strb[strb_size] = src_data[read_size];
                            read_size += 1;
                        }
                        else{ 
                            raw_strb[strb_size] = 0xFF;
                        }
                        strb_size += 1;
                    }
                    strb_size = 0;
                    mantissa_size = 0;
                    misc = DecToBin(src_data[read_size]);
                    read_size += 1;
                    while(misc.length()<8){
                        misc = "0" + misc;    
                    }
                    cmp_data = misc.substr(0,2);
                    cmp_data_size = BinToDec(misc.substr(2,6));
                    for(int i=0; i<(cmp_data_size-1); i++){
                        a = DecToBin(src_data[read_size]);
                        while(a.length() < 8){
                            a = "0" + a; 
                        }
                        cmp_data = a + cmp_data;
                        read_size += 1;
                    }
                    reverse(cmp_data.begin(), cmp_data.end());
                    uint8_t dst_data_num = 16;
                    uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
                    //data rebuild
                    for(int i=0; i<16; i++){
                        per_mantissa= DecToBin(mantissa_array[i]);
                        while(per_mantissa.length() < 8){
                            per_mantissa = "0" + per_mantissa; 
                        }
                        sign = per_mantissa.substr(0,1);
                        per_mantissa.erase(0,1);

                        exponent = DecToBin(uncmp_data[i]);
                        while(exponent.length() < 8){
                            exponent = "0" + exponent; 
                        }
                        per_data = sign + exponent + per_mantissa;
                        per_mantissa = "";

                        for(int k=0; k<2; k++){
                            decmp_data[decmp_data_size+i*2+k] = BinToDec(per_data.substr((1-k)*8,8));
                        }

                    }
                    delete[] uncmp_data;
                    decmp_data_size += 32; 
                    for(int k=0; k<4; k++){
                        decmp_strb[decmp_strb_size+k] = raw_strb[k];
                    }
                    decmp_strb_size += 4;
                }
            }
        }
    }
    else if(data_type == 4){
        //printf("now we get FP32\n");
        for(int i=0; i<blen; i+=4){
            if(i==0)
                whether_init = 1;
            else
                whether_init = 0;
            if(blen%4 == 0){
                for(int j=0; j<4; j++){
                    for(int i=0; i<24; i++){
                        mantissa_array[mantissa_size] = src_data[read_size];
                        read_size += 1;
                        mantissa_size += 1;
                    }
                    str = full_strb.substr(31-(i+j),1);
                    for(int i=0; i<4; i++){
                        if(str == "0"){
                            raw_strb[strb_size] = src_data[read_size];
                            read_size += 1;
                        }
                        else{ 
                            raw_strb[strb_size] = 0xFF;
                        }
                        strb_size += 1;
                    }
                }
                strb_size = 0;
                mantissa_size = 0;
                misc = DecToBin(src_data[read_size]);
                read_size += 1;
                while(misc.length()<8){
                    misc = "0" + misc;    
                }
                cmp_data = misc.substr(0,2);
                cmp_data_size = BinToDec(misc.substr(2,6));
                for(int i=0; i<(cmp_data_size-1); i++){
                    a = DecToBin(src_data[read_size]);
                    while(a.length() < 8){
                        a = "0" + a; 
                    }
                    cmp_data = a + cmp_data;
                    read_size += 1;
                }
                reverse(cmp_data.begin(), cmp_data.end());
                uint8_t dst_data_num = 32;
                uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
                //data rebuild
                for(int i=0; i<32; i++){
                    for(int j=0; j<3; j++){
                        b = DecToBin(mantissa_array[i*3+j]);
                        while(b.length() < 8){
                            b = "0" + b; 
                        }
                        per_mantissa = b + per_mantissa;
                    }
                    sign = per_mantissa.substr(0,1);
                    per_mantissa.erase(0,1);

                    exponent = DecToBin(uncmp_data[i]);
                    while(exponent.length() < 8){
                        exponent = "0" + exponent; 
                    }
                    per_data = sign + exponent + per_mantissa;
                    per_mantissa = "";

                    for(int k=0; k<4; k++){
                        decmp_data[decmp_data_size+i*4+k] = BinToDec(per_data.substr((3-k)*8,8));
                    }

                }
                delete[] uncmp_data;
                decmp_data_size += 128; 
                for(int k=0; k<16; k++){
                    decmp_strb[decmp_strb_size+k] = raw_strb[k];
                }
                decmp_strb_size += 16;
            } 
            else{
                if((blen-i)>4){
                    for(int j=0; j<4; j++){
                        for(int i=0; i<24; i++){
                            mantissa_array[mantissa_size] = src_data[read_size];
                            read_size += 1;
                            mantissa_size += 1;
                        }
                        str = full_strb.substr(31-(i+j),1);
                        for(int i=0; i<4; i++){
                            if(str == "0"){
                                raw_strb[strb_size] = src_data[read_size];
                                read_size += 1;
                            }
                            else{ 
                                raw_strb[strb_size] = 0xFF;
                            }
                            strb_size += 1;
                        }
                    }
                    strb_size = 0;
                    mantissa_size = 0;
                    misc = DecToBin(src_data[read_size]);
                    read_size += 1;
                    while(misc.length()<8){
                        misc = "0" + misc;    
                    }
                    cmp_data = misc.substr(0,2);
                    cmp_data_size = BinToDec(misc.substr(2,6));
                    for(int i=0; i<(cmp_data_size-1); i++){
                        a = DecToBin(src_data[read_size]);
                        while(a.length() < 8){
                            a = "0" + a; 
                        }
                        cmp_data = a + cmp_data;
                        read_size += 1;
                    }
                    reverse(cmp_data.begin(), cmp_data.end());
                    uint8_t dst_data_num = 32;
                    uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
                    //data rebuild
                    for(int i=0; i<32; i++){
                        for(int j=0; j<3; j++){
                            b = DecToBin(mantissa_array[i*3+j]);
                            while(b.length() < 8){
                                b = "0" + b; 
                            }
                            per_mantissa = b + per_mantissa;
                        }
                        sign = per_mantissa.substr(0,1);
                        per_mantissa.erase(0,1);
                        exponent = DecToBin(uncmp_data[i]);
                        while(exponent.length() < 8){
                            exponent = "0" + exponent; 
                        }

                        per_data = sign + exponent + per_mantissa;
                        per_mantissa = "";
                        for(int k=0; k<4; k++){
                            decmp_data[decmp_data_size+i*4+k] = BinToDec(per_data.substr((3-k)*8,8));
                        }
                    }
                    delete[] uncmp_data;
                    decmp_data_size += 128; 
                    for(int k=0; k<16; k++){
                        decmp_strb[decmp_strb_size+k] = raw_strb[k];
                    }
                    decmp_strb_size += 16;
                }
                else {
                    for(int j=0; j<(blen-i); j++){
                        for(int i=0; i<24; i++){
                            mantissa_array[mantissa_size] = src_data[read_size]; 
                            read_size += 1;
                            mantissa_size += 1;
                        }
                        str = full_strb.substr(31-(i+j),1);
                        for(int i=0; i<4; i++){
                            if(str == "0"){
                                raw_strb[strb_size] = src_data[read_size];
                                read_size += 1;
                            }
                            else{ 
                                raw_strb[strb_size] = 0xFF;
                            }
                            strb_size += 1;
                        }
                    }
                    strb_size = 0;
                    mantissa_size = 0;
                    misc = DecToBin(src_data[read_size]);
                    read_size += 1;
                    while(misc.length()<8){
                        misc = "0" + misc;    
                    }
                    cmp_data = misc.substr(0,2);
                    cmp_data_size = BinToDec(misc.substr(2,6));
                    for(int i=0; i<(cmp_data_size-1); i++){
                        a = DecToBin(src_data[read_size]);
                        while(a.length() < 8){
                            a = "0" + a; 
                        }
                        cmp_data = a + cmp_data;
                        read_size += 1;
                    }
                    reverse(cmp_data.begin(), cmp_data.end());
                    uint8_t dst_data_num = (blen-i)*8;
                    uncmp_data = DynDict_decompression(dyn_dict, data_type, cmp_data, dst_data_num, whether_init, init_dict);
                    //data rebuild
                    for(int i=0; i<dst_data_num; i++){
                        for(int j=0; j<3; j++){
                            b = DecToBin(mantissa_array[i*3+j]);
                            while(b.length() < 8){
                                b = "0" + b; 
                            }
                            per_mantissa = b + per_mantissa;
                        }
                        sign = per_mantissa.substr(0,1);
                        per_mantissa.erase(0,1);
                        exponent = DecToBin(uncmp_data[i]);
                        while(exponent.length() < 8){
                            exponent = "0" + exponent; 
                        }
                        per_data = sign + exponent + per_mantissa;
                        per_mantissa = "";

                        for(int k=0; k<4; k++){
                            decmp_data[decmp_data_size+i*4+k] = BinToDec(per_data.substr((3-k)*8,8));
                        }
                    }
                    delete[] uncmp_data;
                    decmp_data_size += dst_data_num*4; 
                    for(int k=0; k<dst_data_num/2; k++){
                        decmp_strb[decmp_strb_size+k] = raw_strb[k];
                    }
                    decmp_strb_size += dst_data_num/2;
                }
            }
        }
    }
    decmp_data_desc->data = decmp_data;
    decmp_data_desc->strb = decmp_strb;
    decmp_data_desc->len = blen;

    delete dyn_dict;
    delete[] raw_strb;
    return decmp_data_desc;
}

#endif  // HARDWARE_ESL_LIBRA_CMODEL_NNC_H_