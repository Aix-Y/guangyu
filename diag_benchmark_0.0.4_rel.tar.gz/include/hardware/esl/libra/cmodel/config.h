/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_ESL_LIBRA_CMODEL_CONFIG_H_
#define HARDWARE_ESL_LIBRA_CMODEL_CONFIG_H_

#include <assert.h>
#include <memory.h>
#include <stdint.h>
// #include <sys/io.h>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

// enum DATA_SYM_SIZE {
//    INT8 = 1,
//    INT16 = 2,
//    INT32 = 4,
//    INT64 = 8,
//    FP8 = 0,
//    FP16 = 2,
//    FP32 = 4,
//    FP64 = 8,
//    BF16 = 2,
//    TF32 = 4
//};

enum DATA_SYM_SIZE {
    SINT8  = 0,
    UINT8  = 1,
    SINT16 = 2,
    UINT16 = 3,
    SINT32 = 4,
    UINT32 = 5,
    SINT64 = 6,
    UINT64 = 7,
    FP8    = 8,
    FP16   = 9,
    BF16   = 10,
    TF16   = 11,
    FP32   = 12,
    TF32   = 13,
    F64    = 14
};

typedef struct src_data_info {
    uint8_t  data_size;
    uint8_t  data_type;
    uint8_t *data = NULL;
} data_desc;

typedef struct dst_data_describe {
    uint8_t *dst_data = NULL;
    uint8_t  dst_data_len;
    uint32_t dst_data_size;
    uint8_t  last_data_size;
} cmp_dst_data_desc;

typedef struct decmp_data_describe {
    uint8_t *data = NULL;
    uint8_t *strb = NULL;
    uint8_t  len;
} decmp_dst_data_desc;

void sim_assert(bool fail, string err_info);

uint8_t BinToDec(string str);

string BinToHex(string str);

string DecToBin(uint8_t dec);

#endif  // HARDWARE_ESL_LIBRA_CMODEL_CONFIG_H_
