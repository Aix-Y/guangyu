/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_ESL_LIBRA_CMODEL_NNC4EMU_H_
#define HARDWARE_ESL_LIBRA_CMODEL_NNC4EMU_H_
#include "hardware/esl/libra/cmodel/nnc.h"

extern "C" {
int nnc_compression_4emu(uint8_t* src_data, uint8_t* raw_strb, uint8_t data_type, uint8_t* init_dict, uint8_t blen, uint32_t & dst_data_size, uint8_t* dst_data)
{
    dpi_nnc dpi_nnc_inst;
    cmp_dst_data_desc* tmp_desc;
    
    uint8_t  full_strb_bit[32];
    uint8_t  full_strb_array[4];
    uint8_t* full_strb = full_strb_array;
    
    for(int i=0; i<32; i++){
        if(i<blen)
            full_strb_bit[i] = 1;
        else
            full_strb_bit[i] = 0;
    }
    for(int i=0; i<4; i++){
        full_strb_array[i] = 0;
    }
    
    for(int i=0; i<blen; i++){
        for(int j=0; j<4; j++){
            if(raw_strb[i*4+j] != 0xff)
                full_strb_bit[i] = 0;
        }
    }
    for(int k=0; k<32; k++){
        if(full_strb_bit[k] == 1){
            if(k<8)
                full_strb_array[0] = full_strb_array[0] | (1 << k);
            else if(k>=8 && k<16)
                full_strb_array[1] = full_strb_array[1] | (1 << (k-8));
            else if(k>=16 && k<24)
                full_strb_array[2] = full_strb_array[2] | (1 << (k-16));
            else
                full_strb_array[3] = full_strb_array[3] | (1 << (k-24));
        }
    }
    uint8_t null = 1;
    for(int i=0; i<(blen*32); i++){
        if(src_data[i] != 0)
            null = 0; 
    }
    tmp_desc = dpi_nnc_inst.nnc_compression(src_data, raw_strb, init_dict, blen, data_type, null, full_strb);
    for(int i=0;i<tmp_desc->dst_data_size;i++){
        dst_data[i] = tmp_desc->dst_data[i];
    }
    dst_data_size = tmp_desc->dst_data_size;
    delete[] tmp_desc->dst_data;
    delete tmp_desc;
    return 0;
}

//decmp_dst_data_desc* nnc_decompression_4emu(uint8_t* src_data, uint8_t* init_dict)
//{ 
//    dpi_nnc dpi_nnc_inst;
//    decmp_dst_data_desc* tmp_desc;
//    tmp_desc = dpi_nnc_inst.nnc_decompression(src_data, init_dict);
//    return tmp_desc; 
//}

}
#endif  // HARDWARE_ESL_LIBRA_CMODEL_NNC4EMU_H_