/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_NOC_SCORPIO_NOC_ERR_ECFCORE_H_
#define HARDWARE_NOC_SCORPIO_NOC_ERR_ECFCORE_H_

#include <memory>
#include <set>
#include <string>
#include "device/dtus/scorpio/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_error.h"

namespace efvf {
namespace hardware {
namespace noc {

class NocErrEcfCore : public NocErr {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocErrEcfCore(std::shared_ptr<spdlog::logger> logger) : NocErr(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocErrEcfCore() {}
    virtual bool Dump(NOC_Err_Info &err);
    virtual bool Clear();

 protected:
    virtual int    TriggerClr();
    virtual std::string DumpInitFlow();
    virtual std::string DumpTargetFlow();
    virtual uint32_t    DumpOffset();
    virtual uint32_t    DumpValid();

 private:
    typedef struct _ECF_Core_RouteId_t {
#if BYTE_ORDER == LITTLE_ENDIAN
        unsigned int SeqId : 9;
        unsigned int TargetSubRange : 4;
        unsigned int TargetFlow : 6;
        unsigned int InitFlow : 6;
#elif BYTE_ORDER == BIG_ENDIAN
        unsigned int InitFlow : 6;
        unsigned int TargetFlow : 6;
        unsigned int TargetSubRange : 4;
        unsigned int SeqId : 9;
#endif
    } ECF_Core_RouteId_t;

    typedef union {
        unsigned int       val : 25;
        ECF_Core_RouteId_t f;
    } ECF_Core_RouteId_u;

    const std::array<std::string, 256> NOCERR_ECFCORE_INIT_FLOW_ARRAY{{
        "rw_aasp_ecf_axi/I/0", "rw_aasplocal_ecf_axi/I/0", "rw_cbf0_ecf_axi/I/0",
        "rw_cbf10_ecf_axi/I/0", "rw_cbf11_ecf_axi/I/0", "rw_cbf12_ecf_axi/I/0",
        "rw_cbf13_ecf_axi/I/0", "rw_cbf14_ecf_axi/I/0", "rw_cbf15_ecf_axi/I/0",
        "rw_cbf1_ecf_axi/I/0", "rw_cbf2_ecf_axi/I/0", "rw_cbf3_ecf_axi/I/0",
        "rw_cbf4_ecf_axi/I/0", "rw_cbf5_ecf_axi/I/0", "rw_cbf6_ecf_axi/I/0",
        "rw_cbf7_ecf_axi/I/0", "rw_cbf8_ecf_axi/I/0", "rw_cbf9_ecf_axi/I/0",
        "rw_cdte_ecf_axi/I/0", "rw_cva_ecf_axi/I/0", "rw_dftentry0_ecf_axi/I/0",
        "rw_dftentry1_ecf_axi/I/0", "rw_dpf_ecf_axi/I/0", "rw_ecfcore_m_ecfio_axi/I/0",
        "rw_gmu_ecf_axi/I/0", "rw_mdf0_ecf_axi/I/0", "rw_mdf1_ecf_axi/I/0",
        "rw_sip0_ecf_axi/I/0", "rw_sip10_ecf_axi/I/0", "rw_sip11_ecf_axi/I/0",
        "rw_sip12_ecf_axi/I/0", "rw_sip13_ecf_axi/I/0", "rw_sip14_ecf_axi/I/0",
        "rw_sip15_ecf_axi/I/0", "rw_sip1_ecf_axi/I/0", "rw_sip2_ecf_axi/I/0",
        "rw_sip3_ecf_axi/I/0", "rw_sip4_ecf_axi/I/0", "rw_sip5_ecf_axi/I/0",
        "rw_sip6_ecf_axi/I/0", "rw_sip7_ecf_axi/I/0", "rw_sip8_ecf_axi/I/0",
        "rw_sip9_ecf_axi/I/0", "rw_sp_ecf_axi/I/0", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED",
    }};

    const std::array<std::string, 256> NOCERR_ECFCORE_TARGET_FLOW_ARRAY{{
        "ecf_edfcorer_axi/T/0", "ecf_edfcorew_axi/T/0", "ecfcore_s_service/T/0",
        "rw_ecf_aasp_axi/T/0", "rw_ecf_aasplocal_axi/T/0", "rw_ecf_cbf0_axi/T/0",
        "rw_ecf_cbf10_axi/T/0", "rw_ecf_cbf11_axi/T/0", "rw_ecf_cbf12_axi/T/0",
        "rw_ecf_cbf13_axi/T/0", "rw_ecf_cbf14_axi/T/0", "rw_ecf_cbf15_axi/T/0",
        "rw_ecf_cbf1_axi/T/0", "rw_ecf_cbf2_axi/T/0", "rw_ecf_cbf3_axi/T/0",
        "rw_ecf_cbf4_axi/T/0", "rw_ecf_cbf5_axi/T/0", "rw_ecf_cbf6_axi/T/0",
        "rw_ecf_cbf7_axi/T/0", "rw_ecf_cbf8_axi/T/0", "rw_ecf_cbf9_axi/T/0",
        "rw_ecf_cdte_axi/T/0", "rw_ecf_cva_axi/T/0", "rw_ecf_dpf_axi/T/0",
        "rw_ecf_gmu_axi/T/0", "rw_ecf_mdf0_axi/T/0", "rw_ecf_mdf1_axi/T/0",
        "rw_ecf_sip0_axi/T/0", "rw_ecf_sip10_axi/T/0", "rw_ecf_sip11_axi/T/0",
        "rw_ecf_sip12_axi/T/0", "rw_ecf_sip13_axi/T/0", "rw_ecf_sip14_axi/T/0",
        "rw_ecf_sip15_axi/T/0", "rw_ecf_sip1_axi/T/0", "rw_ecf_sip2_axi/T/0",
        "rw_ecf_sip3_axi/T/0", "rw_ecf_sip4_axi/T/0", "rw_ecf_sip5_axi/T/0",
        "rw_ecf_sip6_axi/T/0", "rw_ecf_sip7_axi/T/0", "rw_ecf_sip8_axi/T/0",
        "rw_ecf_sip9_axi/T/0", "rw_ecf_sp_axi/T/0", "rw_ecfcore_s_ecfio_axi/T/0", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED",
    }};
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_NOC_SCORPIO_NOC_ERR_ECFCORE_H_
