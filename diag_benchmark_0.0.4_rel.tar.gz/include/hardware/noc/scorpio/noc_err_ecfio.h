/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_NOC_SCORPIO_NOC_ERR_ECFIO_H_
#define HARDWARE_NOC_SCORPIO_NOC_ERR_ECFIO_H_

#include <memory>
#include <set>
#include <string>
#include "device/dtus/scorpio/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_error.h"

namespace efvf {
namespace hardware {
namespace noc {

class NocErrEcfIO : public NocErr {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocErrEcfIO(std::shared_ptr<spdlog::logger> logger) : NocErr(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocErrEcfIO() {}
    virtual bool Dump(NOC_Err_Info &err);
    virtual bool Clear();

 protected:
    virtual int    TriggerClr();
    virtual std::string DumpInitFlow();
    virtual std::string DumpTargetFlow();
    virtual uint32_t    DumpOffset();
    virtual uint32_t    DumpValid();

 private:
    typedef struct _ECF_IO_RouteId_t {
#if BYTE_ORDER == LITTLE_ENDIAN
        unsigned int SeqId : 9;
        unsigned int TargetSubRange : 4;
        unsigned int TargetFlow : 4;
        unsigned int InitFlow : 3;
#elif BYTE_ORDER == BIG_ENDIAN
        unsigned int InitFlow : 3;
        unsigned int TargetFlow : 4;
        unsigned int TargetSubRange : 4;
        unsigned int SeqId : 9;
#endif
    } ECF_IO_RouteId_t;

    typedef union {
        unsigned int     val : 20;
        ECF_IO_RouteId_t f;
    } ECF_IO_RouteId_u;

    const std::array<std::string, 256> NOCERR_ECFIO_INIT_FLOW_ARRAY{{
        "rw_ap_ecf_axi/I/0", "rw_cdft_ecf_axi/I/0", "rw_ecfio_m_ecfcore_axi/I/0",
        "rw_odte_ecf_axi/I/0", "rw_pcie_ecf_axi/I/0", "rw_ssm_ecf_axi/I/0",
        "rw_vpp0_ecf_axi/I/0", "rw_vpp1_ecf_axi/I/0",
    }};

    const std::array<std::string, 256> NOCERR_ECFIO_TARGET_FLOW_ARRAY{{
        "ecf_edfior_axi/T/0", "ecf_edfiow_axi/T/0", "ecfio_s_service/T/0", "rw_ecf_ap_axi/T/0",
        "rw_ecf_cdft_axi/T/0", "rw_ecf_odte_axi/T/0", "rw_ecf_pcie_axi/T/0",
        "rw_ecf_ssm_axi/T/0", "rw_ecf_vpp0_axi/T/0", "rw_ecf_vpp1_axi/T/0",
        "rw_ecfio_s_ecfcore_axi/T/0", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED",
    }};
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_NOC_SCORPIO_NOC_ERR_ECFIO_H_
