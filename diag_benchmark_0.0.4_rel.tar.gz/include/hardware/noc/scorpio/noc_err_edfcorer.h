/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_NOC_SCORPIO_NOC_ERR_EDFCORER_H_
#define HARDWARE_NOC_SCORPIO_NOC_ERR_EDFCORER_H_

#include <memory>
#include <set>
#include <string>
#include "device/dtus/scorpio/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_error.h"

namespace efvf {
namespace hardware {
namespace noc {

class NocErrEdfCoreR : public NocErr {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocErrEdfCoreR(std::shared_ptr<spdlog::logger> logger) : NocErr(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocErrEdfCoreR() {}
    virtual bool Dump(NOC_Err_Info &err);
    virtual bool Clear();

 protected:
    virtual int    TriggerClr();
    virtual std::string DumpInitFlow();
    virtual std::string DumpTargetFlow();
    virtual uint32_t    DumpOffset();
    virtual uint32_t    DumpValid();

 private:
    typedef struct _EDF_CoreR_RouteId_t {
#if BYTE_ORDER == LITTLE_ENDIAN
        unsigned int SeqId : 10;
        unsigned int TargetSubRange : 2;
        unsigned int TargetFlow : 6;
        unsigned int InitFlow : 6;
#elif BYTE_ORDER == BIG_ENDIAN
        unsigned int InitFlow : 6;
        unsigned int TargetFlow : 6;
        unsigned int TargetSubRange : 2;
        unsigned int SeqId : 10;
#endif
    } EDF_CoreR_RouteId_t;

    typedef union {
        unsigned int        val : 24;
        EDF_CoreR_RouteId_t f;
    } EDF_CoreR_RouteId_u;

    const std::array<std::string, 256> NOCERR_EDFCORER_INIT_FLOW_ARRAY{{
        "ecf_edfcorer_axi/I/0", "ro_aasp_edf_axi/I/0", "ro_cbf0_edf_axi/I/0",
        "ro_cbf10_edf_axi/I/0", "ro_cbf11_edf_axi/I/0", "ro_cbf12_edf_axi/I/0",
        "ro_cbf13_edf_axi/I/0", "ro_cbf14_edf_axi/I/0", "ro_cbf15_edf_axi/I/0",
        "ro_cbf1_edf_axi/I/0", "ro_cbf2_edf_axi/I/0", "ro_cbf3_edf_axi/I/0",
        "ro_cbf4_edf_axi/I/0", "ro_cbf5_edf_axi/I/0", "ro_cbf6_edf_axi/I/0",
        "ro_cbf7_edf_axi/I/0", "ro_cbf8_edf_axi/I/0", "ro_cbf9_edf_axi/I/0",
        "ro_cdte0_edf_axi/I/0", "ro_cdte1_edf_axi/I/0", "ro_cdte2_edf_axi/I/0",
        "ro_cdte3_edf_axi/I/0", "ro_cva_edf_axi/I/0", "ro_dftentry0_edf_axi/I/0",
        "ro_dpf_edf_axi/I/0", "ro_edfcore_m_edfio0_axi/I/0", "ro_edfcore_m_edfio1_axi/I/0",
        "ro_sip0_edf_axi/I/0", "ro_sip10_edf_axi/I/0", "ro_sip11_edf_axi/I/0",
        "ro_sip12_edf_axi/I/0", "ro_sip13_edf_axi/I/0", "ro_sip14_edf_axi/I/0",
        "ro_sip15_edf_axi/I/0", "ro_sip1_edf_axi/I/0", "ro_sip2_edf_axi/I/0",
        "ro_sip3_edf_axi/I/0", "ro_sip4_edf_axi/I/0", "ro_sip5_edf_axi/I/0",
        "ro_sip6_edf_axi/I/0", "ro_sip7_edf_axi/I/0", "ro_sip8_edf_axi/I/0",
        "ro_sip9_edf_axi/I/0", "ro_sp_edf_axi/I/0", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED",
    }};

    const std::array<std::string, 256> NOCERR_EDFCORER_TARGET_FLOW_ARRAY{{
        "edfcorer_s_service/T/0", "ro_edf_aasp_axi/T/0", "ro_edf_cbf0p0_axi/T/0",
        "ro_edf_cbf0p1_axi/T/0", "ro_edf_cbf10p0_axi/T/0", "ro_edf_cbf10p1_axi/T/0",
        "ro_edf_cbf11p0_axi/T/0", "ro_edf_cbf11p1_axi/T/0", "ro_edf_cbf12p0_axi/T/0",
        "ro_edf_cbf12p1_axi/T/0", "ro_edf_cbf13p0_axi/T/0", "ro_edf_cbf13p1_axi/T/0",
        "ro_edf_cbf14p0_axi/T/0", "ro_edf_cbf14p1_axi/T/0", "ro_edf_cbf15p0_axi/T/0",
        "ro_edf_cbf15p1_axi/T/0", "ro_edf_cbf1p0_axi/T/0", "ro_edf_cbf1p1_axi/T/0",
        "ro_edf_cbf2p0_axi/T/0", "ro_edf_cbf2p1_axi/T/0", "ro_edf_cbf3p0_axi/T/0",
        "ro_edf_cbf3p1_axi/T/0", "ro_edf_cbf4p0_axi/T/0", "ro_edf_cbf4p1_axi/T/0",
        "ro_edf_cbf5p0_axi/T/0", "ro_edf_cbf5p1_axi/T/0", "ro_edf_cbf6p0_axi/T/0",
        "ro_edf_cbf6p1_axi/T/0", "ro_edf_cbf7p0_axi/T/0", "ro_edf_cbf7p1_axi/T/0",
        "ro_edf_cbf8p0_axi/T/0", "ro_edf_cbf8p1_axi/T/0", "ro_edf_cbf9p0_axi/T/0",
        "ro_edf_cbf9p1_axi/T/0", "ro_edf_mdf0p0_axi/T/0", "ro_edf_mdf0p1_axi/T/0",
        "ro_edf_mdf1p0_axi/T/0", "ro_edf_mdf1p1_axi/T/0", "ro_edf_sp_axi/T/0",
        "ro_edfcore_s_edfio_axi/T/0", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
    }};
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_NOC_SCORPIO_NOC_ERR_EDFCORER_H_
