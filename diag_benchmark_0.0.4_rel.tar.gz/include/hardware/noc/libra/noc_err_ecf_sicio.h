/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_NOC_LIBRA_NOC_ERR_ECF_SICIO_H_
#define HARDWARE_NOC_LIBRA_NOC_ERR_ECF_SICIO_H_

#include <memory>
#include <set>
#include <string>
#include "device/dtus/libra/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_error.h"

namespace efvf {
namespace hardware {
namespace noc {
class NocErrEcfSicioLibra : public NocErr {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocErrEcfSicioLibra(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocErrEcfSicioLibra() {}
    virtual bool Dump(NOC_Err_Info &err);
    virtual bool Clear();
    virtual bool IsErrValid(void);

 protected:
    virtual int DumpOffset(NOC_Err_Info &err);
    virtual int TriggerClr();
    virtual int DumpRoute(NOC_Err_Info &err);
    virtual int DumpAxUser(NOC_Err_Info &err);
    virtual int DumpValid(NOC_Err_Info &err);
    virtual uint32_t DumpErrType(NOC_Err_Info &err);

 private:
    typedef struct _ECF_SICIO_Core_RouteId_Libra_t {
#if BYTE_ORDER == LITTLE_ENDIAN
        unsigned int Reserved0 : 17;
        unsigned int Slave : 3;
        unsigned int Master : 3;
        unsigned int Reserved2 : 9;

#elif BYTE_ORDER == BIG_ENDIAN
        unsigned int Reserved2 : 9;
        unsigned int Slave : 3;
        unsigned int Master : 3;
        unsigned int Reserved0 : 17;
#endif
    } ECF_SICIO_RouteId_Libra_t;

    typedef union {
        unsigned int              val : 32;
        ECF_SICIO_RouteId_Libra_t f;
    } ECF_SICIO_RouteId_Libra_u;

    const std::array<std::string, 256> NOCERR_ECF_SICIO_ERRTYPE_ARRAY{{
        "target error detected by slave", "address decode error", "unsupported request",
        "disconnected target or domain", "Security violation",
        "hidden security violation, reported as OK to initiator", "time-out", "Reserved",
    }};
    const std::array<std::string, 256> NOCERR_ECF_SICIO_USER_FLAGS_ARRAY{{
        "Cache_0", "Cache_1", "Cache_2", "Cache_3", "Prot_0", "Prot_1", "Prot_2", "reqUser_00",
        "reqUser_01", "reqUser_02", "reqUser_03", "reqUser_04", "reqUser_05", "reqUser_06",
        "reqUser_07", "reqUser_08", "reqUser_09", "reqUser_10", "reqUser_11", "reqUser_12",
        "reqUser_13", "reqUser_14", "reqUser_15", "reqUser_16", "reqUser_17", "reqUser_18",
        "reqUser_19", "user_endianness",
    }};
    const std::array<std::string, 256> NOCERR_ECF_SICIO_INIT_ARRAY{{
        "Flow:/Specification/rw_ecfcore_sicio_ft_ib_axi/I/0",
        "Flow:/Specification/rw_sic_p0_ecf_axi/I/0",
        "Flow:/Specification/rw_sic_p1_ecf_axi/I/0", "Flow:/Specification/wo_cdte_ecf_axi/I/0",
        "Flow:/Specification/wo_sic_gsync_m_axi/I/0",
        "Flow:/Specification/wo_sic_mmu_msg_ecf_axi/I/0", "RESERVED", "RESERVED",
    }};

    const std::array<std::string, 256> NOCERR_ECF_SICIO_TARGET_ARRAY{{
        "Flow:/Specification/ecf_sicio_svc/T/0", "Flow:/Specification/rw_ecf_cdte_axi/T/0",
        "Flow:/Specification/rw_ecf_sic_p0_axi/T/0",
        "Flow:/Specification/rw_ecf_sic_p1_axi/T/0",
        "Flow:/Specification/rw_ecf_sicio_svc_axi/T/0",
        "Flow:/Specification/rw_sic_gsync_s_axi/T/0",
        "Flow:/Specification/rw_sic_ecfcore_ft_ob_axi/T/0", "RESERVED",
    }};
};
}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_NOC_LIBRA_NOC_ERR_ECF_SICIO_H_
