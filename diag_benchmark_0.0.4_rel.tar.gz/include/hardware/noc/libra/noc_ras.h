/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_NOC_LIBRA_NOC_RAS_H_
#define HARDWARE_NOC_LIBRA_NOC_RAS_H_

#include <memory>
#include <set>
#include <string>
#include "device/dtus/libra/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_ras.h"

namespace efvf {
namespace hardware {
namespace noc {

class NocRasLibra : public NocRas {
 public:
    explicit NocRasLibra(NocErr *noc_err);
    virtual ~NocRasLibra();

    /**
     * @brief enable ras
     */
    virtual void Enable(RasCfg *cfg) {}

    /**
     * @brief disable ras
     */
    virtual void Disable(RasCfg *cfg) {}

    /**
     * @brief start ras inject
     */
    virtual void StartErrInjection(RasCfg *cfg, RasErrInj *err_inj) {}

    /**
     * @brief stop ras inject
     */
    virtual void StopErrInjection(RasCfg *cfg, RasErrInj *err_inj) {}

    /**
     * @brief query err
     */
    virtual void QueryErrStatus(RasCfg *cfg, RasErrStat *err_stat);

    /**
     * @brief clear err
     */
    virtual void ClearErrStatus(RasCfg *cfg);

    /**
     * @brief print err
     */
    virtual void PrintErrStatus(RasCfg *cfg) {}

    /**
     * @berif get ras cfg
     *
     * @param      cfg   The configuration
     */
    virtual void GetRasCfg(RasCfg *cfg) {}

    /**
     * @brief enable interrupt
     */
    virtual void EnableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief disable interrupt
     */
    virtual void DisableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief clear interrupt
     */
    virtual void ClearInterrupt(IntrptCfg *cfg) {}

    /**
     * @berif save interrupt
     */
    virtual void QueryInterrupt(IntrptCfg *cfg, IntrptStat *stat) {}

    /**
     * @brief print interrupt
     */
    virtual void PrintInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  type     The type
     * @param[in]  is_stop  is stopping err inj?
     *
     * @return     { description_of_the_return_value }
     */
    virtual RasErrInj *GenRasErrInjCfg(const std::string &type, bool is_stop = false) {}
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_NOC_LIBRA_NOC_RAS_H_
