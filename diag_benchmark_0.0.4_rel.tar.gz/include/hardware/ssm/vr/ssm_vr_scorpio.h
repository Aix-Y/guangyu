/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_VR_SSM_VR_SCORPIO_H_
#define HARDWARE_SSM_VR_SSM_VR_SCORPIO_H_

#include <string>
#include <vector>

#include "hardware/include/ssm/vr/ssm_vr.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace vr {

class SsmVrScorpio : public SsmVr {
 public:
    explicit SsmVrScorpio(Ssm *ssm) : SsmVr(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmVrScorpio() {}

 private:
    bool        fw_human(uint32_t);
    std::string vr_db_rev(void);
    bool        vr_db_check(std::string &, uint32_t, const std::vector<std::string> &);
    uint32_t    board_type(void);
    bool        is_vr_cap_r(uint32_t);
    bool        is_vr_cap_w(uint32_t);
    bool        is_vr_avs_t(uint32_t);
    bool        is_vr_mpm82504(uint32_t);

 public:
    bool        chk_tid_valid(uint32_t);
    bool        is_vr_supported(uint32_t);
    bool        is_vr_cap_r(const std::string &);
    uint32_t    vr_name_to_id(const std::string &);
    std::string vr_id_to_name(const uint32_t &);
    std::string vr_id_2str(const uint32_t &);
    std::string get_vr_name(uint32_t);
    std::string get_vr_phyloc(uint32_t);
    uint32_t    get_vr_fwidx(const std::string &);
    uint32_t    get_vr_fwidx(uint32_t);
    double      get_vr_temp(const std::string &);
    double      get_vr_temp(uint32_t);
    double      get_vr_curr(const std::string &);
    double      get_vr_curr(uint32_t);
    double      get_vr_volt(const std::string &);
    double      get_vr_volt(uint32_t);
    double      get_vr_volt_shunt(const std::string &);
    double      get_vr_volt_shunt(uint32_t);
    double      get_vr_volt_bus(const std::string &);
    double      get_vr_volt_bus(uint32_t);
    double      get_vr_power(const std::string &);
    double      get_vr_power(uint32_t);
    double      get_vr_power_asic(void);
    double      get_vr_power_dmem(void);
    uint32_t    get_vr_power_board_ave(void);
    double      get_vr_power_true(void);
    void        set_vr_ot_fault(const std::string &, double);
    void        set_vr_ot_warn(const std::string &, double);
    void        set_vr_oc_fault(const std::string &, double);
    void        set_vr_loadline(uint32_t);
    void        set_vr_dtu_vdroop_raw(uint32_t);
    uint32_t    get_vr_dtu_vdroop_raw(void);
    void        set_vr_volt(const std::string &, double);
    void        set_vr_volt(uint32_t, double);
    void        set_vr_avs_mv(uint32_t, uint32_t);
    uint32_t    get_vr_avs_mv(uint32_t);

 private:
    void     set_vr_volt_pmbus(uint32_t, double);
    void     set_vr_volt_avs(uint32_t, double);
    double   get_vr_volt_avs(uint32_t);
    void     set_vr_volt_dac(uint32_t, double);
    void     set_vr_volt_dac_mcphy(uint32_t, double);
    void     wat_vr_volt_apply(const std::string &, uint32_t, uint32_t);
    void     wat_vr_volt_apply(uint32_t, uint32_t, uint32_t);
    uint32_t set_vr_gb_ctrl(uint32_t, uint32_t, uint32_t);
    bool     get_vr_gb_state(uint32_t, uint32_t);
    bool     set_vr_gb_on(uint32_t, uint32_t);
    bool     set_vr_gb_off(uint32_t, uint32_t);
    bool     set_vr_aging_on(uint32_t);
    bool     set_vr_aging_off(uint32_t);
    bool     get_vr_aging_state(uint32_t);
    bool     set_vr_app_on(uint32_t);
    bool     set_vr_app_off(uint32_t);
    bool     get_vr_app_state(uint32_t);

 private:
    uint32_t pmbc_volt_encode(uint32_t, double);
    double   pmbc_volt_decode(uint32_t, uint32_t);
    double   epmc_get_rshunt_param(uint32_t);
    uint32_t get_vr_page_reg_v(uint32_t, uint32_t, uint32_t, uint32_t);

 public:
    bool test_vr_golden_range_volt(void);
    bool test_vr_golden_setting(void);
    bool test_vr_check_ic_did(void);
    bool test_vr_each_c_ave_dvi(void);
    bool test_vr_each_v_ave_dvi(void);
    bool test_vr_each_t_ave_dvi(void);
    bool test_vr_each_p_ave_dvi(void);

 public:
    bool        handle_tool_req_set(const std::string &, const std::string &);
    bool        handle_tool_req_set_val(const std::string &, std::string &, uint32_t &);
    std::string handle_tool_req_get_str(const std::string &);
    std::string handle_tool_req_get_str(const std::string &, const std::string &);
    std::string handle_req_pmbus_read(const std::string &);
    std::string handle_req_pmbus_write(const std::string &);
    std::string handle_req_pmbus_dump(const std::string &);
    bool        handle_req_pmbus_query(const std::string &);
    bool        handle_req_volt_list(void);
    bool        handle_req_curr_list(void);
    bool        handle_req_power_list(void);
    bool        handle_req_pmon_list(void);
    bool        handle_req_pmon_ext(const std::string &, const std::string &);
    bool        handle_req_avs(const std::string &, const std::string &);
};

}  // namespace vr
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_VR_SSM_VR_SCORPIO_H_
