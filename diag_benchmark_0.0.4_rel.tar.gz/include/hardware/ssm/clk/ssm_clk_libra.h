/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_CLK_SSM_CLK_LIBRA_H_
#define HARDWARE_SSM_CLK_SSM_CLK_LIBRA_H_

#include <string>

#include "hardware/include/ssm/clk/ssm_clk.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace clk {

class SsmClkLibra : public SsmClk {
 public:
    explicit SsmClkLibra(Ssm *ssm) : SsmClk(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmClkLibra() {}

 public:
    void     ssm_clk_set(uint32_t, uint32_t);
    uint32_t ssm_clk_get(uint32_t);
    void     ssm_clk_get_list(uint32_t *);
    bool     ssm_clk_ckb_in_use(void);
    uint32_t ssm_clk_ckb_lv_get(uint32_t);
    void     ssm_clk_gcu_2ref(void);
    double   ssm_clk_obs(uint32_t, uint32_t);

 private:
    SSM_PA gen_addr_pa(uint32_t addr);

 private:
    clk_tree clk_tree_get(void);
    void     clk_tree_pll_init(clk_tree &, uint32_t, uint32_t);
    void     clk_tree_pll_init_cfg(pll_inst &);
    void     clk_tree_pll_init_map(pll_inst &, uint32_t, uint32_t);
    void     clk_tree_pll_init_map_c0txp0(pll_inst &);
    void     clk_tree_pll_init_map_c0txp1(pll_inst &);
    void     clk_tree_pll_init_map_c0txphs(pll_inst &);
    void     clk_tree_pll_init_map_c2t0p0(pll_inst &);
    void     clk_tree_pll_init_map_c2t1p0(pll_inst &);
    void     clk_tree_pll_init_map_c2t2p0(pll_inst &);
    void     clk_tree_pll_init_map_c2t3p0(pll_inst &);
    void     clk_tree_pll_init_map_c3t0p0(pll_inst &);
    void     clk_tree_pll_init_map_c3t0phs(pll_inst &);
    void     clk_tree_pll_init_map_c3t1p0(pll_inst &);
    void     clk_tree_pll_init_map_c3t1phs(pll_inst &);
    void     clk_tree_pll_init_map_c3t2p0(pll_inst &);
    void     clk_tree_pll_init_map_c3t2phs(pll_inst &);
    void     clk_tree_pll_sync(clk_tree &);
    double   clk_tree_pll_ref100(clk_tree &, uint32_t);
    double   clk_tree_pll_memrep_calc(clk_tree &, uint32_t);
    void     clk_tree_clk_init_branch(clk_tree &);
    void     clk_tree_clk_calc(clk_tree &);
    void     clk_tree_clk_calc_c0tx(clk_tree &);
    void     clk_tree_clk_calc_c2t0(clk_tree &);
    void     clk_tree_clk_calc_c2t1(clk_tree &);
    void     clk_tree_clk_calc_c2t2(clk_tree &);
    void     clk_tree_clk_calc_c2t3(clk_tree &);
    void     clk_tree_clk_calc_c3t0(clk_tree &);
    void     clk_tree_clk_calc_c3t1(clk_tree &);
    void     clk_tree_clk_calc_c3t2(clk_tree &);
    uint32_t clk_get_mux_sel(uint32_t);
    void     clk_set_mux_sel(uint32_t, uint32_t);
    uint32_t clk_get_id_by_div(uint32_t);
    uint32_t clk_get_div_addr(uint32_t);
    bool     clk_get_div_cfg(uint32_t, uint32_t &);
    void     clk_set_div_cfg(uint32_t, bool, uint32_t);

 private:
    bool        is_csc_supported(uint32_t);
    bool        is_ckb_supported(uint32_t);
    bool        is_gd_supported(uint32_t);
    uint32_t    get_csc_per_gd_trig(uint32_t);
    uint32_t    get_evt_per_gd_trig(uint32_t);
    uint32_t    csc_get_en_addr(uint32_t);
    void        csc_set_en(uint32_t, uint32_t);
    bool        csc_get_en(uint32_t);
    void        csc_set_en_toggle(uint32_t, uint32_t);
    void        csc_set_en_all(uint32_t, uint32_t);
    uint32_t    csc_get_mode_addr(uint32_t);
    std::string csc_get_mode_str(uint32_t);
    void        csc_set_mode(uint32_t, uint32_t);
    uint32_t    csc_get_mode(uint32_t);
    uint32_t    csc_get_mode_fw(uint32_t);
    void        csc_set_mode_fw(uint32_t, uint32_t);
    uint32_t    csc_get_mode_oct(uint32_t);
    void        csc_set_mode_oct(uint32_t, uint32_t);
    uint32_t    csc_get_mode_ott(uint32_t);
    void        csc_set_mode_ott(uint32_t, uint32_t);
    uint32_t    csc_get_fw_ctrl0_addr(uint32_t);
    uint32_t    csc_get_fw_ctrl1_addr(uint32_t);
    void        csc_set_fw_tt_req(uint32_t, uint32_t);
    void        csc_set_fw_tt_all(uint32_t, uint32_t);
    bool        csc_set_fw_tt_req_check(uint32_t, uint32_t, bool = false);
    uint32_t    csc_get_status(uint32_t);
    uint32_t    csc_get_raw_val(uint32_t);
    uint32_t    csc_get_tar_val(uint32_t);
    uint32_t    csc_get_syc_val(uint32_t);
    uint32_t    csc_get_step_ctrl_addr(uint32_t);
    uint32_t    csc_get_step_ctrl(uint32_t);
    uint32_t    csc_get_step_delay_up(uint32_t);
    uint32_t    csc_get_step_delay_dn(uint32_t);
    void        csc_set_step_mode(uint32_t, uint32_t, uint32_t, uint32_t);
    void        csc_dump_status_all(uint32_t, const std::string &);
    void        csc_dump_status(uint32_t, uint32_t, std::string);
    void        csc_trigger_select(uint32_t, uint32_t);
    void        csc_trigger_assert(uint32_t, uint32_t);
    void        csc_trigger_deassert(uint32_t, uint32_t);
    bool        csc_wait_apply(uint32_t, uint32_t);
    uint32_t    oct_get_ctrl0_addr(uint32_t);
    uint32_t    oct_get_ctrl1_addr(uint32_t);
    void        oct_set_req_update(uint32_t, uint32_t);
    void        oct_req_update(uint32_t);
    void        oct_set_release_bypass(uint32_t, uint32_t);
    uint32_t    oct_get_release_bypass(uint32_t);
    void        oct_set_ceiling(uint32_t, uint32_t);
    uint32_t    oct_get_ceiling(uint32_t);
    void        oct_set_ceiling_info(uint32_t, uint32_t);
    uint32_t    oct_get_ceiling_info(uint32_t);
    bool        oct_exp_ceiling_check(uint32_t, uint32_t);
    void        oct_set_target_low(uint32_t, uint32_t);
    uint32_t    oct_get_target_low(uint32_t);
    void        oct_set_req_value(uint32_t, uint32_t);
    uint32_t    oct_get_req_value(uint32_t);
    void        oct_set_reg_req(uint32_t, uint32_t);
    bool        oct_get_reg_req(uint32_t);
    void        oct_set_reg_trigger(uint32_t);
    void        oct_set_mdn_lowest(uint32_t, uint32_t);
    uint32_t    oct_get_mdn_lowest(uint32_t);
    void        oct_req_setup(uint32_t, bool, uint32_t, uint32_t);
    uint32_t    oct_sel_case_path(uint32_t, uint32_t, uint32_t);
    uint32_t    oct_ent_exp_get(uint32_t, uint32_t, uint32_t);
    bool        oct_ent_exp_check(uint32_t, uint32_t, uint32_t);
    bool        oct_ext_exp_check(uint32_t, uint32_t, uint32_t);
    bool        oct_ext_sdw_check(uint32_t, uint32_t, uint32_t);
    uint32_t    ott_get_ctrl0_addr(uint32_t);
    uint32_t    ott_get_ctrl1_addr(uint32_t);
    void        ott_set_req_update(uint32_t, uint32_t);
    void        ott_req_update(uint32_t);
    void        ott_set_release_bypass(uint32_t, uint32_t);
    uint32_t    ott_get_release_bypass(uint32_t);
    void        ott_set_tt_value(uint32_t, uint32_t);
    uint32_t    ott_get_tt_value(uint32_t);
    void        ott_set_reg_req(uint32_t, uint32_t);
    bool        ott_get_reg_req(uint32_t);
    void        ott_set_reg_trigger(uint32_t);
    uint32_t    obs_get_cfg_addr(uint32_t);
    void        obs_set_timer_start(uint32_t);
    void        obs_set_timer_stop(uint32_t);
    void        obs_set_clk_div(uint32_t, bool, uint32_t);
    uint32_t    obs_get_mux_setting(uint32_t);
    void        obs_set_clk_sel(uint32_t, uint32_t);
    uint32_t    obs_get_comp_addr(uint32_t);
    void        obs_set_tmr_cmp(uint32_t, uint32_t);
    uint32_t    obs_get_cnt_addr(uint32_t);
    uint32_t    obs_get_tmr_cnt(uint32_t);
    void        obs_clr_tmr_cnt(uint32_t);
    void        obs_set_clk2pad(uint32_t);
    uint32_t    obs_get_clk2pad(void);
    void        obs_out2pad_ctrl(bool);
    bool        is_obs_valid(uint32_t, uint32_t);
    bool        is_obs_valid_c0tx(uint32_t);
    bool        is_obs_valid_c2t0(uint32_t);
    bool        is_obs_valid_c2t1(uint32_t);
    bool        is_obs_valid_c2t2(uint32_t);
    bool        is_obs_valid_c2t3(uint32_t);
    bool        is_obs_valid_c3t0(uint32_t);
    bool        is_obs_valid_c3t1(uint32_t);
    bool        is_obs_valid_c3t2(uint32_t);
    uint32_t    obs_wait_calc_ms(uint32_t);
    double      obs_get_freq(OBS_REQ_u &);
    double      obs_get_freq(uint32_t, uint32_t, uint32_t = 0);
    void        obs_get_list(uint32_t, uint32_t *, uint32_t, uint32_t);
    uint32_t    gd_get_macro_ctrl_addr(uint32_t);
    uint32_t    gd_get_macro_pd(uint32_t);
    void        gd_set_macro_pd(uint32_t, uint32_t);
    uint32_t    gd_get_hot_ctrl_addr(uint32_t);
    uint32_t    gd_get_macro_polarity(uint32_t);
    void        gd_set_macro_polarity(uint32_t, uint32_t);
    uint32_t    gd_get_manual_toggle_sel(uint32_t);
    void        gd_set_manual_toggle_sel(uint32_t, uint32_t);
    void        gd_set_manual_hot_toggle(uint32_t, uint32_t);
    void        gd_set_manual_op(uint32_t, bool);
    uint32_t    gd_get_cnt_flt_ctrl_addr(uint32_t);
    bool        gd_get_cnt_flt_en(uint32_t);
    uint32_t    gd_get_cnt_flt_val(uint32_t);
    void        gd_set_cnt_clr(uint32_t);
    uint32_t    gd_get_cnt_val(uint32_t);
    std::string gd_get_cnt_str(void);
    uint32_t    gd_get_int_en_addr(uint32_t);
    bool        gd_get_vddc_profiling_en(uint32_t);
    void        gd_set_vddc_profiling_en(uint32_t, uint32_t);
    bool        gd_get_vddc_gpio_en(uint32_t);
    void        gd_set_vddc_gpio_en(uint32_t, uint32_t);
    bool        gd_get_vddc_int_en(uint32_t);
    void        gd_set_vddc_int_en(uint32_t, uint32_t);
    void        gd_set_ena_per_csc(uint32_t, uint32_t, bool);
    void        gd_set_hot_per_csc(uint32_t, uint32_t, bool);
    uint32_t    gd_get_sig_hystersis_ctrl_addr(uint32_t);
    uint32_t    gd_get_sig_hystersis_delay_left(uint32_t);
    void        gd_set_sig_hystersis_delay_left(uint32_t, uint32_t);
    uint32_t    gd_get_sig_hystersis_delay_right(uint32_t);
    void        gd_set_sig_hystersis_delay_right(uint32_t, uint32_t);
    void        gd_set_sig_hystersis_delay(uint32_t);
    uint32_t    ckb_get_rst_addr(uint32_t);
    void        ckb_set_rst_toggle(uint32_t);
    bool        ckb_get_rst_stat(uint32_t);
    uint32_t    ckb_get_en_addr(uint32_t);
    void        ckb_set_en(uint32_t, uint32_t);
    bool        ckb_get_en(uint32_t);
    void        ckb_set_en_toggle(uint32_t, uint32_t);
    uint32_t    ckb_get_evt_ctrl_addr(uint32_t);
    void        ckb_set_evt_en(uint32_t, uint32_t);
    bool        ckb_get_evt_en(uint32_t);
    void        ckb_set_evt_hys_bypass(uint32_t, uint32_t);
    bool        ckb_get_evt_hys_bypass(uint32_t);
    void        ckb_set_evt_hys_delay(uint32_t, uint32_t);
    uint32_t    ckb_get_evt_hys_delay(uint32_t);
    uint32_t    ckb_get_config_addr(uint32_t);
    void        ckb_set_up_interval(uint32_t, uint32_t);
    uint32_t    ckb_get_up_interval(uint32_t);
    void        ckb_set_slowest_lv(uint32_t, uint32_t);
    uint32_t    ckb_get_slowest_lv(uint32_t);
    void        ckb_set_fastest_lv(uint32_t, uint32_t);
    uint32_t    ckb_get_fastest_lv(uint32_t);
    uint32_t    ckb_get_exp_addr(uint32_t);
    void        ckb_set_exp(uint32_t, uint32_t);
    uint32_t    ckb_get_exp(uint32_t);
    uint32_t    ckb_get_exp_up_addr(uint32_t);
    void        ckb_set_exp_up_toggle(uint32_t);
    void        ckb_set_fw_tt_req(uint32_t, uint32_t);
    uint32_t    ckb_get_status_addr(uint32_t);
    uint32_t    ckb_get_cur_lv(uint32_t);
    bool        ckb_get_clock_rdy(uint32_t);
    double      ckb_get_div_per_lv(uint32_t);
    uint32_t    ckb_gry_2bin(uint32_t);
    uint32_t    ckb_bin_2gry(uint32_t);
    uint32_t    get_mix_evt_delay_val(uint32_t, uint32_t);
    bool        get_mix_evt_delay_en(uint32_t, uint32_t);
    uint32_t    get_mix_evt_delay(uint32_t, uint32_t);
    bool        evt_get_ena_clk0(uint32_t);
    void        evt_set_ena_clk0(uint32_t, bool);
    bool        evt_get_ena_clk3t0(uint32_t);
    void        evt_set_ena_clk3t0(uint32_t, bool);
    bool        evt_get_ena_clk3t1(uint32_t);
    void        evt_set_ena_clk3t1(uint32_t, bool);
    bool        evt_get_ena_clk3t2(uint32_t);
    void        evt_set_ena_clk3t2(uint32_t, bool);
    bool        evt_get_ena(uint32_t, uint32_t);
    void        evt_set_ena(uint32_t, uint32_t, bool);
    void        evt_dis_all_gd(void);
    void        evt_up2_clk_disp_clk0(void);
    void        evt_up2_clk_disp_clk3_t0(void);
    void        evt_up2_clk_disp_clk3_t1(void);
    void        evt_up2_clk_disp_clk3_t2(void);

 public:
    bool test_pll_mpll_bpll_switch(void);
    bool test_clk_obs_vs_obs_div_sweep(void);
    bool test_clk_obs_vs_clk_div_freq(void);
    bool test_clk_obs_vs_clk_div_freq_sweep(void);
    bool test_clk_obs_vs_clk_csc_fw_tt_sweep(void);
    bool test_clk_obs_vs_clk_mux_switch(void);
    bool test_clk_csc_fw_tt_sweep(void);
    bool test_clk_csc_fw_tt_random(void);
    bool test_clk_csc_oct_verify(void);
    bool test_clk_csc_oct_random(void);
    bool test_clk_csc_oct_random_all(void);
    bool test_clk_csc_oct_fw_tt_shadow(void);
    bool test_clk_csc_oct_ceiling(void);
    bool test_clk_csc_oct_step_verify(void);
    bool test_clk_gd_toggle_single(void);
    bool test_clk_gd_toggle_random(void);
    bool test_clk_gd_toggle_vs_csc_oct(void);

 public:
    bool test_clk_golden_range(void);

 public:
    std::string handle_tool_req_get_str(const std::string &);
    std::string handle_req_csc_get_str(const std::string &);
    bool        handle_req_csc_set(const std::string &);
    bool        handle_req_csc_set(const std::string &, uint32_t &);
    bool        handle_req_csc_set(const std::string &, const std::string &);
    bool        handle_req_csc_set(const std::string &, const std::string &, uint32_t &);
    std::string handle_req_ckb_get_str(const std::string &);
    bool        handle_req_ckb_set(const std::string &);
    bool        handle_req_ckb_set(const std::string &, uint32_t &);
    bool        handle_req_ckb_set(const std::string &, const std::string &, uint32_t &);
    std::string handle_req_obs_wp(const std::string &, const std::string &);
    std::string handle_req_obs_cfg(const std::string &);
    std::string handle_req_obs_list(const std::string &, uint32_t &, uint32_t &);
    bool        handle_req_clk_list(const std::string &);
    bool        handle_req_clk_lobs(const std::string &);
    void        handle_req_clk_event_status(const std::string &);
    void        handle_req_clk_event_op(bool, const std::string &);
    bool        handle_req_clk_test(const std::string &, const std::string &);
    bool        handle_req_clk_op(const std::string &);
};

}  // namespace clk
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_CLK_SSM_CLK_LIBRA_H_
