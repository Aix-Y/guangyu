/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_MCU_SSM_MCU_SCORPIO_H_
#define HARDWARE_SSM_MCU_SSM_MCU_SCORPIO_H_

#include <string>

#include "hardware/include/ssm/mcu/ssm_mcu.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace mcu {

class SsmMcuScorpio : public SsmMcu {
 public:
    explicit SsmMcuScorpio(Ssm *ssm) : SsmMcu(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmMcuScorpio() {}

 private:
    bool m_pwrs_feature_on = false;

 public:
    uint32_t    ssm_reg_read(uint32_t);
    void        ssm_reg_write(uint32_t, uint32_t);
    bool        ssm_check_boot_complete(uint64_t = 0 /*timeout_ms*/);
    uint32_t    ssm_check_boot_error(void);
    bool        ssm_check_flr_status(uint32_t = SSM_MAGIC);
    bool        ssm_feature_op_skip(uint32_t);
    bool        ssm_feature_is_valid(uint32_t);
    uint32_t    ssm_feature_idmask(uint32_t);
    uint32_t    ssm_feature_status_get(void);
    void        ssm_feature_enable(uint32_t);
    void        ssm_feature_disable(uint32_t);
    void        ssm_feature_mask_enable(uint32_t);
    void        ssm_feature_mask_disable(uint32_t);
    void        ssm_stop(void);
    void        ssm_start(void);
    void        ssm_stop_d2d(void);
    bool        ssm_gbage_dtu_sticky(void);
    bool        ssm_gbage_soc_sticky(void);
    bool        ssm_gbapp_dtu_sticky(void);
    bool        ssm_gbapp_soc_sticky(void);
    std::string ssm_pmode_2str(uint32_t);
    uint32_t    ssm_pmode_get(void);
    uint32_t    ssm_pmode_set(uint32_t);
    bool        ssm_pmode_set(std::string);
    bool        ssm_pmode_is_active(uint32_t);
    bool        ssm_pmode_is_sleep_0(uint32_t);
    bool        ssm_pmode_is_sleep_1(uint32_t);
    bool        ssm_pmode_is_sleep_2(uint32_t);
    uint32_t    ssm_power_cap(void);
    void        ssm_feat_alter_save(void);
    void        ssm_feat_alter_restore(void);
    void        ssm_apply_onchip_vddc(uint32_t, double);
    void        ssm_force_onchip_vddc(uint32_t);
    uint32_t    get_fw_ver_sub_v(uint32_t);
    uint32_t    get_fw_ver_major(uint32_t);
    uint32_t    get_fw_ver_minor(uint32_t);
    uint32_t    get_fw_ver_patch(uint32_t);
    std::string get_str_board_type(uint32_t);
    std::string get_str_board_rev(uint32_t);
    std::string get_str_bfw_ver(uint32_t);
    std::string get_str_rfw_ver(uint32_t);
    std::string get_str_amc_ver(uint32_t);
    std::string get_str_dmem_type(uint32_t = SSM_MAGIC);
    std::string get_native_uuid(void);
    std::string get_remote_uuid(uint32_t);
    uint32_t    get_remote_uuid_num(void);
    uint32_t    get_fw_reset_type(void);
    uint32_t    get_fw_ver_bl0(void);
    uint32_t    get_fw_init_step_bl0(void);
    uint32_t    get_fw_ver_bl1(void);
    uint32_t    get_fw_init_step_bl1(void);
    uint32_t    get_fw_ver_rfw(void);
    uint32_t    get_fw_init_step_rfw(void);
    uint32_t    get_fw_sip_hav_otp(void);
    uint32_t    get_fw_sip_hav_act(void);
    uint32_t    get_fw_sip_hav_logic(void);
    uint32_t    get_fw_sip_hav_enable(void);
    uint32_t    get_fw_pstock_bneck_l1(void);
    uint32_t    get_fw_pstock_bneck_l2(void);
    uint32_t    get_fw_pstock_bneck_l3(void);
    uint32_t    get_fw_d2d_func(void);
    uint32_t    get_fw_d2d_para(void);
    uint32_t    get_fw_d2d_data(void);
    uint32_t    get_fw_d2d_step_sync(void);
    uint32_t    get_fw_isr_status(void);
    uint32_t    get_fw_boot_stat(void);
    uint32_t    get_fw_avs_ecnts(void);
    uint32_t    get_fw_aasp_link(void);
    uint32_t    get_fw_rfw_up_st(void);
    uint32_t    get_fw_rfw_er_st(void);
    uint32_t    get_fw_rfw_tm_glb(void);
    uint32_t    get_fw_rfw_bk_vld(void);
    uint32_t    get_fw_rfw_bk_addr(void);
    uint32_t    get_fw_rfw_ssm_git(void);
    uint32_t    get_fw_rfw_imu_git(void);
    uint32_t    get_fw_task_max_ts(void);
    uint32_t    get_fw_task_max_id(void);
    uint32_t    get_fw_dmem_type(void);

 private:
    uint32_t    get_log_addr(void);
    uint32_t    get_log_size(void);
    std::string get_log_ssm_boot(void);
    std::string get_log_ssm_runtime(void);
    std::string get_log_ssm_prefix(void);
    std::string get_log_ssm_timestamp(ssm_log_hdr_t &);
    bool        is_ts_invalid_boot(ssm_log_hdr_t &);
    void        mcu_set_pdebug_en(bool);
    bool        mcu_get_pdebug_en(void);
    bool        mcu_get_pdebug_vald(uint32_t);
    uint32_t    mcu_get_pdebug_excp(uint32_t);
    uint32_t    mcu_get_pdebug_priv(uint32_t);
    uint32_t    mcu_get_pdebug_inte(uint32_t);
    uint32_t    mcu_get_pdebug_insn(uint32_t);
    uint64_t    mcu_get_pdebug_addr(uint32_t);
    uint64_t    mcu_get_pdebug_caus(uint32_t);
    uint64_t    mcu_get_pdebug_tval(uint32_t);
    void        mcu_dec_sticky_reg(void);
    void        mcu_dec_sticky_ras(void);
    void        mcu_dec_vraw(const std::string &);
    void        mcu_dec_traw(const std::string &);
    void        mcu_dec_freq(const std::string &);

 private:
    typedef struct _mcu_sic_self_gd {
        bool     valid        = false;
        uint32_t gd_traw_vref = 0;
        uint32_t gd_traw_sic0 = 0;
        uint32_t gd_traw_sic1 = 0;
        uint32_t gd_traw_sic2 = 0;
        uint32_t gd_traw_sic3 = 0;
        uint32_t gd_trim_vref = 0;
        uint32_t gd_trim_sic0 = 0;
        uint32_t gd_trim_sic1 = 0;
        uint32_t gd_trim_sic2 = 0;
        uint32_t gd_trim_sic3 = 0;
    } mcu_sic_self_gd_t;
    mcu_sic_self_gd_t m_mcu_sic_self_gd;
    uint32_t          mcu_sic_self_gd(uint32_t, double);

 private:
    uint32_t mcu_get_gd_code(uint32_t, uint32_t, double, uint32_t);
    uint32_t mcu_cac_gd_code(uint32_t, uint32_t);
    void     mcu_set_gd_code(uint32_t, uint32_t, uint32_t);

 public:
    bool        handle_req_ssm_ping(void);
    bool        handle_req_ssm_test(const std::string &, const std::string &);
    std::string handle_req_bfw_version(void);
    std::string handle_req_rfw_version(void);
    void        handle_req_ssm_versions(void);
    void        handle_req_ssm_status(void);
    uint32_t    handle_req_ssm_r32(const std::string &);
    bool        handle_req_ssm_decode(const std::string &, const std::string &);
    bool        handle_req_ssm_encode(const std::string &, const std::string &);
    bool        handle_req_ssm_query(const std::string &);
    bool        handle_req_ssm_uuid(void);
    bool        handle_req_ssm_gsync(const std::string &);
    std::string handle_req_ssm_pmode_get(void);
    bool        handle_req_ssm_pmode_set(const std::string &);
    std::string handle_req_ssm_log(const std::string &);
    bool        handle_req_ssm_pc(const std::string &);
    std::string handle_req_ssm_pc_r(const std::string &);
    std::string handle_req_ssm_task_r(const std::string &);
    bool        handle_req_gd_update(const std::string &);
    std::string handle_req_ssm_feat(const std::string &, const std::string &);
};

}  // namespace mcu
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_MCU_SSM_MCU_SCORPIO_H_
