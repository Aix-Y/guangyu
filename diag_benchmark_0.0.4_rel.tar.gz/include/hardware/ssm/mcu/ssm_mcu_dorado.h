/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_MCU_SSM_MCU_DORADO_H_
#define HARDWARE_SSM_MCU_SSM_MCU_DORADO_H_

#include "hardware/include/ssm/mcu/ssm_mcu.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace mcu {

class SsmMcuDorado : public SsmMcu {
 public:
    explicit SsmMcuDorado(Ssm *ssm) : SsmMcu(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmMcuDorado() {}

 public:
    uint32_t ssm_reg_read(uint32_t);
    void     ssm_reg_write(uint32_t, uint32_t);

 public:
    bool handle_req_ssm_ping(void);
};

}  // namespace mcu
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_MCU_SSM_MCU_DORADO_H_
