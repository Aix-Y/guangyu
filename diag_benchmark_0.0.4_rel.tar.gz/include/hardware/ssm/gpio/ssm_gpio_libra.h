/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_GPIO_SSM_GPIO_LIBRA_H_
#define HARDWARE_SSM_GPIO_SSM_GPIO_LIBRA_H_

#include <string>

#include "hardware/include/ssm/gpio/ssm_gpio.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace gpio {

class SsmGpioLibra : public SsmGpio {
 public:
    explicit SsmGpioLibra(Ssm *ssm) : SsmGpio(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmGpioLibra() {}

 private:
    void *   get_db_ptr(void);
    uint64_t get_raw_pinstrap(void);
    uint64_t get_raw_io_dir(void);
    uint64_t get_raw_io_iput(void);
    uint64_t get_raw_io_oput(void);
    uint32_t get_gpio_reuse_for_vddc_en(void);
    void     set_gpio_reuse_for_vddc_en(uint32_t);
    uint32_t get_gpio_per_gd(uint32_t);

 private:
    uint32_t get_esl_pad_ctrl_addr(uint32_t);
    uint32_t get_esl_raw_pad_ctrl(uint32_t);
    uint32_t get_esl_raw_io_dir(uint32_t);
    uint32_t get_esl_raw_io_iput(void);
    uint32_t get_esl_raw_io_oput(void);
    uint32_t get_esl_io_dir(uint32_t);
    uint32_t get_esl_io_val(uint32_t);
    void     set_esl_io_val(uint32_t, uint32_t);
    void     set_esl_io_dir(uint32_t, uint32_t);
    uint32_t get_esl_mdio_share_en(void);
    void     set_esl_mdio_share_en(uint32_t);
    uint32_t get_esl_iic_mode_ctrl(void);
    void     set_esl_iic_mode_ctrl(uint32_t);

 public:
    bool     is_io_iput(uint32_t);
    bool     is_io_iput_lo(uint32_t);
    bool     is_io_iput_hi(uint32_t);
    bool     is_io_oput(uint32_t);
    bool     is_io_oput_lo(uint32_t);
    bool     is_io_oput_hi(uint32_t);
    bool     is_lvs_m2s_supp(void);
    uint32_t get_card_id(void);
    uint32_t get_pinstrap(uint32_t);
    uint64_t get_pinstrap_all(void);
    uint32_t get_io_dir(uint32_t);
    uint32_t get_io_val(uint32_t);
    void     set_io_val(uint32_t, uint32_t);
    void     set_io_dir(uint32_t, uint32_t);
    void     set_io_dir_iput(uint32_t);
    void     set_io_dir_oput(uint32_t);
    void     set_io_oput_lo(uint32_t);
    void     set_io_oput_hi(uint32_t);
    bool     get_gd_vddc2gpio_ena(uint32_t);
    void     set_gd_vddc2gpio_ena(uint32_t, bool);
    void     set_d2d_fatal_pad_ena(bool);
    void     set_spi_mst_access_slv(bool);

 public:
    bool test_gpio_pinstrap_golden_setting(void);

 private:
    std::string get_gpio_desc(uint32_t, uint32_t);

 public:
    std::string handle_req_gpio_status(void);
    std::string handle_req_gpio_esl_status(void);
    bool        handle_req_gpio_esl_on_off(const std::string &, const std::string &);
    uint32_t    handle_req_gpio_esl_set_iput_v(uint32_t);
    void        handle_req_gpio_esl_set_oput_v(uint32_t, uint32_t);
    bool        handle_req_gpio_reuse(const std::string &, const std::string &);
    void        handle_req_gpio_reuse_status(void);
    bool        handle_req_gpio_sku_info(void);
};

}  // namespace gpio
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_GPIO_SSM_GPIO_LIBRA_H_
