/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_GPIO_P4A_PIN_STRAP_HXX_
#define HARDWARE_SSM_GPIO_P4A_PIN_STRAP_HXX_

static SSM_GPIO_INFO pin_strap_bu[] = { // Bring-up Value asic.libra
    { .check = 1, .gpio =  0, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_0",  .name = "PIN_STRAP_FUSE_SENSE_BYPASS             ", },
    { .check = 1, .gpio =  1, .value = 1, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_1",  .name = "PIN_STRAP_SKIP_FUSE_SENSE_FOR_WARM_RESET", },
    { .check = 1, .gpio =  2, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_2",  .name = "PIN_STRAP_FW_LOAD_BYPASS                ", },
    { .check = 1, .gpio =  3, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_3",  .name = "PIN_STRAP_SKIP_FW_LOAD_FOR_WARM_RESET   ", },
    { .check = 1, .gpio =  4, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_4",  .name = "PIN_STRAP_BOOT_START_LOCATION           ", },
    { .check = 1, .gpio =  5, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_5",  .name = "PIN_STRAP_BOOT_SOURCE                   ", },
    { .check = 1, .gpio =  6, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_6",  .name = "PIN_STRAP_SECURE_BOOT_EN                ", },
    { .check = 1, .gpio =  7, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_7",  .name = "PIN_STRAP_HW_PCIE_LINK_TRAINING_ENABLE  ", },
    { .check = 1, .gpio =  8, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_8",  .name = "PIN_STRAP_SPI_CLK_FREQ                  ", },
    { .check = 1, .gpio =  9, .value = 1, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_9",  .name = "PIN_STRAP_SSM_SRAMMISC_SEL              ", },
    { .check = 0, .gpio = 10, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_10", .name = "                                        ", },
    { .check = 0, .gpio = 11, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_11", .name = "                                        ", },
    { .check = 0, .gpio = 12, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_12", .name = "                                        ", },
    { .check = 0, .gpio = 13, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_13", .name = "                                        ", },
    { .check = 0, .gpio = 14, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_14", .name = "                                        ", },
    { .check = 0, .gpio = 15, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_15", .name = "                                        ", },
    { .check = 0, .gpio = 16, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_16", .name = "                                        ", },
    { .check = 0, .gpio = 17, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_17", .name = "                                        ", },
    { .check = 0, .gpio = 18, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_18", .name = "                                        ", },
    { .check = 0, .gpio = 19, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_19", .name = "                                        ", },
    { .check = 0, .gpio = 20, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_20", .name = "                                        ", },
    { .check = 0, .gpio = 21, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_21", .name = "                                        ", },
    { .check = 0, .gpio = 22, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_22", .name = "                                        ", },
    { .check = 0, .gpio = 23, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_23", .name = "                                        ", },
    { .check = 0, .gpio = 24, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_24", .name = "                                        ", },
    { .check = 0, .gpio = 25, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_25", .name = "                                        ", },
    { .check = 0, .gpio = 26, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_26", .name = "                                        ", },
    { .check = 0, .gpio = 27, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_27", .name = "                                        ", },
    { .check = 0, .gpio = 28, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_28", .name = "                                        ", },
    { .check = 0, .gpio = 29, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_29", .name = "                                        ", },
    { .check = 0, .gpio = 30, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_30", .name = "                                        ", },
    { .check = 0, .gpio = 31, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_31", .name = "                                        ", },
};

#endif  // HARDWARE_SSM_GPIO_P4A_PIN_STRAP_HXX_
