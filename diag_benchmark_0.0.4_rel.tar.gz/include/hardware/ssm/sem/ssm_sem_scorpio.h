/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_SEM_SSM_SEM_SCORPIO_H_
#define HARDWARE_SSM_SEM_SSM_SEM_SCORPIO_H_

#include <string>

#include "hardware/include/ssm/sem/ssm_sem.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace sem {

class SsmSemScorpio : public SsmSem {
 public:
    explicit SsmSemScorpio(Ssm *ssm) : SsmSem(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmSemScorpio() {}

 private:
    void     ssm_sem_info_get(void *, uint32_t);
    void     sem_info_dump_addr(void *);
    void     sem_info_dump_value(void *, std::string = "");
    void     sem_rst_sw_seq(void *);
    bool     sem_get_lock(uint32_t);
    void     sem_rls_lock(uint32_t);
    void     sem_rst_lock(uint32_t);
    uint32_t sem_max_credit(void);
    void     sem_cfg_credit(uint32_t, uint32_t);
    uint32_t sem_cur_credit(uint32_t);
    void     sem_cfg_credit_lowm(uint32_t, uint32_t);
    void     sem_cfg_credit_hiwm(uint32_t, uint32_t);
    void     sem_cfg_credit_loint(uint32_t, uint32_t);
    void     sem_cfg_credit_hiint(uint32_t, uint32_t);
    void     sem_cfg_credit_vfint(uint32_t, uint32_t);
    bool     sem_get_credit_hilo_status(uint32_t, uint32_t);
    void     sem_clr_credit_hilo_interrupt(uint32_t, uint32_t);
    bool     sem_get_credit_ovfl_status(uint32_t, uint32_t);
    void     sem_clr_credit_ovfl_status(uint32_t, uint32_t);

 private:
    bool test_get_lock(uint32_t, uint32_t, uint32_t);
    bool test_rls_lock(uint32_t, uint32_t, uint32_t);
    bool test_swm_hit(ssm_sem_set_t &);
    bool test_sem_overflow(uint32_t, uint32_t, uint32_t);

 public:
    void test_mcu_semaphore_mutex_dump_addr(void);
    void test_mcu_semaphore_mutex_dump_value(void);

 public:
    bool test_sem_lock(const std::string &);
    bool test_sem_unlock(const std::string &);
    bool test_sem_hilo_wm(const std::string &);
    bool test_sem_ibint(const std::string &);
};

}  // namespace sem
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_SEM_SSM_SEM_SCORPIO_H_
