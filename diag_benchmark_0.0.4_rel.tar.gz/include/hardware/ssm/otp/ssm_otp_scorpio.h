/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_OTP_SSM_OTP_SCORPIO_H_
#define HARDWARE_SSM_OTP_SSM_OTP_SCORPIO_H_

#include <string>
#include <vector>

#include "hardware/include/ssm/otp/ssm_otp.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace otp {

class SsmOtpScorpio : public SsmOtp {
 public:
    explicit SsmOtpScorpio(Ssm *);
    ~SsmOtpScorpio() {}

 private:
    uint32_t                  m_otps_array_sz;
    SSM_OTP_INFO *            m_otps_array;
    std::string               m_otps_desc;
    std::vector<SSM_OTP_INFO> m_otps;
    bool                      m_asicvf_tbl_init;
    bool                      m_asicvf_force_up;
    ssm_vftbl_3d0_t           m_asicvf_tbl;
    bool                      m_otp_timing_applied = false;

 private:
    void         ssm_otp_data_init(void);
    uint32_t     ssm_otp_get_prog_passwd(void);
    uint32_t     ssm_otp_get_item_number(void);
    uint32_t     ssm_otp_strap_get_bsz(const std::string &);
    bool         ssm_otp_strap_supported(const std::string &);
    bool         ssm_otp_get_info_by_index(uint32_t, SSM_OTP_INFO &);
    bool         ssm_otp_get_info_by_name(const std::string &, SSM_OTP_INFO &);
    SSM_OTP_INFO ssm_otp_get_info(const std::string &);
    uint64_t     ssm_otp_sense_by_name(const std::string &);
    uint8_t      ssm_otp_sense_u8(const std::string &);
    uint16_t     ssm_otp_sense_u16(const std::string &);
    uint32_t     ssm_otp_sense_u32(const std::string &);
    uint64_t     ssm_otp_sense_u64(const std::string &);
    bool         ssm_otp_read64(const std::string &, uint32_t *, uint64_t *);
    bool         ssm_otp_progm_by_name(const std::string &, uint64_t &);
    bool         ssm_otp_sense_to_file(const std::string &);
    bool         ssm_otp_progm_by_file(uint32_t &, uint32_t &, const std::string &);
    void         ssm_otp_dump_rams_item(void);
    uint32_t     ssm_otp_ram_dw_r_by_name(const std::string &);
    bool         ssm_otp_ram_dw_r_by_name(const std::string &, uint32_t &);
    bool         ssm_otp_ram_dw_w_by_name(const std::string &, uint32_t &);
    std::string  ssm_otp_dump_ro(void);
    std::string  ssm_otp_dump_leakage(const std::string &);
    std::string  get_otp_uuid_wafer(void);
    std::string  get_otp_uuid_hwdist_src(void);
    std::string  get_otp_uuid_hwdist_ram(void);
    std::string  get_otp_uuid_hwdist_dst(void);
    uint16_t     ssm_otp_crc_calc16(const std::string &, uint32_t = SSM_MAGIC);
    void         ssm_otp_ram_r_dw_buf(uint32_t *, uint32_t, uint32_t = 0U);
    void         ssm_otp_ram_w_dw_buf(uint32_t *, uint32_t, uint32_t = 0U);
    std::string  ssm_otp_sense_bits(uint32_t, uint32_t);
    void         ssm_otp_progm_bits(uint32_t, uint32_t, uint64_t);
    uint32_t     ssm_otp_sense_by_row(uint32_t);
    void         ssm_otp_sense_by_rows(uint32_t, uint32_t);
    void         ssm_otp_sense_by_rows(uint32_t, uint32_t, uint32_t *);
    void         ssm_otp_sense_by_rows(void);
    void         ssm_otp_sense_to_rams(uint32_t, uint32_t);
    void         ssm_otp_sense_to_rams(void);

 private:
    uint32_t otp_sense_macro_dw2ram(uint32_t);
    uint32_t otp_sense_macro_dw2reg(uint32_t);
    void     otp_progm_macro_ram2dw(uint32_t, uint32_t);
    void     otp_progm_macro_reg2dw(uint32_t, uint32_t);
    bool     otp_status_in_active(void);
    bool     otp_status_in_standby(void);
    bool     otp_being_set_active(void);
    bool     otp_being_set_standby(void);
    bool     otp_init_is_busy(void);
    void     otp_status_force_awake(void);
    void     otp_status_force_standby(void);

 private:
    void        otp_fsm_set_timing(void);
    bool        otp_fsm_get_timing_in_25(void);
    bool        otp_fsm_get_timing_in_1g(void);
    void        otp_fsm_set_timing_init(uint32_t);
    std::string otp_fsm_get_timing_init(void);
    void        otp_fsm_set_timing_read(uint32_t);
    std::string otp_fsm_get_timing_read(void);
    void        otp_fsm_set_timing_prog(uint32_t);
    std::string otp_fsm_get_timing_prog(void);
    uint32_t    otp_fsm_get_stat_standby(void);
    uint32_t    otp_fsm_get_stat_awake(void);
    void        otp_fsm_set_stat(bool);
    uint32_t    otp_fsm_get_init_busy(void);
    uint32_t    otp_fsm_get_init_active(void);
    void        otp_fsm_wat_init_idle(void);
    void        otp_fsm_wat_op_on(void);
    void        otp_fsm_wat_op_off(void);
    void        otp_fsm_set_read_dst_ram_main_array(void);
    void        otp_fsm_set_read_dst_reg_main_array(void);
    void        otp_fsm_set_read_addr_dw(uint32_t, uint32_t = 1U);
    void        otp_fsm_set_read_addr(uint32_t, uint32_t);
    void        otp_fsm_set_read_start(void);
    void        otp_fsm_clr_read_start(void);
    uint32_t    otp_fsm_get_read_ptm(void);
    void        otp_fsm_set_read_ptm(uint32_t);
    void        otp_fsm_wat_read_idle(void);
    void        otp_fsm_wat_read_done(void);
    void        otp_fsm_clr_read_done(void);
    uint32_t    otp_fsm_get_read_dst_reg_data(void);
    void        otp_fsm_set_prog_src_ram_main_prcp(void);
    void        otp_fsm_set_prog_src_ram_main_rddc(void);
    void        otp_fsm_set_prog_src_reg_main_prcp(void);
    void        otp_fsm_set_prog_src_reg_main_rddc(void);
    void        otp_fsm_set_prog_addr_dw(uint32_t, uint32_t = 1U);
    void        otp_fsm_set_prog_addr(uint32_t, uint32_t);
    void        otp_fsm_set_prog_start(void);
    void        otp_fsm_clr_prog_start(void);
    void        otp_fsm_wat_prog_idle(void);
    void        otp_fsm_wat_prog_done(void);
    void        otp_fsm_clr_prog_done(void);
    void        otp_fsm_set_prog_src_reg_data(uint32_t);
    void        otp_fsm_set_prog_prot_en(void);
    void        otp_fsm_clr_prog_prot_en(void);

 public:
    bool     test_otp_ram_pattern_wrcr(void);
    bool     test_otp_sense_macro_dw2ram_o_dw2reg(void);
    bool     test_otp_progm_ram2macro_dw(void);
    bool     test_otp_progm_reg2macro_dw(void);
    bool     test_otp_progm_bits_sweep(void);
    bool     test_otp_golden_crc(void);
    bool     test_otp_vftbl_valid(void);
    bool     test_otp_fixed_valid(void);
    bool     test_otp_idsku_valid(void);
    bool     test_otp_bcode_valid(void);
    bool     test_otp_hdist_valid(void);
    uint32_t sw_seq_asicvf_lv2dpmlv(uint32_t);
    uint32_t sw_seq_sweep_asicvf_min(uint32_t);
    uint32_t sw_seq_sweep_asicvf_max(uint32_t);
    uint32_t sw_seq_sweep_asicvf(uint32_t, uint32_t);
    uint32_t get_otp_dtu_fmin(void);
    uint32_t get_otp_dtu_fmax(void);

 private:
    bool     set_asicvf_table_init_sku1(void *);
    bool     set_asicvf_table_init_sku2(void *);
    bool     set_asicvf_table_init(void *);
    void *   get_asicvf_table(void);
    uint32_t get_asicvf_level(void);
    void     set_asicvf_level(uint32_t);
    uint32_t get_asicvf_level_min(void);
    uint32_t get_asicvf_level_max(void);
    uint32_t get_asicvf_level_vapp(uint32_t);

 private:
    typedef struct _otp_uuid {
        char u821xchar(uint8_t d) {
            if (0xFF == d) {
                return 'F';  // 1x ret
            }
            return static_cast<char>(std::isprint(d) ? d : '0');
        }
        std::string u822xint(uint8_t d) {
            if (0xFF == d) {
                return "FF";  // 2x ret
            }
            std::stringstream int_s("");  // initial clear
            int_s << std::setfill('0') << std::setw(2) << static_cast<int>(d);
            return int_s.str();
        }
        std::string fmt(void) {
            /**
             * UUID vs OTP WAFFER_LOT_X INFO MAAPING
             * +------------------------------------------------------------------------------+
             * |UUID_31_0   [31           24|23           16|15            8|7             0] |
             * |            [WAFER_LOT_Char4|WAFER_LOT_Char3|WAFER_LOT_Char2|WAFER_LOT_Char1] |
             * +------------------------------------------------------------------------------+
             * |UUID_63_32  [31           24|23           16|15            8|7             0] |
             * |            [WAFER_LOT_Char8|WAFER_LOT_Char7|WAFER_LOT_Char6|WAFER_LOT_Char5] |
             * +------------------------------------------------------------------------------+
             * |UUID_95_64  [31           24|23           16|15            8|7             0] |
             * |            [             NA|          DIE_Y|          DIE_X|       WAFER_ID] |
             * +------------------------------------------------------------------------------+
             * |UUID_127_96 [31           24|23           16|15            8|7             0] |
             * |            [             NA|             NA|             NA|             NA] |
             * +------------------------------------------------------------------------------+
             */
            std::string asic_uuid = {};

            asic_uuid.push_back(u821xchar(u31_00.b.b0));  // WAFER_LOT_Char1
            asic_uuid.push_back(u821xchar(u31_00.b.b1));  // WAFER_LOT_Char2
            asic_uuid.push_back(u821xchar(u31_00.b.b2));  // WAFER_LOT_Char3
            asic_uuid.push_back(u821xchar(u31_00.b.b3));  // WAFER_LOT_Char4
            asic_uuid.push_back(u821xchar(u63_32.b.b0));  // WAFER_LOT_Char5
            asic_uuid.push_back(u821xchar(u63_32.b.b1));  // WAFER_LOT_Char6
            asic_uuid.append(u822xint(u95_64.b.b0));      // WAFER_ID
            asic_uuid.append(u822xint(u95_64.b.b1));      // DIE_X
            asic_uuid.append(u822xint(u95_64.b.b2));      // DIE_Y

            return asic_uuid;
        }

        SSM_U32_u u31_00;
        SSM_U32_u u63_32;
        SSM_U32_u u95_64;
        SSM_U32_u u127_96;
    } otp_uuid_t;

 public:
    bool test_otp_golden_fotp(void);

 public:
    std::string handle_req_otp_status(void);
    std::string handle_req_otp_pstate(const std::string &);
    bool        handle_req_otp_hwdist(void);
    bool        handle_req_otp_crc(const std::string &, const std::string &);
    bool        handle_req_otp_crc_calc(const std::string &, const std::string &);
    bool        handle_req_otp_crc_check(const std::string &);
    bool        handle_req_otp_test(const std::string &, const std::string &);
    std::string handle_req_otp_timing(const std::string &, const std::string &);
    void        handle_req_otp_sense_bits(uint32_t, uint32_t);
    bool        handle_req_otp_vftbl_dump(const std::string &);
};

}  // namespace otp
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_OTP_SSM_OTP_SCORPIO_H_
