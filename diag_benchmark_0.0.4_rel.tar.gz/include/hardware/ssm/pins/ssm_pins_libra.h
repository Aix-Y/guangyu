/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_PINS_SSM_PINS_LIBRA_H_
#define HARDWARE_SSM_PINS_SSM_PINS_LIBRA_H_

#include <string>

#include "hardware/include/ssm/pins/ssm_pins.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace pins {

class SsmPinsLibra : public SsmPins {
 public:
    explicit SsmPinsLibra(Ssm *ssm) : SsmPins(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmPinsLibra() {}

 public:
    bool handle_req_edc_op(const std::string &);
    bool handle_req_ldidt_op(const std::string &);
    bool handle_req_pins_set(const std::string &);
    bool handle_req_pins_set(const std::string &, const std::string &);
    bool handle_req_pins_set(const std::string &, uint32_t &, uint32_t &);
};

}  // namespace pins
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_PINS_SSM_PINS_LIBRA_H_
