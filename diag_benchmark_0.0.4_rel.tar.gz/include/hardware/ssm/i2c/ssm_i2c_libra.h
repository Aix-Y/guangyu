/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_I2C_SSM_I2C_LIBRA_H_
#define HARDWARE_SSM_I2C_SSM_I2C_LIBRA_H_

#include <string>

#include "hardware/include/ssm/i2c/ssm_i2c.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace i2c {

class SsmI2cLibra : public SsmI2c {
 public:
    explicit SsmI2cLibra(Ssm *ssm) : SsmI2c(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmI2cLibra() {}

 private:
    uint32_t board_type(void);
    bool     is_tasic_type(uint32_t);
    bool     is_t1412_type(uint32_t);

 public:
    bool        is_i2c_supported(uint32_t);
    uint32_t    i2c_name_to_id(const std::string &);
    std::string i2c_id_to_name(const uint32_t &);
    std::string i2c_id_2str(const uint32_t &);
    bool        chk_tid_valid(uint32_t);
    std::string get_i2c_name(uint32_t);
    std::string get_i2c_phyloc(uint32_t);
    uint32_t    get_i2c_fwgrp(const std::string &);
    uint32_t    get_i2c_fwgrp(uint32_t);
    uint32_t    get_i2c_fwidx(const std::string &);
    uint32_t    get_i2c_fwidx(uint32_t);
    double      get_i2c_temp(const std::string &);
    double      get_i2c_temp(uint32_t);
    double      get_i2c_temp_enum(uint32_t);
    double      get_i2c_temp_asic(uint32_t);
    double      get_i2c_temp_fan(void);
    double      get_i2c_temp_board(void);
    double      get_i2c_hotspot(void);
    double      get_asic_hotspot(void);
    void        set_i2c_thres_alert(uint32_t, uint32_t);

 private:
    bool        i2c_apb_init(uint32_t, uint32_t, uint32_t);
    bool        i2c_apb_is_ic_ena(uint32_t);
    bool        i2c_apb_is_rx_data_lost(uint32_t);
    bool        i2c_apb_is_slv_dis_on_busy(uint32_t);
    bool        i2c_apb_is_slv_addr_rsvd(uint32_t);
    bool        i2c_apb_is_mst(uint32_t);
    bool        i2c_apb_is_slv(uint32_t);
    bool        i2c_apb_is_idle(uint32_t);
    bool        i2c_apb_is_busy(uint32_t);
    bool        i2c_apb_is_tx_fifo_full(uint32_t);
    bool        i2c_apb_is_tx_fifo_empty(uint32_t);
    bool        i2c_apb_is_rx_fifo_empty(uint32_t);
    bool        i2c_apb_is_rx_fifo_full(uint32_t);
    bool        i2c_apb_is_mst_sda_rec_active(uint32_t);
    uint32_t    i2c_apb_tx_fifo_nx_entry(uint32_t);
    uint32_t    i2c_apb_rx_fifo_nx_entry(uint32_t);
    uint32_t    i2c_apb_ic_status_get(uint32_t);
    std::string i2c_apb_ic_status_dec(uint32_t &);
    uint32_t    i2c_apb_smbus_udid_get(uint32_t);
    uint32_t    i2c_apb_comp_param1_get(uint32_t);
    uint32_t    i2c_apb_comp_ver_get(uint32_t);
    uint32_t    i2c_apb_comp_type_get(uint32_t);
    uint32_t    i2c_apb_sda_rx_hold_get(uint32_t);
    void        i2c_apb_sda_rx_hold_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_sda_tx_hold_get(uint32_t);
    void        i2c_apb_sda_tx_hold_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_sda_setup_get(uint32_t);
    void        i2c_apb_sda_setup_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_spklen_get(uint32_t);
    void        i2c_apb_spklen_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_scl_tout_get(uint32_t);
    void        i2c_apb_scl_tout_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_sda_tout_get(uint32_t);
    void        i2c_apb_sda_tout_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_enable_get(uint32_t);
    void        i2c_apb_enable_set_en(uint32_t, uint32_t);
    uint32_t    i2c_apb_con_get(uint32_t);
    void        i2c_apb_con_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_tar_get(uint32_t);
    void        i2c_apb_tar_set_addr(uint32_t, uint32_t);
    uint32_t    i2c_apb_tar_get_addr(uint32_t);
    uint32_t    i2c_apb_sar_get(uint32_t);
    void        i2c_apb_sar_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_sar_opt_get(uint32_t);
    uint32_t    i2c_apb_ss_scl_hcnt_get(uint32_t);
    void        i2c_apb_ss_scl_hcnt_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_ss_scl_lcnt_get(uint32_t);
    void        i2c_apb_ss_scl_lcnt_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_fs_scl_hcnt_get(uint32_t);
    void        i2c_apb_fs_scl_hcnt_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_fs_scl_lcnt_get(uint32_t);
    void        i2c_apb_fs_scl_lcnt_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_intr_stat_get(uint32_t);
    uint32_t    i2c_apb_intr_mask_get(uint32_t);
    void        i2c_apb_intr_mask_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_intr_stat_raw_get(uint32_t);
    uint32_t    i2c_apb_intr_clr_combine(uint32_t);
    uint32_t    i2c_apb_intr_clr_rx_under(uint32_t);
    uint32_t    i2c_apb_intr_clr_rx_over(uint32_t);
    uint32_t    i2c_apb_intr_clr_tx_over(uint32_t);
    uint32_t    i2c_apb_intr_clr_rd_req(uint32_t);
    uint32_t    i2c_apb_intr_clr_tx_abrt(uint32_t);
    uint32_t    i2c_apb_intr_clr_rx_done(uint32_t);
    uint32_t    i2c_apb_intr_clr_activity(uint32_t);
    uint32_t    i2c_apb_intr_clr_stop_det(uint32_t);
    uint32_t    i2c_apb_intr_clr_start_det(uint32_t);
    uint32_t    i2c_apb_intr_clr_gen_call(uint32_t);
    uint32_t    i2c_apb_intr_clr_scl_stuck(uint32_t);
    uint32_t    i2c_apb_intr_clr_smbus_intr(uint32_t);
    std::string i2c_apb_intr_clr_all(uint32_t);
    uint32_t    i2c_apb_rx_tl_get(uint32_t);
    void        i2c_apb_rx_tl_set(uint32_t, uint32_t);
    uint32_t    i2c_apb_tx_tl_get(uint32_t);
    void        i2c_apb_tx_tl_set(uint32_t, uint32_t);
    bool        i2c_apb_is_enable(uint32_t &);
    bool        i2c_apb_is_trans_abort(uint32_t &);
    bool        i2c_apb_is_mst_tx_blocked(uint32_t &);
    bool        i2c_apb_is_mst_sda_rec_ongoing(uint32_t &);
    bool        i2c_apb_is_mst_smbus_reset_slv(uint32_t &);
    bool        i2c_apb_is_mst_smbus_suspend_on(uint32_t &);
    bool        i2c_apb_is_slv_smbus_alert_on(uint32_t &);
    bool        i2c_apb_con_is_mst(uint32_t &);
    bool        i2c_apb_con_is_slv(uint32_t &);
    bool        i2c_apb_con_speed_is_std(uint32_t &);
    bool        i2c_apb_con_speed_is_fast(uint32_t &);
    bool        i2c_apb_con_speed_is_high(uint32_t &);
    bool        i2c_apb_con_slv_addr_is7x(uint32_t &);
    bool        i2c_apb_con_slv_addr_is10x(uint32_t &);
    bool        i2c_apb_con_mst_addr_is7x(uint32_t &);
    bool        i2c_apb_con_mst_addr_is10x(uint32_t &);
    bool        i2c_apb_con_mst_restart_ena(uint32_t &);
    bool        i2c_apb_con_slv_disabled(uint32_t &);
    bool        i2c_apb_con_slv_opt_sar_ena(uint32_t &);
    bool        i2c_apb_con_slv_smbus_quick_en(uint32_t &);
    bool        i2c_apb_con_slv_smbus_arp_en(uint32_t &);
    bool        i2c_apb_con_slv_smbus_addr_psist(uint32_t &);
    uint32_t    i2c_apb_tar_addr_get(uint32_t &);
    uint32_t    i2c_apb_sar_addr_get(uint32_t &);
    bool        i2c_apb_intr_is_err(uint32_t &);
    std::string i2c_apb_intr_dec(uint32_t &);
    uint32_t    i2c_apb_tx_abort_src_get(uint32_t);
    std::string i2c_apb_tx_abort_src_dec(uint32_t &);
    uint32_t    i2c_apb_data_cmd_get(uint32_t);
    void        i2c_apb_data_cmd_set(uint32_t, uint32_t);
    bool        i2c_trans_wait_idle(ssm_i2c_trans_t &, uint64_t, std::string);
    bool        i2c_trans_wait_tx_fifo_nfull(ssm_i2c_trans_t &, uint64_t, std::string);
    bool        i2c_trans_wait_tx_fifo_empty(ssm_i2c_trans_t &, uint64_t, std::string);
    bool        i2c_trans_wait_rx_fifo_nempty(ssm_i2c_trans_t &, uint64_t, std::string);
    bool        i2c_trans_error_exist(ssm_i2c_trans_t &, std::string);
    bool        i2c_trans_apply_tar(ssm_i2c_trans_t &);
    bool        i2c_trans_rx(ssm_i2c_trans_t &);
    bool        i2c_trans_tx(ssm_i2c_trans_t &);
    bool        i2c_trans(ssm_i2c_trans_t &, bool, bool, bool, uint8_t = 0);

 private:
    uint32_t ssm_i2c_get_ic_pid(uint32_t);
    uint32_t ssm_i2c_get_ic_mid(uint32_t);

 public:
    std::string ttgt_get_p_asic_pwr(void);
    std::string ttgt_get_p_volt_min(void);
    std::string ttgt_get_p_volt_max(void);
    std::string ttgt_get_p_volt_step(void);
    double      ttgt_get_p_asic_ave(void);
    void        ttgt_off_feat(void);
    void        ttgt_set_volt(double, bool);
    void        ttgt_set_cmin(void);
    bool        test_i2c_check_ic_did(void);
    bool        test_i2c_each_t_ave_dvi(void);
    bool        test_i2c_each_t_ave_dvi_mixed(void);
    bool        test_i2c_each_t_in_range(void);
    bool        test_i2c_golden_tsensor(void);

 public:
    void        handle_req_i2c_apb_status(const std::string &);
    bool        handle_req_i2c_apb_init(const std::string &);
    void        handle_req_i2c_apb_int_clr(const std::string &);
    bool        handle_req_i2c_apb_read(const std::string &);
    bool        handle_req_i2c_apb_write(const std::string &);
    bool        handle_req_i2c_apb_scan(const std::string &);
    std::string handle_tool_req_get_str(const std::string &);
    std::string handle_tool_req_get_str(const std::string &, const std::string &);
    bool        handle_req_i2c_tdiode(const std::string &);
    std::string handle_req_i2c_dump(const std::string &);
    bool        handle_req_thm_list(void);

 private:
    double m_ttgt_asic_ave = 0;
};

}  // namespace i2c
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_I2C_SSM_I2C_LIBRA_H_
