/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_SPI_SSM_SPI_PAVO_H_
#define HARDWARE_SSM_SPI_SSM_SPI_PAVO_H_

#include "hardware/include/ssm/spi/ssm_spi.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace spi {

class SsmSpiPavo : public SsmSpi {
 public:
    explicit SsmSpiPavo(Ssm *ssm) : SsmSpi(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmSpiPavo() {}
};

}  // namespace spi
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_SPI_SSM_SPI_PAVO_H_
