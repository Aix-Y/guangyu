/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_FIW_SSM_FIW_LIBRA_H_
#define HARDWARE_SSM_FIW_SSM_FIW_LIBRA_H_

#include <string>

#include "hardware/include/ssm/fiw/ssm_fiw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace fiw {

class SsmFiwLibra : public SsmFiw {
 public:
    explicit SsmFiwLibra(Ssm *ssm) : SsmFiw(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmFiwLibra() {}

 private:
    bool test_sa_raf_access_block_ram_r(const std::string &);
    bool test_sa_raf_access_block_ram_w(const std::string &);
    bool test_sa_raf_access_block_range_r(uint32_t, uint32_t);
    bool test_sa_raf_access_block_range_w(uint32_t, uint32_t);
    bool test_sa_raf_access_block_switch(void);

 public:
    bool test_sa_raf_reg_acc_flt(const std::string &);
};

}  // namespace fiw
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_FIW_SSM_FIW_LIBRA_H_
