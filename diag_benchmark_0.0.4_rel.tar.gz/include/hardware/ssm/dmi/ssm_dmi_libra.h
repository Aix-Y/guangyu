/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_DMI_SSM_DMI_LIBRA_H_
#define HARDWARE_SSM_DMI_SSM_DMI_LIBRA_H_

#include <string>

#include "hardware/include/ssm/dmi/ssm_dmi.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace dmi {

class SsmDmiLibra : public SsmDmi {
 public:
    explicit SsmDmiLibra(Ssm *ssm) : SsmDmi(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmDmiLibra() {}

 public:
    bool        is_imu_supported(uint32_t);
    bool        is_dmi_supported(uint32_t);
    uint32_t    dmi_name_to_id(const std::string &);
    std::string dmi_id_to_name(const uint32_t &);
    std::string dmi_id_2str(const uint32_t &);
    bool        chk_tid_valid(uint32_t);
    std::string get_dmi_name(uint32_t);
    std::string get_dmi_phyloc(uint32_t);
    uint32_t    get_dmi_fwgrp(const std::string &);
    uint32_t    get_dmi_fwgrp(uint32_t);
    uint32_t    get_dmi_fwidx(const std::string &);
    uint32_t    get_dmi_fwidx(uint32_t);
    double      get_dmi_temp(const std::string &);
    double      get_dmi_temp(uint32_t);
    double      get_dmi_temp_enum(uint32_t);
    void        get_dmi_rma_status(void *);
    bool        get_dmi_rma_flag(void);
    bool        get_hbm_swizzle_stat(void);
    void        set_hbm_swizzle_stat(bool);

 private:
    std::string rma_type_2str(uint32_t);
    std::string rma_entry_2str(uint64_t);

 public:
    bool test_dmi_each_t_ave_dvi(void);
    bool test_dmi_each_t_ave_dvi_mixed(void);
    bool test_dmi_each_t_in_range(void);

 public:
    bool handle_req_ssm_ecc(const std::string &);
    bool handle_req_ssm_rma(const std::string &, const std::string &);
};

}  // namespace dmi
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_DMI_SSM_DMI_LIBRA_H_
