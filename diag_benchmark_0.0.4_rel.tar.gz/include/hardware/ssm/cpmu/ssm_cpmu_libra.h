/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_CPMU_SSM_CPMU_LIBRA_H_
#define HARDWARE_SSM_CPMU_SSM_CPMU_LIBRA_H_

#include "hardware/include/ssm/cpmu/ssm_cpmu.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace cpmu {

class SsmCpmuLibra : public SsmCpmu {
 public:
    explicit SsmCpmuLibra(Ssm *ssm) : SsmCpmu(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmCpmuLibra() {}
};

}  // namespace cpmu
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_CPMU_SSM_CPMU_LIBRA_H_
