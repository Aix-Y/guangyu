/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_CPMU_SSM_CPMU_SCORPIO_H_
#define HARDWARE_SSM_CPMU_SSM_CPMU_SCORPIO_H_

#include "hardware/include/ssm/cpmu/ssm_cpmu.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace cpmu {

class SsmCpmuScorpio : public SsmCpmu {
 public:
    explicit SsmCpmuScorpio(Ssm *ssm) : SsmCpmu(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmCpmuScorpio() {}
};

}  // namespace cpmu
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_CPMU_SSM_CPMU_SCORPIO_H_
