/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_MISC_SSM_MISC_PAVO_H_
#define HARDWARE_SSM_MISC_SSM_MISC_PAVO_H_

#include "hardware/include/ssm/misc/ssm_misc.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace misc {

class SsmMiscPavo : public SsmMisc {
 public:
    explicit SsmMiscPavo(Ssm *ssm) : SsmMisc(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmMiscPavo() {}

 public:
    bool     dbg_test(uint32_t, uint32_t);
    uint32_t dbg_interface(uint32_t, uint32_t, uint32_t, uint64_t = 0);
    uint32_t drv_interface(uint32_t, uint32_t, uint32_t, uint64_t = 0);
};

}  // namespace misc
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_MISC_SSM_MISC_PAVO_H_
