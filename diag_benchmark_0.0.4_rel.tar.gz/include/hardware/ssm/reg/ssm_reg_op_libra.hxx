/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_REG_SSM_REG_OP_LIBRA_HXX_
#define HARDWARE_SSM_REG_SSM_REG_OP_LIBRA_HXX_

#include "device/dtus/libra/data_fabric.h"
#include "device/dtus/libra/register_soc.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////
// MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED
//////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * refer device/dtus/proj/plat_stage/hwt_xxx_x_x_x
 * L0 | e.g.  __hwtree_obj_die (hw_soc_,  SUB_SOC_REGMODEL, id-diex)
 * L1 | e.g.  __hwtree_obj_hw  (hw_die_,      SSM_REGMODEL, id-inst)
 * L2 | e.g.  __hwtree_obj_hw  (hw_obj_l1,        SSM_REGS, id-inst)
 */

#define __hwtree_obj_die(_obj_soc, _l0, _id)                                    \
({                                                                              \
    Hardware *_obj_die = nullptr;                                               \
    if (((0 == (_id)) || (1 == (_id))) &&                                       \
        (nullptr != (_obj_soc)) &&                                              \
        (true)) {                                                               \
        _obj_die = (_obj_soc)->Get(#_l0, (_id));                                \
    }                                                                           \
    (_obj_die);                                                                 \
})

#define __hwtree_obj_hw(_obj_die, _lx, _id)                                     \
({                                                                              \
    Hardware *_obj_hw = nullptr;                                                \
    if (nullptr != (_obj_die)) {                                                \
        _obj_hw = (_obj_die)->Get(#_lx, (_id));                                 \
    }                                                                           \
    (_obj_hw);                                                                  \
})

#define __hwtree_die_ssm(_obj_soc, _id)                                         \
({                                                                              \
    Hardware * _ssm_x = nullptr;                                                \
    Hardware * _die_x = __hwtree_obj_die((_obj_soc), SUB_SOC_REGMODEL, (_id));  \
    if (nullptr != _die_x) {                                                    \
        _ssm_x = __hwtree_obj_hw(_die_x, SSM_REGMODEL, 0);                      \
    }                                                                           \
    (_ssm_x);                                                                   \
})

#define __hwtree_obj_addr_l0(_obj_hw) ((_obj_hw) ? ((_obj_hw)->ecf_addr_) : ~0)
#define __hwtree_obj_addr_l1(_obj_hw, _l1, _id)                                 \
({                                                                              \
    Hardware * _obj_l1 = __hwtree_obj_hw(_obj_hw, _l1, _id);                    \
    (__hwtree_obj_addr_l0(_obj_l1));                                            \
})
#define __hwtree_obj_addr_l2(_obj_hw, _l1, _l2, _id1, _id2)                     \
({                                                                              \
    Hardware * _obj_l1 = __hwtree_obj_hw(_obj_hw, _l1, _id1);                   \
    Hardware * _obj_l2 = __hwtree_obj_hw(_obj_l1, _l2, _id2);                   \
    (__hwtree_obj_addr_l0(_obj_l2));                                            \
})

#define ECF_ADDR_SSM_BASE0(_ssm)                (__hwtree_obj_addr_l0(_ssm))
#define ECF_ADDR_SSM_SA(_ssm)                   (__hwtree_obj_addr_l1(_ssm, SSM_SYSTEM_ADAPTER_REGMODEL, 0))
#define ECF_ADDR_SSM_CLK0_0(_ssm)               (__hwtree_obj_addr_l1(_ssm, CLK0_REGMODEL, 0))
#define ECF_ADDR_SSM_CLK2_0(_ssm)               (__hwtree_obj_addr_l1(_ssm, CLK2_REGMODEL, 0))
#define ECF_ADDR_SSM_CLK2_1(_ssm)               (__hwtree_obj_addr_l1(_ssm, CLK2_REGMODEL, 1))
#define ECF_ADDR_SSM_CLK2_2(_ssm)               (__hwtree_obj_addr_l1(_ssm, CLK2_REGMODEL, 2))
#define ECF_ADDR_SSM_CLK2_3(_ssm)               (__hwtree_obj_addr_l1(_ssm, CLK2_REGMODEL, 3))
#define ECF_ADDR_SSM_CLK3_0(_ssm)               (__hwtree_obj_addr_l1(_ssm, CLK3_REGMODEL, 0))
#define ECF_ADDR_SSM_CLK3_1(_ssm)               (__hwtree_obj_addr_l1(_ssm, CLK3_REGMODEL, 1))
#define ECF_ADDR_SSM_CLK3_2(_ssm)               (__hwtree_obj_addr_l1(_ssm, CLK3_REGMODEL, 2))
#define ECF_ADDR_SSM_I2C0(_ssm)                 (__hwtree_obj_addr_l1(_ssm, DW_APB_I2C,    0))
#define ECF_ADDR_SSM_I2C1(_ssm)                 (__hwtree_obj_addr_l1(_ssm, DW_APB_I2C,    1))
#define ECF_ADDR_SSM_I2C2(_ssm)                 (__hwtree_obj_addr_l1(_ssm, DW_APB_I2C,    2))
#define ECF_ADDR_SSM_I2C3(_ssm)                 (__hwtree_obj_addr_l1(_ssm, DW_APB_I2C,    3))
#define ECF_ADDR_SSM_I2C4(_ssm)                 (__hwtree_obj_addr_l1(_ssm, DW_APB_I2C,    4))
#define ECF_ADDR_SSM_UART0(_ssm)                (__hwtree_obj_addr_l1(_ssm, DW_APB_UART,   0))
#define ECF_ADDR_SSM_UART1(_ssm)                (__hwtree_obj_addr_l1(_ssm, DW_APB_UART,   1))
#define ECF_ADDR_SSM_SSI0(_ssm)                 (__hwtree_obj_addr_l1(_ssm, DW_APB_SSI,    0))
#define ECF_ADDR_SSM_OTP0(_ssm)                 (__hwtree_obj_addr_l1(_ssm, OTP_REGMODEL,  0))
#define ECF_ADDR_SSM_UCIE0(_ssm)                (__hwtree_obj_addr_l1(_ssm, UCIE_REGMODEL, 0))
#define ECF_ADDR_SSM_SE0(_ssm)                  (__hwtree_obj_addr_l2(_ssm, SE_REGMODEL, SE_REGS,  0, 0))
#define ECF_ADDR_SSM_SE0_RSA0(_ssm)             (__hwtree_obj_addr_l2(_ssm, SE_REGMODEL, RSA_REGS, 0, 0))
#define ECF_ADDR_SSM_SE0_SHA0(_ssm)             (__hwtree_obj_addr_l2(_ssm, SE_REGMODEL, SHA_REGS, 0, 0))
#define ECF_ADDR_SSM_SE0_AES0(_ssm)             (__hwtree_obj_addr_l2(_ssm, SE_REGMODEL, AES_REGS, 0, 0))
#define ECF_ADDR_SSM_MDMA0(_ssm)                (__hwtree_obj_addr_l1(_ssm, MDMA_LITE_REGMODEL, 0))
#define ECF_ADDR_SSM_MIH(_ssm)                  (__hwtree_obj_addr_l1(_ssm, MIH_REGMODEL, 0))
#define ECF_ADDR_SSM_REG(_ssm)                  (__hwtree_obj_addr_l1(_ssm, SSM_REGS, 0))
#define ECF_ADDR_SSM_MCU(_ssm)                  (__hwtree_obj_addr_l1(_ssm, SSM_MCU_REGMODEL, 0))

#define ECF_ADDR_SSM_ODTE_SM4_XTS(_ssm)         (__hwtree_obj_addr_l0(_ssm) + 0x12000U)
#define ECF_ADDR_SSM_SMEM0(_ssm)                (__hwtree_obj_addr_l0(_ssm) + 0x18000U + 0x8000U * 0)
#define ECF_ADDR_SSM_SMEM1(_ssm)                (__hwtree_obj_addr_l0(_ssm) + 0x18000U + 0x8000U * 1)
#define ECF_ADDR_SSM_SMEM2(_ssm)                (__hwtree_obj_addr_l0(_ssm) + 0x18000U + 0x8000U * 2)
#define ECF_ADDR_SSM_SMEM3(_ssm)                (__hwtree_obj_addr_l0(_ssm) + 0x18000U + 0x8000U * 3)
#define ECF_ADDR_SSM_SMEM4(_ssm)                (__hwtree_obj_addr_l0(_ssm) + 0x18000U + 0x8000U * 4)
#define ECF_ADDR_SSM_SMEM5(_ssm)                (__hwtree_obj_addr_l0(_ssm) + 0x18000U + 0x8000U * 5)
#define ECF_ADDR_SSM_BOOT(_ssm)                 (ECF_ADDR_SSM_SMEM0(_ssm))
#define ECF_ADDR_SSM_DLS(_ssm)                  (__hwtree_obj_addr_l0(_ssm) + 0x50000U)
#define ECF_ADDR_SSM_OTPM0(_ssm)                (__hwtree_obj_addr_l0(_ssm) + 0x6200U)

//////////////////////////////////////////////////////////////////////////////////////////////////////
// MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED
//////////////////////////////////////////////////////////////////////////////////////////////////////

#include "hardware/include/ssm/reg/ssm_reg_op.hxx"

// per asic capbility macros
#define regr32_clk00(_reg)               (regr32_clk(0, 0, _reg))
#define regw32_clk00(_reg, _val)         (regw32_clk(0, 0, _reg, (_val)))
#define regr32f_clk00(_reg, _f)          (regr32f_clk(0, 0, _reg, _f))
#define regw32f_clk00(_reg, _f, _fv)     (regw32f_clk(0, 0, _reg, _f, (_fv)))

#define regr32_clk10(_reg)               (regr32_clk(1, 0, _reg))
#define regw32_clk10(_reg, _val)         (regw32_clk(1, 0, _reg, (_val)))
#define regr32f_clk10(_reg, _f)          (regr32f_clk(1, 0, _reg, _f))
#define regw32f_clk10(_reg, _f, _fv)     (regw32f_clk(1, 0, _reg, _f, (_fv)))

#define regr32_clk11(_reg)               (regr32_clk(1, 1, _reg))
#define regw32_clk11(_reg, _val)         (regw32_clk(1, 1, _reg, (_val)))
#define regr32f_clk11(_reg, _f)          (regr32f_clk(1, 1, _reg, _f))
#define regw32f_clk11(_reg, _f, _fv)     (regw32f_clk(1, 1, _reg, _f, (_fv)))

#define regr32_clk20(_reg)               (regr32_clk(2, 0, _reg))
#define regw32_clk20(_reg, _val)         (regw32_clk(2, 0, _reg, (_val)))
#define regr32f_clk20(_reg, _f)          (regr32f_clk(2, 0, _reg, _f))
#define regw32f_clk20(_reg, _f, _fv)     (regw32f_clk(2, 0, _reg, _f, (_fv)))

#define regr32_clk21(_reg)               (regr32_clk(2, 1, _reg))
#define regw32_clk21(_reg, _val)         (regw32_clk(2, 1, _reg, (_val)))
#define regr32f_clk21(_reg, _f)          (regr32f_clk(2, 1, _reg, _f))
#define regw32f_clk21(_reg, _f, _fv)     (regw32f_clk(2, 1, _reg, _f, (_fv)))

#define regr32_clk22(_reg)               (regr32_clk(2, 2, _reg))
#define regw32_clk22(_reg, _val)         (regw32_clk(2, 2, _reg, (_val)))
#define regr32f_clk22(_reg, _f)          (regr32f_clk(2, 2, _reg, _f))
#define regw32f_clk22(_reg, _f, _fv)     (regw32f_clk(2, 2, _reg, _f, (_fv)))

#define regr32_clk23(_reg)               (regr32_clk(2, 3, _reg))
#define regw32_clk23(_reg, _val)         (regw32_clk(2, 3, _reg, (_val)))
#define regr32f_clk23(_reg, _f)          (regr32f_clk(2, 3, _reg, _f))
#define regw32f_clk23(_reg, _f, _fv)     (regw32f_clk(2, 3, _reg, _f, (_fv)))

#define regr32_clk24(_reg)               (regr32_clk(2, 4, _reg))
#define regw32_clk24(_reg, _val)         (regw32_clk(2, 4, _reg, (_val)))
#define regr32f_clk24(_reg, _f)          (regr32f_clk(2, 4, _reg, _f))
#define regw32f_clk24(_reg, _f, _fv)     (regw32f_clk(2, 4, _reg, _f, (_fv)))

#define regr32_clk30(_reg)               (regr32_clk(3, 0, _reg))
#define regw32_clk30(_reg, _val)         (regw32_clk(3, 0, _reg, (_val)))
#define regr32f_clk30(_reg, _f)          (regr32f_clk(3, 0, _reg, _f))
#define regw32f_clk30(_reg, _f, _fv)     (regw32f_clk(3, 0, _reg, _f, (_fv)))

#define regr32_clk31(_reg)               (regr32_clk(3, 1, _reg))
#define regw32_clk31(_reg, _val)         (regw32_clk(3, 1, _reg, (_val)))
#define regr32f_clk31(_reg, _f)          (regr32f_clk(3, 1, _reg, _f))
#define regw32f_clk31(_reg, _f, _fv)     (regw32f_clk(3, 1, _reg, _f, (_fv)))

#define regr32_clk32(_reg)               (regr32_clk(3, 2, _reg))
#define regw32_clk32(_reg, _val)         (regw32_clk(3, 2, _reg, (_val)))
#define regr32f_clk32(_reg, _f)          (regr32f_clk(3, 2, _reg, _f))
#define regw32f_clk32(_reg, _f, _fv)     (regw32f_clk(3, 2, _reg, _f, (_fv)))

#define regr32_smem0(_off)               (regr32_smem(0, _off))
#define regw32_smem0(_off, _val)         (regw32_smem(0, _off, (_val)))
#define regr32_smem1(_off)               (regr32_smem(1, _off))
#define regw32_smem1(_off, _val)         (regw32_smem(1, _off, (_val)))
#define regr32_smem2(_off)               (regr32_smem(2, _off))
#define regw32_smem2(_off, _val)         (regw32_smem(2, _off, (_val)))

#define regr32_uart0(_reg)               (regr32_uart(0, _reg))
#define regw32_uart0(_reg, _val)         (regw32_uart(0, _reg, (_val)))
#define regr32f_uart0(_reg, _f)          (regr32f_uart(0, _reg, _f))
#define regw32f_uart0(_reg, _f, _fv)     (regw32f_uart(0, _reg, _f, (_fv)))

#define regr32_uart1(_reg)               (regr32_uart(1, _reg))
#define regw32_uart1(_reg, _val)         (regw32_uart(1, _reg, (_val)))
#define regr32f_uart1(_reg, _f)          (regr32f_uart(1, _reg, _f))
#define regw32f_uart1(_reg, _f, _fv)     (regw32f_uart(1, _reg, _f, (_fv)))

// per asic revision workaround macros
#define ssm_fw_boot_up() (0xB0 == (regr32_ssm(SSM_SCRATCH_FW_VERSION) >> 24))
#define ssm_reg_use_wa() (true == is_asic_a0() && true == ssm_fw_boot_up())

#define regr32_ssm_wa(_reg)                                           \
({                                                                    \
    SSM_LIB_PTR_MCU->ssm_reg_read(__reg_addr_ssm(_reg));              \
})

#define regw32_ssm_wa(_reg, _val)                                     \
{                                                                     \
    SSM_LIB_PTR_MCU->ssm_reg_write(__reg_addr_ssm(_reg), (_val));     \
}

#define regr32f_ssm_wa(_reg, _f) (REG_GET_F(regr32_ssm_wa(_reg), _reg, _f))
#define regw32f_ssm_wa(_reg, _f, _fv) (regw32_ssm_wa(_reg, REG_SET_F(regr32_ssm_wa(_reg), _reg, _f, (_fv))))

#define regp32_ssm_wa(_reg, _p_val, _tout_ms)                         \
{                                                                     \
    uint32_t _tout_cnt = 0;                                           \
    while (1)                                                         \
    {                                                                 \
        if ((_p_val) == regr32_ssm_wa(_reg)) break;                   \
        std::this_thread::sleep_for(std::chrono::milliseconds(1));    \
        if (++_tout_cnt > (_tout_ms)) assert(false);                  \
    }                                                                 \
}

#define regp32f_ssm_wa(_reg, _f, _p_val, _tout_ms)                    \
{                                                                     \
    uint32_t _tout_cnt = 0;                                           \
    while (1)                                                         \
    {                                                                 \
        if ((_p_val) == regr32f_ssm_wa(_reg, _f)) break;              \
        std::this_thread::sleep_for(std::chrono::milliseconds(1));    \
        if (++_tout_cnt > (_tout_ms)) assert(false);                  \
    }                                                                 \
}

#define regp32_ssm(_reg, _p_val, _tout_ms)                            \
{                                                                     \
    uint32_t _tout_cnt = 0;                                           \
    while (1)                                                         \
    {                                                                 \
        if ((_p_val) == regr32_ssm(_reg)) break;                      \
        std::this_thread::sleep_for(std::chrono::milliseconds(1));    \
        if (++_tout_cnt > (_tout_ms)) assert(false);                  \
    }                                                                 \
}

#define regp32f_ssm(_reg, _f, _p_val, _tout_ms)                       \
{                                                                     \
    uint32_t _tout_cnt = 0;                                           \
    while (1)                                                         \
    {                                                                 \
        if ((_p_val) == regr32f_ssm(_reg, _f)) break;                 \
        std::this_thread::sleep_for(std::chrono::milliseconds(1));    \
        if (++_tout_cnt > (_tout_ms)) assert(false);                  \
    }                                                                 \
}

#endif  // HARDWARE_SSM_REG_SSM_REG_OP_LIBRA_HXX_
