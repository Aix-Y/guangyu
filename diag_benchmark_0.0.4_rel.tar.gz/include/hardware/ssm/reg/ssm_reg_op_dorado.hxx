/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_REG_SSM_REG_OP_DORADO_HXX_
#define HARDWARE_SSM_REG_SSM_REG_OP_DORADO_HXX_

#include "device/dtus/dorado/data_fabric.h"
#include "device/dtus/dorado/dtu_wrapper.h"
#include "device/dtus/dorado/register_soc.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////
// MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED
//////////////////////////////////////////////////////////////////////////////////////////////////////
#define __hwtree_l1__(_top, _mid, _m) ((_top)->Get(#_m, _mid)->ecf_addr_)
#define __hwtree_l2__(_top, _mid, _sid, _m, _s) ((_top)->Get(#_m, _mid)->Get(#_s, _sid)->ecf_addr_)

#define ECF_HOBJ_SSM_0               (hw_soc_->Get("SSM_SUBSYS_REGMODEL", 0))

#define ECF_ADDR_SSM_BASE0(_top)     __hwtree_l1__(_top, 0,    SSM_REGS)
#define ECF_ADDR_SSM_I2C0(_top)      __hwtree_l1__(_top, 0,    DW_APB_I2C)
#define ECF_ADDR_SSM_I2C1(_top)      __hwtree_l1__(_top, 1,    DW_APB_I2C)
#define ECF_ADDR_SSM_I2C2(_top)      __hwtree_l1__(_top, 2,    DW_APB_I2C)
#define ECF_ADDR_SSM_I2C3(_top)      __hwtree_l1__(_top, 3,    DW_APB_I2C)
#define ECF_ADDR_SSM_I2C4(_top)      __hwtree_l1__(_top, 4,    DW_APB_I2C)
#define ECF_ADDR_SSM_FUSE0(_top)     __hwtree_l1__(_top, 0,    FUSE_REGS)
#define ECF_ADDR_SSM_OTP0(_top)      __hwtree_l1__(_top, 0,    OTP_REGS)
#define ECF_ADDR_SSM_TSEN0(_top)     __hwtree_l1__(_top, 0,    INNO_TSENSOR)
#define ECF_ADDR_SSM_LDMA0(_top)     __hwtree_l1__(_top, 0,    LDMA_REGS)
#define ECF_ADDR_SSM_LDMA0_VC0(_top) __hwtree_l2__(_top, 0, 0, LDMA_REGS, LDMA_CMD_PKT_REGS)
#define ECF_ADDR_SSM_LDMA0_VC1(_top) __hwtree_l2__(_top, 0, 1, LDMA_REGS, LDMA_CMD_PKT_REGS)
#define ECF_ADDR_SSM_LDMA0_VC2(_top) __hwtree_l2__(_top, 0, 2, LDMA_REGS, LDMA_CMD_PKT_REGS)
#define ECF_ADDR_SSM_LDMA0_VC3(_top) __hwtree_l2__(_top, 0, 3, LDMA_REGS, LDMA_CMD_PKT_REGS)
#define ECF_ADDR_SSM_SE0(_top)       __hwtree_l1__(_top, 0,    SE_REGMODEL)
#define ECF_ADDR_SSM_SE0_RSA0(_top)  __hwtree_l2__(_top, 0, 0, SE_REGMODEL, RSA_REGS)
#define ECF_ADDR_SSM_SE0_SHA0(_top)  __hwtree_l2__(_top, 0, 0, SE_REGMODEL, SHA_REGS)
#define ECF_ADDR_SSM_UART0(_top)     __hwtree_l1__(_top, 0,    UART_MEMORY_MAP_UART_ADDRESS_BLOCK)
#define ECF_ADDR_SSM_UART1(_top)     __hwtree_l1__(_top, 1,    UART_MEMORY_MAP_UART_ADDRESS_BLOCK)
#define ECF_ADDR_SSM_RM0(_top)       __hwtree_l1__(_top, 0,    RM_CLIENT_REGS)
#define ECF_ADDR_SSM_VM0(_top)       __hwtree_l1__(_top, 0,    VM_CLIENT_REGS)
#define ECF_ADDR_SSM_CPMU0(_top)     __hwtree_l1__(_top, 0,    CPMU)

#define ECF_ADDR_SSM_IRAM0(_top)     (ECF_ADDR_SSM_BASE0(_top) + 0x20000U)
#define ECF_ADDR_SSM_DRAM0(_top)     (ECF_ADDR_SSM_BASE0(_top) + 0x40000U)
#define ECF_ADDR_SSM_SMEM0(_top)     (ECF_ADDR_SSM_BASE0(_top) + 0x48000U + 0x1000U * 0)
#define ECF_ADDR_SSM_SMEM1(_top)     (ECF_ADDR_SSM_BASE0(_top) + 0x48000U + 0x1000U * 1)
#define ECF_ADDR_SSM_FRAM0(_top)     (ECF_ADDR_SSM_BASE0(_top) + 0x0F000U)
#define ECF_ADDR_SSM_OTPM0(_top)     (ECF_ADDR_SSM_BASE0(_top) + 0x10000U)

#define ECF_BASE_MCX(_id)            (ECF_MC(_id) + 0x0080000) //addrmap.h MC_
//////////////////////////////////////////////////////////////////////////////////////////////////////
// MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED
//////////////////////////////////////////////////////////////////////////////////////////////////////

#include "hardware/include/ssm/reg/ssm_reg_op.hxx"

// per asic capbility macros
#define regr32_smem0(_off)               (regr32_smem(0, _off))
#define regw32_smem0(_off, _val)         (regw32_smem(0, _off, (_val)))
#define regr32_smem1(_off)               (regr32_smem(1, _off))
#define regw32_smem1(_off, _val)         (regw32_smem(1, _off, (_val)))

#define regr32_uart0(_reg)               (regr32_uart(0, _reg))
#define regw32_uart0(_reg, _val)         (regw32_uart(0, _reg, (_val)))
#define regr32f_uart0(_reg, _f)          (regr32f_uart(0, _reg, _f))
#define regw32f_uart0(_reg, _f, _fv)     (regw32f_uart(0, _reg, _f, (_fv)))

#define regr32_uart1(_reg)               (regr32_uart(1, _reg))
#define regw32_uart1(_reg, _val)         (regw32_uart(1, _reg, (_val)))
#define regr32f_uart1(_reg, _f)          (regr32f_uart(1, _reg, _f))
#define regw32f_uart1(_reg, _f, _fv)     (regw32f_uart(1, _reg, _f, (_fv)))

#define regr32_cqm0(_reg)                (regr32_cqm(0, _reg))
#define regw32_cqm0(_reg, _val)          (regw32_cqm(0, _reg, (_val)))
#define regr32f_cqm0(_reg, _f)           (regr32f_cqm(0, _reg, _f))
#define regw32f_cqm0(_reg, _f, _fv)      (regw32f_cqm(0, _reg, _f, (_fv)))

#define regr32_cqm1(_reg)                (regr32_cqm(1, _reg))
#define regw32_cqm1(_reg, _val)          (regw32_cqm(1, _reg, (_val)))
#define regr32f_cqm1(_reg, _f)           (regr32f_cqm(1, _reg, _f))
#define regw32f_cqm1(_reg, _f, _fv)      (regw32f_cqm(1, _reg, _f, (_fv)))

#define regr32_cqm2(_reg)                (regr32_cqm(2, _reg))
#define regw32_cqm2(_reg, _val)          (regw32_cqm(2, _reg, (_val)))
#define regr32f_cqm2(_reg, _f)           (regr32f_cqm(2, _reg, _f))
#define regw32f_cqm2(_reg, _f, _fv)      (regw32f_cqm(2, _reg, _f, (_fv)))

#define regr32_cqm3(_reg)                (regr32_cqm(3, _reg))
#define regw32_cqm3(_reg, _val)          (regw32_cqm(3, _reg, (_val)))
#define regr32f_cqm3(_reg, _f)           (regr32f_cqm(3, _reg, _f))
#define regw32f_cqm3(_reg, _f, _fv)      (regw32f_cqm(3, _reg, _f, (_fv)))

// per asic revision workaround macros
#define ssm_fw_boot_up() (0xB0 == (regr32_ssm(SSM_SCRATCH_FW_VERSION) >> 24))
#define ssm_reg_use_wa() (true == is_asic_a0() && true == ssm_fw_boot_up())

#define regr32_ssm_wa(_reg)                                           \
({                                                                    \
    SSM_LIB_PTR_MCU->ssm_reg_read(__reg_addr_ssm(_reg));              \
})

#define regw32_ssm_wa(_reg, _val)                                     \
{                                                                     \
    SSM_LIB_PTR_MCU->ssm_reg_write(__reg_addr_ssm(_reg), (_val));     \
}

#define regr32f_ssm_wa(_reg, _f) (REG_GET_F(regr32_ssm_wa(_reg), _reg, _f))
#define regw32f_ssm_wa(_reg, _f, _fv) (regw32_ssm_wa(_reg, REG_SET_F(regr32_ssm_wa(_reg), _reg, _f, (_fv))))

#define regp32_ssm_wa(_reg, _p_val, _tout_ms)                         \
{                                                                     \
    uint32_t _tout_cnt = 0;                                           \
    while (1)                                                         \
    {                                                                 \
        if ((_p_val) == regr32_ssm_wa(_reg)) break;                   \
        std::this_thread::sleep_for(std::chrono::milliseconds(1));    \
        if (++_tout_cnt > (_tout_ms)) assert(false);                  \
    }                                                                 \
}

#define regp32f_ssm_wa(_reg, _f, _p_val, _tout_ms)                    \
{                                                                     \
    uint32_t _tout_cnt = 0;                                           \
    while (1)                                                         \
    {                                                                 \
        if ((_p_val) == regr32f_ssm_wa(_reg, _f)) break;              \
        std::this_thread::sleep_for(std::chrono::milliseconds(1));    \
        if (++_tout_cnt > (_tout_ms)) assert(false);                  \
    }                                                                 \
}

#define regp32_ssm(_reg, _p_val, _tout_ms)                            \
{                                                                     \
    uint32_t _tout_cnt = 0;                                           \
    while (1)                                                         \
    {                                                                 \
        if ((_p_val) == regr32_ssm(_reg)) break;                      \
        std::this_thread::sleep_for(std::chrono::milliseconds(1));    \
        if (++_tout_cnt > (_tout_ms)) assert(false);                  \
    }                                                                 \
}

#define regp32f_ssm(_reg, _f, _p_val, _tout_ms)                       \
{                                                                     \
    uint32_t _tout_cnt = 0;                                           \
    while (1)                                                         \
    {                                                                 \
        if ((_p_val) == regr32f_ssm(_reg, _f)) break;                 \
        std::this_thread::sleep_for(std::chrono::milliseconds(1));    \
        if (++_tout_cnt > (_tout_ms)) assert(false);                  \
    }                                                                 \
}

#endif  // HARDWARE_SSM_REG_SSM_REG_OP_DORADO_HXX_
