/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_UART_SSM_UART_SCORPIO_H_
#define HARDWARE_SSM_UART_SSM_UART_SCORPIO_H_

#include <string>

#include "hardware/include/ssm/uart/ssm_uart.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace uart {

class SsmUartScorpio : public SsmUart {
 public:
    explicit SsmUartScorpio(Ssm *ssm) : SsmUart(ssm) {
        IP_ASSERT(nullptr != m_ssm);
        is_mcu_gd = true;
    }
    ~SsmUartScorpio() {}

 private:
    bool is_mcu_gd;

 public:
    bool        amc_supported(void);
    bool        amc_image_download(bool, std::string, uint32_t);
    bool        amc_fwbuf_download(bool, uint32_t, void *);
    bool        ust_fwbuf_download(bool, uint32_t, void *);
    void        amc_force_dead(bool, bool);
    void        amc_reset_toggle(bool);
    uint32_t    amc_upmode_select(bool);
    bool        amc_sync_time(uint32_t = ~0U);
    std::string amc_pid_status(void);
    bool        amc_fwsz_valid(uint32_t);
    void        amc_reset_boot_mode(bool, bool);

 private:
    void        amc_package_cmd(uint32_t, uint32_t);
    void        amc_package_end(uint32_t);
    uint32_t    amc_package_resp(uint32_t);
    void        amc_wait_util_ack(uint32_t);
    void        amc_wait_util_nak(uint32_t);
    bool        amc_wait_resp_code(uint32_t, std::string, uint64_t);
    bool        amc_wait_resp_timeout(uint32_t, uint32_t, uint64_t);
    bool        amc_package_xmode_switch(uint32_t);
    uint8_t     amc_package_checksum_u8(uint8_t *, uint32_t);
    void        amc_package_fmt(AMC_PKG_128B &, void *, uint32_t);
    bool        amc_package_send(AMC_PKG_128B &);
    bool        amc_package_send_wait(AMC_PKG_128B &, uint32_t);
    bool        amc_mcu_is_gd(uint32_t);
    std::string cmd_decode_2str(uint32_t);
    std::string amc_package_2str(AMC_PKG_128B &);
    std::string amc_fifo_rx_force_clr(uint32_t, uint32_t = 0U);

 private:
    bool        ust_bmode_is_on(void);
    bool        ust_bmode_is_off(void);
    void        ust_bmode_ctl_hw(bool);
    bool        ust_bmode_cmd_bdr(uint32_t);
    bool        ust_bmode_cmd_get(UST_PKG_STM32 &);
    bool        ust_bmode_cmd_gvp(UST_PKG_STM32 &);
    bool        ust_bmode_cmd_gid(UST_PKG_STM32 &);
    bool        ust_bmode_cmd_pid(UST_PKG_STM32 &);
    bool        ust_bmode_cmd_eer(uint32_t, uint32_t, uint32_t = 1U);
    bool        ust_bmode_cmd_ers(uint32_t, uint32_t, uint32_t = 1U);
    bool        ust_bmode_cmd_eerg(uint32_t);
    bool        ust_bmode_cmd_ersg(uint32_t);
    bool        ust_bmode_cmd_rmm(UST_PKG_STM32 &);
    bool        ust_bmode_cmd_wmm(UST_PKG_STM32 &);
    bool        ust_bmode_cmd_send(UST_PKG_STM32 &);
    bool        ust_bmode_cmd_recv(UST_PKG_STM32 &);
    bool        ust_bmode_cmd_wait(uint32_t, uint32_t, uint64_t);
    bool        ust_bmode_apply_addr(uint32_t, uint32_t);
    bool        ust_bmode_apply_size(uint32_t, uint32_t);
    uint8_t     ust_bmode_csm_u8(uint8_t *, uint32_t);
    bool        ust_bmode_switch_autob(uint32_t, bool, bool);
    bool        ust_package_send_wait_st(UST_PKG_STM32 &, uint32_t);
    bool        ust_package_send_wait_gd(UST_PKG_STM32 &, uint32_t);
    std::string ust_bmode_dump_info(uint32_t);

 private:
    void        uart_init(uint32_t, uint32_t);
    void        uart_reset(uint32_t);
    bool        uart_reset_on_error(uint32_t, std::string);
    void        uart_wait_idle(uint32_t);
    uint32_t    uart_cac_baud(uint32_t, uint32_t = 0U);
    uint32_t    uart_cac_divisor(uint32_t, uint32_t = 0U);
    void        uart_set_baud_rate(uint32_t, uint32_t);
    bool        uart_chk_ncomp_busy(uint32_t);
    std::string uart_get_comp_ver(uint32_t);
    std::string uart_get_cio_status(uint32_t);
    std::string uart_get_lcr_status(uint32_t);
    std::string uart_get_usr_status(uint32_t);
    std::string uart_get_lsr_status(uint32_t);
    std::string uart_get_mcr_status(uint32_t);
    std::string uart_get_cpr_status(uint32_t);

 private:
    void uart_ctl_set_clk_en(uint32_t, bool);
    void uart_ctl_set_rst_en(uint32_t, uint32_t);
    void uart_ctl_set_rst(uint32_t);
    bool uart_ctl_get_gpio_en(uint32_t);
    void uart_ctl_set_gpio_en(uint32_t, bool);
    bool uart_cio_get_gpio_en(uint32_t);
    void uart_cio_set_gpio_en(uint32_t, bool);
    void uart_cio_set_gpio16_en(uint32_t, bool);

 private:
    bool     uart_apb_16550_compatible(uint32_t);
    uint32_t uart_apb_cpr_get_fifo_mode(uint32_t, uint32_t = 0U);
    bool     uart_apb_cpr_in_fifo_mode(uint32_t);
    bool     uart_apb_cpr_get_fifo_stat(uint32_t);
    bool     uart_apb_cpr_adt_feat_en(uint32_t);
    bool     uart_apb_cpr_adt_para_en(uint32_t);
    uint32_t uart_apb_cpr_get_data_width(uint32_t, uint32_t = 0U);
    uint32_t uart_apb_ucv_get(uint32_t);
    bool     uart_apb_usr_get_busy(uint32_t);
    bool     uart_apb_usr_get_tfnf(uint32_t);
    void     uart_apb_usr_tfnf_wait(uint32_t);
    bool     uart_apb_usr_get_tfe(uint32_t);
    void     uart_apb_usr_tfe_wait(uint32_t);
    bool     uart_apb_usr_get_rfne(uint32_t);
    void     uart_apb_usr_rfne_wait(uint32_t);
    bool     uart_apb_usr_get_rff(uint32_t);
    void     uart_apb_usr_rff_wait_negative(uint32_t);
    bool     uart_apb_lsr_get_dr(uint32_t);
    void     uart_apb_lsr_dr_wait_ready(uint32_t);
    bool     uart_apb_lsr_get_temt(uint32_t);
    void     uart_apb_lsr_temt_wait(uint32_t);
    bool     uart_apb_lsr_get_thre(uint32_t);
    void     uart_apb_lsr_thre_wait(uint32_t);
    bool     uart_apb_lsr_no_err(uint32_t);
    void     uart_apb_lsr_wait_no_err(uint32_t);
    void     uart_apb_set_mcr_modem(uint32_t, uint32_t);
    void     uart_apb_set_lcr_cfg(uint32_t);
    void     uart_apb_set_lcr_cfg_pece(uint32_t);
    uint32_t uart_apb_get_lcr_div_latch(uint32_t);
    void     uart_apb_set_lcr_div_latch(uint32_t, uint32_t);
    uint8_t  uart_apb_get_dll(uint32_t);
    void     uart_apb_set_dll(uint32_t, uint32_t);
    uint8_t  uart_apb_get_dlh(uint32_t);
    void     uart_apb_set_dlh(uint32_t, uint32_t);
    uint32_t uart_apb_get_divisor(uint32_t);
    void     uart_apb_set_divisor(uint32_t, uint32_t);
    bool     uart_apb_get_iir_fifose(uint32_t);
    void     uart_apb_set_iir_fifose(uint32_t, bool);
    bool     uart_apb_get_fcr_fifoe(uint32_t);
    void     uart_apb_set_fcr_fifoe(uint32_t, bool);
    uint8_t  uart_apb_get_rbr(uint32_t);
    uint8_t  uart_apb_get_rbr_echo(uint32_t);
    void     uart_apb_set_thr(uint32_t, uint32_t);
    void     uart_apb_set_thr_echo(uint32_t, uint32_t);

 private:
    bool     check_amc_ssm_alive(const std::string &);
    uint32_t fetch_amc_ssm_spi_jdec(void);
    bool     fetch_amc_test_result_i2chub(uint32_t, void *);
    bool     fetch_amc_test_result_adcscan(void *);
    bool     fetch_amc_data_flash(uint32_t, void *);
    bool     fetch_amc_data_flash(void *);
    bool     erase_amc_data_flash(void);
    bool     fetch_amc_debug_log(void *);
    bool     erase_amc_debug_log(void);
    uint8_t  amc_eeprom_ru8(uint32_t);
    void     amc_eeprom_wu8(uint32_t, uint32_t);
    uint32_t amc_format_ver(uint32_t);
    bool     amc_error_log_in_spi(void);

 public:
    bool test_amc_reset_alive(void);
    bool test_amc_ssm_data_exchange(void);
    bool test_amc_ssm_check_i2c_hub(void);
    bool test_amc_ssm_check_eeprom(void);
    bool test_amc_ssm_check_adc_scan(void);
    bool test_amc_ssm_check_spi_access(void);

 public:
    std::string handle_tool_req_get_str(const std::string &);
    std::string handle_tool_req_get_str(const std::string &, const std::string &);
    std::string handle_tool_req_get_str(const std::string &, const uint32_t &);
    bool        handle_tool_req_set(const std::string &);
    bool        handle_tool_req_set(const std::string &, uint32_t &);
    bool        handle_tool_req_set(const std::string &, const std::string &);
    bool        handle_req_uart_status(const std::string &);
    bool        handle_req_uart_reset(const std::string &);
    bool        handle_req_uart_init(const std::string &, const std::string &);
    uint32_t    handle_req_uart_rxu8(const std::string &);
    void        handle_req_uart_txu8(const std::string &, uint32_t);
    bool        handle_req_uart_rx_clr(const std::string &);
};

}  // namespace uart
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_UART_SSM_UART_SCORPIO_H_
