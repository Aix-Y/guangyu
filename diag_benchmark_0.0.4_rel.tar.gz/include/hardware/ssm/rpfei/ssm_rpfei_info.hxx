/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_RPFEI_SSM_RPFEI_INFO_HXX_
#define HARDWARE_SSM_RPFEI_SSM_RPFEI_INFO_HXX_

/**
 * GLB[16] o_mcu_int[0]  = o_pheriph_0_int;                                                                                           |- SSM_MCU_INT_PHERIPH_CTRL0
 * GLB[17] o_mcu_int[1]  = o_pheriph_1_int;                                                                                           |- SSM_MCU_INT_PHERIPH_CTRL1
 * GLB[18] o_mcu_int[2]  = o_pheriph_2_int;                                                                                           |- SSM_MCU_INT_PHERIPH_CTRL2
 * GLB[19] o_mcu_int[3]  = o_pheriph_3_int;                                                                                           |- SSM_MCU_INT_PHERIPH_CTRL3
 * GLB[20] o_mcu_int[4]  = o_pheriph_4_int;                                                                                           |- SSM_MCU_INT_PHERIPH_CTRL4
 * GLB[21] o_mcu_int[5]  = o_pheriph_5_int;                                                                                           |- SSM_MCU_INT_PHERIPH_CTRL5
 * GLB[22] o_mcu_int[6]  = o_pheriph_6_int;                                                                                           |- SSM_MCU_INT_PHERIPH_CTRL6
 * GLB[23] o_mcu_int[7]  = o_pheriph_7_int;                                                                                           |- SSM_MCU_INT_PHERIPH_CTRL7
 * GLB[24] o_mcu_int[8]  = o_pheriph_8_int;                                                                                           |- SSM_MCU_INT_PHERIPH_CTRL8
 * GLB[25] o_mcu_int[9]  = o_pheriph_9_int;                                                                                           |- SSM_MCU_INT_PHERIPH_CTRL9
 * GLB[26] o_mcu_int[10] = o_pheriph_10_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL10
 * GLB[27] o_mcu_int[11] = o_pheriph_11_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL11
 * GLB[28] o_mcu_int[12] = o_pheriph_12_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL12
 * GLB[29] o_mcu_int[13] = o_pheriph_13_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL13
 * GLB[30] o_mcu_int[14] = o_pheriph_14_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL14
 * GLB[31] o_mcu_int[15] = o_pheriph_15_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL15
 * GLB[32] o_mcu_int[16] = o_pheriph_16_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL16
 * GLB[33] o_mcu_int[17] = o_pheriph_17_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL17
 * GLB[34] o_mcu_int[18] = o_pheriph_18_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL18
 * GLB[35] o_mcu_int[19] = o_pheriph_19_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL19
 * GLB[36] o_mcu_int[20] = o_pheriph_20_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL20
 * GLB[37] o_mcu_int[21] = o_pheriph_21_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL21
 * GLB[38] o_mcu_int[22] = o_pheriph_22_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL22
 * GLB[39] o_mcu_int[23] = o_pheriph_23_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL23
 * GLB[40] o_mcu_int[24] = o_pheriph_24_int;                                                                                          |- SSM_MCU_INT_PHERIPH_CTRL24
 * GLB[41] o_mcu_int[25] = o_thm_0_int;                                                                                               |- SSM_MCU_INT_THM_CTRL0
 * GLB[42] o_mcu_int[26] = o_thm_1_int;                                                                                               |- SSM_MCU_INT_THM_CTRL1
 * GLB[43] o_mcu_int[27] = o_thm_2_int;                                                                                               |- SSM_MCU_INT_THM_CTRL2
 * GLB[44] o_mcu_int[28] = o_thm_3_int;                                                                                               |- SSM_MCU_INT_THM_CTRL3
 * GLB[45] o_mcu_int[29] = o_thm_4_int;                                                                                               |- SSM_MCU_INT_THM_CTRL4
 * GLB[46] o_mcu_int[30] = o_thm_5_int;                                                                                               |- SSM_MCU_INT_THM_CTRL5
 * GLB[47] o_mcu_int[31] = o_thm_6_int;                                                                                               |- SSM_MCU_INT_THM_CTRL6
 * GLB[48] o_mcu_int[32] = o_pwr_0_int;                                                                                               |- SSM_MCU_INT_PWR_CTRL0
 * GLB[49] o_mcu_int[33] = o_pwr_1_int;                                                                                               |- SSM_MCU_INT_PWR_CTRL1
 * GLB[50] o_mcu_int[34] = o_pwr_2_int;                                                                                               |- SSM_MCU_INT_PWR_CTRL2
 * GLB[51] o_mcu_int[35] = o_pwr_3_int;                                                                                               |- SSM_MCU_INT_PWR_CTRL3
 * GLB[52] o_mcu_int[36] = o_internal_module_int0;                                                                                    |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT0_EN
 * GLB[53] o_mcu_int[37] = o_internal_module_int1;                                                                                    |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT1_EN
 * GLB[54] o_mcu_int[38] = o_internal_module_int2;                                                                                    |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT2_EN
 * GLB[55] o_mcu_int[39] = o_internal_module_int3;                                                                                    |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT3_EN
 * GLB[56] o_mcu_int[40] = o_internal_module_int4;                                                                                    |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT4_EN
 * GLB[57] o_mcu_int[41] = o_internal_module_int5;                                                                                    |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT5_EN
 * GLB[58] o_mcu_int[42] = o_internal_module_int6;                                                                                    |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT6_EN
 * GLB[59] o_mcu_int[43] = o_internal_module_int7;                                                                                    |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT7_EN
 * GLB[60] o_mcu_int[44] = o_internal_module_int8;                                                                                    |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT8_EN
 * GLB[61] o_mcu_int[45] = o_internal_module_int9;                                                                                    |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT9_EN
 * GLB[62] o_mcu_int[46] = o_internal_module_int10;                                                                                   |- SSM_MCU_INT_INTERNAL_MODULE_INT_CTRL.INT10_EN
 * GLB[63] o_mcu_int[47] = o_mcu_int_sem_low_int;                                                                                     |- SEM_[0~31]_INT_CFG.CREDIT_LOW_INT_EN
 * GLB[64] o_mcu_int[48] = o_mcu_int_sem_high_int;                                                                                    |- SEM_[0~31]_INT_CFG.CREDIT_HIGH_INT_EN
 * GLB[65] o_mcu_int[49] = o_mcu_int_gpio_int;                                                                                        |- SSM_MCU_INT_GPIO_63_32_INT_ENABLE / SSM_MCU_INT_GPIO_31_0_INT_ENABLE
 * GLB[66] o_mcu_int[50] = o_mcu_int_gp0_int;                                                                                         |- SSM_MCU_INT_MCU_GP0_INT_ENABLE
 * GLB[67] o_mcu_int[51] = o_mcu_int_gp1_int;                                                                                         |- SSM_MCU_INT_MCU_GP1_INT_ENABLE
 * GLB[68] o_mcu_int[52] = o_mcu_int_gp2_int;                                                                                         |- SSM_MCU_INT_MCU_GP2_INT_ENABLE
 * GLB[69] o_mcu_int[53] = o_mcu_int_gp3_int;                                                                                         |- SSM_MCU_INT_MCU_GP3_INT_ENABLE
 * GLB[70] o_mcu_int[54] = aasp_link_donw_int;                                                                                        |- SSM_MCU_INT_AASP_LINK_DOWN_INT_CTRL
 * GLB[71] o_mcu_int[55] = esl_error_int;                                                                                             |- SSM_MCU_INT_ESL_ERROR_INT_CTL
 * GLB[72] o_mcu_int[56] = exf_error_int;                                                                                             |- SSM_MCU_INT_EXF_ERROR_INT_CTL
 * GLB[73] o_mcu_int[57] = sicio_int;                                                                                                 |- SSM_MCU_INT_SICIO_INT_CTL
 * GLB[74] o_mcu_int[58] = boost_pipe_int;                                                                                            |- SSM_MCU_INT_BSTP_INT_CTL
 * GLB[75] o_mcu_int[59] = parity_int || i_sem_credit_ovfl_int || i_mdma_err_int;
 *                         parity_int = feed_through_gr0_int_total || feed_through_gr1_int_total || feed_through_gr2_int_total;
 *                                                                                                                                    |- SSM_MCU_INT_FEED_THROUGH_GP0_CTRL.INT0_EN ~ INT6_EN
 *                                                                                                                                    |- SSM_MCU_INT_FEED_THROUGH_GP1_CTRL.INT0_EN ~ INT14_EN
 *                                                                                                                                    |- SSM_MCU_INT_FEED_THROUGH_GP2_CTRL.INT0_EN ~ INT3_EN
 *                         i_sem_credit_ovfl_int                                                                                      |- inst.0 ~ inst.31 SEM_CREDIT_OVFL_INT_EN.SEM_CREDIT_OVFL_INT_EN
 *                         i_mdma_err_int                                                                                             |- vc.0 ~ vc.3 INT_ENABLE.TRIG_MISS_INT_EN
 *                                                                                                                                    |- MDMA_INT_CTRL.CMDQ_OVFL_INT_EN
 *                                                                                                                                    |- MDMA_INT_CTRL.HQS_SRC_OVFL_INT_EN
 *                                                                                                                                    |- MDMA_INT_CTRL.MPQ_OVFL_INT_EN
 *                                                                                                                                    |- MDMA_INT_CTRL.LC_STATIC_ID_ERR_INT_EN
 *                                                                                                                                    |- MDMA_INT_CTRL.LC_SRAM_FIFO_PARITY_ERR_INT_EN
 * GLB[76] o_mcu_int[60] = hw_ctf = (i_thm_3_int && i_reg_hw_ctf_off_chip_trig_en) ||                                                 |- SSM_MCU_INT_CTF_CTRL.CTF_OFF_CHIP_TRIG_EN
 *                                  (i_thm_6_int && i_reg_hw_ctf_on_chip_trig_en ) ||                                                 |- SSM_MCU_INT_CTF_CTRL.CTF_ON_CHIP_TRIG_EN
 *                                  (mc0_cattrip_int && i_reg_mc0_cattrip_int_en)  ||                                                 |- SSM_MCU_INT_CTF_CTRL.CTF_MC0_CATTRIP_EN
 *                                  (mc1_cattrip_int && i_reg_mc1_cattrip_int_en)  ||                                                 |- SSM_MCU_INT_CTF_CTRL.CTF_MC1_CATTRIP_EN
 *                                  (mc2_cattrip_int && i_reg_mc2_cattrip_int_en)  ||                                                 |- SSM_MCU_INT_CTF_CTRL.CTF_MC2_CATTRIP_EN
 *                                  (mc3_cattrip_int && i_reg_mc3_cattrip_int_en);                                                    |- SSM_MCU_INT_CTF_CTRL.CTF_MC3_CATTRIP_EN
 * GLB[77] o_mcu_int[61] = i_secip_sensor_int && i_secip_sensor_int_en;                                                               |- SSM_SECIP_SENSOR_HAPPEN_INT_CTRL.SSM_SECIP_SENSOR_HAPPEN_INT_EN
 */

#endif  // HARDWARE_SSM_RPFEI_SSM_RPFEI_INFO_HXX_
