/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_SDW_SSM_SDW_LIBRA_H_
#define HARDWARE_SSM_SDW_SSM_SDW_LIBRA_H_

#include "hardware/include/ssm/sdw/ssm_sdw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace sdw {

class SsmSdwLibra : public SsmSdw {
 public:
    explicit SsmSdwLibra(Ssm *ssm) : SsmSdw(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmSdwLibra() {}

 public:
    void sdw_ena(bool);
    void sdw_int_ena(bool);
    void sdw_int_clr(void);
    void sdw_debug_dump(uint32_t = SSM_MAGIC);
    void sdw_force_decrypt(uint32_t, bool);
    void sdw_force_integrity(uint32_t, bool);
    bool sdw_update_key(uint32_t, void *, void *);

 public:
    bool     sm4_xts_ctrl_get_ena(void);
    void     sm4_xts_ctrl_set_ena(bool);
    uint32_t sm4_xts_ctrl_get_mode(void);
    void     sm4_xts_ctrl_set_mode(uint32_t);
    bool     sm4_xts_ctrl_int_2ssm_ena(void);
    void     sm4_xts_ctrl_int_2ssm(bool);
    bool     sm4_xts_ctrl_int_2dte_ena(void);
    void     sm4_xts_ctrl_int_2dte(bool);
    bool     sm4_xts_csum_int_err_arv(void);
    void     sm4_xts_csum_int_err_clr(void);
    uint32_t sm4_xts_csum_err_fifo_num(void);
    void     sm4_xts_csum_err_fifo_pop(void);
    uint64_t sm4_xts_csum_err_fifo_fetch(void);
    void     sm4_xts_csum_err_fifo_set_flush(uint32_t);
    void     sm4_xts_csum_err_fifo_flush(void);
    void     sm4_xts_csum_err_fifo_dump(void);
    uint32_t sm4_xts_get_addr_f_decrypt(uint32_t);
    bool     sm4_xts_get_f_decrypt(uint32_t);
    void     sm4_xts_set_f_decrypt(uint32_t, bool);
    uint32_t sm4_xts_get_addr_f_integrity(uint32_t);
    bool     sm4_xts_get_f_integrity(uint32_t);
    void     sm4_xts_set_f_integrity(uint32_t, bool);
    uint32_t sm4_xts_get_addr_k_update(uint32_t);
    bool     sm4_xts_get_k_update_done(uint32_t);
    void     sm4_xts_set_k_update(uint32_t);
    uint32_t sm4_xts_get_addr_k_1_0(uint32_t);
    uint32_t sm4_xts_get_addr_k_1_1(uint32_t);
    uint32_t sm4_xts_get_addr_k_1_2(uint32_t);
    uint32_t sm4_xts_get_addr_k_1_3(uint32_t);
    void     sm4_xts_set_k1(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
    uint32_t sm4_xts_get_addr_k_2_0(uint32_t);
    uint32_t sm4_xts_get_addr_k_2_1(uint32_t);
    uint32_t sm4_xts_get_addr_k_2_2(uint32_t);
    uint32_t sm4_xts_get_addr_k_2_3(uint32_t);
    void     sm4_xts_set_k2(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
};

}  // namespace sdw
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_SDW_SSM_SDW_LIBRA_H_
