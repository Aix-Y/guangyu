/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_CMD_SSM_CMD_SCORPIO_H_
#define HARDWARE_SSM_CMD_SSM_CMD_SCORPIO_H_

#include <string>

#include "hardware/include/ssm/cmd/ssm_cmd.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace cmd {

class SsmCmdScorpio : public SsmCmd {
 public:
    explicit SsmCmdScorpio(Ssm *ssm) : SsmCmd(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmCmdScorpio() {}

 protected:
    void        ssm_port_addr_init(SSM_MCU_CMD *);
    void        ssm_cmd_reg_w(SSM_CMD_REG_TYPE, SSM_MCU_CMD *);
    uint32_t    ssm_cmd_reg_r(SSM_CMD_REG_TYPE, SSM_MCU_CMD *);
    void        ssm_cmd_buf_w(SSM_MCU_CMD *);
    void        ssm_cmd_buf_r(SSM_MCU_CMD *);
    std::string ssm_cmd_dec_f(SSM_MCU_CMD *);
    std::string ssm_cmd_dec_e(SSM_MCU_CMD *);

 public:
    bool     cmd_get_ssm_alive(void);
    uint32_t cmd_get_ping_code(uint32_t);
    uint32_t cmd_reg_read(uint32_t);
    void     cmd_reg_write(uint32_t, uint32_t);
    uint32_t cmd_get_board_type(void);
    uint32_t cmd_get_board_rev(void);
    uint32_t cmd_get_git_rev_ivm(void);
    uint32_t cmd_get_git_rev_ssm(void);
    uint32_t cmd_get_ssm_version(void);
    uint32_t cmd_get_amc_version(void);
    uint32_t cmd_get_imu_version(uint32_t);
    uint32_t cmd_get_imu_version(void *, uint32_t);
    uint32_t cmd_get_compile_time(void *, uint32_t);
    uint32_t cmd_get_asic_version(void);
    uint32_t cmd_get_power_cap(void);
    bool     cmd_get_amc_alive(void);
    bool     cmd_get_amc_alive(uint64_t);
    void     cmd_set_amc_rst_toggle(void);
    void     cmd_set_amc_force_dead(bool);
    bool     cmd_eeprom_read(void *);
    bool     cmd_eeprom_erase(void);
    void     cmd_set_dpm_ena(bool);
    void     cmd_set_dpm_level(uint32_t);
    uint32_t cmd_get_dpm_level(void);
    void     cmd_set_dpm_max(uint32_t);
    uint32_t cmd_get_dpm_max(void);
    bool     cmd_set_fw_prepare_update(void);
    void     cmd_set_vr_ena(bool);
    void     cmd_set_int_ena(bool);
    void     cmd_set_tsen_ena(bool);
    void     cmd_set_sip_harvest_on(uint32_t);
    void     cmd_set_sip_harvest_off(void);
    uint32_t cmd_get_sip_harvest_info(uint32_t);
    uint32_t cmd_req_verify_amc_fw(void);
    uint32_t cmd_get_boot_ecode(void);
    uint32_t cmd_get_boot_health(void);
    void     cmd_set_gsync_ctrl(bool);
    uint32_t cmd_get_pmode_config(void);
    uint32_t cmd_set_pmode_config(uint32_t);
    void     cmd_set_ecc_ena(bool);
    bool     cmd_get_ecc_ena(void);
    uint32_t cmd_get_ecc_status(void);
    uint32_t cmd_get_boot_complete(uint64_t = 0 /*timeout_ms*/);
    uint32_t cmd_get_boot_error(void);
    uint32_t cmd_get_flr_status(uint64_t = 0 /*timeout_ms*/);
    uint32_t cmd_get_feat_status(void);
    void     cmd_set_feat_ena(uint32_t);
    void     cmd_set_feat_dis(uint32_t);
    uint32_t cmd_get_lchip_uuid(void *, uint32_t);
    uint32_t cmd_get_rchip_uuid(void *, uint32_t, uint32_t);
    void     cmd_set_avs_volt(uint32_t, uint32_t);
    uint32_t cmd_get_avs_volt(uint32_t);
    uint32_t cmd_get_avs_curr(uint32_t);
    uint32_t cmd_get_avs_temp(uint32_t);
    uint32_t cmd_get_avs_stat(uint32_t);
    void     cmd_set_i2c_alert(uint32_t, uint32_t);
    uint32_t cmd_get_temp(uint32_t);
    uint32_t cmd_get_temp_group(uint32_t);
    uint32_t cmd_cfg_1412_reg(uint32_t, uint32_t);
    uint32_t cmd_cfg_1412_reg_r(uint32_t, uint32_t);
    void     cmd_cfg_1412_reg_w(uint32_t, uint32_t, uint32_t);
    void     cmd_set_global_time(uint32_t);
    uint32_t cmd_send_data2amc(uint32_t);
    uint32_t cmd_send_data2amc(uint32_t, uint32_t);
    uint32_t cmd_get_fidfamc(void);
    void     cmd_get_tres_i2chub(uint32_t);
    void     cmd_get_tres_adc(void);
    void     cmd_get_amc_flog(void);
    uint32_t cmd_get_amc_eeprom_r(void);
    uint32_t cmd_get_rma_config(uint32_t);
    uint32_t cmd_get_rma_config(uint32_t, uint32_t);
    uint32_t cmd_get_rma_type(void);
    uint32_t cmd_get_rma_rmap_num(uint32_t);
    uint32_t cmd_get_rma_rmap_num_all(void);
    uint32_t cmd_get_rma_info(void);
    uint64_t cmd_get_rma_ent_s(void);
    uint64_t cmd_get_rma_ent_n(void);
    uint32_t cmd_get_mc_swizzle(void);
    void     cmd_set_mc_swizzle(uint32_t);
    uint32_t cmd_get_board_pwr_ave(void);
    void     cmd_set_ltc2635_vref(uint32_t, uint32_t);
    void     cmd_set_i2c_dac(uint32_t, double);
    void     cmd_set_spi_dac(uint32_t, double);
    void     cmd_set_mcphy_vref(uint32_t, uint32_t);
    uint32_t cmd_cfg_gb_aging(uint32_t);
    uint32_t cmd_send_pmbus_req(uint32_t, uint32_t);
    uint32_t pmbc_command_get_raw(uint32_t, uint32_t);
    void     pmbc_command_set_raw(uint32_t, uint32_t, uint32_t);
    void     pmbc_command_vout_raw(uint32_t, uint32_t);        // 21
    void     pmbc_command_vout(uint32_t, uint32_t);            // 21
    void     pmbc_command_vout_droop(uint32_t, uint32_t);      // 28
    void     pmbc_command_iout_oc_fault(uint32_t, uint32_t);   // 46
    void     pmbc_command_ot_fault_limit(uint32_t, uint32_t);  // 4F
    void     pmbc_command_ot_warn_limit(uint32_t, uint32_t);   // 51
    void     pmbc_command_power_on(uint32_t, uint32_t);        // 5E
    void     pmbc_command_power_off(uint32_t, uint32_t);       // 5F
    uint32_t pmbc_command_read_vout_raw(uint32_t);             // 8B
    uint32_t pmbc_command_read_vout(uint32_t);                 // 8B
    uint32_t pmbc_command_read_iout_raw(uint32_t);             // 8C
    uint32_t pmbc_command_read_iout(uint32_t);                 // 8C
    uint32_t pmbc_command_read_temp_raw(uint32_t);             // 8D
    uint32_t pmbc_command_read_temp(uint32_t);                 // 8D
    uint32_t pmbc_command_read_pout_raw(uint32_t);             // 96
    uint32_t pmbc_command_read_pout(uint32_t);                 // 96
    uint32_t pmbc_command_read_ic_did(uint32_t);               // AD
    uint32_t cmd_vr_info_dump_by_page(uint32_t);
    uint32_t cmd_cfg_ext_pmon(uint32_t, uint32_t);
    uint32_t cmd_cfg_ext_pmon_r(uint32_t, uint32_t);
    void     cmd_cfg_ext_pmon_w(uint32_t, uint32_t, uint32_t);
    uint32_t epmc_read_vraw_shunt(uint32_t);   // 01
    uint32_t epmc_read_vraw_bus(uint32_t);     // 02
    uint32_t epmc_read_praw(uint32_t);         // 03
    uint32_t epmc_read_craw(uint32_t);         // 04
    uint32_t epmc_read_calibration(uint32_t);  // 05
    void     cmd_set_clk_freq_dtu(uint32_t);
    void     cmd_set_clk_freq_ssm(uint32_t);
    void     cmd_set_clk_freq_mc(uint32_t);
    void     cmd_set_clk_freq_edf(uint32_t);
    void     cmd_set_clk_freq_edf(uint32_t, uint32_t);
    void     cmd_set_clk_freq_vdec(uint32_t);
    void     cmd_set_clk_freq_soc(uint32_t);
    uint32_t cmd_get_pn(void *, uint32_t, uint32_t);
    void     cmd_set_pn(void *, uint32_t, uint32_t);
    uint32_t cmd_get_pn_brd(void *, uint32_t);
    void     cmd_set_pn_brd(void *, uint32_t);
    uint32_t cmd_get_pn_brd_ixsp(void *, uint32_t);
    void     cmd_set_pn_brd_ixsp(void *, uint32_t);
    uint32_t cmd_get_pn_prd_ixsp(void *, uint32_t);
    void     cmd_set_pn_prd_ixsp(void *, uint32_t);
    uint32_t cmd_get_sn(void *, uint32_t, uint32_t);
    void     cmd_set_sn(void *, uint32_t, uint32_t);
    uint32_t cmd_get_sn_brd(void *, uint32_t);
    void     cmd_set_sn_brd(void *, uint32_t);
    uint32_t cmd_get_sn_brd_ixsp(void *, uint32_t);
    void     cmd_set_sn_brd_ixsp(void *, uint32_t);
    uint32_t cmd_get_sn_prd_ixsp(void *, uint32_t);
    void     cmd_set_sn_prd_ixsp(void *, uint32_t);
    uint32_t cmd_get_openflag(void);
    void     cmd_set_openflag(uint32_t);
    uint32_t cmd_get_manu_name(void *, uint32_t);
    void     cmd_set_manu_date(uint32_t);
    uint32_t cmd_get_manu_date(void);
    uint32_t cmd_get_model(void *, uint32_t, uint32_t);
    void     cmd_set_model(void *, uint32_t, uint32_t);
    uint32_t cmd_get_model_brd_ixsp(void *, uint32_t);
    void     cmd_set_model_brd_ixsp(void *, uint32_t);
    uint32_t cmd_get_model_prd_ixsp(void *, uint32_t);
    void     cmd_set_model_prd_ixsp(void *, uint32_t);
    void     cmd_set_edc_ldidt_ctrl(uint32_t, uint32_t);
    void     cmd_set_edc_ctrl(bool);
    void     cmd_set_ldidt_ctrl(bool);
    void     cmd_set_pid_feed_data_ctrl(uint32_t);
    void     cmd_set_pid_config(uint32_t);
    void     cmd_set_pid_config_point(uint32_t, uint32_t);
    uint32_t cmd_get_pid_status(void *, uint32_t);
    uint32_t cmd_get_dpm_status(void *, uint32_t);
    uint32_t cmd_off_chip_ctrl(uint32_t, uint32_t);
    void     cmd_off_chip_edcc_dtu_set(bool);
    bool     cmd_off_chip_edcc_dtu_get(void);
    void     cmd_off_chip_edcc_soc_set(bool);
    bool     cmd_off_chip_edcc_soc_get(void);
    void     cmd_off_chip_vddc_dtu_set(bool, uint32_t);
    bool     cmd_off_chip_vddc_dtu_get(uint32_t);
    void     cmd_off_chip_vddc_soc_set(bool, uint32_t);
    bool     cmd_off_chip_vddc_soc_get(uint32_t);
    uint32_t cmd_rfw_prepare_update(uint32_t, uint32_t);
    void     cmd_rfw_load_finish(uint32_t);
    uint32_t cmd_rfw_boot_complete(void);
    void     cmd_set_kfc_lv(uint32_t, uint32_t);
    uint32_t cmd_get_kfc_lv(uint32_t);
    void     cmd_set_kfc_lv_dtu_single(uint32_t);
    void     cmd_set_kfc_lv_soc_single(uint32_t);
    void     cmd_set_kfc_lv_dtu(uint32_t);
    uint32_t cmd_get_kfc_lv_dtu(void);
    void     cmd_set_kfc_lv_soc(uint32_t);
    uint32_t cmd_get_kfc_lv_soc(void);
    uint32_t cmd_get_ocp_threshold(void);
    void     cmd_set_ocp_threshold(uint32_t);

 public:
    std::string handle_cmd_dec(uint32_t, const std::string &);
};

}  // namespace cmd
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_CMD_SSM_CMD_SCORPIO_H_
