/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_IVM_SSM_IVM_SCORPIO_H_
#define HARDWARE_SSM_IVM_SSM_IVM_SCORPIO_H_

#include <string>

#include "hardware/include/ssm/ivm/ssm_ivm.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace ivm {

class SsmIvmScorpio : public SsmIvm {
 public:
    explicit SsmIvmScorpio(Ssm *ssm) : SsmIvm(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmIvmScorpio() {}

 public:
    bool ivm_image_download(bool, const std::string &);
    bool ivm_amc_download(bool, const std::string &, uint32_t);
    bool ivm_openflag_pipo_rdump(void);
    bool ivm_openflag_pipo_write(void);

 private:
    std::string ivm_openflag_spi_r(uint32_t);
    bool        ivm_openflag_spi_w(uint32_t);
    bool        ivm_amc_size_valid(uint32_t);
    bool        ivm_amc_sync_needed(bool, void *);
    bool        ivm_amc_pipo_select(bool, uint32_t &);
    uint32_t    ivm_ppe(uint32_t, uint32_t);
    uint32_t    get_ppe_tbl(uint32_t);
    uint32_t    get_ppe_eid(uint32_t);
    bool        is_ivm_ppe(uint32_t);
    bool        is_spi_ppe(uint32_t);
    ivm_desc_t  get_ivm_desc(bool, std::string);
    ivm_desc_t  get_spi_desc(void);
    bool        clr_ivm_desc(ivm_desc_t &, bool);
    uint32_t    get_ivm_rev(ivm_desc_t &);
    void *      get_ivm_tbl(ivm_desc_t &);
    void        get_ivm_tbl_dump(ivm_desc_t &);
    bool        get_ivm_tbl_rev_valid(ivm_desc_t &);
    bool        get_ivm_ent_define_valid(ivm_desc_t &);
    void *      get_ivm_ent_load(ivm_desc_t &, uint32_t);
    ent_desc_t  get_ent_desc_by_idx(ivm_desc_t &, uint32_t);
    ent_desc_t  get_ent_desc_by_eid(ivm_desc_t &, uint32_t);
    bool        hdl_ent_desc(ent_desc_t &);
    uint32_t    get_ent_op_type_decode(uint32_t);
    bool        is_ent_desc_found(ivm_desc_t &, uint32_t);
    bool        is_ent_pipo_found(ivm_ppe_desc_t &, uint32_t, uint32_t);
    bool        chk_ent_pipo_matches(ivm_ppe_desc_t &, uint32_t, uint32_t);
    bool        elemt_board_type_valid(uint32_t);
    void *      elemt_board_type_get_hdr(ivm_desc_t &, uint32_t);
    void *      elemt_board_type_get_elemt(ivm_desc_t &, uint32_t);

 public:
    std::string handle_tool_req_get_str(const std::string &, const uint32_t &);
    std::string handle_tool_req_get_str(const std::string &, const std::string &);
    bool        handle_req_image_prep(void);
    bool        handle_req_image_info(const std::string &);
    std::string handle_req_image_version(void);
    std::string handle_req_image_btype(void);
    bool        handle_req_image_data_sync(bool, const std::string &);
    std::string handle_req_image_dump(const std::string &, const std::string &);
};

}  // namespace ivm
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_IVM_SSM_IVM_SCORPIO_H_
