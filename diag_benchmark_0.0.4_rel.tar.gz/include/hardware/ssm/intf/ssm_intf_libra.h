/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_INTF_SSM_INTF_LIBRA_H_
#define HARDWARE_SSM_INTF_SSM_INTF_LIBRA_H_

#include "hardware/include/ssm/intf/ssm_intf.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace intf {

class SsmIntfLibra : public SsmIntf {
 public:
    explicit SsmIntfLibra(Ssm *ssm) : SsmIntf(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmIntfLibra() {}

 public:
    bool ecc_mode_get_ena(void);
    void ecc_mode_set_ena(bool);
    void ecc_stat_get(SSM_ECC_STAT_t &);
};

}  // namespace intf
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_INTF_SSM_INTF_LIBRA_H_
