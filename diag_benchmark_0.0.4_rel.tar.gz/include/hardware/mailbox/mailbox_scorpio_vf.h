/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
   \file mailbox_scorpio.h
*/

#ifndef HARDWARE_MAILBOX_MAILBOX_SCORPIO_VF_H_
#define HARDWARE_MAILBOX_MAILBOX_SCORPIO_VF_H_

#include <hardware/include/mailbox.h>
#include <cstdint>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <vector>

#include "device/include/dtu.h"
#include "framework/include/init.h"
#include "hardware/mailbox/mailbox_scorpio.h"

using efvf::framework::g_ef_dtus;

namespace efvf {
namespace hardware {
namespace mailbox {
/**
 * @brief MailboxScorpio
 *
 */
class MailboxScorpioVf : public MailboxScorpio {
 public:
    MailboxScorpioVf()                                  = delete;
    explicit MailboxScorpioVf(const MailboxScorpioVf &) = delete;
    explicit MailboxScorpioVf(MailboxScorpioVf &&)      = delete;
    MailboxScorpioVf &operator=(const MailboxScorpioVf &) = delete;

    /**
     * @brief group size
     *
     * @return uint32_t
     */
    virtual uint32_t group_size() {
        return group_size_;
    }

    /**
     * @brief entry size
     *
     * @return uint32_t
     */
    virtual uint32_t size() {
        return size_;
    }

    /**
     * @brief config a mailbox entry
     *
     * @param id entry id of mailbox to config
     * @param cfg configuration info
     */
    virtual void ConfigEntry(const MbxConfig &cfg) {
        CheckIdValid(cfg.mb_id);
        MbxConfig p_cfg = cfg;
        p_cfg.mb_id     = WaitId(cfg.mb_id);
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        MailboxScorpio::ConfigEntry(p_cfg);
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
    }

    /**
     * @brief clear an entry of mailbox
     * clear entry counter by config entry with default configuration
     * @param id entry id
     */
    virtual void ClearEntry(uint32_t id) {
        CheckIdValid(id);
        auto pid = WaitId(id);
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        MailboxScorpio::ClearEntry(pid);
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
    }

    /**
     * @brief config all mailbox entry with same configuration
     * all mailbox entry will be configured with same paramter
     * all mailbox entry counter will be cleared
     * @param cfg configuration info
     */
    virtual void ConfigGlobalEntry(const MbxConfig &cfg) {
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        auto e_cfg = cfg;
        for (uint32_t mid = min_entry_id(); mid <= max_entry_id(); ++mid) {
            e_cfg.mb_id = mid;
            MailboxScorpio::ConfigEntry(e_cfg);
        }
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
        // throw std::runtime_error("vf mode should not use this feature!");
    }

    /**
     * @brief clear all mailbox entry
     * clear all entry counters by config all entry with default configuration
     */
    virtual void ClearGlobalEntry() {
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        for (uint32_t mid = min_entry_id(); mid <= max_entry_id(); ++mid) {
            MailboxScorpio::ClearEntry(mid);
        }
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
        // throw std::runtime_error("vf mode should not use this feature!");
    }

    /**
     * @brief send signal once
     *
     * @param id mailbox entry to send signal
     */
    virtual void SendSignal(uint32_t id) {
        CheckIdValid(id);
        auto pid = WaitId(id);
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        MailboxScorpio::SendSignal(pid);
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
    }

    /**
     * @brief send signal with certain uniq id once
     *
     * @param id mailbox entry to send signal
     */
    virtual void SendSignal(uint32_t id, uint32_t uniq_id) {
        CheckIdValid(id);
        auto pid = WaitId(id);
        MailboxScorpio::SendSignal(pid, uniq_id);
    }

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t GenSignalData(uint32_t id, uint32_t uniq_id) {
        CheckIdValid(id);
        auto pid = WaitId(id);
        return MailboxScorpio::GenSignalData(pid, uniq_id);
    }

    /**
     * @brief send signal with certain credits
     * it may send multi signals to the entry, which depends on the entry configuration
     * it means the mailbox entry status checking will happen
     * @param id mailbox entry to send signal
     * @param uniq_id uniq id used for sending signal
     * @param credits total credits to send
     */
    virtual void SendSignalCredit(uint32_t id, uint32_t uniq_id, uint32_t credits) {
        CheckIdValid(id);
        auto pid = WaitId(id);
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        MailboxScorpio::SendSignalCredit(pid, uniq_id, credits);
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
    }

    // sending signal and check error.
    // virtual bool SendSignalWithChk(uint32_t id)                         = 0;
    // virtual bool SendSignalSeqWithChk(uint32_t id, uint32_t times)      = 0;
    // virtual bool SendSignalCreditWithChk(uint32_t id, uint32_t credits) = 0;

    /**
     * @brief Get the Entry Status
     *
     * @param id entry id to get status
     * @return MbxStatus
     */
    virtual MbxStatus GetStatus(uint32_t id) {
        CheckIdValid(id);
        auto pid = WaitId(id);
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        auto mbx_sts = MailboxScorpio::GetStatus(pid);
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
        return mbx_sts;
    }

    /**
     * @brief Get the Entry Ref
     * get the ref value configured
     * @param id entry id to get ref
     * @return uint32_t
     */
    virtual uint32_t GetRef(uint32_t id) {
        CheckIdValid(id);
        auto pid = WaitId(id);
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        auto ref = MailboxScorpio::GetRef(pid);
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
        return ref;
    }

    /**
     * @brief Get the Entry Mail Counter
     * get the mail counter of entry
     * @param id entry id to get mail counter
     * @return uint32_t
     */
    virtual uint32_t GetCounter(uint32_t id) {
        CheckIdValid(id);
        auto pid = WaitId(id);
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        auto cnt = MailboxScorpio::GetCounter(pid);
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
        return cnt;
    }

    virtual uint32_t GetMasterId() {
        auto mst_id = MailboxScorpio::GetMasterId();
        return mst_id;
    }

    // for debug
    /**
     * @brief print an entry configuration to log
     *
     * @param id entry id to pring
     */
    virtual void PrintConfig(uint32_t id) {
        CheckIdValid(id);
        auto pid = WaitId(id);
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        MailboxScorpio::PrintConfig(pid);
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
    }

    /**
     * @brief print an entry status to log
     *
     * @param id entry id to print
     */
    virtual void PrintStatus(uint32_t id) {
        CheckIdValid(id);
        auto pid = WaitId(id);
        hw_->dtu_->get_di().pf_->p_access_lock_->LockWait(5);
        MailboxScorpio::PrintStatus(pid);
        hw_->dtu_->get_di().pf_->p_access_lock_->Unlock();
    }

    virtual std::vector<uint32_t> GetErrGroup() {
        std::vector<uint32_t> err_groups;
        std::bitset<32>       flags(GetErrRpt());
        for (uint32_t gid = 0; gid < group_size(); ++gid) {
            auto pgid = vgid2pgid(gid);
            if (flags.test(pgid)) {
                err_groups.push_back(gid);
            }
        }
        return err_groups;
    }

    virtual bool ChkGroupErr(uint32_t group_id) {
        CheckGroupIdValid(group_id);
        auto                  p_group_id = vgid2pgid(group_id);
        std::vector<uint32_t> err_groups;
        std::bitset<32>       flags(GetErrRpt());
        return flags.test(p_group_id);
    }

    virtual void GetErrInfo(uint32_t group_id, MbxErr *err_info) {
        CheckGroupIdValid(group_id);
        auto           p_group_id = vgid2pgid(group_id);
        ErrCode0Helper code0;
        ErrCode1Helper code1;
        code0.val               = Read(code0_offsets_[p_group_id]);
        code1.val               = Read(code1_offsets_[p_group_id]);
        err_info->group_id      = group_id;
        err_info->uniq_id_err   = false;
        err_info->overflow_err  = false;
        err_info->underflow_err = false;
        if (code1.reg.err == 0b00 /*&& code0.reg.master_id != 0*/) {
            err_info->uniq_id_err = true;
        } else if (code1.reg.err == 0b01 /*&& code0.reg.master_id != 0*/) {
            err_info->overflow_err = true;
        } else if (code1.reg.err == 0b10 && code0.reg.master_id == 0) {
            err_info->underflow_err = true;
        } else {
            LOG_ERROR("no err happened in mailbox");
            throw;
        }
        err_info->code0             = code0.val;
        err_info->code1             = code1.val;
        err_info->master_id         = code0.reg.master_id;
        err_info->ref               = code0.reg.ref;
        err_info->counter           = code0.reg.counter;
        err_info->upd_mode          = code1.reg.upd_mode;
        err_info->cre_mode          = code1.reg.cre_mode;
        err_info->trg_mode          = code1.reg.trg_mode;
        err_info->inc_mode          = code1.reg.inc_mode;
        err_info->signaling_uniq_id = code1.reg.signaling_uniq_id;
        err_info->mbx_uniq_id       = code1.reg.mbx_uniq_id;
        err_info->mbx_id            = pid2vid(code1.reg.mbx_id);
    }

    virtual void ClearErr(uint32_t group_id) {
        CheckGroupIdValid(group_id);
        auto            p_group_id = vgid2pgid(group_id);
        std::bitset<32> flags(0x0);
        flags.set(p_group_id);
        Write(mail_box_err_rpt_offset_, flags.to_ullong());
    }

    /**
     * @brief Construct a new Mailbox Scorpio object
     *
     * @param size mailbox entry size
     * @param reg_cfg mailbox entry configuration
     */
    MailboxScorpioVf(Hardware *hw, const MailboxScorpioParam &reg_cfg)
        : MailboxScorpio(hw, reg_cfg) {
        if (!hw || !hw->dtu_) {
            throw;
        }
        auto dtu         = hw->dtu_;
        auto vf_idx      = hw->dtu_->get_di().vf_idx_;
        auto vf_size     = hw->dtu_->get_di().vf_num_;
        vf_entry_size_   = reg_cfg.entry_size / vf_size;
        vf_entry_offset_ = vf_entry_size_ * vf_idx;
        vf_min_entry_id_ = vf_entry_offset_;
        vf_max_entry_id_ = vf_entry_offset_ + vf_entry_size_ - 1;
        vf_min_group_id_ = vf_min_entry_id_ / 64;
        vf_max_group_id_ = vf_max_entry_id_ / 64;
        vf_group_offset_ = vf_min_group_id_;
        vf_group_size_   = vf_max_group_id_ - vf_min_group_id_ + 1;
    }

 private:
    /**
     * @brief min valid entry id for vf mode
     *
     * @return uint32_t
     */
    virtual uint32_t min_entry_id() {
        return vf_entry_offset_;
    }

    /**
     * @brief max valid entry id for vf mode
     *
     * @return uint32_t
     */
    virtual uint32_t max_entry_id() {
        return vf_entry_offset_ + vf_entry_size_ - 1;
    }

    /**
     * @brief max valid group id for vf mode
     *
     * @return uint32_t
     */
    virtual uint32_t max_group_id() {
        return vf_max_group_id_;
    }

    /**
     * @brief min valid group id for vf mode
     *
     * @return uint32_t
     */
    virtual uint32_t min_group_id() {
        return vf_min_group_id_;
    }

    /**
     * @brief get physical entry id from virtual entry id
     *
     * @param id
     * @return uint32_t
     */
    virtual uint32_t WaitId(uint32_t id) {
        CheckIdValid(id);
        return id + vf_entry_offset_;
    }

    /**
     * @brief get virtual entry id from physical entry id
     *
     * @param id
     * @return uint32_t
     */
    virtual uint32_t pid2vid(uint32_t id) {
        if (id <= max_entry_id() && id >= min_entry_id()) {
            return id - vf_entry_offset_;
        } else {
            throw std::runtime_error("physical entry id not belong to this vf");
        }
    }

    virtual uint32_t vgid2pgid(uint32_t gid) {
        CheckGroupIdValid(gid);
        return gid + vf_group_offset_;
    }

    virtual uint32_t pgid2vgid(uint32_t gid) {
        if (gid <= max_group_id() && gid >= min_group_id()) {
            return gid - vf_group_offset_;
        } else {
            throw std::runtime_error("physical entry id not belong to this vf");
        }
    }

    /// vf entry offset
    uint32_t vf_entry_offset_;
    /// vf entry size
    uint32_t vf_entry_size_;
    /// vf group offset
    uint32_t vf_group_offset_;
    /// vf group size
    uint32_t vf_group_size_;
    /// vf min entry id
    uint32_t vf_min_entry_id_;
    /// vf max entry id
    uint32_t vf_max_entry_id_;
    /// vf min group id
    uint32_t vf_min_group_id_;
    /// vf max group id
    uint32_t vf_max_group_id_;

 public:
    /**
     * @brief Get the Mailbox object
     *
     * @param hw hardware ptr
     * @param reg_cfg mailbox entry configuration
     * @return MailboxScorpio
     */
    static MailboxScorpioVf *GetMailboxVf(Hardware *hw, const MailboxScorpioParam &reg_cfg) {
        std::ostringstream oss;
        if (!hw) {
            throw std::runtime_error("get mailbox failed! hw nullptr!");
        }
        if (!hw->dtu_) {
            throw std::runtime_error("cannot get dtu ptr form hardware!");
        }
        if (!hw->dtu_->IsVf()) {
            throw std::runtime_error("dtu is not in vf mode!");
        }
        uint32_t vf_size = hw->dtu_->get_di().vf_num_;
        uint32_t vf_id   = hw->dtu_->get_di().vf_idx_;
        if (vf_id >= vf_size) {
            oss << "invalid vf id 0x" << std::hex << vf_id << ", vf size is 0x" << std::hex
                << vf_size << "!";
            throw std::runtime_error(oss.str());
        }
        auto entry_size = reg_cfg.entry_size;
        if (vf_size > entry_size || (entry_size % vf_size != 0)) {
            oss << "invalid vf size 0x" << std::hex << vf_size << ", mailbox entry size is 0x"
                << std::hex << entry_size << "!";
            throw std::runtime_error(oss.str());
        }
        if (entry_size > 64 && entry_size != 128 && entry_size != 256 && entry_size != 512) {
            oss << "invalid size for mailbox entry 0x" << std::hex << entry_size
                << ", must be less than 64 or 128, 256, 512!";
            throw std::runtime_error(oss.str());
        }
        if (reg_cfg.code0_offsets.size() != reg_cfg.code1_offsets.size()) {
            oss << "num of error code_0 offsets 0x" << std::hex << reg_cfg.code0_offsets.size()
                << " and num of error code_1 offsets 0x" << std::hex
                << reg_cfg.code1_offsets.size() << " mismatch!";
            throw std::runtime_error(oss.str());
        }
        if (reg_cfg.code0_offsets.size() != (entry_size / 64)) {
            oss << "num of error code0/1 offsets 0x" << std::hex
                << reg_cfg.code0_offsets.size() << " and num of entry groups 0x" << std::hex
                << entry_size / 64 << " mismatch!";
            throw std::runtime_error(oss.str());
        }
        return new MailboxScorpioVf(hw, reg_cfg);
    }
};

}  // namespace mailbox
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_MAILBOX_MAILBOX_SCORPIO_VF_H_
