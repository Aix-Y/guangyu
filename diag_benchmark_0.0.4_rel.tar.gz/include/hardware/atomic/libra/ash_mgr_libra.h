/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_ATOMIC_LIBRA_ASH_MGR_LIBRA_H_
#define HARDWARE_ATOMIC_LIBRA_ASH_MGR_LIBRA_H_
#include <memory>
#include <vector>
#include "hardware/include/atomic/ash_mgr.h"
#include "hardware/include/atomic/atomic_ctx.h"

namespace efvf {
namespace hardware {
namespace atomic {

class AshMgrLibra : public AshMgr {
 public:
    AshMgrLibra(const std::shared_ptr<spdlog::logger> &logger, const Dtu &dtu);
    virtual ~AshMgrLibra();

    virtual bool                    Init();
    virtual std::vector<AmoExcpInf> GetException();
    virtual void                    ClearIntStat();
    virtual void                    OvflowClamp(bool);
    virtual void                    PrefetchOverride(bool);

 protected:
    std::vector<Ash *> ash_list_;
};

}  // namespace atomic
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_ATOMIC_LIBRA_ASH_MGR_LIBRA_H_
