/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_ATOMIC_ATOM_CALC_H_
#define HARDWARE_ATOMIC_ATOM_CALC_H_
#include <algorithm>
#include <memory>
#include <string>
#include <vector>
#include "device/include/dtu.h"
#include "efloat/src/efloat.h"
#include "framework/include/mem.h"
#include "framework/include/utils.h"
#include "hardware/include/atomic/atomic_ctx.h"
#include "hardware/include/gdte/gdte.h"

using efvf::device::Dtu;
using efvf::framework::mem::Mem;
using efvf::hardware::atomic::AtomAttr;
using efvf::hardware::atomic::AtomOp;
using efvf::hardware::gdte::Gdte;
using Dims      = std::vector<dim_t>;
namespace utils = efvf::framework::utils;

namespace efvf {
namespace hardware {
namespace atomic {

class AmoCalc {
 public:
    virtual ~AmoCalc() {}

    // for linear copy -- all wstrb valid
    virtual void AddVecCalc(const AtomAttr *attr, const Mem *src, const Mem *dst, Mem *exp,
        uint64_t offs = 0, uint64_t length = 0);

    // for dsl copy -- partial wstrb valid
    virtual void AddVecCalc(
        const AtomAttr *attr, const Mem *src, const Mem *dst, const Dims dst_offs, Mem *exp);

    virtual void MaxVecCalc(const AtomAttr *attr, const Mem *src, const Mem *dst, Mem *exp,
        uint64_t offs = 0, uint64_t length = 0);

    virtual uint8_t GetBpe(std::string dtype);

    virtual bool IsAtomOpValid(const std::string &op_name, const std::string &dtype) const {}
    virtual uint32_t GetAtomOpInt(const std::string &inst_s) const {}
    virtual AtomOp GetAtomOpType(const std::string &op_name) const {}
    virtual std::string GetAtomOpName(const AtomOp &op_type) const {}
    virtual std::string GetAtomOpStr(uint32_t opcode) const {}
    virtual bool IsInstStoreOnly(const std::string &inst_s) const {}
    virtual uint32_t GetDtypeInt(const std::string &dtype) const {}
    virtual uint32_t                                GenAtomicUserBits4Wqe(
        const std::string &inst_s, const uint32_t data_type) = 0;

    virtual bool IsGreaterEqual(const Mem *lhs, const Mem *rhs, std::string dtype,
        uint64_t offs = 0, uint64_t length = 0) const;

    virtual void MemSet(Mem *mem, std::string data_type, float value);
    virtual void GenIncrementPattern(
        Mem *mem, std::string data_type, float value, float inc) const;
    virtual void GenNanPattern(
        Mem *mem, std::string data_type, uint64_t start = 0, uint64_t size = 0) const;

    virtual int32_t RectifyDataValid(std::string data_type, int32_t data) const;

    virtual void ConverToDataType(std::string data_type, void *dst, float in) const;
    virtual void ConverToDataType(std::string data_type, void *dst, uint64_t in) const;

 protected:
    template <typename T>
    void Add(const Mem *src, const Mem *dst, Mem *out, uint64_t offs, uint64_t length);

    void Add_fp32_efloat(
        const Mem *src, const Mem *dst, Mem *out, uint64_t offs, uint64_t length);

    void Add_bf16_fp16(const Mem *src, const Mem *dst, Mem *out, uint64_t offs,
        uint64_t length, std::string dtype);

    template <typename T>
    void Add(const Mem *src, const Mem *dst, Mem *out, const Dims &dst_offs);

    void Add_bf16_fp16(
        const Mem *src, const Mem *dst, Mem *out, const Dims &dst_offs, std::string dtype);
    template <typename T>
    using IsNanFunc = bool (*)(T);
    template <typename T>
    using IsGtFunc = bool (*)(T, T, uint_fast8_t, uint_fast8_t *, bool);

    template <typename T>
    void AmoMax(const Mem *src, const Mem *dst, Mem *out, uint64_t offs, uint64_t length,
        AtomOp op = AtomOp::vMAX, IsNanFunc<T> is_nan = nullptr,
        IsGtFunc<T> is_gt = nullptr) const;

    // add a src tensor with dst tensor with offset,
    template <typename T>
    void TensorAdd(const Mem *src, const Mem *dst, Mem *out, const Dims &dst_offs);

    template <typename T>
    bool IsGreaterEqual(const Mem *lhs, const Mem *rhs, uint64_t offs, uint64_t length) const;

    bool IsGreaterEqualBfFp16(const Mem *lhs, const Mem *rhs, uint64_t offs, uint64_t length,
        std::string dtype) const;

    template <typename T>
    void GenIncrementPattern(Mem *mem, float value, float inc) const;

    void GenIncrementPatternFp16(Mem *mem, float value, float inc) const;

    void GenIncrementPatternBp16(Mem *mem, float value, float inc) const;

    template <typename T>
    void GenNanPattern(Mem *mem, T value, uint64_t start, uint64_t size) const;

 protected:
    const Dtu *                     dtu_;
    std::shared_ptr<spdlog::logger> logger_;
};

// for linear copy -- all wstrb valid
template <typename T>
void AmoCalc::Add(const Mem *src, const Mem *dst, Mem *out, uint64_t offs, uint64_t length) {
    LOG_ASSERT(
        src != nullptr && dst != nullptr && out != nullptr, "{}, nullptr", __FUNCTION__);
    LOG_ASSERT(src->GetSize() == dst->GetSize() && src->GetSize() == out->GetSize(),
        "{}, mem size not equal", __FUNCTION__);

    LOG_ASSERT((src->GetHostAddr() + offs) % sizeof(T) == 0,
        "{}, src start not aligned to data type", __FUNCTION__);
    LOG_ASSERT((dst->GetHostAddr() + offs) % sizeof(T) == 0,
        "{}, dst start not aligned to data type", __FUNCTION__);
    LOG_ASSERT(
        length % sizeof(T) == 0, "{}, calc size not aligned to data type", __FUNCTION__);
    LOG_ASSERT(offs + length <= src->GetSize(), "{}, exceeding src boundary", __FUNCTION__);
    LOG_ASSERT(offs + length <= dst->GetSize(), "{}, exceeding dst boundary", __FUNCTION__);
    LOG_ASSERT(offs + length <= out->GetSize(), "{}, exceeding out boundary", __FUNCTION__);

    T *t_src = static_cast<T *>(static_cast<void *>(src->GetHostPtr() + offs));
    T *t_dst = static_cast<T *>(static_cast<void *>(dst->GetHostPtr() + offs));
    T *t_out = static_cast<T *>(static_cast<void *>(out->GetHostPtr() + offs));

    const uint64_t unroll_k = 4;
    uint64_t       remain   = length / sizeof(T) % unroll_k;
    uint64_t       loop     = length / sizeof(T) / unroll_k;
    uint64_t       pos      = loop * unroll_k;

    for (uint64_t k = 0; k < pos; k += unroll_k) {
        t_out[k]     = t_src[k] + t_dst[k];
        t_out[k + 1] = t_src[k + 1] + t_dst[k + 1];
        t_out[k + 2] = t_src[k + 2] + t_dst[k + 2];
        t_out[k + 3] = t_src[k + 3] + t_dst[k + 3];
    }

    for (uint64_t k = 0; k < remain; k++) {
        t_out[pos + k] = t_src[pos + k] + t_dst[pos + k];
    }
}

// used for dte deslice (partial wr) -- only partial wstrb valid
template <typename T>
void AmoCalc::Add(const Mem *src, const Mem *dst, Mem *out, const Dims &dst_offs) {
    TensorAdd<T>(src, dst, out, dst_offs);
}

// add a src tensor to dst tensor from offset, result at out;
template <typename T>
void AmoCalc::TensorAdd(const Mem *src, const Mem *dst, Mem *out, const Dims &dst_offs) {
    LOG_ASSERT(
        src->GetDims().size() == 4 || (src->GetDims().size() == 5 && src->GetDims()[4] == 1),
        "src tensor not rank 4");
    LOG_ASSERT(
        dst->GetDims().size() == 4 || (dst->GetDims().size() == 5 && dst->GetDims()[4] == 1),
        "dst tensor not rank 4");
    if (dst != out) {
        LOG_WARN("{}: init out memory by copying from dst memory", __FUNCTION__);
        auto odte = dtu_->GetOdte(0, 0);
        odte->Init();
        odte->Copy(const_cast<Mem *>(dst), out, 0, 0, 0, 10000);
    }

    auto src_shape = src->GetDims();
    auto dst_shape = dst->GetDims();
    auto end_dims  = utils::VecAdd<dim_t>(src_shape, dst_offs);

    // clang-format off
    for (dim_t n = dst_offs[3]; n < dst_shape[3] && n < end_dims[3]; n++) {
    for (dim_t c = dst_offs[2]; c < dst_shape[2] && c < end_dims[2]; c++) {
    for (dim_t h = dst_offs[1]; h < dst_shape[1] && h < end_dims[1]; h++) {
        auto ns = (n - dst_offs[3]);
        auto cs = (c - dst_offs[2]);
        auto hs = (h - dst_offs[1]);
        dim_t src_pos = ns * src_shape[2] * src_shape[1] * src_shape[0] +
                        cs * src_shape[1] * src_shape[0] +
                        hs * src_shape[0];

        dim_t dst_pos = n * dst_shape[2] * dst_shape[1] * dst_shape[0] +
                        c * dst_shape[1] * dst_shape[0] +
                        h * dst_shape[0] + dst_offs[0];

        dim_t count = std::min((dst_shape[0] - dst_offs[0]), (end_dims[0] - dst_offs[0]));
        auto src_ptr = static_cast<T *>(static_cast<void*>(src->GetHostPtr()));
        auto dst_ptr = static_cast<T *>(static_cast<void*>(dst->GetHostPtr()));
        auto out_ptr = static_cast<T *>(static_cast<void*>(out->GetHostPtr()));
        for (dim_t k = 0; k < count; k++, dst_pos++, src_pos++) {
            out_ptr[dst_pos] = dst_ptr[dst_pos] + src_ptr[src_pos];
        }
    }
    }
    }
    // clang-format on
}

template <typename T>
bool AmoCalc::IsGreaterEqual(
    const Mem *lhs, const Mem *rhs, uint64_t offs, uint64_t length) const {
    LOG_ASSERT(offs + length <= lhs->GetSize(), "{}, exceeding lhs boundary", __FUNCTION__);
    LOG_ASSERT(offs + length <= rhs->GetSize(), "{}, exceeding rhs boundary", __FUNCTION__);

    bool status = true;
    T *  t_lhs  = static_cast<T *>(static_cast<void *>(lhs->GetHostPtr() + offs));
    T *  t_rhs  = static_cast<T *>(static_cast<void *>(rhs->GetHostPtr() + offs));

    const uint64_t unroll_k = 4;
    uint64_t       remain   = length / sizeof(T) % unroll_k;
    uint64_t       loop     = length / sizeof(T) / unroll_k;
    uint64_t       pos      = loop * unroll_k;
    uint64_t       fail_pos = 0;

    for (uint64_t k = 0; k < pos; k += unroll_k) {
        bool st0 = (t_lhs[k] >= t_rhs[k]);
        bool st1 = (t_lhs[k + 1] >= t_rhs[k + 1]);
        bool st2 = (t_lhs[k + 2] >= t_rhs[k + 2]);
        bool st3 = (t_lhs[k + 3] >= t_rhs[k + 3]);
        bool sts = st0 && st1 && st2 && st3;
        if (!sts) {
            fail_pos = k;
            status   = false;
            break;
        }
    }

    for (uint64_t k = 0; k < remain; k++) {
        bool sts = (t_lhs[pos + k] >= t_rhs[pos + k]);
        if (!sts) {
            fail_pos = pos + k;
            status   = false;
            break;
        }
    }

    if (!status) {
        T *lhs = t_lhs + fail_pos;
        T *rhs = t_rhs + fail_pos;
        LOG_ERROR("{}: not met condition: lhs >= rhs at offset {:#x}", __FUNCTION__,
            fail_pos * sizeof(T));
        // LOG_ERROR("{}: lhs addr {:#x}", __FUNCTION__,
        // static_cast<uint64_t>(reinterpret_cast<void *>(lhs)));
        // LOG_ERROR("{}: rhs addr {:#x}", __FUNCTION__,
        // static_cast<uint64_t>(reinterpret_cast<void *>(rhs)));

        for (uint64_t i = 0; i < unroll_k; i++) {
            LOG_ERROR("lhs {:#x}  :    {:#x} rhs", lhs[i], rhs[i]);
        }
    }

    return status;
}

template <typename T>
void AmoCalc::GenIncrementPattern(Mem *mem, float value, float inc) const {
    T        init = static_cast<T>(value);
    T        incr = static_cast<T>(inc);
    auto     ptr  = reinterpret_cast<T *>(mem->GetHostPtr());
    auto     size = mem->GetSize();
    uint64_t kele = size / sizeof(T);
    uint64_t krem = size % sizeof(T);
    LOG_ASSERT(krem == 0, "target memory size not align to data type");

    const uint64_t unroll   = 4;
    auto           uke_loop = kele / unroll;
    auto           ukremain = kele % unroll;
    for (uint64_t i = 0; i < kele; i += unroll, init += 4 * incr) {
        ptr[i + 0] = init + 0;
        ptr[i + 1] = init + incr * 1;
        ptr[i + 2] = init + incr * 2;
        ptr[i + 3] = init + incr * 3;
    }
    auto pos = uke_loop * unroll;
    for (uint64_t i = pos; i < kele; i++) {
        ptr[i] = init++;
    }
}

template <typename T>
void AmoCalc::GenNanPattern(Mem *mem, T value, uint64_t start, uint64_t size) const {
    auto vptr = static_cast<void *>(mem->GetHostPtr());
    auto ptr  = reinterpret_cast<T *>(vptr);
    auto offs = (start / sizeof(T));
    auto num  = (size / sizeof(T));
    auto end  = offs + num;

    for (uint64_t i = offs; i < end; i++) {
        ptr[i] = value;
    }
}

template <typename T>
void AmoCalc::AmoMax(const Mem *src, const Mem *dst, Mem *out, uint64_t offs, uint64_t length,
    AtomOp op, IsNanFunc<T> is_nan, IsGtFunc<T> is_gt) const {
    // parameter check
    LOG_ASSERT(
        src != nullptr && dst != nullptr && out != nullptr, "{}, nullptr", __FUNCTION__);
    LOG_ASSERT(src->GetSize() == dst->GetSize() && src->GetSize() == out->GetSize(),
        "{}, mem size not equal", __FUNCTION__);

    LOG_ASSERT((src->GetHostAddr() + offs) % sizeof(T) == 0,
        "{}, src start not aligned to data type", __FUNCTION__);
    LOG_ASSERT((dst->GetHostAddr() + offs) % sizeof(T) == 0,
        "{}, dst start not aligned to data type", __FUNCTION__);
    LOG_ASSERT(
        length % sizeof(T) == 0, "{}, calc size not aligned to data type", __FUNCTION__);
    LOG_ASSERT(offs + length <= src->GetSize(), "{}, exceeding src boundary", __FUNCTION__);
    LOG_ASSERT(offs + length <= dst->GetSize(), "{}, exceeding dst boundary", __FUNCTION__);
    LOG_ASSERT(offs + length <= out->GetSize(), "{}, exceeding out boundary", __FUNCTION__);

    //
    auto is_a_nan = [](T a) { return false; };
    auto is_a_gt  = [](T a, T b, uint_fast8_t, uint_fast8_t *, bool) { return (a > b); };
    is_nan        = (!is_nan) ? is_a_nan : is_nan;
    is_gt         = (!is_gt) ? is_a_gt : is_gt;

    auto ef_amo_max = [](T v0, T v1, IsNanFunc<T> is_nan, IsGtFunc<T> is_gt) {
        uint_fast8_t excp;
        if (is_nan(v0))
            return v0;
        if (is_nan(v1)) {
            return v1;
        } else {
            return (is_gt(v0, v1, 0, &excp, false) ? v0 : v1);
        }
    };

    auto ef_amo_maxnum = [](T v0, T v1, IsNanFunc<T> is_nan, IsGtFunc<T> is_gt) {
        uint_fast8_t excp;
        if (is_nan(v0)) {
            return v1;
        } else if (is_nan(v1)) {
            return v0;
        } else {
            return (is_gt(v0, v1, 0, &excp, false) ? v0 : v1);
        }
    };

    T (*func)(T, T, IsNanFunc<T> is_nan, IsGtFunc<T> is_gt);
    func = (op == AtomOp::vMAX) ? ef_amo_max : ef_amo_maxnum;

    T *            t_src = static_cast<T *>(static_cast<void *>(src->GetHostPtr() + offs));
    T *            t_dst = static_cast<T *>(static_cast<void *>(dst->GetHostPtr() + offs));
    T *            t_out = static_cast<T *>(static_cast<void *>(out->GetHostPtr() + offs));
    uint64_t       count = length / sizeof(T);
    const uint64_t pos   = 0;
    for (uint64_t k = 0; k < count; k++) {
        t_out[pos + k] = func(t_src[pos + k], t_dst[pos + k], is_nan, is_gt);
    }
}

extern AmoCalc *GetAmoCalc(const Dtu *dtu);

}  // namespace atomic
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_ATOMIC_ATOM_CALC_H_
