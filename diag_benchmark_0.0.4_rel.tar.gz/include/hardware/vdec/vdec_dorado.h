/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_VDEC_VDEC_DORADO_H_
#define HARDWARE_VDEC_VDEC_DORADO_H_
#include "hardware/include/vdec/vdec.h"

namespace efvf {
namespace hardware {
namespace vdec {
DefineVdec(DORADO, VdecDorado, VDEC_REGMODEL);

}  // namespace vdec
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_VDEC_VDEC_DORADO_H_
