/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_LIBRA_MC_H_
#define HARDWARE_MC_LIBRA_MC_H_

#include <bitset>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <vector>
#include "hardware/include/mc/mc.h"
#include "hardware/include/mc/mc_mgr.h"
#include "hardware/include/mc/mc_phy.h"
#include "hardware/include/mc/mc_reg_op.hpp"
#include "hardware/include/system_adapter.h"

using efvf::hardware::system_adapter::SystemAdapter;

namespace efvf {
namespace hardware {
namespace mc {

#define MC_WRAPPER_NUM_ON_MC (4)
#define MC_CHAN_NUM_ON_MC_WRAPPER (4)

#define MTC_ACQ_MEM_DEPTH 16  // each ACQ Memory Entry is 211 bits wide
/* MC interrupt mask/status */
#define MC_INTR_AXI_OUT_OF_RANGE (0x1)
#define MC_INTR_UC_DQ_WR_PARITY_ERR (0x1 << 1)
#define MC_INTR_UC_DQ_RD_PARITY_ERR (0x1 << 2)
#define MC_INTR_CECC_ERR (0x1 << 3)
#define MC_INTR_CECC_THRESHOLD (0x1 << 4)
#define MC_INTR_UECC_ERR (0x1 << 5)
#define MC_INTR_AXI_WDATA_PARIRY_ERR (0x1 << 6)
#define MC_INTR_WDATA_PATH_TO_PHY_PARITY_ERR (0x1 << 7)
#define MC_INTR_CA_PARITY_ERR (0x1 << 16)
#define MC_INTR_CATTRIP (0x1 << 17)
#define MC_INTR_TEMP_SENSOR_CHANGE (0x1 << 18)
#define MC_INTR_CSR_PARITY_ERR (0x1 << 19)
#define MC_INTR_DFI_TRAINING_COMPLETE (0x1 << 20)
#define MC_INTR_DFI_INIT_COMPLETE (0x1 << 21)
#define MC_INTR_APB_SLV_ERR (0x1 << 23)
#define MC_INTR_ON_DIE_CECC_ERR (0x1 << 24)
#define MC_INTR_ON_DIE_UECC_ERR (0x1 << 25)
#define MC_INTR_INVALID_SEV_ERR (0x1 << 26)

/* MC IMU IRAM/DRAM */
#define MC_IMU_IRAM_SIZE (32 * 1024)
#define MC_IMU_IRAM_ADDR_OFFSET (0x5000)
#define MC_IMU_DRAM_SIZE (16 * 1024)
#define MC_IMU_DRAM_ADDR_OFFSET (0xD000)

struct ddrAddrView {
    std::bitset<3>  locPchId;
    std::bitset<2>  locChId;
    std::bitset<2>  sId;
    std::bitset<3>  ba;
    std::bitset<15> row;
    std::bitset<5>  col;
    std::bitset<1>  bg0;
    std::bitset<5>  offset;
    bool            addr_overlap;

    bool operator==(const ddrAddrView &rhs);
};

typedef struct _DDR_ADDR_VIEW_t {
    uint64_t locPchId : 3;
    uint64_t locChId : 2;
    uint64_t sId : 2;
    uint64_t ba : 3;
    uint64_t row : 15;
    uint64_t col : 5;
    uint64_t bg0 : 1;
    uint64_t offset : 5;
    uint64_t addr_overlap : 1;
    uint64_t : 27;
} DDR_ADDR_VIEW_t;

typedef union {
    uint64_t        val : 64;
    DDR_ADDR_VIEW_t f;
} DDR_ADDR_VIEW_u;

class McLibra : public Mc {
 public:
    explicit McLibra(std::shared_ptr<spdlog::logger> logger);
    virtual ~McLibra() {}

    //!
    //! @berif from Hardware
    //!
    bool         HwInit();
    virtual bool HwDeinit();
    virtual void LibInit();
    virtual bool HwInitMini();
    virtual int Deamon(int task_id, void *param);
    virtual void set_mask(const std::bitset<HW_MAX_BIT> &mask);

    /* 2.0 interface */
 public:
    uint32_t       GetGlbInst(void);
    uint32_t       GetDieId(void);
    std::string    GetName(void);
    bool           ImuSramRw(const std::string, uint32_t, uint8_t *, uint32_t);
    bool           handle_tool_req(const std::string &);
    bool           handle_tool_req(const std::string &, std::string &);
    bool           handle_tool_req(const std::string, uint64_t &, uint64_t &);
    bool           handle_tool_req(const std::string, uint64_t &);
    SystemAdapter *sa(void);

 protected:
    system_adapter::SystemAdapter *m_sa = nullptr;

 private:
    // mc related data
    std::string m_name;
    uint32_t    m_glb_inst_id;
    uint32_t    m_logic_id;
    uint32_t    m_die_id;

    uint32_t m_hbm_type;
    uint32_t m_hbm_sid_type;
    uint64_t m_capacity_in_bytes;
    uint64_t m_edf_offset;

    // hbm_row_width
    // 0: 14 bit row addr
    // 1: 15 bit row addr
    // 2: 13 bit row addr
    uint32_t m_hbm_row_width;

    // mdf_capacity
    // 0 for 1GB
    // 1 for 2GB
    // 2 for 3GB
    // 3 for 4GB
    // 5 for 6GB
    // 7 for 8GB
    // 8 for 9GB
    // 11 for 12GB
    // 15 for 16GB
    uint32_t m_mdf_capacity;
    uint64_t m_mdf_capacity_in_bytes;

    bool     m_ecc_on;
    bool     m_hash_on;
    uint32_t m_chan_hash_col[3];
    uint32_t m_bank_hash_col[3];
    uint32_t m_bg0_hash_col;
    uint32_t m_sid_hash_col[2];

    // broadcast
    uint32_t              m_wrappers_broadcast_dis;
    std::vector<uint32_t> m_wrapper_broadcast_dis;

    // bist
    // 0 for gsync, 1 for normal
    uint32_t m_bist_mode;
    // 0 for single, 1 for continuous
    uint32_t m_bist_work_mode;
    // bit.0 for PS0(mc_wrapper.0 -> mc_controller.0 -> PS0), bit.31 for PS31(mc_wrapper.3 ->
    // mc_controller.3 -> PS1)
    uint32_t              m_bist_chan_masks;
    uint32_t              m_bist_stop_on_error;
    uint32_t              m_bist_read_only;
    uint32_t              m_bist_write_only;
    uint32_t              m_bist_data_pattern;
    uint32_t              m_bist_addr_pattern;
    uint32_t              m_bist_data_invert;
    uint32_t              m_bist_addr_bits;
    uint32_t              m_bist_start_addr;
    uint32_t              m_bist_user_data_pattern;
    std::vector<uint32_t> m_bist_channels;

    // ECC
    bool     m_ecc_scrub_en;
    uint32_t m_ecc_scrub_period;
    bool     m_ecc_scrub_init_en;
    bool     m_ecc_scrub_init_rmw;
    uint32_t m_ecc_scrub_min_addr;
    uint32_t m_ecc_scrub_max_addr;
    bool     m_ecc_scrub_err_clr;
    uint32_t m_ecc_scrub_1_bit_int_threhold;
    bool     m_ecc_1_bit_err_gen;
    bool     m_ecc_2_bit_err_gen;

// DFI
#define AM_WR_CMD_INDEX (0)
#define AM_WR_AP_CMD_INDEX (1)
#define AM_RD_CMD_INDEX (2)
#define AM_RD_AP_CMD_INDEX (3)
#define AM_REFRESH_CMD_INDEX (4)
#define AM_ACT_CMD_INDEX (5)
#define AM_PRECHARGE_CMD_INDEX (6)
#define AM_PRECHARGE_ALL_CMD_INDEX (7)
#define AM_POWER_DOWN_CMD_INDEX (8)
#define AM_SELF_REFRESH_CMD_INDEX (9)
    uint64_t m_am_cmds[AM_SELF_REFRESH_CMD_INDEX + 1][32] = {{0}};

 private:
    // mc related functions
    // ECC related
    void McConfigEcc(void);
    void McEccInject(uint32_t);
    void McStopEccInject(void);
    bool McEccQueryIntStatus(std::string, uint64_t &, std::string &);
    bool McEccClearIntStatus(uint64_t);
    bool McEccConfigInt(uint64_t, bool);
    // interrupt/status relates
    bool McConfigInt(uint64_t, bool);
    bool McGetIntStatus(uint32_t, uint32_t);
    void McClrIntStatus(uint32_t, uint32_t);
    // mc top related
    bool McImuIramParityOp(std::string, uint64_t &);
    bool McImuDramParityOp(std::string, uint64_t &);
    bool McSramCtrl(std::string, uint64_t &);
    bool McImuOp(std::string, uint64_t &);
    bool McRasOp(std::string, uint64_t &);
    bool McSramRas(std::string, uint64_t &);
    // ddr controller
    bool McMrsWrite(uint32_t, uint32_t, uint32_t);
    bool McMrsRead(uint32_t, uint32_t, uint64_t &);
    bool McBistOp(std::string, uint64_t &);
    bool McBistOp(std::string, uint8_t *);
    bool McBusInvertOp(std::string);

    Hardware *McGetWrapperItems(uint32_t, std::string);
    uint64_t  addr_trans_loc2ddr(
        uint64_t i_addr, ddrAddrView &ddr_view, bool mdf_hash_bypass, uint32_t mdf_capacity);
    uint64_t addr_trans_ddr2loc(ddrAddrView &ddr_view, bool mdf_hash_bypass,
        uint32_t mdf_capacity, DDR_ADDR_VIEW_u pa);
    bool check_addr_range(uint32_t mdf_capacity, uint64_t addr, uint32_t size_in_byte);

    // 1 HBM device have 16 channel. 4 MC wrapper, each wrapper have 4 channel(64bits)
    void McChannelRdSel(uint32_t);
    void McChannelWrSel(uint32_t);
    bool McHandleAmReq(const std::string req, uint64_t &item, uint64_t &val);
    bool McHandleGetDramTimingReq(const std::string req, uint64_t &item, uint64_t &val);
    bool McHandleSetDramTimingReq(const std::string req, uint64_t &item, uint64_t &val);
    bool McHandleEccErrInj(const std::string req, uint64_t &val);
    bool McHandleEccErrclr(const std::string req, uint64_t &val);
    bool McHandleEccQueryErrStat(const std::string req, uint64_t &val);
    void McHandleCeccPrintErrStat(uint32_t chn);
    void McHandleEccClrErr(const std::string req, uint64_t &val);
    bool McAddrRangeCheckQueryErrStat(const std::string req, uint64_t &val);
    void McAddrRangeCheckClrErr(const std::string req, uint64_t &val);
    bool McOutOfAxiAddrQueryErrStat(const std::string req, uint64_t &val);
    void McOutOfAxiAddrClrErr(const std::string req, uint64_t &val);
    bool McWrParityProtectQueryErrStat(const std::string req, uint64_t &val);
    void McWrParityProtectClrErr(const std::string req, uint64_t &val);
    bool McHandleCaParityQueryErrStat(const std::string req, uint64_t &val);
    void McHandleCaParityClrErr(const std::string req, uint64_t &val);
    bool McHandleCaParityErrInj(const std::string req, uint64_t &val);
    bool McHandleDqParityQueryErrStat(const std::string req, uint64_t &val);
    void McHandleDqParityClrErr(const std::string req, uint64_t &val);
    bool McHandleDqParityErrInj(const std::string req, uint64_t &val);
    void McHandleTopCsrParityEn(const std::string req);
    bool McHandleTopCsrParityQueryErrStat(const std::string req);
    void McHandleTopCsrParityClrErr(const std::string req);
    void McHandleTopCsrParityInj(const std::string req);
    bool McHandleCsrParityQueryErrStat(const std::string req);
    void McHandleCsrParityClrErr(const std::string req);
    void McHandleCsrParityInj(const std::string req, uint32_t chn);
    bool McHandleCattripQueryErrStat(const std::string req);
    void McHandleCattripClrErr(const std::string req);
    bool McHandleSramQueryErrStat(const std::string req);
    void McHandleSramErrinj(const std::string req, uint32_t pc);
    void McHandleSramClrErr(const std::string req);
    void McHandleSramRasEnable(const std::string req, uint32_t pc);
    void McHandleSramOp(const std::string req, uint32_t pc);
    bool McPhyReset(uint32_t channel);

 private:
    // test
    bool PhyResetTest(void);
    bool McResetTest(void);
    bool McBroadcastEnAllTest(void);
    bool McBroadcastDisAllTest(void);
    bool McAmMonitorTest(void);
    bool McIssueRefreshCmdTest(void);
    bool McIssueSelfRefreshCmdTest(void);
    bool McIssuePowerDownCmdTest(void);
    bool McIssueMrsCmdTest(void);
    bool McAutoRefreshAllBankTest(void);
    bool McAutoRefreshPerBankTest(void);
    bool McAxiAutoStallTest(void);
    bool McAxiManualStallTest(void);
    bool McAmMonitorRepeatModeTest(void);
    bool McFullBistCfg(void);
    bool McFullBistRun(void);
    bool McEccCfg(void);
    bool McEccEcsCfg(void);
    bool McEccEcsRun(void);
    bool McEccEcsCheckStatus(void);
    bool McPowerInsuranceCfg(void);
    bool McPowerInsuranceRun(void);
    bool McAddrRangeCheckCfg(void);
    bool McOutOfAxiAddrCfg(void);
    bool McWrParityProtect(bool);
    bool McMtSramParityTest(uint32_t);
};

/*!
 * @brief McPhyLibra lib
 */
class McPhyLibra : public McPhy {
 public:
    /*!
     * @brief McPhy constructor
     */
    explicit McPhyLibra(McPhyInit &init);

    /*!
     * @brief desctructor
     */
    virtual ~McPhyLibra();

 public:
    /*!
     * @brief print all the McPhy configuration
     */
    virtual void PrintAll(std::string &);

    /*!
     * @brief write phy reg
     */
    virtual void WritePhyReg(uint32_t addr, uint32_t val);

    /*!
     * @brief read phy reg
     */
    virtual uint32_t ReadPhyReg(uint32_t addr);

 protected:
    Hpd *hpd_;
    Mc * mc_;
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_MC_LIBRA_MC_H_
