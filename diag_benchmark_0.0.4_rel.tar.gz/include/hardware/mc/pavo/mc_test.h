/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_MC_PAVO_MC_TEST_H_
#define HARDWARE_MC_PAVO_MC_TEST_H_

#include "hardware/include/mc/mc_test.h"

namespace efvf {
namespace hardware {
namespace mc {

class McPavo;
class McTestPavo : public IMcTest {
 public:
    explicit McTestPavo(McPavo *hw);
    virtual ~McTestPavo() {}
    virtual bool TestPmc();

 private:
    McPavo *hw_;
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_MC_PAVO_MC_TEST_H_
