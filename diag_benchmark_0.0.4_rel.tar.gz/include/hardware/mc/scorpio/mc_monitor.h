/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_SCORPIO_MC_MONITOR_H_
#define HARDWARE_MC_SCORPIO_MC_MONITOR_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/mc/mc.h"
#include "hardware/include/pmc.h"

namespace efvf {
namespace hardware {
namespace dfi {

///
///@ PmcDFI
///
class PmcMcDfiBase : public Pmc {
 public:
    PmcMcDfiBase(
        McLibBase *mclib, uint8_t mc_inst, std::string &filename, enum PmcUseMode use_mode);
    virtual ~PmcMcDfiBase();
    Mc *GetMc() {
        return m_mclib_base;
    }
    virtual void LoadConfigFile(const std::string &filename, const std::string &ip_name);
    virtual void ConfigGroup1UserReg();

 protected:
    virtual uint32_t RegRead(uint8_t group, uint8_t index);
    virtual void RegWrite(uint8_t group, uint8_t index, uint32_t data);

 protected:
    McLibBase *m_mclib_base;
    uint32_t   m_index_cmd;
    uint32_t   m_index_wdata;
    uint32_t   m_index_rdata;
};

class PmcMcDfiLib {
 public:
    PmcMcDfiLib(
        McLibBase *mclib, uint8_t mc_inst, std::string filename, enum PmcUseMode use_mode);
    ~PmcMcDfiLib();

    PmcMcDfiBase *GetInstance() {
        return m_pmc_mc_dfi.get();
    }

 protected:
    std::unique_ptr<PmcMcDfiBase> m_pmc_mc_dfi;
    DtuType                       m_dtu_type;
};

}  // namespace dfi
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_MC_SCORPIO_MC_MONITOR_H_
