/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_SCORPIO_MC_MDF_H_
#define HARDWARE_MC_SCORPIO_MC_MDF_H_

#include <memory>
#include <string>
#include <vector>

#include "hardware/include/hardware.h"
#include "hardware/include/mc/mc_mdf.h"
#include "hardware/include/mc/mc_mgr.h"
#include "hardware/include/mc/mc_test.h"
#include "hardware/include/pmc.h"

namespace efvf {
namespace hardware {
namespace mc {

class MdfScorpio : public Mdf {
 public:
    explicit MdfScorpio(std::shared_ptr<spdlog::logger> logger);
    virtual ~MdfScorpio() {}

 private:
    bool         HwInit();
    virtual bool HwDeinit();
    virtual void LibInit();

 public:
    //!
    //! @berif from Hardware
    //!
    virtual void set_mask(const std::bitset<HW_MAX_BIT> &mask);

 public:
    virtual std::string GetName(void);
    virtual bool        handle_tool_req(const std::string);
    virtual bool        handle_tool_req(const std::string, std::string);
    virtual bool        handle_tool_req(const std::string, std::string *);
    virtual bool        handle_tool_req(const std::string, uint64_t &);
    virtual bool        handle_tool_req(const std::string, uint64_t, uint64_t &);
    virtual void        print_info(const std::string = "");

 protected:
    std::shared_ptr<IMcTest> test_;

 private:
    uint32_t              m_die_id;
    uint32_t              m_subsys_id;
    uint32_t              m_glb_inst_id;
    uint32_t              m_num_of_avail_mc;
    std::vector<uint32_t> m_avail_mc;
    std::string           m_name;
    uint32_t              m_capacity;
    uint64_t              m_capacity_in_bytes;
    uint64_t              m_avail_capacity_in_bytes;
    bool                  m_ecc_on;
    bool                  m_channel_hash_bypass;
    bool                  m_bank_hash_bypass;
    bool                  m_clip_on;
    uint32_t              m_clip_ar_gl;
    uint32_t              m_clip_aw_gl;
    uint32_t              m_frist_avail_mc_in_mdf;
    uint64_t              m_mdf_edf_start_addr_p0;
    uint64_t              m_mdf_edf_start_addr_p1;
    uint64_t              m_mdf_edf_size;
    uint64_t              deintlv_mode[8];
    uint64_t              deintlv_start[8];
    uint64_t              deintlv_size[8];
    uint64_t              deintlv_index[8];
    uint64_t              deintlv_base[8];
    uint32_t              channel_hash[8];
    uint32_t              bank_hash[3];
    uint32_t              channel_map[3];
    bool                  mdf_log_mute_ = false;

 private:
    uint32_t ReadReg(std::string, uint64_t);
    void     WriteReg(std::string, uint64_t, uint32_t);
    void     MdfWrapRegWrite(uint64_t, uint32_t);
    uint32_t MdfWrapRegRead(uint64_t);
    void     MdfConfigClipAraddrGranularity(uint32_t);
    void     MdfConfigClipAwaddrGranularity(uint32_t);
    void     MdfConfigClip(bool);
    void MdfConfigAddrRange(bool hw = false);
    void     MdfHwConfigAddrRange(void);
    void     MdfConfigChannelHashBypass(void);
    void     MdfConfigBankHashBypass(void);
    bool     MdfGetChannelHashBypassStatus(void);
    bool     MdfGetBankHashBypassStatus(void);
    void     MdfConfigChannelMap(uint32_t, uint32_t);
    void     MdfConfigChannelHashCode(uint32_t, uint32_t);
    uint32_t MdfGetChannelHashCode(uint32_t);
    void     MdfConfigBankHashCode(uint32_t, uint32_t);
    uint32_t MdfGetBankHashCode(uint32_t);
    void     MdfConfigDeinterlvMode(uint32_t, uint32_t);
    void     MdfConfigApertureIndex(uint32_t, uint32_t);
    void     MdfConfigApertureSize(uint32_t, uint32_t);
    void     MdfConfigApertureBase(uint32_t, uint32_t);
    void     MdfConfigApertureStart(uint32_t, uint32_t);
    bool     MdfRangeCheckStatus(uint64_t &);
    bool     MdfRangeCheckErr(std::string, uint64_t &);
    bool     MdfCleanRangeCheckErr(void);
    bool     MdfConfigBroadCast(uint32_t, bool);
    bool     MdfPrintStatus(std::string *);
    uint64_t GetMemSubsysAddrRange(void);
    uint32_t GlbMcId2LocalMcId(uint32_t);
    void     addr_channel_hash_bypass(uint64_t, uint64_t &, uint64_t &);
    void     addr_channel_hash(uint64_t, uint64_t &, uint64_t &);
    uint64_t addr_deinterleave(uint64_t);
    uint64_t ecc_adjust(uint64_t, bool);
    void     addr_bank_hash(uint64_t, uint64_t &);
    uint32_t addr_channel_map(uint32_t, bool);
    void     edf_addr_to_mc_addr(uint64_t, uint64_t &, uint64_t &);
    void     edf_addr_to_deintlv_addr(uint64_t, uint64_t &);
    void     deintlv_addr_bypass_channel_hash(uint64_t, uint64_t &, uint64_t &);
    void     deintlv_addr_to_channel_hash_addr(uint64_t, uint64_t &, uint64_t &);
    void     channel_hash_addr_to_bank_hash_addr(uint64_t, uint64_t &, bool);
    void     channel_map_to_mc(uint32_t, uint32_t &);
    void     addr_channel_hash_bypass_rev(uint64_t, uint64_t, uint64_t &);
    void     addr_channel_hash_rev(uint64_t, uint64_t, uint64_t &);
    uint64_t addr_deinterleave_reverse(uint64_t);
    void     mc_addr_to_edf_addr(uint64_t &, uint64_t, uint64_t);
    void     mc_addr_to_edf_addr_p0(uint64_t &, uint64_t, uint64_t);
    void     mc_addr_to_edf_addr_p1(uint64_t &, uint64_t, uint64_t);
    void     MdfGetFwCfg(void);
    void     mdf_addr_scan(uint64_t, uint64_t);
};

class MdfRasScorpio : public MdfRas {
 public:
    explicit MdfRasScorpio(MdfScorpio *mc);
    virtual ~MdfRasScorpio();

    /**
     * @brief enable ras
     */
    virtual void Enable(RasCfg *cfg) {}

    /**
     * @brief disable ras
     */
    virtual void Disable(RasCfg *cfg) {}

    /**
     * @brief start ras inject
     */
    virtual void StartErrInjection(RasCfg *cfg, RasErrInj *err_inj) {}

    /**
     * @brief stop ras inject
     */
    virtual void StopErrInjection(RasCfg *cfg, RasErrInj *err_inj) {}

    /**
     * @brief query err
     */
    virtual void QueryErrStatus(RasCfg *cfg, RasErrStat *err_stat);

    /**
     * @brief clear err
     */
    virtual void ClearErrStatus(RasCfg *cfg);

    /**
     * @brief print err
     */
    virtual void PrintErrStatus(RasCfg *cfg) {}

    /**
     * @berif get ras cfg
     *
     * @param      cfg   The configuration
     */
    virtual void GetRasCfg(RasCfg *cfg) {}

    /**
     * @brief enable interrupt
     */
    virtual void EnableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief disable interrupt
     */
    virtual void DisableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief clear interrupt
     */
    virtual void ClearInterrupt(IntrptCfg *cfg) {}

    /**
     * @berif save interrupt
     */
    virtual void QueryInterrupt(IntrptCfg *cfg, IntrptStat *stat) {}

    /**
     * @brief print interrupt
     */
    virtual void PrintInterrupt(IntrptCfg *cfg) {}

 private:
    MdfScorpio *     mdf_;
    std::string      m_name;
    std::vector<int> m_inst;
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_MC_SCORPIO_MC_MDF_H__
