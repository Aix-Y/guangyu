/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file mc_phy.h
    \brief define a mc phy lib
 */

#ifndef HARDWARE_MC_SCORPIO_MC_PHY_H_
#define HARDWARE_MC_SCORPIO_MC_PHY_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/mc/mc_phy.h"

namespace efvf {
namespace hardware {
namespace mc {

/*!
 * @brief McPhyScorpio lib
 */
class McPhyScorpio : public McPhy {
 public:
    /*!
     * @brief McPhy constructor
     */
    explicit McPhyScorpio(McPhyInit &init);

    /*!
     * @brief desctructor
     */
    virtual ~McPhyScorpio();

 public:
    /*!
     * @brief print all the McPhy configuration
     */
    virtual void PrintAll(std::string &);

 protected:
    Hpd *hpd_;
    Mc * mc_;

 private:
    virtual uint32_t ReadReg(std::string, uint64_t);
    virtual void     WriteReg(std::string, uint64_t, uint32_t);
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_MC_SCORPIO_MC_PHY_H_
