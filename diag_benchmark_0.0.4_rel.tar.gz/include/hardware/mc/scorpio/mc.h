/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_SCORPIO_MC_H_
#define HARDWARE_MC_SCORPIO_MC_H_

#include <bitset>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <vector>
#include "hardware/include/mc/mc.h"
#include "hardware/include/mc/mc_mgr.h"
#include "hardware/include/mc/mc_phy.h"
#include "hardware/include/mc/mc_reg_op.hpp"
#include "hardware/include/system_adapter.h"

using efvf::hardware::system_adapter::SystemAdapter;

namespace efvf {
namespace hardware {
namespace mc {

/* MC interrupt mask/status */
#define MC_EVENT_TIMEOUT (0x1)
#define MC_EVENT_ECC (0x1 << 1)
#define MC_EVENT_LOW_POWER (0x1 << 2)
#define MC_EVENT_USER_INTERFACE (0x1 << 6)
#define MC_EVENT_MISC (0x1 << 7)
#define MC_EVENT_BIST (0x1 << 8)
#define MC_EVENT_CRC (0x1 << 9)
#define MC_EVENT_DFI (0x1 << 10)
#define MC_EVENT_FREQ (0x1 << 12)
#define MC_EVENT_INIT (0x1 << 13)
#define MC_EVENT_MODE (0x1 << 14)
#define MC_EVENT_PARITY (0x1 << 15)
#define MC_EVENT_ANY (0x1 << 31)

typedef enum {
    MC_INTERRUPT_SRC_TIMEOUT = 0,
    MC_INTERRUPT_SRC_ECC,
    MC_INTERRUPT_SRC_LOW_POWER,
    MC_INTERRUPT_SRC_USER_INTERFACE,
    MC_INTERRUPT_SRC_MISC,
    MC_INTERRUPT_SRC_BIST,
    MC_INTERRUPT_SRC_CRC,
    MC_INTERRUPT_SRC_DFI,
    MC_INTERRUPT_SRC_FREQ,
    MC_INTERRUPT_SRC_INIT,
    MC_INTERRUPT_SRC_MODE,
    MC_INTERRUPT_SRC_PARITY,
    MC_INTERRUPT_SRC_ANY,
} MC_INTERRUPT_SRC;

/* MC MRS status */
#define MRS_EVENT_MRR_ERROR (0x1)
#define MRS_EVENT_MRR_COMPLETED (0x1 << 2)
#define MRS_EVENT_MRW_COMPLETED (0x1 << 3)

typedef enum {
    MC_MRR_ERROR = 0,
    MC_MRR_COMPLETED,
    MC_MRW_COMPLETED,
} MC_MRS_STATUS;

/* MC parity interrupt mask/status */
#define WRITE_PARITY_ERR_EVENT (0x1)
#define OVERLAP_WRITE_PARITY_ERR_EVENT (0x1 << 1)
typedef enum {
    MC_PARITY_WRITE_PARITY_ERR         = 0,
    MC_PARITY_OVERLAP_WRITE_PARITY_ERR = 1,
} MC_PARITY_STATUS;

/* MC CRC(EDC) interrupt mask/status */
#define WRITE_CRC_ERR_EVENT (0x1)
#define READ_CRC_ERR_EVENT (0x1 << 2)
#define WRITE_CRC_RETRY_ERR_EVENT (0x1 << 3)
#define READ_CRC_RETRY_ERR_EVENT (0x1 << 4)
typedef enum {
    MC_CRC_WRITE_CRC_ERR       = 0,
    MC_CRC_READ_CRC_ERR        = 1,
    MC_CRC_WRITE_CRC_RETRY_ERR = 2,
    MC_CRC_READ_CRC_RETRY_ERR  = 3,
} MC_CRC_STATUS;

/* MC ECC interrupt mask/status */
#define ECC_EVENT_C_ECC (0x1)
#define ECC_EVENT_MULTI_C_ECC (0x1 << 1)
#define ECC_EVENT_U_ECC (0x1 << 2)
#define ECC_EVENT_MULTI_U_ECC (0x1 << 3)
#define ECC_EVENT_WRITEBACK_DROP (0x1 << 6)
#define ECC_EVENT_SCRUB_COMPLETED (0x1 << 7)
#define ECC_EVENT_C_ECC_SCRUB (0x1 << 8)

/* MC IMU IRAM/DRAM */
#define MC_IMU_IRAM_SIZE (32 * 1024)
#define MC_IMU_IRAM_ADDR_OFFSET (0x3000)
#define MC_IMU_DRAM_SIZE (16 * 1024)
#define MC_IMU_DRAM_ADDR_OFFSET (0xB000)

/* MC TESTBUF */
#define MC_TESTBUF_SIZE (4 * 1024)

class McScorpio : public Mc {
 public:
    explicit McScorpio(std::shared_ptr<spdlog::logger> logger);
    virtual ~McScorpio() {}

    //!
    //! @berif from Hardware
    //!
    bool         HwInit();
    virtual bool HwDeinit();
    virtual void LibInit();
    virtual bool HwInitMini();
    virtual int Deamon(int task_id, void *param);
    virtual void set_mask(const std::bitset<HW_MAX_BIT> &mask);

    //!
    //! @berif from Mc
    //!
    virtual uint8_t  GetHbmInst();
    virtual uint32_t GetGlbInstId();

    virtual bool ConfigChanForRegRw(uint32_t chan);
    virtual bool ConfigECC(bool ecc_en);
    virtual bool ConfigChanRegBrdcst(bool enable);
    virtual void ConfigWrapperRegBrdcst(bool enable);

    virtual uint32_t GetNumOfInsts();
    virtual uint32_t GetNumOfMcChannelsPerInst();
    virtual uint32_t GetNumOfMemoryChannels();
    virtual void TopRegWrite(uint32_t offset, uint32_t val);
    virtual uint32_t TopRegRead(uint32_t offset);
    virtual std::vector<uint32_t> ChanRegRead(uint32_t chan, uint32_t offset);
    virtual void ChanRegWrite(uint32_t chan, uint32_t offset, uint32_t val);

    /* 2.0 interface */
 public:
    virtual bool     SetMcPriority();
    virtual void     EnableMcCFCnt();
    virtual void     DisableMcCFCnt();
    virtual uint32_t CalCntVal();
    virtual void     SoftResetECFPmc();
    uint32_t         GetGlbInst(void);
    uint32_t         GetDieId(void);
    uint32_t         GetMemSubsysId(void);
    uint64_t         GetAddrOffsetOnMdf(void);
    uint32_t         GetChannelId(void);
    uint64_t         GetPaOffset(void);
    std::string      GetName(void);
    bool             ImuSramRw(const std::string, uint32_t, uint8_t *, uint32_t);
    bool             handle_tool_req(const std::string &);
    bool             handle_tool_req(const std::string &, std::string &);
    bool             handle_tool_req(const std::string, uint64_t &, uint64_t &);
    bool             handle_tool_req(const std::string, uint64_t &);
    SystemAdapter *  sa(void);

 protected:
    system_adapter::SystemAdapter *m_sa = nullptr;

 private:
    // mc related data
    uint32_t    m_subsys_id;
    uint32_t    m_die_id;
    uint32_t    m_glb_inst_id;
    uint32_t    m_glb_subsys_id;
    std::string m_name;
    std::string m_subsys_name;
    std::map<const std::string, uint64_t> m_reg_base;
    uint32_t m_channel_id;
    uint32_t m_mc_id;
    uint64_t m_edf_offset_in_mdf;
    uint64_t m_edf_start_addr_p0;  // normal port
    uint64_t m_edf_start_addr_p1;  // shadow port
    uint32_t m_capacity;
    uint64_t m_capacity_in_bytes;
    uint64_t m_avail_capacity_in_bytes;
    bool     m_ecc_on;
    bool     m_testbuf_on;
    bool     m_rd_edc_on;
    bool     m_wr_edc_on;
    bool     m_edc_half_rate_on;
    bool     m_edc_retry_on;
    uint32_t m_edc_retry_level;
    uint64_t m_pa_offset;

 private:
    // mc related functions
    uint32_t ReadReg(std::string section, uint64_t offset);
    void WriteReg(std::string section, uint64_t offset, uint32_t val);
    uint32_t McDdrCtlRegRead(uint32_t);
    void     McDdrCtlRegWrite(uint32_t, uint32_t);
    uint32_t McImuRegRead(uint32_t offset);
    void McImuRegWrite(uint32_t offset, uint32_t val);
    uint32_t McWrapRegRead(uint32_t offset);
    void McWrapRegWrite(uint32_t offset, uint32_t val);
    uint32_t McTopRegRead(uint32_t offset);
    void McTopRegWrite(uint32_t offset, uint32_t val);
    uint32_t McPhyDSNonTraining0Read(uint32_t offset);
    void McPhyDSNonTraining0Write(uint32_t offset, uint32_t val);
    uint32_t McTopStickyRegRead(uint32_t offset);
    void McTopStickyRegWrite(uint32_t offset, uint32_t val);
    // ECC related
    void McConfigEcc(void);
    void McEccInject(uint32_t);
    void McStopEccInject(void);
    bool McEccQueryIntStatus(std::string, uint64_t &, std::string &);
    bool McEccClearIntStatus(uint64_t);
    bool McEccConfigInt(uint64_t, bool);
    // interrupt/status relates
    bool McConfigInt(uint64_t, bool);
    bool McGetIntStatus(MC_INTERRUPT_SRC);
    bool McGetMrsStatus(MC_MRS_STATUS);
    bool McClrMrsStatus(MC_MRS_STATUS);
    bool McGetParityStatus(MC_PARITY_STATUS);
    bool McClrParityStatus(MC_PARITY_STATUS);
    bool McGetCrcStatus(MC_CRC_STATUS);
    bool McClrCrcStatus(MC_CRC_STATUS);
    // mc wrapper relates
    bool McTestBufConfig(bool);
    bool McGetControllerStatus(std::string);
    // mc top related
    bool McDataBufferParityOp(std::string, uint64_t &);
    bool McImuIramParityOp(std::string, uint64_t &);
    bool McImuDramParityOp(std::string, uint64_t &);
    bool McSramCtrl(std::string, uint64_t &);
    bool McImuOp(std::string, uint64_t &);
    bool McRasOp(std::string, uint64_t &);
    // ddr controller
    bool McMrsWrite(uint32_t, uint32_t, uint32_t);
    bool McMrsRead(uint32_t, uint32_t, uint64_t &);
    bool McGetDramTemp(uint32_t &);
    bool McGetDramVendorId1(uint32_t &);
    bool McGetDramVendorId2(uint32_t &);
    bool McEdcOp(std::string);
    bool McEdcOp(std::string, uint64_t &);
    bool McBistOp(std::string, uint64_t &);
    bool McBistOp(std::string, uint8_t *);
    bool McBusInvertOp(std::string);
    bool McPageRetireOp(std::string, uint64_t &);
    bool McLowPowerOp(std::string, uint64_t &);
    bool McAutoRefreshOp(std::string, uint64_t &);
    bool McDfiOp(std::string, uint64_t &);
    bool McParityOp(std::string, uint64_t &);
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_MC_SCORPIO_MC_H_
