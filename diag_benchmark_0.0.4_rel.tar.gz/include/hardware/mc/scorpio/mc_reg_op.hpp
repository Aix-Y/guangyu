/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_MC_REG_OP_SCORPIO_HPP_
#define HARDWARE_MC_MC_REG_OP_SCORPIO_HPP_

//#include "device/dtus/scorpio/data_fabric.h"
//#include "device/dtus/scorpio/dtu_wrapper.h"
#include "device/dtus/scorpio/register_soc.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////
// MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED
//////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * refer device/dtus/scorpio/scorpio_hw_tree.cpp
 * L0 | e.g.  __hwtree_obj_die (hw_soc_,   SUB_SOC_REGMODEL, id-diex)
 * L1 | e.g.  __hwtree_obj_hw  (hw_die_,   MEM_SUBSYS_REGMODEL, id-inst)
 * L2 | e.g.  __hwtree_obj_hw  (hw_obj_l1, MC_TOP_REGMODEL, id-inst)
 */

#define __hwtree_obj_die(_obj_soc, _l0, _id)                                    \
({                                                                              \
    Hardware *_obj_die = nullptr;                                               \
    if (((0 == (_id)) || (1 == (_id))) &&                                       \
        (nullptr != (_obj_soc)) &&                                              \
        (true)) {                                                               \
        _obj_die = (_obj_soc)->Get(#_l0, (_id));                                \
    }                                                                           \
    (_obj_die);                                                                 \
})

#define __hwtree_obj_hw(_obj_die, _lx, _id)                                     \
({                                                                              \
    Hardware *_obj_hw = nullptr;                                                \
    if (nullptr != (_obj_die)) {                                                \
        _obj_hw = (_obj_die)->Get(#_lx, (_id));                                 \
    }                                                                           \
    (_obj_hw);                                                                  \
})

#define __hwtree_die_mem_subsys(_obj_soc, _id, _inst)                           \
({                                                                              \
    Hardware * _mem_subsys_x = nullptr;                                         \
    Hardware * _die_x = __hwtree_obj_die((_obj_soc), SUB_SOC_REGMODEL, (_id));  \
    if (nullptr != _die_x) {                                                    \
        _mem_subsys_x = __hwtree_obj_hw(_die_x, MEM_SUBSYS_REGMODEL, _inst);    \
    }                                                                           \
    (_mem_subsys_x);                                                            \
})

#define __hwtree_obj_addr_l0(_obj_hw) ((_obj_hw) ? ((_obj_hw)->ecf_addr_) : ~0)
#define __hwtree_obj_addr_l1(_obj_hw, _l1, _id)                                 \
({                                                                              \
    Hardware * _obj_l1 = __hwtree_obj_hw(_obj_hw, _l1, _id);                    \
    (__hwtree_obj_addr_l0(_obj_l1));                                            \
})
#define __hwtree_obj_addr_l2(_obj_hw, _l1, _l2, _id1, _id2)                     \
({                                                                              \
    Hardware * _obj_l1 = __hwtree_obj_hw(_obj_hw, _l1, _id1);                   \
    Hardware * _obj_l2 = __hwtree_obj_hw(_obj_l1, _l2, _id2);                   \
    (__hwtree_obj_addr_l0(_obj_l2));                                            \
})
#define __hwtree_obj_addr_l3(_obj_hw, _l1, _l2, _l3, _id1, _id2, _id3)          \
({                                                                              \
    Hardware * _obj_l1 = __hwtree_obj_hw(_obj_hw, _l1, _id1);                   \
    Hardware * _obj_l2 = __hwtree_obj_hw(_obj_l1, _l2, _id2);                   \
    Hardware * _obj_l3 = __hwtree_obj_hw(_obj_l2, _l3, _id3);                   \
    (__hwtree_obj_addr_l0(_obj_l3));                                            \
})

#define ECF_HOBJ_MEM_SUBSYS_(_die_id, _inst)     __hwtree_die_mem_subsys(hw_soc_, _die_id, _inst)

// define MC_TOP reg address
#define ECF_ADDR_MC_DDR_CONTROLLER(_mem_subsys, _mc)     __hwtree_obj_addr_l3(_mem_subsys, MC_TOP_REGMODEL, CDN_CTL_REGS, DDR_CONTROLLER, _mc, 0, 0)

// define MDF_TOP reg address
#define ECF_ADDR_MDF_MDF_WRAP(_mem_subsys)               __hwtree_obj_addr_l2(_mem_subsys, MDF_TOP_REGMODEL, MDF_WRAP, 0, 0)


#include "hardware/include/mc/mc_reg_op.hpp"

// macro mapping address
#define __reg_addr_ddr_ctl(_reg)                     (__reg_o(_reg) + __reg_base(ddr_ctl, (0), (0)))
#define __reg_addr_mdf_wrap(_reg)                     (__reg_o(_reg) + __reg_base(mdf_wrap, (0), (0)))


#define __ddr_ctl_reg_addr(_reg)                     ((_reg) + __reg_base(ddr_ctl, (0), (0)))
#define __mdf_wrap_reg_addr(_reg)                     ((_reg) + __reg_base(mdf_wrap, (0), (0)))


#define regr32_ddr_ctl(_reg)                         (regr32(__reg_addr_ddr_ctl(_reg)))
#define regr32_mdf_wrap(_reg)                        (regr32(__reg_addr_mdf_wrap(_reg)))



#endif  // HARDWARE_MC_MC_REG_OP_SCORPIO_HPP_
