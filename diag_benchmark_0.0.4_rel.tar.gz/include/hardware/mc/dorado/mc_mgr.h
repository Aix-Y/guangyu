/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_DORADO_MC_MGR_H_
#define HARDWARE_MC_DORADO_MC_MGR_H_

#include <memory>
#include <vector>
#include "hardware/include/mc/mc_mgr.h"

namespace efvf {
namespace hardware {
namespace mc {
class McMgrDorado : public McMgr {
 public:
    // explicit McMgrDorado(std::shared_ptr<spdlog::logger> logger, const Dtu &dtu);
    McMgrDorado(std::shared_ptr<spdlog::logger> logger, const Dtu &dtu);
    virtual ~McMgrDorado() {}

    //!
    //! @berif from Hardware
    //!
    virtual int Deamon(int task_id, void *param);
    virtual void set_mask(const std::bitset<HW_MAX_BIT> &mask);

    //!
    //! @berif from McMgr
    //!
    void         PrintMemInfo();
    MC_MEM_TYPE  GetMemType();
    MC_VENDOR_ID GetVendorId();
    uint32_t     GetNumOfMcInsts();
    uint32_t     GetMaskOfMcInsts();
    uint32_t     GetNumOfMcChannelsPerInst();
    uint32_t     GetMaskOfMcChannelsPerInst();
    Mc *         GetMcInst(uint32_t);

 private:
    virtual bool HwInit();
    virtual bool HwDeinit();
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_MC_DORADO_MC_MGR_H_
