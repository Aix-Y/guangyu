/////////////////////////////////////////////////////////////////////////////
//
//  @file dft_lib_base.h
//
//  @brief Interface declaration of dft base library
//
//  Enflame Tech, All Rights Reserved. 2024 Copyright (C)
//
/////////////////////////////////////////////////////////////////////////////
#ifndef HARDWARE_DFT_DFT_BASE_H_
#define HARDWARE_DFT_DFT_BASE_H_

#include <memory>
#include <string>
#include "hardware/include/dft.h"

namespace efvf {
namespace hardware {
namespace dft {

class DftBase : public Dft {
 public:
    DftBase() {}
    explicit DftBase(std::shared_ptr<spdlog::logger> logger);
    virtual ~DftBase();

    virtual bool ReadTDR(std::string tdr, uint32_t &outValue);
    virtual bool WriteTDR(char *tdr, uint32_t value);

    virtual int ShiftIR(uint32_t sizeInBits, uint32_t IR);
    virtual int ShiftDR(uint32_t sizeInBits, uint32_t DR);
    virtual int ShiftDR(uint32_t sizeInBits, uint32_t buffer[]);

    virtual int ReadTDO(int sizeInBits, uint32_t &TDO);
    virtual int ReadTDO(int sizeInBits, uint32_t buffer[]);

    virtual void ShiftTMS(void);

    virtual bool TestJTAG();
    virtual bool ReadIDCode();

    virtual void JTAG_Reset();

    virtual void SwitchAltTAP();

    // Access registers via jtag2axi
    virtual int ReadReg(uint32_t addr, uint32_t &outValue);
    virtual int WriteReg(uint32_t addr, uint32_t value);

    // Access registers via LTAP jtag2axi
    virtual int ReadLtapReg(std::string ip, uint32_t addr, uint32_t &outValue);
    virtual int WriteLtapReg(std::string ip, uint32_t addr, uint32_t value);

    // SSM register access methods
    virtual int ReadSSMReg(int offset, uint32_t &outValue);
    virtual int WriteSSMReg(int offset, uint32_t value);

    // MC related functional interfaces
    virtual int MC_SetApbOwnTap(int mc_index, bool enable);
    virtual int MC_WriteIR(int mc_index, int sizeInBits, uint32_t IR);
    virtual int MC_ReadDR(int mc_index, int sizeInBits, uint32_t outValue[]);
    virtual int MC_WriteDR(int mc_index, int sizeInBits, uint32_t value[]);

    virtual bool ReadMcLtapIDCode(int mc_index);

    // HBM Phy register access methods
    virtual bool ReadHBMPhyReg(
        int phy_index, int channel_index, int dword_index, int offset, uint32_t &outValue);
    virtual bool WriteHBMPhyReg(
        int phy_index, int channel_index, int dword_index, int offset, uint32_t value);

    // PCIE/CCIX Phy register access methods
    virtual bool ReadPCIePhyReg(int phy_index, int address, uint32_t &outValue);
    virtual bool WritePCIePhyReg(int phy_index, int address, uint32_t value);

    virtual bool ReadCCIXPhyReg(int phy_index, int address, uint32_t &outValue);
    virtual bool WriteCCIXPhyReg(int phy_index, int address, uint32_t value);

    // Scan setup TDR for Pavo cluster reset workaround
    virtual int ReadScanSetupTDR(int cluster_id, uint32_t &outValue);
    virtual int WriteScanSetupTDR(int cluster_id);

    virtual int MemoryRepairWorkaround(void);
    virtual int ReadMemoryRepairWorkaroundTDR(void);

    virtual int SampleCode(void);

 protected:
    uint32_t DFT_BASE_ADDRESS = 0x01300000;

    void InitJtagAxiCtrl();
    void ReleaseAXITAP();

 private:
    inline void ReadRegCheck(uint32_t address, uint32_t value);
    bool SelectHBMPhyChannel(int phy_index, int channel_index, int dword_index);
    bool EnablePCIePhyAltTAP();
    bool SelectCCIXPhyChannel(uint32_t phy_index);

    int GetBitsNum(std::string bits_str);
    uint64_t GetTdrValue(int startbit, int *data, int len, int width);
    int ssm_stat_data(int op, int value);
    void ssm_enable(int op /* 0 w, 1 r */, int value);
    void ssm_ctrl_data(int op /* 0 w, 1 r */, uint64_t val);
    void ssm_override(int op /* 0 w, 1 r */, uint32_t value);
    void tdr_ssm_op(int op, uint64_t addr, uint64_t data);
    BitsNumValue BitsStrToBitsNumAndValue(std::string bits_str);
    void Pmtap2Tessent();
    void Tessent2Pmtap();
};

}  // namespace dft
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_DFT_DFT_BASE_H_
