/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_AP_SCORPIO_AP_RAS_SCORPIO_H_
#define HARDWARE_AP_SCORPIO_AP_RAS_SCORPIO_H_

#include <algorithm>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "hardware/include/ap/ap.h"
#include "hardware/include/ap/ap_ras.h"

namespace efvf {
namespace hardware {
namespace ap {

// class ApRasScorpio;
class ApRasScorpio : public ApRas {
 public:
    explicit ApRasScorpio(Ap *ap);
    virtual ~ApRasScorpio();

    /**
     * @brief enable ras
     */
    virtual void Enable(RasCfg *cfg);

    /**
     * @brief disable ras
     */
    virtual void Disable(RasCfg *cfg);

    /**
     * @brief start ras inject
     */
    virtual void StartErrInjection(RasCfg *cfg, RasErrInj *err_inj);

    /**
     * @brief stop ras inject
     */
    virtual void StopErrInjection(RasCfg *cfg, RasErrInj *err_inj);

    /**
     * @brief query err
     */
    virtual void QueryErrStatus(RasCfg *cfg, RasErrStat *err_stat);

    /**
     * @brief clear err
     */
    virtual void ClearErrStatus(RasCfg *cfg);

    /**
     * @brief print err
     */
    virtual void PrintErrStatus(RasCfg *cfg) {}

    /**
     * @berif get ras cfg
     *
     * @param      cfg   The configuration
     */
    virtual void GetRasCfg(RasCfg *cfg);

    /**
     * @brief enable interrupt
     */
    virtual void EnableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief disable interrupt
     */
    virtual void DisableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief clear interrupt
     */
    virtual void ClearInterrupt(IntrptCfg *cfg) {}

    /**
     * @berif save interrupt
     */
    virtual void QueryInterrupt(IntrptCfg *cfg, IntrptStat *stat) {}

    /**
     * @brief print interrupt
     */
    virtual void PrintInterrupt(IntrptCfg *cfg) {}

 private:
    Ap *        ap_;
    std::string m_name;
};

}  // namespace ap
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_AP_SCORPIO_AP_RAS_SCORPIO_H_
