/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_SECURE_SSM_SECURE_LIBRA_H_
#define HARDWARE_SSM_SECURE_SSM_SECURE_LIBRA_H_

#include "hardware/include/ssm/secure/ssm_secure.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace secure {

class SsmSecureLibra : public SsmSecure {
 public:
    explicit SsmSecureLibra(Ssm *ssm) : SsmSecure(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmSecureLibra() {}

 public:
    bool trng(uint8_t *output, uint32_t &output_len);
    bool sm3_digest(uint8_t *input, uint32_t input_len, uint8_t *output, uint32_t &output_len);
    bool sm2_sign(uint8_t *input, uint32_t input_len, uint8_t *pvt, uint32_t pvt_len,
        uint8_t *random, uint32_t random_len, uint8_t *output, uint32_t &output_len);
    bool sm2_verify(uint8_t *plain_signature, uint32_t plain_signature_len, uint8_t *signature,
        uint32_t signature_len, uint8_t *pub, uint32_t pub_len);
    bool sm2_encrypt(uint8_t *plain, uint32_t plain_len, uint8_t *rand, uint32_t rand_len,
        uint8_t *pub, uint32_t pub_len, Sm2CipherOrder, uint8_t *cipher, uint32_t &cipher_len);
    bool sm2_decrypt(uint8_t *cipher, uint32_t cipher_len, uint8_t *pvt, uint32_t pvt_len,
        Sm2CipherOrder order, uint8_t *plain, uint32_t &plain_len);
    bool sm4_encrypt(SkeMode mode, uint8_t *plain, uint32_t plain_len, uint8_t *key,
        uint32_t key_len, uint8_t *iv, uint32_t iv_len, uint8_t *cipher, uint32_t &cipher_len);
    bool sm4_decrypt(SkeMode mode, uint8_t *plain, uint32_t &plain_len, uint8_t *key,
        uint32_t key_len, uint8_t *iv, uint32_t iv_len, uint8_t *cipher, uint32_t cipher_len);
    bool aes128_encrypt(SkeMode mode, uint8_t *plain, uint32_t plain_len, uint8_t *key,
        uint32_t key_len, uint8_t *iv, uint32_t iv_len, uint8_t *cipher, uint32_t &cipher_len);
    bool aes128_decrypt(SkeMode mode, uint8_t *plain, uint32_t &plain_len, uint8_t *key,
        uint32_t key_len, uint8_t *iv, uint32_t iv_len, uint8_t *cipher, uint32_t cipher_len);
    bool aes256_encrypt(SkeMode mode, uint8_t *plain, uint32_t plain_len, uint8_t *key,
        uint32_t key_len, uint8_t *iv, uint32_t iv_len, uint8_t *cipher, uint32_t &cipher_len);
    bool aes256_decrypt(SkeMode mode, uint8_t *plain, uint32_t &plain_len, uint8_t *key,
        uint32_t key_len, uint8_t *iv, uint32_t iv_len, uint8_t *cipher, uint32_t cipher_len);
    bool rsa_encrypt(RsaAlgo mode, uint32_t *plain, uint32_t plain_len, uint32_t *n,
        uint32_t *d, uint32_t key_len, uint32_t *cipher, uint32_t &cipher_len);
    bool rsa_decrypt(RsaAlgo mode, uint32_t *plain, uint32_t &plain_len, uint32_t *n,
        uint32_t *e, uint32_t n_len, uint32_t e_len, uint32_t *cipher, uint32_t cipher_len);
    bool sha256_digest(
        uint8_t *input, uint32_t input_len, uint8_t *output, uint32_t &output_len);
};

}  // namespace secure
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_SECURE_SSM_SECURE_LIBRA_H_
