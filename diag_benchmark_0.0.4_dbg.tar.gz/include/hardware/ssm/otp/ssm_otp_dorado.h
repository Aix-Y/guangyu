/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_OTP_SSM_OTP_DORADO_H_
#define HARDWARE_SSM_OTP_SSM_OTP_DORADO_H_

#include "hardware/include/ssm/otp/ssm_otp.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace otp {

class SsmOtpDorado : public SsmOtp {
 public:
    explicit SsmOtpDorado(Ssm *ssm) : SsmOtp(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmOtpDorado() {}
};

}  // namespace otp
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_OTP_SSM_OTP_DORADO_H_
