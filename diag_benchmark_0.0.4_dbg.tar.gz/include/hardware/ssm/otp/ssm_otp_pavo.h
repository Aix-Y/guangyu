/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_OTP_SSM_OTP_PAVO_H_
#define HARDWARE_SSM_OTP_SSM_OTP_PAVO_H_

#include "hardware/include/ssm/otp/ssm_otp.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace otp {

class SsmOtpPavo : public SsmOtp {
 public:
    explicit SsmOtpPavo(Ssm *ssm) : SsmOtp(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmOtpPavo() {}
};

}  // namespace otp
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_OTP_SSM_OTP_PAVO_H_
