/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_REG_SSM_REG_DORADO_H_
#define HARDWARE_SSM_REG_SSM_REG_DORADO_H_

#include "hardware/include/ssm/reg/ssm_reg.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace reg {

class SsmRegDorado : public SsmReg {
 public:
    explicit SsmRegDorado(Ssm *ssm) : SsmReg(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmRegDorado() {}

 public:
    bool ssm_reg_path_h2ecf2ssm_r(void);
    bool ssm_reg_path_h2ecf2ssm_wrcr(void);
};

}  // namespace reg
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_REG_SSM_REG_DORADO_H_
