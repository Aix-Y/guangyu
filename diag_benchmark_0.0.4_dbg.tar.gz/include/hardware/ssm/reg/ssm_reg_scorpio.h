/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_REG_SSM_REG_SCORPIO_H_
#define HARDWARE_SSM_REG_SSM_REG_SCORPIO_H_

#include <string>

#include "hardware/include/ssm/reg/ssm_reg.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace reg {

class SsmRegScorpio : public SsmReg {
 public:
    explicit SsmRegScorpio(Ssm *ssm) : SsmReg(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmRegScorpio() {}

 public:
    bool ssm_reg_path_h2ecf2ssm_r(void);
    bool ssm_reg_path_h2ecf2ssm_wrcr(void);

 public:
    bool handle_req_reg_op(const std::string &, const std::string &);
    void handle_req_range(const std::string &);
};

}  // namespace reg
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_REG_SSM_REG_SCORPIO_H_
