/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_SSM_DORADO_H_
#define HARDWARE_SSM_SSM_DORADO_H_

#include <map>
#include <memory>
#include <string>

#include "hardware/include/ssm/ssm.h"

namespace efvf {
namespace hardware {
namespace ssm {

class SsmDorado : public Ssm {
 public:
    explicit SsmDorado(std::shared_ptr<spdlog::logger>);
    virtual ~SsmDorado() {}

 private:
    bool HwInit();
    std::map<const std::string, uint64_t> m_reg_base;

 public:
    uint64_t r_base(const std::string & /*mip_mid_sid*/);

 public:
    reg::SsmReg *  GetReg();
    mem::SsmMem *  GetMem();
    cmd::SsmCmd *  GetCmd();
    mcu::SsmMcu *  GetMcu();
    spi::SsmSpi *  GetSpi();
    clk::SsmClk *  GetClk();
    misc::SsmMisc *GetMisc();
    fuse::SsmFuse *GetFuse();
    otp::SsmOtp *  GetOtp();
};

}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_SSM_DORADO_H_
