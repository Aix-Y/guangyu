/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_CMD_SSM_CMD_PAVO_H_
#define HARDWARE_SSM_CMD_SSM_CMD_PAVO_H_

#include "hardware/include/ssm/cmd/ssm_cmd.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace cmd {

class SsmCmdPavo : public SsmCmd {
 public:
    explicit SsmCmdPavo(Ssm *ssm) : SsmCmd(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmCmdPavo() {}

 protected:
    void     ssm_port_addr_init(SSM_MCU_CMD *);
    void     ssm_cmd_reg_w(SSM_CMD_REG_TYPE, SSM_MCU_CMD *);
    uint32_t ssm_cmd_reg_r(SSM_CMD_REG_TYPE, SSM_MCU_CMD *);

 public:
    bool     cmd_get_ssm_alive(void);
    uint32_t cmd_get_ping_code(uint32_t);
    uint32_t cmd_reg_read(uint32_t);
    void     cmd_reg_write(uint32_t, uint32_t);
};

}  // namespace cmd
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_CMD_SSM_CMD_PAVO_H_
