/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_RAS_SSM_RAS_LIBRA_H_
#define HARDWARE_SSM_RAS_SSM_RAS_LIBRA_H_

#include <string>

#include "hardware/include/ssm/ras/ssm_ras.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace ras {

class SsmRasLibra : public SsmRas {
 public:
    explicit SsmRasLibra(Ssm *ssm);
    ~SsmRasLibra() {}

 public:
    void       Enable(RasCfg *);
    void       Disable(RasCfg *);
    void       StartErrInjection(RasCfg *, RasErrInj *);
    void       StopErrInjection(RasCfg *, RasErrInj *);
    void       QueryErrStatus(RasCfg *, RasErrStat *);
    void       ClearErrStatus(RasCfg *);
    void       PrintErrStatus(RasCfg *);
    void       GetRasCfg(RasCfg *);
    void       EnableInterrupt(IntrptCfg *);
    void       DisableInterrupt(IntrptCfg *);
    void       ClearInterrupt(IntrptCfg *);
    void       QueryInterrupt(IntrptCfg *, IntrptStat *);
    void       PrintInterrupt(IntrptCfg *);
    RasErrInj *GenRasErrInjCfg(const std::string &, bool = false);

 public:
    Ssm *m_ssm;
};

}  // namespace ras
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_RAS_SSM_RAS_LIBRA_H_
