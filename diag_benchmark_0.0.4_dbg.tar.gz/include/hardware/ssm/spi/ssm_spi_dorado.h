/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_SPI_SSM_SPI_DORADO_H_
#define HARDWARE_SSM_SPI_SSM_SPI_DORADO_H_

#include <string>

#include "hardware/include/ssm/spi/ssm_spi.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace spi {

class SsmSpiDorado : public SsmSpi {
 public:
    explicit SsmSpiDorado(Ssm *ssm) : SsmSpi(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmSpiDorado() {}

 public:
    uint32_t ssm_spi_density(void);
    bool     ssm_spi_4k_erase(uint32_t);
    bool     ssm_spi_erase_all(void);
    bool     ssm_spi_erase_bytes(SSM_SPI_REQ &);
    bool     ssm_spi_progm_bytes(SSM_SPI_REQ &);
    bool     ssm_spi_eprog_bytes(SSM_SPI_REQ &);
    void     ssm_spi_flash_read(uint32_t, uint32_t, void *);
    void     ssm_spi_flash_write(uint32_t, uint32_t, void *);

    //////////////////////////
    // SSM SPI GENCMD WRAPPERS
    //////////////////////////
 private:
    void     spi_gencmd_setup(void *);
    void     spi_gencmd_send(void *);
    uint64_t spi_gencmd_send(uint32_t, uint32_t = 0U, uint32_t = 0U, uint32_t = 0U);
    void     spi_gencmd_seq_dump(void *);
    void     spi_gencmd_rst_mem(void);
    void     spi_gencmd_rst_quadio(void);
    void     spi_gencmd_ena_quadio(void);
    uint8_t  spi_gencmd_rdsr(void);
    uint8_t  spi_gencmd_rdcr(void);
    uint32_t spi_gencmd_jedecid(void);
    uint8_t  spi_gencmd_get_mafid(void);
    uint32_t spi_gencmd_rems(void);
    uint32_t spi_gencmd_rbpr(void);
    void     spi_gencmd_rdsr_wait_idle(void);
    void     spi_gencmd_rdsr_wait_wena(void);
    void     spi_gencmd_rdsr_wait_wdis(void);
    uint64_t spi_gencmd_read(uint32_t, uint32_t);
    uint64_t spi_gencmd_read_hs(uint32_t, uint32_t);
    void     spi_gencmd_wren(void);
    void     spi_gencmd_wdis(void);
    void     spi_gencmd_lbpr(void);
    void     spi_gencmd_ulbpr(void);
    void     spi_gencmd_eraseblk(uint32_t, uint32_t);
    void     spi_gencmd_erase4k(uint32_t);
    void     spi_gencmd_erase_all(void);
    void     spi_gencmd_pp(uint32_t, uint32_t);
    uint8_t  spi_gencmd_r8(uint32_t);
    uint16_t spi_gencmd_r16(uint32_t);
    uint32_t spi_gencmd_r32(uint32_t);
    uint64_t spi_gencmd_r64(uint32_t);

    /////////////////////////////////
    // SSM SPI FWLOAD|PGPROG WRAPPERS
    /////////////////////////////////
 private:
    void     spi_fwload_flash_to_smem(uint32_t, uint32_t);  // TODO(casper) merge
    void     spi_fwload_flash_to_iram(uint32_t, uint32_t);  // TODO(casper) merge
    void     spi_fwload_flash_to_dram(uint32_t, uint32_t);  // TODO(casper) merge
    uint32_t spi_pgprog_time_calc(void);
    void     spi_pgprog_smem_to_flash(uint32_t, uint32_t);  // TODO(casper) merge
    void     spi_pgprog_iram_to_flash(uint32_t, uint32_t);  // TODO(casper) merge
    void     spi_pgprog_dram_to_flash(uint32_t, uint32_t);  // TODO(casper) merge
    bool     spi_ctl_clk_enabled(void);
    uint32_t spi_ctl_sck_hperiod(void);
    void     spi_ctl_mode_set(uint32_t);
    uint32_t spi_ctl_mode_get(void);
    bool     spi_ctl_mode_is_lspi(void);
    bool     spi_ctl_mode_is_qspi(void);
    void     spi_ctl_sw_rst(void);
    void     spi_ctl_status(void);

    /////////////////////
    // SPI TEST INTERFACE
    /////////////////////
 public:
    bool test_spi_gencmd_read(void);
    bool test_spi_gencmd_read_mix(void);
    bool test_spi_gencmd_erase4k(void);
    bool test_spi_gencmd_write(void);
    bool test_spi_gencmd_read_all(void);
    bool test_spi_gencmd_read_hs(void);
    bool test_spi_fwload_to_smem(void);
    bool test_spi_fwload_to_iram(void);
    bool test_spi_fwload_to_dram(void);
    bool test_spi_fwload_backdoor_rc(void);
    bool test_spi_pgprog_smem_fwload_rc(void);
    bool test_spi_pgprog_iram_fwload_rc(void);
    bool test_spi_pgprog_dram_fwload_rc(void);
    bool test_spi_fwload_measure(void);
    bool test_spi_pgprog_measure(void);
    bool test_spi_rw_basic(void);
    bool test_spi_backup_fw(void);

    ////////////////////////
    // SSM SPI TOOL FUNCTION
    ////////////////////////
 public:
    void ssm_spi_status(void);
    void ssm_spi_reset(uint32_t);
    void ssm_spi_reset_lspi(void);
    void ssm_spi_reset_qspi(void);
    void ssm_spi_reset_for_bringup(void);
    bool ssm_spi_flash_dump(const std::string &, uint32_t, uint32_t);
    bool ssm_spi_flash_file(const std::string &, uint32_t, uint32_t);
};

}  // namespace spi
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_SPI_SSM_SPI_DORADO_H_
