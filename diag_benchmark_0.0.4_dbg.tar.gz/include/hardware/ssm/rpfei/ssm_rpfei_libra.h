/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_RPFEI_SSM_RPFEI_LIBRA_H_
#define HARDWARE_SSM_RPFEI_SSM_RPFEI_LIBRA_H_

#include <string>

#include "hardware/include/ssm/rpfei/ssm_rpfei.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace rpfei {

class SsmRpfeiLibra : public SsmRpfei {
 public:
    explicit SsmRpfeiLibra(Ssm *ssm) : SsmRpfei(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmRpfeiLibra() {}

 public:
    bool     get_int_arv(uint32_t);
    bool     get_int_ena(uint32_t);
    void     set_int_ena(uint32_t);
    void     set_int_dis(uint32_t);
    void     set_int_clr(uint32_t);
    void     set_axuser(const std::string &);
    uint32_t get_axuser(const std::string &);

 private:
    bool        mcu_int_get_sel_pheriph(uint32_t);
    bool        mcu_int_get_pls_pheriph(uint32_t);
    bool        mcu_int_get_ena_pheriph(uint32_t);
    void        mcu_int_set_ena_pheriph(uint32_t);
    void        mcu_int_set_dis_pheriph(uint32_t);
    bool        mcu_int_chk_arv_pheriph(uint32_t);
    bool        mcu_int_get_sel_thm(uint32_t);
    bool        mcu_int_get_pls_thm(uint32_t);
    bool        mcu_int_get_ena_thm(uint32_t);
    void        mcu_int_set_ena_thm(uint32_t);
    void        mcu_int_set_dis_thm(uint32_t);
    bool        mcu_int_chk_arv_thm(uint32_t);
    bool        mcu_int_get_sel_pwr(uint32_t);
    bool        mcu_int_get_pls_pwr(uint32_t);
    bool        mcu_int_get_ena_pwr(uint32_t);
    void        mcu_int_set_ena_pwr(uint32_t);
    void        mcu_int_set_dis_pwr(uint32_t);
    bool        mcu_int_chk_arv_pwr(uint32_t);
    bool        mcu_int_chk_vld_feedt(uint32_t, uint32_t);
    bool        mcu_int_get_ena_feedt(uint32_t, uint32_t);
    void        mcu_int_set_ena_feedt(uint32_t, uint32_t);
    void        mcu_int_set_dis_feedt(uint32_t, uint32_t);
    uint32_t    mcu_int_get_feedt_ginst(uint32_t);
    uint32_t    mcu_int_get_feedt_iinst(uint32_t);
    bool        mcu_int_get_ena_inter_md(uint32_t);
    void        mcu_int_set_ena_inter_md(uint32_t);
    void        mcu_int_set_dis_inter_md(uint32_t);
    bool        mcu_int_get_ena_rsa(void);
    void        mcu_int_set_ena_rsa(void);
    void        mcu_int_set_dis_rsa(void);
    bool        mcu_int_chk_arv_rsa(void);
    void        mcu_int_clr_arv_rsa(void);
    bool        mcu_int_get_ena_sha(void);
    void        mcu_int_set_ena_sha(void);
    void        mcu_int_set_dis_sha(void);
    bool        mcu_int_chk_arv_sha(void);
    void        mcu_int_clr_arv_sha(void);
    bool        mcu_int_get_ena_pke(void);
    bool        mcu_int_chk_arv_pke(void);
    bool        mcu_int_get_ena_ske(void);
    bool        mcu_int_chk_arv_ske(void);
    bool        mcu_int_get_ena_hash(void);
    bool        mcu_int_chk_arv_hash(void);
    bool        mcu_int_get_ena_trng(void);
    bool        mcu_int_chk_arv_trng(void);
    bool        mcu_int_get_sel_aasp_down(void);
    bool        mcu_int_get_ena_aasp_down(void);
    void        mcu_int_set_ena_aasp_down(void);
    void        mcu_int_set_dis_aasp_down(void);
    bool        mcu_int_chk_arv_aasp_down(void);
    std::string mcu_int_get_omc_details(void);
    bool        mcu_int_get_sel_exf(void);
    bool        mcu_int_get_ena_exf(void);
    void        mcu_int_set_ena_exf(void);
    void        mcu_int_set_dis_exf(void);
    bool        mcu_int_chk_arv_exf(void);
    std::string mcu_int_get_exf_details(void);
    bool        mcu_int_get_ena_ctf(void);
    void        mcu_int_set_ena_ctf(void);
    void        mcu_int_set_dis_ctf(void);
    bool        mcu_int_get_ena_ctf_off(void);
    void        mcu_int_set_ena_ctf_off(void);
    void        mcu_int_set_dis_ctf_off(void);
    bool        mcu_int_get_ena_ctf_on(void);
    void        mcu_int_set_ena_ctf_on(void);
    void        mcu_int_set_dis_ctf_on(void);
    bool        mcu_int_chk_arv_mih_rne(void);
    bool        mcu_int_chk_arv_mih_rwm(void);
    bool        mcu_int_get_ena_fatal(void);
    void        mcu_int_set_ena_fatal(void);
    void        mcu_int_set_dis_fatal(void);
    bool        mcu_int_get_ena_fwdog(void);
    void        mcu_int_set_ena_fwdog(void);
    void        mcu_int_set_dis_fwdog(void);
    bool        mcu_int_chk_arv_fwdog(void);
    uint32_t    mcu_inter_type_ram_misc_r(uint32_t);
    void        mcu_inter_type_ram_misc_w(uint32_t, uint32_t);
    uint32_t    mcu_inter_type_ram_ctrl_r(uint32_t);
    void        mcu_inter_type_ram_ctrl_w(uint32_t, uint32_t);
    uint32_t    mcu_inter_type_bch_ctrl_r(uint32_t);
    void        mcu_inter_type_bch_ctrl_w(uint32_t, uint32_t);
    uint32_t    mcu_inter_type_bch_stts_r(uint32_t);
    void        mcu_inter_type_bch_stts_w(uint32_t, uint32_t);
    uint32_t    mcu_inter_type_rch_ctrl_r(uint32_t);
    void        mcu_inter_type_rch_ctrl_w(uint32_t, uint32_t);
    uint32_t    mcu_inter_type_rch_stts_r(uint32_t);
    void        mcu_inter_type_rch_stts_w(uint32_t, uint32_t);
    bool        mcu_inter_perr_eco_type_se93(uint32_t);
    bool        mcu_inter_perr_gen_get_ena(uint32_t);
    void        mcu_inter_perr_gen_set_ena(uint32_t);
    void        mcu_inter_perr_gen_set_dis(uint32_t);
    bool        mcu_inter_perr_chk_get_ena(uint32_t);
    void        mcu_inter_perr_chk_set_ena(uint32_t);
    void        mcu_inter_perr_chk_set_dis(uint32_t);
    bool        mcu_inter_perr_inj_get_ena(uint32_t);
    void        mcu_inter_perr_inj_set_ena(uint32_t);
    void        mcu_inter_perr_inj_set_dis(uint32_t);
    void        mcu_inter_perr_inj_type(uint32_t, uint32_t, uint32_t);
    bool        mcu_inter_perr_int_get_ena(uint32_t);
    void        mcu_inter_perr_int_set_ena(uint32_t);
    void        mcu_inter_perr_int_set_dis(uint32_t);
    bool        mcu_inter_perr_int_stk_arv(uint32_t);
    bool        mcu_inter_perr_chk_err_arv(uint32_t);
    void        mcu_inter_perr_log_err_arv(uint32_t);
    void        mcu_inter_perr_log_err_arv_ram(uint32_t);
    void        mcu_inter_perr_log_err_arv_bch(uint32_t);
    void        mcu_inter_perr_log_err_arv_rch(uint32_t);
    void        mcu_inter_perr_wat_err_clr(uint32_t);
    void        mcu_inter_perr_clr_err_arv(uint32_t);
    uint32_t    mcu_inter_perr_cvt_err_adr(uint32_t, uint32_t);
    uint32_t    mcu_inter_perr_get_err_adr(uint32_t);
    void        mcu_inter_perr_stt_dump(uint32_t, std::string);
    uint32_t    mcu_inter_perr_ram_rw_trigger(uint32_t, uint32_t);
    bool        mcu_int_is_pulse_type(uint32_t);
    bool        mcu_int_is_not_revert(uint32_t);
    bool        mcu_int_get_arv(uint32_t);
    bool        mcu_int_get_ena(uint32_t);
    void        mcu_int_set_ena(uint32_t);
    void        mcu_int_set_dis(uint32_t);
    void        mcu_int_set_clr(uint32_t);
    uint32_t    mcu_thm_type2idx(uint32_t);
    uint32_t    mcu_pwr_type2idx(uint32_t);
    uint32_t    mcu_pheriph_type2idx(uint32_t);
    uint32_t    mcu_interm_type2idx(uint32_t);
    uint32_t    mcu_int_get_ibint_per_bit(uint32_t);
    std::string mcu_int_get_ibint_desc_phe(uint32_t);
    std::string mcu_int_get_ibint_desc_thm(uint32_t);
    std::string mcu_int_get_ibint_desc_pwr(uint32_t);
    std::string mcu_int_get_ibint_desc_itm(uint32_t);
    std::string mcu_int_get_ibint_desc_sec(uint32_t);
    std::string mcu_int_get_ibint_desc_ram(uint32_t);
    std::string mcu_int_get_ibint_desc_par(uint32_t);
    std::string mcu_int_get_ibint_desc(uint32_t);
    std::string mcu_int_get_ibint_typ2str(uint32_t);
    std::string mcu_int_get_ibint_pol2str(uint32_t);
    std::string mcu_int_get_ibint_arv2str(uint32_t);
    std::string mcu_int_get_ibint_ena2str(uint32_t);
    std::string mcu_int_get_ibint_status(uint32_t);
    std::string mcu_int_get_ibint_walk(void);

 public:
    bool test_rpfei_ssm_as_ecf_slv_r(const std::string &);
    bool test_rpfei_ssm_as_ecf_slv_w(const std::string &);
    bool test_rpfei_ssm_as_ecf_mst_r(const std::string &);
    bool test_rpfei_ssm_as_ecf_mst_w(const std::string &);
    bool test_rpfei_ssm_as_edf_mst_r(const std::string &);
    bool test_rpfei_ssm_as_edf_mst_w(const std::string &);
    bool test_rpfei_ibound_interrupt(const std::string &);
    bool test_rpfei_obound_fatal_error(const std::string &);
    bool test_rpfei_obound_fatal_single_die(const std::string &);
    bool test_rpfei_obound_fatal_dual_die(const std::string &);
    bool test_rpfei_ram_nxwnxr_check(const std::string &);
    bool test_rpfei_ram_1xw1xr_check(const std::string &);
    bool test_rpfei_ram_no_gen_check(const std::string &);
    bool test_rpfei_ram_err_scan(const std::string &);
    bool test_rpfei_sanity_check(const std::string &);

 private:
    bool     test_rpfei_ram_as_ecf_slv_r_err(ssm_rpfei_set_t &);
    bool     test_rpfei_ram_as_ecf_slv_r_int(ssm_rpfei_set_t &);
    bool     test_rpfei_reg_as_ecf_slv_r_by_pcie(void);
    bool     test_rpfei_reg_as_ecf_slv_w_by_pcie(void);
    bool     test_rpfei_ssm_as_ecf_mst_r_parity(void);
    bool     test_rpfei_ssm_as_ecf_mst_r_resp(void);
    bool     test_rpfei_ssm_as_ecf_mst_r_slverr(void);
    bool     test_rpfei_ssm_as_ecf_mst_w_cdte(void);
    bool     test_rpfei_mih_as_noc_mst_w_decerr(void);
    bool     test_rpfei_ssm_as_edf_mst_r_parity(void);
    bool     test_rpfei_ssm_as_edf_mst_w_dmem(void);
    bool     test_rpfei_ram_no_err_nxwnxr(ssm_rpfei_set_t &);
    bool     test_rpfei_ram_no_err_1xw1xr(ssm_rpfei_set_t &);
    bool     test_rpfei_ram_no_gen_1xw1xr(ssm_rpfei_set_t &);
    bool     test_rpfei_ram_addr_err_scan(ssm_rpfei_set_t &);
    bool     test_rpfei_ssm_on_boot_ras_def(void);
    bool     pci_int_ih_ssmexcp_chk_err_arv(bool);
    void     pci_int_ih_ssmexcp_clr_err_arv(bool);
    void     pci_int_ih_ssmexcp_wat_err_clr(bool);
    void     pci_off_auto_link_down(void);
    uint32_t get_rpfei_type_per_mem(uint32_t);
    uint32_t get_rpfei_type_cascade(uint32_t);
    Abmp *   abmp_get(const std::string &);
    Absp *   absp_get(const std::string &);

 public:
    std::string handle_tool_req_get_str(const std::string &);
    bool        handle_tool_req_set(const std::string &, uint32_t &);
    void        handle_ras_req(const std::string &, std::string = "");
    void        handle_ras_ena(RasCfg *);
    void        handle_ras_dis(RasCfg *);
    void        handle_ras_clr(RasCfg *);
    void        handle_ras_query(RasErrStat *);
    void        handle_ras_inj_stop(RasErrInj *);
    void        handle_ras_inj_start(RasErrInj *);
    RasErrInj * handle_ras_inj_cfg_gen(const std::string &, bool);
};

}  // namespace rpfei
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_RPFEI_SSM_RPFEI_LIBRA_H_
