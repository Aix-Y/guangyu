/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_SDW_SSM_SM4_XTS_4D0_LMD_H_
#define HARDWARE_SSM_SDW_SSM_SM4_XTS_4D0_LMD_H_

#pragma pack(push, 1)
#define SM4_XTS_CTRL_OFFSET 0x0000
typedef struct _SM4_XTS_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int ENABLE : 1;
    unsigned int MODE_SEL : 1;
    unsigned int : 30;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 30;
    unsigned int MODE_SEL : 1;
    unsigned int ENABLE : 1;
#endif
} SM4_XTS_CTRL_t;

typedef union {
    unsigned int   val : 32;
    SM4_XTS_CTRL_t f;
} SM4_XTS_CTRL_u;

#define SM4_XTS_VC0_DECRYPT_FORCE_OFFSET 0x0004
typedef struct _SM4_XTS_VC0_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC0_DECRYPT_FORCE_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_VC0_DECRYPT_FORCE_t f;
} SM4_XTS_VC0_DECRYPT_FORCE_u;

#define SM4_XTS_VC0_INTEGRITY_FORCE_OFFSET 0x0008
typedef struct _SM4_XTS_VC0_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC0_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                  val : 32;
    SM4_XTS_VC0_INTEGRITY_FORCE_t f;
} SM4_XTS_VC0_INTEGRITY_FORCE_u;

#define SM4_XTS_VC0_KEY_UPDATE_OFFSET 0x000c
typedef struct _SM4_XTS_VC0_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC0_KEY_UPDATE_t;

typedef union {
    unsigned int             val : 32;
    SM4_XTS_VC0_KEY_UPDATE_t f;
} SM4_XTS_VC0_KEY_UPDATE_u;

#define SM4_XTS_VC0_KEY1_0_OFFSET 0x0010
typedef struct _SM4_XTS_VC0_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC0_KEY1_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC0_KEY1_0_t f;
} SM4_XTS_VC0_KEY1_0_u;

#define SM4_XTS_VC0_KEY1_1_OFFSET 0x0014
typedef struct _SM4_XTS_VC0_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC0_KEY1_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC0_KEY1_1_t f;
} SM4_XTS_VC0_KEY1_1_u;

#define SM4_XTS_VC0_KEY1_2_OFFSET 0x0018
typedef struct _SM4_XTS_VC0_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC0_KEY1_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC0_KEY1_2_t f;
} SM4_XTS_VC0_KEY1_2_u;

#define SM4_XTS_VC0_KEY1_3_OFFSET 0x001c
typedef struct _SM4_XTS_VC0_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC0_KEY1_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC0_KEY1_3_t f;
} SM4_XTS_VC0_KEY1_3_u;

#define SM4_XTS_VC0_KEY2_0_OFFSET 0x0020
typedef struct _SM4_XTS_VC0_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC0_KEY2_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC0_KEY2_0_t f;
} SM4_XTS_VC0_KEY2_0_u;

#define SM4_XTS_VC0_KEY2_1_OFFSET 0x0024
typedef struct _SM4_XTS_VC0_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC0_KEY2_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC0_KEY2_1_t f;
} SM4_XTS_VC0_KEY2_1_u;

#define SM4_XTS_VC0_KEY2_2_OFFSET 0x0028
typedef struct _SM4_XTS_VC0_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC0_KEY2_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC0_KEY2_2_t f;
} SM4_XTS_VC0_KEY2_2_u;

#define SM4_XTS_VC0_KEY2_3_OFFSET 0x002c
typedef struct _SM4_XTS_VC0_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC0_KEY2_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC0_KEY2_3_t f;
} SM4_XTS_VC0_KEY2_3_u;

#define SM4_XTS_VC1_DECRYPT_FORCE_OFFSET 0x0030
typedef struct _SM4_XTS_VC1_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC1_DECRYPT_FORCE_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_VC1_DECRYPT_FORCE_t f;
} SM4_XTS_VC1_DECRYPT_FORCE_u;

#define SM4_XTS_VC1_INTEGRITY_FORCE_OFFSET 0x0034
typedef struct _SM4_XTS_VC1_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC1_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                  val : 32;
    SM4_XTS_VC1_INTEGRITY_FORCE_t f;
} SM4_XTS_VC1_INTEGRITY_FORCE_u;

#define SM4_XTS_VC1_KEY_UPDATE_OFFSET 0x0038
typedef struct _SM4_XTS_VC1_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC1_KEY_UPDATE_t;

typedef union {
    unsigned int             val : 32;
    SM4_XTS_VC1_KEY_UPDATE_t f;
} SM4_XTS_VC1_KEY_UPDATE_u;

#define SM4_XTS_VC1_KEY1_0_OFFSET 0x003c
typedef struct _SM4_XTS_VC1_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC1_KEY1_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC1_KEY1_0_t f;
} SM4_XTS_VC1_KEY1_0_u;

#define SM4_XTS_VC1_KEY1_1_OFFSET 0x0040
typedef struct _SM4_XTS_VC1_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC1_KEY1_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC1_KEY1_1_t f;
} SM4_XTS_VC1_KEY1_1_u;

#define SM4_XTS_VC1_KEY1_2_OFFSET 0x0044
typedef struct _SM4_XTS_VC1_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC1_KEY1_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC1_KEY1_2_t f;
} SM4_XTS_VC1_KEY1_2_u;

#define SM4_XTS_VC1_KEY1_3_OFFSET 0x0048
typedef struct _SM4_XTS_VC1_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC1_KEY1_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC1_KEY1_3_t f;
} SM4_XTS_VC1_KEY1_3_u;

#define SM4_XTS_VC1_KEY2_0_OFFSET 0x004c
typedef struct _SM4_XTS_VC1_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC1_KEY2_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC1_KEY2_0_t f;
} SM4_XTS_VC1_KEY2_0_u;

#define SM4_XTS_VC1_KEY2_1_OFFSET 0x0050
typedef struct _SM4_XTS_VC1_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC1_KEY2_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC1_KEY2_1_t f;
} SM4_XTS_VC1_KEY2_1_u;

#define SM4_XTS_VC1_KEY2_2_OFFSET 0x0054
typedef struct _SM4_XTS_VC1_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC1_KEY2_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC1_KEY2_2_t f;
} SM4_XTS_VC1_KEY2_2_u;

#define SM4_XTS_VC1_KEY2_3_OFFSET 0x0058
typedef struct _SM4_XTS_VC1_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC1_KEY2_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC1_KEY2_3_t f;
} SM4_XTS_VC1_KEY2_3_u;

#define SM4_XTS_VC2_DECRYPT_FORCE_OFFSET 0x005c
typedef struct _SM4_XTS_VC2_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC2_DECRYPT_FORCE_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_VC2_DECRYPT_FORCE_t f;
} SM4_XTS_VC2_DECRYPT_FORCE_u;

#define SM4_XTS_VC2_INTEGRITY_FORCE_OFFSET 0x0060
typedef struct _SM4_XTS_VC2_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC2_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                  val : 32;
    SM4_XTS_VC2_INTEGRITY_FORCE_t f;
} SM4_XTS_VC2_INTEGRITY_FORCE_u;

#define SM4_XTS_VC2_KEY_UPDATE_OFFSET 0x0064
typedef struct _SM4_XTS_VC2_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC2_KEY_UPDATE_t;

typedef union {
    unsigned int             val : 32;
    SM4_XTS_VC2_KEY_UPDATE_t f;
} SM4_XTS_VC2_KEY_UPDATE_u;

#define SM4_XTS_VC2_KEY1_0_OFFSET 0x0068
typedef struct _SM4_XTS_VC2_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC2_KEY1_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC2_KEY1_0_t f;
} SM4_XTS_VC2_KEY1_0_u;

#define SM4_XTS_VC2_KEY1_1_OFFSET 0x006c
typedef struct _SM4_XTS_VC2_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC2_KEY1_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC2_KEY1_1_t f;
} SM4_XTS_VC2_KEY1_1_u;

#define SM4_XTS_VC2_KEY1_2_OFFSET 0x0070
typedef struct _SM4_XTS_VC2_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC2_KEY1_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC2_KEY1_2_t f;
} SM4_XTS_VC2_KEY1_2_u;

#define SM4_XTS_VC2_KEY1_3_OFFSET 0x0074
typedef struct _SM4_XTS_VC2_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC2_KEY1_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC2_KEY1_3_t f;
} SM4_XTS_VC2_KEY1_3_u;

#define SM4_XTS_VC2_KEY2_0_OFFSET 0x0078
typedef struct _SM4_XTS_VC2_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC2_KEY2_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC2_KEY2_0_t f;
} SM4_XTS_VC2_KEY2_0_u;

#define SM4_XTS_VC2_KEY2_1_OFFSET 0x007c
typedef struct _SM4_XTS_VC2_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC2_KEY2_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC2_KEY2_1_t f;
} SM4_XTS_VC2_KEY2_1_u;

#define SM4_XTS_VC2_KEY2_2_OFFSET 0x0080
typedef struct _SM4_XTS_VC2_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC2_KEY2_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC2_KEY2_2_t f;
} SM4_XTS_VC2_KEY2_2_u;

#define SM4_XTS_VC2_KEY2_3_OFFSET 0x0084
typedef struct _SM4_XTS_VC2_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC2_KEY2_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC2_KEY2_3_t f;
} SM4_XTS_VC2_KEY2_3_u;

#define SM4_XTS_VC3_DECRYPT_FORCE_OFFSET 0x0088
typedef struct _SM4_XTS_VC3_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC3_DECRYPT_FORCE_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_VC3_DECRYPT_FORCE_t f;
} SM4_XTS_VC3_DECRYPT_FORCE_u;

#define SM4_XTS_VC3_INTEGRITY_FORCE_OFFSET 0x008c
typedef struct _SM4_XTS_VC3_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC3_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                  val : 32;
    SM4_XTS_VC3_INTEGRITY_FORCE_t f;
} SM4_XTS_VC3_INTEGRITY_FORCE_u;

#define SM4_XTS_VC3_KEY_UPDATE_OFFSET 0x0090
typedef struct _SM4_XTS_VC3_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC3_KEY_UPDATE_t;

typedef union {
    unsigned int             val : 32;
    SM4_XTS_VC3_KEY_UPDATE_t f;
} SM4_XTS_VC3_KEY_UPDATE_u;

#define SM4_XTS_VC3_KEY1_0_OFFSET 0x0094
typedef struct _SM4_XTS_VC3_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC3_KEY1_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC3_KEY1_0_t f;
} SM4_XTS_VC3_KEY1_0_u;

#define SM4_XTS_VC3_KEY1_1_OFFSET 0x0098
typedef struct _SM4_XTS_VC3_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC3_KEY1_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC3_KEY1_1_t f;
} SM4_XTS_VC3_KEY1_1_u;

#define SM4_XTS_VC3_KEY1_2_OFFSET 0x009c
typedef struct _SM4_XTS_VC3_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC3_KEY1_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC3_KEY1_2_t f;
} SM4_XTS_VC3_KEY1_2_u;

#define SM4_XTS_VC3_KEY1_3_OFFSET 0x00a0
typedef struct _SM4_XTS_VC3_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC3_KEY1_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC3_KEY1_3_t f;
} SM4_XTS_VC3_KEY1_3_u;

#define SM4_XTS_VC3_KEY2_0_OFFSET 0x00a4
typedef struct _SM4_XTS_VC3_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC3_KEY2_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC3_KEY2_0_t f;
} SM4_XTS_VC3_KEY2_0_u;

#define SM4_XTS_VC3_KEY2_1_OFFSET 0x00a8
typedef struct _SM4_XTS_VC3_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC3_KEY2_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC3_KEY2_1_t f;
} SM4_XTS_VC3_KEY2_1_u;

#define SM4_XTS_VC3_KEY2_2_OFFSET 0x00ac
typedef struct _SM4_XTS_VC3_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC3_KEY2_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC3_KEY2_2_t f;
} SM4_XTS_VC3_KEY2_2_u;

#define SM4_XTS_VC3_KEY2_3_OFFSET 0x00b0
typedef struct _SM4_XTS_VC3_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC3_KEY2_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC3_KEY2_3_t f;
} SM4_XTS_VC3_KEY2_3_u;

#define SM4_XTS_VC4_DECRYPT_FORCE_OFFSET 0x00b4
typedef struct _SM4_XTS_VC4_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC4_DECRYPT_FORCE_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_VC4_DECRYPT_FORCE_t f;
} SM4_XTS_VC4_DECRYPT_FORCE_u;

#define SM4_XTS_VC4_INTEGRITY_FORCE_OFFSET 0x00b8
typedef struct _SM4_XTS_VC4_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC4_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                  val : 32;
    SM4_XTS_VC4_INTEGRITY_FORCE_t f;
} SM4_XTS_VC4_INTEGRITY_FORCE_u;

#define SM4_XTS_VC4_KEY_UPDATE_OFFSET 0x00bc
typedef struct _SM4_XTS_VC4_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC4_KEY_UPDATE_t;

typedef union {
    unsigned int             val : 32;
    SM4_XTS_VC4_KEY_UPDATE_t f;
} SM4_XTS_VC4_KEY_UPDATE_u;

#define SM4_XTS_VC4_KEY1_0_OFFSET 0x00c0
typedef struct _SM4_XTS_VC4_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC4_KEY1_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC4_KEY1_0_t f;
} SM4_XTS_VC4_KEY1_0_u;

#define SM4_XTS_VC4_KEY1_1_OFFSET 0x00c4
typedef struct _SM4_XTS_VC4_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC4_KEY1_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC4_KEY1_1_t f;
} SM4_XTS_VC4_KEY1_1_u;

#define SM4_XTS_VC4_KEY1_2_OFFSET 0x00c8
typedef struct _SM4_XTS_VC4_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC4_KEY1_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC4_KEY1_2_t f;
} SM4_XTS_VC4_KEY1_2_u;

#define SM4_XTS_VC4_KEY1_3_OFFSET 0x00cc
typedef struct _SM4_XTS_VC4_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC4_KEY1_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC4_KEY1_3_t f;
} SM4_XTS_VC4_KEY1_3_u;

#define SM4_XTS_VC4_KEY2_0_OFFSET 0x00d0
typedef struct _SM4_XTS_VC4_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC4_KEY2_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC4_KEY2_0_t f;
} SM4_XTS_VC4_KEY2_0_u;

#define SM4_XTS_VC4_KEY2_1_OFFSET 0x00d4
typedef struct _SM4_XTS_VC4_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC4_KEY2_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC4_KEY2_1_t f;
} SM4_XTS_VC4_KEY2_1_u;

#define SM4_XTS_VC4_KEY2_2_OFFSET 0x00d8
typedef struct _SM4_XTS_VC4_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC4_KEY2_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC4_KEY2_2_t f;
} SM4_XTS_VC4_KEY2_2_u;

#define SM4_XTS_VC4_KEY2_3_OFFSET 0x00dc
typedef struct _SM4_XTS_VC4_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC4_KEY2_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC4_KEY2_3_t f;
} SM4_XTS_VC4_KEY2_3_u;

#define SM4_XTS_VC5_DECRYPT_FORCE_OFFSET 0x00e0
typedef struct _SM4_XTS_VC5_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC5_DECRYPT_FORCE_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_VC5_DECRYPT_FORCE_t f;
} SM4_XTS_VC5_DECRYPT_FORCE_u;

#define SM4_XTS_VC5_INTEGRITY_FORCE_OFFSET 0x00e4
typedef struct _SM4_XTS_VC5_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC5_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                  val : 32;
    SM4_XTS_VC5_INTEGRITY_FORCE_t f;
} SM4_XTS_VC5_INTEGRITY_FORCE_u;

#define SM4_XTS_VC5_KEY_UPDATE_OFFSET 0x00e8
typedef struct _SM4_XTS_VC5_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC5_KEY_UPDATE_t;

typedef union {
    unsigned int             val : 32;
    SM4_XTS_VC5_KEY_UPDATE_t f;
} SM4_XTS_VC5_KEY_UPDATE_u;

#define SM4_XTS_VC5_KEY1_0_OFFSET 0x00ec
typedef struct _SM4_XTS_VC5_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC5_KEY1_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC5_KEY1_0_t f;
} SM4_XTS_VC5_KEY1_0_u;

#define SM4_XTS_VC5_KEY1_1_OFFSET 0x00f0
typedef struct _SM4_XTS_VC5_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC5_KEY1_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC5_KEY1_1_t f;
} SM4_XTS_VC5_KEY1_1_u;

#define SM4_XTS_VC5_KEY1_2_OFFSET 0x00f4
typedef struct _SM4_XTS_VC5_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC5_KEY1_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC5_KEY1_2_t f;
} SM4_XTS_VC5_KEY1_2_u;

#define SM4_XTS_VC5_KEY1_3_OFFSET 0x00f8
typedef struct _SM4_XTS_VC5_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC5_KEY1_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC5_KEY1_3_t f;
} SM4_XTS_VC5_KEY1_3_u;

#define SM4_XTS_VC5_KEY2_0_OFFSET 0x00fc
typedef struct _SM4_XTS_VC5_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC5_KEY2_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC5_KEY2_0_t f;
} SM4_XTS_VC5_KEY2_0_u;

#define SM4_XTS_VC5_KEY2_1_OFFSET 0x0100
typedef struct _SM4_XTS_VC5_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC5_KEY2_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC5_KEY2_1_t f;
} SM4_XTS_VC5_KEY2_1_u;

#define SM4_XTS_VC5_KEY2_2_OFFSET 0x0104
typedef struct _SM4_XTS_VC5_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC5_KEY2_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC5_KEY2_2_t f;
} SM4_XTS_VC5_KEY2_2_u;

#define SM4_XTS_VC5_KEY2_3_OFFSET 0x0108
typedef struct _SM4_XTS_VC5_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC5_KEY2_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC5_KEY2_3_t f;
} SM4_XTS_VC5_KEY2_3_u;

#define SM4_XTS_VC6_DECRYPT_FORCE_OFFSET 0x010c
typedef struct _SM4_XTS_VC6_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC6_DECRYPT_FORCE_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_VC6_DECRYPT_FORCE_t f;
} SM4_XTS_VC6_DECRYPT_FORCE_u;

#define SM4_XTS_VC6_INTEGRITY_FORCE_OFFSET 0x0110
typedef struct _SM4_XTS_VC6_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC6_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                  val : 32;
    SM4_XTS_VC6_INTEGRITY_FORCE_t f;
} SM4_XTS_VC6_INTEGRITY_FORCE_u;

#define SM4_XTS_VC6_KEY_UPDATE_OFFSET 0x0114
typedef struct _SM4_XTS_VC6_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC6_KEY_UPDATE_t;

typedef union {
    unsigned int             val : 32;
    SM4_XTS_VC6_KEY_UPDATE_t f;
} SM4_XTS_VC6_KEY_UPDATE_u;

#define SM4_XTS_VC6_KEY1_0_OFFSET 0x0118
typedef struct _SM4_XTS_VC6_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC6_KEY1_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC6_KEY1_0_t f;
} SM4_XTS_VC6_KEY1_0_u;

#define SM4_XTS_VC6_KEY1_1_OFFSET 0x011c
typedef struct _SM4_XTS_VC6_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC6_KEY1_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC6_KEY1_1_t f;
} SM4_XTS_VC6_KEY1_1_u;

#define SM4_XTS_VC6_KEY1_2_OFFSET 0x0120
typedef struct _SM4_XTS_VC6_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC6_KEY1_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC6_KEY1_2_t f;
} SM4_XTS_VC6_KEY1_2_u;

#define SM4_XTS_VC6_KEY1_3_OFFSET 0x0124
typedef struct _SM4_XTS_VC6_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC6_KEY1_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC6_KEY1_3_t f;
} SM4_XTS_VC6_KEY1_3_u;

#define SM4_XTS_VC6_KEY2_0_OFFSET 0x0128
typedef struct _SM4_XTS_VC6_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC6_KEY2_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC6_KEY2_0_t f;
} SM4_XTS_VC6_KEY2_0_u;

#define SM4_XTS_VC6_KEY2_1_OFFSET 0x012c
typedef struct _SM4_XTS_VC6_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC6_KEY2_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC6_KEY2_1_t f;
} SM4_XTS_VC6_KEY2_1_u;

#define SM4_XTS_VC6_KEY2_2_OFFSET 0x0130
typedef struct _SM4_XTS_VC6_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC6_KEY2_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC6_KEY2_2_t f;
} SM4_XTS_VC6_KEY2_2_u;

#define SM4_XTS_VC6_KEY2_3_OFFSET 0x0134
typedef struct _SM4_XTS_VC6_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC6_KEY2_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC6_KEY2_3_t f;
} SM4_XTS_VC6_KEY2_3_u;

#define SM4_XTS_VC7_DECRYPT_FORCE_OFFSET 0x0138
typedef struct _SM4_XTS_VC7_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC7_DECRYPT_FORCE_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_VC7_DECRYPT_FORCE_t f;
} SM4_XTS_VC7_DECRYPT_FORCE_u;

#define SM4_XTS_VC7_INTEGRITY_FORCE_OFFSET 0x013c
typedef struct _SM4_XTS_VC7_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC7_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                  val : 32;
    SM4_XTS_VC7_INTEGRITY_FORCE_t f;
} SM4_XTS_VC7_INTEGRITY_FORCE_u;

#define SM4_XTS_VC7_KEY_UPDATE_OFFSET 0x0140
typedef struct _SM4_XTS_VC7_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC7_KEY_UPDATE_t;

typedef union {
    unsigned int             val : 32;
    SM4_XTS_VC7_KEY_UPDATE_t f;
} SM4_XTS_VC7_KEY_UPDATE_u;

#define SM4_XTS_VC7_KEY1_0_OFFSET 0x0144
typedef struct _SM4_XTS_VC7_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC7_KEY1_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC7_KEY1_0_t f;
} SM4_XTS_VC7_KEY1_0_u;

#define SM4_XTS_VC7_KEY1_1_OFFSET 0x0148
typedef struct _SM4_XTS_VC7_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC7_KEY1_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC7_KEY1_1_t f;
} SM4_XTS_VC7_KEY1_1_u;

#define SM4_XTS_VC7_KEY1_2_OFFSET 0x014c
typedef struct _SM4_XTS_VC7_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC7_KEY1_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC7_KEY1_2_t f;
} SM4_XTS_VC7_KEY1_2_u;

#define SM4_XTS_VC7_KEY1_3_OFFSET 0x0150
typedef struct _SM4_XTS_VC7_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC7_KEY1_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC7_KEY1_3_t f;
} SM4_XTS_VC7_KEY1_3_u;

#define SM4_XTS_VC7_KEY2_0_OFFSET 0x0154
typedef struct _SM4_XTS_VC7_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC7_KEY2_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC7_KEY2_0_t f;
} SM4_XTS_VC7_KEY2_0_u;

#define SM4_XTS_VC7_KEY2_1_OFFSET 0x0158
typedef struct _SM4_XTS_VC7_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC7_KEY2_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC7_KEY2_1_t f;
} SM4_XTS_VC7_KEY2_1_u;

#define SM4_XTS_VC7_KEY2_2_OFFSET 0x015c
typedef struct _SM4_XTS_VC7_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC7_KEY2_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC7_KEY2_2_t f;
} SM4_XTS_VC7_KEY2_2_u;

#define SM4_XTS_VC7_KEY2_3_OFFSET 0x0160
typedef struct _SM4_XTS_VC7_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC7_KEY2_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC7_KEY2_3_t f;
} SM4_XTS_VC7_KEY2_3_u;

#define SM4_XTS_VC8_DECRYPT_FORCE_OFFSET 0x0164
typedef struct _SM4_XTS_VC8_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC8_DECRYPT_FORCE_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_VC8_DECRYPT_FORCE_t f;
} SM4_XTS_VC8_DECRYPT_FORCE_u;

#define SM4_XTS_VC8_INTEGRITY_FORCE_OFFSET 0x0168
typedef struct _SM4_XTS_VC8_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC8_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                  val : 32;
    SM4_XTS_VC8_INTEGRITY_FORCE_t f;
} SM4_XTS_VC8_INTEGRITY_FORCE_u;

#define SM4_XTS_VC8_KEY_UPDATE_OFFSET 0x016c
typedef struct _SM4_XTS_VC8_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC8_KEY_UPDATE_t;

typedef union {
    unsigned int             val : 32;
    SM4_XTS_VC8_KEY_UPDATE_t f;
} SM4_XTS_VC8_KEY_UPDATE_u;

#define SM4_XTS_VC8_KEY1_0_OFFSET 0x0170
typedef struct _SM4_XTS_VC8_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC8_KEY1_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC8_KEY1_0_t f;
} SM4_XTS_VC8_KEY1_0_u;

#define SM4_XTS_VC8_KEY1_1_OFFSET 0x0174
typedef struct _SM4_XTS_VC8_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC8_KEY1_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC8_KEY1_1_t f;
} SM4_XTS_VC8_KEY1_1_u;

#define SM4_XTS_VC8_KEY1_2_OFFSET 0x0178
typedef struct _SM4_XTS_VC8_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC8_KEY1_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC8_KEY1_2_t f;
} SM4_XTS_VC8_KEY1_2_u;

#define SM4_XTS_VC8_KEY1_3_OFFSET 0x017c
typedef struct _SM4_XTS_VC8_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC8_KEY1_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC8_KEY1_3_t f;
} SM4_XTS_VC8_KEY1_3_u;

#define SM4_XTS_VC8_KEY2_0_OFFSET 0x0180
typedef struct _SM4_XTS_VC8_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC8_KEY2_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC8_KEY2_0_t f;
} SM4_XTS_VC8_KEY2_0_u;

#define SM4_XTS_VC8_KEY2_1_OFFSET 0x0184
typedef struct _SM4_XTS_VC8_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC8_KEY2_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC8_KEY2_1_t f;
} SM4_XTS_VC8_KEY2_1_u;

#define SM4_XTS_VC8_KEY2_2_OFFSET 0x0188
typedef struct _SM4_XTS_VC8_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC8_KEY2_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC8_KEY2_2_t f;
} SM4_XTS_VC8_KEY2_2_u;

#define SM4_XTS_VC8_KEY2_3_OFFSET 0x018c
typedef struct _SM4_XTS_VC8_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC8_KEY2_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC8_KEY2_3_t f;
} SM4_XTS_VC8_KEY2_3_u;

#define SM4_XTS_VC9_DECRYPT_FORCE_OFFSET 0x0190
typedef struct _SM4_XTS_VC9_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC9_DECRYPT_FORCE_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_VC9_DECRYPT_FORCE_t f;
} SM4_XTS_VC9_DECRYPT_FORCE_u;

#define SM4_XTS_VC9_INTEGRITY_FORCE_OFFSET 0x0194
typedef struct _SM4_XTS_VC9_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC9_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                  val : 32;
    SM4_XTS_VC9_INTEGRITY_FORCE_t f;
} SM4_XTS_VC9_INTEGRITY_FORCE_u;

#define SM4_XTS_VC9_KEY_UPDATE_OFFSET 0x0198
typedef struct _SM4_XTS_VC9_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC9_KEY_UPDATE_t;

typedef union {
    unsigned int             val : 32;
    SM4_XTS_VC9_KEY_UPDATE_t f;
} SM4_XTS_VC9_KEY_UPDATE_u;

#define SM4_XTS_VC9_KEY1_0_OFFSET 0x019c
typedef struct _SM4_XTS_VC9_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC9_KEY1_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC9_KEY1_0_t f;
} SM4_XTS_VC9_KEY1_0_u;

#define SM4_XTS_VC9_KEY1_1_OFFSET 0x01a0
typedef struct _SM4_XTS_VC9_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC9_KEY1_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC9_KEY1_1_t f;
} SM4_XTS_VC9_KEY1_1_u;

#define SM4_XTS_VC9_KEY1_2_OFFSET 0x01a4
typedef struct _SM4_XTS_VC9_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC9_KEY1_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC9_KEY1_2_t f;
} SM4_XTS_VC9_KEY1_2_u;

#define SM4_XTS_VC9_KEY1_3_OFFSET 0x01a8
typedef struct _SM4_XTS_VC9_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC9_KEY1_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC9_KEY1_3_t f;
} SM4_XTS_VC9_KEY1_3_u;

#define SM4_XTS_VC9_KEY2_0_OFFSET 0x01ac
typedef struct _SM4_XTS_VC9_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC9_KEY2_0_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC9_KEY2_0_t f;
} SM4_XTS_VC9_KEY2_0_u;

#define SM4_XTS_VC9_KEY2_1_OFFSET 0x01b0
typedef struct _SM4_XTS_VC9_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC9_KEY2_1_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC9_KEY2_1_t f;
} SM4_XTS_VC9_KEY2_1_u;

#define SM4_XTS_VC9_KEY2_2_OFFSET 0x01b4
typedef struct _SM4_XTS_VC9_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC9_KEY2_2_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC9_KEY2_2_t f;
} SM4_XTS_VC9_KEY2_2_u;

#define SM4_XTS_VC9_KEY2_3_OFFSET 0x01b8
typedef struct _SM4_XTS_VC9_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC9_KEY2_3_t;

typedef union {
    unsigned int         val : 32;
    SM4_XTS_VC9_KEY2_3_t f;
} SM4_XTS_VC9_KEY2_3_u;

#define SM4_XTS_VC10_DECRYPT_FORCE_OFFSET 0x01bc
typedef struct _SM4_XTS_VC10_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC10_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC10_DECRYPT_FORCE_t f;
} SM4_XTS_VC10_DECRYPT_FORCE_u;

#define SM4_XTS_VC10_INTEGRITY_FORCE_OFFSET 0x01c0
typedef struct _SM4_XTS_VC10_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC10_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC10_INTEGRITY_FORCE_t f;
} SM4_XTS_VC10_INTEGRITY_FORCE_u;

#define SM4_XTS_VC10_KEY_UPDATE_OFFSET 0x01c4
typedef struct _SM4_XTS_VC10_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC10_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC10_KEY_UPDATE_t f;
} SM4_XTS_VC10_KEY_UPDATE_u;

#define SM4_XTS_VC10_KEY1_0_OFFSET 0x01c8
typedef struct _SM4_XTS_VC10_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC10_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC10_KEY1_0_t f;
} SM4_XTS_VC10_KEY1_0_u;

#define SM4_XTS_VC10_KEY1_1_OFFSET 0x01cc
typedef struct _SM4_XTS_VC10_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC10_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC10_KEY1_1_t f;
} SM4_XTS_VC10_KEY1_1_u;

#define SM4_XTS_VC10_KEY1_2_OFFSET 0x01d0
typedef struct _SM4_XTS_VC10_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC10_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC10_KEY1_2_t f;
} SM4_XTS_VC10_KEY1_2_u;

#define SM4_XTS_VC10_KEY1_3_OFFSET 0x01d4
typedef struct _SM4_XTS_VC10_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC10_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC10_KEY1_3_t f;
} SM4_XTS_VC10_KEY1_3_u;

#define SM4_XTS_VC10_KEY2_0_OFFSET 0x01d8
typedef struct _SM4_XTS_VC10_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC10_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC10_KEY2_0_t f;
} SM4_XTS_VC10_KEY2_0_u;

#define SM4_XTS_VC10_KEY2_1_OFFSET 0x01dc
typedef struct _SM4_XTS_VC10_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC10_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC10_KEY2_1_t f;
} SM4_XTS_VC10_KEY2_1_u;

#define SM4_XTS_VC10_KEY2_2_OFFSET 0x01e0
typedef struct _SM4_XTS_VC10_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC10_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC10_KEY2_2_t f;
} SM4_XTS_VC10_KEY2_2_u;

#define SM4_XTS_VC10_KEY2_3_OFFSET 0x01e4
typedef struct _SM4_XTS_VC10_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC10_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC10_KEY2_3_t f;
} SM4_XTS_VC10_KEY2_3_u;

#define SM4_XTS_VC11_DECRYPT_FORCE_OFFSET 0x01e8
typedef struct _SM4_XTS_VC11_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC11_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC11_DECRYPT_FORCE_t f;
} SM4_XTS_VC11_DECRYPT_FORCE_u;

#define SM4_XTS_VC11_INTEGRITY_FORCE_OFFSET 0x01ec
typedef struct _SM4_XTS_VC11_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC11_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC11_INTEGRITY_FORCE_t f;
} SM4_XTS_VC11_INTEGRITY_FORCE_u;

#define SM4_XTS_VC11_KEY_UPDATE_OFFSET 0x01f0
typedef struct _SM4_XTS_VC11_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC11_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC11_KEY_UPDATE_t f;
} SM4_XTS_VC11_KEY_UPDATE_u;

#define SM4_XTS_VC11_KEY1_0_OFFSET 0x01f4
typedef struct _SM4_XTS_VC11_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC11_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC11_KEY1_0_t f;
} SM4_XTS_VC11_KEY1_0_u;

#define SM4_XTS_VC11_KEY1_1_OFFSET 0x01f8
typedef struct _SM4_XTS_VC11_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC11_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC11_KEY1_1_t f;
} SM4_XTS_VC11_KEY1_1_u;

#define SM4_XTS_VC11_KEY1_2_OFFSET 0x01fc
typedef struct _SM4_XTS_VC11_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC11_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC11_KEY1_2_t f;
} SM4_XTS_VC11_KEY1_2_u;

#define SM4_XTS_VC11_KEY1_3_OFFSET 0x0200
typedef struct _SM4_XTS_VC11_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC11_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC11_KEY1_3_t f;
} SM4_XTS_VC11_KEY1_3_u;

#define SM4_XTS_VC11_KEY2_0_OFFSET 0x0204
typedef struct _SM4_XTS_VC11_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC11_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC11_KEY2_0_t f;
} SM4_XTS_VC11_KEY2_0_u;

#define SM4_XTS_VC11_KEY2_1_OFFSET 0x0208
typedef struct _SM4_XTS_VC11_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC11_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC11_KEY2_1_t f;
} SM4_XTS_VC11_KEY2_1_u;

#define SM4_XTS_VC11_KEY2_2_OFFSET 0x020c
typedef struct _SM4_XTS_VC11_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC11_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC11_KEY2_2_t f;
} SM4_XTS_VC11_KEY2_2_u;

#define SM4_XTS_VC11_KEY2_3_OFFSET 0x0210
typedef struct _SM4_XTS_VC11_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC11_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC11_KEY2_3_t f;
} SM4_XTS_VC11_KEY2_3_u;

#define SM4_XTS_VC12_DECRYPT_FORCE_OFFSET 0x0214
typedef struct _SM4_XTS_VC12_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC12_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC12_DECRYPT_FORCE_t f;
} SM4_XTS_VC12_DECRYPT_FORCE_u;

#define SM4_XTS_VC12_INTEGRITY_FORCE_OFFSET 0x0218
typedef struct _SM4_XTS_VC12_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC12_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC12_INTEGRITY_FORCE_t f;
} SM4_XTS_VC12_INTEGRITY_FORCE_u;

#define SM4_XTS_VC12_KEY_UPDATE_OFFSET 0x021c
typedef struct _SM4_XTS_VC12_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC12_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC12_KEY_UPDATE_t f;
} SM4_XTS_VC12_KEY_UPDATE_u;

#define SM4_XTS_VC12_KEY1_0_OFFSET 0x0220
typedef struct _SM4_XTS_VC12_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC12_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC12_KEY1_0_t f;
} SM4_XTS_VC12_KEY1_0_u;

#define SM4_XTS_VC12_KEY1_1_OFFSET 0x0224
typedef struct _SM4_XTS_VC12_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC12_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC12_KEY1_1_t f;
} SM4_XTS_VC12_KEY1_1_u;

#define SM4_XTS_VC12_KEY1_2_OFFSET 0x0228
typedef struct _SM4_XTS_VC12_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC12_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC12_KEY1_2_t f;
} SM4_XTS_VC12_KEY1_2_u;

#define SM4_XTS_VC12_KEY1_3_OFFSET 0x022c
typedef struct _SM4_XTS_VC12_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC12_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC12_KEY1_3_t f;
} SM4_XTS_VC12_KEY1_3_u;

#define SM4_XTS_VC12_KEY2_0_OFFSET 0x0230
typedef struct _SM4_XTS_VC12_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC12_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC12_KEY2_0_t f;
} SM4_XTS_VC12_KEY2_0_u;

#define SM4_XTS_VC12_KEY2_1_OFFSET 0x0234
typedef struct _SM4_XTS_VC12_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC12_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC12_KEY2_1_t f;
} SM4_XTS_VC12_KEY2_1_u;

#define SM4_XTS_VC12_KEY2_2_OFFSET 0x0238
typedef struct _SM4_XTS_VC12_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC12_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC12_KEY2_2_t f;
} SM4_XTS_VC12_KEY2_2_u;

#define SM4_XTS_VC12_KEY2_3_OFFSET 0x023c
typedef struct _SM4_XTS_VC12_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC12_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC12_KEY2_3_t f;
} SM4_XTS_VC12_KEY2_3_u;

#define SM4_XTS_VC13_DECRYPT_FORCE_OFFSET 0x0240
typedef struct _SM4_XTS_VC13_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC13_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC13_DECRYPT_FORCE_t f;
} SM4_XTS_VC13_DECRYPT_FORCE_u;

#define SM4_XTS_VC13_INTEGRITY_FORCE_OFFSET 0x0244
typedef struct _SM4_XTS_VC13_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC13_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC13_INTEGRITY_FORCE_t f;
} SM4_XTS_VC13_INTEGRITY_FORCE_u;

#define SM4_XTS_VC13_KEY_UPDATE_OFFSET 0x0248
typedef struct _SM4_XTS_VC13_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC13_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC13_KEY_UPDATE_t f;
} SM4_XTS_VC13_KEY_UPDATE_u;

#define SM4_XTS_VC13_KEY1_0_OFFSET 0x024c
typedef struct _SM4_XTS_VC13_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC13_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC13_KEY1_0_t f;
} SM4_XTS_VC13_KEY1_0_u;

#define SM4_XTS_VC13_KEY1_1_OFFSET 0x0250
typedef struct _SM4_XTS_VC13_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC13_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC13_KEY1_1_t f;
} SM4_XTS_VC13_KEY1_1_u;

#define SM4_XTS_VC13_KEY1_2_OFFSET 0x0254
typedef struct _SM4_XTS_VC13_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC13_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC13_KEY1_2_t f;
} SM4_XTS_VC13_KEY1_2_u;

#define SM4_XTS_VC13_KEY1_3_OFFSET 0x0258
typedef struct _SM4_XTS_VC13_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC13_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC13_KEY1_3_t f;
} SM4_XTS_VC13_KEY1_3_u;

#define SM4_XTS_VC13_KEY2_0_OFFSET 0x025c
typedef struct _SM4_XTS_VC13_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC13_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC13_KEY2_0_t f;
} SM4_XTS_VC13_KEY2_0_u;

#define SM4_XTS_VC13_KEY2_1_OFFSET 0x0260
typedef struct _SM4_XTS_VC13_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC13_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC13_KEY2_1_t f;
} SM4_XTS_VC13_KEY2_1_u;

#define SM4_XTS_VC13_KEY2_2_OFFSET 0x0264
typedef struct _SM4_XTS_VC13_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC13_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC13_KEY2_2_t f;
} SM4_XTS_VC13_KEY2_2_u;

#define SM4_XTS_VC13_KEY2_3_OFFSET 0x0268
typedef struct _SM4_XTS_VC13_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC13_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC13_KEY2_3_t f;
} SM4_XTS_VC13_KEY2_3_u;

#define SM4_XTS_VC14_DECRYPT_FORCE_OFFSET 0x026c
typedef struct _SM4_XTS_VC14_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC14_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC14_DECRYPT_FORCE_t f;
} SM4_XTS_VC14_DECRYPT_FORCE_u;

#define SM4_XTS_VC14_INTEGRITY_FORCE_OFFSET 0x0270
typedef struct _SM4_XTS_VC14_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC14_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC14_INTEGRITY_FORCE_t f;
} SM4_XTS_VC14_INTEGRITY_FORCE_u;

#define SM4_XTS_VC14_KEY_UPDATE_OFFSET 0x0274
typedef struct _SM4_XTS_VC14_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC14_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC14_KEY_UPDATE_t f;
} SM4_XTS_VC14_KEY_UPDATE_u;

#define SM4_XTS_VC14_KEY1_0_OFFSET 0x0278
typedef struct _SM4_XTS_VC14_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC14_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC14_KEY1_0_t f;
} SM4_XTS_VC14_KEY1_0_u;

#define SM4_XTS_VC14_KEY1_1_OFFSET 0x027c
typedef struct _SM4_XTS_VC14_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC14_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC14_KEY1_1_t f;
} SM4_XTS_VC14_KEY1_1_u;

#define SM4_XTS_VC14_KEY1_2_OFFSET 0x0280
typedef struct _SM4_XTS_VC14_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC14_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC14_KEY1_2_t f;
} SM4_XTS_VC14_KEY1_2_u;

#define SM4_XTS_VC14_KEY1_3_OFFSET 0x0284
typedef struct _SM4_XTS_VC14_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC14_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC14_KEY1_3_t f;
} SM4_XTS_VC14_KEY1_3_u;

#define SM4_XTS_VC14_KEY2_0_OFFSET 0x0288
typedef struct _SM4_XTS_VC14_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC14_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC14_KEY2_0_t f;
} SM4_XTS_VC14_KEY2_0_u;

#define SM4_XTS_VC14_KEY2_1_OFFSET 0x028c
typedef struct _SM4_XTS_VC14_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC14_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC14_KEY2_1_t f;
} SM4_XTS_VC14_KEY2_1_u;

#define SM4_XTS_VC14_KEY2_2_OFFSET 0x0290
typedef struct _SM4_XTS_VC14_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC14_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC14_KEY2_2_t f;
} SM4_XTS_VC14_KEY2_2_u;

#define SM4_XTS_VC14_KEY2_3_OFFSET 0x0294
typedef struct _SM4_XTS_VC14_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC14_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC14_KEY2_3_t f;
} SM4_XTS_VC14_KEY2_3_u;

#define SM4_XTS_VC15_DECRYPT_FORCE_OFFSET 0x0298
typedef struct _SM4_XTS_VC15_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC15_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC15_DECRYPT_FORCE_t f;
} SM4_XTS_VC15_DECRYPT_FORCE_u;

#define SM4_XTS_VC15_INTEGRITY_FORCE_OFFSET 0x029c
typedef struct _SM4_XTS_VC15_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC15_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC15_INTEGRITY_FORCE_t f;
} SM4_XTS_VC15_INTEGRITY_FORCE_u;

#define SM4_XTS_VC15_KEY_UPDATE_OFFSET 0x02a0
typedef struct _SM4_XTS_VC15_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC15_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC15_KEY_UPDATE_t f;
} SM4_XTS_VC15_KEY_UPDATE_u;

#define SM4_XTS_VC15_KEY1_0_OFFSET 0x02a4
typedef struct _SM4_XTS_VC15_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC15_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC15_KEY1_0_t f;
} SM4_XTS_VC15_KEY1_0_u;

#define SM4_XTS_VC15_KEY1_1_OFFSET 0x02a8
typedef struct _SM4_XTS_VC15_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC15_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC15_KEY1_1_t f;
} SM4_XTS_VC15_KEY1_1_u;

#define SM4_XTS_VC15_KEY1_2_OFFSET 0x02ac
typedef struct _SM4_XTS_VC15_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC15_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC15_KEY1_2_t f;
} SM4_XTS_VC15_KEY1_2_u;

#define SM4_XTS_VC15_KEY1_3_OFFSET 0x02b0
typedef struct _SM4_XTS_VC15_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC15_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC15_KEY1_3_t f;
} SM4_XTS_VC15_KEY1_3_u;

#define SM4_XTS_VC15_KEY2_0_OFFSET 0x02b4
typedef struct _SM4_XTS_VC15_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC15_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC15_KEY2_0_t f;
} SM4_XTS_VC15_KEY2_0_u;

#define SM4_XTS_VC15_KEY2_1_OFFSET 0x02b8
typedef struct _SM4_XTS_VC15_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC15_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC15_KEY2_1_t f;
} SM4_XTS_VC15_KEY2_1_u;

#define SM4_XTS_VC15_KEY2_2_OFFSET 0x02bc
typedef struct _SM4_XTS_VC15_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC15_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC15_KEY2_2_t f;
} SM4_XTS_VC15_KEY2_2_u;

#define SM4_XTS_VC15_KEY2_3_OFFSET 0x02c0
typedef struct _SM4_XTS_VC15_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC15_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC15_KEY2_3_t f;
} SM4_XTS_VC15_KEY2_3_u;

#define SM4_XTS_VC16_DECRYPT_FORCE_OFFSET 0x02c4
typedef struct _SM4_XTS_VC16_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC16_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC16_DECRYPT_FORCE_t f;
} SM4_XTS_VC16_DECRYPT_FORCE_u;

#define SM4_XTS_VC16_INTEGRITY_FORCE_OFFSET 0x02c8
typedef struct _SM4_XTS_VC16_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC16_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC16_INTEGRITY_FORCE_t f;
} SM4_XTS_VC16_INTEGRITY_FORCE_u;

#define SM4_XTS_VC16_KEY_UPDATE_OFFSET 0x02cc
typedef struct _SM4_XTS_VC16_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC16_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC16_KEY_UPDATE_t f;
} SM4_XTS_VC16_KEY_UPDATE_u;

#define SM4_XTS_VC16_KEY1_0_OFFSET 0x02d0
typedef struct _SM4_XTS_VC16_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC16_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC16_KEY1_0_t f;
} SM4_XTS_VC16_KEY1_0_u;

#define SM4_XTS_VC16_KEY1_1_OFFSET 0x02d4
typedef struct _SM4_XTS_VC16_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC16_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC16_KEY1_1_t f;
} SM4_XTS_VC16_KEY1_1_u;

#define SM4_XTS_VC16_KEY1_2_OFFSET 0x02d8
typedef struct _SM4_XTS_VC16_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC16_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC16_KEY1_2_t f;
} SM4_XTS_VC16_KEY1_2_u;

#define SM4_XTS_VC16_KEY1_3_OFFSET 0x02dc
typedef struct _SM4_XTS_VC16_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC16_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC16_KEY1_3_t f;
} SM4_XTS_VC16_KEY1_3_u;

#define SM4_XTS_VC16_KEY2_0_OFFSET 0x02e0
typedef struct _SM4_XTS_VC16_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC16_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC16_KEY2_0_t f;
} SM4_XTS_VC16_KEY2_0_u;

#define SM4_XTS_VC16_KEY2_1_OFFSET 0x02e4
typedef struct _SM4_XTS_VC16_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC16_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC16_KEY2_1_t f;
} SM4_XTS_VC16_KEY2_1_u;

#define SM4_XTS_VC16_KEY2_2_OFFSET 0x02e8
typedef struct _SM4_XTS_VC16_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC16_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC16_KEY2_2_t f;
} SM4_XTS_VC16_KEY2_2_u;

#define SM4_XTS_VC16_KEY2_3_OFFSET 0x02ec
typedef struct _SM4_XTS_VC16_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC16_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC16_KEY2_3_t f;
} SM4_XTS_VC16_KEY2_3_u;

#define SM4_XTS_VC17_DECRYPT_FORCE_OFFSET 0x02f0
typedef struct _SM4_XTS_VC17_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC17_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC17_DECRYPT_FORCE_t f;
} SM4_XTS_VC17_DECRYPT_FORCE_u;

#define SM4_XTS_VC17_INTEGRITY_FORCE_OFFSET 0x02f4
typedef struct _SM4_XTS_VC17_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC17_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC17_INTEGRITY_FORCE_t f;
} SM4_XTS_VC17_INTEGRITY_FORCE_u;

#define SM4_XTS_VC17_KEY_UPDATE_OFFSET 0x02f8
typedef struct _SM4_XTS_VC17_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC17_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC17_KEY_UPDATE_t f;
} SM4_XTS_VC17_KEY_UPDATE_u;

#define SM4_XTS_VC17_KEY1_0_OFFSET 0x02fc
typedef struct _SM4_XTS_VC17_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC17_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC17_KEY1_0_t f;
} SM4_XTS_VC17_KEY1_0_u;

#define SM4_XTS_VC17_KEY1_1_OFFSET 0x0300
typedef struct _SM4_XTS_VC17_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC17_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC17_KEY1_1_t f;
} SM4_XTS_VC17_KEY1_1_u;

#define SM4_XTS_VC17_KEY1_2_OFFSET 0x0304
typedef struct _SM4_XTS_VC17_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC17_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC17_KEY1_2_t f;
} SM4_XTS_VC17_KEY1_2_u;

#define SM4_XTS_VC17_KEY1_3_OFFSET 0x0308
typedef struct _SM4_XTS_VC17_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC17_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC17_KEY1_3_t f;
} SM4_XTS_VC17_KEY1_3_u;

#define SM4_XTS_VC17_KEY2_0_OFFSET 0x030c
typedef struct _SM4_XTS_VC17_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC17_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC17_KEY2_0_t f;
} SM4_XTS_VC17_KEY2_0_u;

#define SM4_XTS_VC17_KEY2_1_OFFSET 0x0310
typedef struct _SM4_XTS_VC17_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC17_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC17_KEY2_1_t f;
} SM4_XTS_VC17_KEY2_1_u;

#define SM4_XTS_VC17_KEY2_2_OFFSET 0x0314
typedef struct _SM4_XTS_VC17_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC17_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC17_KEY2_2_t f;
} SM4_XTS_VC17_KEY2_2_u;

#define SM4_XTS_VC17_KEY2_3_OFFSET 0x0318
typedef struct _SM4_XTS_VC17_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC17_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC17_KEY2_3_t f;
} SM4_XTS_VC17_KEY2_3_u;

#define SM4_XTS_VC18_DECRYPT_FORCE_OFFSET 0x031c
typedef struct _SM4_XTS_VC18_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC18_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC18_DECRYPT_FORCE_t f;
} SM4_XTS_VC18_DECRYPT_FORCE_u;

#define SM4_XTS_VC18_INTEGRITY_FORCE_OFFSET 0x0320
typedef struct _SM4_XTS_VC18_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC18_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC18_INTEGRITY_FORCE_t f;
} SM4_XTS_VC18_INTEGRITY_FORCE_u;

#define SM4_XTS_VC18_KEY_UPDATE_OFFSET 0x0324
typedef struct _SM4_XTS_VC18_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC18_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC18_KEY_UPDATE_t f;
} SM4_XTS_VC18_KEY_UPDATE_u;

#define SM4_XTS_VC18_KEY1_0_OFFSET 0x0328
typedef struct _SM4_XTS_VC18_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC18_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC18_KEY1_0_t f;
} SM4_XTS_VC18_KEY1_0_u;

#define SM4_XTS_VC18_KEY1_1_OFFSET 0x032c
typedef struct _SM4_XTS_VC18_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC18_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC18_KEY1_1_t f;
} SM4_XTS_VC18_KEY1_1_u;

#define SM4_XTS_VC18_KEY1_2_OFFSET 0x0330
typedef struct _SM4_XTS_VC18_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC18_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC18_KEY1_2_t f;
} SM4_XTS_VC18_KEY1_2_u;

#define SM4_XTS_VC18_KEY1_3_OFFSET 0x0334
typedef struct _SM4_XTS_VC18_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC18_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC18_KEY1_3_t f;
} SM4_XTS_VC18_KEY1_3_u;

#define SM4_XTS_VC18_KEY2_0_OFFSET 0x0338
typedef struct _SM4_XTS_VC18_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC18_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC18_KEY2_0_t f;
} SM4_XTS_VC18_KEY2_0_u;

#define SM4_XTS_VC18_KEY2_1_OFFSET 0x033c
typedef struct _SM4_XTS_VC18_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC18_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC18_KEY2_1_t f;
} SM4_XTS_VC18_KEY2_1_u;

#define SM4_XTS_VC18_KEY2_2_OFFSET 0x0340
typedef struct _SM4_XTS_VC18_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC18_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC18_KEY2_2_t f;
} SM4_XTS_VC18_KEY2_2_u;

#define SM4_XTS_VC18_KEY2_3_OFFSET 0x0344
typedef struct _SM4_XTS_VC18_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC18_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC18_KEY2_3_t f;
} SM4_XTS_VC18_KEY2_3_u;

#define SM4_XTS_VC19_DECRYPT_FORCE_OFFSET 0x0348
typedef struct _SM4_XTS_VC19_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC19_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC19_DECRYPT_FORCE_t f;
} SM4_XTS_VC19_DECRYPT_FORCE_u;

#define SM4_XTS_VC19_INTEGRITY_FORCE_OFFSET 0x034c
typedef struct _SM4_XTS_VC19_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC19_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC19_INTEGRITY_FORCE_t f;
} SM4_XTS_VC19_INTEGRITY_FORCE_u;

#define SM4_XTS_VC19_KEY_UPDATE_OFFSET 0x0350
typedef struct _SM4_XTS_VC19_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC19_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC19_KEY_UPDATE_t f;
} SM4_XTS_VC19_KEY_UPDATE_u;

#define SM4_XTS_VC19_KEY1_0_OFFSET 0x0354
typedef struct _SM4_XTS_VC19_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC19_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC19_KEY1_0_t f;
} SM4_XTS_VC19_KEY1_0_u;

#define SM4_XTS_VC19_KEY1_1_OFFSET 0x0358
typedef struct _SM4_XTS_VC19_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC19_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC19_KEY1_1_t f;
} SM4_XTS_VC19_KEY1_1_u;

#define SM4_XTS_VC19_KEY1_2_OFFSET 0x035c
typedef struct _SM4_XTS_VC19_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC19_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC19_KEY1_2_t f;
} SM4_XTS_VC19_KEY1_2_u;

#define SM4_XTS_VC19_KEY1_3_OFFSET 0x0360
typedef struct _SM4_XTS_VC19_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC19_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC19_KEY1_3_t f;
} SM4_XTS_VC19_KEY1_3_u;

#define SM4_XTS_VC19_KEY2_0_OFFSET 0x0364
typedef struct _SM4_XTS_VC19_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC19_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC19_KEY2_0_t f;
} SM4_XTS_VC19_KEY2_0_u;

#define SM4_XTS_VC19_KEY2_1_OFFSET 0x0368
typedef struct _SM4_XTS_VC19_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC19_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC19_KEY2_1_t f;
} SM4_XTS_VC19_KEY2_1_u;

#define SM4_XTS_VC19_KEY2_2_OFFSET 0x036c
typedef struct _SM4_XTS_VC19_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC19_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC19_KEY2_2_t f;
} SM4_XTS_VC19_KEY2_2_u;

#define SM4_XTS_VC19_KEY2_3_OFFSET 0x0370
typedef struct _SM4_XTS_VC19_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC19_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC19_KEY2_3_t f;
} SM4_XTS_VC19_KEY2_3_u;

#define SM4_XTS_VC20_DECRYPT_FORCE_OFFSET 0x0374
typedef struct _SM4_XTS_VC20_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC20_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC20_DECRYPT_FORCE_t f;
} SM4_XTS_VC20_DECRYPT_FORCE_u;

#define SM4_XTS_VC20_INTEGRITY_FORCE_OFFSET 0x0378
typedef struct _SM4_XTS_VC20_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC20_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC20_INTEGRITY_FORCE_t f;
} SM4_XTS_VC20_INTEGRITY_FORCE_u;

#define SM4_XTS_VC20_KEY_UPDATE_OFFSET 0x037c
typedef struct _SM4_XTS_VC20_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC20_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC20_KEY_UPDATE_t f;
} SM4_XTS_VC20_KEY_UPDATE_u;

#define SM4_XTS_VC20_KEY1_0_OFFSET 0x0380
typedef struct _SM4_XTS_VC20_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC20_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC20_KEY1_0_t f;
} SM4_XTS_VC20_KEY1_0_u;

#define SM4_XTS_VC20_KEY1_1_OFFSET 0x0384
typedef struct _SM4_XTS_VC20_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC20_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC20_KEY1_1_t f;
} SM4_XTS_VC20_KEY1_1_u;

#define SM4_XTS_VC20_KEY1_2_OFFSET 0x0388
typedef struct _SM4_XTS_VC20_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC20_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC20_KEY1_2_t f;
} SM4_XTS_VC20_KEY1_2_u;

#define SM4_XTS_VC20_KEY1_3_OFFSET 0x038c
typedef struct _SM4_XTS_VC20_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC20_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC20_KEY1_3_t f;
} SM4_XTS_VC20_KEY1_3_u;

#define SM4_XTS_VC20_KEY2_0_OFFSET 0x0390
typedef struct _SM4_XTS_VC20_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC20_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC20_KEY2_0_t f;
} SM4_XTS_VC20_KEY2_0_u;

#define SM4_XTS_VC20_KEY2_1_OFFSET 0x0394
typedef struct _SM4_XTS_VC20_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC20_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC20_KEY2_1_t f;
} SM4_XTS_VC20_KEY2_1_u;

#define SM4_XTS_VC20_KEY2_2_OFFSET 0x0398
typedef struct _SM4_XTS_VC20_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC20_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC20_KEY2_2_t f;
} SM4_XTS_VC20_KEY2_2_u;

#define SM4_XTS_VC20_KEY2_3_OFFSET 0x039c
typedef struct _SM4_XTS_VC20_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC20_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC20_KEY2_3_t f;
} SM4_XTS_VC20_KEY2_3_u;

#define SM4_XTS_VC21_DECRYPT_FORCE_OFFSET 0x03a0
typedef struct _SM4_XTS_VC21_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC21_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC21_DECRYPT_FORCE_t f;
} SM4_XTS_VC21_DECRYPT_FORCE_u;

#define SM4_XTS_VC21_INTEGRITY_FORCE_OFFSET 0x03a4
typedef struct _SM4_XTS_VC21_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC21_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC21_INTEGRITY_FORCE_t f;
} SM4_XTS_VC21_INTEGRITY_FORCE_u;

#define SM4_XTS_VC21_KEY_UPDATE_OFFSET 0x03a8
typedef struct _SM4_XTS_VC21_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC21_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC21_KEY_UPDATE_t f;
} SM4_XTS_VC21_KEY_UPDATE_u;

#define SM4_XTS_VC21_KEY1_0_OFFSET 0x03ac
typedef struct _SM4_XTS_VC21_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC21_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC21_KEY1_0_t f;
} SM4_XTS_VC21_KEY1_0_u;

#define SM4_XTS_VC21_KEY1_1_OFFSET 0x03b0
typedef struct _SM4_XTS_VC21_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC21_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC21_KEY1_1_t f;
} SM4_XTS_VC21_KEY1_1_u;

#define SM4_XTS_VC21_KEY1_2_OFFSET 0x03b4
typedef struct _SM4_XTS_VC21_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC21_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC21_KEY1_2_t f;
} SM4_XTS_VC21_KEY1_2_u;

#define SM4_XTS_VC21_KEY1_3_OFFSET 0x03b8
typedef struct _SM4_XTS_VC21_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC21_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC21_KEY1_3_t f;
} SM4_XTS_VC21_KEY1_3_u;

#define SM4_XTS_VC21_KEY2_0_OFFSET 0x03bc
typedef struct _SM4_XTS_VC21_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC21_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC21_KEY2_0_t f;
} SM4_XTS_VC21_KEY2_0_u;

#define SM4_XTS_VC21_KEY2_1_OFFSET 0x03c0
typedef struct _SM4_XTS_VC21_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC21_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC21_KEY2_1_t f;
} SM4_XTS_VC21_KEY2_1_u;

#define SM4_XTS_VC21_KEY2_2_OFFSET 0x03c4
typedef struct _SM4_XTS_VC21_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC21_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC21_KEY2_2_t f;
} SM4_XTS_VC21_KEY2_2_u;

#define SM4_XTS_VC21_KEY2_3_OFFSET 0x03c8
typedef struct _SM4_XTS_VC21_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC21_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC21_KEY2_3_t f;
} SM4_XTS_VC21_KEY2_3_u;

#define SM4_XTS_VC22_DECRYPT_FORCE_OFFSET 0x03cc
typedef struct _SM4_XTS_VC22_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC22_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC22_DECRYPT_FORCE_t f;
} SM4_XTS_VC22_DECRYPT_FORCE_u;

#define SM4_XTS_VC22_INTEGRITY_FORCE_OFFSET 0x03d0
typedef struct _SM4_XTS_VC22_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC22_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC22_INTEGRITY_FORCE_t f;
} SM4_XTS_VC22_INTEGRITY_FORCE_u;

#define SM4_XTS_VC22_KEY_UPDATE_OFFSET 0x03d4
typedef struct _SM4_XTS_VC22_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC22_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC22_KEY_UPDATE_t f;
} SM4_XTS_VC22_KEY_UPDATE_u;

#define SM4_XTS_VC22_KEY1_0_OFFSET 0x03d8
typedef struct _SM4_XTS_VC22_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC22_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC22_KEY1_0_t f;
} SM4_XTS_VC22_KEY1_0_u;

#define SM4_XTS_VC22_KEY1_1_OFFSET 0x03dc
typedef struct _SM4_XTS_VC22_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC22_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC22_KEY1_1_t f;
} SM4_XTS_VC22_KEY1_1_u;

#define SM4_XTS_VC22_KEY1_2_OFFSET 0x03e0
typedef struct _SM4_XTS_VC22_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC22_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC22_KEY1_2_t f;
} SM4_XTS_VC22_KEY1_2_u;

#define SM4_XTS_VC22_KEY1_3_OFFSET 0x03e4
typedef struct _SM4_XTS_VC22_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC22_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC22_KEY1_3_t f;
} SM4_XTS_VC22_KEY1_3_u;

#define SM4_XTS_VC22_KEY2_0_OFFSET 0x03e8
typedef struct _SM4_XTS_VC22_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC22_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC22_KEY2_0_t f;
} SM4_XTS_VC22_KEY2_0_u;

#define SM4_XTS_VC22_KEY2_1_OFFSET 0x03ec
typedef struct _SM4_XTS_VC22_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC22_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC22_KEY2_1_t f;
} SM4_XTS_VC22_KEY2_1_u;

#define SM4_XTS_VC22_KEY2_2_OFFSET 0x03f0
typedef struct _SM4_XTS_VC22_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC22_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC22_KEY2_2_t f;
} SM4_XTS_VC22_KEY2_2_u;

#define SM4_XTS_VC22_KEY2_3_OFFSET 0x03f4
typedef struct _SM4_XTS_VC22_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC22_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC22_KEY2_3_t f;
} SM4_XTS_VC22_KEY2_3_u;

#define SM4_XTS_VC23_DECRYPT_FORCE_OFFSET 0x03f8
typedef struct _SM4_XTS_VC23_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC23_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC23_DECRYPT_FORCE_t f;
} SM4_XTS_VC23_DECRYPT_FORCE_u;

#define SM4_XTS_VC23_INTEGRITY_FORCE_OFFSET 0x03fc
typedef struct _SM4_XTS_VC23_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC23_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC23_INTEGRITY_FORCE_t f;
} SM4_XTS_VC23_INTEGRITY_FORCE_u;

#define SM4_XTS_VC23_KEY_UPDATE_OFFSET 0x0400
typedef struct _SM4_XTS_VC23_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC23_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC23_KEY_UPDATE_t f;
} SM4_XTS_VC23_KEY_UPDATE_u;

#define SM4_XTS_VC23_KEY1_0_OFFSET 0x0404
typedef struct _SM4_XTS_VC23_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC23_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC23_KEY1_0_t f;
} SM4_XTS_VC23_KEY1_0_u;

#define SM4_XTS_VC23_KEY1_1_OFFSET 0x0408
typedef struct _SM4_XTS_VC23_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC23_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC23_KEY1_1_t f;
} SM4_XTS_VC23_KEY1_1_u;

#define SM4_XTS_VC23_KEY1_2_OFFSET 0x040c
typedef struct _SM4_XTS_VC23_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC23_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC23_KEY1_2_t f;
} SM4_XTS_VC23_KEY1_2_u;

#define SM4_XTS_VC23_KEY1_3_OFFSET 0x0410
typedef struct _SM4_XTS_VC23_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC23_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC23_KEY1_3_t f;
} SM4_XTS_VC23_KEY1_3_u;

#define SM4_XTS_VC23_KEY2_0_OFFSET 0x0414
typedef struct _SM4_XTS_VC23_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC23_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC23_KEY2_0_t f;
} SM4_XTS_VC23_KEY2_0_u;

#define SM4_XTS_VC23_KEY2_1_OFFSET 0x0418
typedef struct _SM4_XTS_VC23_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC23_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC23_KEY2_1_t f;
} SM4_XTS_VC23_KEY2_1_u;

#define SM4_XTS_VC23_KEY2_2_OFFSET 0x041c
typedef struct _SM4_XTS_VC23_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC23_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC23_KEY2_2_t f;
} SM4_XTS_VC23_KEY2_2_u;

#define SM4_XTS_VC23_KEY2_3_OFFSET 0x0420
typedef struct _SM4_XTS_VC23_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC23_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC23_KEY2_3_t f;
} SM4_XTS_VC23_KEY2_3_u;

#define SM4_XTS_VC24_DECRYPT_FORCE_OFFSET 0x0424
typedef struct _SM4_XTS_VC24_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC24_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC24_DECRYPT_FORCE_t f;
} SM4_XTS_VC24_DECRYPT_FORCE_u;

#define SM4_XTS_VC24_INTEGRITY_FORCE_OFFSET 0x0428
typedef struct _SM4_XTS_VC24_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC24_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC24_INTEGRITY_FORCE_t f;
} SM4_XTS_VC24_INTEGRITY_FORCE_u;

#define SM4_XTS_VC24_KEY_UPDATE_OFFSET 0x042c
typedef struct _SM4_XTS_VC24_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC24_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC24_KEY_UPDATE_t f;
} SM4_XTS_VC24_KEY_UPDATE_u;

#define SM4_XTS_VC24_KEY1_0_OFFSET 0x0430
typedef struct _SM4_XTS_VC24_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC24_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC24_KEY1_0_t f;
} SM4_XTS_VC24_KEY1_0_u;

#define SM4_XTS_VC24_KEY1_1_OFFSET 0x0434
typedef struct _SM4_XTS_VC24_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC24_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC24_KEY1_1_t f;
} SM4_XTS_VC24_KEY1_1_u;

#define SM4_XTS_VC24_KEY1_2_OFFSET 0x0438
typedef struct _SM4_XTS_VC24_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC24_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC24_KEY1_2_t f;
} SM4_XTS_VC24_KEY1_2_u;

#define SM4_XTS_VC24_KEY1_3_OFFSET 0x043c
typedef struct _SM4_XTS_VC24_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC24_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC24_KEY1_3_t f;
} SM4_XTS_VC24_KEY1_3_u;

#define SM4_XTS_VC24_KEY2_0_OFFSET 0x0440
typedef struct _SM4_XTS_VC24_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC24_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC24_KEY2_0_t f;
} SM4_XTS_VC24_KEY2_0_u;

#define SM4_XTS_VC24_KEY2_1_OFFSET 0x0444
typedef struct _SM4_XTS_VC24_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC24_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC24_KEY2_1_t f;
} SM4_XTS_VC24_KEY2_1_u;

#define SM4_XTS_VC24_KEY2_2_OFFSET 0x0448
typedef struct _SM4_XTS_VC24_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC24_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC24_KEY2_2_t f;
} SM4_XTS_VC24_KEY2_2_u;

#define SM4_XTS_VC24_KEY2_3_OFFSET 0x044c
typedef struct _SM4_XTS_VC24_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC24_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC24_KEY2_3_t f;
} SM4_XTS_VC24_KEY2_3_u;

#define SM4_XTS_VC25_DECRYPT_FORCE_OFFSET 0x0450
typedef struct _SM4_XTS_VC25_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC25_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC25_DECRYPT_FORCE_t f;
} SM4_XTS_VC25_DECRYPT_FORCE_u;

#define SM4_XTS_VC25_INTEGRITY_FORCE_OFFSET 0x0454
typedef struct _SM4_XTS_VC25_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC25_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC25_INTEGRITY_FORCE_t f;
} SM4_XTS_VC25_INTEGRITY_FORCE_u;

#define SM4_XTS_VC25_KEY_UPDATE_OFFSET 0x0458
typedef struct _SM4_XTS_VC25_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC25_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC25_KEY_UPDATE_t f;
} SM4_XTS_VC25_KEY_UPDATE_u;

#define SM4_XTS_VC25_KEY1_0_OFFSET 0x045c
typedef struct _SM4_XTS_VC25_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC25_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC25_KEY1_0_t f;
} SM4_XTS_VC25_KEY1_0_u;

#define SM4_XTS_VC25_KEY1_1_OFFSET 0x0460
typedef struct _SM4_XTS_VC25_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC25_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC25_KEY1_1_t f;
} SM4_XTS_VC25_KEY1_1_u;

#define SM4_XTS_VC25_KEY1_2_OFFSET 0x0464
typedef struct _SM4_XTS_VC25_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC25_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC25_KEY1_2_t f;
} SM4_XTS_VC25_KEY1_2_u;

#define SM4_XTS_VC25_KEY1_3_OFFSET 0x0468
typedef struct _SM4_XTS_VC25_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC25_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC25_KEY1_3_t f;
} SM4_XTS_VC25_KEY1_3_u;

#define SM4_XTS_VC25_KEY2_0_OFFSET 0x046c
typedef struct _SM4_XTS_VC25_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC25_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC25_KEY2_0_t f;
} SM4_XTS_VC25_KEY2_0_u;

#define SM4_XTS_VC25_KEY2_1_OFFSET 0x0470
typedef struct _SM4_XTS_VC25_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC25_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC25_KEY2_1_t f;
} SM4_XTS_VC25_KEY2_1_u;

#define SM4_XTS_VC25_KEY2_2_OFFSET 0x0474
typedef struct _SM4_XTS_VC25_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC25_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC25_KEY2_2_t f;
} SM4_XTS_VC25_KEY2_2_u;

#define SM4_XTS_VC25_KEY2_3_OFFSET 0x0478
typedef struct _SM4_XTS_VC25_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC25_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC25_KEY2_3_t f;
} SM4_XTS_VC25_KEY2_3_u;

#define SM4_XTS_VC26_DECRYPT_FORCE_OFFSET 0x047c
typedef struct _SM4_XTS_VC26_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC26_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC26_DECRYPT_FORCE_t f;
} SM4_XTS_VC26_DECRYPT_FORCE_u;

#define SM4_XTS_VC26_INTEGRITY_FORCE_OFFSET 0x0480
typedef struct _SM4_XTS_VC26_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC26_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC26_INTEGRITY_FORCE_t f;
} SM4_XTS_VC26_INTEGRITY_FORCE_u;

#define SM4_XTS_VC26_KEY_UPDATE_OFFSET 0x0484
typedef struct _SM4_XTS_VC26_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC26_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC26_KEY_UPDATE_t f;
} SM4_XTS_VC26_KEY_UPDATE_u;

#define SM4_XTS_VC26_KEY1_0_OFFSET 0x0488
typedef struct _SM4_XTS_VC26_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC26_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC26_KEY1_0_t f;
} SM4_XTS_VC26_KEY1_0_u;

#define SM4_XTS_VC26_KEY1_1_OFFSET 0x048c
typedef struct _SM4_XTS_VC26_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC26_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC26_KEY1_1_t f;
} SM4_XTS_VC26_KEY1_1_u;

#define SM4_XTS_VC26_KEY1_2_OFFSET 0x0490
typedef struct _SM4_XTS_VC26_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC26_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC26_KEY1_2_t f;
} SM4_XTS_VC26_KEY1_2_u;

#define SM4_XTS_VC26_KEY1_3_OFFSET 0x0494
typedef struct _SM4_XTS_VC26_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC26_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC26_KEY1_3_t f;
} SM4_XTS_VC26_KEY1_3_u;

#define SM4_XTS_VC26_KEY2_0_OFFSET 0x0498
typedef struct _SM4_XTS_VC26_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC26_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC26_KEY2_0_t f;
} SM4_XTS_VC26_KEY2_0_u;

#define SM4_XTS_VC26_KEY2_1_OFFSET 0x049c
typedef struct _SM4_XTS_VC26_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC26_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC26_KEY2_1_t f;
} SM4_XTS_VC26_KEY2_1_u;

#define SM4_XTS_VC26_KEY2_2_OFFSET 0x04a0
typedef struct _SM4_XTS_VC26_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC26_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC26_KEY2_2_t f;
} SM4_XTS_VC26_KEY2_2_u;

#define SM4_XTS_VC26_KEY2_3_OFFSET 0x04a4
typedef struct _SM4_XTS_VC26_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC26_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC26_KEY2_3_t f;
} SM4_XTS_VC26_KEY2_3_u;

#define SM4_XTS_VC27_DECRYPT_FORCE_OFFSET 0x04a8
typedef struct _SM4_XTS_VC27_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC27_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC27_DECRYPT_FORCE_t f;
} SM4_XTS_VC27_DECRYPT_FORCE_u;

#define SM4_XTS_VC27_INTEGRITY_FORCE_OFFSET 0x04ac
typedef struct _SM4_XTS_VC27_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC27_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC27_INTEGRITY_FORCE_t f;
} SM4_XTS_VC27_INTEGRITY_FORCE_u;

#define SM4_XTS_VC27_KEY_UPDATE_OFFSET 0x04b0
typedef struct _SM4_XTS_VC27_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC27_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC27_KEY_UPDATE_t f;
} SM4_XTS_VC27_KEY_UPDATE_u;

#define SM4_XTS_VC27_KEY1_0_OFFSET 0x04b4
typedef struct _SM4_XTS_VC27_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC27_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC27_KEY1_0_t f;
} SM4_XTS_VC27_KEY1_0_u;

#define SM4_XTS_VC27_KEY1_1_OFFSET 0x04b8
typedef struct _SM4_XTS_VC27_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC27_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC27_KEY1_1_t f;
} SM4_XTS_VC27_KEY1_1_u;

#define SM4_XTS_VC27_KEY1_2_OFFSET 0x04bc
typedef struct _SM4_XTS_VC27_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC27_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC27_KEY1_2_t f;
} SM4_XTS_VC27_KEY1_2_u;

#define SM4_XTS_VC27_KEY1_3_OFFSET 0x04c0
typedef struct _SM4_XTS_VC27_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC27_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC27_KEY1_3_t f;
} SM4_XTS_VC27_KEY1_3_u;

#define SM4_XTS_VC27_KEY2_0_OFFSET 0x04c4
typedef struct _SM4_XTS_VC27_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC27_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC27_KEY2_0_t f;
} SM4_XTS_VC27_KEY2_0_u;

#define SM4_XTS_VC27_KEY2_1_OFFSET 0x04c8
typedef struct _SM4_XTS_VC27_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC27_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC27_KEY2_1_t f;
} SM4_XTS_VC27_KEY2_1_u;

#define SM4_XTS_VC27_KEY2_2_OFFSET 0x04cc
typedef struct _SM4_XTS_VC27_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC27_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC27_KEY2_2_t f;
} SM4_XTS_VC27_KEY2_2_u;

#define SM4_XTS_VC27_KEY2_3_OFFSET 0x04d0
typedef struct _SM4_XTS_VC27_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC27_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC27_KEY2_3_t f;
} SM4_XTS_VC27_KEY2_3_u;

#define SM4_XTS_VC28_DECRYPT_FORCE_OFFSET 0x04d4
typedef struct _SM4_XTS_VC28_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC28_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC28_DECRYPT_FORCE_t f;
} SM4_XTS_VC28_DECRYPT_FORCE_u;

#define SM4_XTS_VC28_INTEGRITY_FORCE_OFFSET 0x04d8
typedef struct _SM4_XTS_VC28_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC28_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC28_INTEGRITY_FORCE_t f;
} SM4_XTS_VC28_INTEGRITY_FORCE_u;

#define SM4_XTS_VC28_KEY_UPDATE_OFFSET 0x04dc
typedef struct _SM4_XTS_VC28_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC28_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC28_KEY_UPDATE_t f;
} SM4_XTS_VC28_KEY_UPDATE_u;

#define SM4_XTS_VC28_KEY1_0_OFFSET 0x04e0
typedef struct _SM4_XTS_VC28_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC28_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC28_KEY1_0_t f;
} SM4_XTS_VC28_KEY1_0_u;

#define SM4_XTS_VC28_KEY1_1_OFFSET 0x04e4
typedef struct _SM4_XTS_VC28_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC28_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC28_KEY1_1_t f;
} SM4_XTS_VC28_KEY1_1_u;

#define SM4_XTS_VC28_KEY1_2_OFFSET 0x04e8
typedef struct _SM4_XTS_VC28_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC28_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC28_KEY1_2_t f;
} SM4_XTS_VC28_KEY1_2_u;

#define SM4_XTS_VC28_KEY1_3_OFFSET 0x04ec
typedef struct _SM4_XTS_VC28_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC28_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC28_KEY1_3_t f;
} SM4_XTS_VC28_KEY1_3_u;

#define SM4_XTS_VC28_KEY2_0_OFFSET 0x04f0
typedef struct _SM4_XTS_VC28_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC28_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC28_KEY2_0_t f;
} SM4_XTS_VC28_KEY2_0_u;

#define SM4_XTS_VC28_KEY2_1_OFFSET 0x04f4
typedef struct _SM4_XTS_VC28_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC28_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC28_KEY2_1_t f;
} SM4_XTS_VC28_KEY2_1_u;

#define SM4_XTS_VC28_KEY2_2_OFFSET 0x04f8
typedef struct _SM4_XTS_VC28_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC28_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC28_KEY2_2_t f;
} SM4_XTS_VC28_KEY2_2_u;

#define SM4_XTS_VC28_KEY2_3_OFFSET 0x04fc
typedef struct _SM4_XTS_VC28_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC28_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC28_KEY2_3_t f;
} SM4_XTS_VC28_KEY2_3_u;

#define SM4_XTS_VC29_DECRYPT_FORCE_OFFSET 0x0500
typedef struct _SM4_XTS_VC29_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC29_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC29_DECRYPT_FORCE_t f;
} SM4_XTS_VC29_DECRYPT_FORCE_u;

#define SM4_XTS_VC29_INTEGRITY_FORCE_OFFSET 0x0504
typedef struct _SM4_XTS_VC29_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC29_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC29_INTEGRITY_FORCE_t f;
} SM4_XTS_VC29_INTEGRITY_FORCE_u;

#define SM4_XTS_VC29_KEY_UPDATE_OFFSET 0x0508
typedef struct _SM4_XTS_VC29_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC29_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC29_KEY_UPDATE_t f;
} SM4_XTS_VC29_KEY_UPDATE_u;

#define SM4_XTS_VC29_KEY1_0_OFFSET 0x050c
typedef struct _SM4_XTS_VC29_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC29_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC29_KEY1_0_t f;
} SM4_XTS_VC29_KEY1_0_u;

#define SM4_XTS_VC29_KEY1_1_OFFSET 0x0510
typedef struct _SM4_XTS_VC29_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC29_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC29_KEY1_1_t f;
} SM4_XTS_VC29_KEY1_1_u;

#define SM4_XTS_VC29_KEY1_2_OFFSET 0x0514
typedef struct _SM4_XTS_VC29_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC29_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC29_KEY1_2_t f;
} SM4_XTS_VC29_KEY1_2_u;

#define SM4_XTS_VC29_KEY1_3_OFFSET 0x0518
typedef struct _SM4_XTS_VC29_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC29_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC29_KEY1_3_t f;
} SM4_XTS_VC29_KEY1_3_u;

#define SM4_XTS_VC29_KEY2_0_OFFSET 0x051c
typedef struct _SM4_XTS_VC29_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC29_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC29_KEY2_0_t f;
} SM4_XTS_VC29_KEY2_0_u;

#define SM4_XTS_VC29_KEY2_1_OFFSET 0x0520
typedef struct _SM4_XTS_VC29_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC29_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC29_KEY2_1_t f;
} SM4_XTS_VC29_KEY2_1_u;

#define SM4_XTS_VC29_KEY2_2_OFFSET 0x0524
typedef struct _SM4_XTS_VC29_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC29_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC29_KEY2_2_t f;
} SM4_XTS_VC29_KEY2_2_u;

#define SM4_XTS_VC29_KEY2_3_OFFSET 0x0528
typedef struct _SM4_XTS_VC29_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC29_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC29_KEY2_3_t f;
} SM4_XTS_VC29_KEY2_3_u;

#define SM4_XTS_VC30_DECRYPT_FORCE_OFFSET 0x052c
typedef struct _SM4_XTS_VC30_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC30_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC30_DECRYPT_FORCE_t f;
} SM4_XTS_VC30_DECRYPT_FORCE_u;

#define SM4_XTS_VC30_INTEGRITY_FORCE_OFFSET 0x0530
typedef struct _SM4_XTS_VC30_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC30_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC30_INTEGRITY_FORCE_t f;
} SM4_XTS_VC30_INTEGRITY_FORCE_u;

#define SM4_XTS_VC30_KEY_UPDATE_OFFSET 0x0534
typedef struct _SM4_XTS_VC30_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC30_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC30_KEY_UPDATE_t f;
} SM4_XTS_VC30_KEY_UPDATE_u;

#define SM4_XTS_VC30_KEY1_0_OFFSET 0x0538
typedef struct _SM4_XTS_VC30_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC30_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC30_KEY1_0_t f;
} SM4_XTS_VC30_KEY1_0_u;

#define SM4_XTS_VC30_KEY1_1_OFFSET 0x053c
typedef struct _SM4_XTS_VC30_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC30_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC30_KEY1_1_t f;
} SM4_XTS_VC30_KEY1_1_u;

#define SM4_XTS_VC30_KEY1_2_OFFSET 0x0540
typedef struct _SM4_XTS_VC30_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC30_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC30_KEY1_2_t f;
} SM4_XTS_VC30_KEY1_2_u;

#define SM4_XTS_VC30_KEY1_3_OFFSET 0x0544
typedef struct _SM4_XTS_VC30_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC30_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC30_KEY1_3_t f;
} SM4_XTS_VC30_KEY1_3_u;

#define SM4_XTS_VC30_KEY2_0_OFFSET 0x0548
typedef struct _SM4_XTS_VC30_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC30_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC30_KEY2_0_t f;
} SM4_XTS_VC30_KEY2_0_u;

#define SM4_XTS_VC30_KEY2_1_OFFSET 0x054c
typedef struct _SM4_XTS_VC30_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC30_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC30_KEY2_1_t f;
} SM4_XTS_VC30_KEY2_1_u;

#define SM4_XTS_VC30_KEY2_2_OFFSET 0x0550
typedef struct _SM4_XTS_VC30_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC30_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC30_KEY2_2_t f;
} SM4_XTS_VC30_KEY2_2_u;

#define SM4_XTS_VC30_KEY2_3_OFFSET 0x0554
typedef struct _SM4_XTS_VC30_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC30_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC30_KEY2_3_t f;
} SM4_XTS_VC30_KEY2_3_u;

#define SM4_XTS_VC31_DECRYPT_FORCE_OFFSET 0x0558
typedef struct _SM4_XTS_VC31_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC31_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC31_DECRYPT_FORCE_t f;
} SM4_XTS_VC31_DECRYPT_FORCE_u;

#define SM4_XTS_VC31_INTEGRITY_FORCE_OFFSET 0x055c
typedef struct _SM4_XTS_VC31_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC31_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC31_INTEGRITY_FORCE_t f;
} SM4_XTS_VC31_INTEGRITY_FORCE_u;

#define SM4_XTS_VC31_KEY_UPDATE_OFFSET 0x0560
typedef struct _SM4_XTS_VC31_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC31_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC31_KEY_UPDATE_t f;
} SM4_XTS_VC31_KEY_UPDATE_u;

#define SM4_XTS_VC31_KEY1_0_OFFSET 0x0564
typedef struct _SM4_XTS_VC31_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC31_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC31_KEY1_0_t f;
} SM4_XTS_VC31_KEY1_0_u;

#define SM4_XTS_VC31_KEY1_1_OFFSET 0x0568
typedef struct _SM4_XTS_VC31_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC31_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC31_KEY1_1_t f;
} SM4_XTS_VC31_KEY1_1_u;

#define SM4_XTS_VC31_KEY1_2_OFFSET 0x056c
typedef struct _SM4_XTS_VC31_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC31_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC31_KEY1_2_t f;
} SM4_XTS_VC31_KEY1_2_u;

#define SM4_XTS_VC31_KEY1_3_OFFSET 0x0570
typedef struct _SM4_XTS_VC31_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC31_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC31_KEY1_3_t f;
} SM4_XTS_VC31_KEY1_3_u;

#define SM4_XTS_VC31_KEY2_0_OFFSET 0x0574
typedef struct _SM4_XTS_VC31_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC31_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC31_KEY2_0_t f;
} SM4_XTS_VC31_KEY2_0_u;

#define SM4_XTS_VC31_KEY2_1_OFFSET 0x0578
typedef struct _SM4_XTS_VC31_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC31_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC31_KEY2_1_t f;
} SM4_XTS_VC31_KEY2_1_u;

#define SM4_XTS_VC31_KEY2_2_OFFSET 0x057c
typedef struct _SM4_XTS_VC31_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC31_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC31_KEY2_2_t f;
} SM4_XTS_VC31_KEY2_2_u;

#define SM4_XTS_VC31_KEY2_3_OFFSET 0x0580
typedef struct _SM4_XTS_VC31_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC31_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC31_KEY2_3_t f;
} SM4_XTS_VC31_KEY2_3_u;

#define SM4_XTS_VC32_DECRYPT_FORCE_OFFSET 0x0584
typedef struct _SM4_XTS_VC32_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC32_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC32_DECRYPT_FORCE_t f;
} SM4_XTS_VC32_DECRYPT_FORCE_u;

#define SM4_XTS_VC32_INTEGRITY_FORCE_OFFSET 0x0588
typedef struct _SM4_XTS_VC32_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC32_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC32_INTEGRITY_FORCE_t f;
} SM4_XTS_VC32_INTEGRITY_FORCE_u;

#define SM4_XTS_VC32_KEY_UPDATE_OFFSET 0x058c
typedef struct _SM4_XTS_VC32_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC32_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC32_KEY_UPDATE_t f;
} SM4_XTS_VC32_KEY_UPDATE_u;

#define SM4_XTS_VC32_KEY1_0_OFFSET 0x0590
typedef struct _SM4_XTS_VC32_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC32_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC32_KEY1_0_t f;
} SM4_XTS_VC32_KEY1_0_u;

#define SM4_XTS_VC32_KEY1_1_OFFSET 0x0594
typedef struct _SM4_XTS_VC32_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC32_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC32_KEY1_1_t f;
} SM4_XTS_VC32_KEY1_1_u;

#define SM4_XTS_VC32_KEY1_2_OFFSET 0x0598
typedef struct _SM4_XTS_VC32_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC32_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC32_KEY1_2_t f;
} SM4_XTS_VC32_KEY1_2_u;

#define SM4_XTS_VC32_KEY1_3_OFFSET 0x059c
typedef struct _SM4_XTS_VC32_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC32_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC32_KEY1_3_t f;
} SM4_XTS_VC32_KEY1_3_u;

#define SM4_XTS_VC32_KEY2_0_OFFSET 0x05a0
typedef struct _SM4_XTS_VC32_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC32_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC32_KEY2_0_t f;
} SM4_XTS_VC32_KEY2_0_u;

#define SM4_XTS_VC32_KEY2_1_OFFSET 0x05a4
typedef struct _SM4_XTS_VC32_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC32_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC32_KEY2_1_t f;
} SM4_XTS_VC32_KEY2_1_u;

#define SM4_XTS_VC32_KEY2_2_OFFSET 0x05a8
typedef struct _SM4_XTS_VC32_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC32_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC32_KEY2_2_t f;
} SM4_XTS_VC32_KEY2_2_u;

#define SM4_XTS_VC32_KEY2_3_OFFSET 0x05ac
typedef struct _SM4_XTS_VC32_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC32_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC32_KEY2_3_t f;
} SM4_XTS_VC32_KEY2_3_u;

#define SM4_XTS_VC33_DECRYPT_FORCE_OFFSET 0x05b0
typedef struct _SM4_XTS_VC33_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC33_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC33_DECRYPT_FORCE_t f;
} SM4_XTS_VC33_DECRYPT_FORCE_u;

#define SM4_XTS_VC33_INTEGRITY_FORCE_OFFSET 0x05b4
typedef struct _SM4_XTS_VC33_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC33_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC33_INTEGRITY_FORCE_t f;
} SM4_XTS_VC33_INTEGRITY_FORCE_u;

#define SM4_XTS_VC33_KEY_UPDATE_OFFSET 0x05b8
typedef struct _SM4_XTS_VC33_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC33_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC33_KEY_UPDATE_t f;
} SM4_XTS_VC33_KEY_UPDATE_u;

#define SM4_XTS_VC33_KEY1_0_OFFSET 0x05bc
typedef struct _SM4_XTS_VC33_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC33_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC33_KEY1_0_t f;
} SM4_XTS_VC33_KEY1_0_u;

#define SM4_XTS_VC33_KEY1_1_OFFSET 0x05c0
typedef struct _SM4_XTS_VC33_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC33_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC33_KEY1_1_t f;
} SM4_XTS_VC33_KEY1_1_u;

#define SM4_XTS_VC33_KEY1_2_OFFSET 0x05c4
typedef struct _SM4_XTS_VC33_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC33_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC33_KEY1_2_t f;
} SM4_XTS_VC33_KEY1_2_u;

#define SM4_XTS_VC33_KEY1_3_OFFSET 0x05c8
typedef struct _SM4_XTS_VC33_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC33_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC33_KEY1_3_t f;
} SM4_XTS_VC33_KEY1_3_u;

#define SM4_XTS_VC33_KEY2_0_OFFSET 0x05cc
typedef struct _SM4_XTS_VC33_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC33_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC33_KEY2_0_t f;
} SM4_XTS_VC33_KEY2_0_u;

#define SM4_XTS_VC33_KEY2_1_OFFSET 0x05d0
typedef struct _SM4_XTS_VC33_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC33_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC33_KEY2_1_t f;
} SM4_XTS_VC33_KEY2_1_u;

#define SM4_XTS_VC33_KEY2_2_OFFSET 0x05d4
typedef struct _SM4_XTS_VC33_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC33_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC33_KEY2_2_t f;
} SM4_XTS_VC33_KEY2_2_u;

#define SM4_XTS_VC33_KEY2_3_OFFSET 0x05d8
typedef struct _SM4_XTS_VC33_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC33_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC33_KEY2_3_t f;
} SM4_XTS_VC33_KEY2_3_u;

#define SM4_XTS_VC34_DECRYPT_FORCE_OFFSET 0x05dc
typedef struct _SM4_XTS_VC34_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC34_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC34_DECRYPT_FORCE_t f;
} SM4_XTS_VC34_DECRYPT_FORCE_u;

#define SM4_XTS_VC34_INTEGRITY_FORCE_OFFSET 0x05e0
typedef struct _SM4_XTS_VC34_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC34_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC34_INTEGRITY_FORCE_t f;
} SM4_XTS_VC34_INTEGRITY_FORCE_u;

#define SM4_XTS_VC34_KEY_UPDATE_OFFSET 0x05e4
typedef struct _SM4_XTS_VC34_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC34_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC34_KEY_UPDATE_t f;
} SM4_XTS_VC34_KEY_UPDATE_u;

#define SM4_XTS_VC34_KEY1_0_OFFSET 0x05e8
typedef struct _SM4_XTS_VC34_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC34_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC34_KEY1_0_t f;
} SM4_XTS_VC34_KEY1_0_u;

#define SM4_XTS_VC34_KEY1_1_OFFSET 0x05ec
typedef struct _SM4_XTS_VC34_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC34_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC34_KEY1_1_t f;
} SM4_XTS_VC34_KEY1_1_u;

#define SM4_XTS_VC34_KEY1_2_OFFSET 0x05f0
typedef struct _SM4_XTS_VC34_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC34_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC34_KEY1_2_t f;
} SM4_XTS_VC34_KEY1_2_u;

#define SM4_XTS_VC34_KEY1_3_OFFSET 0x05f4
typedef struct _SM4_XTS_VC34_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC34_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC34_KEY1_3_t f;
} SM4_XTS_VC34_KEY1_3_u;

#define SM4_XTS_VC34_KEY2_0_OFFSET 0x05f8
typedef struct _SM4_XTS_VC34_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC34_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC34_KEY2_0_t f;
} SM4_XTS_VC34_KEY2_0_u;

#define SM4_XTS_VC34_KEY2_1_OFFSET 0x05fc
typedef struct _SM4_XTS_VC34_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC34_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC34_KEY2_1_t f;
} SM4_XTS_VC34_KEY2_1_u;

#define SM4_XTS_VC34_KEY2_2_OFFSET 0x0600
typedef struct _SM4_XTS_VC34_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC34_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC34_KEY2_2_t f;
} SM4_XTS_VC34_KEY2_2_u;

#define SM4_XTS_VC34_KEY2_3_OFFSET 0x0604
typedef struct _SM4_XTS_VC34_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC34_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC34_KEY2_3_t f;
} SM4_XTS_VC34_KEY2_3_u;

#define SM4_XTS_VC35_DECRYPT_FORCE_OFFSET 0x0608
typedef struct _SM4_XTS_VC35_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC35_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC35_DECRYPT_FORCE_t f;
} SM4_XTS_VC35_DECRYPT_FORCE_u;

#define SM4_XTS_VC35_INTEGRITY_FORCE_OFFSET 0x060c
typedef struct _SM4_XTS_VC35_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC35_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC35_INTEGRITY_FORCE_t f;
} SM4_XTS_VC35_INTEGRITY_FORCE_u;

#define SM4_XTS_VC35_KEY_UPDATE_OFFSET 0x0610
typedef struct _SM4_XTS_VC35_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC35_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC35_KEY_UPDATE_t f;
} SM4_XTS_VC35_KEY_UPDATE_u;

#define SM4_XTS_VC35_KEY1_0_OFFSET 0x0614
typedef struct _SM4_XTS_VC35_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC35_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC35_KEY1_0_t f;
} SM4_XTS_VC35_KEY1_0_u;

#define SM4_XTS_VC35_KEY1_1_OFFSET 0x0618
typedef struct _SM4_XTS_VC35_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC35_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC35_KEY1_1_t f;
} SM4_XTS_VC35_KEY1_1_u;

#define SM4_XTS_VC35_KEY1_2_OFFSET 0x061c
typedef struct _SM4_XTS_VC35_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC35_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC35_KEY1_2_t f;
} SM4_XTS_VC35_KEY1_2_u;

#define SM4_XTS_VC35_KEY1_3_OFFSET 0x0620
typedef struct _SM4_XTS_VC35_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC35_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC35_KEY1_3_t f;
} SM4_XTS_VC35_KEY1_3_u;

#define SM4_XTS_VC35_KEY2_0_OFFSET 0x0624
typedef struct _SM4_XTS_VC35_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC35_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC35_KEY2_0_t f;
} SM4_XTS_VC35_KEY2_0_u;

#define SM4_XTS_VC35_KEY2_1_OFFSET 0x0628
typedef struct _SM4_XTS_VC35_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC35_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC35_KEY2_1_t f;
} SM4_XTS_VC35_KEY2_1_u;

#define SM4_XTS_VC35_KEY2_2_OFFSET 0x062c
typedef struct _SM4_XTS_VC35_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC35_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC35_KEY2_2_t f;
} SM4_XTS_VC35_KEY2_2_u;

#define SM4_XTS_VC35_KEY2_3_OFFSET 0x0630
typedef struct _SM4_XTS_VC35_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC35_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC35_KEY2_3_t f;
} SM4_XTS_VC35_KEY2_3_u;

#define SM4_XTS_VC36_DECRYPT_FORCE_OFFSET 0x0634
typedef struct _SM4_XTS_VC36_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC36_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC36_DECRYPT_FORCE_t f;
} SM4_XTS_VC36_DECRYPT_FORCE_u;

#define SM4_XTS_VC36_INTEGRITY_FORCE_OFFSET 0x0638
typedef struct _SM4_XTS_VC36_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC36_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC36_INTEGRITY_FORCE_t f;
} SM4_XTS_VC36_INTEGRITY_FORCE_u;

#define SM4_XTS_VC36_KEY_UPDATE_OFFSET 0x063c
typedef struct _SM4_XTS_VC36_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC36_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC36_KEY_UPDATE_t f;
} SM4_XTS_VC36_KEY_UPDATE_u;

#define SM4_XTS_VC36_KEY1_0_OFFSET 0x0640
typedef struct _SM4_XTS_VC36_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC36_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC36_KEY1_0_t f;
} SM4_XTS_VC36_KEY1_0_u;

#define SM4_XTS_VC36_KEY1_1_OFFSET 0x0644
typedef struct _SM4_XTS_VC36_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC36_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC36_KEY1_1_t f;
} SM4_XTS_VC36_KEY1_1_u;

#define SM4_XTS_VC36_KEY1_2_OFFSET 0x0648
typedef struct _SM4_XTS_VC36_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC36_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC36_KEY1_2_t f;
} SM4_XTS_VC36_KEY1_2_u;

#define SM4_XTS_VC36_KEY1_3_OFFSET 0x064c
typedef struct _SM4_XTS_VC36_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC36_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC36_KEY1_3_t f;
} SM4_XTS_VC36_KEY1_3_u;

#define SM4_XTS_VC36_KEY2_0_OFFSET 0x0650
typedef struct _SM4_XTS_VC36_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC36_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC36_KEY2_0_t f;
} SM4_XTS_VC36_KEY2_0_u;

#define SM4_XTS_VC36_KEY2_1_OFFSET 0x0654
typedef struct _SM4_XTS_VC36_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC36_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC36_KEY2_1_t f;
} SM4_XTS_VC36_KEY2_1_u;

#define SM4_XTS_VC36_KEY2_2_OFFSET 0x0658
typedef struct _SM4_XTS_VC36_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC36_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC36_KEY2_2_t f;
} SM4_XTS_VC36_KEY2_2_u;

#define SM4_XTS_VC36_KEY2_3_OFFSET 0x065c
typedef struct _SM4_XTS_VC36_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC36_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC36_KEY2_3_t f;
} SM4_XTS_VC36_KEY2_3_u;

#define SM4_XTS_VC37_DECRYPT_FORCE_OFFSET 0x0660
typedef struct _SM4_XTS_VC37_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC37_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC37_DECRYPT_FORCE_t f;
} SM4_XTS_VC37_DECRYPT_FORCE_u;

#define SM4_XTS_VC37_INTEGRITY_FORCE_OFFSET 0x0664
typedef struct _SM4_XTS_VC37_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC37_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC37_INTEGRITY_FORCE_t f;
} SM4_XTS_VC37_INTEGRITY_FORCE_u;

#define SM4_XTS_VC37_KEY_UPDATE_OFFSET 0x0668
typedef struct _SM4_XTS_VC37_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC37_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC37_KEY_UPDATE_t f;
} SM4_XTS_VC37_KEY_UPDATE_u;

#define SM4_XTS_VC37_KEY1_0_OFFSET 0x066c
typedef struct _SM4_XTS_VC37_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC37_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC37_KEY1_0_t f;
} SM4_XTS_VC37_KEY1_0_u;

#define SM4_XTS_VC37_KEY1_1_OFFSET 0x0670
typedef struct _SM4_XTS_VC37_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC37_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC37_KEY1_1_t f;
} SM4_XTS_VC37_KEY1_1_u;

#define SM4_XTS_VC37_KEY1_2_OFFSET 0x0674
typedef struct _SM4_XTS_VC37_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC37_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC37_KEY1_2_t f;
} SM4_XTS_VC37_KEY1_2_u;

#define SM4_XTS_VC37_KEY1_3_OFFSET 0x0678
typedef struct _SM4_XTS_VC37_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC37_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC37_KEY1_3_t f;
} SM4_XTS_VC37_KEY1_3_u;

#define SM4_XTS_VC37_KEY2_0_OFFSET 0x067c
typedef struct _SM4_XTS_VC37_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC37_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC37_KEY2_0_t f;
} SM4_XTS_VC37_KEY2_0_u;

#define SM4_XTS_VC37_KEY2_1_OFFSET 0x0680
typedef struct _SM4_XTS_VC37_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC37_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC37_KEY2_1_t f;
} SM4_XTS_VC37_KEY2_1_u;

#define SM4_XTS_VC37_KEY2_2_OFFSET 0x0684
typedef struct _SM4_XTS_VC37_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC37_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC37_KEY2_2_t f;
} SM4_XTS_VC37_KEY2_2_u;

#define SM4_XTS_VC37_KEY2_3_OFFSET 0x0688
typedef struct _SM4_XTS_VC37_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC37_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC37_KEY2_3_t f;
} SM4_XTS_VC37_KEY2_3_u;

#define SM4_XTS_VC38_DECRYPT_FORCE_OFFSET 0x068c
typedef struct _SM4_XTS_VC38_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC38_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC38_DECRYPT_FORCE_t f;
} SM4_XTS_VC38_DECRYPT_FORCE_u;

#define SM4_XTS_VC38_INTEGRITY_FORCE_OFFSET 0x0690
typedef struct _SM4_XTS_VC38_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC38_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC38_INTEGRITY_FORCE_t f;
} SM4_XTS_VC38_INTEGRITY_FORCE_u;

#define SM4_XTS_VC38_KEY_UPDATE_OFFSET 0x0694
typedef struct _SM4_XTS_VC38_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC38_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC38_KEY_UPDATE_t f;
} SM4_XTS_VC38_KEY_UPDATE_u;

#define SM4_XTS_VC38_KEY1_0_OFFSET 0x0698
typedef struct _SM4_XTS_VC38_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC38_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC38_KEY1_0_t f;
} SM4_XTS_VC38_KEY1_0_u;

#define SM4_XTS_VC38_KEY1_1_OFFSET 0x069c
typedef struct _SM4_XTS_VC38_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC38_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC38_KEY1_1_t f;
} SM4_XTS_VC38_KEY1_1_u;

#define SM4_XTS_VC38_KEY1_2_OFFSET 0x06a0
typedef struct _SM4_XTS_VC38_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC38_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC38_KEY1_2_t f;
} SM4_XTS_VC38_KEY1_2_u;

#define SM4_XTS_VC38_KEY1_3_OFFSET 0x06a4
typedef struct _SM4_XTS_VC38_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC38_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC38_KEY1_3_t f;
} SM4_XTS_VC38_KEY1_3_u;

#define SM4_XTS_VC38_KEY2_0_OFFSET 0x06a8
typedef struct _SM4_XTS_VC38_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC38_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC38_KEY2_0_t f;
} SM4_XTS_VC38_KEY2_0_u;

#define SM4_XTS_VC38_KEY2_1_OFFSET 0x06ac
typedef struct _SM4_XTS_VC38_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC38_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC38_KEY2_1_t f;
} SM4_XTS_VC38_KEY2_1_u;

#define SM4_XTS_VC38_KEY2_2_OFFSET 0x06b0
typedef struct _SM4_XTS_VC38_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC38_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC38_KEY2_2_t f;
} SM4_XTS_VC38_KEY2_2_u;

#define SM4_XTS_VC38_KEY2_3_OFFSET 0x06b4
typedef struct _SM4_XTS_VC38_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC38_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC38_KEY2_3_t f;
} SM4_XTS_VC38_KEY2_3_u;

#define SM4_XTS_VC39_DECRYPT_FORCE_OFFSET 0x06b8
typedef struct _SM4_XTS_VC39_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC39_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC39_DECRYPT_FORCE_t f;
} SM4_XTS_VC39_DECRYPT_FORCE_u;

#define SM4_XTS_VC39_INTEGRITY_FORCE_OFFSET 0x06bc
typedef struct _SM4_XTS_VC39_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC39_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC39_INTEGRITY_FORCE_t f;
} SM4_XTS_VC39_INTEGRITY_FORCE_u;

#define SM4_XTS_VC39_KEY_UPDATE_OFFSET 0x06c0
typedef struct _SM4_XTS_VC39_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC39_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC39_KEY_UPDATE_t f;
} SM4_XTS_VC39_KEY_UPDATE_u;

#define SM4_XTS_VC39_KEY1_0_OFFSET 0x06c4
typedef struct _SM4_XTS_VC39_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC39_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC39_KEY1_0_t f;
} SM4_XTS_VC39_KEY1_0_u;

#define SM4_XTS_VC39_KEY1_1_OFFSET 0x06c8
typedef struct _SM4_XTS_VC39_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC39_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC39_KEY1_1_t f;
} SM4_XTS_VC39_KEY1_1_u;

#define SM4_XTS_VC39_KEY1_2_OFFSET 0x06cc
typedef struct _SM4_XTS_VC39_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC39_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC39_KEY1_2_t f;
} SM4_XTS_VC39_KEY1_2_u;

#define SM4_XTS_VC39_KEY1_3_OFFSET 0x06d0
typedef struct _SM4_XTS_VC39_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC39_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC39_KEY1_3_t f;
} SM4_XTS_VC39_KEY1_3_u;

#define SM4_XTS_VC39_KEY2_0_OFFSET 0x06d4
typedef struct _SM4_XTS_VC39_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC39_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC39_KEY2_0_t f;
} SM4_XTS_VC39_KEY2_0_u;

#define SM4_XTS_VC39_KEY2_1_OFFSET 0x06d8
typedef struct _SM4_XTS_VC39_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC39_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC39_KEY2_1_t f;
} SM4_XTS_VC39_KEY2_1_u;

#define SM4_XTS_VC39_KEY2_2_OFFSET 0x06dc
typedef struct _SM4_XTS_VC39_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC39_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC39_KEY2_2_t f;
} SM4_XTS_VC39_KEY2_2_u;

#define SM4_XTS_VC39_KEY2_3_OFFSET 0x06e0
typedef struct _SM4_XTS_VC39_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC39_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC39_KEY2_3_t f;
} SM4_XTS_VC39_KEY2_3_u;

#define SM4_XTS_VC40_DECRYPT_FORCE_OFFSET 0x06e4
typedef struct _SM4_XTS_VC40_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC40_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC40_DECRYPT_FORCE_t f;
} SM4_XTS_VC40_DECRYPT_FORCE_u;

#define SM4_XTS_VC40_INTEGRITY_FORCE_OFFSET 0x06e8
typedef struct _SM4_XTS_VC40_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC40_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC40_INTEGRITY_FORCE_t f;
} SM4_XTS_VC40_INTEGRITY_FORCE_u;

#define SM4_XTS_VC40_KEY_UPDATE_OFFSET 0x06ec
typedef struct _SM4_XTS_VC40_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC40_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC40_KEY_UPDATE_t f;
} SM4_XTS_VC40_KEY_UPDATE_u;

#define SM4_XTS_VC40_KEY1_0_OFFSET 0x06f0
typedef struct _SM4_XTS_VC40_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC40_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC40_KEY1_0_t f;
} SM4_XTS_VC40_KEY1_0_u;

#define SM4_XTS_VC40_KEY1_1_OFFSET 0x06f4
typedef struct _SM4_XTS_VC40_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC40_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC40_KEY1_1_t f;
} SM4_XTS_VC40_KEY1_1_u;

#define SM4_XTS_VC40_KEY1_2_OFFSET 0x06f8
typedef struct _SM4_XTS_VC40_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC40_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC40_KEY1_2_t f;
} SM4_XTS_VC40_KEY1_2_u;

#define SM4_XTS_VC40_KEY1_3_OFFSET 0x06fc
typedef struct _SM4_XTS_VC40_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC40_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC40_KEY1_3_t f;
} SM4_XTS_VC40_KEY1_3_u;

#define SM4_XTS_VC40_KEY2_0_OFFSET 0x0700
typedef struct _SM4_XTS_VC40_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC40_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC40_KEY2_0_t f;
} SM4_XTS_VC40_KEY2_0_u;

#define SM4_XTS_VC40_KEY2_1_OFFSET 0x0704
typedef struct _SM4_XTS_VC40_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC40_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC40_KEY2_1_t f;
} SM4_XTS_VC40_KEY2_1_u;

#define SM4_XTS_VC40_KEY2_2_OFFSET 0x0708
typedef struct _SM4_XTS_VC40_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC40_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC40_KEY2_2_t f;
} SM4_XTS_VC40_KEY2_2_u;

#define SM4_XTS_VC40_KEY2_3_OFFSET 0x070c
typedef struct _SM4_XTS_VC40_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC40_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC40_KEY2_3_t f;
} SM4_XTS_VC40_KEY2_3_u;

#define SM4_XTS_VC41_DECRYPT_FORCE_OFFSET 0x0710
typedef struct _SM4_XTS_VC41_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC41_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC41_DECRYPT_FORCE_t f;
} SM4_XTS_VC41_DECRYPT_FORCE_u;

#define SM4_XTS_VC41_INTEGRITY_FORCE_OFFSET 0x0714
typedef struct _SM4_XTS_VC41_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC41_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC41_INTEGRITY_FORCE_t f;
} SM4_XTS_VC41_INTEGRITY_FORCE_u;

#define SM4_XTS_VC41_KEY_UPDATE_OFFSET 0x0718
typedef struct _SM4_XTS_VC41_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC41_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC41_KEY_UPDATE_t f;
} SM4_XTS_VC41_KEY_UPDATE_u;

#define SM4_XTS_VC41_KEY1_0_OFFSET 0x071c
typedef struct _SM4_XTS_VC41_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC41_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC41_KEY1_0_t f;
} SM4_XTS_VC41_KEY1_0_u;

#define SM4_XTS_VC41_KEY1_1_OFFSET 0x0720
typedef struct _SM4_XTS_VC41_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC41_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC41_KEY1_1_t f;
} SM4_XTS_VC41_KEY1_1_u;

#define SM4_XTS_VC41_KEY1_2_OFFSET 0x0724
typedef struct _SM4_XTS_VC41_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC41_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC41_KEY1_2_t f;
} SM4_XTS_VC41_KEY1_2_u;

#define SM4_XTS_VC41_KEY1_3_OFFSET 0x0728
typedef struct _SM4_XTS_VC41_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC41_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC41_KEY1_3_t f;
} SM4_XTS_VC41_KEY1_3_u;

#define SM4_XTS_VC41_KEY2_0_OFFSET 0x072c
typedef struct _SM4_XTS_VC41_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC41_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC41_KEY2_0_t f;
} SM4_XTS_VC41_KEY2_0_u;

#define SM4_XTS_VC41_KEY2_1_OFFSET 0x0730
typedef struct _SM4_XTS_VC41_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC41_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC41_KEY2_1_t f;
} SM4_XTS_VC41_KEY2_1_u;

#define SM4_XTS_VC41_KEY2_2_OFFSET 0x0734
typedef struct _SM4_XTS_VC41_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC41_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC41_KEY2_2_t f;
} SM4_XTS_VC41_KEY2_2_u;

#define SM4_XTS_VC41_KEY2_3_OFFSET 0x0738
typedef struct _SM4_XTS_VC41_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC41_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC41_KEY2_3_t f;
} SM4_XTS_VC41_KEY2_3_u;

#define SM4_XTS_VC42_DECRYPT_FORCE_OFFSET 0x073c
typedef struct _SM4_XTS_VC42_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC42_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC42_DECRYPT_FORCE_t f;
} SM4_XTS_VC42_DECRYPT_FORCE_u;

#define SM4_XTS_VC42_INTEGRITY_FORCE_OFFSET 0x0740
typedef struct _SM4_XTS_VC42_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC42_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC42_INTEGRITY_FORCE_t f;
} SM4_XTS_VC42_INTEGRITY_FORCE_u;

#define SM4_XTS_VC42_KEY_UPDATE_OFFSET 0x0744
typedef struct _SM4_XTS_VC42_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC42_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC42_KEY_UPDATE_t f;
} SM4_XTS_VC42_KEY_UPDATE_u;

#define SM4_XTS_VC42_KEY1_0_OFFSET 0x0748
typedef struct _SM4_XTS_VC42_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC42_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC42_KEY1_0_t f;
} SM4_XTS_VC42_KEY1_0_u;

#define SM4_XTS_VC42_KEY1_1_OFFSET 0x074c
typedef struct _SM4_XTS_VC42_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC42_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC42_KEY1_1_t f;
} SM4_XTS_VC42_KEY1_1_u;

#define SM4_XTS_VC42_KEY1_2_OFFSET 0x0750
typedef struct _SM4_XTS_VC42_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC42_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC42_KEY1_2_t f;
} SM4_XTS_VC42_KEY1_2_u;

#define SM4_XTS_VC42_KEY1_3_OFFSET 0x0754
typedef struct _SM4_XTS_VC42_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC42_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC42_KEY1_3_t f;
} SM4_XTS_VC42_KEY1_3_u;

#define SM4_XTS_VC42_KEY2_0_OFFSET 0x0758
typedef struct _SM4_XTS_VC42_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC42_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC42_KEY2_0_t f;
} SM4_XTS_VC42_KEY2_0_u;

#define SM4_XTS_VC42_KEY2_1_OFFSET 0x075c
typedef struct _SM4_XTS_VC42_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC42_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC42_KEY2_1_t f;
} SM4_XTS_VC42_KEY2_1_u;

#define SM4_XTS_VC42_KEY2_2_OFFSET 0x0760
typedef struct _SM4_XTS_VC42_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC42_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC42_KEY2_2_t f;
} SM4_XTS_VC42_KEY2_2_u;

#define SM4_XTS_VC42_KEY2_3_OFFSET 0x0764
typedef struct _SM4_XTS_VC42_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC42_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC42_KEY2_3_t f;
} SM4_XTS_VC42_KEY2_3_u;

#define SM4_XTS_VC43_DECRYPT_FORCE_OFFSET 0x0768
typedef struct _SM4_XTS_VC43_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC43_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC43_DECRYPT_FORCE_t f;
} SM4_XTS_VC43_DECRYPT_FORCE_u;

#define SM4_XTS_VC43_INTEGRITY_FORCE_OFFSET 0x076c
typedef struct _SM4_XTS_VC43_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC43_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC43_INTEGRITY_FORCE_t f;
} SM4_XTS_VC43_INTEGRITY_FORCE_u;

#define SM4_XTS_VC43_KEY_UPDATE_OFFSET 0x0770
typedef struct _SM4_XTS_VC43_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC43_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC43_KEY_UPDATE_t f;
} SM4_XTS_VC43_KEY_UPDATE_u;

#define SM4_XTS_VC43_KEY1_0_OFFSET 0x0774
typedef struct _SM4_XTS_VC43_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC43_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC43_KEY1_0_t f;
} SM4_XTS_VC43_KEY1_0_u;

#define SM4_XTS_VC43_KEY1_1_OFFSET 0x0778
typedef struct _SM4_XTS_VC43_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC43_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC43_KEY1_1_t f;
} SM4_XTS_VC43_KEY1_1_u;

#define SM4_XTS_VC43_KEY1_2_OFFSET 0x077c
typedef struct _SM4_XTS_VC43_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC43_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC43_KEY1_2_t f;
} SM4_XTS_VC43_KEY1_2_u;

#define SM4_XTS_VC43_KEY1_3_OFFSET 0x0780
typedef struct _SM4_XTS_VC43_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC43_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC43_KEY1_3_t f;
} SM4_XTS_VC43_KEY1_3_u;

#define SM4_XTS_VC43_KEY2_0_OFFSET 0x0784
typedef struct _SM4_XTS_VC43_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC43_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC43_KEY2_0_t f;
} SM4_XTS_VC43_KEY2_0_u;

#define SM4_XTS_VC43_KEY2_1_OFFSET 0x0788
typedef struct _SM4_XTS_VC43_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC43_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC43_KEY2_1_t f;
} SM4_XTS_VC43_KEY2_1_u;

#define SM4_XTS_VC43_KEY2_2_OFFSET 0x078c
typedef struct _SM4_XTS_VC43_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC43_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC43_KEY2_2_t f;
} SM4_XTS_VC43_KEY2_2_u;

#define SM4_XTS_VC43_KEY2_3_OFFSET 0x0790
typedef struct _SM4_XTS_VC43_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC43_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC43_KEY2_3_t f;
} SM4_XTS_VC43_KEY2_3_u;

#define SM4_XTS_VC44_DECRYPT_FORCE_OFFSET 0x0794
typedef struct _SM4_XTS_VC44_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC44_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC44_DECRYPT_FORCE_t f;
} SM4_XTS_VC44_DECRYPT_FORCE_u;

#define SM4_XTS_VC44_INTEGRITY_FORCE_OFFSET 0x0798
typedef struct _SM4_XTS_VC44_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC44_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC44_INTEGRITY_FORCE_t f;
} SM4_XTS_VC44_INTEGRITY_FORCE_u;

#define SM4_XTS_VC44_KEY_UPDATE_OFFSET 0x079c
typedef struct _SM4_XTS_VC44_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC44_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC44_KEY_UPDATE_t f;
} SM4_XTS_VC44_KEY_UPDATE_u;

#define SM4_XTS_VC44_KEY1_0_OFFSET 0x07a0
typedef struct _SM4_XTS_VC44_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC44_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC44_KEY1_0_t f;
} SM4_XTS_VC44_KEY1_0_u;

#define SM4_XTS_VC44_KEY1_1_OFFSET 0x07a4
typedef struct _SM4_XTS_VC44_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC44_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC44_KEY1_1_t f;
} SM4_XTS_VC44_KEY1_1_u;

#define SM4_XTS_VC44_KEY1_2_OFFSET 0x07a8
typedef struct _SM4_XTS_VC44_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC44_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC44_KEY1_2_t f;
} SM4_XTS_VC44_KEY1_2_u;

#define SM4_XTS_VC44_KEY1_3_OFFSET 0x07ac
typedef struct _SM4_XTS_VC44_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC44_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC44_KEY1_3_t f;
} SM4_XTS_VC44_KEY1_3_u;

#define SM4_XTS_VC44_KEY2_0_OFFSET 0x07b0
typedef struct _SM4_XTS_VC44_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC44_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC44_KEY2_0_t f;
} SM4_XTS_VC44_KEY2_0_u;

#define SM4_XTS_VC44_KEY2_1_OFFSET 0x07b4
typedef struct _SM4_XTS_VC44_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC44_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC44_KEY2_1_t f;
} SM4_XTS_VC44_KEY2_1_u;

#define SM4_XTS_VC44_KEY2_2_OFFSET 0x07b8
typedef struct _SM4_XTS_VC44_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC44_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC44_KEY2_2_t f;
} SM4_XTS_VC44_KEY2_2_u;

#define SM4_XTS_VC44_KEY2_3_OFFSET 0x07bc
typedef struct _SM4_XTS_VC44_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC44_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC44_KEY2_3_t f;
} SM4_XTS_VC44_KEY2_3_u;

#define SM4_XTS_VC45_DECRYPT_FORCE_OFFSET 0x07c0
typedef struct _SM4_XTS_VC45_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC45_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC45_DECRYPT_FORCE_t f;
} SM4_XTS_VC45_DECRYPT_FORCE_u;

#define SM4_XTS_VC45_INTEGRITY_FORCE_OFFSET 0x07c4
typedef struct _SM4_XTS_VC45_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC45_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC45_INTEGRITY_FORCE_t f;
} SM4_XTS_VC45_INTEGRITY_FORCE_u;

#define SM4_XTS_VC45_KEY_UPDATE_OFFSET 0x07c8
typedef struct _SM4_XTS_VC45_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC45_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC45_KEY_UPDATE_t f;
} SM4_XTS_VC45_KEY_UPDATE_u;

#define SM4_XTS_VC45_KEY1_0_OFFSET 0x07cc
typedef struct _SM4_XTS_VC45_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC45_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC45_KEY1_0_t f;
} SM4_XTS_VC45_KEY1_0_u;

#define SM4_XTS_VC45_KEY1_1_OFFSET 0x07d0
typedef struct _SM4_XTS_VC45_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC45_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC45_KEY1_1_t f;
} SM4_XTS_VC45_KEY1_1_u;

#define SM4_XTS_VC45_KEY1_2_OFFSET 0x07d4
typedef struct _SM4_XTS_VC45_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC45_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC45_KEY1_2_t f;
} SM4_XTS_VC45_KEY1_2_u;

#define SM4_XTS_VC45_KEY1_3_OFFSET 0x07d8
typedef struct _SM4_XTS_VC45_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC45_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC45_KEY1_3_t f;
} SM4_XTS_VC45_KEY1_3_u;

#define SM4_XTS_VC45_KEY2_0_OFFSET 0x07dc
typedef struct _SM4_XTS_VC45_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC45_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC45_KEY2_0_t f;
} SM4_XTS_VC45_KEY2_0_u;

#define SM4_XTS_VC45_KEY2_1_OFFSET 0x07e0
typedef struct _SM4_XTS_VC45_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC45_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC45_KEY2_1_t f;
} SM4_XTS_VC45_KEY2_1_u;

#define SM4_XTS_VC45_KEY2_2_OFFSET 0x07e4
typedef struct _SM4_XTS_VC45_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC45_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC45_KEY2_2_t f;
} SM4_XTS_VC45_KEY2_2_u;

#define SM4_XTS_VC45_KEY2_3_OFFSET 0x07e8
typedef struct _SM4_XTS_VC45_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC45_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC45_KEY2_3_t f;
} SM4_XTS_VC45_KEY2_3_u;

#define SM4_XTS_VC46_DECRYPT_FORCE_OFFSET 0x07ec
typedef struct _SM4_XTS_VC46_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC46_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC46_DECRYPT_FORCE_t f;
} SM4_XTS_VC46_DECRYPT_FORCE_u;

#define SM4_XTS_VC46_INTEGRITY_FORCE_OFFSET 0x07f0
typedef struct _SM4_XTS_VC46_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC46_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC46_INTEGRITY_FORCE_t f;
} SM4_XTS_VC46_INTEGRITY_FORCE_u;

#define SM4_XTS_VC46_KEY_UPDATE_OFFSET 0x07f4
typedef struct _SM4_XTS_VC46_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC46_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC46_KEY_UPDATE_t f;
} SM4_XTS_VC46_KEY_UPDATE_u;

#define SM4_XTS_VC46_KEY1_0_OFFSET 0x07f8
typedef struct _SM4_XTS_VC46_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC46_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC46_KEY1_0_t f;
} SM4_XTS_VC46_KEY1_0_u;

#define SM4_XTS_VC46_KEY1_1_OFFSET 0x07fc
typedef struct _SM4_XTS_VC46_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC46_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC46_KEY1_1_t f;
} SM4_XTS_VC46_KEY1_1_u;

#define SM4_XTS_VC46_KEY1_2_OFFSET 0x0800
typedef struct _SM4_XTS_VC46_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC46_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC46_KEY1_2_t f;
} SM4_XTS_VC46_KEY1_2_u;

#define SM4_XTS_VC46_KEY1_3_OFFSET 0x0804
typedef struct _SM4_XTS_VC46_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC46_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC46_KEY1_3_t f;
} SM4_XTS_VC46_KEY1_3_u;

#define SM4_XTS_VC46_KEY2_0_OFFSET 0x0808
typedef struct _SM4_XTS_VC46_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC46_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC46_KEY2_0_t f;
} SM4_XTS_VC46_KEY2_0_u;

#define SM4_XTS_VC46_KEY2_1_OFFSET 0x080c
typedef struct _SM4_XTS_VC46_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC46_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC46_KEY2_1_t f;
} SM4_XTS_VC46_KEY2_1_u;

#define SM4_XTS_VC46_KEY2_2_OFFSET 0x0810
typedef struct _SM4_XTS_VC46_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC46_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC46_KEY2_2_t f;
} SM4_XTS_VC46_KEY2_2_u;

#define SM4_XTS_VC46_KEY2_3_OFFSET 0x0814
typedef struct _SM4_XTS_VC46_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC46_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC46_KEY2_3_t f;
} SM4_XTS_VC46_KEY2_3_u;

#define SM4_XTS_VC47_DECRYPT_FORCE_OFFSET 0x0818
typedef struct _SM4_XTS_VC47_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC47_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC47_DECRYPT_FORCE_t f;
} SM4_XTS_VC47_DECRYPT_FORCE_u;

#define SM4_XTS_VC47_INTEGRITY_FORCE_OFFSET 0x081c
typedef struct _SM4_XTS_VC47_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC47_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC47_INTEGRITY_FORCE_t f;
} SM4_XTS_VC47_INTEGRITY_FORCE_u;

#define SM4_XTS_VC47_KEY_UPDATE_OFFSET 0x0820
typedef struct _SM4_XTS_VC47_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC47_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC47_KEY_UPDATE_t f;
} SM4_XTS_VC47_KEY_UPDATE_u;

#define SM4_XTS_VC47_KEY1_0_OFFSET 0x0824
typedef struct _SM4_XTS_VC47_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC47_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC47_KEY1_0_t f;
} SM4_XTS_VC47_KEY1_0_u;

#define SM4_XTS_VC47_KEY1_1_OFFSET 0x0828
typedef struct _SM4_XTS_VC47_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC47_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC47_KEY1_1_t f;
} SM4_XTS_VC47_KEY1_1_u;

#define SM4_XTS_VC47_KEY1_2_OFFSET 0x082c
typedef struct _SM4_XTS_VC47_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC47_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC47_KEY1_2_t f;
} SM4_XTS_VC47_KEY1_2_u;

#define SM4_XTS_VC47_KEY1_3_OFFSET 0x0830
typedef struct _SM4_XTS_VC47_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC47_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC47_KEY1_3_t f;
} SM4_XTS_VC47_KEY1_3_u;

#define SM4_XTS_VC47_KEY2_0_OFFSET 0x0834
typedef struct _SM4_XTS_VC47_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC47_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC47_KEY2_0_t f;
} SM4_XTS_VC47_KEY2_0_u;

#define SM4_XTS_VC47_KEY2_1_OFFSET 0x0838
typedef struct _SM4_XTS_VC47_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC47_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC47_KEY2_1_t f;
} SM4_XTS_VC47_KEY2_1_u;

#define SM4_XTS_VC47_KEY2_2_OFFSET 0x083c
typedef struct _SM4_XTS_VC47_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC47_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC47_KEY2_2_t f;
} SM4_XTS_VC47_KEY2_2_u;

#define SM4_XTS_VC47_KEY2_3_OFFSET 0x0840
typedef struct _SM4_XTS_VC47_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC47_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC47_KEY2_3_t f;
} SM4_XTS_VC47_KEY2_3_u;

#define SM4_XTS_VC48_DECRYPT_FORCE_OFFSET 0x0844
typedef struct _SM4_XTS_VC48_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC48_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC48_DECRYPT_FORCE_t f;
} SM4_XTS_VC48_DECRYPT_FORCE_u;

#define SM4_XTS_VC48_INTEGRITY_FORCE_OFFSET 0x0848
typedef struct _SM4_XTS_VC48_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC48_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC48_INTEGRITY_FORCE_t f;
} SM4_XTS_VC48_INTEGRITY_FORCE_u;

#define SM4_XTS_VC48_KEY_UPDATE_OFFSET 0x084c
typedef struct _SM4_XTS_VC48_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC48_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC48_KEY_UPDATE_t f;
} SM4_XTS_VC48_KEY_UPDATE_u;

#define SM4_XTS_VC48_KEY1_0_OFFSET 0x0850
typedef struct _SM4_XTS_VC48_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC48_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC48_KEY1_0_t f;
} SM4_XTS_VC48_KEY1_0_u;

#define SM4_XTS_VC48_KEY1_1_OFFSET 0x0854
typedef struct _SM4_XTS_VC48_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC48_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC48_KEY1_1_t f;
} SM4_XTS_VC48_KEY1_1_u;

#define SM4_XTS_VC48_KEY1_2_OFFSET 0x0858
typedef struct _SM4_XTS_VC48_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC48_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC48_KEY1_2_t f;
} SM4_XTS_VC48_KEY1_2_u;

#define SM4_XTS_VC48_KEY1_3_OFFSET 0x085c
typedef struct _SM4_XTS_VC48_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC48_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC48_KEY1_3_t f;
} SM4_XTS_VC48_KEY1_3_u;

#define SM4_XTS_VC48_KEY2_0_OFFSET 0x0860
typedef struct _SM4_XTS_VC48_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC48_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC48_KEY2_0_t f;
} SM4_XTS_VC48_KEY2_0_u;

#define SM4_XTS_VC48_KEY2_1_OFFSET 0x0864
typedef struct _SM4_XTS_VC48_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC48_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC48_KEY2_1_t f;
} SM4_XTS_VC48_KEY2_1_u;

#define SM4_XTS_VC48_KEY2_2_OFFSET 0x0868
typedef struct _SM4_XTS_VC48_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC48_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC48_KEY2_2_t f;
} SM4_XTS_VC48_KEY2_2_u;

#define SM4_XTS_VC48_KEY2_3_OFFSET 0x086c
typedef struct _SM4_XTS_VC48_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC48_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC48_KEY2_3_t f;
} SM4_XTS_VC48_KEY2_3_u;

#define SM4_XTS_VC49_DECRYPT_FORCE_OFFSET 0x0870
typedef struct _SM4_XTS_VC49_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC49_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC49_DECRYPT_FORCE_t f;
} SM4_XTS_VC49_DECRYPT_FORCE_u;

#define SM4_XTS_VC49_INTEGRITY_FORCE_OFFSET 0x0874
typedef struct _SM4_XTS_VC49_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC49_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC49_INTEGRITY_FORCE_t f;
} SM4_XTS_VC49_INTEGRITY_FORCE_u;

#define SM4_XTS_VC49_KEY_UPDATE_OFFSET 0x0878
typedef struct _SM4_XTS_VC49_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC49_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC49_KEY_UPDATE_t f;
} SM4_XTS_VC49_KEY_UPDATE_u;

#define SM4_XTS_VC49_KEY1_0_OFFSET 0x087c
typedef struct _SM4_XTS_VC49_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC49_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC49_KEY1_0_t f;
} SM4_XTS_VC49_KEY1_0_u;

#define SM4_XTS_VC49_KEY1_1_OFFSET 0x0880
typedef struct _SM4_XTS_VC49_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC49_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC49_KEY1_1_t f;
} SM4_XTS_VC49_KEY1_1_u;

#define SM4_XTS_VC49_KEY1_2_OFFSET 0x0884
typedef struct _SM4_XTS_VC49_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC49_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC49_KEY1_2_t f;
} SM4_XTS_VC49_KEY1_2_u;

#define SM4_XTS_VC49_KEY1_3_OFFSET 0x0888
typedef struct _SM4_XTS_VC49_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC49_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC49_KEY1_3_t f;
} SM4_XTS_VC49_KEY1_3_u;

#define SM4_XTS_VC49_KEY2_0_OFFSET 0x088c
typedef struct _SM4_XTS_VC49_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC49_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC49_KEY2_0_t f;
} SM4_XTS_VC49_KEY2_0_u;

#define SM4_XTS_VC49_KEY2_1_OFFSET 0x0890
typedef struct _SM4_XTS_VC49_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC49_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC49_KEY2_1_t f;
} SM4_XTS_VC49_KEY2_1_u;

#define SM4_XTS_VC49_KEY2_2_OFFSET 0x0894
typedef struct _SM4_XTS_VC49_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC49_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC49_KEY2_2_t f;
} SM4_XTS_VC49_KEY2_2_u;

#define SM4_XTS_VC49_KEY2_3_OFFSET 0x0898
typedef struct _SM4_XTS_VC49_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC49_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC49_KEY2_3_t f;
} SM4_XTS_VC49_KEY2_3_u;

#define SM4_XTS_VC50_DECRYPT_FORCE_OFFSET 0x089c
typedef struct _SM4_XTS_VC50_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC50_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC50_DECRYPT_FORCE_t f;
} SM4_XTS_VC50_DECRYPT_FORCE_u;

#define SM4_XTS_VC50_INTEGRITY_FORCE_OFFSET 0x08a0
typedef struct _SM4_XTS_VC50_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC50_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC50_INTEGRITY_FORCE_t f;
} SM4_XTS_VC50_INTEGRITY_FORCE_u;

#define SM4_XTS_VC50_KEY_UPDATE_OFFSET 0x08a4
typedef struct _SM4_XTS_VC50_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC50_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC50_KEY_UPDATE_t f;
} SM4_XTS_VC50_KEY_UPDATE_u;

#define SM4_XTS_VC50_KEY1_0_OFFSET 0x08a8
typedef struct _SM4_XTS_VC50_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC50_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC50_KEY1_0_t f;
} SM4_XTS_VC50_KEY1_0_u;

#define SM4_XTS_VC50_KEY1_1_OFFSET 0x08ac
typedef struct _SM4_XTS_VC50_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC50_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC50_KEY1_1_t f;
} SM4_XTS_VC50_KEY1_1_u;

#define SM4_XTS_VC50_KEY1_2_OFFSET 0x08b0
typedef struct _SM4_XTS_VC50_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC50_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC50_KEY1_2_t f;
} SM4_XTS_VC50_KEY1_2_u;

#define SM4_XTS_VC50_KEY1_3_OFFSET 0x08b4
typedef struct _SM4_XTS_VC50_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC50_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC50_KEY1_3_t f;
} SM4_XTS_VC50_KEY1_3_u;

#define SM4_XTS_VC50_KEY2_0_OFFSET 0x08b8
typedef struct _SM4_XTS_VC50_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC50_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC50_KEY2_0_t f;
} SM4_XTS_VC50_KEY2_0_u;

#define SM4_XTS_VC50_KEY2_1_OFFSET 0x08bc
typedef struct _SM4_XTS_VC50_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC50_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC50_KEY2_1_t f;
} SM4_XTS_VC50_KEY2_1_u;

#define SM4_XTS_VC50_KEY2_2_OFFSET 0x08c0
typedef struct _SM4_XTS_VC50_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC50_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC50_KEY2_2_t f;
} SM4_XTS_VC50_KEY2_2_u;

#define SM4_XTS_VC50_KEY2_3_OFFSET 0x08c4
typedef struct _SM4_XTS_VC50_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC50_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC50_KEY2_3_t f;
} SM4_XTS_VC50_KEY2_3_u;

#define SM4_XTS_VC51_DECRYPT_FORCE_OFFSET 0x08c8
typedef struct _SM4_XTS_VC51_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC51_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC51_DECRYPT_FORCE_t f;
} SM4_XTS_VC51_DECRYPT_FORCE_u;

#define SM4_XTS_VC51_INTEGRITY_FORCE_OFFSET 0x08cc
typedef struct _SM4_XTS_VC51_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC51_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC51_INTEGRITY_FORCE_t f;
} SM4_XTS_VC51_INTEGRITY_FORCE_u;

#define SM4_XTS_VC51_KEY_UPDATE_OFFSET 0x08d0
typedef struct _SM4_XTS_VC51_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC51_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC51_KEY_UPDATE_t f;
} SM4_XTS_VC51_KEY_UPDATE_u;

#define SM4_XTS_VC51_KEY1_0_OFFSET 0x08d4
typedef struct _SM4_XTS_VC51_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC51_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC51_KEY1_0_t f;
} SM4_XTS_VC51_KEY1_0_u;

#define SM4_XTS_VC51_KEY1_1_OFFSET 0x08d8
typedef struct _SM4_XTS_VC51_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC51_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC51_KEY1_1_t f;
} SM4_XTS_VC51_KEY1_1_u;

#define SM4_XTS_VC51_KEY1_2_OFFSET 0x08dc
typedef struct _SM4_XTS_VC51_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC51_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC51_KEY1_2_t f;
} SM4_XTS_VC51_KEY1_2_u;

#define SM4_XTS_VC51_KEY1_3_OFFSET 0x08e0
typedef struct _SM4_XTS_VC51_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC51_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC51_KEY1_3_t f;
} SM4_XTS_VC51_KEY1_3_u;

#define SM4_XTS_VC51_KEY2_0_OFFSET 0x08e4
typedef struct _SM4_XTS_VC51_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC51_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC51_KEY2_0_t f;
} SM4_XTS_VC51_KEY2_0_u;

#define SM4_XTS_VC51_KEY2_1_OFFSET 0x08e8
typedef struct _SM4_XTS_VC51_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC51_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC51_KEY2_1_t f;
} SM4_XTS_VC51_KEY2_1_u;

#define SM4_XTS_VC51_KEY2_2_OFFSET 0x08ec
typedef struct _SM4_XTS_VC51_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC51_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC51_KEY2_2_t f;
} SM4_XTS_VC51_KEY2_2_u;

#define SM4_XTS_VC51_KEY2_3_OFFSET 0x08f0
typedef struct _SM4_XTS_VC51_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC51_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC51_KEY2_3_t f;
} SM4_XTS_VC51_KEY2_3_u;

#define SM4_XTS_VC52_DECRYPT_FORCE_OFFSET 0x08f4
typedef struct _SM4_XTS_VC52_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC52_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC52_DECRYPT_FORCE_t f;
} SM4_XTS_VC52_DECRYPT_FORCE_u;

#define SM4_XTS_VC52_INTEGRITY_FORCE_OFFSET 0x08f8
typedef struct _SM4_XTS_VC52_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC52_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC52_INTEGRITY_FORCE_t f;
} SM4_XTS_VC52_INTEGRITY_FORCE_u;

#define SM4_XTS_VC52_KEY_UPDATE_OFFSET 0x08fc
typedef struct _SM4_XTS_VC52_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC52_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC52_KEY_UPDATE_t f;
} SM4_XTS_VC52_KEY_UPDATE_u;

#define SM4_XTS_VC52_KEY1_0_OFFSET 0x0900
typedef struct _SM4_XTS_VC52_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC52_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC52_KEY1_0_t f;
} SM4_XTS_VC52_KEY1_0_u;

#define SM4_XTS_VC52_KEY1_1_OFFSET 0x0904
typedef struct _SM4_XTS_VC52_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC52_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC52_KEY1_1_t f;
} SM4_XTS_VC52_KEY1_1_u;

#define SM4_XTS_VC52_KEY1_2_OFFSET 0x0908
typedef struct _SM4_XTS_VC52_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC52_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC52_KEY1_2_t f;
} SM4_XTS_VC52_KEY1_2_u;

#define SM4_XTS_VC52_KEY1_3_OFFSET 0x090c
typedef struct _SM4_XTS_VC52_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC52_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC52_KEY1_3_t f;
} SM4_XTS_VC52_KEY1_3_u;

#define SM4_XTS_VC52_KEY2_0_OFFSET 0x0910
typedef struct _SM4_XTS_VC52_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC52_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC52_KEY2_0_t f;
} SM4_XTS_VC52_KEY2_0_u;

#define SM4_XTS_VC52_KEY2_1_OFFSET 0x0914
typedef struct _SM4_XTS_VC52_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC52_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC52_KEY2_1_t f;
} SM4_XTS_VC52_KEY2_1_u;

#define SM4_XTS_VC52_KEY2_2_OFFSET 0x0918
typedef struct _SM4_XTS_VC52_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC52_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC52_KEY2_2_t f;
} SM4_XTS_VC52_KEY2_2_u;

#define SM4_XTS_VC52_KEY2_3_OFFSET 0x091c
typedef struct _SM4_XTS_VC52_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC52_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC52_KEY2_3_t f;
} SM4_XTS_VC52_KEY2_3_u;

#define SM4_XTS_VC53_DECRYPT_FORCE_OFFSET 0x0920
typedef struct _SM4_XTS_VC53_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC53_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC53_DECRYPT_FORCE_t f;
} SM4_XTS_VC53_DECRYPT_FORCE_u;

#define SM4_XTS_VC53_INTEGRITY_FORCE_OFFSET 0x0924
typedef struct _SM4_XTS_VC53_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC53_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC53_INTEGRITY_FORCE_t f;
} SM4_XTS_VC53_INTEGRITY_FORCE_u;

#define SM4_XTS_VC53_KEY_UPDATE_OFFSET 0x0928
typedef struct _SM4_XTS_VC53_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC53_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC53_KEY_UPDATE_t f;
} SM4_XTS_VC53_KEY_UPDATE_u;

#define SM4_XTS_VC53_KEY1_0_OFFSET 0x092c
typedef struct _SM4_XTS_VC53_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC53_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC53_KEY1_0_t f;
} SM4_XTS_VC53_KEY1_0_u;

#define SM4_XTS_VC53_KEY1_1_OFFSET 0x0930
typedef struct _SM4_XTS_VC53_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC53_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC53_KEY1_1_t f;
} SM4_XTS_VC53_KEY1_1_u;

#define SM4_XTS_VC53_KEY1_2_OFFSET 0x0934
typedef struct _SM4_XTS_VC53_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC53_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC53_KEY1_2_t f;
} SM4_XTS_VC53_KEY1_2_u;

#define SM4_XTS_VC53_KEY1_3_OFFSET 0x0938
typedef struct _SM4_XTS_VC53_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC53_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC53_KEY1_3_t f;
} SM4_XTS_VC53_KEY1_3_u;

#define SM4_XTS_VC53_KEY2_0_OFFSET 0x093c
typedef struct _SM4_XTS_VC53_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC53_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC53_KEY2_0_t f;
} SM4_XTS_VC53_KEY2_0_u;

#define SM4_XTS_VC53_KEY2_1_OFFSET 0x0940
typedef struct _SM4_XTS_VC53_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC53_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC53_KEY2_1_t f;
} SM4_XTS_VC53_KEY2_1_u;

#define SM4_XTS_VC53_KEY2_2_OFFSET 0x0944
typedef struct _SM4_XTS_VC53_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC53_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC53_KEY2_2_t f;
} SM4_XTS_VC53_KEY2_2_u;

#define SM4_XTS_VC53_KEY2_3_OFFSET 0x0948
typedef struct _SM4_XTS_VC53_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC53_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC53_KEY2_3_t f;
} SM4_XTS_VC53_KEY2_3_u;

#define SM4_XTS_VC54_DECRYPT_FORCE_OFFSET 0x094c
typedef struct _SM4_XTS_VC54_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC54_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC54_DECRYPT_FORCE_t f;
} SM4_XTS_VC54_DECRYPT_FORCE_u;

#define SM4_XTS_VC54_INTEGRITY_FORCE_OFFSET 0x0950
typedef struct _SM4_XTS_VC54_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC54_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC54_INTEGRITY_FORCE_t f;
} SM4_XTS_VC54_INTEGRITY_FORCE_u;

#define SM4_XTS_VC54_KEY_UPDATE_OFFSET 0x0954
typedef struct _SM4_XTS_VC54_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC54_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC54_KEY_UPDATE_t f;
} SM4_XTS_VC54_KEY_UPDATE_u;

#define SM4_XTS_VC54_KEY1_0_OFFSET 0x0958
typedef struct _SM4_XTS_VC54_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC54_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC54_KEY1_0_t f;
} SM4_XTS_VC54_KEY1_0_u;

#define SM4_XTS_VC54_KEY1_1_OFFSET 0x095c
typedef struct _SM4_XTS_VC54_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC54_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC54_KEY1_1_t f;
} SM4_XTS_VC54_KEY1_1_u;

#define SM4_XTS_VC54_KEY1_2_OFFSET 0x0960
typedef struct _SM4_XTS_VC54_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC54_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC54_KEY1_2_t f;
} SM4_XTS_VC54_KEY1_2_u;

#define SM4_XTS_VC54_KEY1_3_OFFSET 0x0964
typedef struct _SM4_XTS_VC54_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC54_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC54_KEY1_3_t f;
} SM4_XTS_VC54_KEY1_3_u;

#define SM4_XTS_VC54_KEY2_0_OFFSET 0x0968
typedef struct _SM4_XTS_VC54_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC54_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC54_KEY2_0_t f;
} SM4_XTS_VC54_KEY2_0_u;

#define SM4_XTS_VC54_KEY2_1_OFFSET 0x096c
typedef struct _SM4_XTS_VC54_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC54_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC54_KEY2_1_t f;
} SM4_XTS_VC54_KEY2_1_u;

#define SM4_XTS_VC54_KEY2_2_OFFSET 0x0970
typedef struct _SM4_XTS_VC54_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC54_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC54_KEY2_2_t f;
} SM4_XTS_VC54_KEY2_2_u;

#define SM4_XTS_VC54_KEY2_3_OFFSET 0x0974
typedef struct _SM4_XTS_VC54_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC54_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC54_KEY2_3_t f;
} SM4_XTS_VC54_KEY2_3_u;

#define SM4_XTS_VC55_DECRYPT_FORCE_OFFSET 0x0978
typedef struct _SM4_XTS_VC55_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC55_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC55_DECRYPT_FORCE_t f;
} SM4_XTS_VC55_DECRYPT_FORCE_u;

#define SM4_XTS_VC55_INTEGRITY_FORCE_OFFSET 0x097c
typedef struct _SM4_XTS_VC55_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC55_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC55_INTEGRITY_FORCE_t f;
} SM4_XTS_VC55_INTEGRITY_FORCE_u;

#define SM4_XTS_VC55_KEY_UPDATE_OFFSET 0x0980
typedef struct _SM4_XTS_VC55_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC55_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC55_KEY_UPDATE_t f;
} SM4_XTS_VC55_KEY_UPDATE_u;

#define SM4_XTS_VC55_KEY1_0_OFFSET 0x0984
typedef struct _SM4_XTS_VC55_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC55_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC55_KEY1_0_t f;
} SM4_XTS_VC55_KEY1_0_u;

#define SM4_XTS_VC55_KEY1_1_OFFSET 0x0988
typedef struct _SM4_XTS_VC55_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC55_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC55_KEY1_1_t f;
} SM4_XTS_VC55_KEY1_1_u;

#define SM4_XTS_VC55_KEY1_2_OFFSET 0x098c
typedef struct _SM4_XTS_VC55_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC55_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC55_KEY1_2_t f;
} SM4_XTS_VC55_KEY1_2_u;

#define SM4_XTS_VC55_KEY1_3_OFFSET 0x0990
typedef struct _SM4_XTS_VC55_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC55_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC55_KEY1_3_t f;
} SM4_XTS_VC55_KEY1_3_u;

#define SM4_XTS_VC55_KEY2_0_OFFSET 0x0994
typedef struct _SM4_XTS_VC55_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC55_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC55_KEY2_0_t f;
} SM4_XTS_VC55_KEY2_0_u;

#define SM4_XTS_VC55_KEY2_1_OFFSET 0x0998
typedef struct _SM4_XTS_VC55_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC55_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC55_KEY2_1_t f;
} SM4_XTS_VC55_KEY2_1_u;

#define SM4_XTS_VC55_KEY2_2_OFFSET 0x099c
typedef struct _SM4_XTS_VC55_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC55_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC55_KEY2_2_t f;
} SM4_XTS_VC55_KEY2_2_u;

#define SM4_XTS_VC55_KEY2_3_OFFSET 0x09a0
typedef struct _SM4_XTS_VC55_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC55_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC55_KEY2_3_t f;
} SM4_XTS_VC55_KEY2_3_u;

#define SM4_XTS_VC56_DECRYPT_FORCE_OFFSET 0x09a4
typedef struct _SM4_XTS_VC56_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC56_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC56_DECRYPT_FORCE_t f;
} SM4_XTS_VC56_DECRYPT_FORCE_u;

#define SM4_XTS_VC56_INTEGRITY_FORCE_OFFSET 0x09a8
typedef struct _SM4_XTS_VC56_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC56_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC56_INTEGRITY_FORCE_t f;
} SM4_XTS_VC56_INTEGRITY_FORCE_u;

#define SM4_XTS_VC56_KEY_UPDATE_OFFSET 0x09ac
typedef struct _SM4_XTS_VC56_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC56_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC56_KEY_UPDATE_t f;
} SM4_XTS_VC56_KEY_UPDATE_u;

#define SM4_XTS_VC56_KEY1_0_OFFSET 0x09b0
typedef struct _SM4_XTS_VC56_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC56_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC56_KEY1_0_t f;
} SM4_XTS_VC56_KEY1_0_u;

#define SM4_XTS_VC56_KEY1_1_OFFSET 0x09b4
typedef struct _SM4_XTS_VC56_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC56_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC56_KEY1_1_t f;
} SM4_XTS_VC56_KEY1_1_u;

#define SM4_XTS_VC56_KEY1_2_OFFSET 0x09b8
typedef struct _SM4_XTS_VC56_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC56_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC56_KEY1_2_t f;
} SM4_XTS_VC56_KEY1_2_u;

#define SM4_XTS_VC56_KEY1_3_OFFSET 0x09bc
typedef struct _SM4_XTS_VC56_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC56_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC56_KEY1_3_t f;
} SM4_XTS_VC56_KEY1_3_u;

#define SM4_XTS_VC56_KEY2_0_OFFSET 0x09c0
typedef struct _SM4_XTS_VC56_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC56_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC56_KEY2_0_t f;
} SM4_XTS_VC56_KEY2_0_u;

#define SM4_XTS_VC56_KEY2_1_OFFSET 0x09c4
typedef struct _SM4_XTS_VC56_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC56_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC56_KEY2_1_t f;
} SM4_XTS_VC56_KEY2_1_u;

#define SM4_XTS_VC56_KEY2_2_OFFSET 0x09c8
typedef struct _SM4_XTS_VC56_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC56_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC56_KEY2_2_t f;
} SM4_XTS_VC56_KEY2_2_u;

#define SM4_XTS_VC56_KEY2_3_OFFSET 0x09cc
typedef struct _SM4_XTS_VC56_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC56_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC56_KEY2_3_t f;
} SM4_XTS_VC56_KEY2_3_u;

#define SM4_XTS_VC57_DECRYPT_FORCE_OFFSET 0x09d0
typedef struct _SM4_XTS_VC57_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC57_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC57_DECRYPT_FORCE_t f;
} SM4_XTS_VC57_DECRYPT_FORCE_u;

#define SM4_XTS_VC57_INTEGRITY_FORCE_OFFSET 0x09d4
typedef struct _SM4_XTS_VC57_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC57_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC57_INTEGRITY_FORCE_t f;
} SM4_XTS_VC57_INTEGRITY_FORCE_u;

#define SM4_XTS_VC57_KEY_UPDATE_OFFSET 0x09d8
typedef struct _SM4_XTS_VC57_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC57_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC57_KEY_UPDATE_t f;
} SM4_XTS_VC57_KEY_UPDATE_u;

#define SM4_XTS_VC57_KEY1_0_OFFSET 0x09dc
typedef struct _SM4_XTS_VC57_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC57_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC57_KEY1_0_t f;
} SM4_XTS_VC57_KEY1_0_u;

#define SM4_XTS_VC57_KEY1_1_OFFSET 0x09e0
typedef struct _SM4_XTS_VC57_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC57_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC57_KEY1_1_t f;
} SM4_XTS_VC57_KEY1_1_u;

#define SM4_XTS_VC57_KEY1_2_OFFSET 0x09e4
typedef struct _SM4_XTS_VC57_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC57_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC57_KEY1_2_t f;
} SM4_XTS_VC57_KEY1_2_u;

#define SM4_XTS_VC57_KEY1_3_OFFSET 0x09e8
typedef struct _SM4_XTS_VC57_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC57_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC57_KEY1_3_t f;
} SM4_XTS_VC57_KEY1_3_u;

#define SM4_XTS_VC57_KEY2_0_OFFSET 0x09ec
typedef struct _SM4_XTS_VC57_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC57_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC57_KEY2_0_t f;
} SM4_XTS_VC57_KEY2_0_u;

#define SM4_XTS_VC57_KEY2_1_OFFSET 0x09f0
typedef struct _SM4_XTS_VC57_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC57_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC57_KEY2_1_t f;
} SM4_XTS_VC57_KEY2_1_u;

#define SM4_XTS_VC57_KEY2_2_OFFSET 0x09f4
typedef struct _SM4_XTS_VC57_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC57_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC57_KEY2_2_t f;
} SM4_XTS_VC57_KEY2_2_u;

#define SM4_XTS_VC57_KEY2_3_OFFSET 0x09f8
typedef struct _SM4_XTS_VC57_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC57_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC57_KEY2_3_t f;
} SM4_XTS_VC57_KEY2_3_u;

#define SM4_XTS_VC58_DECRYPT_FORCE_OFFSET 0x09fc
typedef struct _SM4_XTS_VC58_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC58_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC58_DECRYPT_FORCE_t f;
} SM4_XTS_VC58_DECRYPT_FORCE_u;

#define SM4_XTS_VC58_INTEGRITY_FORCE_OFFSET 0x0a00
typedef struct _SM4_XTS_VC58_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC58_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC58_INTEGRITY_FORCE_t f;
} SM4_XTS_VC58_INTEGRITY_FORCE_u;

#define SM4_XTS_VC58_KEY_UPDATE_OFFSET 0x0a04
typedef struct _SM4_XTS_VC58_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC58_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC58_KEY_UPDATE_t f;
} SM4_XTS_VC58_KEY_UPDATE_u;

#define SM4_XTS_VC58_KEY1_0_OFFSET 0x0a08
typedef struct _SM4_XTS_VC58_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC58_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC58_KEY1_0_t f;
} SM4_XTS_VC58_KEY1_0_u;

#define SM4_XTS_VC58_KEY1_1_OFFSET 0x0a0c
typedef struct _SM4_XTS_VC58_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC58_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC58_KEY1_1_t f;
} SM4_XTS_VC58_KEY1_1_u;

#define SM4_XTS_VC58_KEY1_2_OFFSET 0x0a10
typedef struct _SM4_XTS_VC58_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC58_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC58_KEY1_2_t f;
} SM4_XTS_VC58_KEY1_2_u;

#define SM4_XTS_VC58_KEY1_3_OFFSET 0x0a14
typedef struct _SM4_XTS_VC58_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC58_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC58_KEY1_3_t f;
} SM4_XTS_VC58_KEY1_3_u;

#define SM4_XTS_VC58_KEY2_0_OFFSET 0x0a18
typedef struct _SM4_XTS_VC58_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC58_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC58_KEY2_0_t f;
} SM4_XTS_VC58_KEY2_0_u;

#define SM4_XTS_VC58_KEY2_1_OFFSET 0x0a1c
typedef struct _SM4_XTS_VC58_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC58_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC58_KEY2_1_t f;
} SM4_XTS_VC58_KEY2_1_u;

#define SM4_XTS_VC58_KEY2_2_OFFSET 0x0a20
typedef struct _SM4_XTS_VC58_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC58_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC58_KEY2_2_t f;
} SM4_XTS_VC58_KEY2_2_u;

#define SM4_XTS_VC58_KEY2_3_OFFSET 0x0a24
typedef struct _SM4_XTS_VC58_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC58_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC58_KEY2_3_t f;
} SM4_XTS_VC58_KEY2_3_u;

#define SM4_XTS_VC59_DECRYPT_FORCE_OFFSET 0x0a28
typedef struct _SM4_XTS_VC59_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC59_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC59_DECRYPT_FORCE_t f;
} SM4_XTS_VC59_DECRYPT_FORCE_u;

#define SM4_XTS_VC59_INTEGRITY_FORCE_OFFSET 0x0a2c
typedef struct _SM4_XTS_VC59_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC59_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC59_INTEGRITY_FORCE_t f;
} SM4_XTS_VC59_INTEGRITY_FORCE_u;

#define SM4_XTS_VC59_KEY_UPDATE_OFFSET 0x0a30
typedef struct _SM4_XTS_VC59_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC59_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC59_KEY_UPDATE_t f;
} SM4_XTS_VC59_KEY_UPDATE_u;

#define SM4_XTS_VC59_KEY1_0_OFFSET 0x0a34
typedef struct _SM4_XTS_VC59_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC59_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC59_KEY1_0_t f;
} SM4_XTS_VC59_KEY1_0_u;

#define SM4_XTS_VC59_KEY1_1_OFFSET 0x0a38
typedef struct _SM4_XTS_VC59_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC59_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC59_KEY1_1_t f;
} SM4_XTS_VC59_KEY1_1_u;

#define SM4_XTS_VC59_KEY1_2_OFFSET 0x0a3c
typedef struct _SM4_XTS_VC59_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC59_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC59_KEY1_2_t f;
} SM4_XTS_VC59_KEY1_2_u;

#define SM4_XTS_VC59_KEY1_3_OFFSET 0x0a40
typedef struct _SM4_XTS_VC59_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC59_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC59_KEY1_3_t f;
} SM4_XTS_VC59_KEY1_3_u;

#define SM4_XTS_VC59_KEY2_0_OFFSET 0x0a44
typedef struct _SM4_XTS_VC59_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC59_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC59_KEY2_0_t f;
} SM4_XTS_VC59_KEY2_0_u;

#define SM4_XTS_VC59_KEY2_1_OFFSET 0x0a48
typedef struct _SM4_XTS_VC59_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC59_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC59_KEY2_1_t f;
} SM4_XTS_VC59_KEY2_1_u;

#define SM4_XTS_VC59_KEY2_2_OFFSET 0x0a4c
typedef struct _SM4_XTS_VC59_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC59_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC59_KEY2_2_t f;
} SM4_XTS_VC59_KEY2_2_u;

#define SM4_XTS_VC59_KEY2_3_OFFSET 0x0a50
typedef struct _SM4_XTS_VC59_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC59_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC59_KEY2_3_t f;
} SM4_XTS_VC59_KEY2_3_u;

#define SM4_XTS_VC60_DECRYPT_FORCE_OFFSET 0x0a54
typedef struct _SM4_XTS_VC60_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC60_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC60_DECRYPT_FORCE_t f;
} SM4_XTS_VC60_DECRYPT_FORCE_u;

#define SM4_XTS_VC60_INTEGRITY_FORCE_OFFSET 0x0a58
typedef struct _SM4_XTS_VC60_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC60_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC60_INTEGRITY_FORCE_t f;
} SM4_XTS_VC60_INTEGRITY_FORCE_u;

#define SM4_XTS_VC60_KEY_UPDATE_OFFSET 0x0a5c
typedef struct _SM4_XTS_VC60_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC60_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC60_KEY_UPDATE_t f;
} SM4_XTS_VC60_KEY_UPDATE_u;

#define SM4_XTS_VC60_KEY1_0_OFFSET 0x0a60
typedef struct _SM4_XTS_VC60_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC60_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC60_KEY1_0_t f;
} SM4_XTS_VC60_KEY1_0_u;

#define SM4_XTS_VC60_KEY1_1_OFFSET 0x0a64
typedef struct _SM4_XTS_VC60_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC60_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC60_KEY1_1_t f;
} SM4_XTS_VC60_KEY1_1_u;

#define SM4_XTS_VC60_KEY1_2_OFFSET 0x0a68
typedef struct _SM4_XTS_VC60_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC60_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC60_KEY1_2_t f;
} SM4_XTS_VC60_KEY1_2_u;

#define SM4_XTS_VC60_KEY1_3_OFFSET 0x0a6c
typedef struct _SM4_XTS_VC60_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC60_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC60_KEY1_3_t f;
} SM4_XTS_VC60_KEY1_3_u;

#define SM4_XTS_VC60_KEY2_0_OFFSET 0x0a70
typedef struct _SM4_XTS_VC60_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC60_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC60_KEY2_0_t f;
} SM4_XTS_VC60_KEY2_0_u;

#define SM4_XTS_VC60_KEY2_1_OFFSET 0x0a74
typedef struct _SM4_XTS_VC60_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC60_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC60_KEY2_1_t f;
} SM4_XTS_VC60_KEY2_1_u;

#define SM4_XTS_VC60_KEY2_2_OFFSET 0x0a78
typedef struct _SM4_XTS_VC60_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC60_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC60_KEY2_2_t f;
} SM4_XTS_VC60_KEY2_2_u;

#define SM4_XTS_VC60_KEY2_3_OFFSET 0x0a7c
typedef struct _SM4_XTS_VC60_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC60_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC60_KEY2_3_t f;
} SM4_XTS_VC60_KEY2_3_u;

#define SM4_XTS_VC61_DECRYPT_FORCE_OFFSET 0x0a80
typedef struct _SM4_XTS_VC61_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC61_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC61_DECRYPT_FORCE_t f;
} SM4_XTS_VC61_DECRYPT_FORCE_u;

#define SM4_XTS_VC61_INTEGRITY_FORCE_OFFSET 0x0a84
typedef struct _SM4_XTS_VC61_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC61_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC61_INTEGRITY_FORCE_t f;
} SM4_XTS_VC61_INTEGRITY_FORCE_u;

#define SM4_XTS_VC61_KEY_UPDATE_OFFSET 0x0a88
typedef struct _SM4_XTS_VC61_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC61_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC61_KEY_UPDATE_t f;
} SM4_XTS_VC61_KEY_UPDATE_u;

#define SM4_XTS_VC61_KEY1_0_OFFSET 0x0a8c
typedef struct _SM4_XTS_VC61_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC61_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC61_KEY1_0_t f;
} SM4_XTS_VC61_KEY1_0_u;

#define SM4_XTS_VC61_KEY1_1_OFFSET 0x0a90
typedef struct _SM4_XTS_VC61_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC61_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC61_KEY1_1_t f;
} SM4_XTS_VC61_KEY1_1_u;

#define SM4_XTS_VC61_KEY1_2_OFFSET 0x0a94
typedef struct _SM4_XTS_VC61_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC61_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC61_KEY1_2_t f;
} SM4_XTS_VC61_KEY1_2_u;

#define SM4_XTS_VC61_KEY1_3_OFFSET 0x0a98
typedef struct _SM4_XTS_VC61_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC61_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC61_KEY1_3_t f;
} SM4_XTS_VC61_KEY1_3_u;

#define SM4_XTS_VC61_KEY2_0_OFFSET 0x0a9c
typedef struct _SM4_XTS_VC61_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC61_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC61_KEY2_0_t f;
} SM4_XTS_VC61_KEY2_0_u;

#define SM4_XTS_VC61_KEY2_1_OFFSET 0x0aa0
typedef struct _SM4_XTS_VC61_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC61_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC61_KEY2_1_t f;
} SM4_XTS_VC61_KEY2_1_u;

#define SM4_XTS_VC61_KEY2_2_OFFSET 0x0aa4
typedef struct _SM4_XTS_VC61_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC61_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC61_KEY2_2_t f;
} SM4_XTS_VC61_KEY2_2_u;

#define SM4_XTS_VC61_KEY2_3_OFFSET 0x0aa8
typedef struct _SM4_XTS_VC61_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC61_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC61_KEY2_3_t f;
} SM4_XTS_VC61_KEY2_3_u;

#define SM4_XTS_VC62_DECRYPT_FORCE_OFFSET 0x0aac
typedef struct _SM4_XTS_VC62_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC62_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC62_DECRYPT_FORCE_t f;
} SM4_XTS_VC62_DECRYPT_FORCE_u;

#define SM4_XTS_VC62_INTEGRITY_FORCE_OFFSET 0x0ab0
typedef struct _SM4_XTS_VC62_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC62_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC62_INTEGRITY_FORCE_t f;
} SM4_XTS_VC62_INTEGRITY_FORCE_u;

#define SM4_XTS_VC62_KEY_UPDATE_OFFSET 0x0ab4
typedef struct _SM4_XTS_VC62_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC62_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC62_KEY_UPDATE_t f;
} SM4_XTS_VC62_KEY_UPDATE_u;

#define SM4_XTS_VC62_KEY1_0_OFFSET 0x0ab8
typedef struct _SM4_XTS_VC62_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC62_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC62_KEY1_0_t f;
} SM4_XTS_VC62_KEY1_0_u;

#define SM4_XTS_VC62_KEY1_1_OFFSET 0x0abc
typedef struct _SM4_XTS_VC62_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC62_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC62_KEY1_1_t f;
} SM4_XTS_VC62_KEY1_1_u;

#define SM4_XTS_VC62_KEY1_2_OFFSET 0x0ac0
typedef struct _SM4_XTS_VC62_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC62_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC62_KEY1_2_t f;
} SM4_XTS_VC62_KEY1_2_u;

#define SM4_XTS_VC62_KEY1_3_OFFSET 0x0ac4
typedef struct _SM4_XTS_VC62_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC62_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC62_KEY1_3_t f;
} SM4_XTS_VC62_KEY1_3_u;

#define SM4_XTS_VC62_KEY2_0_OFFSET 0x0ac8
typedef struct _SM4_XTS_VC62_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC62_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC62_KEY2_0_t f;
} SM4_XTS_VC62_KEY2_0_u;

#define SM4_XTS_VC62_KEY2_1_OFFSET 0x0acc
typedef struct _SM4_XTS_VC62_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC62_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC62_KEY2_1_t f;
} SM4_XTS_VC62_KEY2_1_u;

#define SM4_XTS_VC62_KEY2_2_OFFSET 0x0ad0
typedef struct _SM4_XTS_VC62_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC62_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC62_KEY2_2_t f;
} SM4_XTS_VC62_KEY2_2_u;

#define SM4_XTS_VC62_KEY2_3_OFFSET 0x0ad4
typedef struct _SM4_XTS_VC62_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC62_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC62_KEY2_3_t f;
} SM4_XTS_VC62_KEY2_3_u;

#define SM4_XTS_VC63_DECRYPT_FORCE_OFFSET 0x0ad8
typedef struct _SM4_XTS_VC63_DECRYPT_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC63_DECRYPT_FORCE_t;

typedef union {
    unsigned int                 val : 32;
    SM4_XTS_VC63_DECRYPT_FORCE_t f;
} SM4_XTS_VC63_DECRYPT_FORCE_u;

#define SM4_XTS_VC63_INTEGRITY_FORCE_OFFSET 0x0adc
typedef struct _SM4_XTS_VC63_INTEGRITY_FORCE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC63_INTEGRITY_FORCE_t;

typedef union {
    unsigned int                   val : 32;
    SM4_XTS_VC63_INTEGRITY_FORCE_t f;
} SM4_XTS_VC63_INTEGRITY_FORCE_u;

#define SM4_XTS_VC63_KEY_UPDATE_OFFSET 0x0ae0
typedef struct _SM4_XTS_VC63_KEY_UPDATE_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int EN : 1;
    unsigned int : 7;
    unsigned int DONE : 1;
    unsigned int : 23;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 23;
    unsigned int DONE : 1;
    unsigned int : 7;
    unsigned int EN : 1;
#endif
} SM4_XTS_VC63_KEY_UPDATE_t;

typedef union {
    unsigned int              val : 32;
    SM4_XTS_VC63_KEY_UPDATE_t f;
} SM4_XTS_VC63_KEY_UPDATE_u;

#define SM4_XTS_VC63_KEY1_0_OFFSET 0x0ae4
typedef struct _SM4_XTS_VC63_KEY1_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC63_KEY1_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC63_KEY1_0_t f;
} SM4_XTS_VC63_KEY1_0_u;

#define SM4_XTS_VC63_KEY1_1_OFFSET 0x0ae8
typedef struct _SM4_XTS_VC63_KEY1_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC63_KEY1_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC63_KEY1_1_t f;
} SM4_XTS_VC63_KEY1_1_u;

#define SM4_XTS_VC63_KEY1_2_OFFSET 0x0aec
typedef struct _SM4_XTS_VC63_KEY1_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC63_KEY1_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC63_KEY1_2_t f;
} SM4_XTS_VC63_KEY1_2_u;

#define SM4_XTS_VC63_KEY1_3_OFFSET 0x0af0
typedef struct _SM4_XTS_VC63_KEY1_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC63_KEY1_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC63_KEY1_3_t f;
} SM4_XTS_VC63_KEY1_3_u;

#define SM4_XTS_VC63_KEY2_0_OFFSET 0x0af4
typedef struct _SM4_XTS_VC63_KEY2_0_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC63_KEY2_0_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC63_KEY2_0_t f;
} SM4_XTS_VC63_KEY2_0_u;

#define SM4_XTS_VC63_KEY2_1_OFFSET 0x0af8
typedef struct _SM4_XTS_VC63_KEY2_1_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC63_KEY2_1_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC63_KEY2_1_t f;
} SM4_XTS_VC63_KEY2_1_u;

#define SM4_XTS_VC63_KEY2_2_OFFSET 0x0afc
typedef struct _SM4_XTS_VC63_KEY2_2_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC63_KEY2_2_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC63_KEY2_2_t f;
} SM4_XTS_VC63_KEY2_2_u;

#define SM4_XTS_VC63_KEY2_3_OFFSET 0x0b00
typedef struct _SM4_XTS_VC63_KEY2_3_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int KEY : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int KEY : 32;
#endif
} SM4_XTS_VC63_KEY2_3_t;

typedef union {
    unsigned int          val : 32;
    SM4_XTS_VC63_KEY2_3_t f;
} SM4_XTS_VC63_KEY2_3_u;

#define SM4_XTS_INT_CTRL_OFFSET 0x0b08
typedef struct _SM4_XTS_INT_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int CHECKSUM_FAIL_INT_EN : 1;
    unsigned int TO_ODTE_RAS_INT_EN : 1;
    unsigned int : 30;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 30;
    unsigned int TO_ODTE_RAS_INT_EN : 1;
    unsigned int CHECKSUM_FAIL_INT_EN : 1;
#endif
} SM4_XTS_INT_CTRL_t;

typedef union {
    unsigned int       val : 32;
    SM4_XTS_INT_CTRL_t f;
} SM4_XTS_INT_CTRL_u;

#define SM4_XTS_CHECKSUM_FAIL_INT_OFFSET 0x0b0c
typedef struct _SM4_XTS_CHECKSUM_FAIL_INT_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SM4_XTS_CHECKSUM_FAIL_INT : 1;
    unsigned int : 31;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int : 31;
    unsigned int SM4_XTS_CHECKSUM_FAIL_INT : 1;
#endif
} SM4_XTS_CHECKSUM_FAIL_INT_t;

typedef union {
    unsigned int                val : 32;
    SM4_XTS_CHECKSUM_FAIL_INT_t f;
} SM4_XTS_CHECKSUM_FAIL_INT_u;

#define SM4_XTS_CHECKSUM_FAIL_DEBUG_FIFO_CTRL_OFFSET 0x0b10
typedef struct _SM4_XTS_CHECKSUM_FAIL_DEBUG_FIFO_CTRL_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SM4_XTS_CHECKSUM_FAIL_DEBUG_FIFO_POP : 1;
    unsigned int : 7;
    unsigned int SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_NUM : 8;
    unsigned int : 15;
    unsigned int SM4_XTS_CHECKSUM_FAIL_DEBUG_FIFO_FLUSH : 1;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SM4_XTS_CHECKSUM_FAIL_DEBUG_FIFO_FLUSH : 1;
    unsigned int : 15;
    unsigned int SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_NUM : 8;
    unsigned int : 7;
    unsigned int SM4_XTS_CHECKSUM_FAIL_DEBUG_FIFO_POP : 1;
#endif
} SM4_XTS_CHECKSUM_FAIL_DEBUG_FIFO_CTRL_t;

typedef union {
    unsigned int                            val : 32;
    SM4_XTS_CHECKSUM_FAIL_DEBUG_FIFO_CTRL_t f;
} SM4_XTS_CHECKSUM_FAIL_DEBUG_FIFO_CTRL_u;

#define SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_LOW_OFFSET 0x0b14
typedef struct _SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_LOW_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_LOW : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_LOW : 32;
#endif
} SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_LOW_t;

typedef union {
    unsigned int                           val : 32;
    SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_LOW_t f;
} SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_LOW_u;

#define SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_HIGH_OFFSET 0x0b18
typedef struct _SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_HIGH_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_HIGH : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_HIGH : 32;
#endif
} SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_HIGH_t;

typedef union {
    unsigned int                            val : 32;
    SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_HIGH_t f;
} SM4_XTS_CHECKSUM_FAIL_DEBUG_INFO_HIGH_u;

#pragma pack(pop)

#endif  // HARDWARE_SSM_SDW_SSM_SM4_XTS_4D0_LMD_H_
