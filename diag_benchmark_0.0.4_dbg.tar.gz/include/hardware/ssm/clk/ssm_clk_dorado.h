/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_CLK_SSM_CLK_DORADO_H_
#define HARDWARE_SSM_CLK_SSM_CLK_DORADO_H_

#include "hardware/include/ssm/clk/ssm_clk.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace clk {

class SsmClkDorado : public SsmClk {
 public:
    explicit SsmClkDorado(Ssm *ssm) : SsmClk(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmClkDorado() {}

 public:
    uint32_t ssm_clk_get(uint32_t);
    void     ssm_clk_get_list(uint32_t *);
};

}  // namespace clk
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_CLK_SSM_CLK_DORADO_H_
