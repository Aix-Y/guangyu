/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_TIMER_SSM_TIMER_SCORPIO_H_
#define HARDWARE_SSM_TIMER_SSM_TIMER_SCORPIO_H_

#include <string>

#include "hardware/include/ssm/timer/ssm_timer.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace timer {

class SsmTimerScorpio : public SsmTimer {
 public:
    explicit SsmTimerScorpio(Ssm *ssm) : SsmTimer(ssm) {
        IP_ASSERT(nullptr != m_ssm);
        memset(m_saved, 0, sizeof(m_saved));
    }
    ~SsmTimerScorpio() {}

 private:
    ssm_timer_info_t timer_info_get(kSsmTmrId);
    void             timer_dump_raw(ssm_timer_info_t &, std::string);
    ssm_timer_sets_u m_saved[kTmrIdMax];

 private:
    bool        is_timer_glb(kSsmTmrType);
    bool        is_timer_gen(kSsmTmrType);
    bool        is_timer_glb_valid(kSsmTmrId);
    bool        is_timer_gen_valid(kSsmTmrId);
    uint32_t    timer_glb_freq(void);
    uint32_t    timer_gen_freq(void);
    void        timer_init(ssm_timer_meas_t &);
    void        timer_restore(ssm_timer_meas_t &);
    void        timer_delay_reading(ssm_timer_meas_t &, uint32_t);
    bool        timer_measure_checking(ssm_timer_meas_t &);
    void        timer_measure_deviation(ssm_timer_meas_t &);
    void        timer_force_cleanup(ssm_timer_info_t &);
    bool        timer_enabled(uint32_t);
    void        timer_enable_wait(uint32_t);
    void        timer_disable_wait(uint32_t);
    void        timer_cnt_clr_wait(uint32_t);
    uint32_t    timer_int_read(uint32_t);
    void        timer_int_set(uint32_t, uint32_t);
    bool        timer_int_enabled(uint32_t);
    void        timer_int_wait(uint32_t);
    void        timer_int_clr_wait(uint32_t);
    bool        timer_mode_valid(kSsmTmrMode);
    std::string timer_mode_2str(uint32_t);
    uint32_t    timer_mode_2raw(kSsmTmrMode);
    uint32_t    timer_get_mode(uint32_t);
    void        timer_set_mode_wait(uint32_t, kSsmTmrMode);
    void        timer_set_comp0_wait(uint32_t, uint32_t);
    uint32_t    timer_get_comp0(uint32_t);
    void        timer_set_comp1_wait(uint32_t, uint32_t);
    void        timer_value_wait(uint32_t, uint32_t);
    uint32_t    timer_value_read(uint32_t);
    void        timer_set_sigtyp_wait(uint32_t, uint32_t);
    void        timer_set_sigsel_wait(kSsmTmrId, uint32_t);
    void        timer_glb_init(kSsmTmrId);
    void        timer_glb_save(kSsmTmrId);
    void        timer_glb_restore(kSsmTmrId);
    uint64_t    timer_glb_get_cnts(kSsmTmrId);
    uint64_t    timer_raw_get_cnts(ssm_timer_meas_t &);
    void        timer_gen_init(kSsmTmrId, kSsmTmrMode, uint32_t = ~0, uint32_t = ~0);
    void        timer_gen_save(kSsmTmrId);
    void        timer_gen_restore(kSsmTmrId);
    uint64_t    timer_gen_get_cnts(kSsmTmrId);
    bool        watchdog_alive(void);

 public:
    void watchdog_assert(void);
    void watchdog_deassert(void);

 private:
    bool test_timer_skip(kSsmTmrId);
    bool test_timer_freq_glb(kSsmTmrId);
    bool test_timer_freq_gen(kSsmTmrId);
    bool test_timer_mode_chronograph(kSsmTmrId);
    bool test_timer_mode_time_slice(kSsmTmrId);
    bool test_timer_int_gen(kSsmTmrId);

 public:
    bool test_timer_freq_measure(const std::string &);
    bool test_timer_chronograph(const std::string &);
    bool test_timer_time_slice(const std::string &);
    bool test_timer_interrupt(const std::string &);
    bool test_timer_watchdog_feeding(void);

 public:
    bool handle_req_watchdog(const std::string &);
    void handle_req_test(const std::string &);
};

}  // namespace timer
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_TIMER_SSM_TIMER_SCORPIO_H_
