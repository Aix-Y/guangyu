/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_DMA_SSM_DMA_SCORPIO_H_
#define HARDWARE_SSM_DMA_SSM_DMA_SCORPIO_H_

#include <string>

#include "hardware/include/ssm/dma/ssm_dma.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace dma {

using efvf::framework::mem::MemType;

class SsmDmaScorpio : public SsmDma {
 public:
    explicit SsmDmaScorpio(Ssm *ssm) : SsmDma(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmDmaScorpio() {}

 public:
    bool dma_lrcp(uint64_t, uint64_t, uint64_t, uint32_t = 0);
    bool dma_const_fill(uint64_t, uint32_t, uint32_t, uint32_t = 0);
    bool dma_op_parser_lrcp(const SsmDmaOp &, uint32_t = 0);
    void dma_op_parser_init(SsmDmaOp &, const std::string);
    void dma_op_parser_dump(const SsmDmaOp &);

 private:
    void     dma_op_res_init(SsmDmaRes &, std::string, uint64_t = 0);
    void     dma_op_res_dump(const SsmDmaRes &, const SsmDmaRes &, std::string = "");
    void     dma_op_res_fu08(const SsmDmaRes &, uint64_t, uint8_t, uint64_t = 0);
    void     dma_op_src_fu08(const SsmDmaOp &, uint64_t, uint8_t);
    void     dma_op_dst_fu08(const SsmDmaOp &, uint64_t, uint8_t);
    bool     dma_op_res_cu08(const SsmDmaRes &, uint64_t, uint8_t, uint64_t = 0);
    bool     dma_op_src_cu08(const SsmDmaOp &, uint64_t, uint8_t);
    bool     dma_op_dst_cu08(const SsmDmaOp &, uint64_t, uint8_t);
    bool     is_mem_type_ssm(uint32_t);
    bool     is_mem_type_loc(uint32_t);
    bool     is_mem_type_hal(uint32_t);
    MemType  to_mem_type_hal(uint32_t);
    uint32_t get_dma_lmem_addr_st(void);
    void     set_dma_lmem_addr_st(uint32_t);
    uint32_t vld_dma_lmem_addr(void);
    uint32_t get_dma_hw_trig_mux(const std::string &, uint32_t, uint32_t = 0);

 private:
    bool test_dma_smem2dst_all(uint64_t, uint64_t, uint32_t);
    bool test_dma_int_vcdone_2mcu(uint32_t);
    bool test_dma_hw_trig_by_gp(uint32_t, uint32_t, uint32_t);

 public:
    bool test_dma_lrcp(const std::string &);
    bool test_dma_addr_align_check_src(const std::string &);
    bool test_dma_addr_align_check_dst(const std::string &);
    bool test_dma_addr_align_single_op(const std::string &);
    bool test_dma_addr_to_addr_ecf(void);
    bool test_dma_addr_noc_to_noc(const std::string &);
    bool test_dma_interrupt(const std::string &);
    bool test_dma_hw_trig(const std::string &);
    void test_dma_debug(void);

 public:
    bool handle_req_dma_op(const std::string &, const std::string &);
};

}  // namespace dma
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_DMA_SSM_DMA_SCORPIO_H_
