/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_MISC_SSM_MISC_SCORPIO_H_
#define HARDWARE_SSM_MISC_SSM_MISC_SCORPIO_H_

#include <string>

#include "hardware/include/ssm/misc/ssm_misc.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace misc {

class SsmMiscScorpio : public SsmMisc {
 public:
    explicit SsmMiscScorpio(Ssm *ssm) : SsmMisc(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmMiscScorpio() {}

 public:
    bool        dbg_test(uint32_t, uint32_t);
    uint32_t    dbg_interface(uint32_t, uint32_t, uint32_t, uint64_t = 0);
    uint32_t    drv_interface(uint32_t, uint32_t, uint32_t, uint64_t = 0);
    uint32_t    get_chip_version(void);
    uint32_t    get_asic_version(void);
    uint32_t    get_ssm_version(void);
    std::string get_ssm_ver_str(uint32_t);
    std::string get_ssm_ctime_str(void);
    uint32_t    get_amc_version(void);
    std::string get_amc_ver_str(uint32_t);
    uint32_t    get_imu_version(uint32_t);
    uint32_t    get_imu_data_rate(uint32_t);
    uint32_t    get_crit_ping_addr(void);
    uint32_t    get_crit_pong_addr(void);
    std::string get_chip_uuid(void);
    std::string ssm_fw_version(void);
    std::string amc_fw_version(void);
    std::string ssm_board_type(void);
    std::string ssm_board_rev(void);
    std::string ssm_board_ptime(std::string);
    bool        ssm_board_ptime_cmp(const std::string &, const std::string &);
    std::string ssm_pn_read(void);
    void        ssm_pn_write(const std::string &, std::string = 0);
    bool        ssm_pn_valid(const std::string &);
    std::string ssm_sn_read(void);
    void        ssm_sn_write(const std::string &, std::string = 0);
    bool        ssm_sn_valid(const std::string &);
    std::string ssm_openflag_read(void);
    void        ssm_openflag_write(const std::string &);
    bool        ssm_openflag_valid(const std::string &);
    bool        ssm_sip_harvest_ctrl(bool, uint32_t = 0);
    uint32_t    ssm_sip_harvest_info(uint32_t);
    bool        ssm_eeprom_read(void *);
    bool        ssm_eeprom_erase(void);
    bool        ssm_prepare_update(void);
    bool        chk_amc_alive(void);

 private:
    bool        pn_valid_v1d0(const std::string &);  // v1.0
    bool        pn_valid_v2d1(const std::string &);  // v2.1
    bool        sn_valid_v1d0(const std::string &);  // v1.0
    bool        sn_valid_v2d1(const std::string &);  // v2.1
    std::string fru_pn_pcb_w(const std::string &);
    std::string fru_pn_pcb_r(void);
    std::string fru_sn_pcb_w(const std::string &);
    std::string fru_sn_pcb_r(void);
    std::string fru_pn_prd_w(const std::string &);
    std::string fru_pn_prd_r(void);
    std::string fru_sn_prd_w(const std::string &);
    std::string fru_sn_prd_r(void);
    std::string fru_vendor_r(void);
    std::string fru_model_pcb_w(const std::string &);
    std::string fru_model_pcb_r(void);
    std::string fru_model_prd_w(const std::string &);
    std::string fru_model_prd_r(void);
    std::string fru_mdate_w(const std::string &);
    std::string fru_mdate_r(void);
    std::string fru_cfg_w(const std::string &);
    std::string fru_cfg_r(void);
    std::string fru_s2field(const std::string &);
    std::string fru_field2s(const std::string &);
    bool        fru_field_valid(const std::string &);
    std::string fru_item_r(const std::string &);
    std::string fru_item_w(const std::string &, const std::string &);
    std::string fru_trim(const std::string &);

 public:
    bool test_fw_life_cycle(void);
    bool test_fw_port_healthy(void);
    bool test_fw_port_reg_intf(const std::string &);
    bool test_fw_port_bar0_rw(const std::string &);

 public:
    void        handle_req_imu_ver_dump(void);
    bool        handle_req_edcc_vddc(const std::string &, const std::string &);
    bool        handle_req_sip_harvest(const std::string &, const std::string &);
    std::string handle_req_fru(const std::string &, std::string = "");
    std::string handle_req_fru_cfg(const std::string &, std::string = "");
    void        handle_req_ssm_compile_time(void);
    void        handle_req_ssm_chipversions(void);
    bool        handle_req_ssm_qdd(const std::string &, const std::string &);
};

}  // namespace misc
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_MISC_SSM_MISC_SCORPIO_H_
