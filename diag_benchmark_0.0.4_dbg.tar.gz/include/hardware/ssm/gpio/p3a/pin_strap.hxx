/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_GPIO_SCORPIO_PIN_STRAP_HXX_
#define HARDWARE_SSM_GPIO_SCORPIO_PIN_STRAP_HXX_

static SSM_GPIO_INFO pin_strap_bu[] = { // Bring-up Value asic.scorpio
    { .check = 1, .gpio =  0, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_0",  .name = "PIN_STRAP_FUSE_SENSE_BYPASS", },
    { .check = 1, .gpio =  1, .value = 1, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_1",  .name = "PIN_STRAP_SKIP_FUSE_SENSE_FOR_WARM_RESET", },
    { .check = 1, .gpio =  2, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_2",  .name = "PIN_STRAP_FW_LOAD_BYPASS", },
    { .check = 1, .gpio =  3, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_3",  .name = "PIN_STRAP_SKIP_FW_LOAD_FOR_WARM_RESET", },
    { .check = 1, .gpio =  4, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_4",  .name = "PIN_STRAP_BOOT_START_LOCATION", },
    { .check = 1, .gpio =  5, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_5",  .name = "PIN_STRAP_BOOT_SOURCE", },
    { .check = 1, .gpio =  6, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_6",  .name = "PIN_STRAP_SECURE_BOOT_EN", },
    { .check = 1, .gpio =  7, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_7",  .name = "PIN_STRAP_HW_PCIE_LINK_TRAINING_ENABLE", },
    { .check = 1, .gpio =  8, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_8",  .name = "PIN_STRAP_SPI_CLK_FREQ", },
    { .check = 1, .gpio =  9, .value = 1, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_9",  .name = "PIN_STRAP_SSM_SRAMMISC_SEL", },
    { .check = 0, .gpio = 10, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_10", .name = "GPIO DFT_OBS10/JTAG_TDI", },
    { .check = 0, .gpio = 11, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_11", .name = "GPIO DFT_OBS11/JTAG_TMS", },
    { .check = 0, .gpio = 12, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_12", .name = "IO_AVS_CLK", },
    { .check = 0, .gpio = 13, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_13", .name = "IO_AVS_MDATA", },
    { .check = 0, .gpio = 14, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_14", .name = "IO_AVS_SDATA", },
    { .check = 0, .gpio = 15, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_15", .name = "IO_UART0_TX", },
    { .check = 0, .gpio = 16, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_16", .name = "IO_UART0_RX", },
    { .check = 0, .gpio = 17, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_17", .name = "IO_UART1_TX/AP_UART_TX", },
    { .check = 0, .gpio = 18, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_18", .name = "IO_UART1_RX/AP_UART_RX", },
    { .check = 0, .gpio = 19, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_19", .name = "SSI_SPI_CS_N", },
    { .check = 0, .gpio = 20, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_20", .name = "SSI_SPI_SCK", },
    { .check = 0, .gpio = 21, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_21", .name = "SSI_SPI_SIO0", },
    { .check = 0, .gpio = 22, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_22", .name = "SSI_SPI_SIO1", },
    { .check = 0, .gpio = 23, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_23", .name = "GPIO D2D 0", },
    { .check = 0, .gpio = 24, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_24", .name = "GPIO D2D 1", },
    { .check = 0, .gpio = 25, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_25", .name = "GPIO D2D 2", },
    { .check = 0, .gpio = 26, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_26", .name = "GPIO D2D 3", },
    { .check = 0, .gpio = 27, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_27", .name = "GPIO uPad_DFX_SE", },
    { .check = 0, .gpio = 28, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_28", .name = "GPIO uPad_DFX_EDT_UPD", },
    { .check = 0, .gpio = 29, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_29", .name = "GPIO JTAG_TCK", },
    { .check = 0, .gpio = 30, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_30", .name = "GPIO JTAG_ENABLE", },
    { .check = 0, .gpio = 31, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_31", .name = "Reserved", },
};

static SSM_GPIO_INFO pin_strap_pd[] = { // Production Value asic.scorpio
    { .check = 1, .gpio =  0, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_0",  .name = "PIN_STRAP_FUSE_SENSE_BYPASS", },
    { .check = 1, .gpio =  1, .value = 1, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_1",  .name = "PIN_STRAP_SKIP_FUSE_SENSE_FOR_WARM_RESET", },
    { .check = 1, .gpio =  2, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_2",  .name = "PIN_STRAP_FW_LOAD_BYPASS", },
    { .check = 1, .gpio =  3, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_3",  .name = "PIN_STRAP_SKIP_FW_LOAD_FOR_WARM_RESET", },
    { .check = 1, .gpio =  4, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_4",  .name = "PIN_STRAP_BOOT_START_LOCATION", },
    { .check = 1, .gpio =  5, .value = 1, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_5",  .name = "PIN_STRAP_BOOT_SOURCE", },
    { .check = 1, .gpio =  6, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_6",  .name = "PIN_STRAP_SECURE_BOOT_EN", },
    { .check = 1, .gpio =  7, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_7",  .name = "PIN_STRAP_HW_PCIE_LINK_TRAINING_ENABLE", },
    { .check = 1, .gpio =  8, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_8",  .name = "PIN_STRAP_SPI_CLK_FREQ", },
    { .check = 1, .gpio =  9, .value = 1, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_9",  .name = "PIN_STRAP_SSM_SRAMMISC_SEL", },
    { .check = 0, .gpio = 10, .value = 0, .slv = "N", .mst = "Y", .d2d = "Y", .pad = "uPAD_SSM_GPIO_10", .name = "GPIO DFT_OBS10/JTAG_TDI", },
    { .check = 0, .gpio = 11, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_11", .name = "GPIO DFT_OBS11/JTAG_TMS", },
    { .check = 0, .gpio = 12, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_12", .name = "IO_AVS_CLK", },
    { .check = 0, .gpio = 13, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_13", .name = "IO_AVS_MDATA", },
    { .check = 0, .gpio = 14, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_14", .name = "IO_AVS_SDATA", },
    { .check = 0, .gpio = 15, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_15", .name = "IO_UART0_TX", },
    { .check = 0, .gpio = 16, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_16", .name = "IO_UART0_RX", },
    { .check = 0, .gpio = 17, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_17", .name = "IO_UART1_TX/AP_UART_TX", },
    { .check = 0, .gpio = 18, .value = 0, .slv = "N", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_18", .name = "IO_UART1_RX/AP_UART_RX", },
    { .check = 0, .gpio = 19, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_19", .name = "SSI_SPI_CS_N", },
    { .check = 0, .gpio = 20, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_20", .name = "SSI_SPI_SCK", },
    { .check = 0, .gpio = 21, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_21", .name = "SSI_SPI_SIO0", },
    { .check = 0, .gpio = 22, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_22", .name = "SSI_SPI_SIO1", },
    { .check = 0, .gpio = 23, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_23", .name = "GPIO D2D 0", },
    { .check = 0, .gpio = 24, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_24", .name = "GPIO D2D 1", },
    { .check = 0, .gpio = 25, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_25", .name = "GPIO D2D 2", },
    { .check = 0, .gpio = 26, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_26", .name = "GPIO D2D 3", },
    { .check = 0, .gpio = 27, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_27", .name = "GPIO uPad_DFX_SE", },
    { .check = 0, .gpio = 28, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_28", .name = "GPIO uPad_DFX_EDT_UPD", },
    { .check = 0, .gpio = 29, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_29", .name = "GPIO JTAG_TCK", },
    { .check = 0, .gpio = 30, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_30", .name = "GPIO JTAG_ENABLE", },
    { .check = 0, .gpio = 31, .value = 0, .slv = "Y", .mst = "Y", .d2d = "N", .pad = "uPAD_SSM_GPIO_31", .name = "Reserved", },
};

#endif  // HARDWARE_SSM_GPIO_SCORPIO_PIN_STRAP_HXX_
