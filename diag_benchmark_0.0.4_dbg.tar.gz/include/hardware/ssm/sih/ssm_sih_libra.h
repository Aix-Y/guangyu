/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_SIH_SSM_SIH_LIBRA_H_
#define HARDWARE_SSM_SIH_SSM_SIH_LIBRA_H_

#include <string>

#include "hardware/include/ssm/sih/ssm_sih.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace sih {

class SsmSihLibra : public SsmSih {
 public:
    explicit SsmSihLibra(Ssm *ssm) : SsmSih(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmSihLibra() {}

 private:
    ssm_ih_u    sih_ring_addr(uint32_t);
    bool        sih_ring_idle(uint32_t);
    void        sih_ring_idle_wait(uint32_t, const std::string &);
    bool        sih_ring_not_empty(uint32_t);
    bool        sih_ring_watermark(uint32_t);
    void        sih_ring_watermark_clr(uint32_t);
    uint32_t    sih_ring_watermark_get(uint32_t);
    void        sih_ring_int_en(uint32_t, bool);
    void        sih_ring_set_en(uint32_t, bool);
    void        sih_ring_msg_type(uint32_t, const std::string &);
    void        sih_ring_set_addr(uint32_t, uint64_t, uint64_t);
    void        sih_ring_set_addr_raw(uint32_t, uint64_t, uint64_t);
    uint64_t    sih_ring_get_addr(uint32_t);
    void        sih_ring_irq_trig(uint32_t, uint32_t, uint32_t);
    void        sih_ring_rpc_trig(uint32_t, uint32_t, uint32_t);
    void        sih_ring_dbg_trig(uint32_t, uint32_t);
    void        sih_ring_init(uint32_t, uint64_t, uint64_t, std::string = "irq");
    void        sih_ring_init_raw(uint32_t, uint64_t, uint64_t, std::string = "irq");
    void        sih_ring_off(uint32_t, std::string = "");
    bool        sih_ring_get_irq(uint32_t, ih::IrqEntry &);
    bool        sih_ring_get_rpc(uint32_t, ih::RpcEntry &);
    uint64_t    sih_ring_get_rsz(uint64_t);
    std::string sih_ring_ptr_2str(uint32_t);

 private:
    bool sih_ring_wait_irq(/* r_idx, entry, master_id, cause_id, die_id, sec */
        uint32_t, ih::IrqEntry &, uint32_t, uint32_t, uint32_t = 0, uint32_t = 1);
    bool sih_ring_wait_rpc(/* r_idx, entry, master_id, data_1_0, die_id, sec */
        uint32_t, ih::RpcEntry &, uint32_t, uint64_t, uint32_t = 0, uint32_t = 1);

 private:
    void        sih_ip_msi_msix_cfg(uint32_t);
    void        sih_ip_msi_cfg(uint32_t);
    void        sih_ip_msix0_cfg(uint32_t);
    void        sih_ip_msix1_cfg(uint32_t);
    void        sih_ip_set_sideband_en(bool);
    void        sih_ip_excp_int_en(bool);
    uint32_t    sih_ip_excp_log_get(void);
    uint32_t    sih_ip_excp_sts_get(void);
    void        sih_ip_excp_sts_set(uint32_t);
    bool        sih_ip_wmiss_found(void);
    void        sih_ip_wmiss_clr(void);
    bool        sih_ip_llqf_found(void);
    void        sih_ip_llqf_clr(void);
    uint32_t    sih_ip_get_srammisc(void);
    void        sih_ip_set_cg(bool);
    void        sih_ip_rst(void);
    bool        sih_df_ongoing(void);
    void        sih_rd_one_ent(void *, uint64_t, uint64_t);
    std::string sih_ring_t2str(uint32_t);

 private:
    bool test_mih_recv_host_irq(void);
    bool test_mih_recv_host_irq_walk(void);
    bool test_mih_recv_host_irq_s1xr1x(void);
    bool test_mih_recv_host_irq_snxrnx(void);
    bool test_mih_recv_host_rpc(void);
    bool test_mih_recv_host_rpc_walk(void);
    bool test_mih_recv_host_rpc_s1xr1x(void);
    bool test_mih_recv_host_rpc_snxrnx(void);
    bool test_ssm_send_host_irq_s1xr1x(void);
    bool test_ssm_send_host_rpc_s1xr1x(void);
    bool test_mih_send_sideband_ne2mcu(uint32_t, uint32_t, uint32_t);
    bool test_mih_send_sideband_wm2mcu(uint32_t);
    bool test_mih_send_sideband_wmiss2mcu(uint32_t);
    bool test_mih_send_sideband_llqf2mcu(uint32_t);

 public:
    bool test_mih_recv_interrupt(const std::string &);
    bool test_mih_send_interrupt(const std::string &);

 public:
    bool handle_tool_req_set(const std::string &);
};

}  // namespace sih
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_SIH_SSM_SIH_LIBRA_H_
