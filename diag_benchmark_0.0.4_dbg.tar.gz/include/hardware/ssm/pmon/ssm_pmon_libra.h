/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_PMON_SSM_PMON_LIBRA_H_
#define HARDWARE_SSM_PMON_SSM_PMON_LIBRA_H_

#include "hardware/include/ssm/pmon/ssm_pmon.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace pmon {

class SsmPmonLibra : public SsmPmon {
 public:
    explicit SsmPmonLibra(Ssm *ssm) : SsmPmon(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmPmonLibra() {}

 public:
    uint32_t get_bus_volt(uint32_t);
    uint32_t get_shunt_volt(uint32_t);
    uint32_t get_power(uint32_t);
    uint32_t get_current(uint32_t);
    uint32_t get_calibration(uint32_t);

 private:
    bool     is_id_valid(uint32_t);
    uint32_t get_ext_fwidx(uint32_t);
};

}  // namespace pmon
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_PMON_SSM_PMON_LIBRA_H_
