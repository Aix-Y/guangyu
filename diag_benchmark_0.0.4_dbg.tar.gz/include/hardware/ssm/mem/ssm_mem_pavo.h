/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_MEM_SSM_MEM_PAVO_H_
#define HARDWARE_SSM_MEM_SSM_MEM_PAVO_H_

#include "hardware/include/ssm/mem/ssm_mem.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace mem {

class SsmMemPavo : public SsmMem {
 public:
    explicit SsmMemPavo(Ssm *ssm) : SsmMem(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmMemPavo() {}
};

}  // namespace mem
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_MEM_SSM_MEM_PAVO_H_
