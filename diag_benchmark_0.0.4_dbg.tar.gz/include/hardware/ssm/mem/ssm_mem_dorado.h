/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_MEM_SSM_MEM_DORADO_H_
#define HARDWARE_SSM_MEM_SSM_MEM_DORADO_H_

#include "hardware/include/ssm/mem/ssm_mem.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace mem {

class SsmMemDorado : public SsmMem {
 public:
    explicit SsmMemDorado(Ssm *ssm) : SsmMem(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmMemDorado() {}

 public:
    void ssm_mem_r(void *, uint32_t, uint32_t = 0U, uint32_t = 0U);
    void ssm_mem_w(void *, uint32_t, uint32_t = 0U, uint32_t = 0U);
    void ssm_mem_d(uint32_t, uint32_t = 0U, uint32_t = 0U);
    void ssm_mem_f_u08(uint32_t, uint8_t, uint32_t, uint32_t = 0U);
    bool ssm_mem_c_u08(uint32_t, uint8_t, uint32_t, uint32_t = 0U);

 private:
    uint32_t mcu_mem_get_base_addr(uint32_t);
    uint32_t mcu_mem_get_size(uint32_t);
    bool     mcu_mem_opsize_valid(void *);
    void     mcu_mem_backdoor_rd(void *);
    void     mcu_mem_backdoor_wr(void *);
    void     mcu_mem_backdoor_rd(void *, uint32_t, uint32_t = ~0U, uint32_t = ~0U);
    void     mcu_mem_backdoor_wr(void *, uint32_t, uint32_t = ~0U, uint32_t = ~0U);
};

}  // namespace mem
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SSM_MEM_SSM_MEM_DORADO_H_
