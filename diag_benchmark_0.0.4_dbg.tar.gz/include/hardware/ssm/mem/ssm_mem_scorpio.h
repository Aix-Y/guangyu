/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_MEM_SSM_MEM_SCORPIO_H_
#define HARDWARE_SSM_MEM_SSM_MEM_SCORPIO_H_

#include <string>

#include "hardware/include/ssm/mem/ssm_mem.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace mem {

class SsmMemScorpio : public SsmMem {
 public:
    explicit SsmMemScorpio(Ssm *ssm);
    ~SsmMemScorpio() {}

 private:
    bool m_r_dump;
    bool m_w_dump;

 public:
    void     ssm_mem_r(void *, uint32_t, uint32_t = 0U, uint32_t = 0U);
    void     ssm_mem_w(void *, uint32_t, uint32_t = 0U, uint32_t = 0U);
    void     ssm_mem_d(uint32_t, uint32_t = 0U, uint32_t = 0U);
    void     ssm_mem_f_u08(uint32_t, uint8_t, uint32_t, uint32_t = 0U);
    bool     ssm_mem_c_u08(uint32_t, uint8_t, uint32_t, uint32_t = 0U);
    uint32_t ssm_mem_addr_ecf(uint32_t);
    uint32_t ssm_mem_addr_spi(uint32_t);
    uint32_t ssm_mem_addr_dma(uint32_t);
    uint32_t ssm_mem_size(uint32_t);
    uint32_t ssm_mem_vf_base(uint32_t);

 private:
    bool mcu_mem_opsize_valid(void *);
    void mcu_mem_backdoor_rd(void *);
    void mcu_mem_backdoor_wr(void *);
    void mcu_mem_backdoor_rd(void *, uint32_t, uint32_t = ~0U, uint32_t = ~0U);
    void mcu_mem_backdoor_wr(void *, uint32_t, uint32_t = ~0U, uint32_t = ~0U);
    void mcu_mem_backdoor_dump(uint32_t, uint32_t = ~0U);

    /////////////////////
    // MEM TEST INTERFACE
    /////////////////////
 public:
    void test_mcu_mem_backdoor_smem_dump(void);
    bool test_mcu_mem_backdoor_smem_wrc(void);

    /////////////////////
    // MEM TOOL INTERFACE
    /////////////////////
 public:
    bool        handle_tool_req_set(const std::string &, const std::string &);
    std::string handle_req_mem_info(void);
    bool        handle_req_mem_load(const std::string &, const std::string &);

 private:
    std::string get_tool_mem_info(uint32_t);
};

}  // namespace mem
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_MEM_SSM_MEM_SCORPIO_H_
