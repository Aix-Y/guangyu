/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_PLV_SSM_PLV_SCORPIO_H_
#define HARDWARE_SSM_PLV_SSM_PLV_SCORPIO_H_

#include <string>
#include <vector>

#include "hardware/include/ssm/plv/ssm_plv.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace plv {

class SsmPlvScorpio : public SsmPlv {
 public:
    explicit SsmPlvScorpio(Ssm *);
    ~SsmPlvScorpio() {}

 private:
    bool                  m_plv_lv_up;
    bool                  m_plv_finit;
    std::vector<uint32_t> m_plv_f_fix;
    std::vector<uint32_t> m_plv_f_flt;
    plv_map_t             m_plv_map[kPlvTpMax];

 public:
    bool     get_plv_feat_ena(syst_param_plv_t &);
    uint32_t get_plv_lv(syst_param_plv_t &);
    uint32_t get_plv_lv_min(syst_param_plv_t &);
    uint32_t get_plv_lv_max(syst_param_plv_t &);
    bool     get_plv_lv_vld(syst_param_plv_t &, uint32_t &);
    uint32_t get_plv_lv_next(syst_param_plv_t &, uint32_t &);
    void     set_plv_lv(syst_param_plv_t &, uint32_t &);
    bool     chk_plv_samplet(syst_param_plv_t &, syst_samplet_v3 &);

 private:
    plv_map_t &syst_p_2map(syst_param_plv_t &);
    uint32_t   syst_p_tp(syst_param_plv_t &);
    bool       syst_p_tp_test(syst_param_plv_t &);
    bool       syst_p_tp_dpm(syst_param_plv_t &);
    bool       syst_p_tp_pid(syst_param_plv_t &);
    uint32_t   syst_p_op(syst_param_plv_t &);
    bool       syst_p_tp_otp(syst_param_plv_t &);
    bool       syst_p_op_seq(syst_param_plv_t &);
    bool       syst_p_op_rand(syst_param_plv_t &);
    uint32_t   syst_p_2plvmin(syst_param_plv_t &);
    uint32_t   syst_p_2plvmax(syst_param_plv_t &);
    uint32_t   syst_p_plv2rlv(syst_param_plv_t &, uint32_t &);
    uint32_t   syst_p_rlv2plv(syst_param_plv_t &, uint32_t &);

 public:
    void     set_doze_ena(bool);
    void     set_doze_delay(uint32_t);
    void     set_cur_ena(bool);
    void     set_dpm_ena(bool);
    void     set_kfc_ena(bool);
    uint32_t get_kfc_lv_dtu(void);
    void     set_kfc_lv_dtu(uint32_t);
    uint32_t get_kfc_lv_soc(void);
    void     set_kfc_lv_soc(uint32_t);
    void     set_dpm_level(uint32_t);
    uint32_t get_dpm_level(void);
    void     set_dpm_max(uint32_t);
    uint32_t get_dpm_max(void);
    void     set_thm_ena(bool, uint32_t);
    void     set_thm_pid_cfg(uint32_t, uint32_t, uint32_t, uint32_t);
    void     set_thm_pid_point(uint32_t, uint32_t, uint32_t);
    void     set_thm_fan_pwm(uint32_t);
    void     set_vr_ena(bool);
    void     set_int_ena(bool);
    void     set_tsen_ena(bool);
    double   get_ocp_threshold(void);
    void     set_ocp_threshold(double);

 public:
    void handle_req_dpm_status(void);
    void handle_req_kfc_status(void);
    bool handle_req_kfc_lv_op(const std::string &, const std::string &);
};

}  // namespace plv
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_PLV_SSM_PLV_SCORPIO_H_
