/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_SSM_SCORPIO_H_
#define HARDWARE_SSM_SSM_SCORPIO_H_

#include <map>
#include <memory>
#include <string>

#include "hardware/include/ssm/ssm.h"

namespace efvf {
namespace hardware {
namespace ssm {

class SsmScorpio : public Ssm {
 public:
    explicit SsmScorpio(std::shared_ptr<spdlog::logger>);
    virtual ~SsmScorpio() {}

 private:
    void LibInit();
    bool HwInitMini();
    bool HwInit();
    std::map<const std::string, uint64_t> m_reg_base;

 public:
    uint64_t r_base(const std::string & /*mip_mid_sid*/);
    uint32_t r_r32(uint32_t);
    void     r_w32(uint32_t, uint32_t);

 public:
    reg::SsmReg *                  GetReg();
    mem::SsmMem *                  GetMem();
    cmd::SsmCmd *                  GetCmd();
    mcu::SsmMcu *                  GetMcu();
    spi::SsmSpi *                  GetSpi();
    sih::SsmSih *                  GetSih();
    clk::SsmClk *                  GetClk();
    misc::SsmMisc *                GetMisc();
    fuse::SsmFuse *                GetFuse();
    otp::SsmOtp *                  GetOtp();
    dma::SsmDma *                  GetDma();
    mdma::Mdma *                   GetMdma();
    uart::SsmUart *                GetUart();
    timer::SsmTimer *              GetTimer();
    fiw::SsmFiw *                  GetFiw();
    gpio::SsmGpio *                GetGpio();
    i2c::SsmI2c *                  GetI2c();
    pmon::SsmPmon *                GetPmon();
    pins::SsmPins *                GetPins();
    dmi::SsmDmi *                  GetDmi();
    vr::SsmVr *                    GetVr();
    ivm::SsmIvm *                  GetIvm();
    reset::SsmReset *              GetReset();
    rpfei::SsmRpfei *              GetRpfei();
    secure::SsmSecure *            GetSecure();
    sem::SsmSem *                  GetSem();
    cpmu::SsmCpmu *                GetCpmu();
    plv::SsmPlv *                  GetPlv();
    intf::SsmIntf *                GetIntf();
    system_adapter::SystemAdapter *GetSa();
    ih::Ih *                       GetMih();
};

}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_SSM_SCORPIO_H_
