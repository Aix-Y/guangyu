/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_RESET_SSM_RESET_LIBRA_H_
#define HARDWARE_SSM_RESET_SSM_RESET_LIBRA_H_

#include "hardware/include/ssm/reset/ssm_reset.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace reset {

class SsmResetLibra : public SsmReset {
 public:
    explicit SsmResetLibra(Ssm *ssm) : SsmReset(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmResetLibra() {}
};

}  // namespace reset
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_RESET_SSM_RESET_LIBRA_H_
