/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SSM_RESET_SSM_RESET_SCORPIO_H_
#define HARDWARE_SSM_RESET_SSM_RESET_SCORPIO_H_

#include "hardware/include/ssm/reset/ssm_reset.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace reset {

class SsmResetScorpio : public SsmReset {
 public:
    explicit SsmResetScorpio(Ssm *ssm) : SsmReset(ssm) {
        IP_ASSERT(nullptr != m_ssm);
    }
    ~SsmResetScorpio() {}
};

}  // namespace reset
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SSM_RESET_SSM_RESET_SCORPIO_H_
