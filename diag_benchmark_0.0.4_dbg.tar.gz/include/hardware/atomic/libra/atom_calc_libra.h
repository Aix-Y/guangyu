/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_ATOMIC_LIBRA_ATOM_CALC_LIBRA_H_
#define HARDWARE_ATOMIC_LIBRA_ATOM_CALC_LIBRA_H_

#include <string>
#include "hardware/atomic/atom_calc.h"

namespace efvf {
namespace hardware {
namespace atomic {

class AmoCalcLibra : public AmoCalc {
 public:
    explicit AmoCalcLibra(const Dtu *dtu) : AmoCalc() {
        dtu_    = dtu;
        logger_ = dtu_->get_logger();
    }

    virtual ~AmoCalcLibra() {}

    virtual bool IsAtomOpValid(const std::string &op_name, const std::string &dtype) const;
    virtual uint32_t GetAtomOpInt(const std::string &inst_s) const;
    virtual AtomOp GetAtomOpType(const std::string &op_name) const;
    virtual std::string GetAtomOpName(const AtomOp &op_type) const;
    virtual std::string GetAtomOpStr(uint32_t opcode) const;
    virtual bool IsInstStoreOnly(const std::string &inst_s) const;
    virtual uint32_t GetDtypeInt(const std::string &dtype) const;
    virtual uint32_t GenAtomicUserBits4Wqe(
        const std::string &inst_s, const uint32_t data_type);
};

}  // namespace atomic
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_ATOMIC_LIBRA_ATOM_CALC_LIBRA_H_
