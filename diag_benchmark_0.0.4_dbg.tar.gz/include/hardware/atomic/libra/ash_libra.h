/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_ATOMIC_LIBRA_ASH_LIBRA_H_
#define HARDWARE_ATOMIC_LIBRA_ASH_LIBRA_H_
#include <memory>
#include <string>
#include "hardware/include/atomic/ash.h"

namespace efvf {
namespace hardware {
namespace atomic {

class AshLibra : public Ash {
 public:
    explicit AshLibra(std::shared_ptr<spdlog::logger> logger) : Ash(logger) {}
    virtual ~AshLibra() {}

    virtual bool HwInit();
    virtual bool HwDeinit();
    virtual void LibInit();
    virtual bool HwInitMini();

 public:
    virtual uint32_t GetDieId();
    virtual uint32_t GetInstId();
    virtual uint32_t GetInstCnt();

    virtual bool HandleToolReq(const std::string &req);
    virtual bool HandleToolReq(const std::string &req, uint64_t &in_out);
    virtual bool HandleToolReq(const std::string &req, void *ptr);

 private:
    bool BypassAsh(bool bypass);
    bool SetOstCnt(uint64_t ost);
    bool GetOstCnt(uint64_t &ost);
    bool SetBlcgClkGate(bool en);
    bool SetBlcgSwClkEn(bool en);
    bool GetAluIntStat(uint64_t &stat);
    bool RasCheckEnable(bool en);
    bool RasIntReqEnable(bool en);
    bool RasErrorInject(void *inj);
    bool ClearIntStat();
    bool ClearErrStatus();
    bool FloatOvflClamp(uint32_t);
    bool ReadmissHwPfHintOvrd(bool en, uint32_t val = 1);
    //
    // bool HandleSrammisc(Hardware *hw, uint32_t reg_addr, uint32_t idx, uint32_t inj_cnt =
    // 1);
};

}  // namespace atomic
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_ATOMIC_LIBRA_ASH_LIBRA_H_
