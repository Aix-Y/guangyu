/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SYSM_3D0_SYS_MON_TASK_3D0_PTU_H_
#define HARDWARE_SYSM_3D0_SYS_MON_TASK_3D0_PTU_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"

#include "hardware/sysm/3d0/sys_mon_task_3d0.h"

namespace efvf {
namespace hardware {
namespace sysm {

class SysMonTask3d0Ptu : public SysMonTask3d0 {
 public:
    explicit SysMonTask3d0Ptu(const Dtu &);
    virtual ~SysMonTask3d0Ptu() {}

 public:
    void     syst_notify_create(void);
    void     syst_notify_created(void);
    void     syst_notify_delete(void);
    void     syst_notify_deleted(void);
    uint32_t syst_get_dlms(void);
    void     Execute(void *);

 private:
    bool     is_s60(void);
    bool     is_s90(void);
    bool     is_ttgt(void);
    uint32_t get_timer(const std::string &);
    uint32_t get_ctl_mode(const std::string &);
    double   get_pwr_asic(const std::string &);
    double   get_pwr_ldlt(const std::string &);
    double   get_pwr_rdlt(const std::string &);
    double   get_dtu_vmin(const std::string &);
    double   get_dtu_vmax(const std::string &);
    double   get_dtu_step(const std::string &);
    void     params_prep(void);
    void     params_dump(void);
    bool     params_skip_die(int);
    void     pwtune_init(void);
    void     pwtune_start(void);
    void     pwtune_vset(bool, double);

 private:
    syst_param_ptu_t m_param_ptu;
    double           m_pwr_vset;
    bool             m_die_skip0;
    bool             m_die_skip1;
    bool             m_err_capt;
};

}  // namespace sysm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SYSM_3D0_SYS_MON_TASK_3D0_PTU_H_
