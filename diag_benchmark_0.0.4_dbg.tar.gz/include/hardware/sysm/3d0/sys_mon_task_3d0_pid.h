/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SYSM_3D0_SYS_MON_TASK_3D0_PID_H_
#define HARDWARE_SYSM_3D0_SYS_MON_TASK_3D0_PID_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"

#include "hardware/sysm/3d0/sys_mon_task_3d0.h"

namespace efvf {
namespace hardware {
namespace sysm {

class SysMonTask3d0Pid : public SysMonTask3d0 {
 public:
    explicit SysMonTask3d0Pid(const Dtu &);
    virtual ~SysMonTask3d0Pid() {}

 public:
    void     syst_notify_create(void);
    void     syst_notify_created(void);
    void     syst_notify_delete(void);
    void     syst_notify_deleted(void);
    uint32_t syst_get_dlms(void);
    void     Execute(void *);

 private:
    ssm::plv::SsmPlv *get_plv(int);
    uint32_t          get_timer(const std::string &);
    bool              get_logen(const std::string &);
    std::string       get_lognm(const std::string &);
    uint32_t          get_lvtp(const std::string &);
    uint32_t          get_lvop(const std::string &);
    uint32_t          get_lvmin(const std::string &);
    uint32_t          get_lvmax(const std::string &);
    uint32_t          get_lvres(const std::string &);
    void              params_prep(void);
    void              params_dump(void);
    bool              params_skip_die(int);
    void              sample_init(void);
    void              sample_stop(void);
    void              sample_data(void);
    void              sample_data_d2d(bool &, uint64_t &);
    bool              sample_data_check(int);

 private:
    syst_param_plv_t  m_param_pid;
    std::ofstream     m_txt_log;
    syst_samplet_v3   m_pid_data[2];
    ssm::plv::SsmPlv *m_pid_plv[2];
    bool              m_1st_data;
    uint64_t          m_1st_spus;
    uint64_t          m_swt_spus;
    bool              m_die_skip0;
    bool              m_die_skip1;
    bool              m_err_capt;
};

}  // namespace sysm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SYSM_3D0_SYS_MON_TASK_3D0_PID_H_
