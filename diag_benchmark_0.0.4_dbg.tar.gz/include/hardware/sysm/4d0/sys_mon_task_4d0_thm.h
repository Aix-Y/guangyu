/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SYSM_4D0_SYS_MON_TASK_4D0_THM_H_
#define HARDWARE_SYSM_4D0_SYS_MON_TASK_4D0_THM_H_

#include <map>
#include <memory>
#include <string>

#include "hardware/include/hardware.h"

#include "hardware/sysm/4d0/sys_mon_task_4d0.h"

namespace efvf {
namespace hardware {
namespace sysm {

class SysMonTask4d0Thm : public SysMonTask4d0 {
 public:
    explicit SysMonTask4d0Thm(const Dtu &);
    virtual ~SysMonTask4d0Thm() {}

 public:
    void     syst_notify_create(void);
    void     syst_notify_created(void);
    void     syst_notify_delete(void);
    void     syst_notify_deleted(void);
    uint32_t syst_get_dlms(void);
    void     Execute(void *);

 private:
    uint32_t    get_timer(const std::string &);
    bool        get_logen(const std::string &);
    std::string get_lognm(const std::string &);
    void        params_prep(void);
    void        params_dump(void);
    bool        params_skip_die(int);
    void        sample_init(void);
    void        sample_stop(void);
    void        sample_data(void);
    void        sample_data_d2d(void);
    void        sample_data_temp(int);
    void        sample_data_curr(int);
    void        sample_data_volt(int);
    void        sample_data_power(int);
    void        sample_data_clock(int);

 private:
    syst_param_thm_t m_param_thm;
    std::ofstream    m_txt_log;
    std::ofstream    m_csv_log;
    syst_samplet_v2  m_thm_data;
    bool             m_1st_data;
    uint64_t         m_1st_spus;
    bool             m_die_skip0;
    bool             m_die_skip1;
    bool             m_err_capt;
};

}  // namespace sysm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SYSM_4D0_SYS_MON_TASK_4D0_THM_H_
