/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_SYSM_4D0_SYS_MON_TASK_4D0_H_
#define HARDWARE_SYSM_4D0_SYS_MON_TASK_4D0_H_

#include <map>
#include <memory>
#include <string>

#include "hardware/include/hardware.h"

#include "hardware/include/sysm/sys_mon_task.h"

namespace efvf {
namespace hardware {
namespace sysm {

class SysMonTask4d0 : public SysMonTask {
 public:
    explicit SysMonTask4d0(const Dtu &);
    virtual ~SysMonTask4d0() {}

 public:
    virtual void Execute(void *) = 0;  // refer efvf::framework::service_mgr::Task

 public:
    std::string param_ctrl_get(void);
    void        param_gen_kvmap(std::string, std::map<std::string, std::string> &);
    std::string param_in_kvmap(std::string, std::map<std::string, std::string> &);
    bool        param_is_numeric(const std::string &);
    std::string param_2str(const std::string &, const std::string &);
    uint32_t    param_2u32(const std::string &, const std::string &);
    double      param_2dbl(const std::string &, const std::string &);
    std::string get_running_suite(void);
    std::string get_uuid_str(int);
    std::string get_binfo_str(void);
    std::string get_ivm_git_str(void);
    std::string get_rfw_git_str(void);
    std::string get_bfw_ver_str(void);
    std::string get_rfw_ver_str(void);

 protected:
    Ssm *       GetSsm(int);
    std::string u32_2hex8s(uint32_t &);

 private:
    std::mutex  m_reslk;
    std::string m_suite;
    std::string m_uuid0;
    std::string m_uuid1;
    std::string m_binfo;
    std::string m_ivmgv;
    std::string m_rfwgv;
    std::string m_ssmbv;
    std::string m_ssmrv;
};

}  // namespace sysm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_SYSM_4D0_SYS_MON_TASK_4D0_H_
