/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_CQM_H_
#define HARDWARE_INCLUDE_CQM_H_

#include <memory>
#include <vector>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace cqm {
typedef struct _CqmSlotInfo {
    uint32_t status;
    uint32_t addr_hi;
    uint32_t addr_lo;
    uint32_t len;
    uint32_t rptr;
} CqmSlotInfo;

typedef struct _CqmInfo {
    uint32_t                 info;
    uint32_t                 wptr;
    uint32_t                 rptr;
    uint32_t                 err_cnt;
    uint32_t                 err_code;
    std::vector<CqmSlotInfo> slots;
} CqmInfo;

class Cqm : public Hardware {
 public:
    Cqm() {}
    explicit Cqm(std::shared_ptr<spdlog::logger> logger);
    virtual ~Cqm() {}

    virtual void GetCqmStatus(CqmInfo *ci) = 0;
};
}  // namespace cqm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CQM_H_
