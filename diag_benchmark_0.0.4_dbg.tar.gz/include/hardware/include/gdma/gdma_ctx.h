/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#include <stdint.h>

#ifndef HARDWARE_INCLUDE_GDMA_GDMA_CTX_H_
#define HARDWARE_INCLUDE_GDMA_GDMA_CTX_H_

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace gdma {

typedef enum _DmaOpType {
    DMA_OP_LINEAR,
    DMA_OP_TILING_PADDING,
    DMA_OP_TILING_CONCATENATE,
    DMA_OP_TILING_RESHAPE,
    DMA_OP_TILING_BROADCASTING,
    DMA_OP_TILING_SLICE,
    DMA_OP_TILING_SUB_SAMPLING,
    DMA_OP_TILING_MIRROR_L_R,
    DMA_OP_TILING_MIRROR_T_B,
    DMA_OP_CONSTANT_FILL,
    DMA_OP_REGISTER_COPY,
    DMA_OP_ONE_HOT,
    DMA_OP_COMPRESS_CSR,
    DMA_OP_DECOMPRESS_CSR,
    DMA_OP_COMPRESS_DOK,
    DMA_OP_DECOMPRESS_DOK,
    DMA_OP_SYNC,
    DMA_OP_GSYNC,
    DMA_OP_DATA_SHRINK,
    DMA_OP_DATA_EXPAND,
    DMA_OP_SLICE_RESHAPE,
    DMA_OP_DESLICE_RESHAPE,
    DMA_OP_DECOMPRESS_SVS,
    DMA_OP_TILING_DE_SLICE,
    DMA_OP_INVALID,
} DmaOpType;

typedef enum _DmaDir {
    DMA_DIR_H2H,
    DMA_DIR_H2L,
    DMA_DIR_L2H,
    DMA_DIR_L2L,
    DMA_DIR_MAX,
    DMA_DIR_INVALID = 0xFF
} DmaDir;

typedef struct _MbWait {
    uint32_t src_en           = 0;
    uint32_t src_ref_clean_en = 0;
    uint32_t src_group        = 0;  // 6bit - 64 group mailbox
    uint32_t src_check        = 0;  // 8bit - each bit select 1
                                    // mailbox in the group
    uint32_t dst_en           = 0;
    uint32_t dst_ref_clean_en = 0;
    uint32_t dst_group        = 0;  // 6bit - 64 group mailbox
    uint32_t dst_check        = 0;  // 8bit - each bit select 1 mailbox in the group
} MbWait;

typedef struct _MbSignal {
    // DMA_SIG_SRC_CTRL
    uint8_t  src_en         = 0;
    uint8_t  src_mode       = 0;  // 0: command complete, 1: repeat complete
    uint8_t  src_brdcst_en  = 0;
    uint32_t src_brdcst_sel = 0;  // each bit select 1 producer which need signal to
    uint32_t src_addr       = 0;
    uint32_t src_data       = 0;
    uint32_t src_brdcst_addr[12];  // src broadcast address

    // DMA_SIG_DST_CTRL
    uint8_t  dst_en         = 0;
    uint8_t  dst_mode       = 0;  // 0: command complete, 1: repeat complete
    uint8_t  dst_brdcst_en  = 0;
    uint32_t dst_brdcst_sel = 0;  // each bit select 1 consumer which need signal to
    uint32_t dst_addr       = 0;
    uint32_t dst_data       = 0;
    uint32_t dst_brdcst_addr[12];  // dst broadcast address

    // DMA_SIG_CQM_CTRL
    uint8_t  cqm_en   = 0;
    uint8_t  cqm_mode = 0;  // 0: command complete, 1: repeat complete
    uint32_t cqm_addr = 0;
    uint32_t cqm_data = 0;
} MbSignal;

typedef struct _OpSlice {
    uint32_t src_dim_size[5];

    uint32_t slice_dim_start[4];
    uint32_t slice_dim_size[4];
} OpSlice;

typedef struct _DmaCtx {
    int vc_id    = -1;
    int queue_id = -1;

    DmaOpType op_type = DMA_OP_INVALID;

    DmaDir direction = DMA_DIR_INVALID;

    bool crc_en = false;

    uint64_t src_addr = 0;
    uint64_t dst_addr = 0;
    uint32_t src_size = 0;

    uint32_t fill_value = 0;

    uint8_t bpe = 0;

    MbWait   wait;
    MbSignal signal;

    OpSlice cfg_slice;
} DmaCtx;

}  // namespace gdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_GDMA_GDMA_CTX_H_
