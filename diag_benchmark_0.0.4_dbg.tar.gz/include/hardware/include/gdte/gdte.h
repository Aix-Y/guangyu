/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_GDTE_GDTE_H_
#define HARDWARE_INCLUDE_GDTE_GDTE_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "framework/include/mem.h"
#include "hardware/include/bpm.h"
#include "hardware/include/gdte/gdte_ctx.h"
#include "hardware/include/gdte/gdte_ras.h"
#include "hardware/include/hardware.h"
#include "hardware/include/mailbox.h"
#include "hardware/include/system_adapter.h"
#include "hardware/include/xmc/xmc.h"

using efvf::framework::mem::Mem;
using efvf::hardware::mailbox::Mailbox;
using efvf::hardware::pmc::Bpm;
using efvf::hardware::pmc::BpmResult;
using efvf::hardware::pmc::Pmc;
using efvf::hardware::system_adapter::SystemAdapter;
using efvf::hardware::xmc::Xmc;

namespace efvf {
namespace hardware {
namespace gdte {

class Gdte : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    Gdte();

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Gdte(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~Gdte() {}

    /**
     * @brief      deprecated pls use Copy instead.
     *
     * @param[in]  src_df_addr   The source df address
     * @param[in]  dest_df_addr  The destination df address
     * @param[in]  size          The size
     * @param[in]  offset        The offset
     * @param[in]  vc            { parameter_description }
     *
     * @return     deprecated pls use Copy instead.
     */
    virtual bool LinearCopy(const uint64_t &src_df_addr, const uint64_t &dest_df_addr,
        const uint32_t &size, const uint64_t &offset = 0, const int &vc = 0) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  src_df_addr   The source df address
     * @param[in]  dest_df_addr  The destination df address
     * @param[in]  src_off       The source off
     * @param[in]  dst_off       The destination off
     * @param[in]  size          The size
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool Copy(const uint64_t &src_df_addr, const uint64_t &dest_df_addr,
        uint64_t src_off = 0, uint64_t dst_off = 0, uint64_t size = 0, int timeout = 1000) = 0;

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  src_off  The source off
     * @param[in]  dst_off  The destination off
     * @param[in]  size     The size
     * @param[in]  timeout  ms
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool Copy(Mem *src, Mem *dst, uint64_t src_off = 0, uint64_t dst_off = 0,
        uint64_t size = 0, int timeout = 1000) = 0;

    /**
     * @brief      { function_description }
     *
     * @param      dst      The destination
     * @param[in]  pattern  The pattern
     * @param[in]  off      Off
     * @param[in]  size     The size
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FillConst(Mem *dst, uint32_t pattern, uint64_t off = 0, uint64_t size = 0,
        int timeout = 1000) = 0;

    /**
     * @brief      { function_description }
     *
     * @param      buf_addr The destination buffer address
     * @param      buf_size The destination buffer size
     * @param[in]  pattern  The pattern
     * @param[in]  off      Off
     * @param[in]  size     The size
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FillConst(uint64_t buf_addr, uint64_t buf_size, uint32_t pattern,
        uint64_t off = 0, uint64_t size = 0, int timeout = 1000) = 0;

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  src_off  The source off
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool Slice(
        Mem *src, Mem *dst, const std::vector<uint64_t> &src_off, int timeout = 1000) {
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  src_off  The source off
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool Slice(const uint64_t &src, const uint64_t &dst,
        const std::vector<uint32_t> &src_dim, const std::vector<uint32_t> &dst_dim,
        const std::vector<uint32_t> &offset, uint32_t bpe, int timeout = 1000) {
        LOG_ASSERT(false, "Not implemented!!!");
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  dst_off  The destination off
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool DeSlice(
        Mem *src, Mem *dst, const std::vector<uint64_t> &dst_off, int timeout = 1000) {
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  dst_off  The destination off
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool DeSlice(const uint64_t &src, const uint64_t &dst,
        const std::vector<uint32_t> &src_dim, const std::vector<uint32_t> &dst_dim,
        const std::vector<uint32_t> &offset, uint32_t bpe, int timeout = 1000) {
        LOG_ASSERT(false, "Not implemented!!!");
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  dst_off  The destination off
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SliceDeSlice(const uint64_t &src, const uint64_t &dst,
        const std::vector<uint32_t> &src_dim, const std::vector<uint32_t> &dst_dim,
        const std::vector<uint32_t> &src_off, const std::vector<uint32_t> &dst_off,
        const std::vector<uint32_t> &size, uint32_t bpe, int timeout = 1000) {
        LOG_ASSERT(false, "Not implemented!!!");
        return false;
    }

    /**
     * @brief      Sets the command packet.
     *
     * @param[in]  ctx   The new value
     * @param[in]  vc    The new value
     */
    virtual void SetCmdPkt(const DteVcCtx &ctx, int vc = 0) = 0;

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void FillCmdPkt(DteVcCtx *ctx) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  vc    { parameter_description }
     */
    virtual void Trigger(int vc, DteVcCtx *ctx = nullptr) = 0;

    /**
     * @brief      Determines whether the specified vc is vc busy.
     *
     * @param[in]  vc    { parameter_description }
     *
     * @return     True if the specified vc is vc busy, False otherwise.
     */
    virtual bool IsVcBusy(int vc = 0) = 0;

    /**
     * @brief      Determines whether the specified vc is vc occupy.
     *
     * @param[in]  vc    { parameter_description }
     *
     * @return     True if the specified vc is vc occupy, False otherwise.
     */
    virtual bool IsVcOccupy(int vc = 0) = 0;

    /**
     * @brief      Gets the vc status.
     *
     * @param      status  0 idle, 1 occpy, 2 busy
     */
    virtual void GetVcStatus(std::vector<int> &status) {}

    /**
     * @brief      Determines if optimize en.
     *
     * @return     True if optimize en, False otherwise.
     */
    virtual bool IsOptimizeEn() {
        return false;
    }

    /**
     * @brief      Determines if partial write en.
     *
     * @return     True if partial write en, False otherwise.
     */
    virtual bool IsPartialWriteEn() {
        return false;
    }

    /**
     * @brief      Determines if write combine en.
     *
     * @return     True if write combine en, False otherwise.
     */
    virtual bool IsWriteCombineEn() {
        return false;
    }

    /**
     * @brief      Dumps a vc information.
     *
     * @param[in]  vc    { parameter_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual void DumpVcInfo(bool only_abnormal) {}
    virtual void DumpOneVcInfo(int vc) {}

    /**
     * @brief      Gets the vc configuration for django.
     *
     * @param[in]  ctx   The context
     */
    virtual std::string GetVcCfgForDjango(const DteVcCtx &ctx) {
        return "";
    }

    /**
     * @brief      Determines if engine busy.
     *
     * @return     True if engine busy, False otherwise.
     */
    virtual bool IsEngineBusy() {
        return false;
    }

    /**
     * @brief      Determines if stop.
     *
     * @return     True if stop, False otherwise.
     */
    virtual bool IsEngineStop() {
        return false;
    }

    /**
     * @brief
     *
     * @return True if initialization done, False otherwise.
     */
    virtual bool IsEngineSramInitDone() {
        return false;
    }

    /**
     * @brief      wait vc idle Virtuals may have defaults. The defaults in the
     *             base class are not inherited by derived classes. A::f(int a =
     *             4) B::f(int a = 5) p = new B() p->f(), a = 4
     *
     * @param[in]  vc              { parameter_description }
     * @param[in]  timeout         The timeout (ms)
     * @param      ctx             The context
     * @param[in]  expect_timeout  The expect timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitVcIdle(int vc, uint64_t timeout = 10000, DteVcCtx *ctx = nullptr,
        bool expect_timeout = false) = 0;

    virtual bool WaitVcIdleNonBlock(int vc, int timeout) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  vc       { parameter_description }
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitVcOccupy(int vc, int timeout) = 0;

    /**
     * @brief      { function_description }
     */
    virtual bool WaitEngineIdle(int timeout) = 0;

    /**
     * @brief      Gets the operation type by string.
     *
     * @param[in]  type_string  The type string
     *
     * @return     The operation type by string.
     */
    virtual DteOpType GetOpTypeByStr(const std::string &type_string) = 0;

    /**
     * @brief      Gets the aliable vc.
     *
     * @return     The aliable vc.
     */
    virtual int GetAvaliableVc() = 0;

    /**
     * @brief      Gets the avaliable vc from last.
     *
     * @return     The avaliable vc from last.
     */
    virtual int GetAvaliableVcFromLast() {
        return -1;
    }

    /**
     * @brief      Gets the vc randomly.
     *
     * @return     The vc randomly.
     */
    virtual int GetVcRandomly() {
        return 0;
    }

    /**
     * @brief      Gets the avaliable vc.
     *
     * @return     The avaliable vc.
     */
    virtual inline int GetMbxEntry() {
        return -1;
    }

    /**
     * @brief      Gets the vc number.
     *
     * @return     The vc number.
     */
    virtual uint32_t get_vc_num() = 0;

    /**
     * @brief      Gets the valid dir.
     *
     * @return     The valid dir.
     */
    virtual const std::set<std::string> &get_valid_dir() = 0;

    /**
     * @brief      Gets the dir.
     *
     * @return     The dir.
     */
    virtual std::string GetDir() {
        return "d2d";
    }

    /**
     * @brief      Gets the thread mask.
     *
     * @return     The thread mask.
     */
    virtual uint32_t GetThreadMask() {
        return 0;
    }

    /**
     * @brief Get the random Noc Qos Initial Value.
     *
     * @return uint32_t
     */
    virtual uint32_t GetNocQosIniValue() {
        return 0;
    }

    /**
     * @brief      Gets the valid operation.
     *
     * @return     The valid operation.
     */
    virtual const std::set<DteOpType> &get_valid_op() = 0;

    /**
     * @brief      Gets the operation.
     *
     * @return     The operation.
     */
    virtual DteOpType GetOp() {
        return InvalidOpType;
    }

    /**
     * @brief      Gets the operation by iterator.
     *
     * @return     The operation by iterator.
     */
    virtual DteOpType GetOpByIter() {
        return InvalidOpType;
    }

    /**
     * @brief      Sets the operation iterator random.
     */
    virtual void SetOpIterRand() {}

    /**
     * @brief      Gets the operation type.
     *
     * @param[in]  vc    { parameter_description }
     *
     * @return     The operation type.
     */
    virtual uint32_t GetOpType(int vc) {
        return 0;
    }

    /**
     * @brief      Gets the vc sram register address.
     *
     * @param[in]  vc     { parameter_description }
     * @param[in]  index  The index
     *
     * @return     The vc sram register address.
     */
    virtual uint64_t GetVcSramRegAddr(int vc, uint32_t index) {
        return 0;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  vc    { parameter_description }
     */
    virtual void Invalidate(int vc = 0) {}

    /**
     * @brief      Gets the eng name.
     *
     * @return     The eng name.
     */
    virtual std::string GetEngName() {
        return "none";
    }

    /**
     * @brief      Gets the clock m hz.
     *
     * @return     The clock m hz.
     */
    virtual uint64_t GetClkMHz() {
        return 0;
    }

    /**
     * @brief      Gets the mail box.
     *
     * @return     The mail box.
     */
    virtual Mailbox *GetMailBox() {
        return nullptr;
    }

    /**
     * @brief      Gets the sa.
     *
     * @return     The sa.
     */
    virtual SystemAdapter *GetSa() {
        return nullptr;
    }

    virtual Hardware *GetMmuHw() {
        return nullptr;
    }

    /**
     * @brief      Gets the vc trigger address.
     *
     * @param[in]  vc    { parameter_description }
     *
     * @return     The vc trigger address.
     */
    virtual uint32_t GetVcTriggerAddr(int vc) {
        return 0;
    }

    /**
     * @brief      Gets the debug position.
     *
     * @return     The debug position.
     */
    virtual uint32_t GetDbgPos() {
        return 0;
    }

    /**
     * @brief      Gets the debug position.
     *
     * @return     The debug position.
     */
    virtual uint64_t GetDbgThdPos() {
        return 0;
    }

    virtual void DumpThdPos() {}

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void CalcDataTransformByCmodel(DteVcCtx *ctx) {}

    /**
     * @brief      Gets the l 2 loss status.
     *
     * @param      ctx   The context
     */
    virtual void GetL2LossStatus(DteVcCtx *ctx, int vc) {}

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  bl_list  The bl list
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetBL(const DteBurstLen &bl) {
        return false;
    }

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  burstlen  The burstlen
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetBL(uint32_t burstlen) {
        return false;
    }

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  burstlen  The burstlen
     *
     * @return     { description_of_the_return_value }
     */
    virtual void SetMaxBL() {}

    /**
     * @brief      Gets the bl.
     *
     * @return     The bl.
     */
    virtual DteBurstLen GetBL() {
        return DteBurstLen();
    }

    /**
     * @brief      Gets the maximum bl.
     *
     * @return     The maximum bl.
     */
    virtual uint32_t GetMaxBL() {
        return 0;
    }

    /**
     * @brief      Sets the signal.
     *
     * @param[in]  addr  The address
     * @param[in]  data  The data
     */
    virtual bool SetSignalSrc(uint32_t addr, uint32_t data, int vc = 0) {
        return false;
    }

    /**
     * @brief      Sets the signal sts.
     *
     * @param[in]  type  The type
     * @param[in]  sts   The new value
     */
    virtual void SetSignalSts(const std::string &type, int sts, int vc = 0) {}

    /**
     * @brief      Sets the debug misc.
     *
     * @param[in]  cfg   The new value
     *
     * @return     { description_of_the_return_value }
     */
    virtual void SetDbgMisc(const DebugMiscCfg &cfg) {}

    /**
     * @brief      Sets the reorder.
     *
     * @param[in]  status  The status
     */
    virtual void SetReorder(bool status) {}

    /**
     * @brief      Gets the bpm number.
     *
     * @return     The bpm number.
     */
    virtual uint32_t GetPortNum() {
        return 0;
    }

    /**
     * @brief      Gets the bpm.
     *
     * @param[in]  index  The index
     *
     * @return     The bpm.
     */
    virtual Bpm *GetBpm(int index) {
        return nullptr;
    }

    /**
     * @brief      Gets the dvfs.
     *
     * @param[in]  index  The index
     *
     * @return     The dvfs.
     */
    virtual Pmc *GetDvfs(int index) {
        return nullptr;
    }

    /**
     * @brief      { function_description }
     */
    virtual void DvfsPmcStart() {}

    /**
     * @brief      { function_description }
     */
    virtual void DvfsPmcStop() {}

    /**
     * @brief      Gets the dvfs result.
     *
     * @param      result  The result
     */
    virtual void GetDvfsResult(DvfsResult &result) {}

    /**
     * @brief      Gets the performance pmc.
     *
     * @return     The performance pmc.
     */
    virtual Pmc *GetPerfPmc() {
        return nullptr;
    }

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStart() {}

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStop() {}

    /**
     * @brief      Gets the busy cycle.
     */
    virtual uint64_t GetBusyCycle() {
        return 1;
    }

    virtual double GetBusyRate() {
        return 0;
    }

    /**
     * @brief      { function_description }
     */
    virtual void EnClkGate() {}

    /**
     * @brief Enable or disable rshp ifb mode
     *
     * @param enable
     */
    virtual void EnRshpIfbMode(bool enable) {}

    /**
     * @brief Enable or disable dynamic queue
     *
     * @param enable
     */
    virtual void EnDynamicQueue(bool enable) {}

    /**
     * @brief      Enables the bpm.
     *
     * @param[in]  cycle  The cycle
     */
    virtual void EnableBpm(uint64_t cycle) {}

    /**
     * @brief      Gets the bpm w thro.
     *
     * @param[in]  idex  The idex
     * @param      res   The resource
     */
    virtual void GetBpmResult(int index, BpmResult *res) {}

    /**
     * @brief      Prints a bpm status.
     *
     */
    virtual void PrintBpmStatus() {}

    /**
     * @brief      { function_description }
     */
    virtual void EnCrc(uint32_t port, int vc = -1) {}

    /**
     * @brief      Gets the crc value.
     *
     * @return     The crc value.
     */
    virtual uint32_t GetCrcVal() {
        return 0;
    }

    /**
     * @brief      Calc data crc value.
     *
     * @param[in]  src_addr     The src buffer address
     * @param[in]  dst_addr     The dst buffer address
     * @param[in]  size         Calc crc data size
     * @param[in]  timeout      timeout value
     * @return     The crc value.
     */
    virtual uint32_t CalcDataCrc(
        uint64_t src_addr, uint64_t dst_addr, uint64_t size, int timeout = 1000) {
        return 0;
    }

    /**
     * @brief      Sets the throttle.
     *
     * @param[in]  window  The window
     * @param[in]  rd_bw   The rd bd
     * @param[in]  wr_bw   The wr bd
     * @param[in]  rd_os   The rd operating system
     * @param[in]  wr_os   The wr operating system
     */
    virtual void SetThrottle(
        uint32_t window, uint32_t rd_bw, uint32_t wr_bw, uint32_t rd_os, uint32_t wr_os) {}

    /**
     * @brief      Sets the port throttle.
     *
     * @param[in]  port    The port
     * @param[in]  window  The window
     * @param[in]  rd_bw   The rd bd
     * @param[in]  wr_bw   The wr bd
     * @param[in]  rd_os   The rd operating system
     * @param[in]  wr_os   The wr operating system
     */
    virtual void SetPortThrottle(int port, uint32_t window, uint32_t rd_bw, uint32_t wr_bw,
        uint32_t rd_os, uint32_t wr_os) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  p     { parameter_description }
     *
     * @return     The hsdc data.
     */
    virtual void GenHsdcData(HsdcPkt &p) {}

    /**
     * @brief      Sets the hsdc minimum scp.
     *
     * @param[in]  gid   The new value
     * @param[in]  val   The new value
     */
    virtual void SetHsdcMinScp(uint32_t gid, uint32_t val) {}

    /**
     * @brief      Sets the hsdc maximum scp.
     *
     * @param[in]  gid   The new value
     * @param[in]  val   The new value
     */
    virtual void SetHsdcMaxScp(uint32_t gid, uint32_t val) {}

    /**
     * @brief      Sets the hsdc minimum gscp.
     *
     * @param[in]  gid   The new value
     * @param[in]  val   The new value
     */
    virtual void SetHsdcMinGscp(uint32_t gid, uint32_t val) {}

    /**
     * @brief      Sets the hsdc maximum gscp.
     *
     * @param[in]  gid   The new value
     * @param[in]  val   The new value
     */
    virtual void SetHsdcMaxGscp(uint32_t gid, uint32_t val) {}

    /**
     * @brief      Sets the hsdc minimum gscpc.
     *
     * @param[in]  gid   The new value
     * @param[in]  val   The new value
     */
    virtual void SetHsdcMinGscpc(uint32_t gid, uint32_t val) {}

    /**
     * @brief      Sets the wr combine.
     *
     * @param[in]  status    The status 0 or 1
     * @param[in]  wait_num  The wait number
     */
    virtual void SetWrCombine(uint32_t status, uint32_t wait_num) {}

    /**
     * @brief      Sets the partial wr.
     *
     * @param[in]  val   The new value 0 or 1
     */
    virtual void SetPartialWr(uint32_t val) {}

    /**
     * @brief      DTE time out threshold value; unit is 128 DTE clock cycles.
     *
     * @param[in]  val   The new value
     */
    virtual void SetTimeout(uint32_t val) {}

    /**
     * @brief      Sets the error stop.
     *
     * @param[in]  val   0 or 1
     */
    virtual void SetErrStop(uint32_t val) {}

    /**
     * @brief Set the Customized Trace Message Enable or not.
     *
     * @param val
     */
    virtual void SetCusTraceMesg(uint32_t val) {}

    /**
     * @brief      Sets the software stop.
     *
     * @param[in]  val   The new value
     */
    virtual void SetSwStop(uint32_t val, uint32_t stop_sig) {}

    /**
     * @brief      Sets the invld vc clr mbx en.
     *
     * @param[in]  status  The status
     */
    virtual void SetInvldVcClrMbxEn(uint32_t status) {}

    /**
     * @brief      Sets the ih cause address.
     *
     * @param[in]  addr  The address
     */
    virtual void SetIhCauseAddr(uint32_t addr) {}

    /**
     * @brief Set the customized event agent cause address.
     *
     * @param addr
     */
    virtual void SetCusEvntAgentCauseAddr(uint32_t addr) {}

    /**
     * @brief      Gets the eng control address.
     */
    virtual uint64_t GetEngCtrlAddr() {
        return 0;
    }

    /**
     * @brief      Gets the eng control value.
     */
    virtual uint32_t GetEngCtrlVal() {
        return 0;
    }

    /**
     * @brief      Gets the timeout control address.
     *
     * @return     The timeout control address.
     */
    virtual uint64_t GetTimeoutCtrlAddr() {
        return 0;
    }

    /**
     * @brief      { function_description }
     */
    virtual void SetDataSramParityErr(bool status) {}

    /**
     * @brief      { function_description }
     */
    virtual void SetRegSramParityErr(bool status) {}

    /**
     * @brief      Sets the hit ratio.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetHitRatio(const HitRatioCfg &cfg) {}

    /**
     * @brief      Shows the operation description.
     */
    virtual void ShowOpDesc() {}

    /**
     * @brief      Sets the order list pri.
     *
     * @param[in]  status  The status
     */
    virtual void SetOrderListPri(int status) {}

    /**
     * @brief Set whether enable register sram initialization.
     *
     * @param enbale
     */
    virtual void SetSramInit(bool enable) {}

    /**
     * @brief Force trigger interrupt.
     *
     * @param cfg
     */
    virtual void ForceTriggerInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief      Encrypt data by Xts Cmodel
     *
     * @param[in]  key
     * @param[in]  key_sel
     * @param[in]  tweak
     * @param[in]  step
     * @param[in]  block_size
     * @param[in]  format
     * @param[in]  date_size
     * @param[in]  ori_data
     * @param[in]  encrypt_data
     */
    virtual void EncryptDataByXtsCmodel(uint8_t *key, uint32_t key_sel, uint8_t *tweak,
        uint32_t step, uint32_t block_size, uint8_t format, uint64_t date_size,
        uint8_t *ori_data, uint8_t *encrypt_data) {}

    /**
     * @brief      Decrypt data by Xts Cmodel
     *
     * @param[in]  key
     * @param[in]  key_sel
     * @param[in]  tweak
     * @param[in]  step
     * @param[in]  block_size
     * @param[in]  format
     * @param[in]  date_size
     * @param[in]  encrypt_data
     * @param[in]  decrypt_data
     */
    virtual void DecryptDataByXtsCmodel(uint8_t *key, uint32_t key_sel, uint8_t *tweak,
        uint32_t step, uint32_t block_size, uint8_t format, uint64_t date_size,
        uint8_t *encrypt_data, uint8_t *decrypt_data) {}

    /**
     * @brief      Calculate data by Xts Cmodel
     *
     * @param[in]  p_in_data
     * @param[in]  size
     * @param[in]  offset
     * @param[in]  step
     *
     * @return     CRC32 value
     */
    virtual uint32_t CalcDataCrcByXtsCmodel(
        uint8_t *p_in_data, uint64_t size, uint64_t offset = 0, uint64_t step = 4) {}
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_GDTE_GDTE_H_
