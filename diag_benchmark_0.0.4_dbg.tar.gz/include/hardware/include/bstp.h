/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file bstp.h
    \brief define a common boost pipe lib
 */

#ifndef HARDWARE_INCLUDE_BSTP_H_
#define HARDWARE_INCLUDE_BSTP_H_

#include <memory>
#include <string>
#include <vector>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace bstp {

class BstpRasErrStat : public RasErrStat {
 public:
    uint32_t cecc_err_status : 1;
    uint32_t uecc_err_status : 1;
    uint32_t inner_err_status : 1;
    uint32_t : 29;
    uint32_t cecc_err_log_0;
    uint32_t cecc_err_log_1;
    uint32_t cecc_err_log_2;
    uint32_t cecc_err_log_3;
    uint32_t cecc_err_log_4;
    uint32_t uecc_err_log_0;
    uint32_t uecc_err_log_1;
    uint32_t uecc_err_log_2;
    uint32_t uecc_err_log_3;
    uint32_t uecc_err_log_4;

    BstpRasErrStat() {
        cecc_err_status  = 0;
        uecc_err_status  = 0;
        inner_err_status = 0;

        cecc_err_log_0 = 0;
        cecc_err_log_1 = 0;
        cecc_err_log_2 = 0;
        cecc_err_log_3 = 0;
        cecc_err_log_4 = 0;
        uecc_err_log_0 = 0;
        uecc_err_log_1 = 0;
        uecc_err_log_2 = 0;
        uecc_err_log_3 = 0;
        uecc_err_log_4 = 0;
    }
};

class BstpRasErrInj : public RasErrInj {
 public:
    std::string inj_type;

    BstpRasErrInj() {
        inj_type = "";
    }
};

class BstpRas : public efvf::hardware::IRas {};

/*!
 * @brief Bstpbase lib
 */
class Bstp : public Hardware {
 public:
    /*!
     * @brief Bstp constructors
     */
    explicit Bstp(std::shared_ptr<spdlog::logger> logger);

    /*!
     * @brief desctructor
     */
    virtual ~Bstp();

 public:
    /*!
      * @brief get bstp error status
      */
    virtual bool BstpGetErrStat(void) = 0;

    /*!
      * @brief clean error status
      */
    virtual void BstpClearErrStat(void) = 0;

    /*!
      * @brief start error inject
      */
    virtual void BstpStartErrInject(std::string inj_type) = 0;

    /*!
      * @brief stop error inject
      */
    virtual void BstpStopErrInject(std::string inj_type) = 0;

    /*!
      * @brief dump bstp channel debug info
      */
    virtual void BstpChnlDebugDump(std::vector<std::string> &infos) = 0;

 protected:
    std::shared_ptr<Hpd> hpd_;
};

}  // namespace bstp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_BSTP_H_
