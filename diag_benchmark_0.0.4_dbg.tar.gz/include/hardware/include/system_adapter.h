/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SYSTEM_ADAPTER_H_
#define HARDWARE_INCLUDE_SYSTEM_ADAPTER_H_

#include <cstdint>
#include <memory>
#include <vector>

#include "hardware/include/abmp.h"
#include "hardware/include/absp.h"
#include "hardware/include/bpm.h"
#include "hardware/include/ecmo.h"
#include "hardware/include/hardware.h"
#include "hardware/include/message_collector.h"
#include "hardware/include/pmc.h"
#include "hardware/include/raf.h"
#include "hardware/include/xmc/xmc.h"

using efvf::hardware::abmp::Abmp;
using efvf::hardware::absp::Absp;
using efvf::hardware::xmc::Xmc;
using efvf::hardware::ecmo::Ecmo;
using efvf::hardware::message_collector::MessageCollector;
using efvf::hardware::pmc::Pmc;
using efvf::hardware::pmc::Bpm;
using efvf::hardware::raf::Raf;

namespace efvf {
namespace hardware {
namespace system_adapter {

//!
//! @brief System adapter base lib
//!
//! It is a wrapper to get all its internal components
//!
class SystemAdapter : public Hardware {
 public:
    explicit SystemAdapter(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}
    virtual ~SystemAdapter() = default;

    // TODO(baolei): add slave misc regmodel?
    //!
    //! @brief configure AxUser info
    //!
    //! @param master_id: 10-bit master id, -1 if no change of it
    //! @param die_id: 1 bit die id, -1 if no change of it
    //! @param context_id: 4 bit context id, -1 if no change of it
    //! @param asid: 4 bit asid, -1 if no change of it
    //!
    virtual void SetAxUser(int32_t master_id, int32_t die_id = -1, int32_t context_id = -1,
        int32_t asid = -1)       = 0;
    virtual uint32_t GetAxUser() = 0;

    // cf_regmodel
    virtual Xmc * cf_slave_xmc()      = 0;
    virtual Xmc * cf_master_xmc()     = 0;
    virtual Ecmo *cf_slave_ecmo()     = 0;
    virtual Ecmo *cf_master_ecmo()    = 0;
    virtual Absp *cf_slave_absp()     = 0;
    virtual Absp *extcf_slave_absp()  = 0;
    virtual Abmp *cf_master_abmp()    = 0;
    virtual Abmp *extcf_master_abmp() = 0;
    virtual Raf * raf()               = 0;

    // ip_regmodel
    virtual Pmc *             pmc() = 0;
    virtual MessageCollector *mc()  = 0;

    // df_regmodel
    virtual Ecmo *df_master_ecmo(int index = 0) = 0;
    virtual Ecmo *df_slave_ecmo(int index = 0) = 0;
    virtual Xmc *df_master_xmc(int index = 0) = 0;
    virtual Abmp *df_master_abmp(int index = 0) = 0;
    virtual Absp *df_slave_absp(int index = 0) = 0;
    virtual Bpm *bpm(int index = 0) = 0;
};

}  // namespace system_adapter
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SYSTEM_ADAPTER_H_
