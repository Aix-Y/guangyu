/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_ESL_ESL_RAS_H_
#define HARDWARE_INCLUDE_ESL_ESL_RAS_H_

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace esl {

class EslRasCfg : public efvf::hardware::RasCfg {
 public:
    bool     parity_check = true;
    bool     resp_check   = true;
    bool     sa_err_int   = false;
    bool     esl_err_int  = true;
    uint32_t mask_0       = 0;
    uint32_t mask_1       = 0;
};

class EslRasErrInj : public efvf::hardware::RasErrInj {
 public:
    bool     sram_ecc_err;
    bool     sram_uecc_err;
    uint32_t value;
    uint32_t sub_type;
    uint32_t count;
};

class EslRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t status_0 = 0;
    uint32_t status_1 = 0;
};

// class EslIntrptCfg : public efvf::hardware::IntrptCfg {
// };

// class EslIntrptStat : public efvf::hardware::IntrptStat {
// };

class EslRas : public efvf::hardware::IRas {};

}  // namespace esl
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_ESL_ESL_RAS_H_
