/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_PROFILER_PARSER_H_
#define HARDWARE_INCLUDE_PROFILER_PARSER_H_

#include <fstream>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include "boost/property_tree/json_parser.hpp"
#include "boost/property_tree/ptree.hpp"

#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace profiler {

//!
//! @brief supported event masters
//!
//! evnets from masters other than sip and dma will not be parsed currently
//!
enum class DpfMasterType {
    SIP,
    DMA,
    VPP,
    CVA,
    // seperate cdte and odte for customized event
    CDTE,
    ODTE,
    VPU,
    AP,
    UNKNOWN,
};

//!
//! @brief profiling event info
//!
typedef struct {
    uint32_t              packet_id;
    std::vector<uint64_t> counters;
} ProfilingEvent;

//!
//! @brief trace event info
//!
typedef struct {
    uint16_t type;
    uint32_t packet_id;
    uint64_t timestamp;

    // following field added in 4.0
    uint8_t  context_id;
    uint8_t  die_id;
    uint8_t  asid;
    uint16_t pid;
    uint16_t master_id;
    uint16_t thread_id;  // for sip only
} TraceEvent;

typedef struct {
    uint8_t  op_type;
    uint8_t  bpe;
    uint32_t packet_id;
    std::array<uint32_t, 4> src_dim_sizes;
    std::array<uint32_t, 4> dst_dim_sizes;
    uint32_t dim4_size;
    uint64_t src_total_size;
    uint64_t dst_total_size;
    uint64_t src_addr;
    uint64_t dst_addr;
} GdteCustomizedEventContent;

typedef struct {
    uint8_t len;
    std::array<uint32_t, 16> contents;
} SipCustomizedEventContent;

//! TODO(baolei): add support for sip
union CustomizedEventContent {
    GdteCustomizedEventContent gdte_content;
    // TODO(baolei): any other master's content is the same as sip?
    SipCustomizedEventContent sip_content;
};

//!
//! @brief customized event info
//!
//! added in 4.0
//!
typedef struct {
    uint8_t                type;
    uint8_t                die_id;
    uint8_t                context_id;
    uint16_t               pid;
    uint16_t               master_id;
    uint64_t               timestamp;
    DpfMasterType          engine_type;
    CustomizedEventContent content;
} CustomizedEvent;

class ProfilerRing;
class Parser {
 public:
    explicit Parser(ProfilerRing *ring);
    virtual ~Parser() = default;

    //!
    //! @brief parse all events in corresponding specified system buffer
    //!
    //! by default, all 8 counters' valid length is 4B
    //!
    virtual void Parse(
        std::string filename = "", std::vector<uint8_t> len = std::vector<uint8_t>(8, 4)) = 0;

    //!
    //! @brief duration between master's first event and last event
    //!
    virtual uint64_t GetDuration(uint16_t master_id) {
        return -1;
    }

    //!
    //! @brief duration between first event and last event
    //!
    virtual uint64_t GetOverallDuration() {
        return -1;
    }

    //!
    //! @brief get duration from first valid event to last valid event
    //!
    //! it doesn't parse all events. It finds the first and the last valid event,
    //! and, calculate the duration. It will much faster than Parser() for
    //! large event number
    virtual uint64_t GetDuration() {
        return -1;
    }

    //!
    //! @brief print summary of parsed result
    //!
    virtual void PrintSummary() = 0;
    virtual void PrintTraceEvents() {}

    //!
    //! @brief Find the timestamp of a specific event from a given master
    //!
    virtual uint64_t GetEventTimestamp(
        uint32_t master_id, uint8_t event_type, uint32_t index, bool reverve = false);

    virtual uint64_t GetEventTimestamp(uint32_t master_id, uint16_t event_type,
        uint16_t event_mask, uint32_t index, bool reverve = false);

    //!
    //! @brief write parsed results to file
    //!
    virtual void WritetoFile(const std::string &filename) {}

    virtual DpfMasterType GetMasterType(uint32_t master_id) = 0;
    virtual std::string GetMasterName(uint32_t master_id)   = 0;
    //! accessors
 public:
    ProfilerRing *profiler_ring() {
        return profiler_ring_;
    }
    std::map<uint32_t, std::vector<ProfilingEvent>> profiling_events() {
        return profiling_events_;
    }
    std::map<uint32_t, std::vector<TraceEvent>> trace_events() {
        return trace_events_;
    }
    std::map<uint32_t, std::vector<CustomizedEvent>> customized_events() {
        return customized_events_;
    }
    std::map<uint32_t, std::map<uint32_t, std::vector<uint8_t>>> log_buffer_data() {
        return log_buffer_events_;
    }

 protected:
    //!
    //! @brief logger
    //!
    std::shared_ptr<spdlog::logger> logger_;
    //!
    //! @brief key: master id; val: profiling events
    //!
    std::map<uint32_t, std::vector<ProfilingEvent>> profiling_events_;
    //!
    //! @brief key: master id; val: trace events
    //!
    std::map<uint32_t, std::vector<TraceEvent>> trace_events_;
    //!
    //! @brief key: master id; val: customized events
    //!
    std::map<uint32_t, std::vector<CustomizedEvent>> customized_events_;
    //!
    //! @brief 1st key: process id; 2nd key: master id; val: log buffer data
    //!
    std::map<uint32_t, std::map<uint32_t, std::vector<uint8_t>>> log_buffer_events_;

 private:
    //!
    //! @brief pointer to profiler that this parser attaches to
    //!
    ProfilerRing *profiler_ring_ = nullptr;
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_PROFILER_PARSER_H_
