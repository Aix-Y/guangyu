/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_DTM_CTX_H_
#define HARDWARE_INCLUDE_DTM_CTX_H_

#include <bitset>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "framework/include/mem.h"
#include "hardware/include/sip/ctx/ctx.h"
#include "hardware/include/vpu/vpu.h"

using efvf::framework::mem::Mem;
using efvf::hardware::sip::ctx::CtxConfig;

using efvf::hardware::codec::CodecConfig;
using efvf::hardware::vpu::EvpCfg;
using efvf::hardware::vpu::Vpu;

namespace efvf {
namespace hardware {
namespace dtm {

#define MAX_XPU (2)
/* cache type */
enum class Ctype {
    NC = 0,  // non-cache
    WB,      // write back
    WT,      // write through
};

/* cache line alloc policy */
enum class CAllocPolicy {
    NO_ALLOC,
    RD_ALLOC,
    WR_ALLOC,
    RW_ALLOC,
};

enum class CExtWorkMode {
    Sector,
    Normal,
};

enum class CExtRepPri {
    STREAM,
    NORMAL,
    RESIDENCY,
};

// clang-format off
static std::map<std::string, Ctype> ctype_maps = {
    {"nc", Ctype::NC},
    {"wb", Ctype::WB},
    {"wt", Ctype::WT},
};

static std::map<std::string, CAllocPolicy> calloc_maps = {
    {"no_alloc", CAllocPolicy::NO_ALLOC},
    {"rd_alloc", CAllocPolicy::RD_ALLOC},
    {"wr_alloc", CAllocPolicy::WR_ALLOC},
    {"rw_alloc", CAllocPolicy::RW_ALLOC},
};

static std::map<std::string, CExtWorkMode> cmode_maps = {
    {"sector", CExtWorkMode::Sector},
    {"normal", CExtWorkMode::Normal},
};

static std::map<std::string, CExtRepPri> cpriority_maps = {
    {"stream", CExtRepPri::STREAM},
    {"normal", CExtRepPri::NORMAL},
    {"residency", CExtRepPri::RESIDENCY},
};
// clang-format on

class L2CacheCfg {
 public:
    L2CacheCfg()
        : ctype_(Ctype::NC),
          alloc_(CAllocPolicy::NO_ALLOC),
          hwpf_hint_(false),
          hit_ratio_(0),
          repl_pri0_(CExtRepPri::NORMAL),
          repl_pri1_(CExtRepPri::STREAM),
          cache_mode_(CExtWorkMode::Sector) {}

    L2CacheCfg(Ctype ctype, CAllocPolicy alloc, bool hwpf_hint, uint32_t hit_ratio,
        CExtRepPri rep_pri0, CExtRepPri rep_pri1,
        CExtWorkMode cache_mode = CExtWorkMode::Sector)
        : ctype_(ctype),
          alloc_(alloc),
          hwpf_hint_(hwpf_hint),
          hit_ratio_(hit_ratio),
          repl_pri0_(rep_pri0),
          repl_pri1_(rep_pri1),
          cache_mode_(cache_mode) {}

    L2CacheCfg(std::string &ctype, std::string &calloc, bool hwpf_hint, uint32_t hit_ratio,
        std::string &repl_pri0, std::string &repl_pri1, std::string &cmode) {
        assert(cmode_maps.find(cmode) != cmode_maps.end());
        assert(ctype_maps.find(ctype) != ctype_maps.end());
        assert(calloc_maps.find(calloc) != calloc_maps.end());
        assert(cpriority_maps.find(repl_pri0) != cpriority_maps.end());
        assert(cpriority_maps.find(repl_pri1) != cpriority_maps.end());
        cache_mode_ = cmode_maps[cmode];
        ctype_      = ctype_maps[ctype];
        alloc_      = calloc_maps[calloc];
        hwpf_hint_  = hwpf_hint;
        hit_ratio_  = hit_ratio;
        repl_pri0_  = cpriority_maps[repl_pri0];
        repl_pri1_  = cpriority_maps[repl_pri1];
    }

    std::vector<std::string> GetCfgInfoStr(bool concise = false) {
        auto get_key = [](auto &map, auto &value) {
            for (auto it = map.begin(); it != map.end(); it++) {
                if (it->second == value) {
                    return it->first;
                }
            }
        };

        auto ctype     = get_key(ctype_maps, ctype_);
        auto cmode     = get_key(cmode_maps, cache_mode_);
        auto calloc    = get_key(calloc_maps, alloc_);
        auto hw_pfen   = std::to_string(hwpf_hint_);
        auto hit_ratio = std::to_string(hit_ratio_);
        auto rpl_pri0  = get_key(cpriority_maps, repl_pri0_);
        auto rpl_pri1  = get_key(cpriority_maps, repl_pri1_);
        if (concise) {
            return std::vector<std::string>({ctype, calloc, hw_pfen});
        } else {
            return std::vector<std::string>(
                {ctype, cmode, calloc, hw_pfen, hit_ratio, rpl_pri0, rpl_pri1});
        }
    }

    ~L2CacheCfg() {}

    void FillMemReq(efvf::framework::mem::MemReq &req) {
        req.hit_ratio       = hit_ratio_;
        req.cache_priority0 = (repl_pri0_ == CExtRepPri::STREAM)
                                  ? 0
                                  : (repl_pri0_ == CExtRepPri::NORMAL) ? 1 : 2;
        req.cache_priority1 = (repl_pri1_ == CExtRepPri::STREAM)
                                  ? 0
                                  : (repl_pri1_ == CExtRepPri::NORMAL) ? 1 : 2;
        if (ctype_ == Ctype::NC)
            req.ctype_ = efvf::framework::mem::CACHE_TYPE_UNCACHABLE;
        else if (ctype_ == Ctype::WB && alloc_ == CAllocPolicy::NO_ALLOC)
            req.ctype_ = efvf::framework::mem::CACHE_TYPE_WRBACK_NOALLOC;
        else if (ctype_ == Ctype::WT && alloc_ == CAllocPolicy::NO_ALLOC)
            req.ctype_ = efvf::framework::mem::CACHE_TYPE_WRTHRU_NOALLOC;
        else if (ctype_ == Ctype::WB)
            req.ctype_ = efvf::framework::mem::CACHE_TYPE_WRBACK;
        else if (ctype_ == Ctype::WT)
            req.ctype_ = efvf::framework::mem::CACHE_TYPE_WRTHRU;
        else
            req.ctype_ = efvf::framework::mem::CACHE_TYPE_FAULT;
    }

    Ctype        ctype_;
    CAllocPolicy alloc_;
    bool         hwpf_hint_;
    uint32_t     hit_ratio_;
    CExtRepPri   repl_pri0_;
    CExtRepPri   repl_pri1_;
    CExtWorkMode cache_mode_;
};

struct DtmEngineId {
    std::string      engine;
    std::vector<int> loc;
};

struct MmapTable {
    MmapTable(uint64_t pa, uint64_t sz, uint64_t va = 0ULL) : paddr(pa), size(sz), vaddr(va) {}
    ~MmapTable() {}

    uint64_t paddr;
    uint64_t size;

    /* cache attribute */
    L2CacheCfg cache;

    uint64_t GetVaddr() const {
        return vaddr;
    }

 private:
    uint64_t vaddr;
};

struct SipTaskParam {
    // std::bitset<64>      sip_mask;
    std::bitset<MAX_XPU>     xpu_mask;
    std::vector<Mem *>       code_mem;
    std::vector<std::string> code_filenames;
    /* vdmem */
    std::vector<Mem *>    vdata_mem;
    std::vector<uint32_t> vdata_offset;  // offset per xpu
    /* sdmem */
    std::vector<Mem *>    sdata_mem;
    std::vector<uint32_t> sdata_offset;  // offset per xpu

    //
    uint64_t remote_stack_addr;
    uint32_t remote_stack_size;

    std::vector<CtxConfig> configs;
    std::vector<MmapTable> mmaps;
    bool                   check_halt = true;
    int                    main_xpu   = -1;
};

class VpuTaskParam {
 public:
    Vpu *                 vpu;
    uint32_t              cmd_type;  // 0 - dec, 1 - evp
    uint32_t              inst;      // dec or evp instance
    EvpCfg *              evp_cfg;
    CodecConfig *         codec_cfg;
    std::vector<Mem *>    in_data_mem;
    std::vector<uint32_t> in_data_size;
    std::vector<Mem *>    out_data_mem;
    std::vector<uint32_t> frame_gld_crc;
    VpuTaskParam() : vpu(nullptr), cmd_type(0), evp_cfg(nullptr), codec_cfg(nullptr) {
        in_data_mem.clear();
        in_data_size.clear();
        out_data_mem.clear();
        frame_gld_crc.clear();
    }
};

struct SipIcacheCtrl {
    bool icache_mode;
    bool icache_hw_prefetch;
    SipIcacheCtrl() : icache_mode(true), icache_hw_prefetch(true) {}
};

struct SipHwResource {
    // l2_size
    // cdte_vc
};

struct KernelContext {
    int             group_id = -1;  // VG or Cluster id
    std::bitset<64> sip_mask;
    int             sic;
    SipTaskParam    sip_params;
    SipIcacheCtrl   icache;

    /* hw_resource */
    SipHwResource hw_resource;
};

}  // namespace dtm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_DTM_CTX_H_
