/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CLUSTER_CCU_H_
#define HARDWARE_INCLUDE_CLUSTER_CCU_H_

#endif  // HARDWARE_INCLUDE_CLUSTER_CCU_H_
