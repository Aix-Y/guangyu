/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_CLUSTER_CLUSTER_H_
#define HARDWARE_INCLUDE_CLUSTER_CLUSTER_H_

#include <memory>
#include "hardware/include/cluster/csb.h"
#include "hardware/include/hardware.h"

using efvf::hardware::cluster::csb::Csb;

namespace efvf {
namespace hardware {
namespace cluster {
class Cluster : public Hardware {
 public:
    Cluster() : Hardware() {}
    explicit Cluster(std::shared_ptr<spdlog::logger> logger);
    virtual ~Cluster() {}

    virtual Csb *GetCsb(uint8_t csb_id) = 0;
    virtual Hardware *GetCcu()          = 0;
    virtual uint16_t  GetClusterNum()   = 0;
    virtual uint16_t  GetCsbNum()       = 0;
};

}  // namespace cluster
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_CLUSTER_CLUSTER_H_
