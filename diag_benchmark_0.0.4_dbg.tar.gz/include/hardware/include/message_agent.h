/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MESSAGE_AGENT_H_
#define HARDWARE_INCLUDE_MESSAGE_AGENT_H_

#include <memory>
#include <vector>

#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace message_collector {

//! lenght -> byte masks
enum CounterValidLength {
    COUNTER_VALID_LEN_1B = 0x1,
    COUNTER_VALID_LEN_2B = 0x3,
    COUNTER_VALID_LEN_3B = 0x7,
    COUNTER_VALID_LEN_4B = 0xf,
    COUNTER_VALID_LEN_5B = 0x1f,
    COUNTER_VALID_LEN_6B = 0x3f
};

inline CounterValidLength toCounterValidLength(uint8_t bytes) {
    switch (bytes) {
        case 1:
            return COUNTER_VALID_LEN_1B;
        case 2:
            return COUNTER_VALID_LEN_2B;
        case 3:
            return COUNTER_VALID_LEN_3B;
        case 4:
            return COUNTER_VALID_LEN_4B;
        case 5:
            return COUNTER_VALID_LEN_5B;
        case 6:
            return COUNTER_VALID_LEN_6B;
        default:
            throw std::runtime_error("Invalid byte number for valid pmc counter length");
    }
}

//!
//! @brief message agent lib
//!
//! it is base class for all agents. It provides general functions like enable/disable
//! agent and set agent target address.
//!
class MessageCollector;
class MessageAgent {
 public:
    MessageAgent(MessageCollector *mc, uint8_t index);
    virtual ~MessageAgent() = default;

 public:
    //! @brief register read/write
    //! @param offset: register offset in message collector
    //! @param val: new value to write
    uint32_t RegRead(uint32_t offset);
    void RegWrite(uint64_t offset, uint32_t val);

 public:
    //! @brief enable/disable message agent
    virtual void Enable()  = 0;
    virtual void Disable() = 0;

    //! @brief set message agent's target address
    //!
    //! @param addr: target address. It is a CF address that receives events.
    //!
    //! For interrupt agent, the target address should be MIH.
    //! For trace event agent, profiling agent, l2loss agent, and log agent, the target address
    //! should be DPF.
    virtual void SetTargetAddr(uint32_t addr) = 0;

 public:
    //! accessors
    uint8_t index() {
        return index_;
    }
    MessageCollector *mc() {
        return mc_;
    }

 protected:
    std::shared_ptr<spdlog::logger> logger_;

 private:
    MessageCollector *mc_;
    uint8_t           index_;
};

class ProfilingAgent : virtual public MessageAgent {
 public:
    explicit ProfilingAgent(MessageCollector *mc, uint8_t index) : MessageAgent(mc, index) {}
    virtual ~ProfilingAgent() = default;

 public:
    //!
    //! @brief configure valid length for pmc counters
    //!
    //! It is for profiling agent only
    //!
    //! @param vlen: specify the valid length
    //! @param index: specify counter index, -1 if all counters
    virtual void CfgCounterByteNum(CounterValidLength vlen, int index = -1) = 0;
    //!
    //! @brief configure profiling event's package ID
    //!
    //! @param package_id: specify the package_id
    virtual void CfgPackageId(uint32_t package_id) = 0;
};

class InterruptAgent : virtual public MessageAgent {
 public:
    explicit InterruptAgent(MessageCollector *mc, uint8_t index) : MessageAgent(mc, index) {}
    virtual ~InterruptAgent() = default;

 public:
    //!
    //! @brief set interrupt data for specific interrupt line
    //!
    //! It is for interrupt agent only
    //!
    //! @param data: specify the interrupt data
    //! @param index: specify counter index
    virtual void SetInterruptData(uint32_t data, uint8_t interrupt_id) = 0;
};

class TraceEventAgent : virtual public MessageAgent {
 public:
    explicit TraceEventAgent(MessageCollector *mc, uint8_t index) : MessageAgent(mc, index) {}
    virtual ~TraceEventAgent() = default;

    virtual bool Init() {
        return true;
    }
    virtual uint32_t GetDropCount() {
        return 0;
    }
};

class CustomizedEventAgent : virtual public MessageAgent {
 public:
    explicit CustomizedEventAgent(MessageCollector *mc, uint8_t index)
        : MessageAgent(mc, index) {}
    virtual ~CustomizedEventAgent() = default;
};

class LogBufferAgent : virtual public MessageAgent {
 public:
    explicit LogBufferAgent(MessageCollector *mc, uint8_t index) : MessageAgent(mc, index) {}
    virtual ~LogBufferAgent() = default;

 public:
    //!
    //! @brief set log buffer process id
    //!
    //! @param pid: specify the log_buffer data
    virtual void SetProcessId(uint16_t pid) = 0;

    //!
    //! @brief flush log buffer agent
    //!
    virtual void Flush() = 0;

    //!
    //! @brief get log agent cause's ecf address
    //!
    virtual uint32_t GetCauseAddr() = 0;
};
}  // namespace message_collector
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MESSAGE_AGENT_H_
