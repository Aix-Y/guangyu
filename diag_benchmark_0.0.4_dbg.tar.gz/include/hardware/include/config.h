/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_CONFIG_H_
#define HARDWARE_INCLUDE_CONFIG_H_

namespace efvf {
namespace hardware {

extern const char *kPmcCfgPath;

}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CONFIG_H_
