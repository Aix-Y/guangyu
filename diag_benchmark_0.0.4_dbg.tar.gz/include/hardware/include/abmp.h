/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file abmp.h
    \brief define a common axi bus master parity lib
 */

#ifndef HARDWARE_INCLUDE_ABMP_H_
#define HARDWARE_INCLUDE_ABMP_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace abmp {

enum AbmpWrErrIntType { WrBrespErrInt = 0, WrBuserErrInt = 1, WrParityErrInt = 2 };

enum AbmpWrParityInjectType { ErrorInParityBits = 0, ErrorInDataBits = 1 };

enum AbmpRdErrIntType { RdRrespErrInt = 0, RdRuserErrInt = 1, RdParityErrInt = 2 };

class AbmpRasCfg : public RasCfg {
 public:
    uint32_t wr_parity_check_en : 1;
    uint32_t wr_parity_gen_en : 1;
    uint32_t wr_bresp_err_int_en : 1;
    uint32_t wr_buser_err_int_en : 1;
    uint32_t wr_parity_err_int_en : 1;
    uint32_t rd_resp_check_en : 1;
    uint32_t rd_parity_check_en : 1;
    uint32_t rd_rresp_err_int_en : 1;
    uint32_t rd_ruser_err_int_en : 1;
    uint32_t rd_pairy_err_int_en : 1;
    uint32_t : 22;

    AbmpRasCfg() {
        wr_parity_check_en   = 0;
        wr_parity_gen_en     = 0;
        wr_bresp_err_int_en  = 0;
        wr_buser_err_int_en  = 0;
        wr_parity_err_int_en = 0;
        rd_resp_check_en     = 0;
        rd_parity_check_en   = 0;
        rd_rresp_err_int_en  = 0;
        rd_ruser_err_int_en  = 0;
        rd_pairy_err_int_en  = 0;
    }
};

class AbmpRasErrStat : public RasErrStat {
 public:
    uint32_t wr_bresp_err_status : 1;
    uint32_t wr_buser_err_status : 1;
    uint32_t wr_parity_err_status : 1;
    uint32_t rd_rresp_err_status : 1;
    uint32_t rd_ruser_err_status : 1;
    uint32_t rd_parity_err_status : 1;
    uint32_t : 26;
    uint32_t wr_parity_err_bresp;
    uint32_t wr_parity_err_buser;
    uint32_t wr_parity_err_bid;
    uint32_t rd_parity_err_rresp;
    uint32_t rd_parity_err_ruser;
    uint32_t rd_parity_err_rid;

    AbmpRasErrStat() {
        wr_bresp_err_status  = 0;
        wr_buser_err_status  = 0;
        wr_parity_err_status = 0;
        rd_rresp_err_status  = 0;
        rd_ruser_err_status  = 0;
        rd_parity_err_status = 0;
        wr_parity_err_bresp  = 0;
        wr_parity_err_buser  = 0;
        wr_parity_err_bid    = 0;
        rd_parity_err_rresp  = 0;
        rd_parity_err_ruser  = 0;
        rd_parity_err_rid    = 0;
    }
};

class AbmpRasErrInj : public RasErrInj {
 public:
    uint32_t wr_parity_err_inj_sel_data : 1;
    uint32_t : 31;
    uint32_t wr_parity_err_inj_num;

    AbmpRasErrInj() {
        wr_parity_err_inj_sel_data = 0;
        wr_parity_err_inj_num      = 0;
    }
};

class AbmpRas : public efvf::hardware::IRas {};

/*!
 * @brief Abmpbase lib
 */
class Abmp : public Hardware {
 public:
    /*!
     * @brief abmp constructors
     */
    explicit Abmp(std::shared_ptr<spdlog::logger> logger);

    /*!
     * @brief desctructor
     */
    virtual ~Abmp();

 public:
    /*!
     * @brief enable write parity check
     */
    virtual bool AbmpWrParityCheckEnable(bool check_en);

    /*!
     * @brief enable write error interrupt
     */
    virtual bool AbmpWrErrIntEnable(AbmpWrErrIntType err_int, bool enable);

    /*!
     * @brief enable write parity generation
     */
    virtual bool AbmpWrParityGenEnable(bool gen_en);

    /*!
     * @brief enable write parity eror injection
     */
    virtual bool AbmpWrParityErrInject(AbmpWrParityInjectType inj_type, uint16_t num);

    /*!
     * @brief stop write parity error injection
     */
    virtual bool AbmpStopWrParityErrInject(void);

    /*!
     * @brief Get write parity eror injection count
     */
    virtual uint16_t AbmpGetWrParityErrInJCnt(void);

    /*!
     * @brief Get write parity eror injection status
     */
    virtual uint16_t AbmpGetWrParityErrInJStat(void);

    /*!
      * @brief get write parity error status
      */
    virtual bool AbmpGetWrParityErrStat(uint32_t &err_stat);

    /*!
     * @brief enable read parity check
     */
    virtual bool AbmpRdParityCheckEnable(bool check_en);

    /*!
     * @brief enable read response check
     */
    virtual bool AbmpRdRespCheckEnable(bool check_en);

    /*!
     * @brief enable read error interrupt
     */
    virtual bool AbmpRdErrIntEnable(AbmpRdErrIntType err_int, bool enable);

    /*!
      * @brief get read parity error status
      */
    virtual bool AbmpGetRdParityErrStat(uint32_t &err_stat);

    /*!
      * @brief clean error status
      */
    virtual void AbmpClearErrStat(void) = 0;

    /*!
     * @brief print all the abmp configuration
     */
    virtual void PrintAll(std::string &);

 protected:
    std::shared_ptr<Hpd> hpd_;
};

}  // namespace abmp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_ABMP_H_
