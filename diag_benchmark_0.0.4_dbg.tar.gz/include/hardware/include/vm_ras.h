/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_VM_RAS_H_
#define HARDWARE_INCLUDE_VM_RAS_H_

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace vm {
class VmSramRasErrInj : public efvf::hardware::RasErrInj {
 public:
    int      par_gen_en = 0;  // 1: enable parity gen; 0: disable parity gen.
    int      par_chk_en = 0;  // 1: enable parity chk; 0: disable parity chk.
    int      err_inject = 0;  // 1: enable error injection; 0 disable error injection.
    int      err_sel    = 0;  // 1: insert error in data[lsb]; 0: insert error in parity bits.
    uint8_t  err_cnt    = 0;  // error inject counters.
    uint32_t GetVmSrammiscValue() {
        return (err_cnt << 0) | (err_sel << 28) | (err_inject << 29) | (par_chk_en << 30) |
               (par_gen_en << 31);
    }
};

class VmInterruptStat : public efvf::hardware::IntrptStat {
 public:
    int     reg_addr_err_vld       = 0;
    int     df_addr_err_vld        = 0;
    int     write_buff_par_err_vld = 0;
    uint8_t input_fifo_overflow    = 0;
    int     reset_ih_status        = 0;

    bool IsClean() {
        if (GetIrqValue() != 0) {
            return false;
        }
        return true;
    }

    bool FoundRegAddrErr() {
        return reg_addr_err_vld == 1;
    }

    bool FoundDfAddrErr() {
        return df_addr_err_vld == 1;
    }

    bool FoundWriteBuffParErrVld() {
        return write_buff_par_err_vld == 1;
    }

    bool FoundInputFifoOverflow() {
        return input_fifo_overflow != 0;
    }

    uint32_t GetIrqValue() {
        return (input_fifo_overflow >> 0) | (write_buff_par_err_vld >> 8) |
               (reg_addr_err_vld >> 9) | (df_addr_err_vld >> 10) | (reset_ih_status >> 31);
    }
};
}  // namespace vm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_VM_RAS_H_
