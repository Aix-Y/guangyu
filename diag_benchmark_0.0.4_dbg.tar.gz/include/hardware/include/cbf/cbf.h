/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CBF_CBF_H_
#define HARDWARE_INCLUDE_CBF_CBF_H_

#include <memory>
#include <set>
#include <string>
#include "framework/include/log.h"
#include "hardware/include/bpm.h"
#include "hardware/include/cbf/cbf_bb.h"
#include "hardware/include/cbf/cbf_bc.h"
#include "hardware/include/cbf/cbf_ctx.h"
#include "hardware/include/cbf/cbf_dp.h"
#include "hardware/include/hardware.h"
#include "hardware/include/system_adapter.h"

using efvf::hardware::cbf::cbf_dp::CbfDp;
using efvf::hardware::cbf::cbf_bc::CbfBc;
using efvf::hardware::cbf::cbf_bb::CbfBb;
using efvf::hardware::system_adapter::SystemAdapter;

namespace efvf {
namespace hardware {
namespace cbf {

#define CBF_BLOCK_MASK_NUM 8

/**
 * @brief CBF Basic Hardware Interface
 */
class Cbf : public Hardware {
 public:
    Cbf();
    explicit Cbf(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}
    virtual ~Cbf() {}

    /**
     * @brief  Get Die ID
     * @return uint8_t
     */
    virtual uint16_t GetDieId() {
        return parent_->inst_;
    }

    /**
     * @brief Get CBF ID
     * @return uint16_t
     */
    virtual uint16_t GetCbfId() {
        return inst_;
    }

    /**
     * @brief Get CBF Count/Num
     * @return uint16_t
     */
    virtual uint16_t GetCbfCnt() = 0;

    /**
     * @brief Get CBF BC Count/Num
     * @return uint16_t
     */
    virtual uint16_t GetCbfBcCnt() = 0;

    /**
     * @brief Get CBF BC Core Count/Num
     * @return uint16_t
     */
    virtual uint16_t GetCbfBcCoreCnt() = 0;

    /**
     * @brief Get CBF BB Count/Num
     * @return uint16_t
     */
    virtual uint16_t GetCbfBbCnt() = 0;

    /**
     * @brief Get CBF DF Port Count/Num
     * @return uint16_t
     */
    virtual uint16_t GetDfPortCnt() = 0;

    /**
     * @brief Get CBF mem type cnt
     * @return uint16_t
     */
    virtual uint16_t GetCbfCacheMemTypeCnt() = 0;

    /**
     * @brief Get sram count of BB one bank
     * @return uint16_t
     */
    virtual uint16_t GetBbOneBankSramCnt() = 0;

    /**
     * @brief Get sram count of BC one bank
     * @return uint16_t
     */
    virtual uint16_t GetBcOneBankSramCnt() = 0;

    /**
     * @brief Get CBF cache hit ratio total cnt
     * @return uint16_t
     */
    virtual uint16_t GetCacheHitRatioCnt() = 0;

    /**
     * @brief Get CBF slv bpm cnt
     * @return uint16_t
     */
    virtual uint16_t GetSlvBpmCnt() = 0;

    /**
     * @brief Get CBF mst bpm cnt
     * @return uint16_t
     */
    virtual uint16_t GetMstBpmCnt() = 0;

    /**
     * @brief Set CBF Group Num
     */
    virtual void SetCbfGroupNum(uint16_t num) {
        cbf_total_group_num_ = num;
    }

    /**
     * @brief Get CBF Group Num
     * @return uint16_t
     */
    virtual uint16_t GetCbfGroupNum() {
        return cbf_total_group_num_;
    }

    /**
     * @brief CBF num of each CBF Group
     */
    virtual void SetCbfNumOfCbfGroup(uint16_t num) {
        cbf_num_of_per_group_ = num;
    }

    /**
     * @brief Get CBF num of each CBF Group
     * @return uint16_t
     */
    virtual uint16_t GetCbfNumOfCbfGroup() {
        return cbf_num_of_per_group_;
    }

    /**
     * @brief Get total size of all BB buffers
     * @return uint32_t
     */
    virtual uint32_t GetBufferTotalSize() = 0;

    /**
     * @brief Get BC Sratch buffer total size
     * @return uint32_t
     */
    virtual uint32_t GetSratchBufferTotalSize() = 0;

    /**
     * @brief Check scratch buf mode
     * @return bool
     */
    virtual bool IsScratchBufferMode() = 0;

    /**
     * @brief Get BC cache total size
     * @return uint32_t
     */
    virtual uint32_t GetCacheTotalSize() = 0;

    /**
     * @brief Get BB sram bank size
     * @return uint32_t
     */
    virtual uint32_t GetBbBankSize() = 0;

    /**
     * @brief Get BC sram bank size
     * @return uint32_t
     */
    virtual uint32_t GetBcBankSize() = 0;

    /**
     * @brief Get one SRAM size
     * @return uint32_t
     */
    virtual uint32_t GetOneSramSize() = 0;

    /**
     * @brief Get one cacheline size
     * @return uint32_t
     */
    virtual uint32_t GetCachelineSize() = 0;

    /**
     * @brief Get one cache sector size
     * @return uint32_t
     */
    virtual uint32_t GetCacheSectorSize() = 0;

    /**
     * @brief Get mtn cache mtn max outstanding num
     * @return uint32_t
     */
    virtual uint32_t GetCacheMtnMaxOutstanding() = 0;

    /**
     * @brief Get mtn cache max way num
     * @return uint32_t
     */
    virtual uint32_t GetCacheMaxWayNum() = 0;

    /**
     * @brief Get CBF BC Mask
     * @return bitset
     */
    virtual std::bitset<CBF_BLOCK_MASK_NUM> GetCbfBcMask() = 0;

    /**
     * @brief Get CBF BB Mask
     * @return bitset
     */
    virtual std::bitset<CBF_BLOCK_MASK_NUM> GetCbfBbMask() = 0;

    /**
     * @brief Get CBF Buffer Mask
     * @return bitset
     */
    virtual std::bitset<CBF_BLOCK_MASK_NUM> GetCbfBufMask() = 0;

    /**
     * @brief Get CBF DP Inst
     * @return CbfDp*
     */
    virtual CbfDp *GetCbfDp() = 0;

    /**
     * @brief Get CBF Bc Inst
     * @param cbf_bc_id: bc id
     * @return CbfBc*
     */
    virtual CbfBc *GetCbfBc(uint8_t cbf_bc_id) = 0;

    /**
     * @brief Get CBF Bb Inst
     * @param cbf_bb_id: bb id
     * @return CbfBb*
     */
    virtual CbfBb *GetCbfBb(uint8_t cbf_bb_id) = 0;

    /**
     * @brief Get CBF Bpm Inst
     * @param bpm_type: bpm type(mst/slv)
     * @param bpm_idx: bpm idx
     * @return Bpm*
     */
    virtual Bpm *GetCbfBpm(const CbfBpmType &bpm_type, uint8_t bpm_idx) = 0;

    /**
     * @brief Get CBF Cache mem axi arcache/awcache attribute.
     * @param mem_type: cbf cache mem type enum.
     */
    virtual void GetCacheMemAttribute(
        CbfCacheMemCfg *cache_mem_cfg, const CbfCacheMemType &mem_type) = 0;

    /**
     * @brief Set CBF Context ID
     * @param ctx_id: context id
     */
    virtual void SetContextId(uint8_t ctx_id) = 0;

    /**
     * @brief Set CBF Master ID
     * @param mst_id: master id
     */
    virtual void SetMasterId(uint16_t mst_id) = 0;

    /**
     * @brief Enable BC to scratch buffer mode
     */
    virtual void EnableScratchBufferMode() = 0;

    /**
     * @brief Disable BC scratch buffer mode
     */
    virtual void DisableScratchBufferMode() = 0;

    /**
     * @brief : Set Cache addr boundry, resolution is 1MB
     * @param addr_boundary_size: addr boundary size
     */
    virtual void SetCacheAddrBoundary(uint32_t addr_boundary_size) = 0;

    /**
     * @brief Get BC Cache addr boundary
     * @return uint64_t
     */
    virtual uint64_t GetCacheAddrBoundary() = 0;

    /**
     * @brief Enable hw prefetch force Close
     */
    virtual void EnableHwPrefetchForceClose() = 0;

    /**
     * @brief Disable hw prefetch force Close
     */
    virtual void DisableHwPrefetchForceClose() = 0;

    /**
     * @brief Set Profiler start
     */
    virtual void SetProfileStart() = 0;

    /**
     * @brief Set Profiler end
     */
    virtual void SetProfileEnd() = 0;

    /**
     * @brief Clear Profiler
     */
    virtual void ClearProfile() = 0;

    /**
     * @brief Get profiler indicator info
     */
    virtual void GetProfileIndicatorInfo(CbfProfilerInfo *prfl_info) = 0;

    /**
     * @brief Print profiler indicator info
     */
    virtual void PrintProfileIndicatorInfo(const CbfProfilerInfo &prfl_info) = 0;

    /**
     * @brief Check and cmp profiler indicator info
     */
    virtual bool CheckProfileIndicatorInfo(const CbfProfilerInfo &rd_prfl_info,
        const CbfProfilerInfo &exp_prfl_info, bool check_hit_miss) = 0;

    /**
     * @brief Print RW channel addr err info
     */
    virtual void PrintRwChErrInfo() = 0;

    /**
     * @brief Print power stock indicator info
     */
    virtual void PrintPwstIndicatorInfo() = 0;

    /**
     * @brief Get CBF internal status
     * @param cbf_status: cbf status struct
     */
    virtual void GetCbfInnStatus(CbfInnStatus *cbf_status) = 0;

    /**
     * @brief Clear CBF internal status
     * @param cbf_status: cbf status struct
     */
    virtual void ClearCbfInnStatus(const CbfInnStatus &cbf_status) = 0;

    /**
     * @brief Set CBF internal IRQ mask
     * @param cbf_irq_mask: cbf irq mask struct
     */
    virtual void SetCbfInnIrqMask(const CbfIrqStatus &cbf_irq_mask) = 0;

    /**
     * @brief Clear CBF internal all IRQs status
     */
    virtual void ClearAllIrqMasks() = 0;

    /**
     * @brief Set IPU0/1 cache mem type, for post-silicon,
     * this function should not be used with GRS.
     */
    virtual void SetIpuCtrl(uint32_t val) = 0;

    // This part is the ras lib
    virtual bool QueryRasInterrupt(const CbfType &buf_type, const CbfRwType &rw_type,
        uint16_t buf_id, uint16_t port_id) = 0;

    virtual void ClearRasInterrupt(const CbfType &buf_type, const CbfRwType &rw_type,
        uint16_t buf_id, uint16_t port_id) = 0;

 public:
    /**
     * @brief Get System Adapter.
     */
    virtual SystemAdapter *GetSa() = 0;

 protected:
    uint16_t cbf_bc_cnt_           = 0;
    uint16_t cbf_bc_core_cnt_      = 0;
    uint16_t cbf_bb_cnt_           = 0;
    uint16_t cbf_df_port_num_      = 0;
    uint16_t cbf_total_group_num_  = 0;
    uint16_t cbf_num_of_per_group_ = 0;
};

}  // namespace cbf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CBF_CBF_H_
