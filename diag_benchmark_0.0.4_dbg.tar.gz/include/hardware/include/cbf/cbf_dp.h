/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CBF_CBF_DP_H_
#define HARDWARE_INCLUDE_CBF_CBF_DP_H_

#include <memory>
#include <set>
#include <string>
#include "hardware/include/cbf/cbf_ctx.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace cbf {
namespace cbf_dp {

/**
 * @brief CBF DP Hardware Interface
 */
class CbfDp : public Hardware {
 public:
    explicit CbfDp(std::shared_ptr<spdlog::logger> logger);
    virtual ~CbfDp();

    /**
     * @brief  Enable hash config
     * @param cbf_type: cbf block types (bc/bb/sb)
     */
    virtual void EnableHash(CbfType cbf_type) = 0;

    /**
     * @brief  Disable hash config
     * @param cbf_type: cbf block types (bc/bb/sb)
     */
    virtual void DisableHash(CbfType cbf_type) = 0;

    /**
     * @brief Config buf/cache hash addr setting
     * @param cbf_hash_cfg: cbf hash cfg enum
     */
    virtual void ConfigHashAddr(const CbfHashCfg &cbf_hash_cfg) = 0;

    /**
     * @brief Get buf/cache hash addr
     * @param cbf_hash_cfg: cbf hash cfg enum
     * @param addr: edf addr
     */
    virtual uint64_t GetHashAddr(CbfType cbf_type, uint64_t addr) = 0;

    /**
     * @brief  Enable dehash config
     */
    virtual void EnableDeHash() = 0;

    /**
     * @brief  Disable dehash config
     */
    virtual void DisableDeHash() = 0;

    /**
     * @brief  Config dehash
     * @param dehash_cfg: cbf dehash config struct
     */
    virtual void ConfigDeHash(const CbfDeHashCfg &dehash_cfg) = 0;

    /**
     * @brief  Set VF dehash
     * @param cbf_vf_type: vf group type
     */
    virtual void SetVfDeHash(const CbfVfType &cbf_vf_type) = 0;

    /**
     * @brief Set CBF VF Group num
     * @param cbf_vf_type: vf group type
     */
    virtual void SetCbfGroupNum(const CbfVfType &cbf_vf_type) = 0;

    /**
     * @brief Get CBF VF Group num
     * @return uint32_t
     */
    virtual uint32_t GetCbfGroupNum() = 0;

    /**
     * @brief Set CBF Index, for de-hash use
     * @param idx: CBF Index
     */
    virtual void SetCbfIndex(uint8_t idx) = 0;

    /**
     * @brief Set cacheline timeout cnt
     * @param num: timeout size num
     */
    virtual void SetCacheLineTimeout(uint8_t num) = 0;

    /**
     * @brief Config Cache maintenance via host, set mtn_pkg
     * @param cbf_mtn_cfg: cbf cache maintenance struct
     */
    virtual void ConfigCacheMaintenance(const CbfCacheMtnCfg &cbf_mtn_cfg) = 0;

    /**
     * @brief Wait Cache maintenance done with checking notify_data from notify_addr
     * @param cbf_mtn_cfg: cbf cache maintenance struct
     */
    virtual bool WaitCacheMaintenanceDone(const CbfCacheMtnCfg &cbf_mtn_cfg) = 0;

    /**
     * @brief Restore Cache Maintenance Setting setting to default val.
     */
    virtual void RestoreCacheMaintenanceSetting() = 0;
    /**
     * @brief Set HW prefetch block size
     * @param hw_pref_size: HW prefetch block size type
     * @param pref_size_val: HW prefetch block size val
     */
    virtual void SetHwPrefSize(
        const CbfCachePrefSize hw_pref_size, uint32_t *pref_size_val) = 0;

    /**
     * @brief Set HW prefetch outstanding num
     * @param hw_pref_val: HW prefetch outstanding num val
     */
    virtual void SetHwPrefOutstanding(uint32_t outstd_num) = 0;

    /**
     * @brief Set HW prefetch Qos num
     * @param pref_type: HW prefetch type
     * @param qos_num: HW prefetch qos num val
     */
    virtual void SetHwPrefQos(
        const CbfCachePrefType &pref_type, const CbfCachePrefQosType &qos_num) = 0;

    /**
     * @brief Restore HW prefetch setting to default val.
     */
    virtual void RestoreHwPrefSetting() = 0;

    /**
     * @brief DP R/W burst merge enable
     * @param rw_type: CBF DP R/W type struct
     */
    virtual void EnableDpRwBurstMerge(const CbfRwType &rw_type) = 0;

    /**
     * @brief DP R/W burst merge disable
     * @param rw_type: CBF DP R/W type struct
     */
    virtual void DisableDpRwBurstMerge(const CbfRwType &rw_type) = 0;
};

}  // namespace cbf_dp
}  // namespace cbf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CBF_CBF_DP_H_
