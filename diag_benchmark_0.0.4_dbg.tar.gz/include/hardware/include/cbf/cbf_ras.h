/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CBF_CBF_RAS_H_
#define HARDWARE_INCLUDE_CBF_CBF_RAS_H_

#include <stdint.h>
#include <memory>
#include <string>
#include <vector>
#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace cbf {

typedef enum _CbfBbEccErrEnjType {
    Cbf_Ecc_Enj_Ecc_Code = 0,
    Cbf_Ecc_Enj_Data,
    Cbf_Ecc_Enj_Both,
} CbfBbEccErrEnjType;

typedef enum _CbfBcParityErrEnjType {
    Cbf_Parity_Enj_Par = 0,
    Cbf_Parity_Enj_Data,
} CbfBcParityErrEnjType;

class CbfRasCfg : public efvf::hardware::RasCfg {
    bool ecc_error    = false;
    bool parity_error = false;
};

class CbfRasErrInj : public efvf::hardware::RasErrInj {
 public:
    // bb ras error
    bool Cbf_Ecc_Enj_Ecc_Code : 1;
    bool Cbf_Ecc_Enj_Data : 1;
    bool Cbf_Ecc_Enj_Both : 1;
    // bc ras error
    bool Cbf_Parity_Enj_Par : 1;
    bool Cbf_Parity_Enj_Data : 1;
};

class CbfRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t dpw1_wdata_parity_error : 1;
    uint32_t dpw0_wdata_parity_error : 1;
    uint32_t dpw1_qcw_ras_error : 1;
    uint32_t sram_ras_error : 1;
};
/**
 * @brief CBF bb ecc err enj type
 */
class CbfIntrptCfg : public efvf::hardware::IntrptCfg {};
class CbfIntrptStat : public efvf::hardware::IntrptStat {
 public:
    uint32_t bb_dp_rd_ecc_err_int_   = 0;
    uint32_t bb_dp_wr_ecc_err_int_   = 0;
    uint32_t bc_sram_rd_ras_err_int_ = 0;
};

class CbfRas : public efvf::hardware::IRas {};

}  // namespace cbf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CBF_CBF_RAS_H_
