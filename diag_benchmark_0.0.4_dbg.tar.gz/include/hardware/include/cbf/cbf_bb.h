/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CBF_CBF_BB_H_
#define HARDWARE_INCLUDE_CBF_CBF_BB_H_

#include <memory>
#include <set>
#include <string>
#include "hardware/include/cbf/cbf_ctx.h"
#include "hardware/include/cbf/cbf_ras.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace cbf {
namespace cbf_bb {

/**
 * @brief CBF BB Hardware Interface
 */
class CbfBb : public Hardware {
 public:
    explicit CbfBb(std::shared_ptr<spdlog::logger> logger);
    virtual ~CbfBb();

    /**
     * @brief  Get one bb size
     * @return uint32_t
     */
    virtual uint32_t GetOneBbSize() = 0;

    /**
     * @brief  Get bank cnt for one bb
     * @return uint32_t
     */
    virtual uint32_t GetOneBbBankCnt() = 0;

    /**
     * @brief  Enable sram redundant mask
     * @param mask_sel: mask sel(sram num)
     */
    virtual void EnableRedunMask(uint32_t mask_sel) = 0;

    /**
     * @brief  Disable sram redundant mask
     */
    virtual void DisableRedunMask() = 0;

    /**
     * @brief  Enable bb buf ecc decode
     */
    virtual void EnableEccDecode() = 0;

    /**
     * @brief  Disable bb buf ecc decode
     */
    virtual void DisableEccDecode() = 0;

    /**
     * @brief  Enable bb buf ecc err enj
     */
    virtual void EnableEccErrEnj() = 0;

    /**
     * @brief  Disable bb buf ecc err enj
     */
    virtual void DisableEccErrEnj() = 0;

    /**
     * @brief  Set bb buf ecc err enj type
     * @param ecc_err_enj_type: ecc err enj type:
     *              0: insert ecc error in ecc_code[lsb]
     *              1: insert ecc error in data[lsb]
     *              2: insert ecc error both in ecc_code[lsb] and data[lsb]
     */
    virtual void SetEccErrEnjType(const CbfBbEccErrEnjType ecc_err_enj_type) = 0;

    /**
     * @brief  Set bb buf ecc err enj counts at a time
     * @param ecc_err_enj_count: ecc error counters which will insert in data[lsb]
     *              or ecc code[lsb] at a time
     */
    virtual void SetEccErrEnjCountOneTime(uint32_t ecc_err_enj_count) = 0;

    /**
     * @brief  Print BB buffer ras err mem addr
     * @param rw: read/write flag
     * @param port_id: cbf port id
     * @return bool
     */
    virtual bool CheckEccErrInfo(const CbfRwType &rw, uint16_t port_id) = 0;
};

}  // namespace cbf_bb
}  // namespace cbf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CBF_CBF_BB_H_
