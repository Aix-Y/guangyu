/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_HCVG_HCVG_SCH_CMD_H_
#define HARDWARE_INCLUDE_HCVG_HCVG_SCH_CMD_H_

#include <cstring>
#include <iostream>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include "framework/include/mem.h"

using efvf::framework::mem::Mem;

namespace efvf {
namespace hardware {
namespace hcvg {

#define SINGLE_CMD_MAX_DATA_NUM_U32 (16)
#define SINGLE_CMD_MAX_RESP_NUM_U32 (16)
#define BATCH_CMD_MAX_SINGLE_CMD_NUM (0x100)

class SchCmd {
 private:
    //  single command
    bool     m_has_init;
    uint32_t m_cmd_data[SINGLE_CMD_MAX_DATA_NUM_U32];
    uint32_t m_resp_data[SINGLE_CMD_MAX_RESP_NUM_U32];

    // cclnormal - cmd type: 0x10, len: 0x6, ctx_id: 0
    const uint32_t CCLNORMAL_HEADER_VAL = 0x10060000;
    // cclnbrlink - cmd type: 0x11, len: 0x8, ctx_id: 0
    const uint32_t CCLNBRLINK_HEADER_VAL = 0x11080000;
    // FCA
    const uint32_t FCA_ONCE_HEADER_VAL     = 0x21080000;
    const uint32_t FCA_EXTERNAL_HEADER_VAL = 0x200A0000;
    // batch cmd
    const uint32_t BATCH_CMD_HEADER_VAL = 0x7F060000;

    // batch command
    uint32_t m_cmd_num;
    uint32_t m_max_single_cmd_num;
    uint32_t m_cmd_byte_size;
    uint32_t m_resp_byte_size;
    // batch command cmd mem and resp mem
    Mem *m_batch_cmdlist_mem;
    Mem *m_batch_resplist_mem;

 public:
    SchCmd()
        : m_has_init(false),
          m_cmd_num(0),
          m_max_single_cmd_num(BATCH_CMD_MAX_SINGLE_CMD_NUM),
          m_cmd_byte_size(0),
          m_resp_byte_size(0),
          m_batch_cmdlist_mem(nullptr),
          m_batch_resplist_mem(nullptr) {
        memset(&m_cmd_data, 0x0, SINGLE_CMD_MAX_DATA_NUM_U32 * sizeof(uint32_t));
        memset(&m_resp_data, 0x0, SINGLE_CMD_MAX_RESP_NUM_U32 * sizeof(uint32_t));
    }

    virtual ~SchCmd() {}

    bool CheckCmdHasInit() {
        return m_has_init;
    }

    uint32_t GetCmdU32Num() const {
        if (!m_has_init) {
            return 0;
        }

        return ((m_cmd_data[0] >> 16) & 0xFF) + 1;
    }

    uint32_t GetCmdRespU32Num() const {
        if (!m_has_init) {
            return 0;
        }

        uint32_t num      = 0;
        uint32_t cmd_type = m_cmd_data[0] >> 24;
        switch (cmd_type) {
            case 0x10:  // cclnormal resp
            case 0x11:  // cclnbrlink resp
            case 0x20:  // fcexternal resp
            case 0x21:  // fcextonce resp
            case 0x31:  // ConvexHull resp
            case 0x32:  // RotCalipMaxH resp
            case 0x7F:  // batch command resp
                num = 2;
                break;
            case 0x30:  // marnormal resp
            case 0x33:  // RotCalipMinA resp
                num = 6;
                break;
            default:
                break;
        }
        return num;
    }

    uint32_t *GetCmdData() {
        return m_cmd_data;
    }

    uint32_t *GetCmdRespData() {
        return m_resp_data;
    }

    bool CheckCmdResp() {
        return (1 == (m_resp_data[0] & 0xF));
    }

    void DbgPrintCmd() {
        uint32_t    num           = GetCmdU32Num();
        std::string cmd_type_name = GetCmdTypeName();
        std::cout << "CMD TYPE: " << cmd_type_name << std::endl;
        // for (uint32_t i = 0; i < num; ++i) {
        //     std::cout << "CMD DATA| " << i << " : 0x" << std::hex << m_cmd_data[i]
        //               << std::endl;
        // }
    }

    std::string GetCmdTypeName() {
        uint32_t    cmd_type = m_cmd_data[0] >> 24;
        std::string cmd_name;
        switch (cmd_type) {
            case 0x10:
                cmd_name = "CCLNormal";
                break;
            case 0x11:
                cmd_name = "CCLNbrLink";
                break;
            case 0x20:
                cmd_name = "FCExternal";
                break;
            case 0x21:
                cmd_name = "FCExtOnce";
                break;
            case 0x30:
                cmd_name = "MARNormal";
                break;
            case 0x31:
                cmd_name = "ConvexHull";
                break;
            case 0x32:
                cmd_name = "RotCalipMaxH";
                break;
            case 0x33:
                cmd_name = "RotCalipMinA";
                break;
            case 0x7F:
                cmd_name = "BatchCmd";
                break;

            default:
                cmd_name = "Unknow";
                break;
        }

        // std::cout << "CmdType is " << cmd_name << std::endl;
        return cmd_name;
    }

    bool GetCmdResp(uint32_t &resp_type, uint32_t &resp1) {
        if (!m_has_init)
            return false;

        resp_type = (m_resp_data[0] >> 24);
        switch (resp_type) {
            case 0x80:
            case 0x81:
            case 0x90:
            case 0x91:
            case 0xA1:
            case 0xA2:
            case 0xFF:
                resp1 = m_resp_data[1];
                break;
            case 0xA0:
            case 0xA3:
                resp1 = m_resp_data[1];  // need 5 u32
                break;
            default:
                return false;
        }
        return true;
    }

    uint32_t GetCmdType() const {
        uint32_t cmd_type = m_cmd_data[0] >> 24;
        return cmd_type;
    }

    bool CheckIsSchCmd(uint32_t cmd_type) {
        if (0x10 == cmd_type || 0x11 == cmd_type || 0x20 == cmd_type || 0x21 == cmd_type ||
            0x30 == cmd_type || 0x31 == cmd_type || 0x32 == cmd_type || 0x33 == cmd_type ||
            0x7F == cmd_type) {
            return true;
        }
        return false;
    }

    void SetCmdRecvData(uint32_t recv_data) {
        m_cmd_data[SINGLE_CMD_MAX_DATA_NUM_U32 - 1] = recv_data;
    }

    uint32_t GetCmdRecvData() {
        return m_cmd_data[SINGLE_CMD_MAX_DATA_NUM_U32 - 1];
    }

    uint32_t SetSchCmdByBuf(uint32_t *data_u32_buf, uint32_t data_len) {
        uint32_t pos      = 0;
        uint32_t cmd_type = 0;
        while (pos < data_len) {
            cmd_type = data_u32_buf[pos] >> 24;
            if (CheckIsSchCmd(cmd_type)) {
                uint32_t cmd_len = (data_u32_buf[pos] >> 16) & 0xFF;
                cmd_len += 1;  // add header
                for (uint32_t i = 0; i < cmd_len; i++) {
                    m_cmd_data[i] = data_u32_buf[i];
                    // std::cout << "cmd_data " << i << " : " << std::hex << m_cmd_data[i]
                    //           << std::endl;
                }

                pos += cmd_len;
                m_has_init = true;
                break;
            }

            pos++;
        }

        return pos;
    }

    /**
     * @brief  SetMemAddr
     * @note   type: ccla / fca / mara / batch
     * @param  addr1 : ccla - img addr,
     *                 fca  - img addr,
     *                 mara - points addr,
     *                 batch cmd - cmd list addr
     * @param  addr2 : ccla - label addr,
     *                 fca  - contours addr,
     *                 mara - hull addr,
     *                 batch cmd - resp list addr
     * @param  addr3 : ccla - nbr addr,
     *                 fca - contours num addr,
     * @retval
     */
    bool SetMemAddr(uint64_t addr1, uint64_t addr2, uint64_t addr3) {
        uint32_t cmd_type = m_cmd_data[0] >> 24;
        switch (cmd_type) {
            case 0x11:
            case 0x20:
                // cclnbrlink / fca_external
                m_cmd_data[6] = addr3 & 0xFFFFFFFF;
                m_cmd_data[7] = addr3 >> 32;
            // break;
            case 0x10:
            case 0x21:
                // cclnormal
                m_cmd_data[2] = addr1 & 0xFFFFFFFF;
                m_cmd_data[3] = addr1 >> 32;
                m_cmd_data[4] = addr2 & 0xFFFFFFFF;
                m_cmd_data[5] = addr2 >> 32;
                break;
            case 0x31:
                // hull addr
                m_cmd_data[2] = addr1 & 0xFFFFFFFF;
                m_cmd_data[3] = addr1 >> 32;
                m_cmd_data[4] = addr2 & 0xFFFFFFFF;
                m_cmd_data[5] = addr2 >> 32;
                break;
            case 0x30:
            case 0x32:
            case 0x33:
                // mara_normal
                // points addr
                m_cmd_data[2] = addr1 & 0xFFFFFFFF;
                m_cmd_data[3] = addr1 >> 32;

                break;
            case 0x7F:
                // batch cmd list addr and resp list addr
                m_cmd_data[2] = addr1 & 0xFFFFFFFF;
                m_cmd_data[3] = addr1 >> 32;
                m_cmd_data[4] = addr2 & 0xFFFFFFFF;
                m_cmd_data[5] = addr2 >> 32;
                break;

            default:
                break;
        }

        return true;
    }

    bool GetFcaParam(uint32_t &w, uint32_t &h, uint32_t &label_type, uint32_t &method,
        uint32_t &proc, uint32_t &th0, uint32_t &th1) {
        if (!m_has_init)
            return false;
        uint32_t cmd_type = m_cmd_data[0] >> 24;
        if (0x20 == cmd_type) {
            // FCA_External
            w          = m_cmd_data[1] & 0x3FFF;
            h          = (m_cmd_data[1] >> 16) & 0x3FFF;
            label_type = (m_cmd_data[8] >> 24) & 0xFF;
            method     = (m_cmd_data[8] >> 8) & 0xFF;
            proc       = (m_cmd_data[8] & 0x3F);
            th0        = m_cmd_data[9];
            th1        = m_cmd_data[10];
        } else if (0x21 == cmd_type) {
            // FCA_Once
            w          = m_cmd_data[1] & 0x3FFF;
            h          = (m_cmd_data[1] >> 16) & 0x3FFF;
            label_type = (m_cmd_data[6] >> 24) & 0xFF;
            method     = (m_cmd_data[6] >> 8) & 0xFF;
            proc       = (m_cmd_data[6] & 0x3F);
            th0        = m_cmd_data[7];
            th1        = m_cmd_data[8];
        } else {
            return false;
        }
        return true;
    }

    bool GetCclParam(uint32_t &w, uint32_t &h, uint32_t &conn, uint32_t &ltype) {
        if (!m_has_init)
            return false;
        uint32_t cmd_type = m_cmd_data[0] >> 24;
        if (0x10 == cmd_type) {
            // CCLNormal
            w     = m_cmd_data[1] & 0x1FFF;
            h     = (m_cmd_data[1] >> 16) & 0x3FFF;
            conn  = (m_cmd_data[6] >> 24) & 0xFF;
            ltype = (m_cmd_data[6] >> 16) & 0xFF;
        } else if (0x11 == cmd_type) {
            // CCLNbrLink
            w     = m_cmd_data[1] & 0x1FFF;
            h     = (m_cmd_data[1] >> 16) & 0x3FFF;
            conn  = (m_cmd_data[8] >> 24) & 0xFF;
            ltype = (m_cmd_data[8] >> 16) & 0xFF;
        } else {
            return false;
        }
        return true;
    }

    bool SetCclNormalParam(uint32_t w, uint32_t h, uint64_t img_addr, uint64_t label_addr,
        uint32_t connect, uint32_t label_type, uint32_t ctx_loc) {
        uint32_t idx = 0;
        // header
        m_cmd_data[idx++] = CCLNORMAL_HEADER_VAL;
        // body
        m_cmd_data[idx++] = (h << 16 | w) & 0x1FFF1FFF;  // image size
        m_cmd_data[idx++] = img_addr & 0xFFFFFFFF;
        m_cmd_data[idx++] = img_addr >> 32;
        m_cmd_data[idx++] = label_addr & 0xFFFFFFFF;
        m_cmd_data[idx++] = label_addr >> 32;
        m_cmd_data[idx++] = ((connect << 24) | (label_type << 16) | ctx_loc << 8);

        m_has_init = true;
        return m_has_init;
    }

    bool SetCclNbrLinkParam(uint32_t w, uint32_t h, uint64_t img_addr, uint64_t nbr_addr,
        uint64_t label_addr, uint32_t connect, uint32_t label_type, uint32_t ctx_loc) {
        uint32_t idx = 0;
        // header
        m_cmd_data[idx++] = CCLNBRLINK_HEADER_VAL;
        // body
        m_cmd_data[idx++] = (h << 16 | w) & 0x1FFF1FFF;  // image size
        m_cmd_data[idx++] = img_addr & 0xFFFFFFFF;
        m_cmd_data[idx++] = img_addr >> 32;
        m_cmd_data[idx++] = label_addr & 0xFFFFFFFF;
        m_cmd_data[idx++] = label_addr >> 32;
        m_cmd_data[idx++] = nbr_addr & 0xFFFFFFFF;
        m_cmd_data[idx++] = nbr_addr >> 32;
        m_cmd_data[idx++] = ((connect << 24) | (label_type << 16) | ctx_loc << 8);
        m_has_init        = true;
        return m_has_init;
    }

    bool SetFcaExternalParam(uint32_t w, uint32_t h, uint64_t img_addr, uint64_t con_addr,
        uint64_t con_num_addr, uint32_t label_type, uint32_t method, uint32_t ctx_loc,
        uint32_t proc, uint32_t th0, uint32_t th1) {
        uint32_t idx = 0;
        // header
        m_cmd_data[idx++] = FCA_EXTERNAL_HEADER_VAL;
        // body
        m_cmd_data[idx++] = (h << 16 | w) & 0x3FFF3FFF;  // image size
        m_cmd_data[idx++] = img_addr & 0xFFFFFFFF;
        m_cmd_data[idx++] = img_addr >> 32;
        m_cmd_data[idx++] = con_addr & 0xFFFFFFFF;
        m_cmd_data[idx++] = con_addr >> 32;
        m_cmd_data[idx++] = con_num_addr & 0xFFFFFFFF;
        m_cmd_data[idx++] = con_num_addr >> 32;
        m_cmd_data[idx++] = ((label_type << 24) | (method << 8) | (ctx_loc << 7) |
                             (proc & 0x3F));  // 23:16 mode=0
        m_cmd_data[idx++] = th0;
        m_cmd_data[idx++] = th1;
        m_has_init        = true;

        return m_has_init;
    }

    bool SetFcaOnceParam(uint32_t w, uint32_t h, uint64_t img_addr, uint64_t con_addr,
        uint32_t label_type, uint32_t method, uint32_t ctx_loc, uint32_t proc, uint32_t th0,
        uint32_t th1) {
        uint32_t idx = 0;
        // header
        m_cmd_data[idx++] = FCA_ONCE_HEADER_VAL;
        // body
        m_cmd_data[idx++] = (h << 16 | w) & 0x3FFF3FFF;  // image size
        m_cmd_data[idx++] = img_addr & 0xFFFFFFFF;
        m_cmd_data[idx++] = img_addr >> 32;
        m_cmd_data[idx++] = con_addr & 0xFFFFFFFF;
        m_cmd_data[idx++] = con_addr >> 32;
        // 23:16 mode=0
        m_cmd_data[idx++] =
            ((label_type << 24) | (method << 8) | (ctx_loc << 7) | (proc & 0x3F));
        m_cmd_data[idx++] = th0;
        m_cmd_data[idx++] = th1;
        m_has_init        = true;

        return m_has_init;
    }

    // Batch Command
    bool AddSingleCmdToBatch(SchCmd &scmd) {
        bool ret = true;
        // check scmd cmd_type, can not add batch cmd to batch cmd
        if (0x7F != this->GetCmdType()) {
            std::cout << "This is not a batch command" << std::endl;
            return false;
        }
        if (0x7F == scmd.GetCmdType()) {
            std::cout << "Can not add batch cmd to batch cmd" << std::endl;
            return false;
        }

        if (m_cmd_num > m_max_single_cmd_num) {
            std::cout << "Can not add single command to batch, max cmd: "
                      << m_max_single_cmd_num << ", current cmd num: " << m_cmd_num
                      << std::endl;
        }

        static std::mutex add_cmd_mtx;
        add_cmd_mtx.lock();

        uint8_t *scmd_data        = reinterpret_cast<uint8_t *>(scmd.GetCmdData());
        uint32_t scmd_byte_len    = scmd.GetCmdU32Num() * sizeof(uint32_t);
        uint32_t max_cmd_mem_size = m_batch_cmdlist_mem->GetSize();
        if (m_cmd_byte_size + scmd_byte_len > max_cmd_mem_size) {
            std::cout << " Can not add single command to batch, batch command memory limit: "
                      << max_cmd_mem_size << std::endl;
            add_cmd_mtx.unlock();
            return false;
        }

        m_batch_cmdlist_mem->MemSet(m_cmd_byte_size, scmd_data, scmd_byte_len);

        m_cmd_byte_size += scmd_byte_len;
        m_resp_byte_size += scmd.GetCmdRespU32Num() * sizeof(uint32_t);
        m_cmd_num++;

        // update cmd num
        m_cmd_data[0] = (m_cmd_data[0] & 0xFFFFFF00) | m_cmd_num;
        m_cmd_data[1] = m_cmd_byte_size;
        m_cmd_data[6] = m_resp_byte_size;

        add_cmd_mtx.unlock();

        return true;
    }

    bool InitBatchCmd(
        Mem *cmd_mem, Mem *resp_mem, uint32_t max_scmd_num = BATCH_CMD_MAX_SINGLE_CMD_NUM) {
        bool ret = true;
        if (!cmd_mem || !resp_mem) {
            std::cout << "Batch cmd init need cmd and resp memory" << std::endl;
            m_has_init = false;
            return false;
        }

        m_max_single_cmd_num = max_scmd_num;
        uint32_t idx         = 0;
        m_cmd_data[idx++]    = BATCH_CMD_HEADER_VAL;
        // body
        m_cmd_data[idx++] = m_cmd_byte_size;
        m_cmd_data[idx++] = cmd_mem->GetDevAddr()[0] & 0xFFFFFFFF;
        m_cmd_data[idx++] = cmd_mem->GetDevAddr()[0] >> 32;
        m_cmd_data[idx++] = resp_mem->GetDevAddr()[0] & 0xFFFFFFFF;
        m_cmd_data[idx++] = resp_mem->GetDevAddr()[0] >> 32;
        m_cmd_data[idx++] = m_resp_byte_size;

        m_has_init = true;

        m_batch_cmdlist_mem  = cmd_mem;
        m_batch_resplist_mem = cmd_mem;

        return ret;
    }

    uint64_t GetBatchCmdMemAddr() {
        // check cmd type
        return m_batch_cmdlist_mem->GetDevAddr()[0];
    }

    uint64_t GetBatchRespMemAddr() {
        return m_batch_resplist_mem->GetDevAddr()[0];
    }

    uint32_t GetBatchCmdListLen() {
        return m_cmd_byte_size;
    }

    uint32_t GetBatchRespListLen() {
        return m_resp_byte_size;
    }
};

}  // namespace hcvg
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_HCVG_HCVG_SCH_CMD_H_
