/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_VPP_EVP_VPP_RAS_H_
#define HARDWARE_INCLUDE_VPP_EVP_VPP_RAS_H_

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace vpp {

class VppRasCfg : public efvf::hardware::RasCfg {
    // SMEM, MIH / resize / padding / cus / cds / dewarp sram
 public:
    //  smem: 0 - 2 (fw/mdma/ecf)
    uint32_t vpm_smem_parity_gen_en : 1;
    uint32_t vpm_smem_parity_check_en : 1;
    uint32_t mih_sram_parity_gen_en : 1;
    uint32_t mih_sram_parity_check_en : 1;
    uint32_t resize_sram_parity_gen_en : 1;
    uint32_t resize_sram_parity_check_en : 1;
    uint32_t padding_sram_parity_gen_en : 1;
    uint32_t padding_sram_parity_check_en : 1;
    uint32_t cus_sram_parity_gen_en : 1;
    uint32_t cus_sram_parity_check_en : 1;
    uint32_t cds_sram_parity_gen_en : 1;
    uint32_t cds_sram_parity_check_en : 1;
    // evp pro, 0 - 3 type
    uint32_t dewarp_sram_parity_gen_en : 1;
    uint32_t dewarp_sram_parity_check_en : 1;
    uint32_t combo_sram_parity_gen_en : 1;
    uint32_t combo_sram_parity_check_en : 1;
    uint32_t decoder_sram_parity_gen_en : 1;
    uint32_t decoder_sram_parity_check_en : 1;
    uint32_t : 14;
    // uint32_t smem_ras_type : 4;
    // uint32_t dewarp_ras_type : 4;
    VppRasCfg() {
        vpm_smem_parity_gen_en       = 0;
        vpm_smem_parity_check_en     = 0;
        mih_sram_parity_gen_en       = 0;
        mih_sram_parity_check_en     = 0;
        resize_sram_parity_gen_en    = 0;
        resize_sram_parity_check_en  = 0;
        padding_sram_parity_gen_en   = 0;
        padding_sram_parity_check_en = 0;
        cus_sram_parity_gen_en       = 0;
        cus_sram_parity_check_en     = 0;
        cds_sram_parity_gen_en       = 0;
        cds_sram_parity_check_en     = 0;
        dewarp_sram_parity_gen_en    = 0;
        dewarp_sram_parity_check_en  = 0;
        combo_sram_parity_gen_en     = 0;
        combo_sram_parity_check_en   = 0;
        decoder_sram_parity_gen_en   = 0;
        decoder_sram_parity_check_en = 0;
    }
};

class VppRasErrInj : public efvf::hardware::RasErrInj {
 public:
    uint32_t vpm_smem_parity_inj : 1;
    uint32_t mih_sram_parity_inj : 1;
    uint32_t resize_sram_parity_inj : 1;
    uint32_t padding_sram_parity_inj : 1;
    uint32_t cus_sram_parity_inj : 1;
    uint32_t cds_sram_parity_inj : 1;
    uint32_t dewarp_sram_parity_inj : 1;
    uint32_t combo_sram_parity_inj : 1;
    uint32_t decoder_sram_parity_inj : 1;
    uint32_t : 23;
    uint32_t sram_evp_idx;
    uint32_t sram_parity_err_inj_num;
    VppRasErrInj() {
        vpm_smem_parity_inj     = 0;
        mih_sram_parity_inj     = 0;
        resize_sram_parity_inj  = 0;
        padding_sram_parity_inj = 0;
        cus_sram_parity_inj     = 0;
        cds_sram_parity_inj     = 0;
        dewarp_sram_parity_inj  = 0;
        combo_sram_parity_inj   = 0;
        decoder_sram_parity_inj = 0;
        sram_evp_idx            = 0;
        sram_parity_err_inj_num = 1;
    }
};

class VppRasErrStat : public efvf::hardware::RasErrStat {
 public:
    // const uint32_t MAX_EVP_INST = 3;
    // SMEM RAS, INTF0: bit[0:7], INTF1, INTF2
    uint32_t vpm_smem_parity_error;
    uint32_t mih_sram_parity_error;
    uint32_t resize_sram_parity_error[MAX_VPP_EVP_INST];   // 32 bit
    uint32_t padding_sram_parity_error[MAX_VPP_EVP_INST];  // 4 bit
    uint32_t cus_sram_parity_error[MAX_VPP_EVP_INST];      // 2 bit
    uint32_t cds_sram_parity_error[MAX_VPP_EVP_INST];      // 2 bit
    uint32_t dewarp_sram_parity_error[4];
    uint32_t combo_sram_parity_error[4];
    uint32_t combo_ras_event_info[4];
    uint32_t decoder_sram_parity_error[4];
    uint32_t decoder_ras_event_info[4];

    // SMEM RAS LOG, INTF0: bit[0:15], ...
    uint64_t vpm_smem_parity_error_log;
    uint32_t resize_parity_err_addr_mux[MAX_VPP_EVP_INST];
    uint32_t padding_parity_err_addr_mux[MAX_VPP_EVP_INST];
    uint32_t cds_sram_parity_err_addr_mux[MAX_VPP_EVP_INST];
    uint32_t cus_sram_parity_err_addr_mux[MAX_VPP_EVP_INST];
    uint32_t dewarp_parity_err_addr_mux[4];  // dewarp 0 - 3

    uint32_t resize_parity_err_addr[MAX_VPP_EVP_INST];
    uint32_t padding_parity_err_addr[MAX_VPP_EVP_INST];
    uint32_t cds_sram_parity_err_addr[MAX_VPP_EVP_INST];
    uint32_t cus_sram_parity_err_addr[MAX_VPP_EVP_INST];
    uint32_t dewarp_parity_err_addr[4];  // dewarp 0 - 3
    uint64_t combo_sram_parity_error_info;
    uint64_t decoder_sram_parity_error_info;

    VppRasErrStat() {
        vpm_smem_parity_error          = 0;
        mih_sram_parity_error          = 0;
        combo_sram_parity_error_info   = 0;
        decoder_sram_parity_error_info = 0;
        for (uint32_t i = 0; i < 4; i++) {
            combo_sram_parity_error[i]    = 0;
            combo_ras_event_info[i]       = 0;
            decoder_sram_parity_error[i]  = 0;
            decoder_ras_event_info[i]     = 0;
            dewarp_sram_parity_error[i]   = 0;
            dewarp_parity_err_addr_mux[i] = 0;  // dewarp 0 - 3
            dewarp_parity_err_addr[i]     = 0;  // dewarp 0 - 3
        }

        for (uint32_t inst = 0; inst < 3; inst++) {
            resize_sram_parity_error[inst]     = 0;  // 32 bit
            resize_parity_err_addr_mux[inst]   = 0;
            resize_parity_err_addr[inst]       = 0;
            padding_sram_parity_error[inst]    = 0;  // 4 bit
            padding_parity_err_addr_mux[inst]  = 0;
            padding_parity_err_addr[inst]      = 0;
            cus_sram_parity_error[inst]        = 0;  // 2 bit
            cus_sram_parity_err_addr_mux[inst] = 0;
            cus_sram_parity_err_addr[inst]     = 0;
            cds_sram_parity_error[inst]        = 0;  // 2 bit
            cds_sram_parity_err_addr_mux[inst] = 0;
            cds_sram_parity_err_addr[inst]     = 0;
        }
    }
};

class VppIntrptCfg : public efvf::hardware::IntrptCfg {
 public:
};

class VppIntrptStat : public efvf::hardware::IntrptStat {
 public:
};

class VppRas : public efvf::hardware::IRas {};

}  // namespace vpp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_VPP_EVP_VPP_RAS_H_
