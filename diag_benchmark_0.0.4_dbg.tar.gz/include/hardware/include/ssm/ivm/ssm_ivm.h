/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_IVM_SSM_IVM_H_
#define HARDWARE_INCLUDE_SSM_IVM_SSM_IVM_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace ivm {

class SsmIvm : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmIvm(Ssm *ssm);
    virtual ~SsmIvm() {}

 public:
    virtual bool ivm_image_download(bool, const std::string &);
    virtual bool ivm_amc_download(bool, const std::string &, uint32_t);
    virtual bool ivm_openflag_pipo_rdump(void);
    virtual bool ivm_openflag_pipo_write(void);

 public:
    virtual bool        handle_req_image_prep(void);
    virtual bool        handle_req_image_info(const std::string &);
    virtual std::string handle_req_image_version(void);
    virtual std::string handle_req_image_btype(void);
    virtual bool        handle_req_image_data_sync(bool, const std::string &);
    virtual std::string handle_req_image_dump(const std::string &, const std::string &);
};

}  // namespace ivm
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_IVM_SSM_IVM_H_
