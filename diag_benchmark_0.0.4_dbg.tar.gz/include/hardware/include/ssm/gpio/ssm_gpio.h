/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_GPIO_SSM_GPIO_H_
#define HARDWARE_INCLUDE_SSM_GPIO_SSM_GPIO_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace gpio {

class SsmGpio : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmGpio(Ssm *ssm);
    virtual ~SsmGpio() {}

 public:
    virtual bool     is_iput(uint32_t);
    virtual bool     is_oput(uint32_t);
    virtual bool     is_io_iput(uint32_t);
    virtual bool     is_io_iput_lo(uint32_t);
    virtual bool     is_io_iput_hi(uint32_t);
    virtual bool     is_io_oput(uint32_t);
    virtual bool     is_io_oput_lo(uint32_t);
    virtual bool     is_io_oput_hi(uint32_t);
    virtual bool     is_lvs_m2s_supp(void);
    virtual uint32_t get_card_id(void);
    virtual uint32_t get_pinstrap(uint32_t);
    virtual uint64_t get_pinstrap_all(void);
    virtual uint32_t get_io_dir(uint32_t);
    virtual uint32_t get_io_val(uint32_t);
    virtual void     set_io_val(uint32_t, uint32_t);
    virtual void     set_io_dir(uint32_t, uint32_t);
    virtual void     set_io_dir_iput(uint32_t);
    virtual void     set_io_dir_oput(uint32_t);
    virtual void     set_io_oput_lo(uint32_t);
    virtual void     set_io_oput_hi(uint32_t);
    virtual bool     get_gd_vddc2gpio_ena(uint32_t);
    virtual void     set_gd_vddc2gpio_ena(uint32_t, bool);
    virtual void     set_d2d_fatal_pad_ena(bool);
    virtual void     set_spi_mst_access_slv(bool);

 public:
    virtual bool test_gpio_mode_output_led_sweep(void);
    virtual bool test_gpio_pinstrap_golden_setting(void);

 public:
    virtual std::string handle_req_gpio_status(void);
    virtual std::string handle_req_gpio_esl_status(void);
    virtual bool        handle_req_gpio_esl_on_off(const std::string &, const std::string &);
    virtual uint32_t    handle_req_gpio_esl_set_iput_v(uint32_t);
    virtual void        handle_req_gpio_esl_set_oput_v(uint32_t, uint32_t);
    virtual bool        handle_req_gpio_reuse(const std::string &, const std::string &);
    virtual bool        handle_req_gpio_sku_info(void);
};

}  // namespace gpio
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_GPIO_SSM_GPIO_H_
