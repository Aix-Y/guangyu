/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_I2C_SSM_I2C_H_
#define HARDWARE_INCLUDE_SSM_I2C_SSM_I2C_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace i2c {

class SsmI2c : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmI2c(Ssm *ssm);
    virtual ~SsmI2c() {}

 public:
    virtual double      decode_temp_emc1412(uint32_t);
    virtual double      decode_temp_emc1412_erange(uint32_t);
    virtual double      decode_temp_emc1412_drange(uint32_t);
    virtual double      decode_data_by_req(const std::string &, uint32_t);
    virtual bool        is_i2c_supported(uint32_t);
    virtual uint32_t    get_id_max(void);
    virtual uint32_t    i2c_enum_to_id(uint32_t &);
    virtual uint32_t    i2c_name_to_id(const std::string &);
    virtual std::string i2c_id_to_name(const uint32_t &);
    virtual std::string i2c_id_2str(const uint32_t &);
    virtual bool        chk_tid_valid(uint32_t);
    virtual std::string get_i2c_name(uint32_t);
    virtual std::string get_i2c_phyloc(uint32_t);
    virtual double      get_i2c_temp(const std::string &);
    virtual double      get_i2c_temp(uint32_t);
    virtual double      get_i2c_temp_enum(uint32_t);
    virtual double      get_i2c_temp_asic(uint32_t);
    virtual double      get_i2c_temp_fan(void);
    virtual double      get_i2c_temp_board(void);
    virtual double      get_i2c_hotspot(void);
    virtual double      get_asic_hotspot(void);
    virtual void        set_i2c_thres_alert(uint32_t, uint32_t);
    virtual void        set_i2c_thres_ctf(uint32_t, uint32_t);
    virtual bool        ssm_i2c_trigger_sensor_hot(uint32_t);
    virtual bool        ssm_i2c_check_ic_did(void);
    virtual bool        ssm_i2c_read_temperature_verify(void);
    virtual bool        ssm_i2c_read_temperature_mixed(void);
    virtual bool        ssm_i2c_temperature_valid(void);
    virtual void        ssm_i2c_tune_power_hbm(void);
    virtual bool        ssm_i2c_push_dtu_power(void);
    virtual bool        ssm_i2c_tune_power_dtu(void);
    virtual void        ssm_i2c_update_tune_paras(void);
    virtual void        test_thm_temperature_gradient_pre(void);
    virtual void        test_thm_temperature_gradient_pst(void);
    virtual bool        test_thm_temperature_gradient(void);
    virtual void        test_thm_heating_pre(void);
    virtual bool        test_thm_heating_ent(void);
    virtual bool        test_thm_heating_pst(void);

 public:
    virtual std::string ttgt_get_p_asic_pwr(void);
    virtual std::string ttgt_get_p_volt_min(void);
    virtual std::string ttgt_get_p_volt_max(void);
    virtual std::string ttgt_get_p_volt_step(void);
    virtual double      ttgt_get_p_asic_ave(void);
    virtual void        ttgt_off_feat(void);
    virtual void        ttgt_set_volt(double, bool);
    virtual void        ttgt_set_cmin(void);
    virtual bool        test_i2c_check_ic_did(void);
    virtual bool        test_i2c_each_t_ave_dvi(void);
    virtual bool        test_i2c_each_t_ave_dvi_mixed(void);
    virtual bool        test_i2c_each_t_in_range(void);
    virtual bool        test_i2c_golden_tsensor(void);

 public:
    virtual void        handle_req_i2c_apb_status(const std::string &);
    virtual bool        handle_req_i2c_apb_init(const std::string &);
    virtual void        handle_req_i2c_apb_int_clr(const std::string &);
    virtual bool        handle_req_i2c_apb_read(const std::string &);
    virtual bool        handle_req_i2c_apb_write(const std::string &);
    virtual bool        handle_req_i2c_apb_scan(const std::string &);
    virtual bool        handle_req_i2c_tdiode(const std::string &);
    virtual std::string handle_req_i2c_dump(const std::string &);
    virtual bool        handle_req_thm_list(void);
};

}  // namespace i2c
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_I2C_SSM_I2C_H_
