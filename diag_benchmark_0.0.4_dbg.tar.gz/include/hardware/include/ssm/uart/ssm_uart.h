/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UART_SSM_UART_H_
#define HARDWARE_INCLUDE_SSM_UART_SSM_UART_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace uart {

class SsmUart : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmUart(Ssm *ssm);
    virtual ~SsmUart() {}

 public:
    virtual bool        amc_supported(void);
    virtual bool        amc_image_download(bool, std::string, uint32_t);
    virtual bool        amc_fwbuf_download(bool, uint32_t, void *);
    virtual bool        ust_fwbuf_download(bool, uint32_t, void *);
    virtual void        amc_force_dead(bool, bool);
    virtual void        amc_reset_toggle(bool);
    virtual uint32_t    amc_upmode_select(bool);
    virtual bool        amc_sync_time(uint32_t = ~0U);
    virtual std::string amc_pid_status(void);
    virtual bool        amc_fwsz_valid(uint32_t);

 public:
    virtual bool test_amc_reset_alive(void);
    virtual bool test_amc_ssm_data_exchange(void);
    virtual bool test_amc_ssm_check_i2c_hub(void);
    virtual bool test_amc_ssm_check_eeprom(void);
    virtual bool test_amc_ssm_check_adc_scan(void);
    virtual bool test_amc_ssm_check_spi_access(void);

 public:
    virtual bool     handle_req_uart_status(const std::string &);
    virtual bool     handle_req_uart_reset(const std::string &);
    virtual bool     handle_req_uart_init(const std::string &, const std::string &);
    virtual uint32_t handle_req_uart_rxu8(const std::string &);
    virtual void     handle_req_uart_txu8(const std::string &, uint32_t);
    virtual bool     handle_req_uart_rx_clr(const std::string &);
};

}  // namespace uart
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_UART_SSM_UART_H_
