/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_MEM_SSM_MEM_H_
#define HARDWARE_INCLUDE_SSM_MEM_SSM_MEM_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace mem {

class SsmMem : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmMem(Ssm *ssm);
    virtual ~SsmMem() {}

 public:
    virtual void     ssm_mem_r(void *, uint32_t, uint32_t = 0U, uint32_t = 0U);
    virtual void     ssm_mem_w(void *, uint32_t, uint32_t = 0U, uint32_t = 0U);
    virtual void     ssm_mem_d(uint32_t, uint32_t = 0U, uint32_t = 0U);
    virtual void     ssm_mem_f_u08(uint32_t, uint8_t, uint32_t, uint32_t = 0U);
    virtual bool     ssm_mem_c_u08(uint32_t, uint8_t, uint32_t, uint32_t = 0U);
    virtual uint32_t ssm_mem_addr_ecf(uint32_t);
    virtual uint32_t ssm_mem_addr_spi(uint32_t);
    virtual uint32_t ssm_mem_addr_dma(uint32_t);
    virtual uint32_t ssm_mem_size(uint32_t);
    virtual uint32_t ssm_mem_vf_base(uint32_t);

    /////////////////////
    // MEM TEST INTERFACE
    /////////////////////
 public:
    virtual void test_mcu_mem_backdoor_iram_dump(void);
    virtual bool test_mcu_mem_backdoor_iram_wrc(void);
    virtual void test_mcu_mem_backdoor_dram_dump(void);
    virtual bool test_mcu_mem_backdoor_dram_wrc(void);
    virtual void test_mcu_mem_backdoor_fmem_dump(void);
    virtual bool test_mcu_mem_backdoor_fmem_wrc(void);
    virtual void test_mcu_mem_backdoor_smem_dump(void);
    virtual bool test_mcu_mem_backdoor_smem_wrc(void);
    virtual bool test_mcu_mem_repair_sram_wrc(void);

 public:
    virtual std::string handle_req_mem_info(void);
    virtual bool        handle_req_mem_load(const std::string &, const std::string &);
};

}  // namespace mem
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_MEM_SSM_MEM_H_
