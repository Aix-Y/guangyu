/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_FW_SSM_CMD_CMN_H_
#define HARDWARE_INCLUDE_SSM_FW_SSM_CMD_CMN_H_

// clang-format off
#define SSM_PING_ECODE_NO_OPENFLAG        (0xeeee0000)
#define SSM_PING_ECODE_IVM_MISMATCH_PAM   (0xeeee0001)
#define SSM_PING_ECODE_IVM_MISMATCH_PROD  (0xeeee0002)
#define SSM_PING_ECODE_IVM_MISMATCH_OTHER (0xeeee0003)

#define SSM_MAGIC_BOOT_COMPLETE_OK (0xabcd1234)
#define SSM_MAGIC_BOOT_COMPLETE_NG (0x1234abcd)

#define SSM_SMEM_VF_BASE_OFST_SCORPIO (0x17E00)
#define SSM_SMEM_VF_BASE_OFST_LIBRA   (0x17E00)

#define SSM_AVS_SET_V (0x0)
#define SSM_AVS_GET_V (0x1)
#define SSM_AVS_GET_C (0x2)
#define SSM_AVS_GET_T (0x3)
#define SSM_AVS_GET_S (0x4)

#define SSM_FW_CMD_SUCCESS        (0x0)
#define SSM_FW_CMD_INVALID_FUNC   (0x1)
#define SSM_FW_CMD_INVALID_PARAM  (0x2)
#define SSM_FW_CMD_DATA_ERROR     (0x3)

#define SSM_EDCC_12V_OFF (0x0)

enum kFwBtype {
    kFwBoard_Prd = 0,
    kFwBoard_Pam,
    kFwBoard_Oam,
    kFwBoard_Mxm,
    kFwBoard_Other,
};

enum kFwBRev {
    kFwBoard_RevA = 0,
    kFwBoard_RevB,
    kFwBoard_RevC,
    kFwBoard_RevX,
};

enum kFwItype {
    eTdiode_0,
    eTdiode_1,
    eTdiode_2,
    eTdiode_3,
    eTdiode_4,
    eTdiode_5,
    eTdiode_6,
    eTdiode_7,
    eTdiode_8,
    eTdiode_9,

    eHbm_0,
    eHbm_1,
    eHbm_2,
    eHbm_3,

    eVdd_Dtu,
    eVdd_Soc,
    eVdd_Hbmqc,
    eVdd_1V8,
    eVdd_Vddp,
    eVdd_McPhy,
    eVdd_HbmVpp,
    eVdd_MphyPll,

    eDac_0,
    eDac_1,
    eDac_2,
    eDac_3,
    eDac_McphyRef,

    eTdc_12vbus,
    eTdc_12vext,
    eTdc_3v3bus,
};

enum kFwSipHOp {
    kFwSipH_On           = 0,
    kFwSipH_Off          = 1,
    kFwSipH_GetDefIn     = 2,
    kFwSipH_GetDefOut    = 3,
    kFwSipH_GetDefLogic  = 4,
    kFwSipH_GetDefEnable = 5,
};

enum kFwCritInfo {
    kFwCritOcpWarn = 0,
    kFwCritMax,
};

enum kFwAsicVer {
    kFwAsicVerA0 = 1,
    kFwAsicVerA1 = 2,
    kFwAsicVerA2 = 3,
    kFwAsicVerMax,
};

enum kFwPmode {
    kFwPmodePerf  = 0,
    kFwPmodeBoost = 1,
    kFwPmodeMax,
};

/**
 * SSM DEBUG LOG SUPPORT
 *
 * +---------------------------------------------------------+
 * | SHARED MEMORY IN USE[PAVO/DORADO]                       +
 * +---------------------------------------------------------+
 * | SSM_LOG_T.M_LOG_BUF_INDEX[U32] | SSM_LOG_T.M_LOG_BUF[0] |
 * +---------------------------------------------------------+
 * | LOG_HEADER_T[U64] + STR | LOG_HEADER_T[U64] + STR | ... |
 * +---------------------------------------------------------+
 */
typedef struct _ssm_log_hdr_t {
    uint64_t m_start_flag : 8;
    uint64_t m_timestamp : 48;
    uint64_t m_end_flag : 8;
} ssm_log_hdr_t;

#define SSM_LOG_HDR_FLAG_ST  (0x7F)
#define SSM_LOG_HDR_FLAG_ED  (0xF7)
#define SSM_LOG_BUF_SZ       (SSM_KB(7))

/**
 * IVM IMAGE HEADER
 */
struct image_header_v1_t {
    uint32_t header_version : 8;    // [0   :   0]
    uint32_t sig_algo : 8;          // [1   :   1]
    uint32_t iram_size:24;          // [2   :   4]
    uint32_t dram_size:24;          // [5   :   7]
    uint32_t image_type:8;          // [8   :   8]
    uint32_t image_version:24;      // [9   :  11]
    uint32_t prod_class;            // [12  :  15]
    uint32_t rev0[12];              // [16  :  63]
    uint32_t checksum[16];          // [64  : 127]    //CRC checksum
    uint32_t encrypted_hash[32];    // [128 : 255]
    uint32_t pubkey_e[32];          // [256 : 383]
    uint32_t pubkey_n[32];          // [384 : 511]
    uint32_t pubkey_r[32];          // [512 : 639]
    uint32_t pubkey_u[32];          // [640 : 767]
    uint32_t pubkey_np[1];          // [768 : 771]
    uint32_t rev1[63];              // [772 : 1023]
} __attribute__((packed));

struct image_header_v2_t {
    uint32_t header_version : 8;    // [0   :   0]
    uint32_t sig_algo: 8;           // [1   :   1]
    uint32_t iram_size:24;          // [2   :   4]
    uint32_t dram_size:24;          // [5   :   7]
    uint32_t rev0[24];              // [8   : 103]
    uint32_t image_type;            // [104 : 107]
    uint32_t prod_class;            // [108 : 111]
    uint32_t git_version;           // [112 : 115]
    uint32_t build_date;            // [116 : 119]
    uint32_t build_time;            // [120 : 123]
    uint32_t image_version;         // [124 : 127]
    uint32_t encrypted_hash[32];    // [128 : 255]
    uint32_t pubkey_e[32];          // [256 : 383]
    uint32_t pubkey_n[32];          // [384 : 511]
    uint32_t pubkey_r[32];          // [512 : 639]
    uint32_t pubkey_u[32];          // [640 : 767]
    uint32_t pubkey_np[1];          // [768 : 771]
    uint32_t rev1[63];              // [772 : 1023]
} __attribute__((packed));

struct image_header_v3_t {
    unsigned int header_version : 8;    // [0   :   0]
    unsigned int sig_algo: 8;           // [1   :   1]
    unsigned int iram_size:24;          // [2   :   4]
    unsigned int dram_size:24;          // [5   :   7]
    unsigned int iram_src_offset;       // [8   :  11]
    unsigned int dram_src_offset;       // [12  :  15]
    unsigned int iram_dst_offset;       // [16  :  19]
    unsigned int dram_dst_offset;       // [20  :  23]
    unsigned int rev0[20];              // [24  : 103]
    unsigned int image_type;            // [104 : 107]
    unsigned int prod_class;            // [108 : 111]
    unsigned int git_version;           // [112 : 115]
    unsigned int build_date;            // [116 : 119]
    unsigned int build_time;            // [120 : 123]
    unsigned int image_version;         // [124 : 127]
    unsigned int encrypted_hash[32];    // [128 : 255]
    unsigned int pubkey_e[32];          // [256 : 383]
    unsigned int pubkey_n[32];          // [384 : 511]
    unsigned int pubkey_r[32];          // [512 : 639]
    unsigned int pubkey_u[32];          // [640 : 767]
    unsigned int pubkey_np[1];          // [768 : 771]
    unsigned int rev1[63];              // [772 : 1023]
} __attribute__((packed));

struct image_header_v3_1_t {
    uint8_t header_version;        // [0   :   0]
    uint8_t sig_algo;              // [1   :   1]
    uint8_t fw_size[6];            // [2   :   7]
    uint32_t image_type;           // [8   :  11]
    uint32_t image_version;        // [12  :  15]
    uint32_t prod_class;           // [16  :  19]
    uint32_t build_time;           // [20  :  23]
    uint32_t build_date;           // [24  :  27]
    uint32_t git_version;          // [28  :  31]
    uint32_t rev0[24];             // [32  : 127]
    uint32_t encrypted_hash[32];   // [128 : 255]
    uint8_t m_pub_key[768];        // [256 : 1023]
} __attribute__((packed));

typedef enum {
    IMAGE_TYPE_CMN       = 0,
    IMAGE_TYPE_SSM_RT    = 1,
    IMAGE_TYPE_CQM       = 2,
    IMAGE_TYPE_TS        = 3,
    IMAGE_TYPE_PCIE      = 4,
    IMAGE_TYPE_IMU       = 5,
    IMAGE_TYPE_HCVG      = 6,
    IMAGE_TYPE_VDEC      = 7,
    IMAGE_TYPE_SSM_BL    = 8,
    IMAGE_TYPE_SSM_BFW   = 9,
    IMAGE_TYPE_SP        = 10,
    IMAGE_TYPE_AP        = 11,
    IMAGE_TYPE_VPP       = 12,
    IMAGE_TYPE_CVA       = 13,
    IMAGE_TYPE_AASP_ICCM = 14,
    IMAGE_TYPE_AASP_DCCM = 15,
    IMAGE_TYPE_SKU_INFO  = 16,
    IMAGE_TYPE_AMC       = 17,
} image_type_e;

// clang-format on

#endif  // HARDWARE_INCLUDE_SSM_FW_SSM_CMD_CMN_H_
