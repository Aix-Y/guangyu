/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_VR_SSM_VR_H_
#define HARDWARE_INCLUDE_SSM_VR_SSM_VR_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace vr {

class SsmVr : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmVr(Ssm *ssm);
    virtual ~SsmVr() {}

 public:
    virtual bool        vrm_supported(const std::string &);
    virtual void *      vrm_desc_rptr(const std::string &);
    virtual uint32_t    vrm_desc_size(const std::string &);
    virtual std::string vrm_desc_2str(void *);
    virtual std::string vrm_query_2str(const std::string &, uint32_t);
    virtual void *      vrm_query_desc(const std::string &, uint32_t);
    virtual bool        vrm_query_dump(const std::string &, const std::string &);
    virtual uint32_t    encode_volt(uint32_t, double);
    virtual double      decode_volt(uint32_t, uint32_t);
    virtual uint32_t    encode_volt_max16600(double);
    virtual double      decode_volt_max16600(uint32_t);
    virtual double      decode_temp(uint32_t);
    virtual double      decode_curr(uint32_t);
    virtual double      decode_power(uint32_t);
    virtual double      decode_volt_ina226_shunt(uint32_t);
    virtual double      decode_volt_ina226_bus(uint32_t);
    virtual double      decode_curr_ina226(uint32_t, uint32_t, double);
    virtual double      decode_power_ina226(uint32_t, uint32_t, double);
    virtual uint32_t    encode_volt_mpm82504(double);
    virtual double      decode_volt_mpm82504(uint32_t);
    virtual double      decode_curr_mpm82504(uint32_t);
    virtual double      decode_temp_mpm82504(uint32_t);
    virtual double      decode_data_by_req(const std::string &, uint32_t);
    virtual uint32_t    encode_data_by_req(const std::string &, double);
    virtual bool        is_vr_supported(uint32_t);
    virtual bool        is_vr_cap_r(const std::string &);
    virtual uint32_t    get_id_max(void);
    virtual uint32_t    vr_enum_to_id(uint32_t &);
    virtual uint32_t    vr_name_to_id(const std::string &);
    virtual std::string vr_id_to_name(const uint32_t &);
    virtual std::string vr_id_2str(const uint32_t &);
    virtual bool        chk_tid_valid(uint32_t);
    virtual std::string get_vr_name(uint32_t);
    virtual std::string get_vr_phyloc(uint32_t);
    virtual double      get_vr_temp(const std::string &);
    virtual double      get_vr_temp(uint32_t);
    virtual double      get_vr_temp_enum(uint32_t);
    virtual double      get_vr_curr(const std::string &);
    virtual double      get_vr_curr(uint32_t);
    virtual double      get_vr_curr_enum(uint32_t);
    virtual double      get_vr_volt(const std::string &);
    virtual double      get_vr_volt(uint32_t);
    virtual double      get_vr_volt_enum(uint32_t);
    virtual double      get_vr_volt_shunt(const std::string &);
    virtual double      get_vr_volt_shunt(uint32_t);
    virtual double      get_vr_volt_shunt_enum(uint32_t);
    virtual double      get_vr_volt_bus(const std::string &);
    virtual double      get_vr_volt_bus(uint32_t);
    virtual double      get_vr_volt_bus_enum(uint32_t);
    virtual double      get_vr_power(const std::string &);
    virtual double      get_vr_power(uint32_t);
    virtual double      get_vr_power_enum(uint32_t);
    virtual double      get_vr_power_asic(void);
    virtual double      get_vr_power_dmem(void);
    virtual uint32_t    get_vr_power_board_ave(void);
    virtual double      get_vr_power_true(void);
    virtual void        set_vr_ot_fault(const std::string &, double);
    virtual void        set_vr_ot_warn(const std::string &, double);
    virtual void        set_vr_oc_fault(const std::string &, double);
    virtual void        set_vr_loadline(uint32_t);
    virtual void        set_vr_dtu_vdroop_raw(uint32_t);
    virtual uint32_t    get_vr_dtu_vdroop_raw(void);
    virtual void        set_vr_volt(const std::string &, double);
    virtual void        set_vr_volt(uint32_t, double);
    virtual void        set_vr_volt_enum(uint32_t, double);
    virtual void        set_vr_avs_mv(uint32_t, uint32_t);
    virtual uint32_t    get_vr_avs_mv(uint32_t);

 public:
    virtual bool test_vr_golden_range_volt(void);
    virtual bool test_vr_golden_setting(void);
    virtual bool test_vr_check_ic_did(void);
    virtual bool test_vr_each_c_ave_dvi(void);
    virtual bool test_vr_each_v_ave_dvi(void);
    virtual bool test_vr_each_t_ave_dvi(void);
    virtual bool test_vr_each_p_ave_dvi(void);

 public:
    virtual bool        handle_req_volt_list(void);
    virtual bool        handle_req_curr_list(void);
    virtual bool        handle_req_power_list(void);
    virtual std::string handle_req_pmbus_read(const std::string &);
    virtual std::string handle_req_pmbus_write(const std::string &);
    virtual std::string handle_req_pmbus_dump(const std::string &);
    virtual bool        handle_req_pmbus_query(const std::string &);
    virtual bool        handle_req_pmon_list(void);
    virtual bool        handle_req_pmon_ext(const std::string &, const std::string &);
    virtual bool        handle_req_avs(const std::string &, const std::string &);
};

}  // namespace vr
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_VR_SSM_VR_H_
