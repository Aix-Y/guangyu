/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_SSM_H_
#define HARDWARE_INCLUDE_SSM_SSM_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ih.h"
#include "hardware/include/mdma/mdma.h"
#include "hardware/include/system_adapter.h"

#include "hardware/include/ssm/clk/ssm_clk.h"
#include "hardware/include/ssm/cmd/ssm_cmd.h"
#include "hardware/include/ssm/cpmu/ssm_cpmu.h"
#include "hardware/include/ssm/dma/ssm_dma.h"
#include "hardware/include/ssm/dmi/ssm_dmi.h"
#include "hardware/include/ssm/fiw/ssm_fiw.h"
#include "hardware/include/ssm/fuse/ssm_fuse.h"
#include "hardware/include/ssm/gpio/ssm_gpio.h"
#include "hardware/include/ssm/i2c/ssm_i2c.h"
#include "hardware/include/ssm/intf/ssm_intf.h"
#include "hardware/include/ssm/ivm/ssm_ivm.h"
#include "hardware/include/ssm/mcu/ssm_mcu.h"
#include "hardware/include/ssm/mem/ssm_mem.h"
#include "hardware/include/ssm/misc/ssm_misc.h"
#include "hardware/include/ssm/otp/ssm_otp.h"
#include "hardware/include/ssm/pins/ssm_pins.h"
#include "hardware/include/ssm/plv/ssm_plv.h"
#include "hardware/include/ssm/pmon/ssm_pmon.h"
#include "hardware/include/ssm/ras/ssm_ras.h"
#include "hardware/include/ssm/reg/ssm_reg.h"
#include "hardware/include/ssm/reset/ssm_reset.h"
#include "hardware/include/ssm/rpfei/ssm_rpfei.h"
#include "hardware/include/ssm/sdw/ssm_sdw.h"
#include "hardware/include/ssm/secure/ssm_secure.h"
#include "hardware/include/ssm/sem/ssm_sem.h"
#include "hardware/include/ssm/sih/ssm_sih.h"
#include "hardware/include/ssm/spi/ssm_spi.h"
#include "hardware/include/ssm/timer/ssm_timer.h"
#include "hardware/include/ssm/uart/ssm_uart.h"
#include "hardware/include/ssm/vr/ssm_vr.h"

namespace efvf {
namespace hardware {
namespace ssm {

class Ssm : public Hardware {
 public:
    explicit Ssm(std::shared_ptr<spdlog::logger>);
    virtual ~Ssm() {}

 private:
    virtual bool HwInit();

 public:
    virtual uint64_t r_base(const std::string & /*mip_mid_sid*/);
    virtual uint32_t r_r32(uint32_t);
    virtual void     r_w32(uint32_t, uint32_t);

 public:
    virtual reg::SsmReg *                  GetReg();
    virtual mem::SsmMem *                  GetMem();
    virtual cmd::SsmCmd *                  GetCmd();
    virtual mcu::SsmMcu *                  GetMcu();
    virtual spi::SsmSpi *                  GetSpi();
    virtual sih::SsmSih *                  GetSih();
    virtual clk::SsmClk *                  GetClk();
    virtual misc::SsmMisc *                GetMisc();
    virtual fuse::SsmFuse *                GetFuse();
    virtual otp::SsmOtp *                  GetOtp();
    virtual dma::SsmDma *                  GetDma();
    virtual mdma::Mdma *                   GetMdma();
    virtual uart::SsmUart *                GetUart();
    virtual timer::SsmTimer *              GetTimer();
    virtual fiw::SsmFiw *                  GetFiw();
    virtual gpio::SsmGpio *                GetGpio();
    virtual i2c::SsmI2c *                  GetI2c();
    virtual pmon::SsmPmon *                GetPmon();
    virtual pins::SsmPins *                GetPins();
    virtual dmi::SsmDmi *                  GetDmi();
    virtual vr::SsmVr *                    GetVr();
    virtual ivm::SsmIvm *                  GetIvm();
    virtual reset::SsmReset *              GetReset();
    virtual rpfei::SsmRpfei *              GetRpfei();
    virtual secure::SsmSecure *            GetSecure();
    virtual sem::SsmSem *                  GetSem();
    virtual cpmu::SsmCpmu *                GetCpmu();
    virtual sdw::SsmSdw *                  GetSdw();
    virtual plv::SsmPlv *                  GetPlv();
    virtual intf::SsmIntf *                GetIntf();
    virtual system_adapter::SystemAdapter *GetSa();
    virtual ih::Ih *                       GetMih();

 protected:
    std::unique_ptr<reg::SsmReg>       m_reg    = nullptr;
    std::unique_ptr<mem::SsmMem>       m_mem    = nullptr;
    std::unique_ptr<cmd::SsmCmd>       m_cmd    = nullptr;
    std::unique_ptr<mcu::SsmMcu>       m_mcu    = nullptr;
    std::unique_ptr<spi::SsmSpi>       m_spi    = nullptr;
    std::unique_ptr<sih::SsmSih>       m_sih    = nullptr;
    std::unique_ptr<clk::SsmClk>       m_clk    = nullptr;
    std::unique_ptr<misc::SsmMisc>     m_misc   = nullptr;
    std::unique_ptr<fuse::SsmFuse>     m_fuse   = nullptr;
    std::unique_ptr<otp::SsmOtp>       m_otp    = nullptr;
    std::unique_ptr<dma::SsmDma>       m_dma    = nullptr;
    std::unique_ptr<uart::SsmUart>     m_uart   = nullptr;
    std::unique_ptr<timer::SsmTimer>   m_timer  = nullptr;
    std::unique_ptr<fiw::SsmFiw>       m_fiw    = nullptr;
    std::unique_ptr<gpio::SsmGpio>     m_gpio   = nullptr;
    std::unique_ptr<i2c::SsmI2c>       m_i2c    = nullptr;
    std::unique_ptr<pmon::SsmPmon>     m_pmon   = nullptr;
    std::unique_ptr<pins::SsmPins>     m_pins   = nullptr;
    std::unique_ptr<dmi::SsmDmi>       m_dmi    = nullptr;
    std::unique_ptr<vr::SsmVr>         m_vr     = nullptr;
    std::unique_ptr<ivm::SsmIvm>       m_ivm    = nullptr;
    std::unique_ptr<reset::SsmReset>   m_reset  = nullptr;
    std::unique_ptr<rpfei::SsmRpfei>   m_rpfei  = nullptr;
    std::unique_ptr<secure::SsmSecure> m_secure = nullptr;
    std::unique_ptr<sem::SsmSem>       m_sem    = nullptr;
    std::unique_ptr<cpmu::SsmCpmu>     m_cpmu   = nullptr;
    std::unique_ptr<sdw::SsmSdw>       m_sdw    = nullptr;
    std::unique_ptr<plv::SsmPlv>       m_plv    = nullptr;
    std::unique_ptr<intf::SsmIntf>     m_intf   = nullptr;

 public:
    std::mutex m_mutex_ssmseq;
};

}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_SSM_H_
