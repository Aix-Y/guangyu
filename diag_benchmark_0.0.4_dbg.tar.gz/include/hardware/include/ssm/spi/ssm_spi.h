/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_SPI_SSM_SPI_H_
#define HARDWARE_INCLUDE_SSM_SPI_SSM_SPI_H_

#include <string>
#include <vector>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace spi {

class SsmSpi : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmSpi(Ssm *ssm);
    virtual ~SsmSpi() {}

 public:
    virtual uint32_t ssm_spi_density(void);
    virtual bool     ssm_spi_4k_erase(uint32_t);
    virtual bool     ssm_spi_erase_all(void);
    virtual bool     ssm_spi_erase_bytes(SSM_SPI_REQ &);
    virtual bool     ssm_spi_progm_bytes(SSM_SPI_REQ &);
    virtual bool     ssm_spi_eprog_bytes(SSM_SPI_REQ &);
    virtual void     ssm_spi_flash_read(uint32_t, uint32_t, void *);
    virtual void     ssm_spi_flash_write(uint32_t, uint32_t, void *);
    virtual void     ssm_spi_status(void);
    virtual void     ssm_spi_reset(uint32_t);
    virtual void     ssm_spi_reset_lspi(void);
    virtual void     ssm_spi_reset_qspi(void);
    virtual bool     ssm_spi_flash_dump(const std::string &, uint32_t, uint32_t);
    virtual bool     ssm_spi_flash_file(const std::string &, uint32_t, uint32_t);
    virtual bool     test_spi_gencmd_read(void);
    virtual bool     test_spi_gencmd_read_mix(void);
    virtual bool     test_spi_gencmd_erase4k(void);
    virtual bool     test_spi_gencmd_write(void);
    virtual bool     test_spi_gencmd_read_all(void);
    virtual bool     test_spi_gencmd_read_hs(void);
    virtual bool     test_spi_fwload_to_iram(void);
    virtual bool     test_spi_fwload_to_dram(void);
    virtual bool     test_spi_fwload_to_smem(void);
    virtual bool     test_spi_fwload_backdoor_rc(void);
    virtual bool     test_spi_pgprog_iram_fwload_rc(void);
    virtual bool     test_spi_pgprog_dram_fwload_rc(void);
    virtual bool     test_spi_pgprog_smem_fwload_rc(void);
    virtual bool     test_spi_fwload_measure(void);
    virtual bool     test_spi_pgprog_measure(void);
    virtual bool     test_spi_rw_basic(void);
    virtual bool     test_spi_backup_fw(void);
    virtual bool     test_spi_last4k_erase_rc(void);
    virtual bool     test_spi_last4k_pattern_bist(void);
    virtual bool     test_spi_erase_all_rc(void);
    virtual bool     test_spi_erase_all_pattern_bist_rc(void);

 public:
    virtual uint64_t handle_tool_req_get_u64(const std::string &, const uint32_t &);
    virtual bool     handle_tool_req_set_u64(
        const std::string &, const uint64_t &, const uint64_t &);
    virtual bool handle_tool_req_set(const std::string &, std::vector<uint32_t> &);
    virtual bool handle_req_spi_test(const std::string &, const std::string &);
    virtual void handle_req_spi_usage(void);
    virtual bool handle_req_spi_freq(const std::string &, const std::string &);
};

}  // namespace spi
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_SPI_SSM_SPI_H_
