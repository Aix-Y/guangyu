/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_MCU_SSM_MCU_H_
#define HARDWARE_INCLUDE_SSM_MCU_SSM_MCU_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace mcu {

class SsmMcu : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmMcu(Ssm *ssm);
    virtual ~SsmMcu() {}

 private:
    uint32_t m_board_type = SSM_MAGIC;

 public:
    virtual uint32_t    ssm_reg_read(uint32_t /*addr*/);
    virtual void        ssm_reg_write(uint32_t /*addr*/, uint32_t /*val*/);
    virtual bool        ssm_check_boot_complete(uint64_t = 0 /*timeout_ms*/);
    virtual uint32_t    ssm_check_boot_error(void);
    virtual bool        ssm_check_flr_status(uint32_t = SSM_MAGIC /*timeout_ms*/);
    virtual void        ssm_stop(void);
    virtual void        ssm_start(void);
    virtual void        ssm_stop_d2d(void);
    virtual bool        ssm_feature_is_on(uint32_t);
    virtual bool        ssm_feature_is_off(uint32_t);
    virtual void        ssm_feature_ena_all(void);
    virtual void        ssm_feature_dis_all(void);
    virtual bool        ssm_feature_op_skip(uint32_t);
    virtual bool        ssm_feature_is_valid(uint32_t);
    virtual uint32_t    ssm_feature_idmask(uint32_t);
    virtual uint32_t    ssm_feature_status_get(void);
    virtual void        ssm_feature_enable(uint32_t);
    virtual void        ssm_feature_disable(uint32_t);
    virtual void        ssm_feature_mask_enable(uint32_t);
    virtual void        ssm_feature_mask_disable(uint32_t);
    virtual void        ssm_ulv_state_force(bool);
    virtual bool        ssm_ulv_state_get(void);
    virtual bool        ssm_ulv_state_save(void);
    virtual void        ssm_ulv_state_restore(void);
    virtual bool        ssm_ulv_exit_disable(void);
    virtual bool        ssm_gbage_dtu_sticky(void);
    virtual bool        ssm_gbage_soc_sticky(void);
    virtual bool        ssm_gbapp_dtu_sticky(void);
    virtual bool        ssm_gbapp_soc_sticky(void);
    virtual std::string ssm_pmode_2str(uint32_t);
    virtual uint32_t    ssm_pmode_get(void);
    virtual uint32_t    ssm_pmode_set(uint32_t);
    virtual uint32_t    ssm_power_cap(void);
    virtual void        ssm_feat_alter_save(void);
    virtual void        ssm_feat_alter_restore(void);
    virtual void        ssm_apply_onchip_vddc(uint32_t, double);
    virtual void        ssm_force_onchip_vddc(uint32_t);
    virtual uint32_t    ssm_qdd_eeprom_r_dw(uint32_t, uint32_t);
    virtual std::string get_str_board_type(uint32_t);
    virtual std::string get_str_board_rev(uint32_t);
    virtual std::string get_str_bfw_ver(uint32_t);
    virtual std::string get_str_rfw_ver(uint32_t);
    virtual std::string get_str_amc_ver(uint32_t);
    virtual std::string get_str_dmem_type(uint32_t = SSM_MAGIC);
    virtual std::string get_native_uuid(void);
    virtual std::string get_remote_uuid(uint32_t);
    virtual uint32_t    get_remote_uuid_num(void);
    virtual uint32_t    get_board_type(void);
    virtual bool        is_brd_prd(void);
    virtual bool        is_brd_pam(void);
    virtual bool        is_brd_oam(void);
    virtual bool        is_brd_mxm(void);

 public:
    virtual bool test_mcu_golden_soc_sku(void);
    virtual bool test_mcu_golden_xram_repair(void);

 public:
    virtual bool        handle_req_ssm_ping(void);
    virtual bool        handle_req_ssm_test(const std::string &, const std::string &);
    virtual std::string handle_req_bfw_version(void);
    virtual std::string handle_req_rfw_version(void);
    virtual void        handle_req_ssm_versions(void);
    virtual void        handle_req_ssm_status(void);
    virtual uint32_t    handle_req_ssm_r32(const std::string &);
    virtual bool        handle_req_ssm_decode(const std::string &, const std::string &);
    virtual bool        handle_req_ssm_encode(const std::string &, const std::string &);
    virtual bool        handle_req_ssm_query(const std::string &);
    virtual bool        handle_req_ssm_uuid(void);
    virtual bool        handle_req_ssm_gsync(const std::string &);
    virtual std::string handle_req_ssm_pmode_get(void);
    virtual bool        handle_req_ssm_pmode_set(const std::string &);
    virtual std::string handle_req_ssm_log(const std::string &);
    virtual bool        handle_req_ssm_pc(const std::string &);
    virtual std::string handle_req_ssm_pc_r(const std::string &);
    virtual std::string handle_req_ssm_task_r(const std::string &);
    virtual bool        handle_req_gd_update(const std::string &);
    virtual std::string handle_req_ssm_feat(const std::string &, const std::string &);
};

}  // namespace mcu
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_MCU_SSM_MCU_H_
