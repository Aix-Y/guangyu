/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_SDW_SSM_SDW_H_
#define HARDWARE_INCLUDE_SSM_SDW_SSM_SDW_H_

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace sdw {

class SsmSdw : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmSdw(Ssm *ssm);
    virtual ~SsmSdw() {}

 public:
    virtual void sdw_ena(bool);
    virtual void sdw_int_ena(bool);
    virtual void sdw_int_clr(void);
    virtual void sdw_debug_dump(uint32_t = SSM_MAGIC);
    virtual void sdw_force_decrypt(uint32_t, bool);
    virtual void sdw_force_integrity(uint32_t, bool);
    virtual bool sdw_update_key(uint32_t, void *, void *);
};

}  // namespace sdw
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_SDW_SSM_SDW_H_
