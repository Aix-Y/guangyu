/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_MISC_SSM_MISC_H_
#define HARDWARE_INCLUDE_SSM_MISC_SSM_MISC_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace misc {

class SsmMisc : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmMisc(Ssm *ssm);
    virtual ~SsmMisc() {}

 public:
    virtual bool        dbg_test(uint32_t, uint32_t);
    virtual uint32_t    dbg_interface(uint32_t, uint32_t, uint32_t, uint64_t = 0);
    virtual uint32_t    drv_interface(uint32_t, uint32_t, uint32_t, uint64_t = 0);
    virtual uint32_t    get_chip_version(void);
    virtual uint32_t    get_asic_version(void);
    virtual uint32_t    get_ssm_version(void);
    virtual std::string get_ssm_ver_str(uint32_t);
    virtual std::string get_ssm_ctime_str(void);
    virtual uint32_t    get_amc_version(void);
    virtual std::string get_amc_ver_str(uint32_t);
    virtual uint32_t    get_imu_version(uint32_t);
    virtual uint32_t    get_imu_data_rate(uint32_t);
    virtual uint32_t    get_crit_ping_addr(void);
    virtual uint32_t    get_crit_pong_addr(void);
    virtual std::string get_chip_uuid(void);
    virtual std::string ssm_fw_version(void);
    virtual std::string amc_fw_version(void);
    virtual std::string ssm_board_type(void);
    virtual std::string ssm_board_rev(void);
    virtual std::string ssm_board_ptime(std::string = "");
    virtual bool        ssm_board_ptime_cmp(const std::string &, const std::string &);
    virtual std::string ssm_pn_read(void);
    virtual void        ssm_pn_write(const std::string &, std::string = 0);
    virtual bool        ssm_pn_valid(const std::string &);
    virtual std::string ssm_sn_read(void);
    virtual void        ssm_sn_write(const std::string &, std::string = 0);
    virtual bool        ssm_sn_valid(const std::string &);
    virtual std::string ssm_openflag_read(void);
    virtual void        ssm_openflag_write(const std::string &);
    virtual bool        ssm_openflag_valid(const std::string &);
    virtual bool        ssm_sip_harvest_ctrl(bool, uint32_t = 0);
    virtual uint32_t    ssm_sip_harvest_info(uint32_t);
    virtual bool        ssm_eeprom_read(void *);
    virtual bool        ssm_eeprom_erase(void);
    virtual bool        ssm_prepare_update(void);
    virtual bool        chk_amc_alive(void);

 public:
    virtual bool test_fw_life_cycle(void);
    virtual bool test_fw_port_healthy(void);
    virtual bool test_fw_port_reg_intf(const std::string &);
    virtual bool test_mcu_mailbox_ref_setting(void);
    virtual bool test_mcu_mailbox_uniq_sig_mismatch(void);
    virtual bool test_mcu_mailbox_uniq_sig_overflow(void);
    virtual bool test_mcu_mailbox_uniq_sig_ref_va(void);
    virtual bool test_mcu_mailbox_mismatch_ibound(void);

 public:
    virtual void        handle_req_imu_ver_dump(void);
    virtual bool        handle_req_edcc_vddc(const std::string &, const std::string &);
    virtual bool        handle_req_sip_harvest(const std::string &, const std::string &);
    virtual std::string handle_req_fru(const std::string &, std::string = "");
    virtual std::string handle_req_fru_cfg(const std::string &, std::string = "");
    virtual void        handle_req_ssm_compile_time(void);
    virtual void        handle_req_ssm_chipversions(void);
    virtual bool        handle_req_ssm_qdd(const std::string &, const std::string &);
};

}  // namespace misc
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_MISC_SSM_MISC_H_
