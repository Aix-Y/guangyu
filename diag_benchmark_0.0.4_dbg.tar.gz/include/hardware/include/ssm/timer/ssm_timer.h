/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_TIMER_SSM_TIMER_H_
#define HARDWARE_INCLUDE_SSM_TIMER_SSM_TIMER_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace timer {

class SsmTimer : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmTimer(Ssm *ssm);
    virtual ~SsmTimer() {}

 public:
    virtual void watchdog_assert(void);
    virtual void watchdog_deassert(void);

 public:
    virtual bool test_timer_freq_measure(const std::string &);
    virtual bool test_timer_chronograph(const std::string &);
    virtual bool test_timer_time_slice(const std::string &);
    virtual bool test_timer_interrupt(const std::string &);
    virtual bool test_timer_watchdog_feeding(void);

 public:
    virtual bool handle_req_watchdog(const std::string &);
    virtual void handle_req_test(const std::string &);
};

}  // namespace timer
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_TIMER_SSM_TIMER_H_
