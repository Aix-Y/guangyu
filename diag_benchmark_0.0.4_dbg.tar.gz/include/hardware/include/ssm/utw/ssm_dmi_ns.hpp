/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_DMI_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_DMI_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace dmi {

// clang-format off
enum kSsmDmi {
    kSsmDmi_0  = 0,
    kSsmDmi_1  = 1,
    kSsmDmi_2  = 2,
    kSsmDmi_3  = 3,
    kSsmDmi_4  = 4,
    kSsmDmi_5  = 5,
    kSsmDmi_6  = 6,
    kSsmDmi_7  = 7,
    kSsmDmi_8  = 8,
    kSsmDmi_9  = 9,
    kSsmDmi_10 = 10,
    kSsmDmi_11 = 11,
    kSsmDmi_Max,
    kSsmDmi_All,  // partial cmd support
};

typedef struct {
    std::string nm;
    std::string loc;
    uint32_t    fwidx;
} ssm_dmi_t;

typedef struct {
    std::string nm;
    std::string loc;
    uint32_t    fwgrp;
    uint32_t    fwidx;
} ssm_dmi_3d0_t;

typedef struct {
    bool     rma_flag;     // true: rma needed false: rma not needed
    uint32_t rma_iraw;     // fw info raw saved
    uint32_t rma_type;     // fw t_hbm_rma_flag.m_rma_type SSM_HBM_RMA_TYPE
    uint32_t hbm_id;       // fw t_hbm_rma_flag.m_hbm_id
    uint32_t hbm_chan;     // fw t_hbm_rma_flag.m_hbm_chan
    uint32_t hbm_bank;     // fw t_hbm_rma_flag.m_bank
    uint32_t hbm_row;      // fw t_hbm_rma_flag.m_row
    uint32_t hbm_err;      // fw t_hbm_rma_flag.m_double_bit_error
    uint32_t checksum;     // fw t_hbm_rma_flag.m_checksum
    uint32_t rmap_all;     // hbm row remapping number for all
    uint32_t rmap_num[4];  // hbm row remapping number for each
} SSM_RMA_INFO_2D0_t;

typedef struct _ssm_rma_info {
    bool     rma_flag;     // true: rma needed false: rma not needed
    uint32_t f1_data;      // rma raw type
    uint32_t f2_data[12];  // per each inst error count
    uint32_t f3_data;      // total error count
    uint32_t f4_data;      // rma raw data
    uint32_t f2_inst;      // available inst number
} SSM_RMA_INFO_3D0_t;

// clang-format on

}  // namespace dmi
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_DMI_NS_HPP_
