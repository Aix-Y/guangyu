/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_SPI_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_SPI_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace spi {

typedef struct _ssm_spi_req {
    uint32_t    spi_addr;  // op address
    uint32_t    spi_size;  // op size
    std::string spi_item;  // op item
    bool        spi_pgss;  // op progress
    void *      spi_dbuf;  // op buffer io
} SSM_SPI_REQ;

typedef struct {
    uint32_t op_code;
    uint32_t op_addr;
    uint32_t op_data;
    uint32_t op_size;
    uint32_t op_oput_lo;
    uint32_t op_oput_hi;
    uint32_t iput_lo;
    uint32_t iput_hi;
    uint32_t setting;
    bool     rd_data;
} SSM_SPI_GENCMD;

enum {
    SSM_SPI_MODE_INVAL = 0,
    SSM_SPI_MODE_LSPI,  // SPI Serial Peripheral Interface
    SSM_SPI_MODE_QSPI,  // SQI Serial Quad I/O
};

inline std::string spi_mode_str(uint32_t spi_mode) {
    switch (spi_mode) {
        case SSM_SPI_MODE_INVAL:
            return "SPI_MODE_INVAL";
        case SSM_SPI_MODE_LSPI:
            return "LSPI";
        case SSM_SPI_MODE_QSPI:
            return "QSPI";
        default:
            break;
    }

    return "SSM_SPI_MODE_UNKNOWN";
}

// clang-format off
const uint32_t SPI_DENSITY_KB_512            = SSM_KB(512);     // NOLINT 1.0
const uint32_t SPI_DENSITY_KB_1024           = SSM_MBITS2B(8);  // NOLINT 2.0|3.0 GD25LQ80E 8Mbit
const uint32_t SPI_SE_ECAP_KB_4              = SSM_KB(4);       // NOLINT sector 4KB memory array
const uint32_t SPI_PGPROG_B_256              = 0x100;           // NOLINT 256Bytes
const uint32_t SPI_FWLOAD_B_16               = 0x10;            // NOLINT 16Bytes
const uint32_t SPI_RAM_ALIGN_B_16            = 0x10;            // NOLINT 128bits

const uint32_t SPI_ADDR_CRITICAL_PING_1D0    = (0x7e000);                          // NOLINT FW DEFINED
const uint32_t SPI_ADDR_CRITICAL_PONG_1D0    = (0x7f000);                          // NOLINT FW DEFINED
const uint32_t SPI_ADDR_CRITICAL_PING_2D0    = (SPI_DENSITY_KB_1024 - SSM_KB(8));  // NOLINT FW DEFINED
const uint32_t SPI_ADDR_CRITICAL_PONG_2D0    = (SPI_DENSITY_KB_1024 - SSM_KB(4));  // NOLINT FW DEFINED
const uint32_t SPI_ADDR_CRITICAL_PING_2D1    = (SPI_ADDR_CRITICAL_PING_2D0);       // NOLINT FW DEFINED
const uint32_t SPI_ADDR_CRITICAL_PONG_2D1    = (SPI_ADDR_CRITICAL_PONG_2D0);       // NOLINT FW DEFINED
const uint32_t SPI_ADDR_CRITICAL_PING_3D0    = (SPI_ADDR_CRITICAL_PING_2D1);       // NOLINT FW DEFINED
const uint32_t SPI_ADDR_CRITICAL_PONG_3D0    = (SPI_ADDR_CRITICAL_PONG_2D1);       // NOLINT FW DEFINED
const uint32_t SPI_ADDR_CRITICAL_PING_4D0    = (SPI_ADDR_CRITICAL_PING_3D0);       // NOLINT FW DEFINED
const uint32_t SPI_ADDR_CRITICAL_PONG_4D0    = (SPI_ADDR_CRITICAL_PONG_3D0);       // NOLINT FW DEFINED

const uint32_t SPI_ADDR_RAM_OFFSET_ST_3D0   = (0x17A00);
const uint32_t SPI_ADDR_RAM_OFFSET_ED_3D0   = (0x17BFF);
const uint32_t SPI_ADDR_RAM_OFFSET_RD_3D0   = (SPI_ADDR_RAM_OFFSET_ST_3D0 + 0);    // NOLINT
const uint32_t SPI_ADDR_RAM_OFFSET_WR_3D0   = (SPI_ADDR_RAM_OFFSET_ST_3D0 + 256);  // NOLINT
const uint32_t SPI_ADDR_RAM_OFFSET_SZ_3D0   = (SPI_ADDR_RAM_OFFSET_ED_3D0 - SPI_ADDR_RAM_OFFSET_ST_3D0 + 1);  // NOLINT

const uint32_t SPI_ADDR_RAM_OFFSET_ST_4D0   = (0x2FE00);
const uint32_t SPI_ADDR_RAM_OFFSET_ED_4D0   = (0x2FFFF);
const uint32_t SPI_ADDR_RAM_OFFSET_RD_4D0   = (SPI_ADDR_RAM_OFFSET_ST_4D0 + 0);    // NOLINT
const uint32_t SPI_ADDR_RAM_OFFSET_WR_4D0   = (SPI_ADDR_RAM_OFFSET_ST_4D0 + 256);  // NOLINT
const uint32_t SPI_ADDR_RAM_OFFSET_SZ_4D0   = (SPI_ADDR_RAM_OFFSET_ED_4D0 - SPI_ADDR_RAM_OFFSET_ST_4D0 + 1);  // NOLINT

const uint32_t SPI_MAF_ID_MICROCHIP          = (0xBF);
const uint32_t SPI_MAF_ID_GIGADEVICE         = (0xC8);
const uint32_t SPI_TPP_US_MICROCHIP          = SSM_MS2US(1.5);
const uint32_t SPI_TPP_US_GIGADEVICE         = SSM_MS2US(0.4);  // ranges [0.4 ~ 2.4]

enum kSpiOp {
    // configuration
    SPI_OPI_NOP = 0x00,     // no operation
    SPI_OPI_RSTEN,          // reset enable
    SPI_OPI_RST4,           // reset memory
    SPI_OPI_EQIO,           // enable quad io
    SPI_OPI_RSTQIO5,        // reset quad io
    SPI_OPI_RDSR,           // read status register
    SQI_OPI_RDSR,           // read status register
    SPI_OPI_WRSR,           // write status register
    SPI_OPI_RDCR,           // read configuration register
    SQI_OPI_RDCR,           // read configuration register
    // read
    SPI_OPI_READ,           // read memory
    SPI_OPI_READ_HS,        // read memory at higher speed
    SQI_OPI_READ_HS,        // read memory at higher speed
    SPI_OPI_SQOR6,          // spi quad output read
    SPI_OPI_SQIOR7,         // spi quad io read
    SPI_OPI_SDOR8,          // spi dual output read
    SPI_OPI_SDIOR9,         // spi dual io read
    SPI_OPI_SB,             // set burst length
    SPI_OPI_RBSQI,          // sqi nb burst with wrap
    SPI_OPI_RBSPI7,         // spi nb burst with wrap
    // identification
    SPI_OPI_JEDEC_ID,       // jedec-id read
    SPI_OPI_QUAD_J_ID,      // quad io j-id read
    SPI_OPI_SFDP,           // serial flash discoverable parameters
    // write
    SPI_OPI_WREN,           // write enable
    SPI_OPI_WRDI,           // write disable
    SPI_OPI_SE10,           // erase 4 KBytes of memory array
    SPI_OPI_BE11,           // erase 64,32 or 8 KBytes of memory array
    SPI_OPI_CE,             // erase full array
    SPI_OPI_PP,             // page program
    SPI_OPI_QUAD_PP6,       // sqi quad page program
    SPI_OPI_WRSU,           // suspends program/erase
    SPI_OPI_WRRE,           // resumes program/erase
    // protection
    SPI_OPI_RBPR,           // read block protection register
    SQI_OPI_RBPR,           // read block protection register
    SPI_OPI_WBPR,           // write block protection register
    SPI_OPI_LBPR,           // lock down block protection register
    SPI_OPI_NVWLDR,         // non-volatile write lock-down register
    SPI_OPI_ULBPR,          // global block protection unlock
    SPI_OPI_RSID,           // read security id
    SPI_OPI_PSID,           // program user security id area
    SPI_OPI_LSID,           // lockout security id programming
    // power saving
    SPI_OPI_DPD,            // deep power down mode
    SPI_OPI_RDPD,           // release from deep power down and read id

    // GD25LQ80E SPECIAL
    SPI_OPI_G_REMS,         // read manufacture/device id alternative to RDPD
};

inline std::string opi_decode_str(uint32_t opi_code) {
    switch (opi_code) {
        case SPI_OPI_NOP:             return "SPI_OPI_NOP       ";
        case SPI_OPI_RSTEN:           return "SPI_OPI_RSTEN     ";
        case SPI_OPI_RST4:            return "SPI_OPI_RST4      ";
        case SPI_OPI_EQIO:            return "SPI_OPI_EQIO      ";
        case SPI_OPI_RSTQIO5:         return "SPI_OPI_RSTQIO5   ";
        case SPI_OPI_RDSR:            return "SPI_OPI_RDSR      ";
        case SQI_OPI_RDSR:            return "SQI_OPI_RDSR      ";
        case SPI_OPI_WRSR:            return "SPI_OPI_WRSR      ";
        case SPI_OPI_RDCR:            return "SPI_OPI_RDCR      ";
        case SQI_OPI_RDCR:            return "SQI_OPI_RDCR      ";
        case SPI_OPI_READ:            return "SPI_OPI_READ      ";
        case SPI_OPI_READ_HS:         return "SPI_OPI_READ_HS   ";
        case SQI_OPI_READ_HS:         return "SQI_OPI_READ_HS   ";
        case SPI_OPI_SQOR6:           return "SPI_OPI_SQOR6     ";
        case SPI_OPI_SQIOR7:          return "SPI_OPI_SQIOR7    ";
        case SPI_OPI_SDOR8:           return "SPI_OPI_SDOR8     ";
        case SPI_OPI_SDIOR9:          return "SPI_OPI_SDIOR9    ";
        case SPI_OPI_SB:              return "SPI_OPI_SB        ";
        case SPI_OPI_RBSQI:           return "SPI_OPI_RBSQI     ";
        case SPI_OPI_RBSPI7:          return "SPI_OPI_RBSPI7    ";
        case SPI_OPI_JEDEC_ID:        return "SPI_OPI_JEDEC_ID  ";
        case SPI_OPI_QUAD_J_ID:       return "SPI_OPI_QUAD_J_ID ";
        case SPI_OPI_SFDP:            return "SPI_OPI_SFDP      ";
        case SPI_OPI_WREN:            return "SPI_OPI_WREN      ";
        case SPI_OPI_WRDI:            return "SPI_OPI_WRDI      ";
        case SPI_OPI_SE10:            return "SPI_OPI_SE10      ";
        case SPI_OPI_BE11:            return "SPI_OPI_BE11      ";
        case SPI_OPI_CE:              return "SPI_OPI_CE        ";
        case SPI_OPI_PP:              return "SPI_OPI_PP        ";
        case SPI_OPI_QUAD_PP6:        return "SPI_OPI_QUAD_PP6  ";
        case SPI_OPI_WRSU:            return "SPI_OPI_WRSU      ";
        case SPI_OPI_WRRE:            return "SPI_OPI_WRRE      ";
        case SPI_OPI_RBPR:            return "SPI_OPI_RBPR      ";
        case SQI_OPI_RBPR:            return "SQI_OPI_RBPR      ";
        case SPI_OPI_WBPR:            return "SPI_OPI_WBPR      ";
        case SPI_OPI_LBPR:            return "SPI_OPI_LBPR      ";
        case SPI_OPI_NVWLDR:          return "SPI_OPI_NVWLDR    ";
        case SPI_OPI_ULBPR:           return "SPI_OPI_ULBPR     ";
        case SPI_OPI_RSID:            return "SPI_OPI_RSID      ";
        case SPI_OPI_PSID:            return "SPI_OPI_PSID      ";
        case SPI_OPI_LSID:            return "SPI_OPI_LSID      ";
        case SPI_OPI_DPD:             return "SPI_OPI_DPD       ";
        case SPI_OPI_RDPD:            return "SPI_OPI_RDPD      ";
        case SPI_OPI_G_REMS:          return "SPI_OPI_G_REMS    ";
        default: break;
    }

    return "SPI_OPI_UNDEFINED";
}
// clang-format on

enum {
    SPI_OPI_TYP_RD,
    SPI_OPI_TYP_SET,
    SPI_OPI_TYP_INVALID,
};

typedef struct {
    uint32_t spi_opc;  // SSM_SPI_GENCMD.op_code
    uint32_t opi_cmd;
    uint32_t opi_typ;
    uint32_t opi_adc;  // address cycle
    uint32_t opi_dmc;  //  dummy cycle
    uint32_t opi_dtc;  //   data cycle
} SSM_OPI_INFO;

namespace MICROCHIP_SQI_F_SST26WF {  // SST26WF040B/040BA AND SST26WF080B/080BA | GD25LQ80E

inline SSM_OPI_INFO *opi_cmd_info_get(uint32_t op_code) {
    // clang-format off
    static SSM_OPI_INFO opi_info[] = {
        /**            CONFIGURATION                **/
        { .spi_opc = SPI_OPI_NOP,       .opi_cmd = 0x00, /* no operation                              */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_RSTEN,     .opi_cmd = 0x66, /* reset enable                              */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_RST4,      .opi_cmd = 0x99, /* reset memory                              */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_EQIO,      .opi_cmd = 0x38, /* enable quad io                            */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_RSTQIO5,   .opi_cmd = 0xff, /* reset quad io                             */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_RDSR,      .opi_cmd = 0x05, /* read status register                      */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SQI_OPI_RDSR,      .opi_cmd = 0x05, /* read status register                      */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 0U, .opi_dmc = 1U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_WRSR,      .opi_cmd = 0x01, /* write status register                     */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 2U, },  // NOLINT
        { .spi_opc = SPI_OPI_RDCR,      .opi_cmd = 0x35, /* read configuration register               */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SQI_OPI_RDCR,      .opi_cmd = 0x35, /* read configuration register               */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 0U, .opi_dmc = 1U, .opi_dtc = 1U, },  // NOLINT
        /**            READ                         **/
        { .spi_opc = SPI_OPI_READ,      .opi_cmd = 0x03, /* read memory                               */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 3U, .opi_dmc = 0U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_READ_HS,   .opi_cmd = 0x0b, /* read memory at higher speed               */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 3U, .opi_dmc = 7U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SQI_OPI_READ_HS,   .opi_cmd = 0x0b, /* read memory at higher speed               */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 3U, .opi_dmc = 3U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_SQOR6,     .opi_cmd = 0x6b, /* spi quad output read                      */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 3U, .opi_dmc = 1U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_SQIOR7,    .opi_cmd = 0xeb, /* spi quad io read                          */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 3U, .opi_dmc = 3U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_SDOR8,     .opi_cmd = 0x3b, /* spi dual output read                      */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 3U, .opi_dmc = 1U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_SDIOR9,    .opi_cmd = 0xbb, /* spi dual io read                          */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 3U, .opi_dmc = 1U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_SB,        .opi_cmd = 0xc0, /* set burst length                          */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_RBSQI,     .opi_cmd = 0x0c, /* sqi nb burst with wrap                    */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 3U, .opi_dmc = 3U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_RBSPI7,    .opi_cmd = 0xec, /* spi nb burst with wrap                    */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 3U, .opi_dmc = 3U, .opi_dtc = 0U, },  // NOLINT
        /**            IDENTIFICATION                */
        { .spi_opc = SPI_OPI_JEDEC_ID,  .opi_cmd = 0x9f, /* jedec-id read                             */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 3U, },  // NOLINT
        { .spi_opc = SPI_OPI_QUAD_J_ID, .opi_cmd = 0xaf, /* quad io j-id read                         */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 0U, .opi_dmc = 1U, .opi_dtc = 3U, },  // NOLINT
        { .spi_opc = SPI_OPI_SFDP,      .opi_cmd = 0x5a, /* serial flash discoverable parameters      */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 3U, .opi_dmc = 1U, .opi_dtc = 1U, },  // NOLINT
        /**            WRITE                        **/
        { .spi_opc = SPI_OPI_WREN,      .opi_cmd = 0x06, /* write enable                              */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_WRDI,      .opi_cmd = 0x04, /* write disable                             */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_SE10,      .opi_cmd = 0x20, /* erase 4 KBytes of memory array            */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 3U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_BE11,      .opi_cmd = 0xd8, /* erase 64,32 or 8 KBytes of memory array   */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 3U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_CE,        .opi_cmd = 0xc7, /* erase full array                          */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_PP,        .opi_cmd = 0x02, /* page program                              */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 3U, .opi_dmc = 0U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_QUAD_PP6,  .opi_cmd = 0x32, /* sqi quad page program                     */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 3U, .opi_dmc = 0U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_WRSU,      .opi_cmd = 0xb0, /* suspends program/erase                    */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_WRRE,      .opi_cmd = 0x30, /* resumes program/erase                     */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        /**            PROTECTION                   **/
        { .spi_opc = SPI_OPI_RBPR,      .opi_cmd = 0x72, /* read block protection register            */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 3U, },  // NOLINT
        { .spi_opc = SQI_OPI_RBPR,      .opi_cmd = 0x72, /* read block protection register            */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 0U, .opi_dmc = 1U, .opi_dtc = 3U, },  // NOLINT
        { .spi_opc = SPI_OPI_WBPR,      .opi_cmd = 0x42, /* write block protection register           */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_LBPR,      .opi_cmd = 0x8d, /* lock down block protection register       */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_NVWLDR,    .opi_cmd = 0xe8, /* non-volatile write lock-down register     */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_ULBPR,     .opi_cmd = 0x98, /* global block protection unlock            */ .opi_typ = SPI_OPI_TYP_SET,       .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_RSID,      .opi_cmd = 0x88, /* read security id                          */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 2U, .opi_dmc = 1U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_PSID,      .opi_cmd = 0xa5, /* program user security id area             */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 2U, .opi_dmc = 0U, .opi_dtc = 1U, },  // NOLINT
        { .spi_opc = SPI_OPI_LSID,      .opi_cmd = 0x85, /* lockout security id programming           */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        /**            POWER SAVING                 **/
        { .spi_opc = SPI_OPI_DPD,       .opi_cmd = 0xB9, /* deep power down mode                      */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 0U, .opi_dmc = 0U, .opi_dtc = 0U, },  // NOLINT
        { .spi_opc = SPI_OPI_RDPD,      .opi_cmd = 0xAB, /* release from deep power down and read id  */ .opi_typ = SPI_OPI_TYP_INVALID,   .opi_adc = 3U, .opi_dmc = 0U, .opi_dtc = 1U, },  // NOLINT
        /**            GIGADEVICE BELOW             **/
        { .spi_opc = SPI_OPI_G_REMS,    .opi_cmd = 0x90, /* manufacture/device id read alt RDPD       */ .opi_typ = SPI_OPI_TYP_RD,        .opi_adc = 3U, .opi_dmc = 0U, .opi_dtc = 2U, },  // NOLINT
    };
    // clang-format on

    SSM_OPI_INFO *p_opi_info = nullptr;
    for (uint32_t idx = 0; idx < SSM_ARRAY_SIZE(opi_info); idx++) {
        if (op_code == opi_info[idx].spi_opc) {
            p_opi_info = &opi_info[idx];
            break;
        }
    }

    assert(nullptr != p_opi_info);                       // illegal cmd requested
    assert(SPI_OPI_TYP_INVALID != p_opi_info->opi_typ);  // not tuned yet
    return p_opi_info;
}

inline uint32_t opc2cmd(uint32_t op_code) {  // op code to instruction cmd
    SSM_OPI_INFO *p_opi = opi_cmd_info_get(op_code);
    assert(nullptr != p_opi);           // sanity check
    assert(op_code == p_opi->spi_opc);  // sanity check

    return p_opi->opi_cmd;
}

inline uint32_t opc2dmc(uint32_t op_code) {  // op code to dummy cycle
    SSM_OPI_INFO *p_opi = opi_cmd_info_get(op_code);
    assert(nullptr != p_opi);           // sanity check
    assert(op_code == p_opi->spi_opc);  // sanity check

    return p_opi->opi_dmc;
}

const uint8_t RDSR_MSK_BUSY_M = (uint8_t)(1U << 0 | 1U << 7);
const uint8_t RDSR_MSK_BUSY_G = (uint8_t)(1U << 0);
const uint8_t RDSR_MSK_WEL    = (uint8_t)(1U << 1);
const uint8_t RDSR_MSK_WSE    = (uint8_t)(1U << 2);
const uint8_t RDSR_MSK_WSP    = (uint8_t)(1U << 3);
const uint8_t RDSR_MSK_WPLD   = (uint8_t)(1U << 4);
const uint8_t RDSR_MSK_SEC1   = (uint8_t)(1U << 5);
const uint8_t RDSR_MSK_RES    = (uint8_t)(1U << 6);

}  // namespace MICROCHIP_SQI_F_SST26WF
}  // namespace spi
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_SPI_NS_HPP_
