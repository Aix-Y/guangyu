/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_RPFEI_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_RPFEI_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace rpfei {

enum kSsmRpfei {
    kSsmRpfeiInvalid = 0,
    kRpfei_Pheriph_0,
    kRpfei_Pheriph_1,
    kRpfei_Pheriph_2,
    kRpfei_Pheriph_3,
    kRpfei_Pheriph_4,
    kRpfei_Pheriph_5,
    kRpfei_Pheriph_6,
    kRpfei_Pheriph_7,
    kRpfei_Pheriph_8,
    kRpfei_Pheriph_9,
    kRpfei_Pheriph_10,
    kRpfei_Pheriph_11,
    kRpfei_Pheriph_12,
    kRpfei_Pheriph_13,
    kRpfei_Pheriph_14,
    kRpfei_Pheriph_15,
    kRpfei_Pheriph_16,
    kRpfei_Pheriph_17,
    kRpfei_Pheriph_18,
    kRpfei_Pheriph_19,
    kRpfei_Pheriph_20,
    kRpfei_Pheriph_21,
    kRpfei_Pheriph_22,
    kRpfei_Pheriph_23,
    kRpfei_Pheriph_24,
    kRpfei_InterModule_0,
    kRpfei_InterModule_1,
    kRpfei_InterModule_2,
    kRpfei_InterModule_3,
    kRpfei_InterModule_4,
    kRpfei_InterModule_5,
    kRpfei_InterModule_6,
    kRpfei_InterModule_7,
    kRpfei_InterModule_8,
    kRpfei_InterModule_9,
    kRpfei_InterModule_10,
    kRpfei_FeedtGp_0,
    kRpfei_FeedtGpInt_0_0,
    kRpfei_FeedtGpInt_0_1,
    kRpfei_FeedtGpInt_0_2,
    kRpfei_FeedtGpInt_0_3,
    kRpfei_FeedtGpInt_0_4,
    kRpfei_FeedtGpInt_0_5,
    kRpfei_FeedtGpInt_0_6,
    kRpfei_FeedtGp_1,
    kRpfei_FeedtGpInt_1_0,
    kRpfei_FeedtGpInt_1_1,
    kRpfei_FeedtGpInt_1_2,
    kRpfei_FeedtGpInt_1_3,
    kRpfei_FeedtGpInt_1_4,
    kRpfei_FeedtGpInt_1_5,
    kRpfei_FeedtGpInt_1_6,
    kRpfei_FeedtGpInt_1_7,
    kRpfei_FeedtGpInt_1_8,
    kRpfei_FeedtGpInt_1_9,
    kRpfei_FeedtGpInt_1_10,
    kRpfei_FeedtGpInt_1_11,
    kRpfei_FeedtGpInt_1_12,
    kRpfei_FeedtGpInt_1_13,
    kRpfei_FeedtGpInt_1_14,
    kRpfei_FeedtGp_2,
    kRpfei_FeedtGpInt_2_0,
    kRpfei_FeedtGpInt_2_1,
    kRpfei_FeedtGpInt_2_2,
    kRpfei_FeedtGpInt_2_3,
    kRpfei_Thm_0,
    kRpfei_Thm_1,
    kRpfei_Thm_2,
    kRpfei_Thm_3,
    kRpfei_Thm_4,
    kRpfei_Thm_5,
    kRpfei_Thm_6,
    kRpfei_Pwr_0,
    kRpfei_Pwr_1,
    kRpfei_Pwr_2,
    kRpfei_Pwr_3,
    kRpfei_SemLow,
    kRpfei_SemHigh,
    kRpfei_SemOvfl,
    kRpfei_Gpio,
    kRpfei_Gp_0,
    kRpfei_Gp_1,
    kRpfei_Gp_2,
    kRpfei_Gp_3,
    kRpfei_AaspLinkDown,
    kRpfei_EslErr,
    kRpfei_ExfErr,
    kRpfei_Sicio,
    kRpfei_BoostPipe,
    kRpfei_RasCovflMerr,
    kRpfei_Parity,
    kRpfei_MdmaErr,
    kRpfei_MdmaFuc,
    kRpfei_HwCtf,
    kRpfei_HwCtfExt,
    kRpfei_HwCtfInt,
    kRpfei_Cattrip_0,
    kRpfei_Cattrip_1,
    kRpfei_Cattrip_2,
    kRpfei_Cattrip_3,
    kRpfei_Timer_0,
    kRpfei_Timer_1,
    kRpfei_Timer_2,
    kRpfei_Timer_3,
    kRpfei_Timer_4,
    kRpfei_Timer_5,
    kRpfei_Timer_6,
    kRpfei_Timer_7,
    kRpfei_Uart_0,
    kRpfei_Uart_1,
    kRpfei_Ssi_Txe,
    kRpfei_Ssi_Rxf,
    kRpfei_Ssi_Mst,
    kRpfei_Avs,
    kRpfei_I2c_0,
    kRpfei_I2c_1,
    kRpfei_I2c_2,
    kRpfei_I2c_3,
    kRpfei_I2c_4,
    kRpfei_Sm4XtsErr,
    kRpfei_I2cAlert_0,
    kRpfei_I2cAlert_1,
    kRpfei_I2cAlert_2,
    kRpfei_VrHot,
    kRpfei_ThmProt,
    kRpfei_ThmOmc,
    kRpfei_ThmOmcSampleDone,
    kRpfei_ThmOmcHiTrig,
    kRpfei_Edcc,
    kRpfei_VddcDtuLeft,
    kRpfei_VddcDtuRight,
    kRpfei_VddcSoc,
    kRpfei_SecEngine,
    kRpfei_OsrPke,
    kRpfei_OsrSke,
    kRpfei_OsrHash,
    kRpfei_OsrTrng,
    kRpfei_OsrSeipMbox,
    kRpfei_OsrSeipSensor,
    kRpfei_MihRingNotEmpty,
    kRpfei_MihRingWaterMark,
    kRpfei_MihSramErr,
    kRpfei_MihWRTMismatch,
    kRpfei_MihLLQFull,
    kRpfei_PcieRefclkLost,
    kRpfei_PcieHostTimeout,
    kRpfei_PcieHotRst,
    kRpfei_Rsa,
    kRpfei_Sha,
    kRpfei_Ram_Otp,
    kRpfei_Ram_Bank_0,
    kRpfei_Ram_Bank_1,
    kRpfei_Ram_Bank_2,
    kRpfei_Ram_Bank_3,
    kRpfei_Ram_Bank_4,
    kRpfei_Ram_Bank_5,
    kRpfei_Ram_Hash,
    kRpfei_Ram_Pke_0,
    kRpfei_Ram_Pke_1,
    kRpfei_McuSys_B,
    kRpfei_McuSys_R,
    kRpfei_McuMem_B,
    kRpfei_McuMem_R,
    kRpfei_MdmaWp_B,
    kRpfei_MdmaWp_R,
    kRpfei_MdmaNp_B,
    kRpfei_MdmaNp_R,
    kRpfei_Msg_B,
    kRpfei_Msg_R,
    kRpfei_Ske_B,
    kRpfei_Ske_R,
    kRpfei_Hash_B,
    kRpfei_Hash_R,
    kRpfei_Ih_B,
    kRpfei_McuFp_B,
    kRpfei_McuFp_R,
    kRpfei_Reg_B,
    kRpfei_Reg_R,
    kRpfei_Seip_B,
    kRpfei_Seip_R,
    kRpfei_Fatal,
    kRpfei_Fatal_Wdog,
    kSsmRpfeiMax,
};

inline bool rpfei_type_is_pheriph(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_Pheriph_0  : return true;
        case kRpfei_Pheriph_1  : return true;
        case kRpfei_Pheriph_2  : return true;
        case kRpfei_Pheriph_3  : return true;
        case kRpfei_Pheriph_4  : return true;
        case kRpfei_Pheriph_5  : return true;
        case kRpfei_Pheriph_6  : return true;
        case kRpfei_Pheriph_7  : return true;
        case kRpfei_Pheriph_8  : return true;
        case kRpfei_Pheriph_9  : return true;
        case kRpfei_Pheriph_10 : return true;
        case kRpfei_Pheriph_11 : return true;
        case kRpfei_Pheriph_12 : return true;
        case kRpfei_Pheriph_13 : return true;
        case kRpfei_Pheriph_14 : return true;
        case kRpfei_Pheriph_15 : return true;
        case kRpfei_Pheriph_16 : return true;
        case kRpfei_Pheriph_17 : return true;
        case kRpfei_Pheriph_18 : return true;
        case kRpfei_Pheriph_19 : return true;
        case kRpfei_Pheriph_20 : return true;
        case kRpfei_Pheriph_21 : return true;
        case kRpfei_Pheriph_22 : return true;
        case kRpfei_Pheriph_23 : return true;
        case kRpfei_Pheriph_24 : return true;
        default: break;
    }
    // clang-format on
    return false;
}

inline bool rpfei_type_is_inter_m(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_InterModule_0 : return true;
        case kRpfei_InterModule_1 : return true;
        case kRpfei_InterModule_2 : return true;
        case kRpfei_InterModule_3 : return true;
        case kRpfei_InterModule_4 : return true;
        case kRpfei_InterModule_5 : return true;
        case kRpfei_InterModule_6 : return true;
        case kRpfei_InterModule_7 : return true;
        case kRpfei_InterModule_8 : return true;
        case kRpfei_InterModule_9 : return true;
        case kRpfei_InterModule_10: return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_feed_t(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_FeedtGp_0       : return true;
        case kRpfei_FeedtGpInt_0_0  : return true;
        case kRpfei_FeedtGpInt_0_1  : return true;
        case kRpfei_FeedtGpInt_0_2  : return true;
        case kRpfei_FeedtGpInt_0_3  : return true;
        case kRpfei_FeedtGpInt_0_4  : return true;
        case kRpfei_FeedtGpInt_0_5  : return true;
        case kRpfei_FeedtGpInt_0_6  : return true;
        case kRpfei_FeedtGp_1       : return true;
        case kRpfei_FeedtGpInt_1_0  : return true;
        case kRpfei_FeedtGpInt_1_1  : return true;
        case kRpfei_FeedtGpInt_1_2  : return true;
        case kRpfei_FeedtGpInt_1_3  : return true;
        case kRpfei_FeedtGpInt_1_4  : return true;
        case kRpfei_FeedtGpInt_1_5  : return true;
        case kRpfei_FeedtGpInt_1_6  : return true;
        case kRpfei_FeedtGpInt_1_7  : return true;
        case kRpfei_FeedtGpInt_1_8  : return true;
        case kRpfei_FeedtGpInt_1_9  : return true;
        case kRpfei_FeedtGpInt_1_10 : return true;
        case kRpfei_FeedtGpInt_1_11 : return true;
        case kRpfei_FeedtGpInt_1_12 : return true;
        case kRpfei_FeedtGpInt_1_13 : return true;
        case kRpfei_FeedtGpInt_1_14 : return true;
        case kRpfei_FeedtGp_2       : return true;
        case kRpfei_FeedtGpInt_2_0  : return true;
        case kRpfei_FeedtGpInt_2_1  : return true;
        case kRpfei_FeedtGpInt_2_2  : return true;
        case kRpfei_FeedtGpInt_2_3  : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_thm(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_Thm_0 : return true;
        case kRpfei_Thm_1 : return true;
        case kRpfei_Thm_2 : return true;
        case kRpfei_Thm_3 : return true;
        case kRpfei_Thm_4 : return true;
        case kRpfei_Thm_5 : return true;
        case kRpfei_Thm_6 : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_pwr(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_Pwr_0 : return true;
        case kRpfei_Pwr_1 : return true;
        case kRpfei_Pwr_2 : return true;
        case kRpfei_Pwr_3 : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_semap(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_SemLow  : return true;
        case kRpfei_SemHigh : return true;
        case kRpfei_SemOvfl : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_gpio(const uint32_t &rpfei_t) {
    return (kRpfei_Gpio == rpfei_t);
}

inline bool rpfei_type_is_gp(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_Gp_0 : return true;
        case kRpfei_Gp_1 : return true;
        case kRpfei_Gp_2 : return true;
        case kRpfei_Gp_3 : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_timer(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_Timer_0 : return true;
        case kRpfei_Timer_1 : return true;
        case kRpfei_Timer_2 : return true;
        case kRpfei_Timer_3 : return true;
        case kRpfei_Timer_4 : return true;
        case kRpfei_Timer_5 : return true;
        case kRpfei_Timer_6 : return true;
        case kRpfei_Timer_7 : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_uart(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_Uart_0 : return true;
        case kRpfei_Uart_1 : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_ssi(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_Ssi_Txe : return true;
        case kRpfei_Ssi_Rxf : return true;
        case kRpfei_Ssi_Mst : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_avs(const uint32_t &rpfei_t) {
    return (kRpfei_Avs == rpfei_t);
}

inline bool rpfei_type_is_i2c(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_I2c_0 : return true;
        case kRpfei_I2c_1 : return true;
        case kRpfei_I2c_2 : return true;
        case kRpfei_I2c_3 : return true;
        case kRpfei_I2c_4 : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_i2c_alert(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_I2cAlert_0 : return true;
        case kRpfei_I2cAlert_1 : return true;
        case kRpfei_I2cAlert_2 : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_sec(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_SecEngine     : return true;
        case kRpfei_OsrPke        : return true;
        case kRpfei_OsrSke        : return true;
        case kRpfei_OsrHash       : return true;
        case kRpfei_OsrTrng       : return true;
        case kRpfei_OsrSeipMbox   : return true;
        case kRpfei_OsrSeipSensor : return true;
        case kRpfei_Rsa           : return true;
        case kRpfei_Sha           : return true;
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_ram(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_Ram_Otp    : return true;  // NOLINT scorpio.gp0_int0 = otp_ram_par_int
        case kRpfei_Ram_Bank_0 : return true;  // NOLINT scorpio.gp0_int1 = o_bank0_ram_par_int
        case kRpfei_Ram_Bank_1 : return true;  // NOLINT scorpio.gp0_int2 = o_bank1_ram_par_int
        case kRpfei_Ram_Bank_2 : return true;  // NOLINT scorpio.gp0_int3 = o_bank2_ram_par_int
        case kRpfei_Ram_Bank_3 : return true;  // NOLINT scorpio.gp0_int3 = o_bank3_ram_par_int
        case kRpfei_Ram_Bank_4 : return true;  // NOLINT scorpio.gp0_int3 = o_bank4_ram_par_int
        case kRpfei_Ram_Bank_5 : return true;  // NOLINT scorpio.gp0_int3 = o_bank5_ram_par_int
        case kRpfei_Ram_Hash   : return true;  // NOLINT scorpio.gp0_int4 = o_hash_ram_par_int
        case kRpfei_Ram_Pke_0  : return true;  // NOLINT scorpio.gp0_int5 = o_pke_ram0_par_int
        case kRpfei_Ram_Pke_1  : return true;  // NOLINT scorpio.gp0_int6 = o_pke_ram1_par_int
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_bch(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_McuSys_B : return true;  // NOLINT scorpio.gp1_int0  = ssm_m_mcu_sys_B_ras_int
        case kRpfei_McuMem_B : return true;  // NOLINT scorpio.gp1_int2  = ssm_m_mcu_mem_B_ras_int
        case kRpfei_MdmaWp_B : return true;  // NOLINT scorpio.gp1_int4  = ssm_m_mdma_wp_B_ras_int
        case kRpfei_MdmaNp_B : return true;  // NOLINT scorpio.gp1_int6  = ssm_m_mdma_np_B_ras_int
        case kRpfei_Msg_B    : return true;  // NOLINT scorpio.gp1_int8  = ssm_m_msg_B_ras_int
        case kRpfei_Ske_B    : return true;  // NOLINT scorpio.gp1_int10 = ssm_m_ske_B_ras_int
        case kRpfei_Hash_B   : return true;  // NOLINT scorpio.gp1_int12 = ssm_m_hash_B_ras_int
        case kRpfei_Ih_B     : return true;  // NOLINT scorpio.gp1_int14 = ssm_m_ih_B_ras_int
        case kRpfei_McuFp_B  : return true;  // NOLINT scorpio.gp2_int0  = ssm_s_mcu_fp_B_ras_int
        case kRpfei_Reg_B    : return true;  // NOLINT scorpio.gp2_int2  = ssm_s_reg_B_ras_int
        case kRpfei_Seip_B   : return true;  // NOLINT scorpio.gp2_int2  = ssm_s_reg_B_ras_int
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_rch(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_McuSys_R : return true;  // NOLINT scorpio.gp1_int1  = ssm_m_mcu_sys_R_ras_int
        case kRpfei_McuMem_R : return true;  // NOLINT scorpio.gp1_int3  = ssm_m_mcu_mem_R_ras_int
        case kRpfei_MdmaWp_R : return true;  // NOLINT scorpio.gp1_int5  = ssm_m_mdma_wp_R_ras_int
        case kRpfei_MdmaNp_R : return true;  // NOLINT scorpio.gp1_int7  = ssm_m_mdma_np_R_ras_int
        case kRpfei_Msg_R    : return true;  // NOLINT scorpio.gp1_int9  = ssm_m_msg_R_ras_int
        case kRpfei_Ske_R    : return true;  // NOLINT scorpio.gp1_int11 = ssm_m_ske_R_ras_int
        case kRpfei_Hash_R   : return true;  // NOLINT scorpio.gp1_int13 = ssm_m_hash_R_ras_int
        case kRpfei_McuFp_R  : return true;  // NOLINT scorpio.gp2_int1  = ssm_s_mcu_fp_R_ras_int
        case kRpfei_Reg_R    : return true;  // NOLINT scorpio.gp2_int3  = ssm_s_reg_R_ras_int
        case kRpfei_Seip_R   : return true;  // NOLINT scorpio.gp2_int3  = ssm_s_reg_R_ras_int
        default: break;
    }
    // clang-format on

    return false;
}

inline bool rpfei_type_is_fatal(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_Fatal      : return true;  // NOLINT
        case kRpfei_Fatal_Wdog : return true;  // NOLINT
        default: break;
    }
    // clang-format on
}

inline std::string rpfei_type_ram2str(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_Ram_Otp    : return "kRpfei_Ram_Otp";
        case kRpfei_Ram_Bank_0 : return "kRpfei_Ram_Bank_0";
        case kRpfei_Ram_Bank_1 : return "kRpfei_Ram_Bank_1";
        case kRpfei_Ram_Bank_2 : return "kRpfei_Ram_Bank_2";
        case kRpfei_Ram_Bank_3 : return "kRpfei_Ram_Bank_3";
        case kRpfei_Ram_Bank_4 : return "kRpfei_Ram_Bank_4";
        case kRpfei_Ram_Bank_5 : return "kRpfei_Ram_Bank_5";
        case kRpfei_Ram_Hash   : return "kRpfei_Ram_Hash";
        case kRpfei_Ram_Pke_0  : return "kRpfei_Ram_Pke_0";
        case kRpfei_Ram_Pke_1  : return "kRpfei_Ram_Pke_1";
    }
    // clang-format on

    return "RPFEI_RAM_UDEF";
}

inline std::string rpfei_type_rch2str(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_McuSys_R : return "kRpfei_McuSys_R";
        case kRpfei_McuMem_R : return "kRpfei_McuMem_R";
        case kRpfei_MdmaWp_R : return "kRpfei_MdmaWp_R";
        case kRpfei_MdmaNp_R : return "kRpfei_MdmaNp_R";
        case kRpfei_Msg_R    : return "kRpfei_Msg_R";
        case kRpfei_Ske_R    : return "kRpfei_Ske_R";
        case kRpfei_Hash_R   : return "kRpfei_Hash_R";
        case kRpfei_McuFp_R  : return "kRpfei_McuFp_R";
        case kRpfei_Reg_R    : return "kRpfei_Reg_R";
        case kRpfei_Seip_R   : return "kRpfei_Seip_R";
        default: break;
    }
    // clang-format on

    return "RPFEI_RCH_UDEF";
}

inline std::string rpfei_type_bch2str(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_McuSys_B : return "kRpfei_McuSys_B";
        case kRpfei_McuMem_B : return "kRpfei_McuMem_B";
        case kRpfei_MdmaWp_B : return "kRpfei_MdmaWp_B";
        case kRpfei_MdmaNp_B : return "kRpfei_MdmaNp_B";
        case kRpfei_Msg_B    : return "kRpfei_Msg_B";
        case kRpfei_Ske_B    : return "kRpfei_Ske_B";
        case kRpfei_Hash_B   : return "kRpfei_Hash_B";
        case kRpfei_Ih_B     : return "kRpfei_Ih_B";
        case kRpfei_McuFp_B  : return "kRpfei_McuFp_B";
        case kRpfei_Reg_B    : return "kRpfei_Reg_B";
        case kRpfei_Seip_B   : return "kRpfei_Seip_B";
        default: break;
    }
    // clang-format on

    return "RPFEI_BCH_UDEF";
}

inline std::string rpfei_type_feedt2str(const uint32_t &rpfei_t) {
    // clang-format off
    switch (rpfei_t) {
        case kRpfei_FeedtGp_0       : return "kRpfei_FeedtGpt_0";
        case kRpfei_FeedtGpInt_0_0  : return "kRpfei_FeedtGpInt_0_0";
        case kRpfei_FeedtGpInt_0_1  : return "kRpfei_FeedtGpInt_0_1";
        case kRpfei_FeedtGpInt_0_2  : return "kRpfei_FeedtGpInt_0_2";
        case kRpfei_FeedtGpInt_0_3  : return "kRpfei_FeedtGpInt_0_3";
        case kRpfei_FeedtGpInt_0_4  : return "kRpfei_FeedtGpInt_0_4";
        case kRpfei_FeedtGpInt_0_5  : return "kRpfei_FeedtGpInt_0_5";
        case kRpfei_FeedtGpInt_0_6  : return "kRpfei_FeedtGpInt_0_6";
        case kRpfei_FeedtGp_1       : return "kRpfei_FeedtGp_1";
        case kRpfei_FeedtGpInt_1_0  : return "kRpfei_FeedtGpInt_1_0";
        case kRpfei_FeedtGpInt_1_1  : return "kRpfei_FeedtGpInt_1_1";
        case kRpfei_FeedtGpInt_1_2  : return "kRpfei_FeedtGpInt_1_2";
        case kRpfei_FeedtGpInt_1_3  : return "kRpfei_FeedtGpInt_1_3";
        case kRpfei_FeedtGpInt_1_4  : return "kRpfei_FeedtGpInt_1_4";
        case kRpfei_FeedtGpInt_1_5  : return "kRpfei_FeedtGpInt_1_5";
        case kRpfei_FeedtGpInt_1_6  : return "kRpfei_FeedtGpInt_1_6";
        case kRpfei_FeedtGpInt_1_7  : return "kRpfei_FeedtGpInt_1_7";
        case kRpfei_FeedtGpInt_1_8  : return "kRpfei_FeedtGpInt_1_8";
        case kRpfei_FeedtGpInt_1_9  : return "kRpfei_FeedtGpInt_1_9";
        case kRpfei_FeedtGpInt_1_10 : return "kRpfei_FeedtGpInt_1_10";
        case kRpfei_FeedtGpInt_1_11 : return "kRpfei_FeedtGpInt_1_11";
        case kRpfei_FeedtGpInt_1_12 : return "kRpfei_FeedtGpInt_1_12";
        case kRpfei_FeedtGpInt_1_13 : return "kRpfei_FeedtGpInt_1_13";
        case kRpfei_FeedtGpInt_1_14 : return "kRpfei_FeedtGpInt_1_14";
        case kRpfei_FeedtGp_2       : return "kRpfei_FeedtGp_2";
        case kRpfei_FeedtGpInt_2_0  : return "kRpfei_FeedtGpInt_2_0";
        case kRpfei_FeedtGpInt_2_1  : return "kRpfei_FeedtGpInt_2_1";
        case kRpfei_FeedtGpInt_2_2  : return "kRpfei_FeedtGpInt_2_2";
        case kRpfei_FeedtGpInt_2_3  : return "kRpfei_FeedtGpInt_2_3";
    }
    // clang-format on

    return "RPFEI_FEEDT_UDEF";
}

typedef struct _ssm_rpfei_set {
    _ssm_rpfei_set(
        const std::string &_item_x, const uint32_t &_para_0, const uint32_t &_para_1) {
        i_item_x = _item_x;
        i_para_0 = _para_0;
        i_para_1 = _para_1;
    }
    std::string i_item_x;
    uint32_t    i_para_0;
    uint32_t    i_para_1;
} ssm_rpfei_set_t;

}  // namespace rpfei
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_RPFEI_NS_HPP_
