/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_TIMER_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_TIMER_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace timer {

const uint32_t SSM_GEN_TMR_NUM_3D0 = 8;
const uint32_t SSM_GEN_TMR_NUM_4D0 = 8;

enum kSsmTmrType {
    kTmrTypeInvalid = 0,
    kTmrTypeGlb,  // timer global
    kTmrTypeGen,  // timer generic
    kTmrTypeMax,
};

enum kSsmTmrId {
    kTmrIdInvalid = 0,
    kTmrId_Gen_0,
    kTmrId_Gen_1,
    kTmrId_Gen_2,
    kTmrId_Gen_3,
    kTmrId_Gen_4,
    kTmrId_Gen_5,
    kTmrId_Gen_6,
    kTmrId_Gen_7,
    kTmrId_Glb_0,
    kTmrIdMax,
};

enum kSsmTmrMode {
    kTmrModeInvalid = 0,
    kTmrModeChronograph,
    kTmrModeSlice,
    kTmrModePulseCount,
    kTmrModePwm,
    kTmrModeMax,
};

typedef struct {
    std::string name;
    uint32_t    addr_ctrl;
    uint32_t    addr_comp0;
    uint32_t    addr_comp1;
    uint32_t    addr_value;
} ssm_timer_info_t;

typedef struct {
    kSsmTmrType timer_type;
    kSsmTmrMode timer_mode;
    kSsmTmrId   timer_id;
    uint64_t    timer_freq;
    uint64_t    timer_delay_ms;
    uint64_t    timer_delay_us;
    uint64_t    timer_expect_ts;
    uint64_t    timer_expect_ts_per_us;
    uint64_t    timer_expect_ts_per_ms;
    double      timer_tolerance_freq;
    uint64_t    measured_us;
    uint64_t    measured_ts;
    double      measured_freq;
    uint64_t    measured_ts_min;
    uint64_t    measured_ts_max;
    uint32_t    tick_addr_hi;
    uint32_t    tick_addr_lo;
} ssm_timer_meas_t;

const uint32_t TMR_SETS = 3U;

typedef struct {
    uint32_t ctrl_0;
    uint32_t resv[TMR_SETS - 1];
} TMR_GLBA_t;

typedef struct {
    uint32_t ctrl_0;
    uint32_t comp_0;
    uint32_t comp_1;
} TMR_GENA_t;

typedef union {
    uint32_t   v[TMR_SETS];
    TMR_GLBA_t glb_a;
    TMR_GENA_t gen_a;
} ssm_timer_sets_u;

}  // namespace timer
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_TIMER_NS_HPP_
