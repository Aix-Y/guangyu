/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_UTW_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_UTW_NS_HPP_

#include <memory>
#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace utw {

enum class kSsmDefOp {
    kSsmDefOpEq = 0x0,
    kSsmDefOpGe,  // greater or equal
    kSsmDefOpGt,  // greater than
    kSsmDefOpLe,  // less    or equal
    kSsmDefOpLt,  // less    than
    kSsmDefOpNe,  // not        equal
    kSsmDefOpMax,
};

typedef struct _ssm_fload {
    uint32_t                   size;  // sz byte
    uint32_t                   ofst;  // on offset
    bool                       bin;   // binary or hex
    uint32_t                   fmt;   // hex format
    std::string                file;  // ld file
    std::unique_ptr<uint8_t[]> buf;   // to buf
} ssm_fload_t;

inline std::string def_op_2str(kSsmDefOp op) {
    switch (op) {
        case kSsmDefOp::kSsmDefOpEq:
            return "OP_EQ";
        case kSsmDefOp::kSsmDefOpGe:
            return "OP_GE";
        case kSsmDefOp::kSsmDefOpGt:
            return "OP_GT";
        case kSsmDefOp::kSsmDefOpLe:
            return "OP_LE";
        case kSsmDefOp::kSsmDefOpLt:
            return "OP_LT";
        case kSsmDefOp::kSsmDefOpNe:
            return "OP_NE";
        case kSsmDefOp::kSsmDefOpMax:
            return "OP_MAX";
        default:
            break;
    }
    return "kSsmDefOpXxx";
}

inline static uint64_t u64_bits_val(const uint64_t &v, std::size_t s, std::size_t e) {
    if (s >= 64U)
        return v;
    if (e >= 64U)
        return v;

    std::bitset<64> bits_i(v);
    std::bitset<64> bits_o(0);
    for (std::size_t bit = 0; bit < bits_i.size(); bit++) {
        if ((bit < s) || (bit > e))
            continue;
        bits_o[bit - s] = bits_i[bit];
    }
    return bits_o.to_ullong();
}

inline static uint64_t u64_bits_msk(std::size_t s, std::size_t e) {
    std::bitset<64> bits_m(0);
    bits_m.set();  // all bits true
    if (s >= 64U)
        return bits_m.to_ullong();
    if (e >= 64U)
        return bits_m.to_ullong();

    for (std::size_t bit = 0; bit < bits_m.size(); bit++) {
        if (bit < s)
            bits_m.set(bit, false);
        if (bit > e)
            bits_m.set(bit, false);
    }
    return bits_m.to_ullong();
}

inline static uint64_t u64_bits_set(const uint64_t &v, const uint64_t &u, const uint64_t &m) {
    std::bitset<64> bits_f(v);  // value original     [v v v V v v v]
    std::bitset<64> bits_u(u);  // value updated      [v v v U v v v]
    std::bitset<64> bits_m(m);  // value updated mask [v v v M v v v]

    bits_f &= (~bits_m);
    bits_f |= bits_u;
    return bits_f.to_ullong();
}

inline static uint32_t u32_bits_val(const uint32_t &v, std::size_t s, std::size_t e) {
    uint64_t u64_i = v;
    uint64_t u64_o = u64_bits_val(u64_i, s, e);
    return (uint32_t)(u64_o);
}

inline static uint32_t u32_bits_msk(std::size_t s, std::size_t e) {
    uint64_t u64_o = u64_bits_msk(s, e);
    return (uint32_t)(u64_o);
}

inline static uint32_t u32_bits_set(const uint32_t &v, const uint32_t &u, const uint32_t &m) {
    uint64_t u64_o = u64_bits_set(v, u, m);
    return (uint32_t)(u64_o);
}

inline static uint64_t b2g_u64(uint64_t b_i) {
    return (b_i ^ (b_i >> 1));  // RB|RBC: REFLECTED BINARY CODE
}

inline static uint64_t g2b_u64(uint64_t g_i) {
    std::bitset<64> b_i(g_i);
    std::bitset<64> b_o(g_i);
    for (std::size_t b = b_i.size() - 2; b >= 0; b--) {
        b_o[b] = b_i[b] ^ b_o[b + 1];
        if (!b) {
            break;
        }
    }
    return b_o.to_ullong();  // RB|RBC: REFLECTED BINARY CODE
}

}  // namespace utw
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_UTW_NS_HPP_
