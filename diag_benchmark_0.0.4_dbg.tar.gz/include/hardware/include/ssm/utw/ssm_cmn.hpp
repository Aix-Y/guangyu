/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_CMN_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_CMN_HPP_

#include "hardware/include/ssm/utw/ssm_def.hxx"

#include "hardware/include/ssm/utw/ssm_clk_ns.hpp"
#include "hardware/include/ssm/utw/ssm_cmd_ns.hpp"
#include "hardware/include/ssm/utw/ssm_cpmu_ns.hpp"
#include "hardware/include/ssm/utw/ssm_dma_ns.hpp"
#include "hardware/include/ssm/utw/ssm_dmi_ns.hpp"
#include "hardware/include/ssm/utw/ssm_fiw_ns.hpp"
#include "hardware/include/ssm/utw/ssm_gpio_ns.hpp"
#include "hardware/include/ssm/utw/ssm_i2c_ns.hpp"
#include "hardware/include/ssm/utw/ssm_intf_ns.hpp"
#include "hardware/include/ssm/utw/ssm_ivm_ns.hpp"
#include "hardware/include/ssm/utw/ssm_mcu_ns.hpp"
#include "hardware/include/ssm/utw/ssm_mem_ns.hpp"
#include "hardware/include/ssm/utw/ssm_misc_ns.hpp"
#include "hardware/include/ssm/utw/ssm_otp_ns.hpp"
#include "hardware/include/ssm/utw/ssm_pins_ns.hpp"
#include "hardware/include/ssm/utw/ssm_plv_ns.hpp"
#include "hardware/include/ssm/utw/ssm_pmon_ns.hpp"
#include "hardware/include/ssm/utw/ssm_ras_ns.hpp"
#include "hardware/include/ssm/utw/ssm_reset_ns.hpp"
#include "hardware/include/ssm/utw/ssm_rpfei_ns.hpp"
#include "hardware/include/ssm/utw/ssm_sdw_ns.hpp"
#include "hardware/include/ssm/utw/ssm_secure_ns.hpp"
#include "hardware/include/ssm/utw/ssm_sem_ns.hpp"
#include "hardware/include/ssm/utw/ssm_sih_ns.hpp"
#include "hardware/include/ssm/utw/ssm_spi_ns.hpp"
#include "hardware/include/ssm/utw/ssm_timer_ns.hpp"
#include "hardware/include/ssm/utw/ssm_uart_ns.hpp"
#include "hardware/include/ssm/utw/ssm_utw_ns.hpp"
#include "hardware/include/ssm/utw/ssm_vr_ns.hpp"

namespace efvf {
namespace hardware {
namespace ssm {

typedef struct _SSM_U16_2B {
#if BYTE_ORDER == LITTLE_ENDIAN
    uint16_t b0 : 8;
    uint16_t b1 : 8;
#elif BYTE_ORDER == BIG_ENDIAN
    uint16_t b1 : 8;
    uint16_t b0 : 8;
#endif
} SSM_U16_2B_t;

typedef struct _SSM_U32_2W {
#if BYTE_ORDER == LITTLE_ENDIAN
    uint32_t w0 : 16;
    uint32_t w1 : 16;
#elif BYTE_ORDER == BIG_ENDIAN
    uint32_t w1 : 16;
    uint32_t w0 : 16;
#endif
} SSM_U32_2W_t;

typedef struct _SSM_U32_4B {
#if BYTE_ORDER == LITTLE_ENDIAN
    uint32_t b0 : 8;
    uint32_t b1 : 8;
    uint32_t b2 : 8;
    uint32_t b3 : 8;
#elif BYTE_ORDER == BIG_ENDIAN
    uint32_t b3 : 8;
    uint32_t b2 : 8;
    uint32_t b1 : 8;
    uint32_t b0 : 8;
#endif
} SSM_U32_4B_t;

typedef struct _SSM_U64_2DW {
#if BYTE_ORDER == LITTLE_ENDIAN
    uint64_t dw0 : 32;
    uint64_t dw1 : 32;
#elif BYTE_ORDER == BIG_ENDIAN
    uint64_t dw1 : 32;
    uint64_t dw0 : 32;
#endif
} SSM_U64_2DW_t;

typedef union {
    uint16_t     val : 16;
    SSM_U16_2B_t b;
} SSM_U16_u;

typedef union {
    uint32_t     val : 32;
    SSM_U32_2W_t w;
    SSM_U32_4B_t b;
} SSM_U32_u;

typedef union {
    uint64_t      val : 64;
    SSM_U64_2DW_t dw;
} SSM_U64_u;

typedef struct _SSM_U32_VLD {
    _SSM_U32_VLD() : vld(false), val(~0U) {}
    void set(uint32_t v) {
        vld = true;
        val = v;
    }
    void inv(void) {
        vld = false;
        val = ~0U;
    }
    bool     vld;
    uint32_t val;
} SSM_U32_VLD_t;

}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_CMN_HPP_
