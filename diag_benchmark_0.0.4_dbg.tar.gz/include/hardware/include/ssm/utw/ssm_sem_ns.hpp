/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_SEM_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_SEM_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace sem {

typedef struct {
    uint32_t sem_id;
    uint32_t addr_rlslock;
    uint32_t addr_getlock;
    uint32_t addr_cfg;
    uint32_t addr_cfg_int;
    uint32_t addr_credit;
    uint32_t addr_credit_lo;
    uint32_t addr_credit_hi;
    uint32_t addr_credit_lo_int;
    uint32_t addr_credit_hi_int;
    uint32_t addr_credit_lo_int_clr;
    uint32_t addr_credit_hi_int_clr;
    uint32_t addr_credit_ov_int;     // add since 2d1 for 2d0 ovf detection
    uint32_t addr_credit_ov_int_en;  // add since 2d1 for 2d0 ovf detection
} SSM_SEM_INFO_3D0;

typedef struct _ssm_sem_set {
    _ssm_sem_set(const std::string &_x, const uint32_t &_p0, const uint32_t &_p1,
        const uint32_t &_p2, const uint32_t &_p3, const uint32_t &_p4) {
        i_item_x = _x;
        i_para_0 = _p0;
        i_para_1 = _p1;
        i_para_2 = _p2;
        i_para_3 = _p3;
        i_para_4 = _p4;
    }
    std::string i_item_x;
    uint32_t    i_para_0;
    uint32_t    i_para_1;
    uint32_t    i_para_2;
    uint32_t    i_para_3;
    uint32_t    i_para_4;
} ssm_sem_set_t;

const uint32_t SSM_SEM_NUM_3D0 = 32U;
const uint32_t SSM_SEM_NUM_4D0 = 32U;

}  // namespace sem
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_SEM_NS_HPP_
