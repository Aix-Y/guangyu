/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_GPIO_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_GPIO_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace gpio {

typedef struct {
    bool        check;
    uint32_t    gpio;
    uint32_t    value;
    std::string slv;
    std::string mst;
    std::string d2d;
    std::string pad;
    std::string name;
} SSM_GPIO_INFO;

typedef enum {
    kGpioDirInvalid,
    kGpioDirIput,
    kGpioDirOput,
    kGpioDirMax,
} kGpioDir;

inline std::string gpio_dir_2str(uint32_t io_dir) {
    // clang-format off
    switch (io_dir) {
        case kGpioDirIput:      return "IPUT";
        case kGpioDirOput:      return "OPUT";
        default: break;
    }
    // clang-format on

    return "GPIO_DIR_UDEF";
}

}  // namespace gpio
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_GPIO_NS_HPP_
