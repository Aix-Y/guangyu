/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_DEF_HXX_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_DEF_HXX_

// clang-format off
#define SSM_MAGIC     (0xDE5AA5BF)
#define SSM_U16FF     (0x0000FFFF)
#define SSM_U32FF     (0xFFFFFFFF)
#define SSM_U64FF     (0xFFFFFFFFFFFFFFFF)
#define SSM_MS_PER_S  (1000L)
#define SSM_US_PER_MS (1000L)
#define SSM_NS_PER_US (1000L)
#define SSM_NS_PER_MS (1000000L)
#define SSM_US_PER_S  (1000000L)
#define SSM_NS_PER_S  (1000000000L)

#define SSM_S2MS(_s)  ((_s) * SSM_MS_PER_S)
#define SSM_MS2S(_m)  ((_m) / SSM_MS_PER_S)
#define SSM_S2US(_s)  ((_s) * SSM_US_PER_S)
#define SSM_S2NS(_s)  ((_s) * SSM_NS_PER_S)
#define SSM_MS2US(_m) ((_m) * SSM_US_PER_MS)
#define SSM_US2MS(_u) ((_u) / SSM_US_PER_MS)
#define SSM_US2NS(_u) ((_u) * SSM_NS_PER_US)
#define SSM_MS2NS(_m) ((_m) * SSM_NS_PER_MS)
#define SSM_NS2MS(_n) ((_n) / SSM_NS_PER_MS)

#define SSM_CYCLES_PER_MS(_HZ) ((_HZ) / (SSM_S2MS(1)))
#define SSM_CYCLES_PER_US(_HZ) ((_HZ) / (SSM_S2US(1)))
#define SSM_CYCLES_PER_NS(_HZ) ((_HZ) / (SSM_S2NS(1)))
#define SSM_PERIOD_IN_NS(_HZ)  (SSM_S2NS(1) / (_HZ))
#define SSM_PERIOD_IN_US(_HZ)  (SSM_S2US(1) / (_HZ))
#define SSM_PERIOD_IN_MS(_HZ)  (SSM_S2MS(1) / (_HZ))

#define SSM_DELTA(_v_a, _v_b) \
    ((_v_a) > (_v_b) ? ((_v_a) - (_v_b)) : ((_v_b) - (_v_a)))
#define SSM_MAX(_v_a, _v_b) \
    ((_v_a) > (_v_b) ? (_v_a) : (_v_b))
#define SSM_MIN(_v_a, _v_b) \
    ((_v_a) > (_v_b) ? (_v_b) : (_v_a))
#define SSM_IN_RANGE(_v, _r_a, _r_b) \
    (((_v) >= SSM_MIN(_r_a, _r_b)) && ((_v) <= SSM_MAX(_r_a, _r_b)))
#define SSM_VIN_RANGE(_v_c, _v_t, _v_d) \
    (((_v_c) >= ((_v_t) - (_v_d))) && ((_v_c) <= ((_v_t) + (_v_d))))

#define SSM_TP_CONST_A (10000)
#define SSM_TP_A(_a) (SSM_TP_CONST_A + (_a) * 1000)
#define SSM_TP_AB(_a, _b) (SSM_TP_A(_a) + (_b))

#define SSM_ARRAY_SIZE(_arr) (sizeof(_arr) / sizeof(_arr[0]))
/**
 * Fix for GCC9 [-Werror=ignored-qualifiers]
 * #define SSM_ALIGN_MASK(_po2) ((typeof(_po2))((_po2) - 1))
 */
#define SSM_ALIGN_MASK(_po2)                                              \
({                                                                        \
    typedef typeof(_po2) _po2_type;                                       \
    _po2_type _po2_mask = (_po2) - 1;                                     \
    (_po2_mask);                                                          \
})
#define SSM_IS_ALIGNED(_v, _po2) (0 == ((_v) & SSM_ALIGN_MASK(_po2)))
#define SSM_IS_NOT_ALIGNED(_v, _po2) (!SSM_IS_ALIGNED((_v), (_po2)))
#define SSM_ALIGN_DOWN(_v, _po2) ((_v) & (~SSM_ALIGN_MASK(_po2)))
#define SSM_ALIGN_UP(_v, _po2) (SSM_ALIGN_DOWN(((_v) + SSM_ALIGN_MASK((_po2))), (_po2)))

#define SSM_BITS_VAL(value, start_bit, end_bit) \
    (efvf::hardware::ssm::utw::u32_bits_val(value, start_bit, end_bit))
#define SSM_BITS_MSK(start_bit, end_bit)        \
    (efvf::hardware::ssm::utw::u32_bits_msk(start_bit, end_bit))
#define SSM_BITS_SET(data, up_data, up_mask)    \
    (efvf::hardware::ssm::utw::u32_bits_set(data, up_data, up_mask))
#define SSM_BITS_UP(data, bit_st, bit_ed, bits_v) \
({                                                \
    uint32_t b_st = SSM_MIN(bit_st, bit_ed);      \
    uint32_t b_ed = SSM_MAX(bit_st, bit_ed);      \
    uint32_t v_up = (bits_v << b_st);             \
    uint32_t b_mm = SSM_BITS_MSK(b_st, b_ed);     \
    (SSM_BITS_SET(data, v_up, b_mm));             \
})

#define SSM_BIT_VAL(value, bit) \
    SSM_BITS_VAL(value, bit, bit)
#define SSM_BIT_MSK(bit)        \
    SSM_BITS_MSK((bit), (bit))
#define SSM_BIT_SET(v, b, bv)   \
    SSM_BITS_SET(v, (uint32_t(bv) << uint32_t(b)), SSM_BIT_MSK(b))

#define SSM_DELAY_MS(delay_ms)                                             \
do {                                                                       \
    uint32_t _d_ms = get_param_u32("ssm_delay_ms", delay_ms);              \
    m_hpd->SleepMs(_d_ms);                                                 \
} while (0)                                                                \

#define SSM_KB(s)               ((s) * 1024ULL)
#define SSM_MB(s)               ((s) * SSM_KB(1024))
#define SSM_GB(s)               ((s) * SSM_MB(1024))
#define SSM_TB(s)               ((s) * SSM_GB(1024))
#define SSM_BITS2B(s)           ((s) / 8U)
#define SSM_KBITS(s)            ((s) * 1024)
#define SSM_MBITS(s)            ((s) * SSM_KBITS(1024))
#define SSM_KBITS2B(s)          (SSM_BITS2B(SSM_KBITS(s)))
#define SSM_MBITS2B(s)          (SSM_BITS2B(SSM_MBITS(s)))
#define SSM_B2BITS(s)           ((s) * 8U)
#define SSM_B2KB(s)             ((s) / SSM_KB(1))
#define SSM_B2MB(s)             ((s) / SSM_MB(1))
#define SSM_B2DW(s)             ((s) / 4U)
#define SSM_DW2B(s)             ((s) * 4U)
#define SSM_DW2BITS(s)          (SSM_B2BITS(SSM_DW2B(s)))
#define SSM_KB2DW(s)            (SSM_B2DW(SSM_KB(s)))
#define SSM_CLK_FREQ_KHZ(k)     ((k) * 1000)
#define SSM_CLK_FREQ_MHZ(m)     (SSM_CLK_FREQ_KHZ((m) * 1000))
#define SSM_REFCLK_FREQ_25M_HZ  (SSM_CLK_FREQ_MHZ(25))
#define SSM_REFCLK_FREQ_100M_HZ (SSM_CLK_FREQ_MHZ(100))
#define SSM_H2MHZ(h)            ((h) / 1000 / 1000)

#define ssm_lib                  \
({                               \
    IP_ASSERT(nullptr != m_ssm); \
    (m_ssm);                     \
})
#define ssm_lib_reg             (ssm_lib->GetReg())
#define ssm_lib_mem             (ssm_lib->GetMem())
#define ssm_lib_cmd             (ssm_lib->GetCmd())
#define ssm_lib_mcu             (ssm_lib->GetMcu())
#define ssm_lib_misc            (ssm_lib->GetMisc())
#define ssm_lib_dma             (ssm_lib->GetDma())
#define ssm_lib_dmi             (ssm_lib->GetDmi())
#define ssm_lib_mdma            (ssm_lib->GetMdma())
#define ssm_lib_uart            (ssm_lib->GetUart())
#define ssm_lib_fuse            (ssm_lib->GetFuse())
#define ssm_lib_timer           (ssm_lib->GetTimer())
#define ssm_lib_sih             (ssm_lib->GetSih())
#define ssm_lib_mih             (ssm_lib->GetMih())
#define ssm_lib_spi             (ssm_lib->GetSpi())
#define ssm_lib_fiw             (ssm_lib->GetFiw())
#define ssm_lib_gpio            (ssm_lib->GetGpio())
#define ssm_lib_i2c             (ssm_lib->GetI2c())
#define ssm_lib_hbm             (ssm_lib->GetHbm())
#define ssm_lib_vr              (ssm_lib->GetVr())
#define ssm_lib_clk             (ssm_lib->GetClk())
#define ssm_lib_otp             (ssm_lib->GetOtp())
#define ssm_lib_ivm             (ssm_lib->GetIvm())
#define ssm_lib_rst             (ssm_lib->GetReset())
#define ssm_lib_rpfei           (ssm_lib->GetRpfei())
#define ssm_lib_secure          (ssm_lib->GetSecure())
#define ssm_lib_sem             (ssm_lib->GetSem())
#define ssm_lib_plv             (ssm_lib->GetPlv())
#define ssm_lib_cpmu            (ssm_lib->GetCpmu())
#define ssm_lib_pmon            (ssm_lib->GetPmon())
#define ssm_lib_pwins           (ssm_lib->GetPwins())
#define ssm_lib_intf            (ssm_lib->GetIntf())
#define ssm_lib_sa              (ssm_lib->GetSa())

#define SSM_RES_PTR_TARGET      ((Target*)&(GetTarget()))
#define SSM_RES_PTR_PARAMS      ((ParameterList*)&(GetParamList()))
// clang-format on

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_DEF_HXX_
