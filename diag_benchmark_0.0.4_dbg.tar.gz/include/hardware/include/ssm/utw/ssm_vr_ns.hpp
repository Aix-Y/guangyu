/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_VR_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_VR_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace vr {

// clang-format off
enum kSsmVr {
    kSsmVr_Dtu           =  0,
    kSsmVr_Soc           =  1,
    kSsmVr_1v8           =  2,
    kSsmVr_1v8_bsoc      =  3,
    kSsmVr_Vddp          =  4,
    kSsmVr_Rsvd_5        =  5,
    kSsmVr_Rsvd_6        =  6,
    kSsmVr_Rsvd_7        =  7,
    kSsmVr_G6phy         =  8,
    kSsmVr_G6phy_vdda    =  9,
    kSsmVr_G6phy_vddc    = 10,
    kSsmVr_G6vpp         = 11,
    kSsmVr_G6qc          = 12,
    kSsmVr_Rsvd_13       = 13,
    kSsmVr_Rsvd_14       = 14,
    kSsmVr_Rsvd_15       = 15,
    kSsmVr_Rsvd_16       = 16,
    kSsmVr_Aasp          = 17,
    kSsmVr_Rsvd_18       = 18,
    kSsmVr_Rsvd_19       = 19,
    kSsmVr_Rsvd_20       = 20,
    kSsmVr_Rsvd_21       = 21,
    kSsmVr_Esl           = 22,
    kSsmVr_Esl_L         = 23,
    kSsmVr_Esl_R         = 24,
    kSsmVr_Rsvd_25       = 25,
    kSsmVr_Rsvd_26       = 26,
    kSsmVr_Rsvd_27       = 27,
    kSsmVr_Rsvd_28       = 28,
    kSsmVr_Mc            = 29,
    kSsmVr_Mc_vdda       = 30,
    kSsmVr_Mc_vddc       = 31,
    kSsmVr_Mc_vddio      = 32,
    kSsmVr_Rsvd_33       = 33,
    kSsmVr_Rsvd_34       = 34,
    kSsmVr_Rsvd_35       = 35,
    kSsmVr_Rsvd_36       = 36,
    kSsmVr_Mcphy         = 37,
    kSsmVr_Mcphy_pll     = 38,
    kSsmVr_Rsvd_39       = 39,
    kSsmVr_Hbmiol_T      = 40,
    kSsmVr_Hbmiol_B      = 41,
    kSsmVr_Rsvd_42       = 42,
    kSsmVr_Rsvd_43       = 43,
    kSsmVr_Hbmqc         = 44,
    kSsmVr_Hbmqc_T       = 45,
    kSsmVr_Hbmqc_B       = 46,
    kSsmVr_Hbm           = 47,
    kSsmVr_Hbmvpp        = 48,
    kSsmVr_Rsvd_49       = 49,
    kSsmVr_Dac_I2c0      = 50,
    kSsmVr_Dac_I2c1      = 51,
    kSsmVr_Dac_I2c2      = 52,
    kSsmVr_Dac_I2c3      = 53,
    kSsmVr_Dac_I2c4_Rsvd = 54,
    kSsmVr_Dac_I2c5_Rsvd = 55,
    kSsmVr_Dac_I2c6_Rsvd = 56,
    kSsmVr_Dac_I2c7_Rsvd = 57,
    kSsmVr_Dac_Spi0      = 58,
    kSsmVr_Dac_Spi1      = 59,
    kSsmVr_Dac_Spi2      = 60,
    kSsmVr_Dac_Spi3      = 61,
    kSsmVr_Dac_Spi4_Rsvd = 62,
    kSsmVr_Dac_Spi5_Rsvd = 63,
    kSsmVr_Dac_Spi6_Rsvd = 64,
    kSsmVr_Dac_Spi7_Rsvd = 65,
    kSsmVr_Dac_Mcphyref  = 66,
    kSsmVr_Dac_Rsvd_67   = 67,
    kSsmVr_Dac_Rsvd_68   = 68,
    kSsmVr_Tdc_12vbus    = 69,
    kSsmVr_Tdc_12vext    = 70,
    kSsmVr_Tdc_3v3bus    = 71,
    kSsmVr_Tdc_12vext_a  = 72,
    kSsmVr_Tdc_12vext_b  = 73,
    kSsmVr_Tdc_Rsvd_74   = 74,
    kSsmVr_Tdc_Rsvd_75   = 75,
    kSsmVr_Max,
    kSsmVr_All,  // partial cmd support
};

inline bool is_vr_dtu(const uint32_t& vr_id) {
    return (kSsmVr_Dtu == vr_id);
}

inline bool is_vr_soc(const uint32_t& vr_id) {
    return (kSsmVr_Soc == vr_id);
}

inline bool is_vr_i2c_dac(const uint32_t& vr_id) {
    bool is_dac = false;
    switch (vr_id) {
        case kSsmVr_Dac_I2c0:       is_dac = true; break;
        case kSsmVr_Dac_I2c1:       is_dac = true; break;
        case kSsmVr_Dac_I2c2:       is_dac = true; break;
        case kSsmVr_Dac_I2c3:       is_dac = true; break;
        default: break;
    }
    return is_dac;
}

inline bool is_vr_spi_dac(const uint32_t& vr_id) {
    bool is_dac = false;
    switch (vr_id) {
        case kSsmVr_Dac_Spi0:       is_dac = true; break;
        case kSsmVr_Dac_Spi1:       is_dac = true; break;
        case kSsmVr_Dac_Spi2:       is_dac = true; break;
        case kSsmVr_Dac_Spi3:       is_dac = true; break;
        default: break;
    }
    return is_dac;
}

inline bool is_vr_dac(const uint32_t& vr_id) {
    bool is_dac = false;

    if (is_vr_i2c_dac(vr_id)) {
        is_dac = true;
    }

    if (is_vr_spi_dac(vr_id)) {
        is_dac = true;
    }

    if (kSsmVr_Dac_Mcphyref == vr_id) {
        is_dac = true;
    }

    return is_dac;
}

inline bool is_vr_tdc(const uint32_t& vr_id) {
    bool is_epm = false;
    switch (vr_id) {  // external power monitor
        case kSsmVr_Tdc_12vbus:     is_epm = true; break;
        case kSsmVr_Tdc_12vext:     is_epm = true; break;
        case kSsmVr_Tdc_3v3bus:     is_epm = true; break;
        case kSsmVr_Tdc_12vext_a:   is_epm = true; break;
        case kSsmVr_Tdc_12vext_b:   is_epm = true; break;
        default: break;
    }
    return is_epm;
}

typedef struct {
    std::string nm;
    std::string loc;
    uint32_t    icdid;
    uint32_t    fwidx;
    double      v_min;
    double      v_max;
} ssm_vr_3d0_t;

typedef struct {
    bool        reg_vlid;
    uint32_t    reg_page;
    uint32_t    reg_addr;
    uint32_t    reg_byte;
    uint32_t    reg_mask;
    uint32_t    reg_gval;
    std::string reg_name;
} ssm_vr_reg_t;

typedef struct {
    std::string  vr_name;
    std::string  vr_host;
    uint32_t     vr_addr;
    uint32_t     vr_regs_num;
    ssm_vr_reg_t vr_regs[0xFF];
} ssm_vr_desc_t;

typedef struct {
    uint32_t       vr_db_sz;
    ssm_vr_desc_t* vr_db_dt;
} ssm_vr_db_t;

typedef enum {
    SSM_VR_GB_INVALID = 0,
    SSM_VR_GB_OP_ON,   // gb on
    SSM_VR_GB_OP_OFF,  // gb off
    SSM_VR_GB_OP_STT,  // gb status
    SSM_VR_GB_TP_AGE,  // gb aging offset
    SSM_VR_GB_TP_APP,  // gb application offset
} SSM_VR_GB;

const uint32_t IR35215_IC_DID(0x5D);
const uint32_t IR35217_IC_DID(0x5F);
const uint32_t IR38060_IC_DID(0x30);
const uint32_t IR38062_IC_DID(0x32);
const uint32_t IR38063_IC_DID(0x33);
const uint32_t IR38064_IC_DID(0x34);
const uint32_t XDPE132G5D_DID(0x7C);
const uint32_t TI_INA226_MFID(0x5446);
const uint32_t XXXXXXX_IC_DID(~0U);

// clang-format on

}  // namespace vr
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_VR_NS_HPP_
