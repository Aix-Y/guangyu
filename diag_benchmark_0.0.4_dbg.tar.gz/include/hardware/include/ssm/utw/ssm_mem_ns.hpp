/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_MEM_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_MEM_NS_HPP_

#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace mem {

typedef struct {
    uint32_t rw_type;  // iput kSsmMem
    uint32_t rw_size;  // iput byte
    void *   rw_pbuf;  // iput buff
    uint32_t rw_ofst;  // iput offset byte
    uint32_t rw_base;  // iput base addr byte
} SSM_MEM_RW;

enum kSsmMem {
    kSsmMemInvalid = 0,
    kSsmMemIram,
    kSsmMemDram,
    kSsmMemSmem,
    kSsmMemSmem0,
    kSsmMemSmem1,
    kSsmMemSmem2,
    kSsmMemSmem3,  // SINCE 4D0
    kSsmMemSmem4,  // SINCE 4D0
    kSsmMemSmem5,  // SINCE 4D0
    kSsmMemBoot,   // SINCE 3D0
    kSsmMemDls,    // SINCE 3D0
    kSsmMemFuse,
    kSsmMemOtp,
    kSsmMemOtp0,     // SINCE 4D0
    kSsmMemOtp1,     // SINCE 4D0
    kSsmMemDmem,     // HBM
    kSsmMemSysm,     // SYS
    kSsmMemBcbf,     // SINCE 3D0 DBG CMD BUF
    kSsmMemRcbf,     // SINCE 3D0 DRV CMD BUF
    kSsmMemScratch,  // SELF DEBUG USED
    kSsmMemBlank,    // SELF DEBUG USED
    kSsmMemMax,
};

inline std::string get_mem_type_2str(uint32_t mem_type) {
    // clang-format off
    switch (mem_type) {
        case kSsmMemIram:      return "iram";
        case kSsmMemDram:      return "dram";
        case kSsmMemSmem:      return "smem";
        case kSsmMemSmem0:     return "smem0";
        case kSsmMemSmem1:     return "smem1";
        case kSsmMemSmem2:     return "smem2";
        case kSsmMemSmem3:     return "smem3";
        case kSsmMemSmem4:     return "smem4";
        case kSsmMemSmem5:     return "smem5";
        case kSsmMemBoot:      return "boot";
        case kSsmMemDls:       return "dls";
        case kSsmMemFuse:      return "fram";
        case kSsmMemOtp:       return "otpm";
        case kSsmMemOtp0:      return "otpm0";
        case kSsmMemOtp1:      return "otpm1";
        case kSsmMemDmem:      return "dmem";
        case kSsmMemSysm:      return "sysm";
        case kSsmMemBcbf:      return "bcbf";
        case kSsmMemRcbf:      return "rcbf";
        case kSsmMemScratch:   return "scratch";
        case kSsmMemBlank:     return "blank";
        default: break;
    }
    // clang-format on

    return "SSM_MEM_UDEF";
}

inline uint32_t get_mem_type_per_str(const std::string &mem_type) {
    // clang-format off
    if ("iram"      == mem_type) return kSsmMemIram;
    if ("dram"      == mem_type) return kSsmMemDram;
    if ("smem"      == mem_type) return kSsmMemSmem;
    if ("smem0"     == mem_type) return kSsmMemSmem0;
    if ("smem1"     == mem_type) return kSsmMemSmem1;
    if ("smem2"     == mem_type) return kSsmMemSmem2;
    if ("smem3"     == mem_type) return kSsmMemSmem3;
    if ("smem4"     == mem_type) return kSsmMemSmem4;
    if ("smem5"     == mem_type) return kSsmMemSmem5;
    if ("boot"      == mem_type) return kSsmMemBoot;
    if ("dls"       == mem_type) return kSsmMemDls;
    if ("fram"      == mem_type) return kSsmMemFuse;
    if ("otpm"      == mem_type) return kSsmMemOtp;
    if ("otpm0"     == mem_type) return kSsmMemOtp0;
    if ("otpm1"     == mem_type) return kSsmMemOtp1;
    if ("dmem"      == mem_type) return kSsmMemDmem;
    if ("sysm"      == mem_type) return kSsmMemSysm;
    if ("bcbf"      == mem_type) return kSsmMemBcbf;
    if ("rcbf"      == mem_type) return kSsmMemRcbf;
    if ("scratch"   == mem_type) return kSsmMemScratch;
    if ("blank"     == mem_type) return kSsmMemBlank;
    // clang-format on

    return kSsmMemInvalid;
}

// clang-format off
const uint32_t SSM_LEO_BYTE_SZ_IRAM   = SSM_KB(32);
const uint32_t SSM_LEO_BYTE_SZ_DRAM   = SSM_KB(4);
const uint32_t SSM_LEO_BYTE_SZ_DCACHE = SSM_KB(1);
const uint32_t SSM_LEO_FUSE_DW_ROWS   = (192);

const uint32_t SSM_PAVO_ADDR_ST_IRAM  = 0x00000U;
const uint32_t SSM_PAVO_ADDR_ED_IRAM  = 0x1FFFFU;
const uint32_t SSM_PAVO_BYTE_SZ_IRAM  = SSM_KB(128);

const uint32_t SSM_PAVO_ADDR_ST_DRAM  = 0x20000U;
const uint32_t SSM_PAVO_ADDR_ED_DRAM  = 0x27FFFU;
const uint32_t SSM_PAVO_BYTE_SZ_DRAM  = SSM_KB(32);

const uint32_t SSM_PAVO_ADDR_ST_SMEM0 = 0x28000;
const uint32_t SSM_PAVO_ADDR_ED_SMEM0 = 0x28FFF;
const uint32_t SSM_PAVO_BYTE_SZ_SMEM0 = SSM_KB(4);

const uint32_t SSM_PAVO_ADDR_ST_SMEM1 = 0x29000;
const uint32_t SSM_PAVO_ADDR_ED_SMEM1 = 0x29FFF;
const uint32_t SSM_PAVO_BYTE_SZ_SMEM1 = SSM_KB(4);

const uint32_t SSM_PAVO_ADDR_ST_SMEM  = SSM_PAVO_ADDR_ST_SMEM0;
const uint32_t SSM_PAVO_ADDR_ED_SMEM  = SSM_PAVO_ADDR_ED_SMEM1;
const uint32_t SSM_PAVO_BYTE_SZ_SMEM  = SSM_PAVO_BYTE_SZ_SMEM0 + SSM_PAVO_BYTE_SZ_SMEM1;

/**
 * PAVO FRAM is 4KB Actually from 148_3000 ~ 148_3FFF
 * according to design only 6Kbits(768B aka 192DW) are expected to be used
 * during rw testing on whole 4K zone found that, whole 4K is seperated into 4x1K zone
 * write to each zone address offset, data will be reflected to other zones
 * additionally last 256B are not writable in each zone refer PAVOPSE-280
 */
const uint32_t SSM_PAVO_BYTE_SZ_FRAM  = SSM_KBITS2B(6);  // 6Kbits == 768B == 192DW
const uint32_t SSM_PAVO_FUSE_DW_ROWS  = SSM_B2DW(SSM_PAVO_BYTE_SZ_FRAM);
const uint32_t SSM_PAVO_BYTE_SZ_OTPM  = SSM_KB(8);  // 14A8000 ~ 14A82000
const uint32_t SSM_PAVO_OTPM_DW_ROWS  = SSM_B2DW(SSM_PAVO_BYTE_SZ_OTPM);

const uint32_t SSM_PAVO_HEX_UCODE_FMT = 64U;  // 64Bytes
const uint32_t SSM_PAVO_BIN_UCODE_OFF = 24U;  // 24Bytes

const uint32_t SSM_DORADO_ADDR_ST_IRAM  = 0x00000U;
const uint32_t SSM_DORADO_ADDR_ED_IRAM  = 0x1FFFFU;
const uint32_t SSM_DORADO_BYTE_SZ_IRAM  = SSM_KB(128);

const uint32_t SSM_DORADO_ADDR_ST_DRAM  = 0x20000U;
const uint32_t SSM_DORADO_ADDR_ED_DRAM  = 0x27FFFU;
const uint32_t SSM_DORADO_BYTE_SZ_DRAM  = SSM_KB(32);

const uint32_t SSM_DORADO_ADDR_ST_SMEM0 = 0x28000;
const uint32_t SSM_DORADO_ADDR_ED_SMEM0 = 0x28FFF;
const uint32_t SSM_DORADO_BYTE_SZ_SMEM0 = SSM_KB(4);

const uint32_t SSM_DORADO_ADDR_ST_SMEM1 = 0x29000;
const uint32_t SSM_DORADO_ADDR_ED_SMEM1 = 0x29FFF;
const uint32_t SSM_DORADO_BYTE_SZ_SMEM1 = SSM_KB(4);

const uint32_t SSM_DORADO_ADDR_ST_SMEM  = SSM_DORADO_ADDR_ST_SMEM0;
const uint32_t SSM_DORADO_ADDR_ED_SMEM  = SSM_DORADO_ADDR_ED_SMEM1;
const uint32_t SSM_DORADO_BYTE_SZ_SMEM  = SSM_DORADO_BYTE_SZ_SMEM0 + SSM_DORADO_BYTE_SZ_SMEM1;

const uint32_t SSM_DORADO_BYTE_SZ_FRAM  = SSM_KBITS2B(6);  // 6Kbits == 768B == 192DW
const uint32_t SSM_DORADO_FUSE_DW_ROWS  = SSM_B2DW(SSM_DORADO_BYTE_SZ_FRAM);
const uint32_t SSM_DORADO_BYTE_SZ_OTPM  = SSM_KB(8);  // B98000 ~ B9A000
const uint32_t SSM_DORADO_OTPM_DW_ROWS  = SSM_B2DW(SSM_DORADO_BYTE_SZ_OTPM);
// clang-format on

}  // namespace mem
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_MEM_NS_HPP_
