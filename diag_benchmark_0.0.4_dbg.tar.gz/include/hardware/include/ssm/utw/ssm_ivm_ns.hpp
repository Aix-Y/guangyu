/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_IVM_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_IVM_NS_HPP_

#include <memory>
#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace ivm {

// clang-format off

enum {
    IMG_LAYOUT_TBL_IVM = 0,
    IMG_LAYOUT_TBL_SPI = 1,
    IMG_LAYOUT_TBL_MAX,
};

inline const char* ivm_tbl_2str(uint32_t tbl_t) {
    switch (tbl_t) {
        case IMG_LAYOUT_TBL_IVM: return "IMG_LAYOUT_TBL_IVM";
        case IMG_LAYOUT_TBL_SPI: return "IMG_LAYOUT_TBL_SPI";
        case IMG_LAYOUT_TBL_MAX: return "IMG_LAYOUT_TBL_MAX";
        default: break;
    }

    return "IMG_LAYOUT_TBL_NA";
}

inline bool is_layout_tbl_valid(uint32_t tbl_t) {
    bool t_valid = false;
    switch (tbl_t) {
        case IMG_LAYOUT_TBL_IVM: t_valid = true;  break;
        case IMG_LAYOUT_TBL_SPI: t_valid = true;  break;
        default: break;
    }
    return t_valid;
}

inline bool is_ivm_layout_tbl(uint32_t tbl_t) {
    return (IMG_LAYOUT_TBL_IVM == tbl_t);
}

inline bool is_spi_layout_tbl(uint32_t tbl_t) {
    return (IMG_LAYOUT_TBL_SPI == tbl_t);
}

enum {
    IVM_ENT_OP_NOP = 0,  // no operation
    IVM_ENT_OP_XEX,      // erase only
    IVM_ENT_OP_XXP,      // program only
    IVM_ENT_OP_XEP,      // erase-program
    IVM_ENT_OP_UEP,      // erase-program if different
    IVM_ENT_OP_XXX,      // op type illegal
};

inline const char* ivm_ent_op_2str(uint32_t e_op_t) {
    switch (e_op_t) {
        case IVM_ENT_OP_NOP:    return "---";
        case IVM_ENT_OP_XEX:    return "-E-";
        case IVM_ENT_OP_XXP:    return "--P";
        case IVM_ENT_OP_XEP:    return "-EP";
        case IVM_ENT_OP_UEP:    return "UEP";
        default: break;
    }
    return "XXX";
}

inline bool is_ent_op_valid(uint32_t e_op_t) {
    switch (e_op_t) {
        case IVM_ENT_OP_NOP:    return true;
        case IVM_ENT_OP_XEX:    return true;
        case IVM_ENT_OP_XXP:    return true;
        case IVM_ENT_OP_XEP:    return true;
        case IVM_ENT_OP_UEP:    return true;
        default: break;
    }
    return false;  // out of handle scope
}

inline bool is_ent_nop_type(uint32_t op_t) {
    return (IVM_ENT_OP_NOP == op_t);
}

inline bool is_ent_erase_only(uint32_t op_t) {
    return (IVM_ENT_OP_XEX == op_t);
}

inline bool is_ent_erase_type(uint32_t op_t) {
    bool e_t = ((IVM_ENT_OP_XEX == op_t) ||
                (IVM_ENT_OP_XEP == op_t) ||
                (IVM_ENT_OP_UEP == op_t) ||
                (false));
    return e_t;
}

inline bool is_ent_prog_type(uint32_t op_t) {
    bool p_t = ((IVM_ENT_OP_XXP == op_t) ||
                (IVM_ENT_OP_XEP == op_t) ||
                (IVM_ENT_OP_UEP == op_t) ||
                (false));
    return p_t;
}

typedef struct _ivm_desc {
    uint32_t                   ivm_tbl_type;  // NOLINT code   in : ivm table data location
    uint32_t                   ivm_tbl_base;  // NOLINT fw define : base addr offset of table
    uint32_t                   ivm_tbl_size;  // NOLINT code   in : ivm table size
    uint32_t                   ivm_ent_numx;  // NOLINT fw define : maximum entry items
    uint32_t                   ivm_ent_size;  // NOLINT fw define : per entry size in bytes
    uint32_t                   ivm_tbl_revx;  // NOLINT code  out : ivm table revision
    bool                       ivm_ssm_skip;  // NOLINT args   in : [0] ssm handshake [1] skip ssm talk
    bool                       ivm_des_init;  // NOLINT code  out : [1] init done [0] negative
    FILE*                      ivm_img_fhdl;  // NOLINT code  out : ivm image file handle
    std::string                ivm_img_file;  // NOLINT args   in : ivm image file
    std::unique_ptr<uint8_t[]> ivm_tbl_dptr;  // NOLINT code  out : ivm table data ptr
} ivm_desc_t;

typedef struct _ent_desc {
    uint32_t     ent_tb;
    uint32_t     ent_id;
    uint32_t     ent_st;
    uint32_t     ent_sz;
    uint32_t     ent_ed;
    uint32_t     ent_op;
    bool         ent_zo;
    FILE*        ent_fd;
    std::string  ent_nm;
    std::string  ent_ss;
} ent_desc_t;

typedef struct _ivm_descx {
    ivm_desc_t ivm_desc;
    ivm_desc_t spi_desc;
} ivm_ppe_desc_t;

typedef enum _ivm_entity_id {
    m_ivm_rsvd              = 0x00,
    m_primary               = 0x01,
    m_ivm_table_ping        = 0x02,
    m_ivm_table_pong        = 0x03,
    m_pre_grs_ping          = 0x04,
    m_pre_grs_pong          = 0x05,
    m_turbo_iram_ping       = 0x06,
    m_turbo_iram_pong       = 0x07,
    m_turbo_dram_ping       = 0x08,
    m_turbo_dram_pong       = 0x09,
    m_secondary_iram_ping   = 0x0A,
    m_secondary_iram_pong   = 0x0B,
    m_secondary_dram_ping   = 0x0C,
    m_secondary_dram_pong   = 0x0D,
    m_secondary_lib_ping    = 0x0E,
    m_secondary_lib_pong    = 0x0F,
    m_amc_ping              = 0x10,
    m_amc_pong              = 0x11,
    m_grs_ping              = 0x12,
    m_grs_pong              = 0x13,
    m_bom_cfg0_ping         = 0x14,
    m_bom_cfg0_pong         = 0x15,
    m_pcie_phy_ping         = 0x16,
    m_pcie_phy_pong         = 0x17,
    m_ccix_phy_ping         = 0x18,
    m_ccix_phy_pong         = 0x19,
    m_imu_ping              = 0x1a,
    m_imu_pong              = 0x1b,
    m_event_log             = 0x1c,
    m_error_log             = 0x1d,
    m_hbm_ecc_info_ping     = 0x1e,
    m_hbm_ecc_info_pong     = 0x1f,
    m_critical_info_ping    = 0x20,
    m_critical_info_pong    = 0x21,
    m_aasp_phy_iccm_ping    = 0x22,
    m_aasp_phy_iccm_pong    = 0x23,
    m_special_info_ping     = 0x24,
    m_special_info_pong     = 0x25,
    m_ssm_rt                = 0x26,
    m_aasp_phy_dccm_ping    = 0x27,
    m_aasp_phy_dccm_pong    = 0x28,
    m_ivm_table_ping_header = 0x29,
    m_ivm_table_pong_header = 0x2a,
    m_bom_cfg1_ping         = 0x2b,
    m_bom_cfg1_pong         = 0x2c,
    m_ivm_max
} ivm_entity_id;

typedef struct _ivm_info_t {  // 64 Byte
    uint32_t    m_version;
    char        m_compile_ip[16];
    char        m_compile_time[20];
    char        m_git_version[8];
    char        m_rsvd[15];
    uint8_t     m_checksum;
} ivm_info_t;

typedef struct _ivm_table_entry_t {
    uint32_t    m_flash_addr;
    uint32_t    m_size;
    uint32_t    m_loading_addr;
    uint32_t    m_exec_addr;
    uint8_t     m_content_id;
    uint8_t     m_op_type    : 4;  // NOLINT 0:nop 1:erase 2:prog 3:erase+prog 4:erase+program if differ
    uint8_t     m_board_type : 4;  // NOLINT 0:all type 1:prod 2:pam 3:oam 4:mxm
    char        m_name[13];
    uint8_t     m_checksum;
} ivm_table_entry_t;

typedef struct _rsa_para_t {  // 704 Byte
    uint8_t     m_hashing_value[128];
    uint32_t    m_e[32];
    uint32_t    m_n[32];
    uint32_t    m_r[32];
    uint32_t    m_u[32];
    uint32_t    m_n0[1];
    uint8_t     m_rsvd[59];
    uint8_t     m_checksum;
} rsa_para_t;

const uint32_t MAX_IVM_ENTRY_SUPPORT  = (128);
const uint32_t ACTUAL_IVM_ENTRY_COUNT = (126);

typedef struct _ivm_table_t {                             // 4096 Byte
    ivm_table_entry_t   m_entry[ACTUAL_IVM_ENTRY_COUNT];  // 3328 Byte
    // rsa_para_t       m_rsa;                            //  704 Byte
    ivm_info_t          m_info;                           //   64 Byte
} ivm_table_t;

/**
 * IVM IMAGE LAYOUT ON PAVO|DD-X
 *
 *  0x0000 +------------+
 *         | ....       |
 *  0x4000 +------------+ IVM_TABLE_T@IVM_LAYOUT_TBL_BASE
 *         | m_entry[0] |
 *  0x4020 | m_entry[1] |   +------------+
 *         | ....       |   |m_flash_addr|
 *  0x4fa0 | m_entry[x] |-->| ....       |
 *         |            |   |m_checksum  |
 *         |            |   +------------+
 *         |            |
 *  0x4fc0 +------------+   +------------+
 *         |            |   |m_version   |--> IVM_LAYOUT_REV_2D0
 *    0x40 | IVM_INFO_T |-->| ....       |    IVM_LAYOUT_REV_2D1
 *         |            |   |m_checksum  |
 *  0x5000 +------------+   +------------+
 *         | ....       |
 *         +------------+
 */
const uint32_t IVM_LAYOUT_TBL_BASE = SSM_KB(16);
const uint32_t IVM_LAYOUT_TBL_SIZE = SSM_KB(4);
const uint32_t IVM_LAYOUT_ENT_SIZE = sizeof(ivm_table_entry_t);
const uint32_t IVM_LAYOUT_ENT_NUMX = ACTUAL_IVM_ENTRY_COUNT;

const uint32_t IVM_LAYOUT_REV_2D0 = 2U;
const uint32_t IVM_LAYOUT_REV_2D1 = 2U;
const uint32_t IVM_LAYOUT_REV_3D0 = 3U;
const uint32_t IVM_LAYOUT_REV_4D0 = 3U;

// clang-format on

}  // namespace ivm
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_IVM_NS_HPP_
