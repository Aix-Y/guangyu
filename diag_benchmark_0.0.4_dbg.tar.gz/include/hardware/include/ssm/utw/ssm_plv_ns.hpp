/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_PLV_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_PLV_NS_HPP_

#include <memory>
#include <string>

namespace efvf {
namespace hardware {
namespace ssm {
namespace plv {

enum kSsmPlvTp {
    kPlvTpInvalid = 0,
    kPlvTpTest,
    kPlvTpDpm,
    kPlvTpPid,
    kPlvTpOtp,
    kPlvTpMax,
};

inline std::string plv_tp_2str(uint32_t plv_tp) {
    // clang-format off
    switch (plv_tp) {
        case kPlvTpTest: return "test";
        case kPlvTpDpm:  return "dpm";
        case kPlvTpPid:  return "pid";
        case kPlvTpOtp:  return "otp";
        default: break;
    }
    // clang-format on

    return "PLV_TP_UDEF";
}

inline uint32_t plv_tp_2enum(const std::string tp) {
    // clang-format off
    if (("test"    == tp) || ("TEST"    == tp)) return kPlvTpTest;
    if (("dpm"     == tp) || ("DPM"     == tp)) return kPlvTpDpm;
    if (("pid"     == tp) || ("PID"     == tp)) return kPlvTpPid;
    if (("otp"     == tp) || ("OTP"     == tp)) return kPlvTpOtp;
    // clang-format on

    return kPlvTpInvalid;
}

enum kSsmPlvOp {
    kPlvOpInvalid = 0,
    kPlvOpSeq,
    kPlvOpRand,
    kPlvOpMax,
};

inline std::string plv_op_2str(uint32_t plv_op) {
    // clang-format off
    switch (plv_op) {
        case kPlvOpSeq:     return "seq";
        case kPlvOpRand:    return "rand";
        default: break;
    }
    // clang-format on

    return "PLV_OP_UDEF";
}

inline uint32_t plv_op_2enum(const std::string op) {
    // clang-format off
    if (("seq"     == op) || ("SEQ"     == op)) return kPlvOpSeq;
    if (("rand"    == op) || ("RAND"    == op)) return kPlvOpRand;
    // clang-format on

    return kPlvOpInvalid;
}

const uint32_t PLV_MAX = 255;

typedef struct _plv_desc {
    uint32_t plv;
    uint32_t rlv;
    bool     vld;
} plv_desc_t;

typedef struct _plv_map {
    plv_desc_t desc[PLV_MAX];
    uint32_t   pmin;
    uint32_t   pmax;
    bool       init;
} plv_map_t;

}  // namespace plv
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_PLV_NS_HPP_
