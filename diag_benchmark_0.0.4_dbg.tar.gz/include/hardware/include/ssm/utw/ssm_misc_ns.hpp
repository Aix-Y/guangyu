/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_UTW_SSM_MISC_NS_HPP_
#define HARDWARE_INCLUDE_SSM_UTW_SSM_MISC_NS_HPP_

namespace efvf {
namespace hardware {
namespace ssm {
namespace misc {

// clang-format off

// => refer 2d0 qsfpdd spec
const uint32_t LUXSHARE_EEPROM_BYTE_ST_PAGE_0      =   0;
const uint32_t LUXSHARE_EEPROM_BYTE_ED_PAGE_0      = 255;
const uint32_t LUXSHARE_EEPROM_BYTE_ST_VENDOR_NAME = 129;
const uint32_t LUXSHARE_EEPROM_BYTE_ED_VENDOR_NAME = 144;
const uint32_t LUXSHARE_EEPROM_BYTE_ST_VENDOR_PN   = 148;
const uint32_t LUXSHARE_EEPROM_BYTE_ED_VENDOR_PN   = 163;
const uint32_t LUXSHARE_EEPROM_BYTE_ST_VENDOR_SN   = 166;
const uint32_t LUXSHARE_EEPROM_BYTE_ED_VENDOR_SN   = 181;
// <= refer 2d0 qsfpdd spec

// clang-format on

}  // namespace misc
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SSM_UTW_SSM_MISC_NS_HPP_
