/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_FUSE_SSM_FUSE_H_
#define HARDWARE_INCLUDE_SSM_FUSE_SSM_FUSE_H_

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace fuse {

class SsmFuse : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmFuse(Ssm *ssm);
    virtual ~SsmFuse() {}

 public:
    virtual bool test_fuse_ram_pattern_wrcr(void);
    virtual bool test_fuse_sense_macro2ram(void);
    virtual bool test_fuse_progm_ram2macro(void);
    virtual bool test_fuse_progm_reg2macro(void);
    virtual bool test_fuse_progm_bits_sweep(void);

 public:
    virtual bool test_fuse_golden_crc(void);
};

}  // namespace fuse
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_FUSE_SSM_FUSE_H_
