/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_SEM_SSM_SEM_H_
#define HARDWARE_INCLUDE_SSM_SEM_SSM_SEM_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace sem {

class SsmSem : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmSem(Ssm *ssm);
    virtual ~SsmSem() {}

 public:
    virtual bool test_sem_lock(const std::string &);
    virtual bool test_sem_unlock(const std::string &);
    virtual bool test_sem_hilo_wm(const std::string &);
    virtual bool test_sem_ibint(const std::string &);
    virtual void test_mcu_semaphore_mutex_dump_addr(void);
    virtual void test_mcu_semaphore_mutex_dump_value(void);
};

}  // namespace sem
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_SEM_SSM_SEM_H_
