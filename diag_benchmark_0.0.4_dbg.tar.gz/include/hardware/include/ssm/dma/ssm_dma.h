/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_DMA_SSM_DMA_H_
#define HARDWARE_INCLUDE_SSM_DMA_SSM_DMA_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace dma {

class SsmDma : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmDma(Ssm *ssm);
    virtual ~SsmDma() {}

 public:
    virtual bool dma_lrcp(uint64_t, uint64_t, uint64_t, uint32_t = 0);
    virtual bool dma_const_fill(uint64_t, uint32_t, uint32_t, uint32_t = 0);
    virtual bool dma_op_parser_lrcp(const SsmDmaOp &);
    virtual void dma_op_parser_init(SsmDmaOp &, const std::string);
    virtual void dma_op_parser_dump(const SsmDmaOp &);

 public:
    virtual bool test_dma_lrcp(const std::string &);
    virtual bool test_dma_addr_align_check_src(const std::string &);
    virtual bool test_dma_addr_align_check_dst(const std::string &);
    virtual bool test_dma_addr_align_single_op(const std::string &);
    virtual bool test_dma_addr_to_addr_ecf(void);
    virtual bool test_dma_addr_noc_to_noc(const std::string &);
    virtual bool test_dma_interrupt(const std::string &);
    virtual bool test_dma_hw_trig(const std::string &);
    virtual void test_dma_debug(void);

 public:
    virtual bool handle_req_dma_op(const std::string &, const std::string &);
};

}  // namespace dma
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_DMA_SSM_DMA_H_
