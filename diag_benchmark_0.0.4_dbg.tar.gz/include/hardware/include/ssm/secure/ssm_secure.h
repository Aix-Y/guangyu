/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_SECURE_SSM_SECURE_H_
#define HARDWARE_INCLUDE_SSM_SECURE_SSM_SECURE_H_

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace secure {

// SM2 ciphertext order
typedef enum {
    SM2_C1C3C2 = 0,
    SM2_C1C2C3,
} Sm2CipherOrder;

// SM2 ciphertext C3C2 length
#define SM2_ENCRYPT_ADDED_LEN (97)

// SKE algos
typedef enum {
    SKE_ALG_AES_128 = 5,  // AES 128 bits key
    SKE_ALG_AES_256 = 7,  // AES 256 bits key
    SKE_ALG_SM4     = 8,  // SM4
} SkeAlgo;

// SKE mode
typedef enum {
    SKE_MODE_BYPASS  = 0,   // BYPASS Mode
    SKE_MODE_ECB     = 1,   // ECB Mode
    SKE_MODE_XTS     = 2,   // XTS Mode
    SKE_MODE_CBC     = 3,   // CBC Mode
    SKE_MODE_CFB     = 4,   // CFB Mode
    SKE_MODE_OFB     = 5,   // OFB Mode
    SKE_MODE_CTR     = 6,   // CTR Mode
    SKE_MODE_CMAC    = 7,   // CMAC Mode
    SKE_MODE_CBC_MAC = 8,   // CBC-MAC Mode
    SKE_MODE_GCM     = 9,   // GCM Mode
    SKE_MODE_CCM     = 10,  // CCM Mode
    SKE_MODE_GMAC    = 18,  // GMAC Mode
} SkeMode;

// RSA algos
typedef enum {
    RSA_1024 = 0,
    RSA_2048 = 1,
    RSA_4096 = 2,
} RsaAlgo;

class SsmSecure : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmSecure(Ssm *ssm);
    virtual ~SsmSecure() {}

 public:
    virtual bool trng(uint8_t *output, uint32_t &output_len) {
        return false;
    }
    virtual bool sm3_digest(uint8_t *, uint32_t, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm2_sign(
        uint8_t *, uint32_t, uint8_t *, uint32_t, uint8_t *, uint32_t, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm2_verify(uint8_t *, uint32_t, uint8_t *, uint32_t, uint8_t *, uint32_t) {
        return false;
    }
    virtual bool sm2_encrypt(uint8_t *, uint32_t, uint8_t *, uint32_t, uint8_t *, uint32_t,
        Sm2CipherOrder, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm2_decrypt(
        uint8_t *, uint32_t, uint8_t *, uint32_t, Sm2CipherOrder, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm4_encrypt(SkeMode, uint8_t *, uint32_t, uint8_t *, uint32_t, uint8_t *,
        uint32_t, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm4_decrypt(SkeMode, uint8_t *, uint32_t &, uint8_t *, uint32_t, uint8_t *,
        uint32_t, uint8_t *, uint32_t) {
        return false;
    }
    virtual bool aes128_encrypt(SkeMode, uint8_t *, uint32_t, uint8_t *, uint32_t, uint8_t *,
        uint32_t, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool aes128_decrypt(SkeMode, uint8_t *, uint32_t &, uint8_t *, uint32_t, uint8_t *,
        uint32_t, uint8_t *, uint32_t) {
        return false;
    }
    virtual bool aes256_encrypt(SkeMode, uint8_t *, uint32_t, uint8_t *, uint32_t, uint8_t *,
        uint32_t, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool aes256_decrypt(SkeMode, uint8_t *, uint32_t &, uint8_t *, uint32_t, uint8_t *,
        uint32_t, uint8_t *, uint32_t) {
        return false;
    }
    virtual bool rsa_encrypt(RsaAlgo, uint32_t *, uint32_t, uint32_t *, uint32_t *, uint32_t,
        uint32_t *, uint32_t &) {
        return false;
    }
    virtual bool rsa_decrypt(RsaAlgo, uint32_t *, uint32_t &, uint32_t *, uint32_t *, uint32_t,
        uint32_t, uint32_t *, uint32_t) {
        return false;
    }
    virtual bool sha256_digest(uint8_t *, uint32_t, uint8_t *, uint32_t &) {
        return false;
    }

    virtual bool sm2_key_gen(uint8_t *, uint32_t &, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm2_key_store(uint32_t, uint8_t *, uint32_t &, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm2_key_fetch(uint32_t, uint8_t *, uint32_t &, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm2_key_clear(uint32_t, uint8_t *, uint32_t &, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm4_key_store(uint32_t, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm4_key_fetch(uint32_t, uint8_t *, uint32_t &) {
        return false;
    }
    virtual bool sm4_key_clear(uint32_t, uint8_t *, uint32_t &) {
        return false;
    }
};

}  // namespace secure
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_SECURE_SSM_SECURE_H_
