/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SSM_OTP_SSM_OTP_H_
#define HARDWARE_INCLUDE_SSM_OTP_SSM_OTP_H_

#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/ssm/utw/ssm_utw.h"

namespace efvf {
namespace hardware {
namespace ssm {
namespace otp {

class SsmOtp : public efvf::hardware::ssm::utw::SsmUtw {
 public:
    explicit SsmOtp(Ssm *ssm);
    virtual ~SsmOtp() {}

 public:
    virtual std::string ssm_otp_sense_bits(uint32_t, uint32_t);
    virtual void        ssm_otp_progm_bits(uint32_t, uint32_t, uint64_t);
    virtual bool        ssm_otp_sense_to_file(const std::string &);
    virtual uint32_t    ssm_otp_sense_by_row(uint32_t);
    virtual void        ssm_otp_sense_by_rows(uint32_t, uint32_t);
    virtual void        ssm_otp_sense_by_rows(uint32_t, uint32_t, uint32_t *);
    virtual void        ssm_otp_sense_by_rows(void);
    virtual void        ssm_otp_sense_to_rams(uint32_t, uint32_t);
    virtual void        ssm_otp_sense_to_rams(void);
    virtual bool        ssm_otp_strap_supported(const std::string &);
    virtual uint32_t    ssm_otp_strap_get_bsz(const std::string &);
    virtual uint64_t    ssm_otp_sense_by_name(const std::string &);
    virtual bool        ssm_otp_progm_by_name(const std::string &, uint64_t &);
    virtual std::string get_otp_uuid_wafer(void);
    virtual std::string get_otp_uuid_hwdist_src(void);
    virtual std::string get_otp_uuid_hwdist_ram(void);
    virtual std::string get_otp_uuid_hwdist_dst(void);
    virtual void        ssm_otp_dump_rams_item(void);
    virtual uint32_t    ssm_otp_ram_dw_r_by_name(const std::string &);
    virtual bool        ssm_otp_ram_dw_r_by_name(const std::string &, uint32_t &);
    virtual bool        ssm_otp_ram_dw_w_by_name(const std::string &, uint32_t &);
    virtual std::string ssm_otp_dump_ro(void);
    virtual std::string ssm_otp_dump_leakage(const std::string &);
    virtual void        ssm_otp_dump_chip_rev_id(uint32_t);
    virtual uint32_t    ssm_otp_get_prog_passwd(void);
    virtual bool        ssm_otp_progm_by_file(uint32_t &, uint32_t &, const std::string &);
    virtual bool        ssm_otp_get_bisr_info(void);

 public:
    virtual bool     test_otp_ram_pattern_wrcr(void);
    virtual bool     test_otp_sense_macro_dw2ram_o_dw2reg(void);
    virtual bool     test_otp_progm_ram2macro_dw(void);
    virtual bool     test_otp_progm_reg2macro_dw(void);
    virtual bool     test_otp_progm_bits_sweep(void);
    virtual bool     test_otp_golden_crc(void);
    virtual bool     test_otp_vftbl_valid(void);
    virtual bool     test_otp_fixed_valid(void);
    virtual bool     test_otp_idsku_valid(void);
    virtual bool     test_otp_bcode_valid(void);
    virtual bool     test_otp_hdist_valid(void);
    virtual uint32_t sw_seq_asicvf_lv2dpmlv(uint32_t);
    virtual uint32_t sw_seq_sweep_asicvf_min(uint32_t);
    virtual uint32_t sw_seq_sweep_asicvf_max(uint32_t);
    virtual uint32_t sw_seq_sweep_asicvf(uint32_t, uint32_t);
    virtual uint32_t get_otp_dtu_fmin(void);
    virtual uint32_t get_otp_dtu_fmax(void);

 public:
    virtual bool test_otp_golden_fotp(void);

 public:
    virtual std::string handle_req_otp_status(void);
    virtual std::string handle_req_otp_pstate(const std::string &);
    virtual bool        handle_req_otp_hwdist(void);
    virtual bool        handle_req_otp_crc(const std::string &, const std::string &);
    virtual bool        handle_req_otp_crc_calc(const std::string &, const std::string &);
    virtual bool        handle_req_otp_crc_check(const std::string &);
    virtual bool        handle_req_otp_test(const std::string &, const std::string &);
    virtual std::string handle_req_otp_timing(const std::string &, const std::string &);
    virtual void        handle_req_otp_sense_bits(uint32_t, uint32_t);
    virtual bool        handle_req_otp_vftbl_dump(const std::string &);
    virtual bool        handle_req_otp_decode(const std::string &, const std::string &);
};

}  // namespace otp
}  // namespace ssm
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SSM_OTP_SSM_OTP_H_
