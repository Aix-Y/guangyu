/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SYSM_SYS_MON_TASK_H_
#define HARDWARE_INCLUDE_SYSM_SYS_MON_TASK_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"

#include "hardware/include/sysm/sys_mon_task_ns.h"

namespace efvf {
namespace hardware {
namespace sysm {

class SysMonTask {
 public:
    explicit SysMonTask(const Dtu &);
    virtual ~SysMonTask() {}

 public:
    virtual void     syst_notify_create(void);
    virtual void     syst_notify_created(void);
    virtual void     syst_notify_delete(void);
    virtual void     syst_notify_deleted(void);
    virtual uint32_t syst_get_dlms(void);
    virtual uint32_t syst_reg_r(uint32_t);
    virtual void     syst_reg_w(uint32_t, uint32_t);
    virtual uint64_t syst_clock_ms(void);
    virtual uint64_t syst_clock_us(void);
    virtual void     syst_delay_ms(uint32_t);
    virtual void     syst_delay_us(uint32_t);

 public:
    uint32_t syst_get_id(void) {
        return m_tsk_id;
    }
    void syst_set_id(uint32_t id) {
        m_tsk_id = id;
    }
    std::string syst_get_name(void) {
        return m_tsk_nm;
    }
    void syst_set_name(std::string name) {
        m_tsk_nm = name;
    }
    std::string syst_dev_name(void);
    std::string syst_tgt_name(void);
    void        syst_log_open_trunc(std::string &, std::ofstream &);
    void        syst_log_open_append(std::string &, std::ofstream &);
    void        syst_log_write(std::ofstream &, const std::string &);
    void        syst_log_close(std::ofstream &);
    std::string syst_timestamp_str(void);

 protected:
    uint32_t                        m_tsk_id;
    std::string                     m_tsk_nm;
    std::string                     m_dev_nm;
    std::string                     m_tgt_nm;
    uint32_t                        m_dlms;
    const Dtu &                     m_dtu;
    Hpd *                           m_hpd;
    std::shared_ptr<spdlog::logger> logger_;
};

}  // namespace sysm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SYSM_SYS_MON_TASK_H_
