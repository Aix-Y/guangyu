/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SYSM_SYS_MON_TASK_NS_H_
#define HARDWARE_INCLUDE_SYSM_SYS_MON_TASK_NS_H_

#include <algorithm>
#include <map>
#include <string>
#include <vector>

namespace efvf {
namespace hardware {
namespace sysm {

// clang-format off

typedef enum {
    kSysmTaskGst = 0,
    kSysmTaskPtu,
    kSysmTaskRas,
    kSysmTaskThm,
    kSysmTaskPid,
    kSysmTaskNum,
    kSysmTaskInvalid,
} kSysmTask;

inline std::string get_task_name(uint32_t task_id) {
    switch (task_id) {
        case kSysmTaskGst:       return "TASK_MONITOR_GST";
        case kSysmTaskPtu:       return "TASK_MONITOR_PTU";
        case kSysmTaskRas:       return "TASK_MONITOR_RAS";
        case kSysmTaskThm:       return "TASK_MONITOR_THM";
        case kSysmTaskPid:       return "TASK_MONITOR_PID";
        case kSysmTaskNum:       return "TASK_MONITOR_NUM";
        case kSysmTaskInvalid:   return "TASK_MONITOR_INVALID";
        default: break;
    }
    return "TASK_MONITOR_UDEF";
}

inline uint32_t get_task_id(const std::string& task_name) {
    if ("GHOST"  == task_name)   return kSysmTaskGst;
    if ("PTU"    == task_name)   return kSysmTaskPtu;
    if ("RAS"    == task_name)   return kSysmTaskRas;
    if ("THM"    == task_name)   return kSysmTaskThm;
    if ("PID"    == task_name)   return kSysmTaskPid;
    return kSysmTaskInvalid;  // cmdline param task list
}

typedef struct _syst_param_thm {
    uint32_t    thm_tmr_ms;
    bool        thm_csv_en;
    uint32_t    thm_die_op;
    uint32_t    thm_log_ap;
    std::string thm_log_lb;
    std::string thm_txt_nm;
    std::string thm_csv_nm;
} syst_param_thm_t;

typedef struct _syst_param_ptu {
    uint32_t    ptu_tmr_ms;
    uint32_t    ptu_ctl_md;
    uint32_t    ptu_die_op;
    double      ptu_p_asic;
    double      ptu_p_ldlt;
    double      ptu_p_rdlt;
    double      ptu_d_vmin;
    double      ptu_d_vmax;
    double      ptu_d_step;
} syst_param_ptu_t;

typedef struct _syst_param_plv {
    uint32_t    plv_tmr_ms;
    bool        plv_txt_en;
    uint32_t    plv_die_op;
    uint32_t    plv_log_ap;
    std::string plv_log_lb;
    std::string plv_txt_nm;
    uint32_t    plv_swt_tp;
    uint32_t    plv_swt_op;
    uint32_t    plv_min_lv;
    uint32_t    plv_max_lv;
    uint32_t    plv_res_lv;
    std::string plv_fix_lv;
    std::string plv_flt_lv;
} syst_param_plv_t;

// clang-format on

typedef struct _column_d {
    _column_d(const std::string &_k, const std::string &_v) : key(_k), val(_v) {}
    std::string key;
    std::string val;
} column_d;

typedef struct _dacc_mma_d {
    _dacc_mma_d() : min(DBL_MAX), max(DBL_MIN), acc(0), cnt(0) {}
    void update(const boost::any &_v) {
        try {
            double v = boost::any_cast<double>(_v);

            min = ((v < min) ? v : min);
            max = ((v > max) ? v : max);
            acc = acc + v;
            cnt = cnt + 1;
        } catch (...) {
            cnt = 0;
            min = max = acc = 0;
            return;  // drop data bad_cast
        }
    }
    bool empty(void) const {
        return (0 == cnt);
    }
    double   min;
    double   max;
    double   acc;
    uint32_t cnt;
} dacc_mma_d;

class syst_samplet_v1 {
 public:
    syst_samplet_v1() {
        clear_row();
        clear_column();
    }
    ~syst_samplet_v1() {
        clear_row();
        clear_column();
    }
    void clear_row(void) {
        m_row_data.clear();
    }
    void clear_column(void) {
        m_column_data.clear();
    }
    bool row_empty(void) {
        return m_row_data.empty();
    }
    template <typename T>
    void column_v(const std::string &k, const T v) {
        column_d data(k, std::to_string(v));
        m_row_data.push_back(data);
        m_column_data[k].push_back(boost::any(v));
    }
    void column_s(const std::string &k, const std::string &v) {
        column_d data(k, v);
        m_row_data.push_back(data);
        m_column_data[k].push_back(boost::any(v));
    }
    std::string row_title_str(void) {
        std::string title = {};
        for (uint32_t idx = 0; idx < m_row_data.size(); idx++)
            title += (m_row_data[idx].key + ",");
        return title;
    }
    std::string row_data_str(void) {
        std::string value = {};
        for (uint32_t idx = 0; idx < m_row_data.size(); idx++)
            value += (m_row_data[idx].val + ",");
        return value;
    }
    std::string row_val(const std::string &key) {
        assert(false == row_empty());  // sanity check
        for (uint32_t idx = 0; idx < m_row_data.size(); idx++) {
            if (key == m_row_data[idx].key)
                return m_row_data[idx].val;
        }
        assert(false);  // key not found
    }
    std::string column_dcac_mma_str(const std::string &k) {
        assert(false == k.empty());  // data cac min max ave

        auto search_end = m_column_data.find(k);
        if (m_column_data.end() == search_end) {
            return (k + " SKIP NO SAMPLE DATA FOUND");  // or NA data requested
        }

        std::vector<double> data = {};
        for (auto &any_val : m_column_data[k])
            data.push_back(boost::any_cast<double>(any_val));
        assert(false == data.empty());  // sanity check

        double min = *(std::min_element(data.begin(), data.end()));
        double max = *(std::max_element(data.begin(), data.end()));
        double ave = (std::accumulate(data.begin(), data.end(), 0.0) / data.size());

        std::stringstream ss_min_max_ave("");  // coordinate with script
        ss_min_max_ave << k + "_MIN:" << std::to_string(min) << " "
                       << k + "_MAX:" << std::to_string(max) << " "
                       << k + "_AVE:" << std::to_string(ave);

        return ss_min_max_ave.str();
    }
    void dump_for_debug(void) {
        for (uint32_t idx = 0; idx < m_row_data.size(); idx++) {
            std::cout << "key_" << m_row_data[idx].key << " val_" << m_row_data[idx].val
                      << std::endl;
        }
    }

    std::vector<column_d> m_row_data;
    std::map<std::string, std::vector<boost::any>> m_column_data;
};

class syst_samplet_v2 {
 public:
    syst_samplet_v2() {
        clear_row();
        clear_column();
    }
    ~syst_samplet_v2() {
        clear_row();
        clear_column();
    }
    void clear_row(void) {
        m_row_data.clear();
    }
    void clear_column(void) {
        m_column_data.clear();
    }
    bool row_empty(void) {
        return m_row_data.empty();
    }
    template <typename T>
    void column_v(const std::string &k, const T v) {
        column_d data(k, std::to_string(v));
        m_row_data.push_back(data);
        m_column_data[k].update(boost::any(v));
    }
    void column_s(const std::string &k, const std::string &v) {
        column_d data(k, v);
        m_row_data.push_back(data);
    }
    std::string row_title_str(void) {
        std::string title = {};
        for (uint32_t idx = 0; idx < m_row_data.size(); idx++)
            title += (m_row_data[idx].key + ",");
        return title;
    }
    std::string row_data_str(void) {
        std::string value = {};
        for (uint32_t idx = 0; idx < m_row_data.size(); idx++)
            value += (m_row_data[idx].val + ",");
        return value;
    }
    std::string row_val(const std::string &key) {
        assert(false == row_empty());  // sanity check
        for (uint32_t idx = 0; idx < m_row_data.size(); idx++) {
            if (key == m_row_data[idx].key)
                return m_row_data[idx].val;
        }
        assert(false);  // key not found
    }
    std::string column_dcac_mma_str(const std::string &k) {
        assert(false == k.empty());  // data cac min max ave

        auto search_end = m_column_data.find(k);
        if (m_column_data.end() == search_end) {
            return (k + " SKIP NO SAMPLE DATA FOUND");  // or NA data requested
        }

        std::stringstream ss_min_max_ave("");  // coordinate with script
        {
            const dacc_mma_d &d = m_column_data[k];

            double ave = (d.empty()) ? 0 : (d.acc / d.cnt);
            ss_min_max_ave << k + "_MIN:" << std::to_string(d.min) << " "
                           << k + "_MAX:" << std::to_string(d.max) << " "
                           << k + "_AVE:" << std::to_string(ave);
        }
        return ss_min_max_ave.str();
    }
    void dump_for_debug(void) {
        for (uint32_t idx = 0; idx < m_row_data.size(); idx++) {
            std::cout << "key_" << m_row_data[idx].key << " val_" << m_row_data[idx].val
                      << std::endl;
        }
    }

    std::vector<column_d> m_row_data;
    std::map<std::string, dacc_mma_d> m_column_data;
};

class syst_samplet_v3 {
 public:
    std::string summary(const std::string &dtag) {
        std::stringstream plv_info_str("");
        plv_info_str << dtag << " ORIG FEATURE STATUS: ";
        plv_info_str << (plv_feats_orig ? "ON" : "OFF") << std::endl;
        plv_info_str << dtag << " ORIG LEVEL ON-START: ";
        plv_info_str << plv_level_orig << std::endl;

        for (uint32_t lv = 0; lv < SSM_ARRAY_SIZE(plv_level_cnts); lv++) {
            uint32_t per_lv_cnts = plv_level_cnts[lv];
            if (0U == per_lv_cnts) {
                continue;
            }
            plv_info_str << dtag << " RESIDENCY LV[";
            plv_info_str << std::setw(3) << lv << "]: ";
            plv_info_str << std::setw(5) << per_lv_cnts << " / ";
            plv_info_str << std::setw(5) << plv_total_cnts << " = ";
            plv_info_str << std::to_string((100.0f * per_lv_cnts) / (1.0f * plv_total_cnts));
            plv_info_str << std::endl;
        }
        return plv_info_str.str();
    }

    bool     plv_feats_orig;
    uint32_t plv_level_orig;
    uint32_t plv_total_cnts;
    uint32_t plv_level_cnts[255];
};

}  // namespace sysm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SYSM_SYS_MON_TASK_NS_H_
