/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SYSM_SYS_MON_H_
#define HARDWARE_INCLUDE_SYSM_SYS_MON_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace sysm {

class SysMon {
 public:
    explicit SysMon(const Dtu &);
    virtual ~SysMon() {}

 public:
    virtual void Create(void);
    virtual void Destroy(void);

 protected:
    virtual uint32_t sysm_reg_r(uint32_t);
    virtual void     sysm_reg_w(uint32_t, uint32_t);
    virtual void     sysm_delay_ms(uint32_t);
    virtual void     sysm_delay_us(uint32_t);

 protected:
    const Dtu &                     m_dtu;
    Hpd *                           m_hpd;
    std::shared_ptr<spdlog::logger> logger_;
};

}  // namespace sysm
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SYSM_SYS_MON_H_
