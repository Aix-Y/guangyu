/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_VPP_CODEC_VPP_CODEC_H_
#define HARDWARE_INCLUDE_VPP_CODEC_VPP_CODEC_H_

#include <memory>
#include <vector>

#include "framework/include/mem.h"

using efvf::framework::mem::Mem;

#undef CODEC_DBG_SHOW_FUNC
#define CODEC_DBG_SHOW_FUNC LOG_DEBUG("{}", __func__)

namespace efvf {
namespace hardware {
namespace codec {

// Codec online process:
// Crop -> CSC -> Rotation -> resize -> SFC
typedef struct CodecConfig {
    bool        is_decoder;
    uint32_t    asid;
    uint32_t    ncores;
    uint32_t    disallow;
    uint32_t    lsid;
    uint32_t    input_format;
    uint32_t    output_format;  // CSC
    uint32_t    input_buf_cnt;
    uint32_t    input_buf_size;
    uint32_t    output_buf_cnt;
    uint32_t    input_width;
    uint32_t    input_height;
    uint32_t    nalu_fmt;
    uint32_t    frame_nplane;
    uint32_t    frame_plane_size[3];
    bool        resize_en;
    uint32_t    output_width;  //  resize
    uint32_t    output_height;
    bool        crop_en;
    uint32_t    crop_x;  // crop
    uint32_t    crop_y;
    uint32_t    rotation_mode;  // 90 / 180 / 270
    uint32_t    mirror_mode;    // 0 / 1 / 2
    uint32_t    user_info;
    uint32_t    sfo_itvl;
    uint32_t    frame_cnt;
    uint32_t    frame_rate;
    uint32_t    profile;
    uint32_t    level;
    uint32_t    cabac_init_idc;
    uint32_t    tile_rows;
    uint32_t    tile_cols;
    uint32_t    p_frames;
    uint32_t    b_frames;
    uint32_t    gop_type;
    uint32_t    profiling;
    uint32_t    ddr_die_id;
    uint64_t    crc_buf_addr;
    bool        check_output;
    const char *fw_name;
    CodecConfig()
        : is_decoder(true),
          asid(0),
          ncores(1),
          disallow(0),
          lsid(0),
          input_format(0),
          output_format(0),
          input_buf_cnt(2),
          output_buf_cnt(2),
          input_buf_size(0x200000),
          input_width(0),
          input_height(0),
          nalu_fmt(0),
          frame_nplane(0),
          resize_en(false),
          output_width(0),
          output_height(0),
          crop_en(false),
          crop_x(0),
          crop_y(0),
          rotation_mode(0),
          mirror_mode(0),
          user_info(0),
          sfo_itvl(0),
          frame_cnt(0),
          frame_rate(30),
          profile(0),
          level(0),
          cabac_init_idc(0),
          tile_rows(0),
          tile_cols(0),
          p_frames(0),
          b_frames(0),
          gop_type(0),
          profiling(0),
          ddr_die_id(0),
          crc_buf_addr(0),
          check_output(false),
          fw_name(nullptr) {
        for (uint32_t i = 0; i < 3; i++) {
            frame_plane_size[i] = 0;
        }
    }
} CodecConfig;

typedef struct CodecStatus {
    uint32_t total_core_num;
    uint32_t work_core_num;
    uint32_t work_fps;
    CodecStatus() : total_core_num(4), work_core_num(0), work_fps(0) {}
} CodecStatus;

typedef struct PortBufInfo {
    Mem *    mem_ptr;       // Mem *
    uint32_t free_buf_cnt;  // frame or bitstream
    uint32_t buffer_type;   // frame or bitstream
    uint32_t dir;
    uint32_t data_len;
    uint32_t offset;
    uint32_t flag;             // frame or buffer flag
    uint32_t visable_frame_h;  // frame buffer
    uint32_t visable_frame_w;  // frame buffer
    uint32_t frame_type;       // frame buffer format, bitstream type
    uint32_t src_transform;    // bitstream buffer
    PortBufInfo()
        : mem_ptr(nullptr),
          free_buf_cnt(0),
          buffer_type(0),
          dir(0),
          data_len(0),
          offset(0),
          flag(0),
          visable_frame_h(0),
          visable_frame_w(0),
          frame_type(0),
          src_transform(0) {}
} PortBufInfo;

class Codec {
 public:
    Codec();
    virtual ~Codec();

 public:
    // virtual uint32_t GetCodecInst() const            = 0;
    virtual bool InitCodec(CodecConfig &cfg) = 0;
    virtual bool DeinitCodec()               = 0;
    virtual bool RegisterPortMem(Mem *m, uint32_t dir) = 0;
    virtual Mem *GetPortMem(uint32_t dir, uint32_t &offset, uint32_t &data_len) = 0;
    virtual bool PutPortMem(Mem *m, uint32_t data_len, uint32_t dir)            = 0;
    virtual bool GetPortMem(PortBufInfo &info) = 0;
    virtual bool PutPortMem(PortBufInfo &info) = 0;
    virtual bool GetFrameInfo(uint32_t fmt, uint32_t w, uint32_t h, uint32_t *np,
        uint32_t *stride, uint32_t *plane_size, uint32_t *setting_stride)            = 0;
    virtual bool GetFrameInfo2(uint32_t *np, uint32_t *stride, uint32_t *plane_size) = 0;
    virtual bool MemConstFill(uint64_t buf_addr, uint64_t buf_size, uint32_t pattern = 0) = 0;
    virtual bool DataCopy(uint64_t src_addr, uint64_t dst_addr, uint64_t size)            = 0;
    virtual uint32_t GetDataCrc(uint64_t src_addr, uint64_t dst_addr, uint64_t size)      = 0;

    virtual bool WaitOutputFlushed()               = 0;
    virtual bool CodecRegAccessTest()              = 0;
    virtual bool SetL2Cache(bool en)               = 0;
    virtual bool GetCodecStatus(CodecStatus &info) = 0;
    //
    virtual int32_t InitCodec() = 0;
    virtual int32_t GetCodecOpt(uint32_t opt, int64_t &val) = 0;
    virtual int32_t SetCodecOpt(uint32_t opt, int64_t val)  = 0;
};

}  // namespace codec
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_VPP_CODEC_VPP_CODEC_H_
