/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_AP_AP_RAS_H_
#define HARDWARE_INCLUDE_AP_AP_RAS_H_

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace ap {

class ApRasCfg : public efvf::hardware::RasCfg {
    // SMEM / MIH / AP_RING_BUF_SRAMCTRL
 public:
    uint32_t mih_sram_parity_gen_en : 1;
    uint32_t mih_sram_parity_check_en : 1;
    uint32_t ring_buf_sram_parity_gen_en : 1;
    uint32_t ring_buf_sram_parity_check_en : 1;
    uint32_t mdma_sram_parity_gen_en : 1;
    uint32_t mdma_sram_parity_check_en : 1;

    uint32_t : 24;
    ApRasCfg() {
        mih_sram_parity_gen_en        = 0;
        mih_sram_parity_check_en      = 0;
        ring_buf_sram_parity_gen_en   = 0;
        ring_buf_sram_parity_check_en = 0;
        mdma_sram_parity_gen_en       = 0;
        mdma_sram_parity_check_en     = 0;
    }
};

class ApRasErrInj : public efvf::hardware::RasErrInj {
 public:
    uint32_t mih_sram_parity_inj : 1;
    uint32_t ring_buf_sram_parity_inj : 1;
    uint32_t mdma_sram_parity_inj : 1;

    uint32_t : 29;
    uint32_t sram_parity_err_inj_num;
    ApRasErrInj() {
        mih_sram_parity_inj      = 0;
        ring_buf_sram_parity_inj = 0;
        mdma_sram_parity_inj     = 0;
        sram_parity_err_inj_num  = 1;
    }
};

class ApRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t mih_sram_parity_error;
    uint32_t mdma_sram_parity_error;
    uint32_t mdma_sram_parity_error_log;
    uint32_t ring_buf_sram_parity_error;
    uint64_t ring_buf_sram_parity_error_info[6];

    ApRasErrStat() {
        mih_sram_parity_error      = 0;
        mdma_sram_parity_error     = 0;
        mdma_sram_parity_error_log = 0;
        ring_buf_sram_parity_error = 0;
        for (uint32_t i = 0; i < 6; i++) {
            ring_buf_sram_parity_error_info[i] = 0;
        }
    }
};

class ApIntrptCfg : public efvf::hardware::IntrptCfg {
 public:
};

class ApIntrptStat : public efvf::hardware::IntrptStat {
 public:
};

class ApRas : public efvf::hardware::IRas {};

}  // namespace ap
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_AP_AP_RAS_H_
