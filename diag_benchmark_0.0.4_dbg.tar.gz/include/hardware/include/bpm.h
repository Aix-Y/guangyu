/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_BPM_H_
#define HARDWARE_INCLUDE_BPM_H_

#include <map>
#include <memory>
#include <string>
#include <vector>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace pmc {

typedef struct _BpmResult {
    uint64_t Wc    = 0;
    uint64_t Rc    = 0;
    uint64_t Wthro = 0;
    uint64_t Rthro = 0;
    uint64_t Wl    = 0;
    uint64_t Rl    = 0;
    uint16_t Wost  = 0;
    uint16_t Rost  = 0;
} BpmResult;

class Pmc;
class Bpm : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Bpm(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~Bpm() {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  time  The time
     */
    virtual void ConfigSingleMode(uint64_t time, bool tigger = true) = 0;
    virtual void SingleModeTigger() = 0;

    /**
     * @brief      { function_description }
     */
    virtual void CleanupSingleMode() = 0;

    /**
     * @brief      Gets the result.
     */
    virtual void GetResult(BpmResult *res) = 0;

    /**
     * @brief      Prints a result.
     */
    virtual void PrintResult() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual Pmc *PmcMode() = 0;
};

}  // namespace pmc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_BPM_H_
