/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MC_MC_AL_H_
#define HARDWARE_INCLUDE_MC_MC_AL_H_

#include <memory>
#include <string>
#include <vector>

#include "device/include/dtu.h"
#include "framework/include/mem.h"
#include "hardware/include/hardware.h"

using efvf::framework::mem::Mem;
using efvf::framework::mem::CacheType;
using efvf::framework::mem::CACHE_TYPE_FAULT;

namespace efvf {
namespace hardware {
namespace mc {

typedef struct _RECT {
    uint32_t x0;  // left
    uint32_t y0;  // top
    uint32_t x1;  // right
    uint32_t y1;  // bottom
} RECT;

typedef struct _DIM2 {
    uint32_t x;  // dimension 0
    uint32_t y;  // dimension 1
} DIM2;

typedef enum {
    BLT_MOVE_RECT_STEP = 0,  // location step by step: horiz / vertical / diagonal
    BLT_MOVE_RECT_RANDOM,    // random location
    BLT_MOVE_FULL_MEM,       // full memory BLT
} BLT_MOVE_MODE;

class MC_SURFACE {
 public:
    uint32_t m_width;   // dim0: width
    uint32_t m_height;  // dim1: height
    uint32_t m_depth;   // dim2: depth
    uint32_t m_bpe;     // byte_per_element
    uint32_t m_pitch;   // pitch in bytes

 protected:
    MemType    m_mtype;
    const Dtu &m_dtu;
    uint8_t    m_param;  // param: mc_inst for HBM; cid for cluster_mem; ignore for sysmem

 public:
    MC_SURFACE(const Dtu &dtu, MemType mtype, uint32_t width, uint32_t height, uint32_t depth,
        uint32_t bpe = 4, uint32_t align = 0x1000,
        uint8_t param = 0,  // param: mc_inst for HBM; cid for cluster_mem; sid for sip memory;
                            // ignore for sysmem
        CacheType ctype = CACHE_TYPE_FAULT);

    MC_SURFACE(const Dtu &dtu, uint32_t width, uint32_t height, uint32_t depth, uint32_t bpe,
        Mem &mem_res, uint64_t mem_offset = 0);

    MC_SURFACE(MC_SURFACE &surface, const RECT &rect);

    virtual ~MC_SURFACE();

    uint64_t GetDevAddr() {
        return m_dev_addr;
    }

    // uint64_t GetRelativeAddr();

    uint64_t GetSize() {
        return m_size;
    }

    Mem *GetMem() {
        return m_mem.get();
    }

    MemType GetMemtype() {
        return m_mtype;
    }

    void *GetPtr() {
        return m_vptr;
    }

    Mem *GetMemBase() {
        return m_mem.get();
    }

 private:
    std::shared_ptr<Mem> m_mem;
    void *               m_vptr;
    uint64_t             m_dev_addr;
    uint64_t             m_size;
};

// MemBase has following re-defined for sip-dram's param:
// bit[3:0] cid: 0-3
// bit[7:4] sid: 0-7
// while in testcase, we treat param as GLOBAL SIP-ID,
// here to have to remap Global SIP-ID to CID_SID encoding
// copy from 1.0. TBD(issac.liu)
inline void conv_glb_sid_to_cid_sid(MemType mtype, uint8_t param, std::vector<int> inst) {
    if (efvf::framework::mem::MEM_TYPE_DMEM == mtype) {
        inst.push_back(param);
    }

    if (efvf::framework::mem::MEM_TYPE_HOST == mtype) {
        return;
    }
    /*
    MEM_TYPE_CMEM,
    MEM_TYPE_CBF,
    MEM_TYPE_SMEM,
    MEM_TYPE_CLMEM,
    MEM_TYPE_SLMEM,
    MEM_TYPE_IBN,
    MEM_TYPE_SP,
    */
}

MC_SURFACE::MC_SURFACE(const Dtu &dtu, MemType mtype, uint32_t width, uint32_t height,
    uint32_t depth, uint32_t bpe, uint32_t align,
    uint8_t param,  // param: mc_inst for HBM; cid for cluster_mem; global sid for sip memory;
                    // ignore for sysmem
    CacheType ctype)
    : m_mtype(mtype), m_dtu(dtu) {
    m_width  = width;
    m_height = height;
    m_depth  = depth;
    m_bpe    = bpe;
    m_param  = param;
    m_pitch  = width * bpe;

    std::vector<int> inst;
    conv_glb_sid_to_cid_sid(mtype, param, inst);
    m_mem =
        std::make_shared<Mem>(m_dtu, mtype, inst, (uint64_t)width * height * bpe * depth, 0);

    m_dev_addr = m_mem->GetDevAddr()[0];
    m_size     = m_mem->GetSize();
    if ((this->m_mtype == efvf::framework::mem::MEM_TYPE_DMEM) ||
        (this->m_mtype == efvf::framework::mem::MEM_TYPE_DMEM))
        m_vptr = m_mem->GetHostPtr();
    else
        m_vptr = nullptr;
}

// carve a new smaller surface from the src_surface.
// the new surface location is defined by the aperture_rect.
MC_SURFACE::MC_SURFACE(MC_SURFACE &surface, const RECT &aper_rect)
    : m_mtype(surface.m_mtype), m_dtu(surface.m_dtu) {
    // check if aper_rect is inside of surface
    if (!(aper_rect.y1 < surface.m_height) || !(aper_rect.x1 < surface.m_width) ||
        !(aper_rect.x0 < aper_rect.x1) || !(aper_rect.y0 < aper_rect.y1)) {
        // LOG_ERROR("aper_rect not within surface!");
        throw;
    }
    uint64_t offset =
        (uint64_t)aper_rect.y0 * surface.m_pitch + (uint64_t)aper_rect.x0 * surface.m_bpe;
    if (surface.m_mem) {
        m_dev_addr = surface.m_mem->GetDevAddr()[0] + offset;
    } else {
        // LOG_ERROR("{}(): src surface's mem resource pointer is null", __FUNCTION__);
        throw;
    }
    m_vptr   = reinterpret_cast<void *>((uint64_t)(surface.m_mem->GetHostPtr()) + offset);
    m_width  = aper_rect.x1 - aper_rect.x0 + 1;
    m_height = aper_rect.y1 - aper_rect.y0 + 1;
    m_depth  = surface.m_depth;
    m_bpe    = surface.m_bpe;
    m_param  = surface.m_param;
    m_pitch  = m_width * m_bpe;
    m_size   = (uint64_t)m_pitch * m_height;
}

MC_SURFACE::MC_SURFACE(const Dtu &dtu, uint32_t width, uint32_t height, uint32_t depth,
    uint32_t bpe, Mem &mem_res, uint64_t mem_offset)
    : m_mtype(mem_res.GetMemType()), m_dtu(dtu) {
    if ((uint64_t)width * height * depth * bpe > mem_res.GetSize()) {
        // LOG_ERROR("associated mem resource size too small!! cannot create a surface based on
        // it.");
        throw;
    }

    m_width  = width;
    m_height = height;
    m_depth  = depth;
    m_bpe    = bpe;
    /*
    m_param  = (m_mtype == MEM_TYPE_DMEM) ?
                  mem_res.GetMcInst() :
                  (m_mtype == hpd::MEM_TYPE_CLUSTER) ?
                  mem_res.GetMemRes().in.cluster_id :
                  (m_mtype == hpd::MEM_TYPE_SIP) ? mem_res.GetMemRes().in.sip_id : 0;
    */
    m_pitch    = m_width * m_bpe;
    m_size     = (uint64_t)m_pitch * m_height;
    m_dev_addr = mem_res.GetDevAddr()[0] + mem_offset;
    m_vptr     = mem_res.GetHostPtr();
    m_param    = 0;
}

MC_SURFACE::~MC_SURFACE() {}

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_MC_MC_AL_H_
