/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MC_MC_DFI_H_
#define HARDWARE_INCLUDE_MC_MC_DFI_H_

#include <map>
#include <memory>
#include <string>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace mcdfi {
typedef enum _DFI_EVENT {
    DFI_CNT_MRS_CMD = 0,
    DFI_CNT_ACT_CMD,
    DFI_CNT_RD_CMD,
    DFI_CNT_RDA_CMD,
    DFI_CNT_WOM_CMD,
    DFI_CNT_WOMA_CMD,
    DFI_CNT_WDM_CMD,
    DFI_CNT_WDMA_CMD,
    DFI_CNT_WSM_CMD,
    DFI_CNT_WSMA_CMD,
    DFI_CNT_LDFF_CMD,
    DFI_CNT_RDTR_CMD,
    DFI_CNT_WRTR_CMD,
    DFI_CNT_PREPB_CMD,
    DFI_CNT_PREAB_CMD,
    DFI_CNT_REFPB_CMD,
    DFI_CNT_REFAB_CMD,
    DFI_CNT_CAT_CMD,
    DFI_CNT_CNT_PDE_CMD,
    DFI_CNT_SRE_CMD,
    DFI_CNT_EXIT_CMD,
} Dfi_Event;

class McDfi : public Hardware {
 public:
    /*!
     * @brief McDfi constructor
     */
    explicit McDfi(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /*!
     * @brief desctructor
     */
    virtual ~McDfi() {}

    /*!
     * @brief print all the McDfi configuration
     */
    virtual void     DfiMonChaMatchPattern() = 0;
    virtual void     DfiMonChbMatchPattern() = 0;
    virtual void     StartMon()              = 0;
    virtual void     StopMon()               = 0;
    virtual void     ClearMon()              = 0;
    virtual void     FreeMonMode()           = 0;
    virtual void     WindowsMonMode()        = 0;
    virtual bool     DfiMonStatus()          = 0;
    virtual uint32_t DfiMonEventVal(int ch, Dfi_Event event) = 0;
    virtual void     PrintAllEventValue() = 0;
    virtual uint32_t CalCycleCounterVal() = 0;
};

}  // namespace mcdfi
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MC_MC_DFI_H_
