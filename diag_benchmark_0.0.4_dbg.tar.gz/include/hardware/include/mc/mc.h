/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MC_MC_H_
#define HARDWARE_INCLUDE_MC_MC_H_

#include <memory>
#include <string>
#include <vector>

#include "hardware/include/hardware.h"
#include "hardware/include/mc/mc_phy.h"
#include "hardware/include/mc/mc_ras.h"
#include "hardware/include/mc/mc_test.h"
#include "hardware/include/pmc.h"
#include "hardware/include/system_adapter.h"

using efvf::hardware::system_adapter::SystemAdapter;

namespace efvf {
namespace hardware {
namespace mc {

class McPhy;
// class McDfi;
typedef struct _RegAccessTest {
    uint32_t mc_chan_mask;  //  1: channel to test, 0: channel not test
} RegAccessTest_t;

class Mc : public Hardware {
 public:
    typedef enum {
        CHECK_REG = 0,
    } TaskId;

    typedef struct TaskParam { uint32_t addr; };

 public:
    Mc() : Hardware() {}
    explicit Mc(std::shared_ptr<spdlog::logger> logger);
    virtual ~Mc() {}

    /* legacy interface */
 public:
    virtual uint8_t  GetHbmInst();
    virtual uint32_t GetGlbInstId();

    virtual bool ConfigChanForRegRw(uint32_t chan);
    virtual bool ConfigECC(bool ecc_en);
    virtual bool ConfigChanRegBrdcst(bool enable);
    virtual void ConfigWrapperRegBrdcst(bool enable);

    virtual uint32_t GetNumOfInsts(void);
    virtual uint32_t GetNumOfMcChannelsPerInst(void);
    virtual uint32_t GetNumOfMemoryChannels(void);
    virtual void TopRegWrite(uint32_t offset, uint32_t val);
    virtual uint32_t TopRegRead(uint32_t offset);
    virtual std::vector<uint32_t> ChanRegRead(uint32_t chan, uint32_t offset);
    virtual void ChanRegWrite(uint32_t chan, uint32_t offset, uint32_t val);

    std::shared_ptr<IMcTest> GetTest() {
        return test_;
    }

    std::shared_ptr<McPhy> GetPhy() {
        return phy_;
    }
    /* 2.0 interface */
 public:
    virtual uint32_t       GetGlbInst(void);
    virtual bool           SetMcPriority(void);
    virtual void           EnableMcCFCnt(void);
    virtual void           DisableMcCFCnt(void);
    virtual uint32_t       CalCntVal(void);
    virtual void           SoftResetECFPmc(void);
    virtual uint32_t       GetDieId(void);
    virtual uint32_t       GetMemSubsysId(void);
    virtual uint64_t       GetMemSubsysAddrRange(void);
    virtual uint64_t       GetAddrOffsetOnMdf(void);
    virtual uint64_t       GetPaOffset(void);
    virtual std::string    GetName(void);
    virtual uint32_t       GetChannelId(void);
    virtual bool           ImuSramRw(const std::string, uint32_t, uint8_t *, uint32_t);
    virtual bool           handle_tool_req(const std::string &);
    virtual bool           handle_tool_req(const std::string &, std::string &);
    virtual bool           handle_tool_req(const std::string, uint64_t &, uint64_t &);
    virtual bool           handle_tool_req(const std::string, uint64_t &);
    virtual SystemAdapter *sa();

 protected:
    std::shared_ptr<IMcTest> test_;

 protected:
    std::shared_ptr<McPhy> phy_;
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_MC_MC_H_
