/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MC_MC_MGR_H_
#define HARDWARE_INCLUDE_MC_MC_MGR_H_

#include <memory>
#include <vector>

#include "hardware/include/hardware.h"
#include "hardware/include/mc/mc.h"
#include "hardware/include/mc/mc_mdf.h"
#include "hardware/include/mc/mc_ras.h"
#include "hardware/include/mc/mc_test.h"
#include "hardware/include/pmc.h"

namespace efvf {
namespace hardware {
namespace mc {

enum MC_MEM_TYPE { MC_MEM_HBM = 0, MC_MEM_GDDR6, MC_MEM_INVALID };

enum MC_VENDOR_ID { MC_VENDOR_RAMBUS = 0, MC_VENDOR_CADENCE, MC_VENDOR_INVALID };

enum MC_MEM_CAPACITY { MC_MEM_CAPACITY_2GB = 0, MC_MEM_CAPACITY_4GB, MC_MEM_CAPACITY_INVALID };

#define NUM_OF_MC_PER_MEM_SUBSYS_SCORPIO (3)

enum MC_SA_INTR_INDEX {
    MC_SA_INTR_INDEX_0_MANUAL_TRIG           = 0,
    MC_SA_INTR_INDEX_5_IMU_OB_RD_PARITY      = 5,
    MC_SA_INTR_INDEX_6_IMU_IRAM_WR_PARITY    = 6,
    MC_SA_INTR_INDEX_7_IMU_DRAM_WR_PARITY    = 7,
    MC_SA_INTR_INDEX_8_IMU_IRAM_PARITY       = 8,
    MC_SA_INTR_INDEX_9_IMU_DRAM_PARITY       = 9,
    MC_SA_INTR_INDEX_10_DMEM_INTR            = 10,
    MC_SA_INTR_INDEX_11_ECF_MC_PARITY        = 11,
    MC_SA_INTR_INDEX_12_ABSP_CF_SA_WR_PARITY = 12,
    MC_SA_INTR_INDEX_12_ABMP_CF_SA_RD_PARITY = 12,
    MC_SA_INTR_INDEX_13_ABSP_DF_SA_WR_PARITY = 13,
    MC_SA_INTR_INDEX_13_ABMP_DF_SA_RD_PARITY = 13,
};

typedef struct MemInfo_ {
    uint64_t edf_addr;
    uint64_t mdf_id;
    uint64_t mc_id;
    uint64_t mc_addr;
    uint64_t channel;
    uint64_t bank;
    uint64_t row;
    uint64_t col;
} MemInfo;

typedef struct VirAddr_ {
    uint64_t vir_addr_p0;  // edf port 0 virtual addr
    uint64_t vir_addr_p1;  // edf port 1 virtual addr
} VirAddr;

class McMgr {
 public:
    typedef struct DmemAddrInfo_s {
        uint64_t addr;
        uint64_t length;
    } DmemAddrInfo;

 public:
    // McMgr() : Hardware() {}
    // explicit McMgr(std::shared_ptr<spdlog::logger> logger, const Dtu &dtu);
    McMgr(std::shared_ptr<spdlog::logger> logger, const Dtu &dtu);
    virtual ~McMgr() {}

 private:
    virtual bool HwInit() {
        return false;
    }

 public:
    virtual bool Init() {
        return false;
    }
    virtual void        PrintMemInfo() {}
    virtual void        VA2PA(uint64_t, MemInfo &, bool) {}
    virtual void        PA2VA(uint64_t, uint64_t &, bool) {}
    virtual void        PA2VA(MemInfo &, VirAddr &, bool) {}
    virtual MC_MEM_TYPE GetMemType() {
        return MC_MEM_INVALID;
    }
    virtual MC_VENDOR_ID GetVendorId() {
        return MC_VENDOR_INVALID;
    }
    virtual uint32_t GetNumOfMemSubsys() {
        return 0;
    }
    virtual uint32_t GetNumOfMcInsts() {
        return 0;
    }
    virtual uint32_t GetNumOfAvailMcInsts() {
        return 0;
    }
    virtual uint32_t GetMaskOfMcInsts() {
        return 0;
    }
    virtual uint32_t GetNumOfMcChannelsPerInst() {
        return 0;
    }
    virtual uint32_t GetMaskOfMcChannelsPerInst() {
        return 0;
    }
    virtual uint64_t GetTotalMemSize() {
        return 0;
    }
    virtual Mc *GetMcInst(uint32_t) {
        return nullptr;
    }
    virtual bool SetEcc(bool ecc_on, bool hw = false) {
        return false;
    }
    virtual bool GetEcc(void) {
        return false;
    }
    virtual std::vector<DmemAddrInfo> &GetBaseAddrOfMem() {
        return m_addr_info;
    }
    virtual Mc *GetFirstAvalMcInMemSubsys(uint32_t) {
        return nullptr;
    }
    virtual bool GetAvalMcInMemSubsys(uint32_t, std::vector<uint64_t> &) {
        return false;
    }
    virtual Mdf *GetMdf(uint32_t) {
        return nullptr;
    }
    virtual bool GetMdfIndexFromEdfAddr(uint64_t, uint64_t &) {
        return false;
    }
    virtual MC_MEM_CAPACITY GetChannelDensity(void) {
        return MC_MEM_CAPACITY_INVALID;
    }

    std::shared_ptr<IMcTest> GetTest() {
        return test_;
    }

 protected:
    std::shared_ptr<IMcTest>        test_;
    std::shared_ptr<spdlog::logger> logger_;

 protected:
    const Dtu &               m_dtu;
    std::shared_ptr<Hpd>      m_hpd;
    std::vector<DmemAddrInfo> m_addr_info;

    bool inited_ = false;
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_MC_MC_MGR_H_
