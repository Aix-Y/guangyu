/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_MC_MC_RAS_H_
#define HARDWARE_INCLUDE_MC_MC_RAS_H_
#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace mc {
typedef enum {
    MC_ERR_CNTR_FLUSH = 0,  // flush error CNTR to external register == Disable + Enable
    MC_ERR_CNTR_ENABLE,
    MC_ERR_CNTR_DISABLE,
} MC_ERR_CNTR;

typedef enum {
    OKAY   = 0x0,
    EXOKAY = 0x1,
    SLVERR = 0x2,
    DECERR = 0x3,
} RasRespForceVal;

typedef enum {
    EDF_PAR_INT       = 1UL << 0,
    SRAM_PAR_INT      = 1UL << 1,
    HBM_CA_PAR_INT    = 1UL << 2,
    HBM_WDATA_PAR_INT = 1UL << 3,
    HBM_RDATA_PAR_INT = 1UL << 4,
    HBM_CECC_ERR_INT  = 1UL << 5,
    HBM_UECC_ERR_INT  = 1UL << 6,
    ALL_INT           = ~0U,
} McInterrupt;

enum SramParityInjectType { ErrorInParityBits = 0, ErrorInDataBits = 1 };

class McRasCfg : public efvf::hardware::RasCfg {
 public:
    // imu iram/dram/databuf
    uint32_t sram_parity_gen_en : 1;
    uint32_t sram_parity_check_en : 1;
    uint32_t iram_fetch_parity_err_int_en : 1;
    uint32_t iram_load_parity_err_check_en : 1;
    uint32_t dram_fetch_parity_err_int_en : 1;
    uint32_t dram_load_parity_err_check_en : 1;

    // mc top csr
    uint32_t top_csr_ecf_err_int_en : 1;
    uint32_t top_csr_ecf_wdata_par_chk_en : 1;
    uint32_t top_csr_ecf_rdata_par_gen_en : 1;

    // mc imu outbound read parity check
    uint32_t imu_outbound_rd_par_chk : 1;

    // cadence controller & gddr6
    uint32_t denali_wr_data_parity_check_en : 1;
    uint32_t denali_rd_data_parity_gen_en : 1;
    uint32_t ecc_en : 1;
    uint32_t edc_en : 1;
    uint32_t : 18;

    McRasCfg() {
        sram_parity_gen_en             = 0;
        sram_parity_check_en           = 0;
        iram_fetch_parity_err_int_en   = 0;
        iram_load_parity_err_check_en  = 0;
        dram_fetch_parity_err_int_en   = 0;
        dram_load_parity_err_check_en  = 0;
        top_csr_ecf_err_int_en         = 0;
        top_csr_ecf_wdata_par_chk_en   = 0;
        top_csr_ecf_rdata_par_gen_en   = 0;
        imu_outbound_rd_par_chk        = 0;
        denali_wr_data_parity_check_en = 0;
        denali_rd_data_parity_gen_en   = 0;
        ecc_en                         = 0;
        edc_en                         = 0;
    }
};

class McRasErrInj : public efvf::hardware::RasErrInj {
 public:
    uint32_t sram_parity_err_inj : 1;
    uint32_t sram_parity_err_inj_sel_data : 1;
    uint32_t top_csr_ecf_rdata_par_inj : 1;
    uint32_t denali_rd_data_parity_inj : 1;
    uint32_t cecc_inj : 1;
    uint32_t uecc_inj : 1;
    uint32_t edc_inj : 1;
    uint32_t aer_inj : 1;
    uint32_t der_inj : 1;
    uint32_t csr_parity_inj : 1;
    uint32_t axi1_read_data_sram_uecc_inj : 1;
    uint32_t axi1_read_data_sram_cecc_inj : 1;
    uint32_t rmw_rdata_sram_uecc_inj : 1;
    uint32_t rmw_rdata_sram_cecc_inj : 1;
    uint32_t mta_acq_mem_sram_inj : 1;
    uint32_t mt_arb_a_data_sram_inj : 1;
    uint32_t mt_arb_e_data_sram_inj : 1;
    uint32_t mt_arb_w_data_sram_inj : 1;
    uint32_t axi1_write_data_sram_uecc_inj : 1;
    uint32_t axi1_write_data_sram_cecc_inj : 1;
    uint32_t axi1_read_reorder_sram_inj : 1;
    uint32_t xmc_read_reorder_sram_uecc_inj : 1;
    uint32_t xmc_read_reorder_sram_cecc_inj : 1;
    uint32_t : 9;
    uint32_t sram_parity_err_inj_num;
    uint32_t ecc_inj_chn;
    uint32_t aer_inj_chn;
    uint32_t aer_inj_type;
    uint32_t der_inj_chn;
    uint32_t der_inj_type;
    uint32_t csr_parity_inj_chn;
    uint32_t sram_err_inj_pc;

    McRasErrInj() {
        sram_parity_err_inj            = 0;
        sram_parity_err_inj_sel_data   = 0;
        top_csr_ecf_rdata_par_inj      = 0;
        denali_rd_data_parity_inj      = 0;
        cecc_inj                       = 0;
        uecc_inj                       = 0;
        edc_inj                        = 0;
        aer_inj                        = 0;
        der_inj                        = 0;
        csr_parity_inj                 = 0;
        axi1_read_data_sram_uecc_inj   = 0;
        axi1_read_data_sram_cecc_inj   = 0;
        rmw_rdata_sram_uecc_inj        = 0;
        rmw_rdata_sram_cecc_inj        = 0;
        mta_acq_mem_sram_inj           = 0;
        mt_arb_a_data_sram_inj         = 0;
        mt_arb_e_data_sram_inj         = 0;
        mt_arb_w_data_sram_inj         = 0;
        axi1_write_data_sram_uecc_inj  = 0;
        axi1_write_data_sram_cecc_inj  = 0;
        axi1_read_reorder_sram_inj     = 0;
        xmc_read_reorder_sram_uecc_inj = 0;
        xmc_read_reorder_sram_cecc_inj = 0;
        sram_parity_err_inj_num        = 0;
        ecc_inj_chn                    = 0;
        aer_inj_chn                    = 0;
        aer_inj_type                   = 0;
        der_inj_chn                    = 0;
        der_inj_type                   = 0;
        csr_parity_inj_chn             = 0;
        sram_err_inj_pc                = 0;
    }
};

class McRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t test_mem_rd_err_flag : 1;
    uint32_t iram_parity_err_flag : 1;
    uint32_t iram_load_parity_error : 1;
    uint32_t dram_parity_err_flag : 1;
    uint32_t dram_load_parity_error : 1;
    uint32_t top_csr_ecf_wr_par_err_flag : 1;
    uint32_t denali_wr_data_parity_err_flag : 1;
    uint32_t c_ecc : 1;
    uint32_t multi_c_ecc : 1;
    uint32_t u_ecc : 1;
    uint32_t multi_u_ecc : 1;
    uint32_t ecc_wb_drop : 1;
    uint32_t c_ecc_in_scrub : 1;
    uint32_t rd_edc_err : 1;
    uint32_t wr_edc_err : 1;
    uint32_t rd_edc_retry_err : 1;
    uint32_t wr_edc_retry_err : 1;
    uint32_t imu_outbound_rd_parity_err : 1;

    uint32_t : 14;
    uint32_t iram_parity_error_addr;
    uint32_t dram_parity_error_addr;
    uint32_t top_csr_ecf_wr_par_err_awusr;
    uint32_t top_csr_ecf_wr_par_err_awaddr;
    uint32_t top_csr_ecf_wr_par_err_wdata;
    uint64_t c_ecc_addr;
    uint64_t c_ecc_data;
    uint64_t c_ecc_id;
    uint64_t c_ecc_synd;
    uint64_t u_ecc_addr;
    uint64_t u_ecc_data;
    uint64_t u_ecc_id;
    uint64_t u_ecc_synd;
    uint64_t rd_edc_err_addr;
    uint64_t wr_edc_err_addr;
    uint64_t rd_edc_retry_err_addr;
    uint64_t wr_edc_retry_err_addr;

    McRasErrStat() {
        test_mem_rd_err_flag           = 0;
        iram_parity_err_flag           = 0;
        iram_load_parity_error         = 0;
        dram_parity_err_flag           = 0;
        dram_load_parity_error         = 0;
        top_csr_ecf_wr_par_err_flag    = 0;
        denali_wr_data_parity_err_flag = 0;
        c_ecc                          = 0;
        multi_c_ecc                    = 0;
        u_ecc                          = 0;
        multi_u_ecc                    = 0;
        ecc_wb_drop                    = 0;
        c_ecc_in_scrub                 = 0;
        rd_edc_err                     = 0;
        wr_edc_err                     = 0;
        rd_edc_retry_err               = 0;
        wr_edc_retry_err               = 0;
        iram_parity_error_addr         = 0;
        dram_parity_error_addr         = 0;
        top_csr_ecf_wr_par_err_awusr   = 0;
        top_csr_ecf_wr_par_err_awaddr  = 0;
        top_csr_ecf_wr_par_err_wdata   = 0;
        c_ecc_addr                     = 0;
        c_ecc_data                     = 0;
        c_ecc_id                       = 0;
        c_ecc_synd                     = 0;
        u_ecc_addr                     = 0;
        u_ecc_data                     = 0;
        u_ecc_id                       = 0;
        u_ecc_synd                     = 0;
        rd_edc_err_addr                = 0;
        wr_edc_err_addr                = 0;
        rd_edc_retry_err_addr          = 0;
        wr_edc_retry_err_addr          = 0;
    }
};

class McIntrptCfg : public efvf::hardware::IntrptCfg {};

class McRas : public efvf::hardware::IRas {};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MC_MC_RAS_H_
