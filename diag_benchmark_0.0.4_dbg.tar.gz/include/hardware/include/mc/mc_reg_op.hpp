/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MC_MC_REG_OP_HPP_
#define HARDWARE_INCLUDE_MC_MC_REG_OP_HPP_

#define __addrx32(_addr)                                             \
    \
({                                                                   \
        uint64_t __addrx64_v = (_addr);                              \
        uint32_t __addrx32_v = (uint32_t)(__addrx64_v & 0xFFFFFFFF); \
        assert((__addrx64_v) == (__addrx32_v));                      \
        assert((0U) != (__addrx32_v));                               \
        assert((~0U) != (__addrx32_v));                              \
        (__addrx32_v);                                               \
    \
})

#define __reg_f_g(_val, _reg, _f)       \
    \
({                                      \
        _reg##_u u_reg = {.val = _val}; \
        (u_reg.f._f);                   \
    \
})

#define __reg_f_s(_val, _reg, _f, _fv)  \
    \
({                                      \
        _reg##_u u_reg = {.val = _val}; \
        u_reg.f._f = (_fv);             \
        (u_reg.val);                    \
    \
})

#define __regr32f(_reg, _f, _addr) \
    \
(__reg_f_g(__regr32(_addr), _reg, _f)\
)

#define __regw32f(_reg, _f, _addr, _fv) \
    \
(__regw32(_addr, __reg_f_s(__regr32(_addr), _reg, _f, (_fv)))\
)

#define __regr32(_addr) (dtu_->RegRead(__addrx32(_addr)))
#define __regw32(_addr, _val) (dtu_->RegWrite(__addrx32(_addr), (_val)))
#define __reg_base(_ip, _id, _sub) (this->RegBase(__reg_tag((_id), (_sub), _ip)))
#define __reg_tag(_id, _sub, _ip) (#_ip + std::to_string(_id) + std::to_string(_sub))
#define __reg_o(_reg) (_reg##_OFFSET)

// macro common wrapper
#define regr32(_addr) (__regr32((_addr)))
#define regw32(_addr, _val) (__regw32((_addr), (_val)))
#define regr32f(_reg, _f, _addr) (__regr32f(_reg, _f, (_addr)))
#define regw32f(_reg, _f, _addr, _fv) (__regw32f(_reg, _f, (_addr), (_fv)))

#endif  // HARDWARE_INCLUDE_MC_MC_REG_OP_HPP_
