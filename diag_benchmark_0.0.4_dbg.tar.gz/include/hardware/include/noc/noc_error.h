/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_NOC_NOC_ERROR_H_
#define HARDWARE_INCLUDE_NOC_NOC_ERROR_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace noc {

typedef struct {
    std::string              logger_name;
    std::vector<std::string> fields;
    std::vector<std::string> val;
} NOC_Err_Info;

class NocErr : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocErr(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocErr() {}

    virtual bool Dump(NOC_Err_Info &err) = 0;
    virtual bool Clear()                 = 0;
    virtual bool IsErrValid(void);
    std::string  get_name() {
        return name_;
    }
    std::string get_alias() {
        return alias_;
    }

 protected:
    virtual int TriggerClr() = 0;
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_NOC_NOC_ERROR_H_
