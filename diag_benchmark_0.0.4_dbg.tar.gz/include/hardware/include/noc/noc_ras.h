/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_NOC_NOC_RAS_H_
#define HARDWARE_INCLUDE_NOC_NOC_RAS_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_error.h"

namespace efvf {
namespace hardware {
namespace noc {
class NocRas : public efvf::hardware::IRas {
 protected:
    NocErr *noc_err_;
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_NOC_NOC_RAS_H_
