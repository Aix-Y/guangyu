/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file swr.h
    \brief define sip icache interface lib

    1. define IA access interfaces
    2. define get size interfaces
 */

#ifndef HARDWARE_INCLUDE_SIP_SWR_SWR_H_
#define HARDWARE_INCLUDE_SIP_SWR_SWR_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace swr {
class SipSwr {
 public:
    virtual ~SipSwr() {}
    virtual void ClearWaitData(uint32_t id) = 0;
    virtual void SetWaitData(uint32_t id, uint32_t val) = 0;
    virtual uint32_t GetWaitData(uint32_t id) = 0;
    virtual void ClearCfgData(uint32_t id)    = 0;
    virtual void SetCfgData(uint32_t id, uint32_t val) = 0;
    virtual uint32_t GetCfgData(uint32_t id)     = 0;
    virtual uint32_t GetWaitRegAddr(uint32_t id) = 0;

    virtual uint32_t size() = 0;
};
}  // namespace swr
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_SWR_SWR_H_
