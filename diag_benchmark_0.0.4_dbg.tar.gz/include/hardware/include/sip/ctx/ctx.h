/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file ctx.h
    \brief define sip icache interface lib

    1. define IA access interfaces
    2. define get size interfaces
 */

#ifndef HARDWARE_INCLUDE_SIP_CTX_CTX_H_
#define HARDWARE_INCLUDE_SIP_CTX_CTX_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace ctx {
struct CtxConfig {
 public:
    CtxConfig() = default;
    explicit CtxConfig(uint32_t n_mds) : mds(n_mds, 0x0) {}
    explicit CtxConfig(const std::vector<uint32_t> &mds) : mds(mds) {}
    uint32_t                                        mode_cfg = 0x15070FC0;
    // remove from libra
    uint32_t              iid          = 0x0;
    uint32_t              trpba        = 0x0;
    uint32_t              intba        = 0x0;
    uint32_t              launch       = 0x0;
    uint32_t              imem_base_lo = 0x0;
    uint32_t              imem_base_hi = 0x0;
    std::vector<uint32_t> mds;
    // add from libra
    uint32_t ksid = 0x0;
    // add from libra
    uint32_t asid = 0x0;
    // add from libra
    uint32_t knl_slot = 0x0;
    // add from libra
    uint32_t thd_slot_trig     = 0x0;
    uint32_t lchba             = 0x0;
    uint32_t package_id        = 0x0;
    uint32_t process_id        = 0x0;
    uint32_t param             = 0x0;
    uint32_t sub_thd_id        = 0x0;
    uint32_t param_size        = 0x0;
    uint32_t param_addr        = 0x0;
    uint32_t invalid_icache    = 0x0;
    uint32_t disable_vacc_hash = 0x0;
    uint32_t thread_type       = 0x0;
    uint32_t sub_thread_num    = 0x0;
    uint32_t thread_oacc       = 0x0;
};

class SipCtx {
 public:
    virtual ~SipCtx() {}

    virtual uint32_t Size() = 0;

    virtual void Push(const CtxConfig &ctx) = 0;
    virtual void Pop()                      = 0;
    virtual void Clear()                    = 0;

    virtual CtxConfig Nxt() = 0;
    virtual CtxConfig Wrk() = 0;
    virtual CtxConfig Cfg() = 0;

    virtual uint32_t Available() = 0;
    virtual bool     Empty()     = 0;

    // csr
    virtual void SetApp(uint32_t id, uint32_t val) = 0;
    virtual uint32_t GetApp(uint32_t id)                    = 0;
    virtual void SetApps(const std::vector<uint32_t> &apps) = 0;
    virtual std::vector<uint32_t> GetApps()                 = 0;

    virtual void SetMd(uint32_t id, uint32_t val) = 0;
    virtual uint32_t GetMd(uint32_t id)                    = 0;
    virtual void SetMds(const std::vector<uint32_t> &apps) = 0;
    virtual std::vector<uint32_t> GetMds()                 = 0;

    virtual uint32_t GetPc() = 0;
};
}  // namespace ctx
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_CTX_CTX_H_
