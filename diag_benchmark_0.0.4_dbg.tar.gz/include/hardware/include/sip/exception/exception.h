/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SIP_EXCEPTION_EXCEPTION_H_
#define HARDWARE_INCLUDE_SIP_EXCEPTION_EXCEPTION_H_
#include <cstdint>
#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace exception {
struct SipLoopSts {
    uint32_t sts       = 0;
    uint32_t lsp       = 0;
    uint32_t lep       = 0;
    uint32_t loop2_cnt = 0;
};

class SipException {
 public:
    virtual ~SipException() {}

    virtual bool HasException(uint32_t id = 0) = 0;
    virtual bool IsException(uint32_t mask = 0, uint32_t id = 0) = 0;
    virtual bool HasExceptionTh(uint32_t id = 0) = 0;
    virtual bool IsExceptionTh(uint32_t mask = 0, uint32_t id = 0) = 0;
    virtual void SetExceptionTrap(uint32_t mask = 0xffff'ffffu, uint32_t id = 0) = 0;
    virtual void ResetExceptionTrap(uint32_t mask = 0xffff'ffffu, uint32_t id = 0) = 0;
    virtual uint32_t GetExceptionTrap(uint32_t id = 0) = 0;
    virtual uint32_t GetExceptionMask(uint32_t id = 0) = 0;
    virtual void ResetExceptionMask(uint32_t id = 0) = 0;
    virtual uint32_t GetExceptionPc(uint32_t id = 0) = 0;
    virtual uint32_t GetExceptionSts(uint32_t id = 0) = 0;
    virtual void ResetExceptionSts(uint32_t mask = 0xffff'ffffu, uint32_t id = 0) = 0;
    virtual uint32_t GetExceptionStsTh(uint32_t id = 0) = 0;
    virtual void ResetExceptionStsTh(uint32_t mask = 0xffff'ffffu, uint32_t id = 0) = 0;
    virtual uint32_t GetAuxPc(uint32_t id = 0) = 0;
    virtual void QueryExcpLoopSts(SipLoopSts *loop_sts, uint32_t id = 0) = 0;
    virtual void ExceptionInit(uint32_t id = 0) = 0;
    virtual void ExceptionReset(uint32_t id = 0) = 0;
    virtual uint32_t GetIntrSts(uint32_t id = 0) = 0;
    virtual void IntrSet(uint32_t intr, uint32_t id = 0) = 0;
    virtual uint32_t GetIntrSet(uint32_t id = 0) = 0;
    virtual void ClearIntrSet(uint32_t intr, uint32_t id = 0) = 0;
    // add from libra
    virtual bool HasRasRepException(uint32_t id = 0) {}
    virtual bool IsRasRepException(uint32_t mask = 0, uint32_t id = 0) {}
    virtual void SetRasRepExceptionTrap(uint32_t mask = 0xffff'ffffu, uint32_t id = 0) {}
    virtual void ResetRasRepExceptionTrap(uint32_t mask = 0xffff'ffffu, uint32_t id = 0) {}
    virtual uint32_t GetRasRepExceptionTrap(uint32_t id = 0) {
        return 0;
    }
    virtual uint32_t GetRasRepExceptionSts(uint32_t id = 0) {
        return 0;
    }
    virtual void ResetRasRepExceptionSts(uint32_t mask = 0xffff'ffffu, uint32_t slot_id = 0) {}
};
}  // namespace exception
}  // namespace sip
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SIP_EXCEPTION_EXCEPTION_H_
