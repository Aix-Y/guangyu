/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file cth.h
    \brief define sip customized trace handler interface lib
 */

#ifndef HARDWARE_INCLUDE_SIP_CTH_CTH_H_
#define HARDWARE_INCLUDE_SIP_CTH_CTH_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace cth {

const uint64_t TIMEOUTMS_10S = (10 * 1000);
class SipCth {
 public:
    SipCth() = default;
    virtual ~SipCth() {}
    virtual uint32_t GetMsgData(uint32_t thd_slot_id = 0) = 0;
    virtual void SetMsgData(uint32_t msg_data, uint32_t thd_slot_id = 0) = 0;
    virtual uint32_t GetMsgIdx(uint32_t thd_slot_id = 0) = 0;
    virtual void SetMsgIdx(uint32_t msg_idx, uint32_t thd_slot_id = 0) = 0;
    virtual uint32_t GetMsgDst(uint32_t thd_slot_id = 0) = 0;
    virtual void SetMsgDst(uint32_t msg_dst, uint32_t thd_slot_id = 0) = 0;
    virtual uint32_t GetMsgCnt(uint32_t thd_slot_id = 0) = 0;
    virtual void SetMsgCnt(uint32_t msg_cnt, uint32_t thd_slot_id = 0) = 0;
    virtual uint32_t GetMsgType(uint32_t thd_slot_id = 0) = 0;
    virtual void SetMsgType(uint32_t msg_type, uint32_t thd_slot_id = 0) = 0;
    virtual bool WaitIdle(uint32_t thd_slot_id = 0, uint64_t timeout_ms = TIMEOUTMS_10S) = 0;
    virtual bool IsBusy(uint32_t thd_slot_id = 0) = 0;
    virtual bool IsIdle(uint32_t thd_slot_id = 0) = 0;
    virtual void Trigger(uint32_t thd_slot_id = 0) = 0;
    virtual bool SendMsg(uint32_t msg_dst, std::vector<uint32_t> &msg_data,
        uint32_t msg_type = 0, uint32_t msg_idx = 0, uint32_t thd_slot_id = 0,
        uint64_t timeout_ms = TIMEOUTMS_10S) = 0;
};
}  // namespace cth
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_CTH_CTH_H_
