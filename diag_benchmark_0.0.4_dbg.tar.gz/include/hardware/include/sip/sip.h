/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file sip.h
    \brief define sip base lib
 */

#ifndef HARDWARE_INCLUDE_SIP_SIP_H_
#define HARDWARE_INCLUDE_SIP_SIP_H_

#include <cstdint>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "hardware/include/gdte/gdte.h"
#include "hardware/include/hardware.h"
#include "hardware/include/hwsync/hwsync_new.h"
#include "hardware/include/mailbox.h"
#include "hardware/include/sip/cth/cth.h"
#include "hardware/include/sip/ctx/ctx.h"
#include "hardware/include/sip/debugger/debugger.h"
#include "hardware/include/sip/exception/exception.h"
#include "hardware/include/sip/icache/icache.h"
#include "hardware/include/sip/mmu/mmu.h"
#include "hardware/include/sip/ras/bus_ras.h"
#include "hardware/include/sip/ras/int_ctrl.h"
#include "hardware/include/sip/ras/sram_ras.h"
#include "hardware/include/sip/rpc/rpc.h"
#include "hardware/include/sip/sram/sram.h"
#include "hardware/include/sip/swr/swr.h"
#include "hardware/include/sip/xlcg/xlcg.h"
#include "hardware/include/system_adapter.h"

using efvf::hardware::system_adapter::SystemAdapter;
namespace efvf {
namespace hardware {
namespace sip {
// class SipDebugger;
// class SipInterrupt;
// class SipSramRas;
using ras::SipIntCtrl;
using ras::SipSramRas;
using ras::SipBusRas;
using sram::SipSram;
using exception::SipException;
using debugger::SipDebugger;
using mailbox::Mailbox;
using gdte::Gdte;
using icache::Icache;
using swr::SipSwr;
using mmu::SipMmu;
using ctx::CtxConfig;
using ctx::SipCtx;
using rpc::SipRpc;
using xlcg::SipXlcg;
using hwsync::HwSync;
using cth::SipCth;

enum class SipFsmState : uint32_t {
    kHalt = 0,
    kRun  = 1,
    kWait = 2,
    // kDbgm = 3,
    kInvalid = 0xffff'ffffu,
};

struct SipHwSts {
    SipFsmState state      = SipFsmState::kInvalid;
    bool        wait_gsync = false;
    uint32_t    wait_id    = 0;

    bool operator==(const SipHwSts &sts) const {
        if (sts.state != state) {
            return false;
        }
        if (sts.wait_gsync != wait_gsync) {
            return false;
        }
        if (sts.wait_id != wait_id) {
            return false;
        }
        return true;
    }

    std::string ToStr() {
        std::stringstream ss;
        ss << "plc state:";
        if (state == SipFsmState::kHalt) {
            ss << "halt";
        } else if (state == SipFsmState::kWait) {
            ss << "wait";
            if (wait_gsync) {
                ss << ", wait for gsync";
            } else {
                ss << ", wait for mailbox";
            }
            ss << ", wait id " << std::to_string(wait_id);
        } else if (state == SipFsmState::kRun) {
            ss << "run";
        } else {
            ss << "invalid";
        }
        return ss.str();
    }
};

typedef struct _PerfCfg {
    uint8_t start_group_sel    = 0;
    uint8_t stop_group_sel     = 0;
    uint8_t start_user_index0  = 0;
    uint8_t start_user_index1  = 0;
    uint8_t stop_user_index0   = 0;
    uint8_t stop_user_index1   = 0;
    uint8_t event_group_sel    = 0;
    uint8_t event_group_sel_en = 0;
} PerfCfg;

//!
//! @brief sip events
//!
enum SipEventMask {
    EVENT_MASK_ENTER_RUN          = 0x1,
    EVENT_MASK_ENTER_HALT         = 0x2,
    EVENT_MASK_ENTER_BUSY         = 0x4,
    EVENT_MASK_EXIT_BUSY          = 0x8,
    EVENT_MASK_ENTER_WAIT_MAILBOX = 0x10,
    EVENT_MASK_EXIT_WAIT_MAILBOX  = 0x20,
    EVENT_MASK_ENTER_WAIT_GSYNC   = 0x40,
    EVENT_MASK_EXIT_WAIT_GSYNC    = 0x80,
    EVENT_MASK_ALL                = 0xff,
};

struct SipIdInfo {
    uint32_t die_id     = 0;
    uint32_t sic_id     = 0;
    uint32_t cluster_id = 0;
    uint32_t sip_id     = 0;
};

class Sip : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Sip(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~Sip() {}

    /**
     * @brief is sip in vf
     *
     * @return true
     * @return false
     */
    virtual bool IsVf() = 0;

    virtual void SetSipInfo(const SipIdInfo &info) {}

    virtual void SetSipInfo() {}

    virtual bool AllThdIdle(uint32_t xpu_id = 0) {
        return false;
    }

    virtual uint32_t AllThdSts(uint32_t xpu_id = 0) {
        throw;
    }

    /**
     * @brief      Determines if sip state.
     *
     * @param[in]  sts     The sts
     * @param[in]  xpu_id  The xpu identifier
     *
     * @return     True if sip state, False otherwise.
     */
    virtual bool IsSipState(const SipHwSts &sts, uint32_t xpu_id = 0) = 0;

    /**
     * @brief      Determines if sip state.
     *
     * @param[in]  state   The state
     * @param[in]  xpu_id  The xpu identifier
     *
     * @return     True if sip state, False otherwise.
     */
    virtual bool IsSipState(SipFsmState state, uint32_t xpu_id = 0) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  xpu_id  The xpu identifier
     *
     * @return     The sip hardware sts.
     */
    virtual SipHwSts SipState(uint32_t xpu_id = 0) = 0;

    virtual bool IsSipState(
        SipFsmState state, uint32_t thd_slot, uint32_t knl_slot, uint32_t xpu_id = 0) {
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  cfg     The configuration
     * @param[in]  xpu_id  The xpu identifier
     */
    virtual void LaunchConfig(const CtxConfig &cfg, uint32_t xpu_id = 0) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  cfg     The configuration
     * @param[in]  xpu_id  The xpu identifier
     */
    virtual void LchTrig(const CtxConfig &cfg, uint32_t xpu_id = 0) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  xpu_id  The xpu identifier
     */
    virtual void IntTrig(uint32_t xpu_id = 0) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  cfg     The configuration
     * @param[in]  xpu_id  The xpu identifier
     */
    virtual void LaunchImmediately(const CtxConfig &cfg, uint32_t xpu_id = 0) = 0;

    virtual void LaunchImmediately(
        const CtxConfig &cfg, const std::string &code_file, uint32_t xpu_id = 0) = 0;

    /**
     * @brief      Enables the event trace.
     *
     * @param[in]  xpu_id  The xpu identifier
     */
    virtual void EnableEventTrace(uint32_t xpu_id = 0, uint32_t mask = EVENT_MASK_ALL) = 0;

    /**
     * @brief      Disables the event trace.
     *
     * @param[in]  xpu_id  The xpu identifier
     */
    virtual void DisableEventTrace(uint32_t xpu_id = 0, uint32_t mask = EVENT_MASK_ALL) = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual SystemAdapter *lite_sa() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual SystemAdapter *sa() = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  xpu_id  The xpu identifier
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipCtx *ctx(uint32_t ctx_id = 0) = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual Mailbox *mailbox() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual HwSync *l1hwsync() {
        return nullptr;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  xpu_id  The xpu identifier
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipSram *sram(uint32_t xpu_id = 0) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  xpu_id  The xpu identifier
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipDebugger *debugger(uint32_t xpu_id = 0) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  xpu_id  The xpu identifier
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipException *exception(uint32_t xpu_id = 0) = 0;
    // virtual SipInterrupt *interrupt(uint32_t xpu_id) = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipSramRas *sram_ras() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipBusRas *bus_ras() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipIntCtrl *int_ctrl() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual Gdte *sdte() = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  xpu_id  The xpu identifier
     *
     * @return     { description_of_the_return_value }
     */
    virtual Icache *icache(uint32_t xpu_id = 0) = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipSwr *swr() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipMmu *mmu() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipRpc *rpc() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipXlcg *xlcg() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual SipCth *cth() {
        return nullptr;
    }

    /**
     * @brief      Sets the mask.
     *
     * @param[in]  mask  The mask
     */
    virtual void set_mask(const std::bitset<HW_MAX_BIT> &mask) {
        uint32_t pos = parent_->inst_ * this->num_ + this->inst_;
        if (mask[pos] == 0) {
            LOG_DEBUG("disable sip {} - {} {}", pos, parent_->inst_, this->inst_);
            this->disable_ = true;
        }

        if (this->brdcast_) {
            Sip *next = dynamic_cast<Sip *>(this->brdcast_);
            LOG_ASSERT(next != nullptr, "next is nullptr");
            next->set_mask(mask);
        }
    }

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t xpu_size() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t sip_id() const {
        return inst_;
    }

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t die_id() const {
        return parent_->inst_;
    }

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t cluster_id() const {
        return parent_->inst_;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint64_t offset) {
        return Hardware::RegRead(offset);
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     * @param[in]  val     The value
     */
    virtual void RegWrite(uint64_t offset, uint32_t val) {
        Hardware::RegWrite(offset, val);
    }

    virtual uint64_t GetEcfAddr() {
        return ecf_addr_;
    }

    virtual uint32_t GetInsScfOffset() = 0;

#ifdef ENABLE_SIP_FAKE_REG_IO_FEATURE
    /**
     * @brief      Enables the fake register i/o.
     */
    virtual void EnableFakeRegIO() {}

    /**
     * @brief      Disables the fake register i/o.
     */
    virtual void DisableFakeRegIO() {}
#endif

    virtual void ConfigPerf(const PerfCfg &cfg) {}

    virtual uint32_t GetIntInfo(std::string desc) {
        LOG_ASSERT(false, "undefined function!!");
    }
};
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_SIP_H_
