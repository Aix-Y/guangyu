/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SIP_DEBUGGER_DEBUGGER_H_
#define HARDWARE_INCLUDE_SIP_DEBUGGER_DEBUGGER_H_
#include <cstdint>
#include <vector>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace debugger {
class SipDebugger {
 public:
    virtual ~SipDebugger() {}

    /**
     * @brief num of hw break point entries
     *
     * @return uint32_t
     */
    virtual uint32_t bp_size() = 0;

    /**
     * @brief num of watch point entries
     *
     * @return uint32_t
     */
    virtual uint32_t wp_size() = 0;

    /**
     * @brief Set the Dbg Buf object
     *
     * @param bid dbg_buf id
     * @param val
     */
    virtual void SetDbgBuf(uint32_t bid, uint32_t val) = 0;

    /**
     * @brief Get the Dbg Buf object
     *
     * @param bid dbg_buf id
     * @return uint32_t
     */
    virtual uint32_t GetDbgBuf(uint32_t bid) = 0;

    /**
     * @brief set one break point
     *
     * @param bid hw break point id
     * @param addr hw break point addr
     */
    virtual void SetBreakpoint(uint32_t bid, uint32_t addr) = 0;

    /**
     * @brief clear one breakpoint
     * this will disable breakpoint and clear address value in register
     * @param bid
     */
    virtual void ClearBreakpoint(uint32_t bid) = 0;

    /**
     * @brief clear all break point configuration
     *
     */
    virtual void ClearBreakpoint() = 0;

    /**
     * @brief enable one hw point
     * make sure you have configured the hw break point enabled
     * @param bid hw break point id
     */
    virtual void EnableBreakpoint(uint32_t bid) = 0;

    /**
     * @brief disable one hw breakpoint
     * be careful, this disable break point, and address config in register remained
     * @param bid hw break point id
     */
    virtual void DisableBreakpoint(uint32_t bid) = 0;

    /**
     * @brief disable all hw breakpoint
     *
     */
    virtual void DisableBreakpoint() = 0;

    /**
     * @brief Set the Sr Watchpoint object
     *
     * @param wid watch point id
     * @param link_id linked wid
     * @param sr_id scalar register id
     * @param data data for comparison
     */
    virtual void SetSrWatchpoint(
        uint32_t wid, uint32_t link_id, uint32_t sr_id, uint32_t data) = 0;

    /**
     * @brief config a address watchpoint
     *
     * @param wid watch point id
     * @param addr address for comparison
     * @param mask address mask
     */
    virtual void SetAddressWatchpoint(uint32_t wid, uint32_t addr, uint32_t mask) = 0;

    /**
     * @brief config a data watchpoint
     *
     * @param wid watch point id
     * @param data data for comparison
     * @param size size of data for comparison
     */
    virtual void SetDataWatchpoint(uint32_t wid, uint32_t data, uint32_t size) = 0;

    /**
     * @brief config a pair of linked watchpoint
     * make sure this func will comsure TWO watch point entries, managing your watch point
     * resource is all on yourself
     * @param wid watch point id
     * @param link_id link watch point id
     * @param addr address for comparison
     * @param mask address mask
     * @param data data for comparison
     * @param size size of data for comparison
     */
    virtual void SetLinkWatchpoint(uint32_t wid, uint32_t link_id, uint32_t addr,
        uint32_t mask, uint32_t data, uint32_t size) = 0;

    /**
     * @brief clear an watch point configuration
     * since config an watch point need to write DWP_CTLx, DWP_MASKx, DWP_CMPx, so that make
     * sure clear these three registers with reset value, AND remind that Err bit in DWP_CTLx
     * is w1c, so that be carefully choose your value writen to DWP_CTLx. And one more thing,
     * you need to check whether this watch point is a linked watch point (linking or linked)
     * @param wid watch point id
     */
    virtual void ClearWatchpoint(uint32_t wid) = 0;

    /**
     * @brief clear all watch point config
     *
     */
    virtual void ClearWatchpoint() = 0;

    /**
     * @brief send step code cmd with dbg cmd
     * this func will let pipeline execute one instruction package from imem so it is a step
     * cmd in debug process
     */
    virtual void StepCode() = 0;

    /**
     * @brief send step debug cmd with dbg cmd
     * this func will let pipeline execute one debug instruction package from dbg buf registers
     * @param insts
     * @param wr_arf if true, write the sr result to real architecture resources, else write
     * the sr result to DBG_RDATA0
     */
    virtual void StepDcmd(const std::vector<uint32_t> &insts, bool wr_arf) = 0;

    /**
     * @brief send run cmd with dbg cmd
     * this func will make plc return back not non-debug mode and let cpu running from there
     */
    virtual void Run() = 0;

    /**
     * @brief send stop cmd with dbg cmd
     * this func will require cpu to stop running and entering debug mode
     */
    virtual void Stop() = 0;

    /**
     * @brief send resume cmd with dbg cmd
     * this func will make plc return back to wait state when cpu entered dbg_wi from wait
     * state
     */
    virtual void Resume() = 0;

    /**
     * @brief send force cmd with dbg cmd
     * this func will force plc switch to dbg_wi state
     */
    virtual void Force() = 0;

    // read plc status
    /**
     * @brief get plc finite state machine state
     *
     * @return uint32_t
     */
    virtual uint32_t GetPlcFsm() = 0;

    /**
     * @brief check wether plc fsm in debug state
     * this func exists in interface just for convilience in test case
     * @return true indicates plc fsm is in debug state
     * @return false indicates plc fsm is NOT in debug state
     */
    virtual bool IsDbgMode() = 0;

    // read dbg registers
    /**
     * @brief get the value of register DBG_RDATA0
     * this is a read only register
     * @return uint32_t
     */
    virtual uint32_t GetDbgRdata() = 0;

    /**
     * @brief get the value of register DBG_MODE_PC
     * this is a read only register
     * @return uint32_t
     */
    virtual uint32_t GetDbgModePc() = 0;

    /**
     * @brief get the cause of plc entering debug mode
     * this register is w1c
     * @return uint32_t
     */
    virtual uint32_t GetDbgModeCause() = 0;

    /**
     * @brief clear the cause of plc entering debug mode
     * this field in DBG_MODE_STS is w1c, so that write 1 bit to clear one, write all 1 to
     * clear all
     */
    virtual void ClearDebugCause() = 0;

    /**
     * @brief get which comparator matched for hw breakpoint and watchpoint
     * this filed in DBG_MODE_STS is not read only, so clear it when ClearDebugCause
     * @return uint32_t
     */
    virtual uint32_t GetDbgBrkptIdx() = 0;

    /**
     * @brief get data/address watch point hit status for each addr/data watch point
     * thsi field in DBG_MODE_STS is not read only, so clear it when ClearDebugCause
     * @return uint32_t
     */
    virtual uint32_t GetDbgWatchpointStatus() = 0;

    /**
     * @brief make plc into halt status by using step debug cmd
     * this function will write an instruction package into dbg buffer registers, whcih
     * contains an halt instruction in L slot, use this func to make sip exit debugger mode
     */
    virtual void StepDcmdHalt() = 0;

    /**
     * @brief check whether there is configuration fault
     *
     * @param wid watchpoint id
     */
    virtual bool IsWatchpointCmpCfgErr(uint32_t wid) = 0;

    /**
     * @brief clear configuration fault for a watchpoint
     *
     * @param wid watchpoint id
     */
    virtual void ClearWatchpointCmpCfgErr(uint32_t wid) = 0;

    /**
     * @brief Get the Sr value
     *
     * @param id
     * @return uint32_t
     */
    virtual uint32_t GetSr(uint32_t id) = 0;

    /**
     * @brief Set the Sr object
     *
     * @param id
     * @param val
     */
    virtual void SetSr(uint32_t id, uint32_t val) = 0;

    /**
     * @brief Get the Smr object
     *
     * @param id
     * @param vdmem_addr
     * @return std::vector<std::vector<std::vector<uint8_t>>>
     */
    virtual std::vector<std::vector<std::vector<uint8_t>>> GetSmr(uint32_t smr) = 0;

    /**
     * @brief Set the Smr object
     *
     * @param smr
     * @param data
     */
    virtual void SetSmr(
        uint32_t smr, const std::vector<std::vector<std::vector<uint8_t>>> &smr_host) = 0;

    /**
     * @brief Spill Smr Row to Vdmem
     *
     * @param smr
     * @param row
     * @param vdmem_addr
     * @param sr
     */
    virtual void SpillSmr(uint32_t smr, uint32_t row, uint32_t vdmem_addr, uint32_t sr) = 0;

    /**
     * @brief Load Smr Row to Vdmem
     *
     * @param smr
     * @param row
     * @param vdmem_addr
     * @param sr
     */
    virtual void LoadSmr(uint32_t smr, uint32_t row, uint32_t vdmem_addr, uint32_t sr) = 0;

    // add from libra
    /**
     * @brief set one break point
     *
     * @param bid hw break point id
     * @param addr hw break point addr
     * @param pc hw break point pc
     * @param asid hw break point asid
     */
    virtual void SetBreakpoint(uint32_t bid, uint64_t addr, uint32_t pc, uint32_t asid) {}

    /**
     * @brief config a address watchpoint
     *
     * @param wid watch point id
     * @param addr address for comparison
     * @param mask address mask
     * @param asid asid
     */
    virtual void SetAddressWatchpoint(
        uint32_t wid, uint64_t addr, uint32_t mask, uint32_t asid) {}

    /**
     * @brief send step code cmd with dbg cmd
     * this func will let pipeline execute one instruction package from imem so it is a step
     * cmd in debug process
     * @param thd_slot_sel thread slot bit select
     */
    virtual void StepCode(uint32_t thd_slot_sel) {}

    /**
     * @brief send step debug cmd with dbg cmd
     * this func will let pipeline execute one debug instruction package from dbg buf registers
     * @param thd_slot_sel thread slot bit select
     * @param insts
     * @param wr_arf if true, write the sr result to real architecture resources, else write
     * the sr result to DBG_RDATA0 and DBG_RDATA1
     */
    virtual void StepDcmd(
        uint32_t thd_slot_sel, const std::vector<uint32_t> &insts, bool wr_arf) {}

    /**
     * @brief send stop cmd with dbg cmd
     * this func will require cpu to stop running and entering debug mode
     * @param thd_slot_sel thread slot bit select
     */
    virtual void Stop(uint32_t thd_slot_sel) {}

    /**
     * @brief send resume cmd with dbg cmd
     * @param thd_slot_sel thread slot bit select
     * this func will make plc return back to wait state when cpu entered dbg mode from wait
     * state
     */
    virtual void Resume(uint32_t thd_slot_sel) {}

    /**
     * @brief send force cmd with dbg cmd
     * this func will force plc switch to dbg mode and run state
     * @param thd_slot_sel thread slot bit select
     */
    virtual void Force(uint32_t thd_slot_sel) {}

    /**
     * @brief send halt cmd with dbg cmd
     * this func will make plc switch to dbg mode and halt state
     * @param thd_slot_sel thread slot bit select
     */
    virtual void StepHalt(uint32_t thd_slot_sel) {}

    // read plc status
    /**
     * @brief get plc finite state machine state
     * @param thd_slot_id thread slot id
     * @return uint32_t
     */
    virtual uint32_t GetPlcFsm(uint32_t thd_slot_id) {}

    /**
     * @brief check wether plc fsm in debug state
     * this func exists in interface just for convilience in test case
     * @param thd_slot_id thread slot id
     * @return true indicates plc fsm is in debug state
     * @return false indicates plc fsm is NOT in debug state
     */
    virtual bool IsDbgMode(uint32_t thd_slot_id) {}

    // read dbg registers
    /**
     * @brief get the value of register DBG_RDATA0
     * this is a read only register
     * @param did data index
     * @return uint32_t
     */
    virtual uint32_t GetDbgRdata(uint32_t did) {}

    /**
     * @brief get the value of register DBG_MODE_PC
     * this is a read only register
     * @param thd_slot_id thread slot id
     * @return uint32_t
     */
    virtual uint32_t GetDbgModePc(uint32_t thd_slot_id) {}

    /**
     * @brief get the cause of plc entering debug mode
     * this register is w1c
     * @param thd_slot_id thread slot id
     * @return uint32_t
     */
    virtual uint32_t GetDbgModeCause(uint32_t thd_slot_id) {}

    /**
     * @brief clear the cause of plc entering debug mode
     * this field in DBG_MODE_STS is w1c, so that write 1 bit to clear one, write all 1 to
     * clear all
     * @param thd_slot_id thread slot id
     */
    virtual void ClearDebugCause(uint32_t thd_slot_id) {}

    /**
     * @brief get which comparator matched for hw breakpoint and watchpoint
     * this filed in DBG_MODE_STS is not read only, so clear it when ClearDebugCause
     * @param thd_slot_id thread slot id
     * @return uint32_t
     */
    virtual uint32_t GetDbgBrkptIdx(uint32_t thd_slot_id) {}

    /**
     * @brief get data/address watch point hit status for each addr/data watch point
     * thsi field in DBG_MODE_STS is not read only, so clear it when ClearDebugCause
     * @param thd_slot_id thread slot id
     * @return uint32_t
     */
    virtual uint32_t GetDbgWatchpointStatus(uint32_t thd_slot_id) {}
};
}  // namespace debugger
}  // namespace sip
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_SIP_DEBUGGER_DEBUGGER_H_
