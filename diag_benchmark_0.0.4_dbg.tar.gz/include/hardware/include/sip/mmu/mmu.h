/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file sram_ras.h
    \brief define sip sram ras interface lib

    1. define IA access interfaces
    2. define get size interfaces
 */

#ifndef HARDWARE_INCLUDE_SIP_MMU_MMU_H_
#define HARDWARE_INCLUDE_SIP_MMU_MMU_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace mmu {

struct MmuConfig {
    // uint64_t fixed_va_base;
    uint64_t pa_base         = 0x0u;
    uint64_t size            = 0x0u;
    uint64_t arcache         = 0x0u;
    uint64_t awcache         = 0x0u;
    uint64_t hit_ratio       = 0x0u;
    uint64_t cache_priority0 = 0x0u;
    uint64_t cache_priority1 = 0x0u;
    uint64_t hw_pf           = 0x0u;
    uint64_t l2sector        = 0x0u;
    uint64_t valid           = 0x0u;
};

class SipMmu {
 public:
    SipMmu() = default;
    virtual ~SipMmu() {}
    virtual void SetMmu(uint32_t entry, const MmuConfig &mmu_cfg) = 0;
    virtual MmuConfig GetMmu(uint32_t entry) = 0;
    virtual void EnableMmu(uint32_t entry)   = 0;
    virtual void EnableMmu()                 = 0;
    virtual void DisableMmu(uint32_t entry)  = 0;
    virtual void DisableMmu()                = 0;
};
}  // namespace mmu
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_MMU_MMU_H_
