/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file sram.h
    \brief define sip sram interface lib

    1. define IA access interfaces
    2. define get size interfaces
 */

#ifndef HARDWARE_INCLUDE_SIP_RPC_RPC_H_
#define HARDWARE_INCLUDE_SIP_RPC_RPC_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {

namespace rpc {

union MallocRequest {
    struct MallocRequestData {
        uint64_t size : 32;
        uint64_t : 24;
        uint64_t tag : 4;
        uint64_t type : 4;

        MallocRequestData() : size(0), tag(0), type(0) {}
    } reg;

    uint64_t val;

    MallocRequest() : val(0) {}
};

union MallocResponse {
    struct MallocResponseData {
        uint64_t address : 48;
        uint64_t : 8;
        uint64_t tag : 4;
        uint64_t type : 4;

        MallocResponseData() : address(0), tag(0), type(0) {}
    } reg;

    uint64_t val;

    MallocResponse() : val(0) {}
};

union FreeRequest {
    struct FreeRequestData {
        uint64_t address : 48;
        uint64_t : 8;
        uint64_t tag : 4;
        uint64_t type : 4;

        FreeRequestData() : address(0), tag(0), type(0) {}
    } reg;

    uint64_t val;

    FreeRequest() : val(0) {}
};

class SipRpc {
 public:
    SipRpc() = default;
    virtual ~SipRpc() {}
    // send
    virtual uint64_t GetSendMsg(uint32_t ctx) = 0;
    virtual void SetSendMsg(uint64_t msg, uint32_t ctx) = 0;
    virtual uint32_t GetSendDst(uint32_t ctx) = 0;
    virtual void SetSendDst(uint32_t dst, uint32_t ctx) = 0;
    virtual bool GetSendCfg(uint32_t ctx) = 0;
    // rcv
    virtual uint32_t GetRpcSts(uint32_t ctx) = 0;
    virtual void PopRcvMsg(uint32_t ctx)     = 0;
    virtual uint64_t GetRcvMsg(uint32_t ctx) = 0;
    virtual void SetRcvMsg(uint64_t msg, uint32_t ctx) = 0;
};
}  // namespace rpc
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_RPC_RPC_H_
