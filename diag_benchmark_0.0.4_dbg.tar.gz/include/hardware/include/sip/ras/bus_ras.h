/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file sram_ras.h
    \brief define sip sram ras interface lib

    1. define IA access interfaces
    2. define get size interfaces
 */

#ifndef HARDWARE_INCLUDE_SIP_RAS_BUS_RAS_H_
#define HARDWARE_INCLUDE_SIP_RAS_BUS_RAS_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace ras {
enum class FabricType : uint32_t {
    kCf = 0,
    kDf = 1,
};

enum class IoType : uint32_t {
    kRd = 0,
    kWr = 1,
};

enum class AxiType : uint32_t {
    kSlave  = 0,
    kMaster = 1,
};

enum class ErrInjType : uint32_t {
    kData   = 0,
    kParity = 1,
};

class SipBusRas {
 public:
    SipBusRas() = default;
    virtual ~SipBusRas() {}

    virtual void BusRasInit()  = 0;
    virtual void BusRasReset() = 0;

    virtual void EnableRespCheck(FabricType fabric, AxiType port, IoType rw) = 0;
    virtual void EnableRespCheck() = 0;

    virtual void DisableRespCheck(FabricType fabric, AxiType port, IoType rw) = 0;
    virtual void DisableRespCheck() = 0;

    virtual void EnableParityCheck(FabricType fabric, AxiType port, IoType rw) = 0;
    virtual void EnableParityCheck() = 0;

    virtual void DisableParityCheck(FabricType fabric, AxiType port, IoType rw) = 0;
    virtual void DisableParityCheck() = 0;

    virtual void EnableParityGen(FabricType fabric, AxiType port, IoType rw) = 0;
    virtual void EnableParityGen() = 0;

    virtual void DisableParityGen(FabricType fabric, AxiType port, IoType rw) = 0;
    virtual void DisableParityGen() = 0;

    virtual void EnableParityInj(FabricType fabric, AxiType port, IoType rw, uint32_t cnt = 1,
        ErrInjType inj = ErrInjType::kParity) = 0;
    virtual void DisableParityInj(FabricType fabric, AxiType port, IoType rw) = 0;
    virtual void DisableParityInj() = 0;
};
}  // namespace ras
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_RAS_BUS_RAS_H_
