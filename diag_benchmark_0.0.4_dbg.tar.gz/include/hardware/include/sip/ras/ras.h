/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SIP_RAS_RAS_H_
#define HARDWARE_INCLUDE_SIP_RAS_RAS_H_

#include <vector>

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace ras {
struct SipRasCfg : public RasCfg {
    bool vdram_check = true;
    bool sdram_check = true;
    bool iram_check  = true;
    bool varam_check = true;
    bool ncbuf_check = true;
    bool ldq_check   = true;
    bool stq_check   = true;
    // add from libra
    bool sr_tar_ram_check  = true;
    bool iv_smr_ram_check  = true;
    bool s3_inst_ram_check = true;
    bool l0iram_check      = true;

    // sram parity control
    uint32_t sram_par_gen_en   = 1;
    uint32_t sram_par_check_en = 0;
    // sram ecc control
    uint32_t sram_ecc_gen_en   = 1;
    uint32_t sram_ecc_check_en = 0;

    // df ecc control
    uint32_t df_ecc_gen_en   = 1;
    uint32_t df_ecc_check_en = 0;

    bool df0_mst_check = false;
    bool df0_slv_check = false;
    bool df1_mst_check = false;
    bool df1_slv_check = false;
    bool df2_mst_check = false;
    bool df2_slv_check = false;
};

struct SipRasErrInj : public RasErrInj {
    bool vdram_inj = false;
    bool sdram_inj = false;
    bool iram_inj  = false;
    bool varam_inj = false;
    bool ncbuf_inj = false;
    bool ldq_inj   = false;
    bool stq_inj   = false;
    // add from libra
    bool sr_tar_ram_inj  = false;
    bool iv_smr_ram_inj  = false;
    bool s3_inst_ram_inj = false;
    bool l0iram_inj      = false;

    uint32_t sram_par_err_inj = 0;
    uint32_t sram_par_sel     = 0;
    uint32_t sram_par_err_cnt = 0;

    uint32_t sram_ecc_err_inj = 0;
    uint32_t sram_ecc_sel     = 0;
    uint32_t sram_ecc_err_cnt = 0;

    uint32_t df_ecc_err_inj         = 0;
    uint32_t df_ecc_inj_en          = 0;
    uint32_t df_ecc_force_trigger   = 0;
    uint32_t df_ecc_err_cnt_clr     = 0;
    uint32_t df_ecc_inj_err_cnt_clr = 0;
    uint32_t df_ecc_err_sel         = 0;
    uint32_t df_ecc_err_inj_cnt     = 0;

    bool df0_mst_inj = false;
    bool df0_slv_inj = false;
    bool df1_mst_inj = false;
    bool df1_slv_inj = false;
    bool df2_mst_inj = false;
    bool df2_slv_inj = false;
};

struct SipRasErrStat : public RasErrStat {
    std::vector<bool> vdram_err;
    std::vector<bool> sdram_err;
    std::vector<bool> iram_err;
    std::vector<bool> varam_err;
    std::vector<bool> innerram_err;
    // add from libra
    std::vector<bool> l1ctrl_ram_err;
    std::vector<bool> l1data_ram_err;
    std::vector<bool> sr_tar_ram_err;
    std::vector<bool> iv_smr_ram_err;
    std::vector<bool> s3_inst_ram_err;
};
}  // namespace ras
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_RAS_RAS_H_
