/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SIP_RAS_INT_CTRL_H_
#define HARDWARE_INCLUDE_SIP_RAS_INT_CTRL_H_

#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace sip {
namespace ras {
enum class RingType : uint32_t {
    kPf = 0,
    kVf = 1,
};

enum class IntHandlerType : uint32_t {
    kSp   = 0,
    kPcie = 1,
};

enum class IntType : uint32_t {
    kRas = 0,
    kErr = 1,
};

enum class SaType : uint32_t {
    kCoreLiteSa = 0,
    kSa         = 1,
};

class SipIntCtrl {
 public:
    SipIntCtrl() = default;
    virtual ~SipIntCtrl() {}

    virtual void Init()  = 0;
    virtual void Reset() = 0;

    virtual void SetCoreSaIntHandler(
        uint32_t group, IntHandlerType handler, uint32_t ring_id) = 0;
    virtual void SetCoreSaIrqData(uint32_t group, uint32_t xpu_id, IntType int_type,
        uint32_t userdata, uint8_t cause_id) = 0;

    virtual void SetSaIntHandler(uint32_t group, IntHandlerType handler, uint32_t ring_id) = 0;
    virtual void SetSaIrqData(
        uint32_t group, uint32_t channel, uint32_t userdata, uint8_t cause_id) = 0;
};
}  // namespace ras
}  // namespace sip
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SIP_RAS_INT_CTRL_H_
