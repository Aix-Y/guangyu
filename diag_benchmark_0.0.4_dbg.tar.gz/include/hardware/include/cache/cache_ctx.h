/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_CACHE_CACHE_CTX_H_
#define HARDWARE_INCLUDE_CACHE_CACHE_CTX_H_

#include <map>
#include <string>
#include <vector>

namespace efvf {
namespace hardware {
namespace cache {

/************************* [Cache Type Context] Begin *************************/
typedef enum _CACHE_TYPE {
    CACHE_TYPE_INVALID = 0,
    CACHE_TYPE_L2C,
    CACHE_TYPE_LLC,
} CACHE_TYPE;

const std::map<CACHE_TYPE, std::string> CacheTypeStrInfo{
    {CACHE_TYPE_L2C, "Level-2 Cache"}, {CACHE_TYPE_LLC, "Last Level Cache"}};

typedef enum _AXI_CACHE_TYPE {
    AXI_CACHE_TYPE_INVALID = 0,
    DF_SLV_AWCACHE,
    DF_SLV_ARCACHE,
    DF_MST_AWCACHE,
    DF_MST_ARCACHE,
    CF_SLV_AWCACHE,
    CF_SLV_ARCACHE,
    CF_MST_AWCACHE,
    CF_MST_ARCACHE
} AXI_CACHE_TYPE;
/************************* [Cache Type Context] End *************************/

/************************* [Cache Attribute Context] Begin *************************/
typedef enum _CACHE_UPDATE {
    CACHE_UPDATE_INVALID = 0,
    CACHE_UPDATE_WT,  // Write Through
    CACHE_UPDATE_WB   // Write Back
} CACHE_UPDATE;

typedef enum _CACHE_ALLOC {
    CACHE_ALLOC_INVALID = 0,
    CACHE_ALLOC_NA,
    CACHE_ALLOC_RA,
    CACHE_ALLOC_WA,
    CACHE_ALLOC_RWA,
    CACHE_ALLOC_RNA,  // rd no alloc
    CACHE_ALLOC_WNA,  // wr no alloc
    // CACHE_ALLOC_FORCE_NC  // force non-cacheable
} CACHE_ALLOC;

typedef enum _CACHE_MEM_TYPE {
    CACHE_MEM_TYPE_INVALID = 0,
    CACHE_MEM_TYPE_Dev_NB,     // Device Non-Bufferable
    CACHE_MEM_TYPE_Dev_B,      // Device Bufferable
    CACHE_MEM_TYPE_Nor_NC_NB,  // Normal Non-Cacheable Non-Bufferable
    CACHE_MEM_TYPE_Nor_NC_B,   // Normal Non-Cacheable Bufferable
    CACHE_MEM_TYPE_NC,         // Non-Cacheable
    CACHE_MEM_TYPE_WT_NA,      // Write-Through No-Allocate
    CACHE_MEM_TYPE_WT_RA,      // Write-Through Read-Allocate
    CACHE_MEM_TYPE_WT_WA,      // Write-Through Write-Allocate
    CACHE_MEM_TYPE_WT_RWA,     // Write-Through Read&Write-Allocate
    CACHE_MEM_TYPE_WB_NA,      // Write-Back No-Allocate
    CACHE_MEM_TYPE_WB_RA,      // Write-Back Read-Allocate
    CACHE_MEM_TYPE_WB_WA,      // Write-Back Write-Allocate
    CACHE_MEM_TYPE_WB_RWA      // Write-Back Read&Write-Allocate
} CACHE_MEM_TYPE;

typedef CACHE_MEM_TYPE CACHE_ATTRIBUTE;

typedef struct _CacheAttrib {
    struct {
        bool         en          = false;
        CACHE_UPDATE value       = CACHE_UPDATE_INVALID;
        bool         wt_to_wb_en = false;
    } update;

    struct {
        bool        en    = false;
        CACHE_ALLOC value = CACHE_ALLOC_INVALID;
    } alloc;

    struct {
        bool            en           = false;
        CACHE_ATTRIBUTE value        = CACHE_MEM_TYPE_INVALID;
        bool            for_nc_en    = false;
        CACHE_ATTRIBUTE for_nc_value = CACHE_MEM_TYPE_INVALID;
    } attrib;
} CacheAttrib;

typedef struct _CacheAttribCfg {
    CacheAttrib arcache;
    CacheAttrib awcache;
} CacheAttribCfg;

// clang-format off
const std::map<std::string, CACHE_ATTRIBUTE> CacheAttribStrTypeMap = {
    {"nc", CACHE_MEM_TYPE_NC},
    {"wt_na", CACHE_MEM_TYPE_WT_NA},
    {"wt_ra", CACHE_MEM_TYPE_WT_RA},
    {"wt_wa", CACHE_MEM_TYPE_WT_WA},
    {"wt_rwa", CACHE_MEM_TYPE_WT_RWA},
    {"wb_na", CACHE_MEM_TYPE_WB_NA},
    {"wb_ra", CACHE_MEM_TYPE_WB_RA},
    {"wb_wa", CACHE_MEM_TYPE_WB_WA},
    {"wb_rwa", CACHE_MEM_TYPE_WB_RWA}
};

const std::map<CACHE_ATTRIBUTE, std::string> CacheAttribTypeStrMap = {
    {CACHE_MEM_TYPE_NC, "nc"},
    {CACHE_MEM_TYPE_WT_NA, "wt_na"},
    {CACHE_MEM_TYPE_WT_RA, "wt_ra"},
    {CACHE_MEM_TYPE_WT_WA, "wt_wa"},
    {CACHE_MEM_TYPE_WT_RWA, "wt_rwa"},
    {CACHE_MEM_TYPE_WB_NA, "wb_na"},
    {CACHE_MEM_TYPE_WB_RA, "wb_ra"},
    {CACHE_MEM_TYPE_WB_WA, "wb_wa"},
    {CACHE_MEM_TYPE_WB_RWA, "wb_rwa"}
};
// clang-format on
/************************* [Cache Attribute Context] End *************************/

/************************* [Cache Prefetch Context] Begin *************************/
typedef struct _CachePrefetch {
    bool     close        = false;
    bool     close_for_nc = false;
    uint32_t size         = 0x1;  // cache line num
    uint32_t depth        = 0x0;
    // bool     flush_en            = false;
    // bool     history_clean_en    = false;
    // bool     cmd_output_close_en = false;
    // uint32_t max_ost             = 0x0;
} CachePrefetch;

typedef struct _CachePrefetchCfg {
    CachePrefetch rd_prft;
    CachePrefetch wr_prft;
    bool          flush            = false;
    bool          clean_history    = false;
    bool          close_cmd_output = false;
    uint32_t      max_ost          = 0x0;
} CachePrefetchCfg;
/************************* [Cache Prefetch Context] End *************************/

/************************* [Cache Replace Priority Context] Begin *************************/
typedef enum _CACHE_PRIOR {
    CACHE_PRIOR_INVALID = 0,
    CACHE_PRIOR_LOW,
    CACHE_PRIOR_STREAM,  // Low
    CACHE_PRIOR_MID,
    CACHE_PRIOR_NORMAL,  // Mid
    CACHE_PRIOR_HIGH,
    CACHE_PRIOR_RESIDENCY  // High
} CACHE_PRIOR;

typedef struct _CachePriority {
    bool        ovr_for_nc_en     = false;
    CACHE_PRIOR ovr_for_nc_value  = CACHE_PRIOR_INVALID;
    bool        ovr_for_all_en    = false;
    CACHE_PRIOR ovr_for_all_value = CACHE_PRIOR_INVALID;
} CachePriority;

typedef struct _CachePriorCfg {
    CachePriority rd_prior;
    CachePriority wr_prior;
    bool          set_prior_max_way  = false;
    uint32_t      high_prior_max_way = 0x0;
    uint32_t      mid_prior_max_way  = 0x0;
} CachePriorCfg;
/************************* [Cache Replace Priority Context] End *************************/

/************************* [Cache Maintenance Context] Begin *************************/
typedef enum _CACHE_MTN_TYPE {
    CACHE_MTN_TYPE_INVALID = 0,
    CACHE_MTN_TYPE_CLEAN_ALL,
    CACHE_MTN_TYPE_CLEAN_BY_ADDR,
    CACHE_MTN_TYPE_INVALIDATE_ALL,
    CACHE_MTN_TYPE_INVALIDATE_BY_ADDR,
    CACHE_MTN_TYPE_FLUSH_ALL,
    CACHE_MTN_TYPE_FLUSH_BY_ADDR
} CACHE_MTN_TYPE;

typedef struct _CacheMtnCfg {
    bool           mtn_en                 = false;
    CACHE_MTN_TYPE mtn_type               = CACHE_MTN_TYPE_INVALID;
    uint64_t       mtn_addr               = 0x0;
    uint64_t       mtn_size               = 0x0;
    bool           mtn_ntf_en             = false;
    uint32_t       mtn_ntf_data           = 0;
    uint32_t       mtn_ntf_addr           = 0;
    bool           mtn_ntf_force_close_en = false;
    bool           mtn_timeout_en         = false;
    uint32_t       mtn_timeout            = 0;
    bool           cache_num_per_vf_en    = false;
    uint32_t       cache_num_per_vf       = 0;
    bool           mtn_force_close        = false;
    bool           mtn_force_close_for_nc = false;
} CacheMtnCfg;
/************************* [Cache Maintenance Context] End *************************/

/************************* [Cache Arid Context] Begin *************************/
typedef enum _ARID_GEN_MODE {
    ARID_GEN_MODE_INVALID = 0,
    ARID_GEN_MODE_INCREASE_1,
    ARID_GEN_MODE_DECREASE_1,
    ARID_GEN_MODE_CONSTANT
} ARID_GEN_MODE;
/************************* [Cache Arid Context] End *************************/

/************************* [Bypass Context] Begin *************************/
typedef enum _BYPASS_MODE {
    BYPASS_MODE_INVALID = 0,
    BYPASS_MODE_ON,
    BYPASS_MODE_OFF
} BYPASS_MODE;
/************************* [Bypass Context] End *************************/

/************************* [BC Hash Context] Begin *************************/
typedef enum _BC_HASH_MODE {
    BC_HASH_MODE_INVALID = 0,
    BC_HASH_MODE_ON,
    BC_HASH_MODE_OFF
} BC_HASH_MODE;

typedef struct _BcHashAddrCfg {
    uint32_t bc_hash_cfg_0;
    uint32_t bc_hash_cfg_1;
    uint32_t bc_hash_cfg_2;
    uint32_t bc_hash_cfg_3;
    uint32_t bc_hash_cfg_4;
    uint32_t bc_hash_cfg_5;
    uint32_t bc_hash_cfg_6;
    uint32_t bc_hash_cfg_7;
    uint32_t bc_hash_cfg_8;
} BcHashAddrCfg;
/************************* [BC Hash Context] End *************************/

/************************* [Clock Gating Context] Begin *************************/
typedef enum _CLOCK_GATING_MODE {
    CG_MODE_INVALID = 0,
    CG_MODE_FORCE_ON,
    CG_MODE_FORCE_OFF,
    CG_MODE_DYNAMIC
} CLOCK_GATING_MODE;

typedef struct _ClockGatingCfg {
    struct {
        bool              ctrl = false;
        CLOCK_GATING_MODE mode = CG_MODE_INVALID;
    } ipu, opu, dpw, dpr, prft, mtn, bccore, bcdmem;
} ClockGatingCfg;
/************************* [Clock Gating Context] End *************************/

/************************* [Profiler Info] Begin *************************/
typedef struct _CacheProfilerInfo {
    uint32_t rd_hit_cnt          = 0;
    uint32_t wr_hit_cnt          = 0;
    uint32_t rd_miss_cnt         = 0;
    uint32_t wr_miss_cnt         = 0;
    uint32_t rd_cnt              = 0;
    uint32_t wr_cnt              = 0;
    uint32_t rd_hit_book_cnt     = 0;
    uint32_t wr_hit_book_cnt     = 0;
    uint32_t rd_prf_cnt          = 0;
    uint32_t wr_prf_cnt          = 0;
    uint32_t rd_prf_drop_cnt     = 0;
    uint32_t wr_prf_drop_cnt     = 0;
    uint32_t rd_prf_mtn_drop_cnt = 0;
    uint32_t wr_prf_mtn_drop_cnt = 0;
} CacheProfilerInfo;

typedef std::vector<CacheProfilerInfo> CacheProfilerInfoList;
/************************* [Profiler Info] End *************************/

}  // namespace cache
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CACHE_CACHE_CTX_H_
