
/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_CVA_CVA_H_
#define HARDWARE_INCLUDE_CVA_CVA_H_

#include <memory>
#include <string>

#include "framework/include/mem.h"
#include "hardware/include/hardware.h"
#include "hardware/include/ih.h"
#include "hardware/include/mailbox.h"
#include "hardware/include/mdma/mdma.h"
#include "hardware/include/system_adapter.h"

// using efvf::framework::mem::Mem;
using efvf::hardware::ih::Ih;
using efvf::hardware::mailbox::Mailbox;
using efvf::hardware::mdma::Mdma;
using efvf::hardware::system_adapter::SystemAdapter;

namespace efvf {
namespace hardware {
namespace cva {

#define MAX_CVA_NUM (1)
#define MAX_EFC_INST (2)

#define CVA_DBG_SHOW_FUNC LOG_DEBUG("{}", __func__)

enum CVA_MODE { CVA_MODE_REG = 0, CVA_MODE_FW, CVA_MODE_TOOL, CVA_MODE_KMD, CVA_MODE_MAX };

enum EFC_MODE {
    EFC_MODE_NORMAL = 0,
    EFC_MODE_ONCE   = 1,
};

enum EFC_IMG_FMT {
    EFC_IMG_FMT_U8 = 0,
    EFC_IMG_FMT_U16,
    EFC_IMG_FMT_U32,
    EFC_IMG_FMT_RESERVED,
};

enum EFC_METHOD {
    EFC_METHOD_NONE = 0,
    EFC_METHOD_SIMPLE,
};

typedef struct EfcCmdCfg {
    uint32_t vmh_int_flag;
    uint32_t context_id;
    uint32_t golden_crc;
    uint32_t golden_size;
    bool     cbf_cache_en;
    bool     profile_en;
    bool     trace_en;
    bool     mbx_mask_en;

    uint32_t efc_inst;
    uint32_t efc_mode;
    uint16_t img_width;
    uint16_t img_height;
    // input image line stride, must be 128 bytes align, stride >= width
    uint16_t src_img_stride;
    //  efc output binary data line stride, 128 bytes align, >= width
    uint16_t binary_stride;
    bool     binary_online;
    uint32_t binarize_thr0;
    uint32_t binarize_thr1;
    uint64_t crc_buf_addr;
    uint64_t input_buf_addr;
    uint64_t output_header_addr;
    uint64_t output_countours_addr;
    uint64_t output_binary_addr;
    EfcCmdCfg()
        : vmh_int_flag(0),
          context_id(0),
          golden_crc(0),
          golden_size(0),
          cbf_cache_en(false),
          profile_en(false),
          trace_en(false),
          mbx_mask_en(false),
          efc_inst(0),
          efc_mode(0),
          img_width(0),
          img_height(0),
          src_img_stride(1),
          binary_stride(1),
          binary_online(true),
          binarize_thr0(0),
          binarize_thr1(0),
          crc_buf_addr(0),
          input_buf_addr(0),
          output_header_addr(0),
          output_countours_addr(0),
          output_binary_addr(0) {}
} EfcCmdCfg;

typedef struct EfcStatus {
    uint32_t efc_inst_num;
    struct cva_status {
        bool efc_shadow_busy;
        bool efc_idle;
        bool efc_done;
        bool efc_start;
    } status[2];

    EfcStatus() : efc_inst_num(2) {
        for (uint32_t i = 0; i < 2; i++) {
            status[i].efc_shadow_busy = false;
            status[i].efc_idle        = true;
            status[i].efc_done        = false;
            status[i].efc_start       = false;
        }
    }
} EfcStatus;

class Cva : public Hardware {
 public:
    Cva() : Hardware() {}
    explicit Cva(std::shared_ptr<spdlog::logger> logger);
    virtual ~Cva();

 public:
    virtual CVA_MODE GetRunMode() const = 0;
    virtual void SetRunMode(CVA_MODE mode = CVA_MODE_REG) = 0;

    virtual bool SetCvaBlr() = 0;

    virtual bool RegAccessTest()  = 0;
    virtual bool SramAccessTest() = 0;
    //
    virtual uint32_t GetFwVersion(uint32_t &major, uint32_t &minor) = 0;
    virtual uint32_t GetFwHeartbeat()             = 0;
    virtual uint32_t GetFwStatus()                = 0;
    virtual bool FwSubmitData(EfcCmdCfg &efc_cfg) = 0;
    virtual bool FwGetResp(uint64_t &haddr, uint64_t &caddr) = 0;

    virtual Mailbox *      GetEfcMailbox() = 0;
    virtual Mailbox *      GetVamMailbox() = 0;
    virtual Ih *           GetMih()        = 0;
    virtual Mdma *         GetMdma()       = 0;
    virtual SystemAdapter *GetSa()         = 0;

    virtual bool RunEfcCmdReg(EfcCmdCfg &cfg)      = 0;
    virtual bool CleanEfcCmdCfg(uint32_t efc_inst) = 0;
    virtual bool CheckEfcStatus(uint32_t efc_inst) = 0;
    virtual bool GetCvaStatus(EfcStatus &st, bool en_log = true) = 0;
    virtual uint32_t GetEfcOutputContoursNum(uint32_t efc_inst) = 0;

    virtual bool EnableProfiling(bool profiling_en = false) = 0;
    virtual bool EnableEventTrace(uint32_t efc_inst, bool trace_en = false) = 0;

    virtual bool HandleToolReq(const std::string &req) = 0;
    virtual bool HandleToolReq(const std::string &req, uint64_t &in_out) = 0;
    //
    virtual void SetSmemParityInject(uint32_t status) = 0;
    virtual bool FindSmemParity(uint32_t intfx)       = 0;
    virtual void CleanSmemParity()                    = 0;
    //
    virtual void SetEfcSramParityInject(uint32_t efc_inst, uint32_t status) = 0;
    virtual bool FindEfcSramParity(uint32_t efc_inst)  = 0;
    virtual void CleanEfcSramParity(uint32_t efc_inst) = 0;
    //
    virtual bool MemConstFill(uint64_t buf_addr, uint64_t buf_size, uint32_t pattern,
        uint64_t off = 0, uint64_t size = 0, int timeout = 1000)                     = 0;
    virtual bool DataCopy(uint64_t src_addr, uint64_t dst_addr, uint64_t size)       = 0;
    virtual uint32_t GetDataCrc(uint64_t src_addr, uint64_t dst_addr, uint64_t size) = 0;

    /**
     * @brief      Gets the eng name.
     *
     * @return     The eng name.
     */
    virtual std::string GetEngName() {
        return "cva";
    }
};

}  // namespace cva
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_CVA_CVA_H_
