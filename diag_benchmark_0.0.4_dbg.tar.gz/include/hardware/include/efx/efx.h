/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_EFX_EFX_H_
#define HARDWARE_INCLUDE_EFX_EFX_H_

#include <memory>
#include <string>
#include <vector>
#include "device/include/dtu.h"
#include "framework/include/log.h"
#include "hardware/efx/esl_fake.h"

using efvf::device::Dtu;

typedef struct efqual_item_struct {
    int         id;
    std::string name;
    std::string q_conf_name;
    std::string v_conf_name;
} efqual_item_t;

typedef struct efqual_sku_desc_struct {
    std::vector<int> q_test_list;
    uint64_t         q_test_mask;
    std::vector<int> v_test_list;
    uint64_t         v_test_mask;
} efqual_sku_desc_t;

namespace efvf {
namespace hardware {
namespace efx {
// O2N: traversal all available elements from 0~n
// N2O: traversal all available elements from n~0
const std::vector<int> O2N = std::vector<int>{-1};
const std::vector<int> N2O = std::vector<int>{-2};
typedef struct smtcmd_cap_struct {
    bool             is_support_parallel_in_dtus;
    bool             is_support_parallel_in_dies;
    std::vector<int> default_dies;
    std::vector<int> default_dtus;
    uint64_t         dies_mask = ~0ul;
    std::string      cmd_stack;
} smtcmd_cap_t;

enum efqual_test_id {
    Thermal_Qualification_Test_Id     = 0,
    EDPP_Qualification_Test_Id       = 1,
    Perf_Qualification_Test_Id        = 2,
    Fan_Calibration_Test_Id           = 3,
    PCI_Express_Qualification_Test_Id = 4,
    PCI_Express_Data_Eye_Metric_Id    = 5,
    PCI_Express_Interrupt_Test_Id     = 6,
    PCI_Express_P2P_Test_Id           = 7,
    ESL_Qualification_Test_Id         = 11,
    Performance_Test_Id               = 20,
    Memory_Qualification_Test_Id      = 30,
    Power_Stress_Test_Id              = 40,
};

class Efx {
 public:
    explicit Efx(const Dtu *dtu);
    virtual ~Efx() {}

    /**
     * @brief      Gets the logger.
     *
     * @return     The logger.
     */
    void SetLogger(std::shared_ptr<spdlog::logger> logger) {
        logger_ = logger;
    }

    /**
     * @brief      Get the capability about cmd.
     *
     * @return     The operation result.
     */
    virtual bool GetSmtCmdCap(smtcmd_cap_t *cap) {
        if (cap) {
            FillDefaultCap(cap);
            return true;
        } else {
            return false;
        }
    }

    /**
     * @brief      Return prefix of reg name.
     *
     * @param[in]  die_id    The die id
     *
     * @return     { reg name prefix }
     */
    virtual std::string GetRegNamePrefix(uint32_t die_id) {
        return "";
    }

    virtual std::string FormatRegName(
        std::string reg_name, uint32_t die_id, bool is_dieid_important, bool *is_conflict) {
        return reg_name;
    }

    /**
     * @brief      Shows the memory help.
     *
     * @param[in]  type  The type
     */
    virtual void ShowMemoryHelp(const std::string &type) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  type       The type
     * @param[in]  cmd_param  The command parameter
     * @param[in]  cmd_line   The command line
     */
    virtual int AccessMemory(const std::string &type,
        const std::vector<std::string> &cmd_param, const ParameterList &cmd_line) {
        return -1;
    }

    /**
     * @brief      Get EFQual test items description
     *
     * @param[in]  items_desc The efqual items description
     */
    virtual int GetEfqualItems(efqual_sku_desc_t *items_desc) {
        return -1;
    }

    /**
     * @brief      Get efsmt command white list
     *
     * @return     True if succeeded
     */
    virtual bool GetSmtCmdWhiteList(std::vector<std::string> &white_list);

    /**
     * @brief      GetFakeEsl
     *
     * @return     shared ptr
     */
    virtual std::shared_ptr<EslFake> GetEslFake(int die_id, std::vector<std::string> &params) {
        return nullptr;
    }

    /**
     * @brief      Dump Sip
     *
     * @return    0 if success
     */
    virtual int DumpSip(
        uint32_t die_idx, uint32_t sic_idx, uint32_t sip_idx, uint32_t dump_range = 0x40) {
        LOG_ASSERT(false, "Not implemented!!!");
        return -1;
    }

    /**
     * @brief      SetDiagsRunningFlag
     *
     * @return     True if success
     */
    virtual uint32_t GetDiagsFlag() {
        return 0;
    }

    /**
     * @brief      SetDiagsRunningFlag
     *
     * @return     True if success
     */
    virtual void SetDiagsFlag() {}

    virtual void ClearDiagsFlag() {}

    virtual void ApplyPcieCDCWorkaround() {}

 protected:
    const Dtu *dtu_;

    std::shared_ptr<spdlog::logger> logger_;

 protected:
    virtual void FillDefaultCap(smtcmd_cap_t *cap) {
        if (cap) {
            cap->is_support_parallel_in_dtus = false;
            cap->is_support_parallel_in_dies = false;
            cap->default_dies                = {0};   // only die 0
            cap->default_dtus                = {0};   // only dtu 0
            cap->dies_mask                   = ~0ul;  // all die support
        }
    }
};

/**
 * @brief      Gets the efx.
 *
 * @param[in]  dtu   The dtu
 *
 * @return     The efx.
 */
extern std::shared_ptr<Efx> GetEfx(const Dtu *dtu);

}  // namespace efx
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_EFX_EFX_H_
