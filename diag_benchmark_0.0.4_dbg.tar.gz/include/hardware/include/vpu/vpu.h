/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_VPU_VPU_H_
#define HARDWARE_INCLUDE_VPU_VPU_H_

#include <memory>
#include <string>
#include <vector>
#include "hardware/include/hardware.h"
#include "hardware/include/ih.h"
#include "hardware/include/mailbox.h"
#include "hardware/include/mdma/mdma.h"
#include "hardware/include/system_adapter.h"
#include "hardware/include/vpp_codec/vpp_codec.h"

using efvf::hardware::codec::Codec;
using efvf::hardware::ih::Ih;
using efvf::hardware::mailbox::Mailbox;
using efvf::hardware::mdma::Mdma;
using efvf::hardware::system_adapter::SystemAdapter;

namespace efvf {
namespace hardware {
namespace vpu {

#undef VPU_DBG_SHOW_FUNC
#define VPU_DBG_SHOW_FUNC LOG_DEBUG("{}", __func__)

class Vpu;

typedef struct EvpCfg {
    uint32_t evp_inst   = 0;
    uint32_t vmh_flag   = 0;
    uint32_t pmc_flag   = 0;
    uint32_t profile_en = 0;
    uint32_t context_id = 0;  // EVP_AXUSER.evp_axuser_context_id
    uint32_t as_id      = 0;
    uint32_t mst_id     = 0;  // EVP_AXUSER.evp_axuser_master_id
    uint32_t pkt_id     = 0;  // EVP_PACKET_INFO.evp_pkt_info
    uint32_t type_id    = 0;  // EVP_TYPE_INFO_PROFILE_EVENT.evp_type_id_frame_start / done
    uint32_t process_id = 0;  // EVP_TASK_INFO0.evp_task_process_id
    // uint32_t golden_crc[3];
    std::vector<uint64_t> golden_crc_vec;

    bool check_output    = false;
    bool cbf_en          = false;
    bool multi_engine_en = false;
    //
    bool     cus_en      = false;
    bool     cds_en      = false;
    bool     bduc_en     = false;
    bool     bddc_en     = false;
    bool     crop_en     = false;
    bool     resize_en   = false;
    bool     padding_en  = false;
    bool     csc_en      = false;
    bool     binary_en   = false;
    bool     slice_en    = false;
    uint32_t padding_idx = 0;
    //
    uint32_t input_fmt          = 0x8;
    uint32_t input_offset_x     = 0;
    uint32_t input_offset_y     = 0;
    uint32_t input_img_width    = 640;
    uint32_t input_img_height   = 480;
    uint32_t output_fmt         = 0x8;
    uint32_t output_offset_x    = 0;
    uint32_t output_offset_y    = 0;
    uint32_t output_img_width   = 640;
    uint32_t output_img_height  = 480;
    uint64_t input_buffer_addr  = 0;
    uint64_t output_buffer_addr = 0;

    // rdma / wdma
    uint32_t input_planar_num  = 0;
    uint32_t output_planar_num = 0;
    //
    uint32_t input_planar_size[4];
    uint32_t input_planar_offset[4];
    uint32_t input_stride_width[4];
    uint32_t input_pixel_width[4];
    uint32_t input_pixel_height[4];
    uint32_t input_bytes_pre_pixel[4];
    //
    uint32_t output_planar_size[4];
    uint32_t output_planar_offset[4];
    uint32_t output_stride_width[4];
    uint32_t output_pixel_width[4];
    uint32_t output_pixel_height[4];
    uint32_t output_bytes_pre_pixel[4];

    // get support output format by input format
    std::vector<uint32_t> ofmt_vec;
    //
    // struct {
    //     uint32_t mode;
    // } ifc_cfg;

    // struct {
    //     uint32_t mode;
    // } ofc_cfg;

    struct {
        uint32_t mode;
        uint16_t in_width;
        uint16_t in_height;
        uint16_t offset_x;
        uint16_t offset_y;
        uint16_t out_width;
        uint16_t out_height;
    } cus_cfg, cds_cfg;

    struct {
        uint32_t mode;
    } bduc_cfg, bddc_cfg;

    struct {
        uint32_t mode;
        uint16_t ch_val[4];
        uint16_t width;
        uint16_t height;
        uint16_t size_up;
        uint16_t size_down;
        uint16_t size_left;
        uint16_t size_right;
    } padding_cfg;

    struct {
        uint32_t mode;
        uint16_t in_width;
        uint16_t in_height;
        uint16_t out_width;
        uint16_t out_height;
        uint32_t h_ratio;
        uint32_t v_ratio;
        uint32_t phase_x;
        uint32_t phase_y;
    } resize_cfg;

    struct {
        uint16_t x;
        uint16_t y;
        uint16_t width;
        uint16_t height;
    } crop_cfg;

    struct {
        uint32_t mode;
        uint16_t width;
        uint16_t height;
        uint16_t y_max;
        uint16_t y_min;
        uint16_t uv_max;
        uint16_t uv_min;
        uint32_t coeff[9];
        uint32_t offset[3];
    } csc_cfg;

    struct {
        uint32_t mode;
        uint32_t th[2];
        uint32_t data[2];
    } binary_cfg;

    struct {
        uint32_t row             = 1;
        uint32_t col             = 1;
        uint32_t slice_w         = 0;  // slice input w
        uint32_t slice_h         = 0;
        uint32_t output_w        = 0;
        uint32_t output_h        = 0;
        uint32_t input_offset_x  = 0;
        uint32_t input_offset_y  = 0;
        uint32_t output_offset_x = 0;
        uint32_t output_offset_y = 0;
    } slice_cfg;

    struct {
        uint16_t width;
        uint16_t height;
    } crc_cfg;

    EvpCfg() {
        memset(&cds_cfg, 0x0, sizeof(cds_cfg));
        memset(&cus_cfg, 0x0, sizeof(cus_cfg));
        memset(&bduc_cfg, 0x0, sizeof(bduc_cfg));
        memset(&bddc_cfg, 0x0, sizeof(bddc_cfg));
        memset(&padding_cfg, 0x0, sizeof(padding_cfg));
        memset(&resize_cfg, 0x0, sizeof(resize_cfg));
        memset(&crop_cfg, 0x0, sizeof(crop_cfg));
        memset(&csc_cfg, 0x0, sizeof(csc_cfg));
        memset(&binary_cfg, 0x0, sizeof(binary_cfg));
        memset(&crc_cfg, 0x0, sizeof(crc_cfg));

        for (uint32_t i = 0; i < 4; i++) {
            input_planar_size[i]     = 0;
            input_planar_offset[i]   = 0;
            input_stride_width[i]    = 0;
            input_pixel_width[i]     = 0;
            input_pixel_height[i]    = 0;
            input_bytes_pre_pixel[i] = 0;
            //
            output_planar_size[i]     = 0;
            output_planar_offset[i]   = 0;
            output_stride_width[i]    = 0;
            output_pixel_width[i]     = 0;
            output_pixel_height[i]    = 0;
            output_bytes_pre_pixel[i] = 0;
        }
    }
} EvpCfg;

class Vpu : public Hardware {
 public:
    Vpu();
    explicit Vpu(std::shared_ptr<spdlog::logger> logger);
    virtual ~Vpu();

    virtual Codec *GetCodec(uint32_t inst) = 0;
    virtual Mdma *         GetMdma()       = 0;
    virtual Ih *           GetMih()        = 0;
    virtual Mailbox *      GetMailbox()    = 0;
    virtual SystemAdapter *GetSa()         = 0;

    virtual void SetOption(const std::string &str_type, uint32_t val) = 0;
    virtual uint32_t GetOption(const std::string &str_type) = 0;

    virtual bool HandleToolReq(const std::string &req, uint64_t &in_out) = 0;

    virtual bool SetSaAgent(uint32_t type, uint32_t axuser, bool en) = 0;
    virtual bool SanityTest(uint32_t type = 0) = 0;
    virtual bool ClockTest(uint32_t type)      = 0;
    virtual bool SetAxuserInfo(
        uint32_t type, uint32_t ctx_id, uint32_t asid, uint32_t mst_id) = 0;
    virtual bool GetShareMemAddr(uint32_t &cf_addr, uint32_t &cf_offset, uint32_t &size) = 0;

    virtual bool EvpBlr(uint32_t inst = 0) = 0;
    virtual bool EvpFillCfg(EvpCfg *cfg)   = 0;
    virtual bool EvpGetOfmt(EvpCfg *cfg)   = 0;
    virtual bool RunEvpPipeline(uint32_t inst, EvpCfg *cfg) = 0;
    //
    virtual uint32_t CheckInterrupt(uint32_t evp_inst = 0) = 0;
    virtual void CleanInterrupt(uint32_t evp_inst = 0) = 0;
    //
    virtual void GetCrcResult(
        std::vector<uint64_t> &crc_val, uint32_t evp_inst = 0, uint32_t type = 1) = 0;
    // DTE OP
    virtual bool MemConstFill(uint64_t buf_addr, uint64_t buf_size, uint32_t pattern,
        uint64_t off = 0, uint64_t size = 0, int timeout = -1)                       = 0;
    virtual bool DataCopy(uint64_t src_addr, uint64_t dst_addr, uint64_t size)       = 0;
    virtual uint32_t GetDataCrc(uint64_t src_addr, uint64_t dst_addr, uint64_t size) = 0;
};

}  // namespace vpu
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_VPU_VPU_H_
