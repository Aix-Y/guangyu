/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_TRACE_H_
#define HARDWARE_INCLUDE_TRACE_H_

#include <map>
#include <memory>
#include <string>
#include <vector>

#include "boost/property_tree/json_parser.hpp"
#include "boost/property_tree/ptree.hpp"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace trace {

class TraceCmd {
 public:
    int         trace_id_ = 0;
    std::string name_     = "unknown";
    TraceCmd *  next_     = nullptr;
};

class TraceStream : public TraceCmd {
 public:
    int get_cluster_id() {
        return cmd_node_.get_child("stream_header").get_child("cluster_id").get_value<int>();
    }
    boost::property_tree::ptree cmd_node_;
};

class TraceSimpleCmd : public TraceCmd {
 public:
    boost::property_tree::ptree cmd_node_;
};

class TraceLoopCmd : public TraceCmd {
 public:
    boost::property_tree::ptree cmd_node1_;
    boost::property_tree::ptree cmd_node2_;
};

class TraceLoopTask : public TraceCmd {
 public:
    std::map<int, TraceLoopCmd *> loop_cmds_map_;
    std::vector<TraceLoopCmd *> loop_cmds_;
    boost::property_tree::ptree cmd_node_;
};

class Trace : public Hardware {
 public:
    explicit Trace(std::shared_ptr<spdlog::logger> logger);
    virtual ~Trace();

    virtual int Play(std::string trace_path) = 0;
    virtual void FillTraceStream(std::string path, std::string pattern);

    std::vector<TraceStream *> trace_streams_;
    std::string                trace_path_;
};

}  // namespace trace
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_TRACE_H_
