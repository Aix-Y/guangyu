/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_RMC_RMC_TEST_H_
#define HARDWARE_INCLUDE_RMC_RMC_TEST_H_

#include <memory>
#include "framework/include/log.h"
#include "hardware/include/rmc/rmc.h"

namespace efvf {
namespace hardware {
namespace rmc {
class IRmcTest {
 public:
    virtual bool TestRmcShift()   = 0;
    virtual bool TestRmcReplace() = 0;

 protected:
    std::shared_ptr<spdlog::logger> logger_;
};

}  // namespace rmc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_INCLUDE_RMC_RMC_TEST_H_
