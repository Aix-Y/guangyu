/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_RMC_RMC_H_
#define HARDWARE_INCLUDE_RMC_RMC_H_

#include <memory>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace rmc {

typedef enum {
    SHIFT,
    REPLACE,
} MapType;

typedef struct _RmcAperParam {
    uint32_t index;
    uint64_t size;
    uint64_t virt_base;
    uint64_t physic_base;
    MapType  map_type;
} RmcAperParam;

class IRmcTest;
class RmClient : public Hardware {
 public:
    RmClient() : Hardware() {}
    explicit RmClient(std::shared_ptr<spdlog::logger> logger);
    virtual ~RmClient() {}

    virtual void AperCfg(const RmcAperParam &param) = 0;

    std::shared_ptr<IRmcTest> GetTest() {
        return test_;
    }

 protected:
    std::shared_ptr<IRmcTest> test_;
};

}  // namespace rmc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_RMC_RMC_H_
