/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_ATOMIC_ASH_MGR_H_
#define HARDWARE_INCLUDE_ATOMIC_ASH_MGR_H_
#include <memory>
#include <vector>
#include "hardware/include/atomic/ash.h"
#include "hardware/include/atomic/atomic_ctx.h"

namespace efvf {
namespace hardware {
namespace atomic {

class AshMgr {
 public:
    AshMgr(const std::shared_ptr<spdlog::logger> &logger, const Dtu &dtu)
        : logger_(logger), dtu_(dtu), mgr_inited_(false) {}
    virtual ~AshMgr() {}

    virtual bool                    Init()                 = 0;
    virtual std::vector<AmoExcpInf> GetException()         = 0;
    virtual void                    ClearIntStat()         = 0;
    virtual void                    OvflowClamp(bool)      = 0;
    virtual void                    PrefetchOverride(bool) = 0;

 protected:
    std::shared_ptr<spdlog::logger> logger_;
    const Dtu &                     dtu_;
    bool                            mgr_inited_;
};

}  // namespace atomic
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_ATOMIC_ASH_MGR_H_
