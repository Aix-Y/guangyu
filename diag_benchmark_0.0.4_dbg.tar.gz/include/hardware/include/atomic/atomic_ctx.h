/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_ATOMIC_ATOMIC_CTX_H_
#define HARDWARE_INCLUDE_ATOMIC_ATOMIC_CTX_H_

#include <string>

namespace efvf {
namespace hardware {
namespace atomic {

enum class AtomOp {
    None,  // non-atomic operation
    vADD,
    vMAX,
    vMAXNUM,
    ADD,
    MAX,
    MAXNUM,
    CAS,
    EXCH,
    AND,
    OR,
    XOR,
    MIN,
    MINNUM,
    INC,
    DEC,
};

enum class AtomDtype {
    NOT_INIT = 0,
    INT8,
    UINT8,
    INT16,
    UINT16,
    INT32,
    UINT32,
    INT64,
    UINT64,
    FP8,
    FP16,
    BF16,
    TF16,
    FP32,
    TF32,
    FP64,
};

enum AshExcpType {
    OverFlow = 0,
    UnderFlow,
    Nan,
};

struct AmoExcpInf {
    AshExcpType excp_type;
    bool        alu_excp;
    int         inst;
};

class AtomAttr {
 public:
    AtomAttr() : op(AtomOp::None), dtype(AtomDtype::NOT_INIT), b_ret(false) {}

    AtomAttr(AtomOp aop, std::string dtype, bool is_return)
        : op(aop), dtype(AtomDtype::NOT_INIT), s_dtype(dtype), b_ret(is_return) {}

    //-----------
    AtomOp      op;
    AtomDtype   dtype;  // data type
    std::string s_dtype;
    bool        b_ret;  // whether return value needed.
};

// #define SINT8  (char)
// #define UINT8  (unsigned short)
// #define SINT16 (signed short)
// #define UINT16 (unsigned short)
// #define SINT32 (signed int)
// #define UINT32 (unsigned int)
// #define SINT64 (signed long long)
// #define UINT64 (unsigned long long)
// #define FP32   (float)
// #define FP64   (double)

// class AtomCtx
// {
// private:
//     /* data */
// public:
//     AtomCtx(std::string atm_op, bool is_ret);
//     ~AtomCtx();
// };

// AtomCtx::AtomCtx(std::string atm_op, bool is_ret) {

// }

// AtomCtx::~AtomCtx() {

// }

}  // namespace atomic
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_ATOMIC_ATOMIC_CTX_H_
