
/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_ATOMIC_ASH_H_
#define HARDWARE_INCLUDE_ATOMIC_ASH_H_
#include <memory>
#include <string>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace atomic {

class Ash : public Hardware {
 public:
    Ash();
    explicit Ash(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}
    virtual ~Ash() {}

 public:
    virtual uint32_t GetDieId()   = 0;
    virtual uint32_t GetInstId()  = 0;
    virtual uint32_t GetInstCnt() = 0;

    //  virtual bool Enable(bool enable) = 0;
    //  virtual void SetOstNum(uint32_t ost) = 0;

    virtual bool HandleToolReq(const std::string &req) = 0;
    virtual bool HandleToolReq(const std::string &req, uint64_t &in_out) = 0;
    virtual bool HandleToolReq(const std::string &req, void *ptr)        = 0;
};

}  // namespace atomic
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_ATOMIC_ASH_H_
