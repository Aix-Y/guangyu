/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_AASP_AASP_H_
#define HARDWARE_INCLUDE_AASP_AASP_H_

#include <map>
#include <memory>
#include <string>
#include <vector>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace aasp {

typedef enum { AASP_PHY_NRZ = 1, AASP_PHY_PAM4 = 2 } AaspPhyMode;
typedef enum {
    AASP_PHY_RATE0 = 0,
    AASP_PHY_RATE1 = 1,
    AASP_PHY_RATE2 = 2,
    AASP_PHY_RATE3 = 3,
} AaspPhyRate;

typedef enum {
    AASP_PHY_RATE_CTRL_28   = 12,
    AASP_PHY_RATE_CTRL_31_5 = 13,
    AASP_PHY_RATE_CTRL_35   = 14,
    AASP_PHY_RATE_CTRL_38_5 = 15,
    AASP_PHY_RATE_CTRL_42   = 16,
    AASP_PHY_RATE_CTRL_45_5 = 17,
    AASP_PHY_RATE_CTRL_50   = 18,
    AASP_PHY_RATE_CTRL_52   = 19,
    AASP_PHY_RATE_CTRL_56   = 20,
} AaspPhyRateCtrl;

typedef enum _AaspLinkWidth {
    AASP_LINK_WIDTH_X1      = 1,
    AASP_LINK_WIDTH_X2      = 2,
    AASP_LINK_WIDTH_X4      = 4,
    AASP_LINK_WIDTH_X8      = 8,
    AASP_LINK_WIDTH_X16     = 16,
    AASP_LINK_WIDTH_INVALID = 0xff,
} AaspLinkWidth;

typedef enum _AaspLinkSpeed {
    AASP_LINK_SPEED_112G_PAM4 = 1,
    AASP_LINK_SPEED_104G_PAM4 = 2,
    AASP_LINK_SPEED_96G_PAM4  = 3,
    AASP_LINK_SPEED_80G_PAM4  = 4,
    AASP_LINK_SPEED_64G_PAM4  = 5,
    AASP_LINK_SPEED_56G_PAM4  = 6,
    AASP_LINK_SPEED_28G_PAM4  = 7,
    AASP_LINK_SPEED_56G_NRZ   = 8,
    AASP_LINK_SPEED_52G_NRZ   = 9,
    AASP_LINK_SPEED_48G_NRZ   = 10,
    AASP_LINK_SPEED_40G_NRZ   = 11,
    AASP_LINK_SPEED_32G_NRZ   = 12,
    AASP_LINK_SPEED_28G_NRZ   = 13,
    AASP_LINK_SPEED_14G_NRZ   = 14,
    AASP_LINK_SPEED_7G_NRZ    = 15,
    AASP_LINK_SPEED_INVALID   = 0xff,
} AaspLinkSpeed;

const std::map<const AaspLinkSpeed, std::string> AASP_LINK_SPEED_TABLE = {
    {AASP_LINK_SPEED_INVALID, "invalid link speed"}, {AASP_LINK_SPEED_112G_PAM4, "112G_PAM4"},
    {AASP_LINK_SPEED_104G_PAM4, "104G_PAM4"}, {AASP_LINK_SPEED_96G_PAM4, "96G_PAM4"},
    {AASP_LINK_SPEED_80G_PAM4, "80G_PAM4"}, {AASP_LINK_SPEED_64G_PAM4, "64G_PAM4"},
    {AASP_LINK_SPEED_56G_PAM4, "56G_PAM4"}, {AASP_LINK_SPEED_28G_PAM4, "28G_PAM4"},
    {AASP_LINK_SPEED_56G_NRZ, "56G_NRZ"}, {AASP_LINK_SPEED_52G_NRZ, "52G_NRZ"},
    {AASP_LINK_SPEED_48G_NRZ, "48G_NRZ"}, {AASP_LINK_SPEED_40G_NRZ, "40G_NRZ"},
    {AASP_LINK_SPEED_32G_NRZ, "32G_NRZ"}, {AASP_LINK_SPEED_28G_NRZ, "28G_NRZ"},
    {AASP_LINK_SPEED_14G_NRZ, "14G_NRZ"}, {AASP_LINK_SPEED_7G_NRZ, "7G_NRZ"},
};

const std::map<const AaspLinkWidth, std::string> AASP_LINK_WIDTH_TABLE = {
    {AASP_LINK_WIDTH_X1, "X1"}, {AASP_LINK_WIDTH_X2, "X2"}, {AASP_LINK_WIDTH_X4, "X4"},
    {AASP_LINK_WIDTH_X8, "X8"}, {AASP_LINK_WIDTH_X16, "X16"},
};

enum {
    // edf r/w
    EDF_MASTER_READ_THROUGHPUT  = 1ULL << 0,
    EDF_MASTER_WRITE_THROUGHPUT = 1ULL << 1,
    EDF_SLAVE_READ_THROUGHPUT   = 1ULL << 2,
    EDF_SLAVE_WRITE_THROUGHPUT  = 1ULL << 3,
    EDF_MASTER_READ_REQUEST     = 1ULL << 4,
    EDF_MASTER_READ_RESPONSE    = 1ULL << 5,
    EDF_MASTER_WRITE_REQUEST    = 1ULL << 6,
    EDF_MASTER_WRITE_RESPONSE   = 1ULL << 7,
    EDF_SLAVE_READ_REQUEST      = 1ULL << 8,
    EDF_SLAVE_READ_RESPONSE     = 1ULL << 9,
    EDF_SLAVE_WRITE_REQUEST     = 1ULL << 10,
    EDF_SLAVE_WRITE_RESPONSE    = 1ULL << 11,
    // ecf r/w
    ECF_MASTER_READ_REQUEST   = 1ULL << 12,
    ECF_MASTER_READ_RESPONSE  = 1ULL << 13,
    ECF_MASTER_WRITE_REQUEST  = 1ULL << 14,
    ECF_MASTER_WRITE_RESPONSE = 1ULL << 15,
    ECF_SLAVE_READ_REQUEST    = 1ULL << 16,
    ECF_SLAVE_READ_RESPONSE   = 1ULL << 17,
    ECF_SLAVE_WRITE_REQUEST   = 1ULL << 18,
    ECF_SLAVE_WRITE_RESPONSE  = 1ULL << 19,
    // core r/w
    CORE_MASTER_READ_REQUEST   = 1ULL << 20,
    CORE_MASTER_READ_RESPONSE  = 1ULL << 21,
    CORE_MASTER_WRITE_REQUEST  = 1ULL << 22,
    CORE_MASTER_WRITE_RESPONSE = 1ULL << 23,
    CORE_SLAVE_READ_REQUEST    = 1ULL << 24,
    CORE_SLAVE_READ_RESPONSE   = 1ULL << 25,
    CORE_SLAVE_WRITE_REQUEST   = 1ULL << 26,
    CORE_SLAVE_WRITE_RESPONSE  = 1ULL << 27,
    // in & out bound r/w latency
    INBOUND_EDF_READ_LATENCY   = 1ULL << (32 + 0),
    INBOUND_EDF_WRITE_LATENCY  = 1ULL << (32 + 1),
    OUTBOUND_EDF_READ_LATENCY  = 1ULL << (32 + 2),
    OUTBOUND_EDF_WRITE_LATENCY = 1ULL << (32 + 3),
};

typedef enum {
    INIT            = 0,
    ALIGN_REQ1_0    = 1,
    ALIGN_REQ1_1    = 2,
    ALIGN_REQ1_2    = 3,
    ALIGN_REQ2_0    = 4,
    ALIGN_REQ2_1    = 5,
    TEST_INIT       = 6,
    L0_OS_2_L0_DATA = 7,
    L0_DATA_2_L0_OS = 8
} LTSSM_STATUS;

// clang-format off
const std::map<uint32_t, const std::string> LtssmStrA = {
    {INIT, "INIT"},
    {ALIGN_REQ1_0, "ALIGN_REQ1_0"},
    {ALIGN_REQ1_1, "ALIGN_REQ1_1"},
    {ALIGN_REQ1_2, "ALIGN_REQ1_2"},
    {ALIGN_REQ2_0, "ALIGN_REQ2_0"},
    {ALIGN_REQ2_1, "ALIGN_REQ2_1"},
    {TEST_INIT, "TEST_INIT"},
    {L0_OS_2_L0_DATA, "L0_OS_2_L0_DATA"},
    {L0_DATA_2_L0_OS, "L0_DATA_2_L0_OS"}
};

typedef enum {
    PRE_RCVRY       = 0x5,
    S_RCVRY_LOCK    = 0xd,
    S_RCVRY_RCVRCFG = 0xf,
    S_RCVRY_IDLE    = 0x10,
    S_L0            = 0x11,
    S_LPBK_ENTRY    = 0x1a,
    S_LPBK_ACTIVE   = 0x1b,
    S_LPBK_EXIT     = 0x1c
} LTSSM_STATUS_B;

const std::map<uint32_t, const std::string> LtssmStrB = {
    {PRE_RCVRY, "PRE_RCVRY"},
    {S_RCVRY_LOCK, "S_RCVRY_LOCK"},
    {S_RCVRY_RCVRCFG, "S_RCVRY_RCVRCFG"},
    {S_RCVRY_IDLE, "S_RCVRY_IDLE"},
    {S_L0,         "S_L0"},
    {S_LPBK_ENTRY, "S_LPBK_ENTRY"},
    {S_LPBK_ACTIVE, "S_LPBK_ACTIVE"},
    {S_LPBK_EXIT, "S_LPBK_EXIT"}
};
// clang-format on
#if 0
typedef enum _Sta0 {
    EDF_MASTER_READ_REQUEST = 0,
    EDF_MASTER_READ_RESPONSE,
    EDF_MASTER_WRITE_REQUEST,
    EDF_MASTER_WRITE_RESPONSE,
    EDF_SLAVE_READ_REQUEST,
    EDF_SLAVE_READ_RESPONSE,
    EDF_SLAVE_WRITE_REQUEST,
    EDF_SLAVE_WRITE_RESPONSE,
    ECF_MASTER_READ_REQUEST,
    ECF_MASTER_READ_RESPONSE,
    ECF_MASTER_WRITE_REQUEST,
    ECF_MASTER_WRITE_RESPONSE,
    ECF_SLAVE_READ_REQUEST,
    ECF_SLAVE_READ_RESPONSE,
    ECF_SLAVE_WRITE_REQUEST,
    ECF_SLAVE_WRITE_RESPONSE,
    CORE_MASTER_READ_REQUEST,
    CORE_MASTER_READ_RESPONSE,
    CORE_MASTER_WRITE_REQUEST,
    CORE_MASTER_WRITE_RESPONSE,
    CORE_SLAVE_READ_REQUEST,
    CORE_SLAVE_READ_RESPONSE,
    CORE_SLAVE_WRITE_REQUEST,
    CORE_SLAVE_WRITE_RESPONSE,
} Sta0;

typedef enum _Sta1 {
    INBOUND_EDF_READ_LATENCY = 0,
    INBOUND_EDF_WRITE_LATENCY,
    OUTBOUND_EDF_READ_LATENCY,
    OUTBOUND_EDF_WRITE_LATENCY,
} Sta1;

typedef enum _Sel {
    EDF_MASTER_READ_REQUEST = 0;
    EDF_MASTER_READ_RESPONSE,
    EDF_MASTER_WRITE_REQUEST,
    EDF_MASTER_WRITE_RESPONSE,
    EDF_SLAVE_READ_REQUEST,
    EDF_SLAVE_READ_RESPONSE,
    EDF_SLAVE_WRITE_REQUEST,
    EDF_SLAVE_WRITE_RESPONSE,
    ECF_MASTER_READ_REQUEST,
    ECF_MASTER_READ_RESPONSE,
    ECF_MASTER_WRITE_REQUEST,
    ECF_MASTER_WRITE_RESPONSE,
    ECF_SLAVE_READ_REQUEST,
    ECF_SLAVE_READ_RESPONSE,
    ECF_SLAVE_WRITE_REQUEST,
    ECF_SLAVE_WRITE_RESPONSE,
    CORE_MASTER_READ_REQUEST,
    CORE_MASTER_READ_RESPONSE,
    CORE_MASTER_WRITE_REQUEST,
    CORE_MASTER_WRITE_RESPONSE,
    CORE_SLAVE_READ_REQUEST,
    CORE_SLAVE_READ_RESPONSE,
    CORE_SLAVE_WRITE_REQUEST,
    CORE_SLAVE_WRITE_RESPONSE,
} Sel;

const std::map<const Sta0, std::string> AASP_STA0_ENABLE = {
    {EDF_MASTER_READ_REQUEST, "EDF_MASTER_READ_REQUEST"},
    {EDF_MASTER_READ_RESPONSE, "EDF_MASTER_READ_RESPONSE"},
    {EDF_MASTER_WRITE_REQUEST, "EDF_MASTER_WRITE_REQUEST"},
    {EDF_MASTER_WRITE_RESPONSE, "EDF_MASTER_WRITE_RESPONSE"},
    {EDF_SLAVE_READ_REQUEST, "EDF_SLAVE_READ_REQUEST"},
    {EDF_SLAVE_READ_RESPONSE, "EDF_SLAVE_READ_RESPONSE"},
    {EDF_SLAVE_WRITE_REQUEST, "EDF_SLAVE_WRITE_REQUEST"},
    {EDF_SLAVE_WRITE_RESPONSE, "EDF_SLAVE_WRITE_RESPONSE"},
    {ECF_MASTER_READ_REQUEST, "ECF_MASTER_READ_REQUEST"},
    {ECF_MASTER_READ_RESPONSE, "ECF_MASTER_READ_RESPONSE"},
    {ECF_MASTER_WRITE_REQUEST, "ECF_MASTER_WRITE_REQUEST"},
    {ECF_MASTER_WRITE_RESPONSE, "ECF_MASTER_WRITE_RESPONSE"},
    {ECF_SLAVE_READ_REQUEST, "ECF_SLAVE_READ_REQUEST"},
    {ECF_SLAVE_READ_RESPONSE, "ECF_SLAVE_READ_RESPONSE"},
    {ECF_SLAVE_WRITE_REQUEST, "ECF_SLAVE_WRITE_REQUEST"},
    {ECF_SLAVE_WRITE_RESPONSE, "ECF_SLAVE_WRITE_RESPONSE"},
    {CORE_MASTER_READ_REQUEST, "CORE_MASTER_READ_REQUEST"},
    {CORE_MASTER_READ_RESPONSE, "CORE_MASTER_READ_RESPONSE"},
    {CORE_MASTER_WRITE_REQUEST, "CORE_MASTER_WRITE_REQUEST"},
    {CORE_MASTER_WRITE_RESPONSE, "CORE_MASTER_WRITE_RESPONSE"},
    {CORE_SLAVE_READ_REQUEST, "CORE_SLAVE_READ_REQUEST"},
    {CORE_SLAVE_READ_RESPONSE, "CORE_SLAVE_READ_RESPONSE"},
    {CORE_SLAVE_WRITE_REQUEST, "CORE_SLAVE_WRITE_REQUEST"},
    {CORE_SLAVE_WRITE_RESPONSE, "CORE_SLAVE_WRITE_RESPONSE"},
};

const std::map<const Sta1, std::string> AASP_STA1_ENABLE = {
    {INBOUND_EDF_READ_LATENCY, "INBOUND_EDF_READ_LATENCY"},
    {INBOUND_EDF_WRITE_LATENCY, "INBOUND_EDF_WRITE_LATENCY"},
    {OUTBOUND_EDF_READ_LATENCY, "OUTBOUND_EDF_READ_LATENCY"},
    {OUTBOUND_EDF_WRITE_LATENCY, "OUTBOUND_EDF_WRITE_LATENCY"},
};
#endif
typedef enum {
    ERROR_INJECT_MATCH_TYPE_LMP = 0,
    ERROR_INJECT_MATCH_TYPE_BUN = 1,
} AaspErrInjMatchType;

typedef union {
    struct {
        uint32_t rev : 8;
        uint32_t right : 8;
        uint32_t center : 8;
        uint32_t left : 8;
    } f;
    uint32_t val;
} LANE_EYE;

typedef union {
    struct {
        uint32_t mid_270 : 8;
        uint32_t mid_180 : 8;
        uint32_t mid_90 : 8;
        uint32_t mid_0 : 8;
    } f;
    uint32_t val;
} LANE_EYE_MID;

typedef union {
    struct {
        uint32_t data_0 : 7;
        uint32_t data_90 : 7;
        uint32_t data_180 : 7;
        uint32_t data_270 : 7;
        uint32_t rev : 4;
    } f;
    uint32_t val;
} PMIX_DATA;

typedef union {
    struct {
        uint32_t offset_0 : 7;
        uint32_t offset_90 : 7;
        uint32_t offset_180 : 7;
        uint32_t offset_270 : 7;
        uint32_t rev : 4;
    } f;
    uint32_t val;
} PMIX_OFFSET;

typedef union {
    struct {
        uint32_t rev : 2;
        uint32_t d270 : 6;
        uint32_t d180 : 6;
        uint32_t d90 : 6;
        uint32_t d0 : 6;
        uint32_t d0_pre : 6;
    } f;
    uint32_t val;
} PMIX_CODE;

typedef union {
    struct {
        uint32_t rev : 8;
        uint32_t err270_offset : 6;
        uint32_t err180_offset : 6;
        uint32_t err90_offset : 6;
        uint32_t err0_offset : 6;
    } f;
    uint32_t val;
} PMIX_ERR_OFFSET;

typedef union {
    struct {
        uint32_t rev : 5;
        uint32_t dac_l : 9;
        uint32_t dac_m : 9;
        uint32_t dac_h : 9;
    } f;
    uint32_t val;
} DAC_CODE;

typedef struct AaspInjEccCrcErr_ {
    uint32_t type;
    bool     bu_ecc;
    bool     bu_crc;
    uint32_t match_num;
    uint32_t bu_num;
    uint32_t bu_interval;
    uint32_t bu_seq_num;
    uint32_t bu_seq_limit;
    uint32_t ecc_dw0_index;
    uint32_t ecc_dw1_index;
    uint32_t ecc_dw2_index;
    uint32_t ecc_dw0_vector;
    uint32_t ecc_dw1_vector;
    uint32_t ecc_dw2_vector;
    uint32_t crc_dw0_index;
    uint32_t crc_dw1_index;
    uint32_t crc_dw2_index;
    uint32_t crc_dw0_vector;
    uint32_t crc_dw1_vector;
    uint32_t crc_dw2_vector;
} AaspInjEccCrcErr;

typedef struct aasp_hw_ptr_ {
    Hardware *mst_al_app_ptr          = nullptr;
    Hardware *mst_al_prot_ptr         = nullptr;
    Hardware *mst_d2d_ctl_ptr         = nullptr;
    Hardware *mst_dl_ptr              = nullptr;
    Hardware *mst_pl_ptr              = nullptr;
    Hardware *mst_tl_ptr              = nullptr;
    Hardware *mst_vdr_ptr             = nullptr;
    Hardware *mst_phy_ptr             = nullptr;
    Hardware *mst_xsr_x_ptr           = nullptr;
    Hardware *mst_d2d_ctl_ptr_c0_core = nullptr;
    Hardware *mst_d2d_ctl_ptr_c1_core = nullptr;
    Hardware *slv_al_app_ptr          = nullptr;
    Hardware *slv_al_prot_ptr         = nullptr;
    Hardware *slv_d2d_ctl_ptr         = nullptr;
    Hardware *slv_dl_ptr              = nullptr;
    Hardware *slv_pl_ptr              = nullptr;
    Hardware *slv_tl_ptr              = nullptr;
    Hardware *slv_vdr_ptr             = nullptr;
    Hardware *slv_phy_ptr             = nullptr;
    Hardware *slv_xsr_x_ptr           = nullptr;
} aasp_hw_ptr;

class Aasp : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    Aasp() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Aasp(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~Aasp() {}

    /**
     * @brief      Sets the initialize configuration.
     *
     * @param      cfg   The new value
     */
    virtual void set_init_cfg(void *cfg);
};

class AaspLib {
 public:
    explicit AaspLib(std::shared_ptr<spdlog::logger> logger, const Dtu *dtu);
    virtual ~AaspLib() {}

    virtual bool          Init()              = 0;
    virtual bool          Deinit()            = 0;
    virtual bool          IsLinkUp()          = 0;
    virtual bool          IsDesignB()         = 0;
    virtual uint32_t      GetDesignBLaneNum() = 0;
    virtual AaspLinkSpeed GetLinkSpeed()      = 0;
    virtual uint32_t      CalLinkSpeed()      = 0;
    virtual AaspLinkWidth GetLinkWidth()      = 0;
    virtual void DumpLtssmTraceBuffDie(std::vector<uint32_t> &buff_vec, uint32_t die_id,
        bool is_mode_b, uint32_t aasp_inst = 0) = 0;
    virtual void SetLinkSpeed(const AaspLinkSpeed &val)               = 0;
    virtual void SetLinkWidth(const AaspLinkWidth &val)               = 0;
    virtual uint32_t GetPipeWidth()                                   = 0;
    virtual bool SetPipeWidth(uint32_t width)                         = 0;
    virtual uint32_t                     GetSupCtxSel()               = 0;
    virtual const std::vector<uint32_t> &GetTestRegs(bool remote_die) = 0;
    // aasp event counter interface
    virtual void ClrEventCntSta(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void EnableEvtCnt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void DisableEvtCnt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void PrintAaspEvtCnt() = 0;
    // interrupt mask interface
    virtual void MaskAllInterrupt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void UnMaskAllInterrupt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void ClearInterStatus() = 0;
    virtual void ShowInterSta(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void PrintInterSta(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void PrintPoisonAndNak(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    // PHY symbal rate
    // 28G      - 12
    // 31.5G    - 13
    // 35G      - 14
    // 38.5G    - 15
    // 42G      - 16
    // 45.5G    - 17
    // 50G      - 18
    // 52G      - 19
    // 56G      - 20
    virtual uint32_t GetSSMTryLinkNum(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual float GetPhyRateCtrl() = 0;

    // 0 - NRZ, 1 - PAM4
    virtual uint32_t GetPhyMode() = 0;

    // NRZ
    // 1: 32bit pipe, 2: 16bit pipe, 3: 8bit pipe
    // PAM4
    // 0: 64bit pipe, 1: 32bit pipe, 2: 16bit pipe, 3: 8bit pipe
    virtual uint32_t GetPhyRate()     = 0;
    virtual float    GetDesignBrate() = 0;
    virtual float    GetDataRate()    = 0;

    virtual bool ErrDetected() = 0;

    virtual bool SetDesignB() = 0;

    virtual Hardware *GetMasterAasp() = 0;

    virtual Hardware *GetSlaveAasp() = 0;

    const Dtu *GetDtu() {
        return m_dtu;
    }

    virtual uint64_t TransferRemoteAddr(const uint64_t addr_in) = 0;
    virtual uint32_t TransferRemoteAddr(const uint32_t addr_in) = 0;

    virtual bool GetAaspNormStatus(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual bool CheckErrorValid(
        uint32_t die_id, bool check_mask = true, uint32_t aasp_inst = 0) = 0;
    virtual void ClearAaspNormStatus(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void ClearAaspErrorStatus(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual uint32_t GetAaspEccErrorCnt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual uint32_t GetAaspCrcErrorCnt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;

    virtual bool GetAaspParityChkEn(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void SetAaspParityChkEn(uint32_t die_id, bool val, uint32_t aasp_inst = 0) = 0;
    virtual bool GetAaspRespCheckEn(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void SetAaspRespCheckEn(uint32_t die_id, bool val, uint32_t aasp_inst = 0) = 0;

    virtual void ClearAaspPhyEcfErrInt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual bool GetAaspPhyEcfErrInt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual bool GetAaspPhyEcfErrInfo(uint32_t die_id, uint32_t aasp_inst = 0) = 0;

    virtual void ClearAaspAppSlvErrInt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual bool GetAaspAppSlvErrInt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual bool GetAaspAppSlvErrInfo(uint32_t die_id, uint32_t aasp_inst = 0) = 0;

    virtual void ClearAaspEventHubWriteInt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual bool GetAaspEventHubWriteInt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual bool GetAaspEventHubWriteInfo(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void BackupAaspEventHubAddr(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void RestoreAaspEventHubAddr(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void SetAaspEventHubAddr(
        uint32_t die_id, uint32_t val, uint32_t aasp_inst = 0) = 0;
    // sta perf interface
    virtual void SetThroughPutStaticEn(uint32_t die_id, uint64_t stat_type_mask,
        uint32_t cd_timer_val, bool enable, uint32_t aasp_inst = 0) = 0;
    virtual float GetThroughPutStatic(uint32_t die_id, uint64_t stat_type_mask,
        uint32_t cd_timer_val, uint32_t edf_clk, uint32_t aasp_inst = 0) = 0;
    virtual void SetLatencyStaticEn(uint32_t die_id, uint64_t stat_type_mask,
        uint32_t latency_mode, bool enable, uint32_t aasp_inst = 0) = 0;
    virtual uint32_t GetLatencyStatiCount(
        uint32_t die_id, uint64_t stat_type_mask, uint32_t aasp_inst = 0) = 0;
    virtual void SetPerfStsEn(
        uint32_t die_id, uint64_t stat_type_mask, bool enable, uint32_t aasp_inst = 0) = 0;
    virtual void PrintAllEventsRes(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual uint32_t GetPerfStsCounter(
        uint32_t die_id, uint64_t stat_type_mask, uint32_t aasp_inst = 0) = 0;
    virtual void InjectEccCrcErr(
        uint32_t die_id, AaspInjEccCrcErr &cfg, uint32_t aasp_inst = 0) = 0;
    virtual uint32_t GetEccThreshold(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual uint32_t GetCrcThreshold(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void SetEccThreshold(uint32_t die_id, uint32_t val, uint32_t aasp_inst = 0) = 0;
    virtual void SetCrcThreshold(uint32_t die_id, uint32_t val, uint32_t aasp_inst = 0) = 0;
    virtual void InjectPlRetrain(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void BackupInterMasks(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void RestoreInterMasks(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void ClearAaspCrcCnt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    virtual void ClearAaspEccCnt(uint32_t die_id, uint32_t aasp_inst = 0) = 0;
    // aasp rx scope
    virtual uint32_t AnaOvrdval00(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdval01(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdval02(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdval03(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdval07(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdval11(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdval14(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdval17(uint32_t die_id, uint32_t lane_id) = 0;

    virtual uint32_t AnaOvrdEn00(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdEn02(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdEn03(uint32_t die_id, uint32_t lane_id) = 0;

    virtual uint32_t GenericConf00(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t GenericConf01(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t GenericConf02(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t GenericConf05(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t GenericConf07(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t GenericConf11(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t GenericConf13(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t GenericConf19(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t GenericConf20(uint32_t die_id, uint32_t lane_id) = 0;

    virtual uint32_t Status00(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t Status14(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t Status15(uint32_t die_id, uint32_t lane_id) = 0;

    virtual uint32_t GetPmixErrOffset(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t SetPmixErrOffset(uint32_t die_id, uint32_t lane_id, uint32_t offset) = 0;
    virtual uint32_t PmixOffsetCodeEn(uint32_t die_id, uint32_t lane_id, bool enable)     = 0;
    virtual uint32_t RawpcsSpareFw1(uint32_t die_id) = 0;
    virtual uint32_t RxCalValsSpare0(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t RxScopeCorrAddr(uint32_t die_id) = 0;

    virtual void GenericConf01(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf02(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf03(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf04(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf05(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf06(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf07(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf17(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf18(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf19(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;

    virtual void GenericConf11EnCdrClkgate(uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void GenericConf00CalStatLdVal(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf00CalStatDataMux(
        uint32_t die_id, uint32_t lane_id, uint32_t value)                                = 0;
    virtual void GenericConf00CalStatStart(uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual void GnenricConf01StatsPttrnCr1a(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf02StatsPttrnMskCr1a(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf05CalStatClkgatePam4En(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual uint32_t GenericConf05StatsQuadSel(uint32_t die_id, uint32_t lane_id) = 0;
    virtual void GenericConf05StatsQuadSel(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf07StatusSc1LdVal(
        uint32_t die_id, uint32_t lane_id, uint32_t value)                              = 0;
    virtual void GenericConf19SsmStart(uint32_t die_id, uint32_t lane_id, bool value)   = 0;
    virtual void GenericConf20AsmSsmSelR(uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual void AnaOvrdval02AnaRxAnaCalDacRangeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdval02AnaRxAnaCalDacVcmI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual uint32_t AnaOvrdval03AnaRxAnaCalDacDecRstNI(uint32_t die_id, uint32_t lane_id) = 0;
    virtual void AnaOvrdval03AnaRxAnaCalDacDecRstNI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual void AnaOvrdval03AnaRxAnaCalDacAddrI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdval03AnaRxAnaCalDacCodeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdval03AnaRxAnaCalDacDecClkI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual void AnaOvrdval07AnaRxAnaIbiasLbEnI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void AnaOvrdval07AnaRxAnaIbiasCalContI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdval07AnaRxAnaAfeLbMuxVcmSelI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void AnaOvrdval07AnaRxAnaAfeLbMuxGdSelI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void AnaOvrdval07AnaRxAnaAfeCtleMainEnI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void AnaOvrdval11AnaRxAnaAfeCtleLbEnI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void AnaOvrdval11AnaRxAnaAfeCtleBoostI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdval14AnaRxAnaDllPhdEnI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void AnaOvrdval17AnaRxAnaAfeDigClkI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual uint32_t AnaOvrdval00AnaRxAnaPmixData0CodeI(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdval00AnaRxAnaPmixData90CodeI(
        uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdval00AnaRxAnaPmixData180CodeI(
        uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdval00AnaRxAnaPmixData270CodeI(
        uint32_t die_id, uint32_t lane_id) = 0;
    virtual void AnaOvrdEn00OvrdEnAnaRxAnaCalDacCodeI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual uint32_t AnaOvrdEn00OvrdEnAnaRxAnaCalDacCodeI(
        uint32_t die_id, uint32_t lane_id) = 0;
    virtual void AnaOvrdEn00OvrdEnAnaRxAnaCalDacAddrI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual uint32_t AnaOvrdEn00OvrdEnAnaRxAnaCalDacAddrI(
        uint32_t die_id, uint32_t lane_id) = 0;
    virtual void AnaOvrdEn00OvrdEnAnaRxAnaCalDacDecClkI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual uint32_t AnaOvrdEn00OvrdEnAnaRxAnaCalDacDecClkI(
        uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AnaOvrdEn00OvrdEnAnaRxAnaCalDacDecRstNI(
        uint32_t die_id, uint32_t lane_id) = 0;
    virtual void AnaOvrdEn00OvrdEnAnaRxAnaCalDacDecRstNI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual void AnaOvrdEn02OvrdEnAnaAfeCtleBoostI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual void AnaOvrdEn03OvrdEnAnaRxAnaAfeDigClkI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;

    virtual void AnaOvrdEn00OvrdEnAnaRxAnaPmixErrorEnI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void AnaOvrdEn00OvrdEnAnaRxAnaPmixErrorCodeI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void AnaOvrdval01AnaRxAnaPmixErrorEnI(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void AnaOvrdval01AnaRxAnaPmixErrorCodeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void GenericConf13PmixLaClkOvrdSel(
        uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void GenericConf13PmixLaClkOvrdVal(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;

    virtual uint32_t Status14SsmDacCode(uint32_t die_id, uint32_t lane_id)           = 0;
    virtual uint32_t Status15AsmCtleBoostAdptCode(uint32_t die_id, uint32_t lane_id) = 0;

    // Pmix Sweep
    virtual void Patgen0PatternSel(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void Patgen8InitLfsrModeCnt0Rst1(
        uint32_t die_id, uint32_t lane_id, bool value)                             = 0;
    virtual void Patgen9(uint32_t die_id, uint32_t lane_id, uint32_t value)        = 0;
    virtual void Patgen8BerEn(uint32_t die_id, uint32_t lane_id, bool enable)      = 0;
    virtual void Patgen8ReadModeEn(uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual uint32_t Status1ErrCnt(uint32_t die_id, uint32_t lane_id)             = 0;
    virtual bool GenericConf13PmixOffsetCodeEn(uint32_t die_id, uint32_t lane_id) = 0;
    virtual void GenericConf13PmixOffsetCodeEn(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual uint32_t GenericConf12Pmix0Offset(uint32_t die_id, uint32_t lane_id) = 0;
    virtual void GenericConf12Pmix0Offset(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual uint32_t GenericConf12Pmix90Offset(uint32_t die_id, uint32_t lane_id) = 0;
    virtual void GenericConf12Pmix90Offset(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual uint32_t GenericConf12Pmix180Offset(uint32_t die_id, uint32_t lane_id) = 0;
    virtual void GenericConf12Pmix180Offset(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual uint32_t GenericConf12Pmix270Offset(uint32_t die_id, uint32_t lane_id) = 0;
    virtual void GenericConf12Pmix270Offset(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual uint32_t GenericConf13PmixErrOffset(uint32_t die_id, uint32_t lane_id) = 0;
    virtual void GenericConf13PmixErrOffset(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;

    // spin data pmix
    virtual uint32_t Ovrdval00PmixData0CodeI(uint32_t die_id, uint32_t lane_id)   = 0;
    virtual uint32_t Ovrdval00PmixData90CodeI(uint32_t die_id, uint32_t lane_id)  = 0;
    virtual uint32_t Ovrdval00PmixData180CodeI(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t Ovrdval00PmixData270CodeI(uint32_t die_id, uint32_t lane_id) = 0;
    virtual void Ovrdval00PmixData0CodeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void Ovrdval00PmixData90CodeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void Ovrdval00PmixData180CodeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void Ovrdval00PmixData270CodeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value)                                = 0;
    virtual void Ovrden00PmixData0CodeI(uint32_t die_id, uint32_t lane_id, bool enable)   = 0;
    virtual void Ovrden00PmixData90CodeI(uint32_t die_id, uint32_t lane_id, bool enable)  = 0;
    virtual void Ovrden00PmixData180CodeI(uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void Ovrden00PmixData270CodeI(uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual void Patgen08InitLfsrModeContinue0Restart1(
        uint32_t die_id, uint32_t lane_id, uint32_t value)                          = 0;
    virtual void Patgen08ReadModeEn(uint32_t die_id, uint32_t lane_id, bool enable) = 0;
    virtual uint32_t Status01BitErrorCount(uint32_t die_id, uint32_t lane_id) = 0;

    // 2d eye sweep
    virtual void AnaOvrdval00AnaRxAnaPmixData0CodeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdval00AnaRxAnaPmixData90CodeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdval00AnaRxAnaPmixData180CodeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdval00AnaRxAnaPmixData270CodeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdEn00AnaRxAnaPmixData0CodeI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual void AnaOvrdEn00AnaRxAnaPmixData90CodeI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual void AnaOvrdEn00AnaRxAnaPmixData180CodeI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual void AnaOvrdEn00AnaRxAnaPmixData270CodeI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;
    virtual uint32_t AdaptVals0AdaptD0hSlcDacCode(uint32_t die_id, uint32_t lane_id)   = 0;
    virtual uint32_t AdaptVals0AdaptD0mSlcDacCode(uint32_t die_id, uint32_t lane_id)   = 0;
    virtual uint32_t AdaptVals0AdaptD0lSlcDacCode(uint32_t die_id, uint32_t lane_id)   = 0;
    virtual uint32_t AdaptVals1AdaptD90hSlcDacCode(uint32_t die_id, uint32_t lane_id)  = 0;
    virtual uint32_t AdaptVals1AdaptD90mSlcDacCode(uint32_t die_id, uint32_t lane_id)  = 0;
    virtual uint32_t AdaptVals1AdaptD90lSlcDacCode(uint32_t die_id, uint32_t lane_id)  = 0;
    virtual uint32_t AdaptVals2AdaptD180hSlcDacCode(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AdaptVals2AdaptD180mSlcDacCode(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AdaptVals2AdaptD180lSlcDacCode(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AdaptVals3AdaptD270hSlcDacCode(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AdaptVals3AdaptD270mSlcDacCode(uint32_t die_id, uint32_t lane_id) = 0;
    virtual uint32_t AdaptVals3AdaptD270lSlcDacCode(uint32_t die_id, uint32_t lane_id) = 0;

    virtual void AnaOvrdEn00AnaRxAnaCalDacEnI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;  // rx write dac code
    virtual void AnaOvrdval03AnaRxAnaCalDacEnI(
        uint32_t die_id, uint32_t lane_id, bool value) = 0;  // rx write dac code

    // atb
    virtual void AnaOvrdEn03AnaAtbSEnI(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdEn00AnaCalMuxaSelI(
        uint32_t die_id, uint32_t lane_id, uint32_t value)                                 = 0;
    virtual void AnaOvrdEn00AnaCalModeI(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdEn02AnaAtbMeasCalMuxI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void SupRxAnaOvrdEn03AnaLaneLeftEnI(uint32_t die_id, uint32_t value)   = 0;
    virtual void SupRxAnaOvrdVal04AnaLaneLeftEnI(uint32_t die_id, uint32_t value)  = 0;
    virtual void SupRxAnaOvrdEn03AnaLaneRightEnI(uint32_t die_id, uint32_t value)  = 0;
    virtual void SupRxAnaOvrdVal04AnaLaneRightEnI(uint32_t die_id, uint32_t value) = 0;
    virtual void AnaOvrdVal17AnaAtbSEnI(uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdVal10AnaAtbMeasCalMuxI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdVal03AnaCalModeI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void AnaOvrdVal02AnaCalMuxaSelI(
        uint32_t die_id, uint32_t lane_id, uint32_t value) = 0;
    virtual void SupTxAnaOvrdEn03AnaSupEnI(uint32_t die_id, uint32_t value)     = 0;
    virtual void SupTxAnaOvrdVal04AnaSupEnI(uint32_t die_id, uint32_t value)    = 0;
    virtual void SupTxAnaOvrdVal02AnaRstI(uint32_t die_id, uint32_t value)      = 0;
    virtual void SupTxAnaOvrdEn00AnaClkI(uint32_t die_id, uint32_t value)       = 0;
    virtual void SupTxAnaOvrdEn03AnaCruRdDataO(uint32_t die_id, uint32_t value) = 0;
    virtual void SupTxAnaOvrdEn00AnaRstI(uint32_t die_id, uint32_t value)       = 0;
    virtual void SupTxAnaOvrdEn00AnaWrDataI(uint32_t die_id, uint32_t value)    = 0;
    virtual void SupTxAnaOvrdEn00AnaWrEnI(uint32_t die_id, uint32_t value)      = 0;
    virtual void SupTxAnaOvrdEn00AnaSelI(uint32_t die_id, uint32_t value)       = 0;
    virtual void SupTxAnaOvrdEn00AnaRdEnI(uint32_t die_id, uint32_t value)      = 0;
    virtual void SupTxAnaOvrdVal03AnaSelI(uint32_t die_id, uint32_t value)      = 0;
    virtual void SupTxAnaOvrdVal02AnaWrDataI(uint32_t die_id, uint32_t value)   = 0;
    virtual void SupTxAnaOvrdVal02AnaWrEnI(uint32_t die_id, uint32_t value)     = 0;
    virtual void SupTxAnaOvrdVal02AnaClkI(uint32_t die_id, uint32_t value)      = 0;
    virtual void SupTxAnaOvrdEn02AnaCompRstI(uint32_t die_id, uint32_t value)   = 0;
    // virtual void SupTxAnaOvdEn03AnaEnI(uint32_t die_id, uint32_t value) = 0;
    virtual void SupTxAnaOvrdEn03AnaModeI(uint32_t die_id, uint32_t value)        = 0;
    virtual void SupTxAnaOvrdEn03AnaValueI(uint32_t die_id, uint32_t value)       = 0;
    virtual void SupTxAnaOvrdEn00AnaTermCtrlI(uint32_t die_id, uint32_t value)    = 0;
    virtual void SupTxAnaOvrdEn03AnaCompResultO(uint32_t die_id, uint32_t value)  = 0;
    virtual void SupTxAnaOvrdEn03AnaEnI(uint32_t die_id, uint32_t value)          = 0;
    virtual void SupTxSupCfg13RtRxCalEn(uint32_t die_id, uint32_t value)          = 0;
    virtual void SupTxSupCfg13RtTxCalEn(uint32_t die_id, uint32_t value)          = 0;
    virtual void SupTxSupCfg13RtAccType(uint32_t die_id, uint32_t value)          = 0;
    virtual void SupTxSupCfg14RtValueThermBinSel(uint32_t die_id, uint32_t value) = 0;
    virtual void SupTxSupCfg13RtManualTune(uint32_t die_id, uint32_t value)       = 0;
    virtual uint32_t SupTxRtStat00RtStatReg(uint32_t die_id) = 0;
    /////
    virtual void SupRxAnaOvrdEn03AnaSupEnI(uint32_t die_id, uint32_t value)  = 0;  //
    virtual void SupRxAnaOvrdVal04AnaSupEnI(uint32_t die_id, uint32_t value) = 0;  //

 public:
    std::shared_ptr<spdlog::logger> logger_;
    const Dtu *                     m_dtu;
};

}  // namespace aasp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_AASP_AASP_H_
