/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_AASP_AASP_RAS_H_
#define HARDWARE_INCLUDE_AASP_AASP_RAS_H_

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace aasp {
// ras config , total 64bit, serval bits reserved
class AaspRasCfg : public efvf::hardware::RasCfg {
    bool sram_parity_error      = false;
    bool interface_parity_error = false;
};
class AaspRasErrInj : public efvf::hardware::RasErrInj {
 public:
    bool     specific_axi_error_in_al : 1;
    bool     specific_tdp_field_error : 1;
    bool     specific_lmp_field_error : 1;
    bool     bup_error : 1;
    bool     sequence_number_error : 1;
    bool     crc32_error : 1;
    bool     fec_error : 1;
    bool     fc_credit_update_error : 1;
    bool     blk_unit_error : 1;
    bool     tdp_duplicate_error : 1;
    bool     ordered_set_error : 1;
    uint32_t value;
    uint32_t sub_type;
    uint32_t count;
};

class AaspRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t dfotbd_wrcmd_tdp_id_dismatch : 1;
    uint32_t dfotbd_rdcmd_tdp_id_dismatch : 1;
    uint32_t dfotbd_rdcmd_tdp_len_dismatch : 1;
    uint32_t cfotbd_wrcmd_tdp_id_dismatch : 1;
    uint32_t cfotbd_rdcmd_tdp_id_dismatch : 1;
    uint32_t cfotbd_rdcmd_tdp_len_dismatch : 1;
    uint32_t dfotbd_wrcmd_tdp_parity_data_int : 1;
    uint32_t dfotbd_rdresp_tdp_parity_data_int : 1;
    uint32_t cfotbd_wrcmd_tdp_parity_data_int : 1;
    uint32_t cfotbd_rdresp_tdp_parity_data_int : 1;
    uint32_t int_edf_inbd_wrcmd_data_poison : 1;
    uint32_t int_edf_inbd_rdresp_data_poison : 1;
    uint32_t int_ecf_inbd_wrcmd_data_poison : 1;
    uint32_t int_ecf_inbd_rdresp_data_poison : 1;
    uint32_t int_edf_inbd_tdp_fmt_oot : 1;
    uint32_t int_ecf_inbd_tdp_fmt_oot : 1;
    uint32_t rx_buffer_overflow : 1;
    uint32_t rx_buffer_underflow : 1;
    uint32_t int_fc_credit_err : 1;
    uint32_t int_ebu_header_err : 1;
    uint32_t int_ecc_errcnt : 1;
    uint32_t int_crc_errcnt : 1;
    uint32_t ack_bun_eql_int : 1;
    uint32_t nak_bun_eql_int : 1;
    uint32_t ack_bun_sml_int : 1;
    uint32_t nak_bun_sml_int : 1;
    uint32_t int_train_timeout : 1;
    uint32_t int_retry_err : 1;
    uint32_t int_buffer_full_retry : 1;
    uint32_t int_dl_init_timeout : 1;
    uint32_t int_block_align_timeout : 1;
    uint32_t int_pl_init_timeout : 1;
    uint32_t retrain_req : 1;
    uint32_t int_tx_active_lane_oot : 1;
    uint32_t int_retrain_req_remote : 1;
    uint32_t int_pl_lane_deskew_fail : 1;
    uint32_t int_pl_demux_countdown_orderset_unalign : 1;
    uint32_t rsv : 1;
    uint32_t retrain_done : 1;
    uint32_t retrain_fail_once : 1;
    uint32_t retrain_fail : 1;
    uint32_t cxs0_receive_viral_llctrl_llcrd : 1;
    uint32_t cxs0_rx_fifo_overflow : 1;
    uint32_t cxs0_receive_vd_deactive_llctrl : 1;
    uint32_t edf_tl_rx_buffer_sram_parity_err : 1;
    uint32_t ecf_tl_rx_buffer_sram_parity_err : 1;
    uint32_t cxs1_receive_viral_llctrl_llcrd : 1;
    uint32_t cxs1_rx_fifo_overflow : 1;
    uint32_t cxs1_receive_vd_deactive_llctrl : 1;
    uint32_t d2d_ctrl_sram_parity_err : 1;
    uint32_t vdr_sram_parity_err : 1;
    uint32_t ctl_intr_o : 1;
    uint32_t ras_errint_ehmst_buser_bresp_err : 1;
    uint32_t ras_errint_appreg_slv_prty_err : 1;
    uint32_t ras_errint_m00_axi_buser_bresp_err : 1;
    uint32_t ras_errint_m00_axi_ruser_rresp_prty_err : 1;
    uint32_t ras_errint_m00_axi_prty_err : 1;
    uint32_t ras_errint_autoesm_mst_buser_bresp_err : 1;
    uint32_t ras_errint_autoesm_mst_ruser_rresp_prty_err : 1;
    uint32_t ras_errint_psram_slv_prty_err : 1;
    uint32_t ras_errint_ctrl_cfg_prty_err : 1;
    uint32_t ras_errint_phy_cfg_prty_err : 1;
    uint32_t ras_errint_phy_mem_prty_err : 1;
    uint32_t none_event : 1;
};
#if 0
class AaspRasCfg : public efvf::hardware::RasCfg {
    uint32_t dfotbd_wrcmd_tdp_id_dismatch                = 0;
    uint32_t dfotbd_rdcmd_tdp_id_dismatch                = 0;
    uint32_t dfotbd_rdcmd_tdp_len_dismatch               = 0;
    uint32_t cfotbd_wrcmd_tdp_id_dismatch                = 0;
    uint32_t cfotbd_rdcmd_tdp_id_dismatch                = 0;
    uint32_t cfotbd_rdcmd_tdp_len_dismatch               = 0;
    uint32_t dfotbd_wrcmd_tdp_parity_data_int            = 0;
    uint32_t dfotbd_rdresp_tdp_parity_data_int           = 0;
    uint32_t cfotbd_wrcmd_tdp_parity_data_int            = 0;
    uint32_t cfotbd_rdresp_tdp_parity_data_int           = 0;
    uint32_t int_edf_inbd_wrcmd_data_poison              = 0;
    uint32_t int_edf_inbd_rdresp_data_poison             = 0;
    uint32_t int_ecf_inbd_wrcmd_data_poison              = 0;
    uint32_t int_ecf_inbd_rdresp_data_poison             = 0;
    uint32_t int_edf_inbd_tdp_fmt_oot                    = 0;
    uint32_t int_ecf_inbd_tdp_fmt_oot                    = 0;
    uint32_t rx_buffer_overflow                          = 0;
    uint32_t rx_buffer_underflow                         = 0;
    uint32_t int_fc_credit_err                           = 0;
    uint32_t int_ebu_header_err                          = 0;
    uint32_t int_ecc_errcnt                              = 0;
    uint32_t int_crc_errcnt                              = 0;
    uint32_t ack_bun_eql_int                             = 0;
    uint32_t nak_bun_eql_int                             = 0;
    uint32_t ack_bun_sml_int                             = 0;
    uint32_t nak_bun_sml_int                             = 0;
    uint32_t int_train_timeout                           = 0;
    uint32_t int_retry_err                               = 0;
    uint32_t int_buffer_full_retry                       = 0;
    uint32_t int_dl_init_timeout                         = 0;
    uint32_t int_block_align_timeout                     = 0;
    uint32_t int_pl_init_timeout                         = 0;
    uint32_t retrain_req                                 = 0;
    uint32_t int_tx_active_lane_oot                      = 0;
    uint32_t int_retrain_req_remote                      = 0;
    uint32_t int_pl_lane_deskew_fail                     = 0;
    uint32_t int_pl_demux_countdown_orderset_unalign     = 0;
    uint32_t rsv                                         = 0;
    uint32_t retrain_done                                = 0;
    uint32_t retrain_fail_once                           = 0;
    uint32_t retrain_fail                                = 0;
    uint32_t cxs0_receive_viral_llctrl_llcrd             = 0;
    uint32_t cxs0_rx_fifo_overflow                       = 0;
    uint32_t cxs0_receive_vd_deactive_llctrl             = 0;
    uint32_t edf_tl_rx_buffer_sram_parity_err            = 0;
    uint32_t ecf_tl_rx_buffer_sram_parity_err            = 0;
    uint32_t cxs1_receive_viral_llctrl_llcrd             = 0;
    uint32_t cxs1_rx_fifo_overflow                       = 0;
    uint32_t cxs1_receive_vd_deactive_llctrl             = 0;
    uint32_t d2d_ctrl_sram_parity_err                    = 0;
    uint32_t vdr_sram_parity_err                         = 0;
    uint32_t ctl_intr_o                                  = 0;
    uint32_t ras_errint_ehmst_buser_bresp_err            = 0;
    uint32_t ras_errint_appreg_slv_prty_err              = 0;
    uint32_t ras_errint_m00_axi_buser_bresp_err          = 0;
    uint32_t ras_errint_m00_axi_ruser_rresp_prty_err     = 0;
    uint32_t ras_errint_m00_axi_prty_err                 = 0;
    uint32_t ras_errint_autoesm_mst_buser_bresp_err      = 0;
    uint32_t ras_errint_autoesm_mst_ruser_rresp_prty_err = 0;
    uint32_t ras_errint_psram_slv_prty_err               = 0;
    uint32_t ras_errint_ctrl_cfg_prty_err                = 0;
    uint32_t ras_errint_phy_cfg_prty_err                 = 0;
    uint32_t ras_errint_phy_mem_prty_err                 = 0;
    uint32_t none_event                                  = 0;
};
class AaspRasErrInj : public efvf::hardware::RasErrInj {
    uint32_t dfotbd_wrcmd_tdp_id_dismatch                = 0;
    uint32_t dfotbd_rdcmd_tdp_id_dismatch                = 0;
    uint32_t dfotbd_rdcmd_tdp_len_dismatch               = 0;
    uint32_t cfotbd_wrcmd_tdp_id_dismatch                = 0;
    uint32_t cfotbd_rdcmd_tdp_id_dismatch                = 0;
    uint32_t cfotbd_rdcmd_tdp_len_dismatch               = 0;
    uint32_t dfotbd_wrcmd_tdp_parity_data_int            = 0;
    uint32_t dfotbd_rdresp_tdp_parity_data_int           = 0;
    uint32_t cfotbd_wrcmd_tdp_parity_data_int            = 0;
    uint32_t cfotbd_rdresp_tdp_parity_data_int           = 0;
    uint32_t int_edf_inbd_wrcmd_data_poison              = 0;
    uint32_t int_edf_inbd_rdresp_data_poison             = 0;
    uint32_t int_ecf_inbd_wrcmd_data_poison              = 0;
    uint32_t int_ecf_inbd_rdresp_data_poison             = 0;
    uint32_t int_edf_inbd_tdp_fmt_oot                    = 0;
    uint32_t int_ecf_inbd_tdp_fmt_oot                    = 0;
    uint32_t rx_buffer_overflow                          = 0;
    uint32_t rx_buffer_underflow                         = 0;
    uint32_t int_fc_credit_err                           = 0;
    uint32_t int_ebu_header_err                          = 0;
    uint32_t int_ecc_errcnt                              = 0;
    uint32_t int_crc_errcnt                              = 0;
    uint32_t ack_bun_eql_int                             = 0;
    uint32_t nak_bun_eql_int                             = 0;
    uint32_t ack_bun_sml_int                             = 0;
    uint32_t nak_bun_sml_int                             = 0;
    uint32_t int_train_timeout                           = 0;
    uint32_t int_retry_err                               = 0;
    uint32_t int_buffer_full_retry                       = 0;
    uint32_t int_dl_init_timeout                         = 0;
    uint32_t int_block_align_timeout                     = 0;
    uint32_t int_pl_init_timeout                         = 0;
    uint32_t retrain_req                                 = 0;
    uint32_t int_tx_active_lane_oot                      = 0;
    uint32_t int_retrain_req_remote                      = 0;
    uint32_t int_pl_lane_deskew_fail                     = 0;
    uint32_t int_pl_demux_countdown_orderset_unalign     = 0;
    uint32_t rsv                                         = 0;
    uint32_t retrain_done                                = 0;
    uint32_t retrain_fail_once                           = 0;
    uint32_t retrain_fail                                = 0;
    uint32_t cxs0_receive_viral_llctrl_llcrd             = 0;
    uint32_t cxs0_rx_fifo_overflow                       = 0;
    uint32_t cxs0_receive_vd_deactive_llctrl             = 0;
    uint32_t edf_tl_rx_buffer_sram_parity_err            = 0;
    uint32_t ecf_tl_rx_buffer_sram_parity_err            = 0;
    uint32_t cxs1_receive_viral_llctrl_llcrd             = 0;
    uint32_t cxs1_rx_fifo_overflow                       = 0;
    uint32_t cxs1_receive_vd_deactive_llctrl             = 0;
    uint32_t d2d_ctrl_sram_parity_err                    = 0;
    uint32_t vdr_sram_parity_err                         = 0;
    uint32_t ctl_intr_o                                  = 0;
    uint32_t ras_errint_ehmst_buser_bresp_err            = 0;
    uint32_t ras_errint_appreg_slv_prty_err              = 0;
    uint32_t ras_errint_m00_axi_buser_bresp_err          = 0;
    uint32_t ras_errint_m00_axi_ruser_rresp_prty_err     = 0;
    uint32_t ras_errint_m00_axi_prty_err                 = 0;
    uint32_t ras_errint_autoesm_mst_buser_bresp_err      = 0;
    uint32_t ras_errint_autoesm_mst_ruser_rresp_prty_err = 0;
    uint32_t ras_errint_psram_slv_prty_err               = 0;
    uint32_t ras_errint_ctrl_cfg_prty_err                = 0;
    uint32_t ras_errint_phy_cfg_prty_err                 = 0;
    uint32_t ras_errint_phy_mem_prty_err                 = 0;
    uint32_t none_event                                  = 0;
};

class AaspRasErrStat : public efvf::hardware::RasErrStat {
 public:
    uint32_t ras_errlog_eventhub_master_wr_ = 0;
    uint32_t ras_errlog_appreg_slv_wr0_     = 0;
    uint32_t ras_errlog_appreg_slv_wr1_     = 0;
    uint32_t ras_errlog_init_master_wr_     = 0;
    uint32_t ras_errlog_init_master_rd_     = 0;
    uint32_t ras_errlog_lc_mst0_wr_         = 0;
    uint32_t ras_errlog_lc_mst0_rd_         = 0;
    uint32_t ras_errlog_psram_slv_wr0_      = 0;
    uint32_t ras_errlog_psram_slv_wr1_      = 0;
    uint32_t ras_errlog_ctrl_apb_slv_wr0_   = 0;
    uint32_t ras_errlog_ctrl_apb_slv_wr1_   = 0;
    uint32_t ras_errlog_phy_apb_slv_wr0_    = 0;
    uint32_t ras_errlog_phy_apb_slv_wr1_    = 0;
    uint32_t ras_errlog_phy_ahb_slv_wr0_    = 0;
    uint32_t ras_errlog_phy_ahb_slv_wr1_    = 0;
};
#endif
class AaspIntrptCfg : public efvf::hardware::IntrptCfg {
    uint32_t dfotbd_wrcmd_tdp_id_dismatch                = 0;
    uint32_t dfotbd_rdcmd_tdp_id_dismatch                = 0;
    uint32_t dfotbd_rdcmd_tdp_len_dismatch               = 0;
    uint32_t cfotbd_wrcmd_tdp_id_dismatch                = 0;
    uint32_t cfotbd_rdcmd_tdp_id_dismatch                = 0;
    uint32_t cfotbd_rdcmd_tdp_len_dismatch               = 0;
    uint32_t dfotbd_wrcmd_tdp_parity_data_int            = 0;
    uint32_t dfotbd_rdresp_tdp_parity_data_int           = 0;
    uint32_t cfotbd_wrcmd_tdp_parity_data_int            = 0;
    uint32_t cfotbd_rdresp_tdp_parity_data_int           = 0;
    uint32_t int_edf_inbd_wrcmd_data_poison              = 0;
    uint32_t int_edf_inbd_rdresp_data_poison             = 0;
    uint32_t int_ecf_inbd_wrcmd_data_poison              = 0;
    uint32_t int_ecf_inbd_rdresp_data_poison             = 0;
    uint32_t int_edf_inbd_tdp_fmt_oot                    = 0;
    uint32_t int_ecf_inbd_tdp_fmt_oot                    = 0;
    uint32_t rx_buffer_overflow                          = 0;
    uint32_t rx_buffer_underflow                         = 0;
    uint32_t int_fc_credit_err                           = 0;
    uint32_t int_ebu_header_err                          = 0;
    uint32_t int_ecc_errcnt                              = 0;
    uint32_t int_crc_errcnt                              = 0;
    uint32_t ack_bun_eql_int                             = 0;
    uint32_t nak_bun_eql_int                             = 0;
    uint32_t ack_bun_sml_int                             = 0;
    uint32_t nak_bun_sml_int                             = 0;
    uint32_t int_train_timeout                           = 0;
    uint32_t int_retry_err                               = 0;
    uint32_t int_buffer_full_retry                       = 0;
    uint32_t int_dl_init_timeout                         = 0;
    uint32_t int_block_align_timeout                     = 0;
    uint32_t int_pl_init_timeout                         = 0;
    uint32_t retrain_req                                 = 0;
    uint32_t int_tx_active_lane_oot                      = 0;
    uint32_t int_retrain_req_remote                      = 0;
    uint32_t int_pl_lane_deskew_fail                     = 0;
    uint32_t int_pl_demux_countdown_orderset_unalign     = 0;
    uint32_t rsv                                         = 0;
    uint32_t retrain_done                                = 0;
    uint32_t retrain_fail_once                           = 0;
    uint32_t retrain_fail                                = 0;
    uint32_t cxs0_receive_viral_llctrl_llcrd             = 0;
    uint32_t cxs0_rx_fifo_overflow                       = 0;
    uint32_t cxs0_receive_vd_deactive_llctrl             = 0;
    uint32_t edf_tl_rx_buffer_sram_parity_err            = 0;
    uint32_t ecf_tl_rx_buffer_sram_parity_err            = 0;
    uint32_t cxs1_receive_viral_llctrl_llcrd             = 0;
    uint32_t cxs1_rx_fifo_overflow                       = 0;
    uint32_t cxs1_receive_vd_deactive_llctrl             = 0;
    uint32_t d2d_ctrl_sram_parity_err                    = 0;
    uint32_t vdr_sram_parity_err                         = 0;
    uint32_t ctl_intr_o                                  = 0;
    uint32_t ras_errint_ehmst_buser_bresp_err            = 0;
    uint32_t ras_errint_appreg_slv_prty_err              = 0;
    uint32_t ras_errint_m00_axi_buser_bresp_err          = 0;
    uint32_t ras_errint_m00_axi_ruser_rresp_prty_err     = 0;
    uint32_t ras_errint_m00_axi_prty_err                 = 0;
    uint32_t ras_errint_autoesm_mst_buser_bresp_err      = 0;
    uint32_t ras_errint_autoesm_mst_ruser_rresp_prty_err = 0;
    uint32_t ras_errint_psram_slv_prty_err               = 0;
    uint32_t ras_errint_ctrl_cfg_prty_err                = 0;
    uint32_t ras_errint_phy_cfg_prty_err                 = 0;
    uint32_t ras_errint_phy_mem_prty_err                 = 0;
    uint32_t none_event                                  = 0;
};

class AaspIntrptStat : public efvf::hardware::IntrptStat {
    uint32_t ras_errlog_eventhub_master_wr_ = 0;
    uint32_t ras_errlog_appreg_slv_wr0_     = 0;
    uint32_t ras_errlog_appreg_slv_wr1_     = 0;
    uint32_t ras_errlog_init_master_wr_     = 0;
    uint32_t ras_errlog_init_master_rd_     = 0;
    uint32_t ras_errlog_lc_mst0_wr_         = 0;
    uint32_t ras_errlog_lc_mst0_rd_         = 0;
    uint32_t ras_errlog_psram_slv_wr0_      = 0;
    uint32_t ras_errlog_psram_slv_wr1_      = 0;
    uint32_t ras_errlog_ctrl_apb_slv_wr0_   = 0;
    uint32_t ras_errlog_ctrl_apb_slv_wr1_   = 0;
    uint32_t ras_errlog_phy_apb_slv_wr0_    = 0;
    uint32_t ras_errlog_phy_apb_slv_wr1_    = 0;
    uint32_t ras_errlog_phy_ahb_slv_wr0_    = 0;
    uint32_t ras_errlog_phy_ahb_slv_wr1_    = 0;
};

class AaspRas : public efvf::hardware::IRas {};

}  // namespace aasp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_AASP_AASP_RAS_H_
