/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_UCL_UCODE_LOADER_H_
#define HARDWARE_INCLUDE_UCL_UCODE_LOADER_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace ucl {

class UcodeLoader {
 public:
    explicit UcodeLoader(const Dtu &);
    virtual ~UcodeLoader() {}

 public:
    virtual std::string uc_tool_req_st(const std::string &);
    virtual std::string uc_tool_req_st(const std::string &, const std::string &);
    virtual bool        uc_tool_req_op(const std::string &, const std::string &);
    virtual bool        uc_load_all(void);
    virtual bool        uc_loaded(void);

 protected:
    virtual uint32_t uc_reg_r(uint32_t);
    virtual void     uc_reg_w(uint32_t, uint32_t);
    virtual void     uc_delay_ms(uint32_t);
    virtual void     uc_delay_us(uint32_t);

 protected:
    const Dtu &                     m_dtu;
    Hpd *                           m_hpd;
    std::shared_ptr<spdlog::logger> logger_;
};

}  // namespace ucl
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_UCL_UCODE_LOADER_H_
