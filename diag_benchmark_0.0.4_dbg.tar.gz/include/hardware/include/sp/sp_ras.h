/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_SP_SP_RAS_H_
#define HARDWARE_INCLUDE_SP_SP_RAS_H_
#include <vector>
#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace sp {

enum SramParityInjectType { ErrorInParityBits = 0, ErrorInDataBits = 1 };

enum SramEccInjectType { ErrorInData = 0, ErrorInEccCodeAndData = 1 };

class SpRasCfg : public efvf::hardware::RasCfg {
 public:
    // sram parity control
    uint32_t sram_parity_gen_en : 1;
    uint32_t sram_parity_check_en : 1;

    // sram ecc control
    uint32_t sram_ecc_code_gen_en : 1;
    uint32_t sram_ecc_decode_en : 1;
    uint32_t : 28;

    SpRasCfg() {
        sram_parity_gen_en   = 0;
        sram_parity_check_en = 0;
        sram_ecc_code_gen_en = 0;
        sram_ecc_decode_en   = 0;
    }
};

class SpRasErrInj : public efvf::hardware::RasErrInj {
 public:
    // sram parity error injection
    uint32_t sram_parity_err_inj_en : 1;
    uint32_t sram_parity_err_inj_sel_data : 1;

    // sram ecc error injection
    uint32_t sram_ecc_err_inj_en : 1;
    uint32_t sram_ecc_err_inj_sel_data : 1;
    uint32_t : 28;

    uint32_t sram_parity_err_inj_num;
    uint32_t sram_ecc_err_inj_num;

    SpRasErrInj() {
        sram_parity_err_inj_en       = 0;
        sram_parity_err_inj_sel_data = 0;
        sram_parity_err_inj_num      = 0;
        sram_ecc_err_inj_en          = 0;
        sram_ecc_err_inj_sel_data    = 0;
        sram_ecc_err_inj_num         = 0;
    }
};

typedef struct _SramBankStatus {
    uint32_t sram_err_status : 1;
    uint32_t sram_status : 31;
    _SramBankStatus() {
        sram_err_status = 0;
        sram_status     = 0;
    }
} SramBankStatus;

typedef struct _SramBankParErrAddr {
    uint32_t sram_parity_err_addr;
    _SramBankParErrAddr() {
        sram_parity_err_addr = 0;
    }
} SramBankParErrAddr;

typedef struct _SramBankParErrStatus {
    uint32_t sram_parity_err_status : 1;
    uint32_t : 31;
    _SramBankParErrStatus() {
        sram_parity_err_status = 0;
    }
} SramBankParErrStatus;

class SpRasErrStat : public efvf::hardware::RasErrStat {
 public:
    std::vector<SramBankStatus>       sram_bank_status;
    std::vector<SramBankParErrAddr>   sram_bank_par_err_addr;
    std::vector<SramBankParErrStatus> sram_bank_par_err_status;
    SpRasErrStat() {
        sram_bank_status.clear();
        sram_bank_par_err_addr.clear();
        sram_bank_par_err_status.clear();
    }
};

class SpIntrptCfg : public efvf::hardware::IntrptCfg {};

class SpIntrptStat : public efvf::hardware::IntrptStat {};

class SpRas : public efvf::hardware::IRas {};

}  // namespace sp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SP_SP_RAS_H_
