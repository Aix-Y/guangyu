/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_SP_SP_H_
#define HARDWARE_INCLUDE_SP_SP_H_

#include <cstdint>
#include <map>
#include <memory>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include "hardware/include/bpm.h"
#include "hardware/include/gsync/gsync.h"
#include "hardware/include/hardware.h"
#include "hardware/include/ih.h"
#include "hardware/include/mdma/mdma.h"
#include "hardware/include/sp/sp_ras.h"
#include "hardware/include/system_adapter.h"

using efvf::hardware::pmc::Bpm;
using efvf::hardware::pmc::BpmResult;
using efvf::hardware::gsync::Gsync;
using efvf::hardware::mdma::Mdma;
using efvf::hardware::system_adapter::SystemAdapter;
using efvf::hardware::pmc::Pmc;
using efvf::hardware::ih::Ih;

namespace efvf {
namespace hardware {
namespace sp {

class Sp;

struct _SpWriteRegsParam {
    uint64_t                           global_addr_offset{0};
    std::vector<uint64_t>              addr;
    std::vector<uint32_t>              dwlen;
    std::vector<std::vector<uint32_t>> value;
};
struct _SpReadRegsParam {
    uint64_t              global_src_addr_offset{0};
    std::vector<uint64_t> src_addr;
    std::vector<uint32_t> dwlen;
    uint64_t              dst_addr;
};
using SpWriteRegsParam = struct _SpWriteRegsParam;
using SpReadRegsParam  = struct _SpReadRegsParam;
using SpWriteMemParam  = struct _SpWriteRegsParam;
using SpReadMemParam   = struct _SpReadRegsParam;

struct _SpFillMemParam {
    uint64_t addr;
    uint32_t value;
    uint32_t dwlen;
    _SpFillMemParam(uint64_t a, uint32_t v, uint32_t l = 1) : addr(a), value(v), dwlen(l) {}
};
using SpFillMemParam = struct _SpFillMemParam;

enum _SpTaskEngType {
    sp_task_engine_invalid = 0,
    sp_task_engine_odte,
    sp_task_engine_cdte,
    sp_task_engine_sdte,
    sp_task_engine_sip,
    sp_task_engine_edte,
    sp_task_engine_max
};
using SpTaskEngType = enum _SpTaskEngType;
struct _SpTaskHeader final {
#define kSpTaskDependencyMaxNum 8
#define sp_task_invalid_id 0xffffffff
    uint32_t task_id;
    uint32_t dep_task_ids[kSpTaskDependencyMaxNum];  // this task will depend on the tasks
                                                     // in vector dep_task_ids.
    enum _SpTaskEngType type;
    uint64_t engine_id_mask;  // ODTE{0:master,1:slaver}, CDTE{0,1}, SDTE{0~31}, SIP{0~31}; All
                              // bits are "0"
                              // means don't care engine id and just using HWS to find an
                              // idle engine(SDMA/SIP).
    uint64_t engine_subid_mask[4];  // vc mask for ODTE/CDTE/SDTE, xpu/thread mask for
                                    // SIP; All bits are "0" means don't care vc/xpu id
                                    // and just using HWS to find an idle one.
    //
    _SpTaskHeader() {
        task_id = 0;
        for (uint32_t i = 0; i < kSpTaskDependencyMaxNum; ++i) {
            dep_task_ids[i] = sp_task_invalid_id;
        }
        type           = sp_task_engine_invalid;
        engine_id_mask = 0;
        for (uint32_t i = 0; i < sizeof(engine_subid_mask) / sizeof(engine_subid_mask[0]);
             ++i) {
            engine_subid_mask[i] = 0;
        }
    }
};
enum _SpDteTaskType {
    sp_dte_task_type_invalid = 0,
    sp_dte_task_type_linear_copy,
    sp_dte_task_type_max
};
struct _SpDteTaskParam final {
    struct _SpTaskHeader header;
    enum _SpDteTaskType  type;
    uint64_t             src_addr;
    uint64_t             dst_addr;
    uint64_t             size;
};

#define kSpSipTaskMaxBlkNum 16
struct _SpSipTaskParam final {
    struct _SpTaskHeader header;
    // pls add other params here above blocks...
    uint32_t multi_thread_num{1};  // just like OpenMP
    uint32_t block_id_offset{0};
    uint32_t valid_block_num{0};
    struct {
        uint64_t sipcode;  // pre-loaded sipcode addr in L3, Need alignd by 0x1000
        uint32_t mode{0x5070fc0};
        uint32_t trpba{0x10};
        uint32_t intba{0};
        uint32_t launch_cfg{1};
        uint32_t iid_cfg{0};
        uint32_t md[16];
    } block[kSpSipTaskMaxBlkNum];  // Blocks in one CG. block map to sip.
};

using SpDteTaskParam = struct _SpDteTaskParam;
using SpSipTaskParam = struct _SpSipTaskParam;

/* SubmitQueue is thread un-safe, DO NOT make one SQ used by more than 1 thread. */
struct SubmitQueue {
    virtual void ResetQueue(bool host_queue = true, bool sp_queue = false) {}
    virtual bool Emit(bool preempt = false, bool pending = true) = 0;
    virtual bool AsyncCmdListBegin();
    virtual bool AsyncCmdListEnd();
    virtual bool RandomPattern(bool echo = true);
    /* What is "fence" and "block" ?
     * Usually there is no need to care about these 2 params, just left both of them default.
     * "fence" only works in AsyncCmdList, and indicates the next cmd won't be dispatched until
     * all
     * previous cmds done (include this "fence" cmd). (command queue fence in mcp)
     * "block" only works out of an AsyncCmdList, and indicates this cmd must wait all write
     * response, but not all write request sent. (mdma vc fence).
    */
    virtual bool MemCopy(uint64_t src_addr, uint64_t dst_addr, uint32_t size,
        bool fence = false, bool block = false);
    virtual bool DumpShareMem(uint64_t dst_addr, uint32_t src_offset = 0,
        uint32_t size = 0x80000, bool fence = false, bool block = false);
    virtual bool WriteShareMem(uint64_t src_addr, uint32_t dst_offset, uint32_t size,
        bool fence = false, bool block = false);
    virtual bool DumpMcuL2Mem(uint64_t dst_addr, uint32_t src_offset = 0,
        uint32_t size = 0x100000, bool fence = false, bool block = false);
    virtual bool WriteMcuL2Mem(uint64_t src_addr, uint32_t dst_offset, uint32_t size,
        bool fence = false, bool block = false);
    virtual bool DumpMcuL1Mem(uint64_t dst_addr, uint32_t src_offset = 0,
        uint32_t size = 0x60000, bool fence = false, bool block = false);
    virtual bool WriteMcuL1Mem(uint64_t src_addr, uint32_t dst_offset, uint32_t size,
        bool fence = false, bool block = false);
    virtual bool EnableMcuL2Mem();
    virtual bool GetSpMcuL2RegSpace(uint64_t &reg_start_addr, uint32_t &reg_size);
    virtual bool FillMemory(
        const SpFillMemParam &param, bool fence = false, bool block = false);
    virtual bool WriteRegs(
        const SpWriteRegsParam &param, bool fence = false, bool block = false);
    virtual bool ReadRegs(
        const SpReadRegsParam &param, bool fence = false, bool block = false);
    virtual bool WriteMem(
        const SpWriteMemParam &param, bool fence = false, bool block = false);
    virtual bool ReadMem(const SpReadMemParam &param, bool fence = false, bool block = false);
    virtual bool FakeWriteForPrefetch(uint64_t dst_addr, std::string desc_info = "");
    virtual bool PartialWriteForCacheMaint(uint64_t dst_addr, uint64_t data);

    /* DteTask/SipTask are wrapper based on WriteRegs. Use task level dependency instead of
     * "fence". */
    virtual bool DteTask(const SpDteTaskParam &param);
    virtual bool SipTask(const SpSipTaskParam &param);

    virtual ~SubmitQueue() {}
    virtual bool                    Init() = 0;
    std::shared_ptr<spdlog::logger> logger_;
    friend class Sp;

 private:
    virtual void SetQueueSize(uint32_t host_size, uint32_t sp_size) {}
    bool UnSupportedCmd() {
        LOG_ERROR("unsupported sp cmd!!!");
        return false;
    }
};

typedef enum _SpEcfRemapType {
    sp_ecf_remap_to_mcu_dls            = 0,
    sp_ecf_remap_to_debug_smem         = 1,
    sp_ecf_remap_to_pf_incoherent_smem = 2,
    sp_ecf_remap_to_vf_incoherent_smem = 3,
    sp_ecf_remap_to_vf_coherent_smem   = 4
} SpEcfRemapType;

class Sp : public Hardware {
 public:
    Sp() = delete;
    explicit Sp(std::shared_ptr<spdlog::logger> logger);
    virtual ~Sp();
    uint32_t GetSubmitQueueCnt(bool use_firmware = false);
    SubmitQueue *GetSubmitQueue(uint32_t queue_id, bool use_firmware = false);
    void SetQueueSize(uint32_t host_queue_size, uint32_t sp_queue_size);
    virtual void SetHqsActiveNum(uint32_t active_num);
    virtual bool SetFirmwareAlive(bool alive = true);
    virtual bool SetBlcgCtrl(bool cg = true);
    virtual bool SetElcgCtrl(bool cg = true);
    /* HWS is enabled default.
     * When HWS enabled, sp will ignore the engine id/subid in DteTask/SipTask() and schedule
     * an idle engine resource dynamically.
     * "vf_num" should depend on xmc config, and it will influence the HRM config.
     * Now, "vf_num" should only be 0 (PF) or 4 (4VF).
     * TODO: Currently, it is not impletemented when HWS is disabled.
     * And when HWS is disabled,(also there is no software scheduler), APP itself must avoid
     * resource(vc/sip) conflict in muti-tasks. */
    virtual void HardwareSchedulerEnable(bool enable = true, uint32_t vf_num = 0) = 0;
    virtual void SmemParityEnable(bool enable = true) = 0;
    virtual void SmemParityInj(bool inj = true) = 0;
    virtual void SmemParitySts(bool &err)       = 0;
    virtual Mdma *GetMdma()                     = 0;
    virtual Ih *  GetMih()                      = 0;
    /**
     * @brief   get sp df master bpm
     *
     * @return  sp bpm or nullptr
     */
    virtual Bpm *GetDfMasterBpm() = 0;

    /**
     * @brief   get sp df slave bpm
     *
     * @return  sp bpm or nullptr
     */
    virtual Bpm *GetDfSlaveBpm() = 0;

    /**
     * @brief   get sp gsync
     *
     * @return  sp gsync or nullptr
     */
    virtual Gsync *GetGsync() = 0;
    virtual bool GetSpShareAvlMem(uint64_t &mem_start_addr, uint32_t &mem_size) = 0;
    virtual bool GetSpShareAllMem(uint64_t &mem_start_addr, uint32_t &mem_size) = 0;
    virtual bool GetSpMcuL1AvlMem(uint64_t &mem_start_addr, uint32_t &mem_size) = 0;
    virtual bool GetSpMcuL2AvlMem(uint64_t &mem_start_addr, uint32_t &mem_size) = 0;
    virtual SystemAdapter *GetSa()  = 0;
    virtual Pmc *          GetPmc() = 0;
    virtual bool GetSpIdleReg(std::vector<std::pair<uint64_t, uint32_t>> &idle_reg) = 0;
    virtual uint32_t GetSlaverDieCfOffset()                   = 0;
    virtual uint32_t GetSlaverDieDfOffset()                   = 0;
    virtual uint64_t GetOtherIpTestReg(const std::string &ip) = 0;
    virtual std::pair<uint64_t, uint32_t> ConfigEcfSlaverRemap(
        SpEcfRemapType type, uint64_t expected_mem_offset, uint32_t expected_mem_size) = 0;
    virtual bool GetHardwareSchedulerConfig(_SpTaskEngType type,
        std::vector<std::vector<std::tuple<uint32_t, uint32_t, uint32_t>>> &hws_cfg) = 0;
    virtual bool FlushAxiConfig(uint64_t axi_axuser = 0, uint32_t axi_axcache = 0) = 0;

 protected:
    std::vector<std::unique_ptr<SubmitQueue>> m_sq;
    std::vector<std::unique_ptr<SubmitQueue>> m_sq_naked;
};

}  // namespace sp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_SP_SP_H_
