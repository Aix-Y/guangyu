/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_GSYNC_GSYNC_H_
#define HARDWARE_INCLUDE_GSYNC_GSYNC_H_

#include <memory>
#include <set>
#include <string>
#include <vector>

#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace gsync {

/**
 * @brief Gsync wakeup mode
 */
typedef enum _GsyncWakeupMode {
    GSYNC_WAKEUP_GE = 0, /* CNT >= wait */
    GSYNC_WAKEUP_EQ,     /* CNT == wait */
} GsyncWakeupMode;

/**
 * @brief Gsync wait mode
 */
typedef enum _GsyncWaitMode {
    GSYNC_WAIT_MODE0 = 0,
    GSYNC_WAIT_MODE1,
    GSYNC_WAIT_MODE2,
    GSYNC_WAIT_MODE3,
} GsyncWaitMode;

/**
 * @brief Gsync signal mode
 */
typedef enum _GsyncSignalMode {
    GSYNC_SIGNAL_MODE0 = 0, /* CNT = CNT + Set_Data */
    GSYNC_SIGNAL_MODE1,     /* CNT = Set_Data */
} GsyncSignalMode;

/**
 * @brief Gsync ctx cfg
 */
typedef struct _GsyncCtxCfg {
    uint32_t        entry_id    = 0;
    uint32_t        thread_id   = 0;
    uint32_t        wakeup_data = 0;
    uint32_t        wakeup_addr = 0;
    uint32_t        wait_value  = 0;
    GsyncWaitMode   wait_mode   = GsyncWaitMode::GSYNC_WAIT_MODE0;
    GsyncSignalMode signal_mode = GsyncSignalMode::GSYNC_SIGNAL_MODE1;
    uint32_t        signal_cnt  = 0;
    // uint32_t min_mst_id;
    // uint32_t max_mst_id;
} GsyncCtxCfg;

/**
 * @brief Gsync self clear cfg
 */
typedef struct _GsyncSelfClearCfg {
    bool     self_clear_flag    = true;
    bool     init_cnt_flag      = 0;
    uint32_t init_cnt_prog_val  = 0;
    uint32_t init_wait_prog_val = 0;
} GsyncSelfClearCfg;

/**
 * @brief Gsync Basic Hardware Interface
 */
class Gsync : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Gsync(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~Gsync() {}

    /**
     * @brief Clear single GET entry.
     *
     * @param entry_id entry id of GET.
     */
    virtual void ClearSingleEntry(uint32_t entry_id) = 0;

    /**
     * @brief Clear all GET entries.
     */
    virtual void ClearAllEntries() = 0;

    /**
     * @brief Clear resource of single Gsync thread (CNT/WCB).
     *
     * @param thread_id thread id of Gsync.
     */
    virtual void ClearSingleThread(uint32_t thread_id) = 0;

    /**
     * @brief Clear resource of all Gsync threads (CNT/WCB).
     */
    virtual void ClearAllThreads() = 0;

    /**
     * @brief Clear resource of single Gsync thread (CNT/WCB).
     *
     * @param ctx_cfg ctx cfg of Gsync.
     */
    virtual void Wait(const GsyncCtxCfg &ctx_cfg) = 0;

    /**
     * @brief Clear resource of single Gsync thread (CNT/WCB).
     *
     * @param ctx_cfg ctx cfg of Gsync.
     */
    virtual void Signal(const GsyncCtxCfg &ctx_cfg) = 0;

    /**
     * @brief Get single GET entry valid status.
     *
     * @param entry_id entry id of GET.
     * @return bool
     */
    virtual bool CheckEntryValidStatus(uint32_t entry_id) = 0;

    /**
     * @brief Get single GET entry data.
     *
     * @param ctx_cfg ctx cfg of Gsync.
     */
    virtual void GetSingleEntryData(GsyncCtxCfg *ctx_cfg) = 0;

    /**
     * @brief Get single thread cnt data.
     *
     * @param thread_id thread id of Gsync
     */
    virtual uint32_t GetSingleCntData(uint32_t thread_id) = 0;

    /**
     * @brief Get gsync base addr.
     */
    virtual uint32_t GetGsyncBaseAddr() = 0;

    /**
     * @brief      Get the gsync counter ecf address.
     *
     * @param[in]  entry_id  The thread/counter id
     *
     * @return     The gsync counter ecf address.
     */
    virtual uint32_t GetGsyncCntAddr(uint32_t thread_id) = 0;

    /**
     * @brief Get Gsync entry(GET) max num.
     *
     * @return uint32_t
     */
    virtual uint32_t GetMaxEntryNum() = 0;

    /**
     * @brief Get Gsync thread max num.
     *
     * @return uint32_t
     */
    virtual uint32_t GetMaxThreadNum() = 0;

    /**
     * @brief Get Gsync AXI master outstanding max num.
     *
     * @return uint32_t
     */
    virtual uint32_t GetMaxOutstanding() = 0;

    /**
     * @brief Set Gsync AXI master outstanding max num.
     *
     * @param outstanding_val val of outstanding max num.
     */
    virtual void SetMaxOutstanding(uint32_t outstd_val) = 0;

    /**
     * @brief Set Gsync wakeup mode.
     *
     * @param wakeup_mode wakeup mode val.
     */
    virtual void SetWakeupMode(GsyncWakeupMode wakeup_mode) = 0;

    /**
     * @brief Set Gsync wakeup mode.
     *
     * @param is_self_clear self clear flag.
     */
    virtual void SetSelfClear(const GsyncSelfClearCfg &clear_cfg) = 0;

    /**
     * @brief Set Gsync sram parity err count.
     */
    virtual void SetGsyncSramParityErrEnjCountOneTime(uint32_t par_err_enj_count) = 0;

    /**
     * @brief Set Gsync AXI master max/min id range.
     *
     * @param ctx_cfg ctx cfg of Gsync.
     */
    // virtual void SetMaxMinMasterId(const GsyncCtxCfg &ctx_cfg) = 0;

    /**
     * @brief Get the Entry ctx id.
     *
     * @param entry_id
     * @return uint32_t
     */
    virtual uint32_t GetEntryCtxId(uint32_t entry_id) {
        return 0;
    }

    /**
     * @brief Get the Entry asid
     *
     * @param entry_id
     * @return uint32_t
     */
    virtual uint32_t GetEntryAsId(uint32_t entry_id) {
        return 0;
    }

    /**
     * @brief Get the actual wait value of the entry.
     *
     * @param thread_id
     * @return uint32_t
     */
    virtual uint32_t GetWcbValue(uint32_t thread_id) {
        return 0;
    }

    /**
     * @brief Enable Gsync sram ras check.
     */
    virtual void EnableGsyncSramRasCheck() {}

    /**
     * @brief Disable Gsync sram ras check.
     */
    virtual void DisableGsyncSramRasCheck() {}

    /**
     * @brief Get Gsync sram ras status.
     */
    virtual bool GetGsyncSramRasStatus() {}

    /**
     * @brief Clear Gsync sram ras status.
     */
    virtual void ClearGsyncSramRasStatus() {}

    /**
     * @brief Get Gsync sram ras log addr.
     */
    virtual uint32_t GetGsyncSramRasLogAddr() {
        return 0;
    }

    /**
     * @brief Enable Gsync sram parity check.
     */
    virtual void EnableGsyncSramParityCheck() {}

    /**
     * @brief Disable Gsync sram parity check.
     */
    virtual void DisableGsyncSramParityCheck() {}

    /**
     * @brief Enable Gsync sram parity err enj.
     */
    virtual void EnableGsyncSramParityErrEnj() {}

    /**
     * @brief Disable Gsync sram parity err enj.
     */
    virtual void DisableGsyncSramParityErrEnj() {}

    /**
     * @brief Set Gsync Sp Ih base addr.
     *
     * @param addr Ih base addr.
     */
    virtual void SetSpIhBaseAddr(uint32_t addr) {}

    /**
     * @brief Set Gsync Sp Ih data.
     *
     * @param data Ih base data.
     */
    virtual void SetSpIhBaseData(uint32_t data) {}

    /**
     * @brief Set Gsync Pcie Ih base addr.
     *
     * @param addr Ih base addr.
     */
    virtual void SetPcieIhBaseAddr(uint32_t addr) {}

    /**
     * @brief Set Gsync Pcie Ih data.
     *
     * @param data Ih base data.
     */
    virtual void SetPcieIhBaseData(uint32_t data) {}

    /**
     * @brief Set enable or disable axuser when RAS irp happened.
     *
     * @param true
     */
    virtual void SetIrqAxUserOverride(bool enable) {}

    /**
     * @brief Get Available Gsync thread.
     */
    virtual int GetAvailThread() = 0;

    /**
     * @brief Get Available Gsync entry.
     */
    virtual int GetAvailEntry() = 0;

    /**
     * @brief Release Used Gsync threads.
     */
    virtual void ReleaseUsedThreads(std::vector<int> &threads) = 0;

    /**
     * @brief Release Used Gsync entrys.
     */
    virtual void ReleaseUsedEntrys(std::vector<int> &entrys) = 0;
};

}  // namespace gsync
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_GSYNC_GSYNC_H_
