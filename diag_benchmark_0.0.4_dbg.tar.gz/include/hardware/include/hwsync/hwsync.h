/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_HWSYNC_HWSYNC_H_
#define HARDWARE_INCLUDE_HWSYNC_HWSYNC_H_
#include <map>
#include <memory>
#include <set>
#include <string>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace hwsync {

typedef enum _HwsyncResType {
    Res_static,
    Res_dynamic,
} HwsyncResType;

typedef struct _HwsyncVgResInit {
    HwsyncResType res_type;
    uint32_t      vg_num;
    uint32_t      entry_num;
    uint32_t      static_mutex_num;
    uint32_t      static_cnt_num;
    uint32_t      dynamic_mutex_num;
    uint32_t      dynamic_cnt_num;
} HwsyncVgResInit;

typedef enum _HwsyncIntStatusChk {
    INT_STATUS0_NO_RESOURCE_ALLOCED = 0,
    INT_STATUS1_BRESP_ERROR,
    INT_STATUS2_UNLOCK_UNLOCKED_MUTEX,
    INT_STATUS3_DEALLOC_LOCKED_MUTEX,
    INT_STATUS4_MUTEX_ALLOC_ERROR,
    INT_STATUS5_CNT_ALLOC_ERROR,
    INT_STATUS6_MUTEX_DEALLOC_ERROR,
    INT_STATUS7_COUNTER_DEALLOC_ERROR,
    INT_STATUS8,
    INT_STATUS9,
    INT_STATUS10,
    INT_STATUS11,
    INT_STATUS12,
    INT_STATUS13,
    INT_STATUS14,
    INT_STATUS15,
    INT_STATUS16,
    INT_STATUS17,
    INT_STATUS18,
    INT_STATUS19,
    INT_STATUS20,
    INT_STATUS21,
    INT_STATUS22,
    INT_STATUS23,
} HwsyncIntStatusChk;

const std::map<HwsyncIntStatusChk, uint32_t> intr_status_map = {
    {INT_STATUS0_NO_RESOURCE_ALLOCED, 0}, {INT_STATUS1_BRESP_ERROR, 1},
    {INT_STATUS2_UNLOCK_UNLOCKED_MUTEX, 2}, {INT_STATUS3_DEALLOC_LOCKED_MUTEX, 3},
    {INT_STATUS4_MUTEX_ALLOC_ERROR, 4}, {INT_STATUS5_CNT_ALLOC_ERROR, 5},
    {INT_STATUS6_MUTEX_DEALLOC_ERROR, 6}, {INT_STATUS7_COUNTER_DEALLOC_ERROR, 7},
    {INT_STATUS8, 8}, {INT_STATUS9, 9}, {INT_STATUS10, 10}, {INT_STATUS11, 11},
    {INT_STATUS12, 12}, {INT_STATUS13, 13}, {INT_STATUS14, 14}, {INT_STATUS15, 15},
    {INT_STATUS16, 16}, {INT_STATUS17, 17}, {INT_STATUS18, 18}, {INT_STATUS19, 19},
    {INT_STATUS20, 20}, {INT_STATUS21, 21}, {INT_STATUS22, 22}, {INT_STATUS23, 23}};

#if 0
typedef struct _HwsyncLutNotifyInfo {
    uint32_t last_id;
    uint32_t entry_uniq_id;
    uint32_t lut_id;
    uint32_t notify_addr;
    uint32_t notify_data_h;
    uint32_t notify_data_l;
} HwsyncLutNotifyInfo;
#endif

typedef struct _HwsyncLutNotifyInfo {
    uint32_t last_val;
    uint32_t cnt_uniq_id;
    // uint32_t notify_addr;
    uint32_t notify_data;
} HwsyncLutNotifyInfo;
typedef struct _HwsyncSetCounter {
    uint32_t threshold;
    uint32_t cnt_alloc_id;
    uint32_t config_uniq_id;
} HwsyncSetCounter;

typedef struct _HwsyncCntStaticAlloc {
    uint32_t cnt_sync_type;
    uint32_t cnt_alloc_id;
    uint32_t cnt_uniq_id;
    uint32_t cnt_value;
} HwsyncCntStaticAlloc;

// typedef struct _HwsyncRegisMsg {
//    uint32_t last_id;
//    uint32_t uniq_id;
//    uint32_t regis_info
//} HwsyncRegisMsg;
/**
 * @brief Hwsync Basic Hardware Interface
 */
class Hwsync : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Hwsync(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~Hwsync() {}

    /**
     * @brief clear single entry
     *
     * @param entry_id
     */
    virtual void ClearSingleEntry(uint32_t entry_id) = 0;
    /**
     * @brief clear all entries
     *
     */
    virtual void ClearAllEntries() = 0;
    /**
     * @brief clear single counter
     *
     * @param counter_id
     */
    virtual void ClearSingleCounter(uint32_t counter_id) = 0;
    /**
     * @brief clear all counters
     *
     */
    virtual void ClearAllCounters() = 0;
    /**
     * @brief clear all mutex
     *
     */
    virtual void ClearAllMutex() = 0;
    // combine  struct
    /**
     * @brief init vg resource
     *
     * @param res_init
     */
    virtual void InitVgRes(const HwsyncVgResInit &res_init) = 0;
    /**
     * @brief init lut master addr & axi id
     *
     */
    virtual void InitLut(uint32_t lut_id) = 0;
    /**
     * @brief Set the Lut object
     * include addr master & axi id
     *
     * @param lut_id
     */
    virtual void SetLut(uint32_t lut_id, uint32_t addr) = 0;
    // alloc  static counter
    /**
     * @brief alloc static counter
     *
     * @param alloc_static_cnt
     */
    virtual void AllocStaticCnt(const HwsyncCntStaticAlloc &alloc_static_cnt) = 0;
    // set init counter
    /**
     * @brief set counter (counter alloc id & counter threshold & uniq id)
     *
     * @param counter_num
     * @param threshold
     * @param uniq_id
     */
    virtual void SetCounter(const HwsyncSetCounter &set_counter) = 0;
    /**
     * @brief Set the Lut Notify Info object
     * lut_id  master notify address
     * register_alloc_id connect cnt
     * uniq_id  bonding 2 data
     *
     * @param notify_info
     */
    virtual uint32_t SetLutNotifyInfo(const HwsyncLutNotifyInfo &notify_info) = 0;
    /**
     * @brief Get the Max Mutex object
     *
     * @return uint32_t
     */
    virtual uint32_t GetMaxMutex() = 0;
    /**
     * @brief Get the Max Cnt object
     *
     * @return uint32_t
     */
    virtual uint32_t GetMaxCnt() = 0;
    /**
     * @brief Get the Max Entry object
     *
     * @return uint32_t
     */
    virtual uint32_t GetMaxEntry() = 0;
    /**
     * @brief Get the Alloc Static Mutex Num object
     *
     * @param static_num
     * @return uint32_t
     */
    virtual uint32_t GetAllocStaticMutexNum(uint32_t static_mutex_num) = 0;
    /**
     * @brief Get the Alloc Static Cnt Num object
     *
     * @param static_num
     * @return uint32_t
     */
    virtual uint32_t GetAllocStaticCntNum(uint32_t static_cnt_num) = 0;
    /**
     * @brief Get the Alloc Entry Num object
     *
     * @return uint32_t
     */
    virtual uint32_t GetAllocEntryNum(uint32_t entry_num) = 0;
    /**
     * @brief Get the Alloc dynamic Mutex Num object
     *
     * @return uint32_t
     */
    virtual uint32_t GetAllocDynamicMutexNum(uint32_t static_mutex_num) = 0;
    /**
     * @brief Get the Alloc dynamic Cnt Num object
     *
     * @return uint32_t
     */
    virtual uint32_t GetAllocDynamicCntNum(uint32_t static_cnt_num) = 0;
    // mutex interface
    /**
     * @brief alloc mutex , only for dynamic mode
     *
     * @return uint32_t
     */
    virtual uint32_t AllocMutex() = 0;
    /**
     * @brief dealloc mutex , only for dynamic mode
     *
     * @param mutex_id
     */
    virtual void DeallocMutex(uint32_t mutex_id) = 0;
    /**
     * @brief try lock mutex
     *
     * @param mutex_id
     * @return true
     * @return false
     */
    virtual bool TryLockMutex(uint32_t mutex_id) = 0;
    /**
     * @brief unlock mutex
     *
     * @param mutex_id
     */
    virtual void UnlockMutex(uint32_t mutex_id) = 0;
    // barrier interface
    /**
     * @brief alloc barrier , only for dynamic mode
     *
     * @return uint32_t
     */
    virtual uint32_t AllocBarrier() = 0;
    /**
     * @brief dealloc barrier , only for dynamic mode
     *
     * @param barrier_id
     */
    virtual void DeallocBarrier(uint32_t barrier_id) = 0;
    /**
     * @brief unregister barrier wait
     *
     * @param counter_id
     */
    virtual void UnRegisterBarrierWait(
        uint32_t counter_id, uint32_t uniq_id, uint32_t thread_id) = 0;
    /**
     * @brief one thread notify barrier res , arrive barrier location
     *
     * @param counter_id
     */
    virtual void ArriveBarrier(uint32_t counter_id, uint32_t uniq_id, uint32_t thread_id) = 0;
    /**
     * @brief arrive and drop barrier
     *
     * @param counter_id
     */
    virtual void ArriveAndDropBarrier(uint32_t counter_id, uint32_t uniq_id) = 0;

    // latch interface
    /**
     * @brief alloc latch ,return latch id,only for dynamic mode.
     *
     */
    virtual uint32_t AllocLatch() = 0;
    /**
     * @brief dealloc latch , only for dynamic mode.
     *
     * @param latch_id
     */
    virtual void DeallocLatch(uint32_t latch_id) = 0;
    /**
     * @brief arrive latch
     *
     * @param counter_id
     */
    virtual void ArriveLatch(uint32_t counter_id, uint32_t uniq_id, uint32_t thread_id) = 0;
    /**
     * @brief unregister latch wait
     *
     * @param counter_id
     */
    virtual void UnregisterLatchWait(
        uint32_t counter_id, uint32_t uniq_id, uint32_t thread_id) = 0;

    // queue interface
    /**
     * @brief alloc producer queue , only for dynamic mode.
     *
     * @return uint32_t
     */
    virtual uint32_t AllocProdQueue() = 0;
    /**
     * @brief alloc producer queue , only for dynamic mode.
     *
     * @return uint32_t
     */
    virtual uint32_t AllocConsQueue() = 0;
    /**
     * @brief dealloc producer queue , only for dynamic mode.
     *
     * @param queue_producer_id
     */
    virtual void DeallocProdQueue(uint32_t queue_producer_id) = 0;
    /**
     * @brief advance write far for producer , notify queue , produce buffer
     *
     * @param queue_producer_id
     * @param uniq_id
     */
    virtual void AdvanceWriteFar(uint32_t queue_producer_id, uint32_t uniq_id) = 0;
    /**
     * @brief advance read far for consumer , notify queue ,consume buffer
     *
     * @param queue_consumer_id
     * @param uniq_id
     */
    virtual void AdvanceReadFar(uint32_t queue_consumer_id, uint32_t uniq_id) = 0;
    /**
     * @brief free entry resouce for producer
     *
     * @param queue_producer_id
     * @param uniq_id
     */
    virtual void UnregisterQueueProd(uint32_t queue_consumer_id, uint32_t uniq_id) = 0;

    // atomic interface , for debug
    /**
     * @brief read atomic ,for debug
     *
     */
    virtual uint32_t ReadAtomic(uint32_t atomic_id) = 0;
    /**
     * @brief clear atomic
     *
     */
    virtual void IncSelfIncrMem(uint32_t atomic_id) = 0;
    /**
     * @brief Set the Cf Mst Ots object, for debug
     *
     */
    virtual uint32_t SetCfMstOts(uint32_t ostd) = 0;
    /**
     * @brief Get the Max Ots Num object
     *
     * @return uint32_t
     */
    virtual uint32_t GetMaxOtsNum() = 0;
    /**
     * @brief wait idle status
     *
     */
    virtual bool WaitIdle(int timeout) = 0;
    /**
     * @brief check clock status
     *
     */
    virtual void ClockDisable() = 0;
    /**
     * @brief clock enable
     *
     */
    virtual void ClockEnable() = 0;

    // virtual void ClrEnable() = 0;
    /*
     * @brief operation vg reset
     *
     */
    virtual void VgReset(uint8_t vg) = 0;
    /*
     * @brief add interrupt exception
     *
     */
    // virtual bool InterrputException(const HwsyncIntStatusChk &hwsync_in_status) = 0;
    virtual bool InterrputException(uint32_t status_index) = 0;
    /**
     * @brief check all interrupt exception, if not 0, clear all
     *
     */
    virtual void CheckInterruptAndClear() = 0;
    /**
     * @brief validation done, clear current interrupt exception
     *
     */
    // virtual void ClearCurrentInterruptException(uint32_t status_index) = 0;
    /**
     * @brief Set the Ih Cause Addr object
     *
     * @param addr
     */
    virtual void SetIhCauseAddr(uint32_t addr) = 0;
    /**
     * @brief enable interrupt
     *
     * @return true
     * @return false
     */
    virtual void EnableInterrupt() = 0;
    /**
     * @brief disable interrupt
     *
     * @return true
     * @return false
     */
    virtual void DisableInterrupt() = 0;
    /**
     * @brief vf is 4, check hwsync vf softreset
     *
     * @param vg_id
     */
    virtual void VfRes(uint32_t vg_id) = 0;
};

}  // namespace hwsync
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_HWSYNC_HWSYNC_H_
