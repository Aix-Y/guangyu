/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_INCLUDE_IH_H_
#define HARDWARE_INCLUDE_IH_H_

#include <cstdint>
#include <map>
#include <memory>
#include <string>
#include <vector>
#include "framework/include/mem.h"
#include "hardware/include/hardware.h"

using efvf::framework::mem::Mem;
using efvf::framework::mem::MemType;

namespace efvf {
namespace hardware {
namespace ih {

typedef struct _IrqEntry {
    std::string msg_type   = "";  // rpc, dbg, irq, malformed/asid
    uint32_t    timestamp  = 0;
    uint32_t    ip_info    = 0;  // added in libra project, asid or thread slot id of sip
    uint32_t    context_id = 0;
    uint32_t    rsvd       = 0;
    uint32_t    die_id     = 0;
    uint32_t    master_id  = 0;
    uint32_t    cause_id   = 0;
    uint32_t    userdata   = 0;
    uint32_t    card_index = 0;
} IrqEntry;

typedef struct _RpcEntry {
    std::string msg_type   = "";  // rpc, dbg, irq, malformed/asid
    uint32_t    timestamp  = 0;
    uint32_t    ip_info    = 0;  // added in libra project, asid or thread slot id of sip
    uint32_t    context_id = 0;
    uint32_t    rsvd       = 0;
    uint32_t    die_id     = 0;
    uint32_t    master_id  = 0;
    uint32_t    data0      = 0;
    uint32_t    data1      = 0;
    uint32_t    dummy      = 0;
    uint32_t    card_index = 0;
} RpcEntry;

typedef struct _DbgEntry {
    std::string msg_type   = "";  // rpc, dbg, irq, malformed/asid
    uint32_t    timestamp  = 0;
    uint32_t    context_id = 0;
    uint32_t    rsvd       = 0;
    uint32_t    die_id     = 0;
    uint32_t    master_id  = 0;
    uint32_t    dbg_data   = 0;
    uint32_t    card_index = 0;
} DbgEntry;

typedef struct _RingConfig {
 public:
    bool                 with_kmd       = false;
    uint32_t             ring_id        = 0;
    std::string          ring_loc       = "";  // host or dmem
    std::string          ring_type      = "";  // irq, rpc, debug
    uint32_t             ring_entry_num = 0x1000;
    uint32_t             ring_size_byte = 0x4000;
    std::shared_ptr<Mem> ring_mem       = nullptr;
} RingConfig;

class Ih : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    Ih() : Hardware() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit Ih(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~Ih() {}

    /**
     * @brief      Sets the ring location.
     *
     * @param[in]  loc   The new value
     */
    virtual void SetRingLoc(std::string loc) {}
    virtual void SetRingLoc(int num, std::string loc) {
        throw;
    }

    /**
     * @brief      Sets the ring type.
     *
     * @param[in]  type  The type
     */
    virtual void SetRingType(std::string type) {}
    virtual void SetRingType(int num, std::string type) {
        throw;
    }

    /**
     * @brief      Sets the ring entry number.
     *
     * @param[in]  num   The new value
     */
    virtual void SetRingEntryNum(uint64_t num) {}

    /**
     * @brief      Sets the mask.
     *
     * @param[in]  master_id  The master identifier
     */
    virtual void SetMaskArray(uint32_t master_id) {}

    /**
     * @brief      Sets the timer.
     *
     * @param[in]  timer  The timer
     */
    virtual void SetTimer(uint32_t timer) {}

    /**
     * @brief      get the timer.
     *
     * @param[in]  get trim timer value
     */
    virtual uint32_t GetTimer(void) {
        return 0;
    }

    /**
     * @brief      Sets the integer type mask.
     *
     * @param[in]  idx       The new value
     * @param[in]  cause_id  The cause identifier
     */
    virtual void SetIntTypeMask(uint32_t idx, uint32_t cause_id) {}

    /**
     * @brief      Sets the parity generate.
     *
     * @param[in]  status  The status
     */
    virtual void SetParityGen(uint32_t status) {}

    /**
     * @brief      Determines whether the specified number is ring idle.
     *
     * @param[in]  num   The number of ring
     *
     * @return     True if the specified number is ring idle, False otherwise.
     */
    virtual bool IsRingIdle(int num) {
        return false;
    }

    /**
     * @brief      Sets the ring en.
     *
     * @param[in]  num     The new value
     * @param[in]  status  The status
     */
    virtual void SetRingEn(int num, uint32_t status) {}

    /**
     * @brief      Gets the cause 0 address.
     *
     * @param[in]  num   The number
     *
     * @return     The cause 0 address.
     */
    virtual uint64_t GetCause0Addr(int num) {
        return 0;
    }

    /**
     * @brief      Sets the ring pool index.
     *
     * @param[in]  indx  The indx
     */
    virtual void SetPoolLLQNode(uint32_t idx, uint32_t node_num) {}

    /**
     * @brief      Sets the clock gate.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetClkGate(uint32_t val) {}

    /**
     * @brief      Sets the fake message data.
     *
     * @param[in]  data0  The data 0
     * @param[in]  data1  The data 1
     */
    virtual void SetFakeMsgData(uint32_t data0, uint32_t data1) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  num       The number
     * @param[in]  ctxid     The ctxid
     * @param[in]  masterid  The masterid
     */
    virtual void FakeMsgTrigger(int num, uint32_t ctxid, uint32_t masterid) {}

    /**
     * @brief      Prints an excp status.
     */
    virtual void PrintExcpStatus() {}

    /**
     * @brief      { function_description }
     */
    virtual void CleanExcp() {}

    /**
     * @brief      Finds a llq full.
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FindLLQFull() {
        return false;
    }

    /**
     * @brief      Finds a llq full.
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FindSramParity() {
        return false;
    }

    /**
     * @brief      Creates a ring.
     *
     * @param[in]  num   The number
     */
    virtual void CreateRing(int num) {}

    /**
     * @brief      Creates a ring.
     *
     * @param[in]  ring_id      Ring index
     * @param[in]  entry_num    Total ring entry numbers
     * @param[in]  ring_loc     Ring location
     * @param[in]  ring_type    Ring type
     *
     */
    virtual void CreateRing(int ring_id, uint32_t entry_num, const std::string ring_loc,
        const std::string ring_type) {}

    /**
     * @brief      Creates a ring.
     *
     * @param[in]  ring_cfg     Const Ring config
     *
     */
    virtual void CreateRing(const RingConfig &ring_cfg) {}

    /**
     * @brief      Get Drop counter.
     *
     * @param[in]  rind_id     Ring id
     *
     */
    virtual uint32_t GetDropCounter(uint32_t rind_id) {
        return 0;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  cause_id  The cause identifier
     * @param[in]  userdata  The userdata
     */
    virtual void TriggerIrq(uint32_t cause_id, uint32_t userdata) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  num       The number
     * @param[in]  cause_id  The cause identifier
     * @param[in]  userdata  The userdata
     */
    virtual void TriggerIrq(int num, uint32_t cause_id, uint32_t userdata) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  num       The number
     * @param[in]  cause_id  The cause identifier
     * @param[in]  userdata  The userdata
     */
    virtual void TriggerRpc(int num, uint32_t cause0, uint32_t cause1) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  num   The number
     * @param[in]  data  The data
     */
    virtual void TriggerDbg(int num, uint32_t data) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  master_id    The master identifier
     * @param[in]  cause_id     The cause identifier
     * @param      entry        The entry
     * @param[in]  timeout_sec  The timeout security
     * @param[in]  asid         The matched asid
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitForIrq(uint32_t master_id, uint32_t cause_id, IrqEntry *entry,
        int timeout_sec, uint32_t asid = 0) {
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  num          The number
     * @param[in]  die_id       The die identifier
     * @param[in]  master_id    The master identifier
     * @param[in]  cause_id     The cause identifier
     * @param      entry        The entry
     * @param[in]  timeout_sec  The timeout security
     * @param[in]  asid         The matched asid
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitForIrq(int num, uint32_t die_id, uint32_t master_id, uint32_t cause_id,
        IrqEntry *entry, int timeout_sec, uint32_t asid = 0) {
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  num          The number
     * @param[in]  die_id       The die identifier
     * @param[in]  master_id    The master identifier
     * @param      entry        The entry
     * @param[in]  timeout_sec  The timeout security
     * @param[in]  asid         The matched asid
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitForRpc(int num, uint32_t die_id, uint32_t master_id, RpcEntry *entry,
        int timeout_sec, uint32_t asid = 0) {
        return false;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  num          The number
     * @param[in]  die_id       The die identifier
     * @param[in]  master_id    The master identifier
     * @param      entry        The entry
     * @param[in]  timeout_sec  The timeout security
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitForDbg(
        int num, uint32_t die_id, uint32_t master_id, DbgEntry *entry, int timeout_sec) {
        return false;
    }

    virtual int GetTotalRingNum() {
        return 16;
    }

    virtual std::map<uint32_t, std::vector<IrqEntry>> DumpIrqEntry(int num) {
        return std::map<uint32_t, std::vector<IrqEntry>>();
    }

    virtual std::map<uint32_t, std::vector<RpcEntry>> DumpRpcEntry(int num) {
        return std::map<uint32_t, std::vector<RpcEntry>>();
    }

    virtual std::map<uint32_t, std::vector<DbgEntry>> DumpDbgEntry(int num) {
        return std::map<uint32_t, std::vector<DbgEntry>>();
    }

    /**
     * @brief      Gets one interrupt.
     *
     * @param[in]  num    The number
     * @param      entry  The entry
     *
     * @return     One interrupt.
     */
    virtual bool GetOneIrq(int num, IrqEntry *entry) {
        throw;
    }

    /**
     * @brief      Gets one rpc.
     *
     * @param[in]  num    The number
     * @param      entry  The entry
     *
     * @return     One rpc.
     */
    virtual bool GetOneRpc(int num, RpcEntry *entry) {
        throw;
    }

    /**
     * @brief      Gets one rpc.
     *
     * @param[in]  num    The number
     * @param      entry  The entry
     *
     * @return     One rpc.
     */
    virtual bool GetOneDbg(int num, DbgEntry *entry) {
        throw;
    }
};

}  // namespace ih
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_IH_H_
