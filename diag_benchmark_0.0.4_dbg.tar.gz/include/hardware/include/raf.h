/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_RAF_H_
#define HARDWARE_INCLUDE_RAF_H_

#include <map>
#include <memory>
#include <string>
#include <vector>
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace raf {
typedef struct _AxProt_Checker {
    bool axprot_inst_chk;
    bool axprot_data_chk;
    bool axprot_secure_chk;
    bool axprot_unpriv_chk;
    bool axprot_privi_chk;
} AxProt_Checker_t;

typedef enum RW_TYPE { Read = 0, Write } RW_TYPE_e;

typedef struct _Err_Log {
    RW_TYPE_e rw_type;
    uint32_t  ax_user;
    uint32_t  ax_prot;
    uint32_t  axaddr;
} Err_Log_t;

class AddrRegion {
 public:
    /**
     * @brief Construct a new Addr Region object
     *
     * @param raf the raf
     * @param idx the address region index
     */
    AddrRegion(Hardware *raf, int idx)
        : raf_(raf), idx_(idx), base_(0), logger_(raf->get_logger()) {}

    /**
     * @brief Destroy the Addr Region object
     *
     */
    virtual ~AddrRegion() {}

    /**
     * @brief Set the Region's Start Addr
     *
     * @param start
     */
    virtual void SetStartAddr(uint64_t start) = 0;

    /**
     * @brief Set the Region End Addr
     *
     * @param end
     */
    virtual void SetEndAddr(uint64_t end) = 0;

    /**
     * @brief Set the Master Mask
     *        block / allow specified masters.
     * @param ipmask -- each bit indicate a master
     * @param block  -- action applied to the master: block(1) or allow(0)
     */
    virtual void SetMasterMask(uint64_t ipmask, bool block = true) = 0;

    /**
     * @brief Set the Master Mask
     *        block / allow specified masters.
     * @param ips   -- ip name lists
     * @param block -- action applied to the master: block(1) or allow(0)
     */
    virtual void SetMasterMask(const std::vector<std::string> &ips, bool block = true) = 0;

    /**
     * @brief Set the Secure Level Checker
     *
     * @param level -- permitted secure level
     *        secure_level >= permited level is allowed
     */
    virtual void SetSecuLevelChecker(uint32_t level) = 0;

    /**
     * @brief Set the AxProt Checker
     *
     * @param check
     */
    virtual void SetAxProtChecker(AxProt_Checker_t check) = 0;

    /**
     * @brief Set the Read Checker
     *
     * @param rd_check
     */
    virtual void SetReadChecker(bool enable) = 0;

    /**
     * @brief Set the Write Checker
     *
     * @param wr_check
     */
    virtual void SetWriteChecker(bool enable) = 0;

    virtual uint32_t GetIndex() {
        return idx_;
    }

 protected:
    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint64_t offset);

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     * @param[in]  val     The value
     */
    virtual void RegWrite(uint64_t offset, uint32_t val);

 protected:
    Hardware *raf_;
    int32_t   idx_;
    uint32_t  base_;  // base offset of the region relative of first region
    std::shared_ptr<spdlog::logger> logger_;
};

class Raf : public Hardware {
 public:
    /**
    * @brief Construct new object of register-access-filter
    */
    explicit Raf(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief Destroy the object.
     */
    virtual ~Raf();

    virtual void Enable();
    virtual void Disable();

    virtual void InterruptEnable();
    virtual void InterruptDisable();

    virtual bool SetMasterSecureLevel(uint32_t level, std::string &master);
    virtual bool SetAllMasterSecureLevel(uint32_t level);

    virtual std::shared_ptr<AddrRegion> AllocAddrRegion(int idx = -1);
    virtual std::shared_ptr<AddrRegion> AllocDefaultRegion();

    virtual std::vector<Err_Log_t> GetErrorLog(bool clear = true);
    virtual void ClearErrorLog();

    virtual std::map<std::string, uint32_t> &GetMasterIdMap() {
        return master_id_map_;
    }

    virtual uint32_t GetRegionCount() {
        return addr_region_cnt_;
    }

    /**
     * @brief wait until raf out_standing all clean.
     *  this is a WAR for libra RAF,
     *  refer to SE-20 for details.
     *
     * @param time_out_ms
     * @return true
     * @return false
     */
    virtual bool WaitOstClean(uint32_t time_out_ms = 10) {
        (void)time_out_ms;
        return true;
    }

 protected:
    uint32_t addr_region_cnt_ = 16; /* TODO: whether all IP's RAF has 16 addr_region ?? */
    std::map<int, std::shared_ptr<AddrRegion>> address_regions_;
    std::shared_ptr<AddrRegion> default_region_;

    // master name to initiator id map
    // "sic0" : 1; "sic1" : 2, ... "sic7" : 8
    std::map<std::string, uint32_t> master_id_map_;
};

}  // namespace raf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_RAF_H_
