/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MDMA_MDMA_COMP_HQS_QUEUE_H_
#define HARDWARE_INCLUDE_MDMA_MDMA_COMP_HQS_QUEUE_H_

#include "hardware/include/mdma/mdma_comp.h"

namespace efvf {
namespace hardware {
namespace mdma {

class MdmaCHqsQueue : public MdmaComp {
 public:
    explicit MdmaCHqsQueue(Mdma *dma, MdmaEngineCompDesc_t &desc) : MdmaComp(dma, desc) {}
    virtual ~MdmaCHqsQueue() {}
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MDMA_MDMA_COMP_HQS_QUEUE_H_
