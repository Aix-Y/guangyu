/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MDMA_MDMA_COMP_H_
#define HARDWARE_INCLUDE_MDMA_MDMA_COMP_H_

#include <memory>
#include <string>

#include "hardware/include/hardware.h"
#include "hardware/include/mdma/mdma_desc.h"

namespace efvf {
namespace hardware {
namespace mdma {

class MdmaComp : public Hardware {
 public:
    explicit MdmaComp(Mdma *, MdmaEngineCompDesc_t &);
    virtual ~MdmaComp() {}

    /**
     * @brief      comp access offset valid
     */
    virtual bool IsAddrValid(const uint32_t &);

    /**
     * @brief      comp ecf st addr fetch
     */
    virtual uint32_t GetEcfAddrSt(void);

    /**
     * @brief      comp ecf ed addr fetch
     */
    virtual uint32_t GetEcfAddrEd(void);

    /**
     * @brief      comp desc get string
     */
    virtual std::string GetDescStr(void);

    /**
     * @brief      comp desc gen string
     */
    virtual std::string GenDescStr(void);

    /**
     * @brief      comp desc gen string
     */
    virtual void HandleCfg(const MdmaCfg &);

    /**
     * @brief      comp distinguish engine
     */
    bool IsEngineSp(void) {
        return m_desc.IsEngineSp();
    }

    /**
     * @brief      comp distinguish engine
     */
    bool IsEngineAp(void) {
        return m_desc.IsEngineAp();
    }

    /**
     * @brief      comp distinguish engine
     */
    bool IsEngineCva(void) {
        return m_desc.IsEngineCva();
    }

    /**
     * @brief      comp distinguish engine
     */
    bool IsEngineVpp(void) {
        return m_desc.IsEngineVpp();
    }

    /**
     * @brief      comp distinguish engine
     */
    bool IsEngineVpu(void) {
        return m_desc.IsEngineVpu();
    }

    /**
     * @brief      comp distinguish engine
     */
    bool IsEngineSsm(void) {
        return m_desc.IsEngineSsm();
    }

    /**
     * @brief      comp distinguish self
     */
    bool IsCommon(void) {
        return m_desc.IsCommon();
    }

    /**
     * @brief      comp distinguish self
     */
    bool IsPolling(void) {
        return m_desc.IsPolling();
    }

    /**
     * @brief      comp distinguish self
     */
    bool IsVc(void) {
        return m_desc.IsVc();
    }

    /**
     * @brief      comp distinguish self
     */
    bool IsQueue(void) {
        return m_desc.IsQueue();
    }

    /**
     * @brief      comp distinguish self
     */
    bool IsHqsQueue(void) {
        return m_desc.IsHqsQueue();
    }

    /**
     * @brief      comp distinguish self
     */
    bool IsHqsTop(void) {
        return m_desc.IsHqsTop();
    }

    /**
     * @brief      comp distinguish self
     */
    bool IsMpq(void) {
        return m_desc.IsMpq();
    }

    /**
     * @brief      comp try to occupy
     */
    bool IsAvailable(void);

    /**
     * @brief      comp set free if you give it up
     */
    void SetAvailable(void);

    /**
     * @brief      comp check occupied
     */
    bool IsOccupied(void) {
        return m_occupied;
    }

    /**
     * @brief      comp get inst idx
     */
    uint32_t Inst(void) {
        return m_desc.inst;
    }

    /**
     * @brief      comp ef obj lock
     */
    void Lock(void) {
        obj_mut_.lock();
    }

    /**
     * @brief      comp ef obj unlock
     */
    void UnLock(void) {
        obj_mut_.unlock();
    }

    /**
     * @brief      comp reg read
     */
    virtual uint32_t hpd_regr32(uint32_t);

    /**
     * @brief      comp reg write
     */
    virtual void hpd_regw32(uint32_t, uint32_t);

 public:
    Mdma *               m_dma;
    Dtu *                m_dtu;
    Hpd *                m_hpd;
    MdmaEngineCompDesc_t m_desc;

 protected:
    bool    m_occupied = false;
    MdmaCfg m_last_cfg = {};
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MDMA_MDMA_COMP_H_
