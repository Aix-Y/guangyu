/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MDMA_MDMA_COMP_VC_H_
#define HARDWARE_INCLUDE_MDMA_MDMA_COMP_VC_H_

#include "hardware/include/mdma/mdma_comp.h"

namespace efvf {
namespace hardware {
namespace mdma {

class MdmaCVc : public MdmaComp {
 public:
    explicit MdmaCVc(Mdma *dma, MdmaEngineCompDesc_t &desc) : MdmaComp(dma, desc) {}
    virtual ~MdmaCVc() {}

    /**
     * @brief      manual trigger vc
     *
     * @param[in]  wait idle timeout(ms) default(10s) before trigger
     */
    virtual void Trigger(uint64_t = TIMEOUTMS_10S);

    /**
     * @brief      wait vc idle
     *
     * @param[in]  wait idle timeout(ms) default(10s)
     */
    virtual bool WaitIdle(uint64_t = TIMEOUTMS_10S);

    /**
     * @brief      check vc done
     */
    virtual bool IsVcDone(void);

    /**
     * @brief      clear vc done
     */
    virtual bool ClearVcDone(uint64_t = TIMEOUTMS_10S);

    /**
     * @brief      check vc on-going
     */
    virtual bool IsVcOngoing(void);
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MDMA_MDMA_COMP_VC_H_
