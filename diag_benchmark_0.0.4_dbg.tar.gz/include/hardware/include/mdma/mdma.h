/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_MDMA_MDMA_H_
#define HARDWARE_INCLUDE_MDMA_MDMA_H_

#include <memory>
#include <utility>
#include <vector>

#include "hardware/include/mdma/mdma_comp.h"
#include "hardware/include/mdma/mdma_comp_common.h"
#include "hardware/include/mdma/mdma_comp_hqs_queue.h"
#include "hardware/include/mdma/mdma_comp_hqs_top.h"
#include "hardware/include/mdma/mdma_comp_mpq.h"
#include "hardware/include/mdma/mdma_comp_polling.h"
#include "hardware/include/mdma/mdma_comp_queue.h"
#include "hardware/include/mdma/mdma_comp_vc.h"

namespace efvf {
namespace hardware {
namespace mdma {

class Mdma : public Hardware {
 public:
    /**
     * @brief      mcu dma constructor
     *
     * @param[in]  logger
     */
    explicit Mdma(std::shared_ptr<spdlog::logger> logger) : Hardware(logger) {}

    /**
     * @brief      mcu dma desctructor
     */
    virtual ~Mdma() {}

    /**
     * @brief      mcu dma engine type support check
     */
    virtual bool IsEngineSupport(const MdmaEngine_t &);

    /**
     * @brief      mcu dma engine type specify
     */
    virtual bool SetEngineType(const MdmaEngine_t &);

    /**
     * @brief      mcu dma engine comp fetch max num
     */
    virtual uint32_t GetEngineCompNum(const MdmaComp_t &);

    /**
     * @brief      mcu dma engine comp fetch by type.inst
     *
     * @param[in]  comp type and inst index (default inst.0)
     */
    virtual std::shared_ptr<MdmaComp> GetEngineComp(const MdmaComp_t &, uint32_t = 0);

    /**
     * @brief      mcu dma engine config
     *
     * @param[in]  comp type vs cfg vs inst index (default inst.0)
     */
    virtual void CfgEngineComp(const MdmaComp_t &, const MdmaCfg &, uint32_t inst = 0);

    /**
     * @brief      dma linear copy
     *
     * @param[in]  src Engine view data source addr
     * @param[in]  dst Engine view data destination addr
     * @param[in]  siz Engine copy data bytes
     * @param[in]  vc  Engine vc inst idx (if not specified, pick available)
     *
     * @return     status [true] done or [false] error
     */
    virtual bool LinearCopy(const uint64_t &src, const uint64_t &dst, const uint32_t &siz,
        uint32_t vc = NON_SPECIFIED);

    /**
     * @brief config linear copy and trigger
     *
     * @param opt_cfg  mdma linear copy info
     *
     * @return         True if success, False otherwise.
     */
    virtual bool LinearCopy(const MdmaLinearCopyCfg &opt_cfg, uint32_t vc = NON_SPECIFIED) = 0;

    /**
     * @brief      dma constant filling
     *
     * @param[in]  dst Engine view data destination addr
     * @param[in]  siz Engine fill data bytes
     * @param[in]  pat Engine fill data pattern
     * @param[in]  vc  Engine vc inst idx (if not specified, pick available)
     *
     * @return     status [true] done or [false] error
     */
    virtual bool ConstFill(const uint64_t &dst, const uint32_t &siz, const uint32_t &pat,
        uint32_t vc = NON_SPECIFIED);

    /**
     * @brief config constant filling and trigger
     *
     * @param opt_cfg  mdma constant filling info
     *
     * @return         True if success, False otherwise.
     */
    virtual bool ConstFill(const MdmaConstFillCfg &opt_cfg, uint32_t vc = NON_SPECIFIED) = 0;

    /**
     * @brief      dma scatter
     *
     * @param[in]  des Engine view data descriptor addr
     * @param[in]  siz Engine view data descriptor size
     * @param[in]  vc  Engine vc inst idx (if not specified, pick available)
     *
     * @return     status [true] done or [false] error
     */
    virtual bool Scatter(
        const uint64_t &des, const uint32_t &siz, uint32_t vc = NON_SPECIFIED);

    /**
     * @brief config scatter and trigger
     *
     * @param opt_cfg  mdma scatter info
     *
     * @return         True if success, False otherwise.
     */
    virtual bool Scatter(const MdmaScatterCfg &opt_cfg, uint32_t vc = NON_SPECIFIED) = 0;

    /**
     * @brief      dma scatter derived
     *
     * @param[in]  des_t Engine view data descriptor addr template
     * @param[in]  des_d Engine view data descriptor addr derived
     * @param[in]  siz_t Engine view size descriptor template
     * @param[in]  siz_d Engine view size descriptor derived
     * @param[in]  vc    Engine vc inst idx (if not specified, pick available)
     *
     * @return     status [true] done or [false] error
     */
    virtual bool ScatterDerived(const uint64_t &des_t, const uint64_t &des_d, uint32_t &siz_t,
        uint32_t &siz_d, uint32_t vc = NON_SPECIFIED);

    /**
     * @brief config derived scatter and trigger
     *
     * @param opt_cfg  mdma derived scatter info
     *
     * @return         True if success, False otherwise.
     */
    virtual bool ScatterDerived(
        const MdmaScatterDerivedCfg &opt_cfg, uint32_t vc = NON_SPECIFIED) = 0;

    /**
     * @brief      dma gather
     *
     * @param[in]  des Engine view data descriptor addr
     * @param[in]  dst Engine view data gather-dat addr
     * @param[in]  vc  Engine vc inst idx (if not specified, pick available)
     *
     * @return     status [true] done or [false] error
     */
    virtual bool Gather(const uint64_t &des, const uint32_t &dst, uint32_t vc = NON_SPECIFIED);

    /**
     * @brief config gather and trigger
     *
     * @param opt_cfg  mdma gather info
     *
     * @return         True if success, False otherwise.
     */
    virtual bool Gather(const MdmaGatherCfg &opt_cfg, uint32_t vc = NON_SPECIFIED) = 0;

    /**
     * @brief   flush command queue
     *
     * @return  True if success, False otherwise.
     */
    virtual bool CmdQueueFlush(uint32_t qid = NON_SPECIFIED) = 0;

    /**
     * @brief write mcp to command queue
     *
     * @param mcp    mdma command pointer info
     *
     * @return       True if success, False otherwise.
     */
    virtual bool CmdQueueLaunchCmd(
        const MdmaCommandPointer &mcp, uint32_t qid = NON_SPECIFIED) = 0;
    /**
     * @brief    check command queue is empty
     *
     * @return   True if empty ,false if has mcp
     */
    virtual bool CmdQueueIsEmpty(uint32_t qid = NON_SPECIFIED) = 0;
    /**
     * @brief    check command queue is full
     *
     * @return   True if full ,false if has free
     */
    virtual bool CmdQueueIsFull(uint32_t qid = NON_SPECIFIED) = 0;

    /**
     * @brief    get command queue free size
     *
     * @return   free size
     */
    virtual uint32_t CmdQueueFreeSize(uint32_t qid = NON_SPECIFIED) = 0;

    /**
     * @brief   get command queue used queue
     *
     * @return  used size
     */
    virtual uint32_t CmdQueueUsedSize(uint32_t qid = NON_SPECIFIED) = 0;

    /**
     * @brief build scatter descriptor
     *
     * @param scatter_info <uint64_t, uint32_t> represents destination <addr,data>
     * @param offset_flag  offset flag
     * @param sig_res_flag signal resource flag
     * @param desc_data    descriptor data
     * @param desc_len     descriptor len
     *
     * @return             True if success, False otherwise.
     */
    virtual bool BuildScatterDesc(
        const std::vector<std::pair<uint64_t, uint32_t>> &scatter_info, const bool offset_flag,
        const std::vector<bool> &sig_res_flag, uint32_t *desc_data, uint32_t &desc_len) = 0;

    /**
     * @brief build Derived Scatter descriptor
     * derived descriptor just have data
     * when template desc TDC=1, will use derived desc corresponding data
     * @param template_info        represents template info <addr,data>
     * @param offset_flag          offset flag
     * @param sig_res_flag         signal resource flag
     * @param template_desc_data   template descriptor data
     * @param template_desc_len    template descriptor len
     * @param derived_info         represents derived info
     * @param derived_desc_data    derived descriptor data
     * @param derived_desc_len     derived descriptor len
     *
     * @return             True if success, False otherwise.
     */
    virtual bool BuildScatterDerivedDesc(
        const std::vector<MdmaScatterTemplateInfo> &template_info, const bool offset_flag,
        const std::vector<bool> &sig_res_flag, uint32_t *template_desc_data,
        uint32_t &template_desc_len, const std::vector<uint32_t> &derived_info,
        uint32_t *derived_desc_data, uint32_t &derived_desc_len) = 0;

    /**
     * @brief build Gather descriptor
     *
     * @param gather_info  <uint64_t, uint32_t> represents src <addr,dwlen>
     * @param offset_flag  offset flag
     * @param desc_data    descriptor data
     * @param desc_len     descriptor len
     *
     * @return             True if success, False otherwise.
     */
    virtual bool BuildGatherDesc(const std::vector<std::pair<uint64_t, uint32_t>> &gather_info,
        const bool offset_flag, uint32_t *desc_data, uint32_t &desc_len) = 0;

    /**
     * @brief build LinearCopy Command
     * command consist of header and body
     * @param opt_cfg     linear copy cfg
     * @param cmd_data    Command data
     * @param cmd_len     Command len
     * @param last        Command last flag
     *
     * @return            True if success, False otherwise.
     */
    virtual bool BuildLinearCopyCmd(const MdmaLinearCopyCfg &opt_cfg, uint32_t *cmd_data,
        uint32_t &cmd_len, bool last = false) = 0;

    /**
     * @brief build Scatte Command
     * command consist of header and body
     * @param opt_cfg     Scatte cfg
     * @param cmd_data    Command data
     * @param cmd_len     Command len
     * @param last        Command last flag
     *
     * @return            True if success, False otherwise.
     */
    virtual bool BuildScatterCmd(const MdmaScatterCfg &opt_cfg, uint32_t *cmd_data,
        uint32_t &cmd_len, bool last = false) = 0;

    /**
     * @brief build Derived Scatter Command
     * command consist of header and body
     * @param opt_cfg     Derived Scatter cfg
     * @param cmd_data    Command data
     * @param cmd_len     Command len
     * @param last        Command last flag
     *
     * @return            True if success, False otherwise.
     */
    virtual bool BuildDerivedScatterCmd(const MdmaScatterDerivedCfg &opt_cfg,
        uint32_t *cmd_data, uint32_t &cmd_len, bool last = false) = 0;

    /**
     * @brief      mcu dma engine comp fetch specified/available
     */
    virtual std::shared_ptr<MdmaCCommon> GetCommon(uint32_t = NON_SPECIFIED);

    /**
     * @brief      mcu dma engine comp fetch specified/available
     */
    virtual std::shared_ptr<MdmaCPolling> GetPolling(uint32_t = NON_SPECIFIED);

    /**
     * @brief      mcu dma engine comp fetch specified/available
     */
    virtual std::shared_ptr<MdmaCVc> GetVc(uint32_t = NON_SPECIFIED);

    /**
     * @brief      mcu dma engine comp fetch specified/available
     */
    virtual std::shared_ptr<MdmaCQueue> GetQueue(uint32_t = NON_SPECIFIED);

    /**
     * @brief      mcu dma engine comp fetch specified/available
     */
    virtual std::shared_ptr<MdmaCHqsQueue> GetHqsQueue(uint32_t = NON_SPECIFIED);

    /**
     * @brief      mcu dma engine comp fetch specified/available
     */
    virtual std::shared_ptr<MdmaCHqsTop> GetHqsTop(uint32_t = NON_SPECIFIED);

    /**
     * @brief      mcu dma engine comp fetch specified/available
     */
    virtual std::shared_ptr<MdmaCMpq> GetMpq(uint32_t = NON_SPECIFIED);

    /**
     * @brief      mcu dma engine lock
     */
    void Lock(void) {
        obj_mut_.lock();
    }

    /**
     * @brief      mcu dma engine unlock
     */
    void UnLock(void) {
        obj_mut_.unlock();
    }
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MDMA_MDMA_H_
