/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file mailbox_intf.h
    \brief define a common mailbox lib
 */

#ifndef HARDWARE_INCLUDE_MAILBOX_H_
#define HARDWARE_INCLUDE_MAILBOX_H_

#include <cstdint>
#include <map>
#include <memory>
#include <ostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

#include "customize/customize.h"

namespace efvf {
namespace hardware {
namespace mailbox {

#if 0
/**
 * @brief mailbox status registers
 * this sturct defined the fields in MAIL_BOX_STATUS0 & MAIL_BOX_STATUS_1
 * only scorpio has two mailbox status register
 */
struct MbxStatusReg {
#if BYTE_ORDER == LITTLE_ENDIAN
    /// MAIL_COUNTER field of MAIL_BOX_STATUS_0
    uint32_t mail_counter : 16;
    /// REF field of MAIL_BOX_STATUS_0
    uint32_t ref : 16;
    /// INC_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t inc_mode_config : 1;
    /// TRG_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t trg_mode_config : 1;
    /// CRE_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t cre_mode_config : 1;
    /// UDP_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t udp_mode_config : 2;
    /// UNIQ_ID field of MAIL_BOX_STATUS_1
    uint32_t uniq_id_config : 7;
    /// MASTER_ID field of MAIL_BOX_STATUS_0
    uint32_t master_id : 10;
    uint32_t : 10;
#elif BYTE_ORDER == BIG_ENDIAN
    uint32_t : 10;
    /// MASTER_ID field of MAIL_BOX_STATUS_0
    uint32_t master_id : 10;
    /// UNIQ_ID field of MAIL_BOX_STATUS_1
    uint32_t uniq_id_config : 7;
    /// UDP_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t udp_mode_config : 2;
    /// CRE_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t cre_mode_config : 1;
    /// TRG_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t trg_mode_config : 1;
    /// INC_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t inc_mode_config : 1;
    /// REF field of MAIL_BOX_STATUS_0
    uint32_t ref : 16;
    /// MAIL_COUNTER field of MAIL_BOX_STATUS_0
    uint32_t mail_counter : 16;
#endif

    /**
     * @brief default constructer
     * the default initialization values refer to register reset value
     */
    MbxStatusReg()
        : ref(0x1),
          mail_counter(0),
          master_id(0),
          uniq_id_config(0),
          udp_mode_config(0),
          cre_mode_config(0),
          trg_mode_config(0),
          inc_mode_config(0) {}
};

/**
 * @brief mailbox status info returned by interface
 * 
 */
union MbxStatus {
    /// val of {status1, status0}
    uint64_t     val : 64;
    /// fields of registers
    MbxStatusReg reg;
    /**
     * @brief default constructor with reset val of register value in spec
     */
    MbxStatus() : val(0x100) {}

    /**
     * @brief constructor with register values of status0 and status1
     */
    MbxStatus(uint32_t status0, uint32_t status1) {
        val = (status1 << 32) | status0;
        // for fun
        // uint32_t x[2] = {status0, status1};
        // val = *reinterpret_cast<uint64_t*>(x);
    }

    /**
     * @brief override operator->
     * just for convilient
     * @return MbxStatusReg* 
     */
    MbxStatusReg* operator->() {
        return &reg;
    }
};
#else
/**
 * @brief mailbox status registers
 * this sturct defined the fields in MAIL_BOX_STATUS0 & MAIL_BOX_STATUS_1
 * only scorpio has two mailbox status register
 */
struct MbxStatus {
    /// MAIL_COUNTER field of MAIL_BOX_STATUS_0
    uint32_t mail_counter;
    /// REF field of MAIL_BOX_STATUS_0
    uint32_t ref;
    /// INC_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t inc_mode_config;
    /// TRG_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t trg_mode_config;
    /// CRE_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t cre_mode_config;
    /// UDP_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t udp_mode_config;
    /// UNIQ_ID field of MAIL_BOX_STATUS_1
    uint32_t uniq_id_config;
    /// MASTER_ID field of MAIL_BOX_STATUS_0
    uint32_t master_id;

    /**
     * @brief Construct a new Mbx Status object
     * default reset value of register
     */
    MbxStatus()
        : mail_counter(0),
          ref(0x1),
          inc_mode_config(0),
          trg_mode_config(0),
          cre_mode_config(0),
          udp_mode_config(0),
          uniq_id_config(0),
          master_id(0) {}

    std::vector<std::pair<std::string, uint32_t> > GenStringVec() {
        std::vector<std::pair<std::string, uint32_t> > ret;
        ret.emplace_back("Cnt", mail_counter);
        ret.emplace_back("Ref", ref);
        ret.emplace_back("Inc", inc_mode_config);
        ret.emplace_back("Trg", trg_mode_config);
        ret.emplace_back("Cre", cre_mode_config);
        ret.emplace_back("Upd", udp_mode_config);
        ret.emplace_back("Uniq", uniq_id_config);
        ret.emplace_back("Mst", master_id);
        return ret;
    }
};
#endif

/**
 * @brief mailbox error code returned
 * this struct defined the fields in MAIL_BOX_ERR_CODE_0 & MAIL_BOX_ERR_CODE_1
 * only scorpio has two mailbox error code register, so pavo/dorado will only
 * use code0 member vars.
 */
struct MbxErr {
    /// group id
    uint32_t group_id = 0;
    /// CODE_0 field of MAIL_BOX_ERR_CODE_0
    uint32_t code0 = 0;
    /// CODE_1 field of MAIL_BOX_ERR_CODE_1
    uint32_t code1 = 0;
    /// overflow err
    bool overflow_err = false;
    /// underflow err
    bool underflow_err = false;
    /// uniq_id mismatch err
    bool uniq_id_err = false;
    /// master id
    uint32_t master_id = 0;
    /// ref
    uint32_t ref = 0;
    /// counter
    uint32_t counter = 0;
    /// upd mode
    uint32_t upd_mode = 0;
    /// cre mode
    uint32_t cre_mode = 0;
    /// trg mode
    uint32_t trg_mode = 0;
    /// inc mode
    uint32_t inc_mode = 0;
    /// signaling uniq id
    uint32_t signaling_uniq_id = 0;
    /// mbx uniq id
    uint32_t mbx_uniq_id = 0;
    /// mbx id
    uint32_t mbx_id = 0;

    std::string GetErrInfoStr(const std::string &header) {
        std::ostringstream ss;
        ss << header << std::endl;
        ss << "mailbox group:     0x" << std::hex << group_id << std::endl;
        if (overflow_err) {
            ss << "err:               overflow" << std::endl;
        }
        if (underflow_err) {
            ss << "err:               underflow" << std::endl;
        }
        if (uniq_id_err) {
            ss << "err:               uniq id mismatch" << std::endl;
        }
        ss << "code 0:            0x" << std::hex << code0 << std::endl;
        ss << "code 1:            0x" << std::hex << code1 << std::endl;
        if (uniq_id_err) {
            ss << "master id:         0x" << std::hex << master_id << std::endl;
        }
        ss << "ref:               0x" << std::hex << ref << std::endl;
        ss << "counter:           0x" << std::hex << counter << std::endl;
        ss << "upd mode:          0x" << std::hex << upd_mode << std::endl;
        ss << "cre mode:          0x" << std::hex << cre_mode << std::endl;
        ss << "trg mode:          0x" << std::hex << trg_mode << std::endl;
        ss << "inc mode:          0x" << std::hex << inc_mode << std::endl;
        ss << "signaling uniq id: 0x" << std::hex << signaling_uniq_id << std::endl;
        ss << "mbx uniq id:       0x" << std::hex << mbx_uniq_id << std::endl;
        ss << "mbx id:            0x" << std::hex << mbx_id << std::endl;
        return ss.str();
    }
};

/**
 * @brief mailbox update mode type
 *
 */
enum MbxUpdMode {
    /// clear counter when triggered
    kWaitClear = 0,
    /// counter minus one when triggered
    kWaitMinusOne = 1,
    /// counter minus REF value when triggered
    kWaitMinusRef = 2,
};
/**
 * @brief mailbox credit mode
 *
 */
enum MbxCreMode {
    /// initial mailbox counter would be set to 0
    kSetZero = 0,
    /// initial mailbox counter would be set to REF
    kSetRef = 1,
};
/**
 * @brief mailbox trigger mode
 *
 */
enum MbxTrgMode {
    /// trigger signal is asserted when counter equal or larger than reference number
    kTrgGeRef = 0,
    /// trigger signal is asserted once counter is larger than zero
    kTrgGeZero = 1,
};
/**
 * @brief mailbox counter increment mode
 *
 */
enum MbxIncMode {
    /// counter will increment 1 when according entry is signaled
    kIncOne = 0,
    /// counter will increment REF when according entry is signaled
    kIncRef = 1,
};

/**
 * @brief mailbox config setting
 *
 */
struct MbxConfig {
    /// mailbox entry id
    uint32_t mb_id;
    /// uniq_id, only signal with same uniq_id will increase counter
    uint32_t uniq_id;
    /// ref value for trigger
    uint32_t ref;
    /// increase mode
    MbxIncMode inc_mode;
    /// trigger mode
    MbxTrgMode trg_mode;
    /// credit initialization mode
    MbxCreMode cre_mode;
    /// counter update mode while signal accepted
    MbxUpdMode upd_mode;

    /**
     * @brief Construct a new Mbx Config object
     *
     */
    MbxConfig()
        : mb_id(0),
          uniq_id(0),
          ref(0x1),
          inc_mode(MbxIncMode::kIncOne),
          trg_mode(MbxTrgMode::kTrgGeRef),
          cre_mode(MbxCreMode::kSetZero),
          upd_mode(MbxUpdMode::kWaitClear) {}
};

/**
 * @brief Mailbox Interface
 *
 */
class Mailbox {
 public:
    /**
     * @brief Destroy the Mailbox Interface object
     * pure virtual function
     */
    virtual ~Mailbox() {}

    /**
     * @brief entry size
     *
     * @return uint32_t
     */
    virtual uint32_t size() = 0;

    /**
     * @brief config a mailbox entry
     *
     * @param id entry id of mailbox to config
     * @param cfg configuration info
     */
    virtual void ConfigEntry(const MbxConfig &cfg) = 0;

    /**
     * @brief clear an entry of mailbox
     * clear entry counter by config entry with default configuration
     * @param id entry id
     */
    virtual void ClearEntry(uint32_t id) = 0;

    /**
     * @brief config all mailbox entry with same configuration
     * all mailbox entry will be configured with same paramter
     * all mailbox entry counter will be cleared
     * @param cfg configuration info
     */
    virtual void ConfigGlobalEntry(const MbxConfig &cfg) = 0;

    /**
     * @brief clear all mailbox entry
     * clear all entry counters by config all entry with default configuration
     */
    virtual void ClearGlobalEntry() = 0;

    /**
     * @brief send signal once
     *
     * @param id mailbox entry to send signal
     */
    virtual void SendSignal(uint32_t id) = 0;

    /**
     * @brief send signal with certain uniq id once
     *
     * @param id mailbox entry to send signal
     */
    virtual void SendSignal(uint32_t id, uint32_t uniq_id) = 0;

    /**
     * @brief      Gets the signal address.
     *
     * @return     The signal address.
     */
    virtual uint32_t GetSignalAddr() = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t GenSignalData(uint32_t id, uint32_t uniq_id) = 0;

    // virtual void SendSignalSeq(uint32_t id, uint32_t times)      = 0;

    /**
     * @brief send signal with certain credits
     * it may send multi signals to the entry, which depends on the entry configuration
     * it means the mailbox entry status checking will happen
     * @param id mailbox entry to send signal
     * @param uniq_id uniq id used for sending signal
     * @param credits total credits to send
     */
    virtual void SendSignalCredit(uint32_t id, uint32_t uniq_id, uint32_t credits) = 0;

    // sending signal and check error.
    // virtual bool SendSignalWithChk(uint32_t id)                         = 0;
    // virtual bool SendSignalSeqWithChk(uint32_t id, uint32_t times)      = 0;
    // virtual bool SendSignalCreditWithChk(uint32_t id, uint32_t credits) = 0;

    /**
     * @brief Get the Entry Status
     *
     * @param id entry id to get status
     * @return MbxStatus
     */
    virtual MbxStatus GetStatus(uint32_t id) = 0;

    /**
     * @brief Get the Entry Ref
     * get the ref value configured
     * @param id entry id to get ref
     * @return uint32_t
     */
    virtual uint32_t GetRef(uint32_t id) = 0;

    /**
     * @brief Get the Entry Mail Counter
     * get the mail counter of entry
     * @param id entry id to get mail counter
     * @return uint32_t
     */
    virtual uint32_t GetCounter(uint32_t id) = 0;

    /**
     * @brief Get the Master Id
     *
     * @return uint32_t
     */
    virtual uint32_t GetMasterId() = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  id    The identifier
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t WaitId(uint32_t id) = 0;

    // trace last mail, derived class mast make sure mbox status sel not touched
    // virtual void     TraceLastMailStart(uint32_t id) = 0;  // lock mutex?
    // virtual uint32_t GetLastMail()                   = 0;  // get status field
    // release the mutex
    // virtual void TraceLastMailStop() = 0;  // unlock?

    // chk error
    virtual uint32_t              GetErrRpt()   = 0;
    virtual std::vector<uint32_t> GetErrGroup() = 0;
    virtual bool ChkGroupErr(uint32_t group_id) = 0;
    virtual void GetErrInfo(uint32_t group_id, MbxErr *err_info) = 0;
    virtual void ClearErr()                                       = 0;
    virtual void ClearErr(uint32_t group_id)                      = 0;
    virtual void ClearErr(const std::vector<uint32_t> &group_ids) = 0;

    // for debug
    /**
     * @brief print an entry configuration to log
     *
     * @param id entry id to pring
     */
    virtual void PrintConfig(uint32_t id) = 0;

    /**
     * @brief print all entry configurations to log
     *
     */
    virtual void PrintAllConfig() = 0;

    /**
     * @brief print an entry status to log
     *
     * @param id entry id to print
     */
    virtual void PrintStatus(uint32_t id) = 0;

    /**
     * @brief      Prints a status.
     */
    virtual void PrintStatus() = 0;

    /**
     * @brief print all entry status to log
     *
     */
    virtual void PrintAllStatus() = 0;

    /**
     * @brief print error info of a group to log
     *
     * @param group_id group id to print
     */
    virtual void PrintGroupErr(uint32_t group_id, const std::string &ip_desc = "") = 0;

    /**
     * @brief print error info of all groups to log
     *
     */
    virtual void PrintAllErr(const std::string &ip_desc = "") = 0;

    /**
     * @brief Get the Counter Max Value
     *
     * @return uint32_t
     */
    virtual uint32_t GetCounterMaxValue() = 0;
};

}  // namespace mailbox
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_MAILBOX_H_
