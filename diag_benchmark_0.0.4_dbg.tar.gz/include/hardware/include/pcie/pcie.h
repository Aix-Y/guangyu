/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_PCIE_PCIE_H_
#define HARDWARE_INCLUDE_PCIE_PCIE_H_

#include <map>
#include <memory>
#include <string>
#include <vector>
#include "hardware/include/hardware.h"
#include "hardware/include/ih.h"
#include "hardware/include/pcie/pcie_ras.h"
#include "hardware/include/rmc/rmc.h"
#include "hardware/include/system_adapter.h"
#include "hardware/pcie/pci_caps/pci_caps.h"
#include "hardware/pcie/pci_caps/pcie_capability.h"
#include "hardware/pcie/pci_caps/pcie_ext_caps_aer.h"
#include "hardware/pcie/pci_caps/pcie_ext_caps_dpc.h"
#include "hardware/pcie/pci_caps/pcie_ext_caps_vsec_dorado.h"
#include "hardware/pcie/pci_caps/pcie_ext_caps_vsec_libra.h"
#include "hardware/pcie/pci_caps/pcie_ext_caps_vsec_pavo.h"
#include "hardware/pcie/pci_caps/pcie_ext_caps_vsec_scorpio.h"
#include "hardware/pcie/pci_caps/pcie_ext_resizable_bar.h"
#include "hardware/pcie/pci_caps/pcie_ext_sriov.h"

using efvf::hardware::ih::Ih;

using efvf::hardware::system_adapter::SystemAdapter;

// some reset test will require config space to be save/restored
const uint32_t SAVED_CFG_SPACE_SIZE = 0x40;  // 0x40 in DWords,256 Bytes

enum CFG_DEF {
    CFG_VENDOR_ID        = 0x00,
    CFG_DEVICE_ID        = 0x02,
    CFG_COMMAND          = 0x04,
    CFG_STATUS           = 0x06,
    CFG_REVISION_ID      = 0x08,
    CFG_CLASS_CODE       = 0x09,
    CFG_CLASS_CODE_SUB   = 0x0a,
    CFG_CLASS_CODE_BASE  = 0x0b,
    CFG_CACHE_LINE_SIZE  = 0x0c,
    CFG_LATENCY_TIMER    = 0x0d,
    CFG_HEADER_TYPE      = 0x0e,
    CFG_BIST             = 0x0f,
    CFG_BAR0_BASE_LO     = 0x10,
    CFG_BAR0_BASE_HI     = 0x14,
    CFG_BAR1_BASE_LO     = 0x18,
    CFG_BAR1_BASE_HI     = 0x1C,
    CFG_BAR2_BASE_LO     = 0x20,
    CFG_BAR2_BASE_HI     = 0x24,
    CFG_BASE_ADDR_1      = 0x10,
    CFG_BASE_ADDR_2      = 0x14,
    CFG_BASE_ADDR_3      = 0x18,
    CFG_BASE_ADDR_4      = 0x1C,
    CFG_BASE_ADDR_5      = 0x20,
    CFG_BASE_ADDR_6      = 0x24,
    CFG_ADAPTER_ID       = 0x2c,
    CFG_BIOS_ROM_CONTROL = 0x30,
    CFG_CAP_PTR          = 0x34,
    CFG_INTERRUPT_LINE   = 0x3c,
    CFG_INTERRUPT_PIN    = 0x3d,
    CFG_MIN_GNT          = 0x3e,
    CFG_MAX_LAT          = 0x3f,

    CFG_PRI_BUS_NUM       = 0x18,
    CFG_SEC_BUS_NUM       = 0x19,
    CFG_SUB_BUS_NUM       = 0x1a,
    CFG_SEC_LATENCY_TIMER = 0x1b,
    CFG_IO_BASE           = 0x1c,
    CFG_IO_LIMIT          = 0x1d,
    CFG_SEC_STATUS        = 0x1e,
    CFG_MEM_BASE          = 0x20,
    CFG_MEM_LIMIT         = 0x22,
    CFG_PRF_MEM_BASE      = 0x24,
    CFG_PRF_MEM_LIMIT     = 0x26,
    CFG_PRF_MEM_BASE_HI   = 0x28,
    CFG_PRF_MEM_LIMIT_HI  = 0x2C,
    CFG_IO_BASE_HI        = 0x30,
    CFG_IO_LIMIT_HI       = 0x32,
    CFG_BRIDGE_CONTROL    = 0x3e,
    CFG_EXT_CAP_PTR       = 0x100
};

typedef enum {
    S_DETECT_QUIET = 0,
    S_DETECT_ACT,
    S_POLL_ACTIVE,
    S_POLL_COMPLIANCE,
    S_POLL_CONFIG,
    S_PRE_DETECT_QUIET,
    S_DETECT_WAIT,
    S_CFG_LINKWD_START,
    S_CFG_LINKWD_ACEPT,
    S_CFG_LANENUM_WAI,
    S_CFG_LANENUM_ACEPT,
    S_CFG_COMPLETE,
    S_CFG_IDLE,
    S_RCVRY_LOCK,
    S_RCVRY_SPEED,
    S_RCVRY_RCVRCFG,
    S_RCVRY_IDLE,
    S_L0,
    S_L0S,
    S_L123_SEND_EIDLE,
    S_L1_IDLE,
    S_L2_IDLE,
    S_L2_WAKE,
    S_DISABLED_ENTRY,
    S_DISABLED_IDLE,
    S_DISABLED,
    S_LPBK_ENTRY,
    S_LPBK_ACTIVE,
    S_LPBK_EXIT,
    S_LPBK_EXIT_TIMEOUT,
    S_HOT_RESET_ENTRY,
    S_HOT_RESET,
    S_RCVRY_EQ0,
    S_RCVRY_EQ1,
    S_RCVRY_EQ2,
    S_RCVRY_EQ3
} LTSSM_STATUS;

// clang-format off
const std::map<uint32_t, const std::string> LtssmStr = {
    {S_DETECT_QUIET, "S_DETECT_QUIET"},
    {S_DETECT_ACT, "S_DETECT_ACT"},
    {S_POLL_ACTIVE, "S_POLL_ACTIVE"},
    {S_POLL_COMPLIANCE, "S_POLL_COMPLIANCE"},
    {S_POLL_CONFIG, "S_POLL_CONFIG"},
    {S_PRE_DETECT_QUIET, "S_PRE_DETECT_QUIET"},
    {S_DETECT_WAIT, "S_DETECT_WAIT"},
    {S_CFG_LINKWD_START, "S_CFG_LINKWD_START"},
    {S_CFG_LINKWD_ACEPT, "S_CFG_LINKWD_ACEPT"},
    {S_CFG_LANENUM_WAI, "S_CFG_LANENUM_WAI"},
    {S_CFG_LANENUM_ACEPT, "S_CFG_LANENUM_ACEPT"},
    {S_CFG_COMPLETE, "S_CFG_COMPLETE"},
    {S_CFG_IDLE, "S_CFG_IDLE"},
    {S_RCVRY_LOCK, "S_RCVRY_LOCK"},
    {S_RCVRY_SPEED, "S_RCVRY_SPEED"},
    {S_RCVRY_RCVRCFG, "S_RCVRY_RCVRCFG"},
    {S_RCVRY_IDLE, "S_RCVRY_IDLE"},
    {S_L0, "S_L0"},
    {S_L0S, "S_L0S"},
    {S_L123_SEND_EIDLE, "S_L123_SEND_EIDLE"},
    {S_L1_IDLE, "S_L1_IDLE"},
    {S_L2_IDLE, "S_L2_IDLE"},
    {S_L2_WAKE, "S_L2_WAKE"},
    {S_DISABLED_ENTRY, "S_DISABLED_ENTRY"},
    {S_DISABLED_IDLE, "S_DISABLED_IDLE"},
    {S_DISABLED, "S_DISABLED"},
    {S_LPBK_ENTRY, "S_LPBK_ENTRY"},
    {S_LPBK_ACTIVE, "S_LPBK_ACTIVE"},
    {S_LPBK_EXIT, "S_LPBK_EXIT"},
    {S_LPBK_EXIT_TIMEOUT, "S_LPBK_EXIT_TIMEOUT"},
    {S_HOT_RESET_ENTRY, "S_HOT_RESET_ENTRY"},
    {S_HOT_RESET, "S_HOT_RESET"},
    {S_RCVRY_EQ0, "S_RCVRY_EQ0"},
    {S_RCVRY_EQ1, "S_RCVRY_EQ1"},
    {S_RCVRY_EQ2, "S_RCVRY_EQ2"},
    {S_RCVRY_EQ3, "S_RCVRY_EQ3"}};
// clang-format on

typedef enum { IATU_OB, IATU_IB } IAtuType;

typedef struct _IAtuRegionCtx {
    uint32_t index;
    uint32_t type;
    uint32_t enable;
    uint32_t ctrl1;
    uint32_t ctrl2;
    uint64_t base_addr;
    uint64_t target_addr;
    uint64_t size;
} IAtuRegionCtx;

typedef enum { AER_UNCORR_ERROR, AER_CORR_ERROR } AerErrType;

// performance static enhance
enum {
    EDF_MASTER_READ_THROUGHPUT  = 1ULL << 0,
    EDF_MASTER_WRITE_THROUGHPUT = 1ULL << 1,
    EDF_SLAVE_READ_THROUGHPUT   = 1ULL << 2,
    EDF_SLAVE_WRITE_THROUGHPUT  = 1ULL << 3,

    // EVENT
    EDF_MASTER_READ_REQUEST   = 1ULL << 4,
    EDF_MASTER_READ_RESPONSE  = 1ULL << 5,
    EDF_MASTER_WRITE_REQUEST  = 1ULL << 6,
    EDF_MASTER_WRITE_RESPONSE = 1ULL << 7,
    EDF_SLAVE_READ_REQUEST    = 1ULL << 8,
    EDF_SLAVE_READ_RESPONSE   = 1ULL << 9,
    EDF_SLAVE_WRITE_REQUEST   = 1ULL << 10,
    EDF_SLAVE_WRITE_RESPONSE  = 1ULL << 11,

    ECF_MASTER_READ_REQUEST   = 1ULL << 12,
    ECF_MASTER_READ_RESPONSE  = 1ULL << 13,
    ECF_MASTER_WRITE_REQUEST  = 1ULL << 14,
    ECF_MASTER_WRITE_RESPONSE = 1ULL << 15,
    ECF_SLAVE_READ_REQUEST    = 1ULL << 16,
    ECF_SLAVE_READ_RESPONSE   = 1ULL << 17,
    ECF_SLAVE_WRITE_REQUEST   = 1ULL << 18,
    ECF_SLAVE_WRITE_RESPONSE  = 1ULL << 19,

    CORE_MASTER_READ_REQUEST   = 1ULL << 20,
    CORE_MASTER_READ_RESPONSE  = 1ULL << 21,
    CORE_MASTER_WRITE_REQUEST  = 1ULL << 22,
    CORE_MASTER_WRITE_RESPONSE = 1ULL << 23,
    CORE_SLAVE_READ_REQUEST    = 1ULL << 24,
    CORE_SLAVE_READ_RESPONSE   = 1ULL << 25,
    CORE_SLAVE_WRITE_REQUEST   = 1ULL << 26,
    CORE_SLAVE_WRITE_RESPONSE  = 1ULL << 27,

    // LATENCY
    INBOUND_EDF_READ_LATENCY   = 1ULL << (32 + 0),
    INBOUND_EDF_WRITE_LATENCY  = 1ULL << (32 + 1),
    OUTBOUND_EDF_READ_LATENCY  = 1ULL << (32 + 2),
    OUTBOUND_EDF_WRITE_LATENCY = 1ULL << (32 + 3),

    // DURATION
    DMA_DURATION = 1ULL << (32 + 4)
};

// security access control
typedef struct _SacInfo {
    _SacInfo()
        : index(0),
          region_enable(false),
          read_check(false),
          write_check(false),
          start_addr(0),
          end_addr(0) {}

    uint32_t index;
    bool     region_enable;
    bool     read_check;
    bool     write_check;
    uint32_t start_addr;
    uint32_t end_addr;
} SacInfo;

typedef enum {
    PERF_COUNTER_EVENT,
    PERF_COUNTER_TIME,
} PCIE_PERF_CNTR_TYPE;

typedef enum {
    PCIE_RESET_HOT,
    PCIE_RESET_FLR,
    PCIE_RESET_LINKDOWN,
} PCIE_RESET_TYPE;

typedef enum {
    // Group 0 (4bit Per-Lane)
    EVENT_EBUF_OVERFLOW         = 0x000,
    EVENT_EBUF_UNDERRUN         = 0x001,
    EVENT_DECODE_ERR            = 0x002,
    EVENT_RUNNING_DISPARITY_ERR = 0x003,
    EVENT_SKP_OS_PARITY_ERR     = 0x004,  // Gen3 Only
    EVENT_SYNC_HEADER_ERR       = 0x005,  // Gen3 or greater
    EVENT_RX_VALID_DEASSERTION  = 0x006,  // RxValid de-assertion without EIOSs
    EVENT_CTL_SKP_OS_PARITY_ERR = 0x007,  // Gen4
    EVENT_1_RETIMER_PARITY_ERR  = 0x008,  // Gen4
    EVENT_2_RETIMER_PARITY_ERR  = 0x009,  // Gen4
    EVENT_MARGIN_CRC_PARITY_ERR = 0x00A,  // Gen4

    // Group 1 (8bit Common-Lane)
    EVENT_DETECT_EI_INFER = 0x105,
    EVENT_RECEIVER_ERROR  = 0x106,
    EVENT_RX_RECOVERY_REQ = 0x107,  // When controller receives TS1 OS in L0s state
    EVENT_N_FTS_TIMEOUT   = 0x108,  // Timeout when controller's Rx condition is in Rx_L0s.FTS.
    EVENT_FRAMING_ERR     = 0x109,
    EVENT_DESKEW_ERR      = 0x10A,  // Gen3

    // Group 2 (8bit Common-Lane)
    EVENT_BAD_TLP             = 0x200,
    EVENT_LCRC_ERR            = 0x201,
    EVENT_BAD_DLLP            = 0x202,
    EVENT_REPLAY_NUM_ROLLOVER = 0x203,
    EVENT_REPLAY_TIMEOUT      = 0x204,
    EVENT_RX_NAK_DLLP         = 0x205,
    EVENT_TX_NAK_DLLP         = 0x206,
    EVENT_RETRY_TLP           = 0x207,

    // Group 3 (8bit Common-Lane)
    EVENT_FC_TIMEOUT         = 0x300,
    EVENT_POISONED_TLP       = 0x301,
    EVENT_ECRC_ERR           = 0x302,
    EVENT_UNSUPPORTED_REQ    = 0x303,
    EVENT_COMPLETER_ABORT    = 0x304,
    EVENT_COMPLETION_TIMEOUT = 0x305,

    // Group 4 (4bit Per-Lane)
    EVENT_EBUF_SKP_ADD = 0x400,
    EVENT_SKP_DEL      = 0x401,

    // Group 5 (32bit Common-Lane)
    EVENT_L0_TO_RECOVERY_ENTRY = 0x500,
    EVENT_L1_TO_RECOVERY_ENTRY = 0x501,
    EVENT_TX_L0S_ENTRY         = 0x502,
    EVENT_RX_L0S_ENTRY         = 0x503,
    EVENT_ASPM_L1_REJECT       = 0x504,
    EVENT_L1_ENTRY             = 0x505,
    EVENT_L1_CPM               = 0x506,
    EVENT_L1_1_ENTRY           = 0x507,
    EVENT_L1_2_ENTRY           = 0x508,
    EVENT_L1_SHORT_DURATION    = 0x509,
    EVENT_L1_2_ABORT           = 0x50A,
    EVENT_L2_ENTRY             = 0x50B,
    EVENT_SPEED_CHANGE         = 0x50C,
    EVENT_LINK_WIDTH_CHANGE    = 0x50D,

    // Group 6 (32bit)
    EVENT_TX_ACK_DLLP       = 0x600,
    EVENT_TX_UPDATE_FC_DLLP = 0x601,
    EVENT_RX_ACK_DLLP       = 0x602,
    EVENT_RX_UPDATE_FC_DLLP = 0x603,
    EVENT_RX_NULLIFIED_TLP  = 0x604,
    EVENT_TX_NULLIFIED_TLP  = 0x605,
    EVENT_RX_DUPLICATE_TLP  = 0x606,

    // Group 7 (32bit)
    EVENT_TX_MEM_WRITE  = 0x700,
    EVENT_TX_MEM_READ   = 0x701,
    EVENT_TX_CFG_WRITE  = 0x702,
    EVENT_TX_CFG_READ   = 0x703,
    EVENT_TX_IO_WRITE   = 0x704,
    EVENT_TX_IO_READ    = 0x705,
    EVENT_TX_CPL        = 0x706,
    EVENT_TX_CPLD       = 0x707,
    EVENT_TX_MSG_TLP    = 0x708,  // PCIE VC only
    EVENT_TX_ATOMIC     = 0x709,
    EVENT_TX_TLP_PREFIX = 0x70A,
    EVENT_RX_MEM_WRITE  = 0x70B,
    EVENT_RX_MEM_READ   = 0x70C,
    EVENT_RX_CFG_WRITE  = 0x70D,
    EVENT_RX_CFG_READ   = 0x70E,
    EVENT_RX_IO_WRITE   = 0x70F,
    EVENT_RX_IO_READ    = 0x710,
    EVENT_RX_CPL        = 0x711,
    EVENT_RX_CPLD       = 0x712,
    EVENT_RX_MSG_TLP    = 0x713,  // PCIE VC only
    EVENT_RX_ATOMIC     = 0x714,
    EVENT_RX_TLP_PREFIX = 0x715,
} PCIE_EVENT_CNTR;

typedef enum {
    EVENT_ALL = 0x0,

    // Group 0 (Low-Power Cycle Counter)
    EVENT_TX_L0S          = 0x01,
    EVENT_RX_L0S          = 0x02,
    EVENT_L0              = 0x03,
    EVENT_L1              = 0x04,
    EVENT_L1_1            = 0x05,
    EVENT_L1_2            = 0x06,
    EVENT_CONFIG_RECOVERY = 0x07,
    EVENT_TX_L0S_RX_L0S   = 0x08,
    EVENT_L1_AUX          = 0x09,

    // Group 1 (Throughput)
    EVENT_TX_TLP_PAYLOAD = 0x20,
    EVENT_RX_TLP_PAYLOAD = 0x21,
} PCIE_TIME_CNTR;

typedef enum {
    ENABLE_NO_CHANGE     = 0x0,
    ENABLE_PER_EVENT_OFF = 0x1,
    ENABLE_PER_EVENT_ON  = 0x3,
    ENABLE_ALL_EVENT_OFF = 0x5,
    ALL_EVENT_ON         = 0x7,
} PCIE_EVENT_ENABLE_TYPE;

typedef enum {
    CLEAR_NO_CHANGE = 0x0,
    CLEAR_PER_EVENT = 0x1,
    CLEAR_ALL_EVENT = 0x3,
} PCIE_EVENT_CLEAR_TYPE;

typedef enum {
    DURATION_MANUAL_CTRL = 0x0,
    DURATION_1MS         = 0x1,
    DURATION_10MS        = 0x2,
    DURATION_100MS       = 0x3,
    DURATION_1S          = 0x4,
    DURATION_2S          = 0x5,
    DURATION_4S          = 0x6,
    DURATION_4US         = 0xFF,  // Debug purpose
} PCIE_TIME_BASED_DURATION_TYPE;

namespace efvf {
namespace hardware {
namespace pcie {

class PcieSys : public Hardware {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    PcieSys() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit PcieSys(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~PcieSys() {}

    /**
     * @brief      Sets the initialize configuration.
     *
     * @param      cfg   The new value
     */
    virtual void set_init_cfg(void *cfg);

    /**
     * @brief      Gets the ih.
     *
     * @return     The ih.
     */
    virtual Ih *GetIh() = 0;

    /**
     * @brief      Gets the link width.
     *
     * @return     The link width.
     */
    virtual LinkWidth GetLinkWidth() = 0;

    /**
     * @brief      Sets the link width.
     *
     * @param[in]  val   The new value
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetLinkWidth(LinkWidth val) = 0;

    /**
     * @brief      { function_description }
     *
     * @return     The link width.
     */
    virtual LinkWidth MaxSupportedLinkWidth(void) = 0;

    /**
     * @brief      Gets the link speed.
     *
     * @return     The link speed.
     */
    virtual LinkSpeed GetLinkSpeed() = 0;

    /**
     * @brief      Sets the link speed.
     *
     * @param[in]  req_speed  The request speed
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetLinkSpeed(LinkSpeed req_speed) = 0;

    /**
     * @brief      Links a speed available.
     *
     * @param[in]  link_speed  The link speed
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool LinkSpeedAvailable(LinkSpeed link_speed) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  linkspeed  The linkspeed
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool RcLinkSpeedAvailable(LinkSpeed linkspeed);

    /**
     * @brief      { function_description }
     *
     * @return     The link speed.
     */
    virtual LinkSpeed MaxSupportedLinkSpeed(void) = 0;

    /**
     * @brief      { function_description }
     *
     * @return     The link speed.
     */
    virtual LinkSpeed MaxSupportedLinkSpeedRc(void);

    /**
     * @brief      { function_description }
     *
     * @return     The link width.
     */
    virtual LinkWidth MaxSupportedLinkWidthRc(void);

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint16_t PhysicalSlotID(void);

    /**
     * @brief      Determines if aspm enabled.
     *
     * @return     True if aspm enabled, False otherwise.
     */
    virtual bool IsASPMEnabled();

    /**
     * @brief      Enables the error reporting.
     *
     * @param[in]  flag  The flag
     */
    virtual void EnableErrorReporting(bool flag) = 0;

    /**
     * @brief      Gets the error reporting.
     *
     * @return     The error reporting.
     */
    virtual bool GetErrorReporting() = 0;

    /**
     * @brief      Reports an error.
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool ReportError();

    /**
     * @brief      Reports a rc error.
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool ReportRCError();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool CheckForRCCompletorAbort();

    /**
     * @brief      Initializes the error status.
     */
    virtual void InitializeErrorStatus();

    /**
     * @brief      Initializes the nak count.
     */
    virtual void InitNakCount() = 0;

    /**
     * @brief      Gets the nak count.
     *
     * @param      naks_gen  The naks generate
     * @param      naks_rec  The naks record
     *
     * @return     The nak count.
     */
    virtual bool GetNakCount(uint32_t &naks_gen, uint32_t &naks_rec) = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool CheckForUnsupportedRequests();

    /**
     * @brief      Reports error regs.
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool ReportErrorRegs();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool TriggerHotReset();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool TriggerLinkDownReset();

    /**
     * @brief      Sets the link reset mode.
     *
     * @param[in]  mode  The mode
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetLinkResetMode(uint32_t mode) = 0;

    /**
     * @brief      Gets the link reset mode.
     *
     * @return     The link reset mode.
     */
    virtual uint32_t GetLinkResetMode() = 0;

    /**
     * @brief      Resets the given reset type.
     *
     * @param[in]  reset_type  The reset type
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool Reset(PCIE_RESET_TYPE reset_type);

    /**
     * @brief      Resets the given reset.
     *
     * @param[in]  reset  The reset
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool Reset(std::string reset);

    /**
     * @brief      Determines whether the specified function is flr supported.
     *
     * @param[in]  fn    The function
     *
     * @return     True if the specified function is flr supported, False otherwise.
     */
    virtual bool IsFLRSupported(uint8_t fn) = 0;

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool TriggerFLR() = 0;

    /**
     * @brief      Sets the flr mode.
     *
     * @param[in]  fn    The new value
     * @param[in]  mode  The mode
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetFLRMode(uint8_t fn, uint32_t mode) = 0;

    /**
     * @brief      Gets the flr mode.
     *
     * @param[in]  fn    The function
     *
     * @return     The flr mode.
     */
    virtual uint32_t GetFLRMode(uint8_t fn) = 0;

    /**
     * @brief      Starts a performance counter.
     *
     * @param[in]  type      The type
     * @param[in]  id        The identifier
     * @param[in]  duration  The duration
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool StartPerfCounter(PCIE_PERF_CNTR_TYPE type, uint32_t id,
        PCIE_TIME_BASED_DURATION_TYPE duration = DURATION_MANUAL_CTRL) = 0;

    /**
     * @brief      Stops a performance counter.
     *
     * @param[in]  type      The type
     * @param[in]  id        The identifier
     * @param[in]  duration  The duration
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool StopPerfCounter(PCIE_PERF_CNTR_TYPE type, uint32_t id,
        PCIE_TIME_BASED_DURATION_TYPE duration = DURATION_MANUAL_CTRL) = 0;

    /**
     * @brief      { function_description }
     *
     * @param[in]  type  The type
     * @param[in]  id    The identifier
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool ClearPerfCounter(PCIE_PERF_CNTR_TYPE type, uint32_t id) = 0;

    /**
     * @brief      Gets the performance counter duration milliseconds.
     *
     * @return     The performance counter duration milliseconds.
     */
    virtual uint32_t GetPerfCounterDurationMs() = 0;

    /**
     * @brief      Sets the performance counter duration milliseconds.
     *
     * @param[in]  val   The new value
     */
    virtual void SetPerfCounterDurationMs(uint32_t val) = 0;

    /**
     * @brief      Gets the performance counter status.
     *
     * @param[in]  type  The type
     * @param[in]  id    The identifier
     *
     * @return     The performance counter status.
     */
    virtual bool GetPerfCounterStatus(PCIE_PERF_CNTR_TYPE type, uint32_t id) = 0;

    /**
     * @brief      Gets the performance counter data.
     *
     * @param[in]  type  The type
     * @param[in]  id    The identifier
     *
     * @return     picosecond
     */
    virtual uint64_t GetPerfCounterData(PCIE_PERF_CNTR_TYPE type, uint32_t id) = 0;

    /**
     * @brief      Gets the invalid register.
     *
     * @return     The invalid register.
     */
    virtual uint32_t GetInvalidReg() = 0;

    virtual const std::vector<uint32_t> GetScratchRegs() {
        return std::vector<uint32_t>();
    }

    virtual const std::vector<uint32_t> GetDieScratchRegs(uint32_t /*die_id*/) {
        return std::vector<uint32_t>();
    }

    /**
     * @brief      Enables the relax order.
     *
     * @param[in]  val   The value
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool EnableRelaxOrder(bool val) = 0;

    /**
     * @brief      Determines if hot plug interrupt supported.
     *
     * @return     True if hot plug interrupt supported, False otherwise.
     */
    virtual bool IsHotPlugInterruptSupported();

    /**
     * @brief      Gets the hot plug interrupt status.
     *
     * @return     The hot plug interrupt status.
     */
    virtual bool GetHotPlugInterruptStatus();

    /**
     * @brief      Enables the hot plug interrupt.
     *
     * @param[in]  enable  The enable
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool EnableHotPlugInterrupt(bool enable);

    /**
     * @brief      Gets the device.
     *
     * @return     The device.
     */
    virtual PcieDevice *GetDevice() {
        return m_dev;
    }

    /**
     * @brief      Gets the device parent.
     *
     * @return     The device parent.
     */
    virtual PcieDevice *GetParent() {
        return m_parent;
    }

    // trigger link speed change
    virtual void TriggerSpeedChange() {}

    /**
     * @brief      Gets the ltssm status.
     *
     * @return     The ltssm status.
     */
    virtual uint8_t GetLtssmStatus() {
        return 0;
    }

    /**
     * @brief      Gets the domain.
     *
     * @return     The domain.
     */
    virtual uint32_t GetDomain() {
        return (m_domain);
    }

    /**
     * @brief      Gets the bus.
     *
     * @return     The bus.
     */
    virtual uint8_t GetBus() {
        return (m_bus_num);
    }

    /**
     * @brief      Gets the dev.
     *
     * @return     The dev.
     */
    virtual uint8_t GetDev() {
        return (m_dev_num);
    }

    /**
     * @brief      Gets the fun.
     *
     * @return     The fun.
     */
    virtual uint8_t GetFun() {
        return (m_func_num);
    }

    /**
     * @brief      Gets the header type.
     *
     * @return     The header type.
     */
    virtual uint8_t GetHeaderType();

    /**
     * @brief      Gets the device id.
     *
     * @return     The device id.
     */
    virtual uint16_t GetDeviceID();

    /**
     * @brief      Gets the vendor id.
     *
     * @return     The vendor id.
     */
    virtual uint16_t GetVendorID();

    /**
     * @brief      Gets the command.
     *
     * @return     The command.
     */
    virtual uint16_t GetCommand();

    /**
     * @brief      Gets the status.
     *
     * @return     The status.
     */
    virtual uint16_t GetStatus();

    /**
     * @brief      Gets the revision id.
     *
     * @return     The revision id.
     */
    virtual uint8_t GetRevisionID();

    /**
     * @brief      Determines if valid.
     *
     * @return     True if valid, False otherwise.
     */
    virtual bool IsValid();

    /**
     * @brief      Gets the base class.
     *
     * @return     The base class.
     */
    virtual uint8_t GetBaseClass();

    /**
     * @brief      Gets the sub class.
     *
     * @return     The sub class.
     */
    virtual uint8_t GetSubClass();

    /**
     * @brief      Gets the rlpi class.
     *
     * @return     The rlpi class.
     */
    virtual uint8_t GetRLPIClass();

    /**
     * @brief      Gets the i/o space enable.
     *
     * @return     The i/o space enable.
     */
    virtual bool GetIOSpaceEnable();

    /**
     * @brief      Gets the memory space enable.
     *
     * @return     The memory space enable.
     */
    virtual bool GetMemorySpaceEnable();

    /**
     * @brief      Gets the bus master enable.
     *
     * @return     The bus master enable.
     */
    bool GetBusMasterEnable();

    /**
     * @brief      Gets the parity error response.
     *
     * @return     The parity error response.
     */
    virtual bool GetParityErrorResponse();

    /**
     * @brief      Gets the bridge parity error response.
     *
     * @return     The bridge parity error response.
     */
    virtual bool GetBridgeParityErrorResponse();

    /**
     * @brief      Gets the serr enable.
     *
     * @return     The serr enable.
     */
    virtual bool GetSERREnable();

    /**
     * @brief      Gets the bridge serr enable.
     *
     * @return     The bridge serr enable.
     */
    virtual bool GetBridgeSERREnable();

    /**
     * @brief      Gets the bridge vga enable.
     *
     * @return     The bridge vga enable.
     */
    virtual bool GetBridgeVGAEnable();

    /**
     * @brief      Gets the interrupt disable.
     *
     * @return     The interrupt disable.
     */
    virtual bool GetInterruptDisable();

    /**
     * @brief      Sets the i/o space enable.
     *
     * @param[in]  status  The status
     */
    virtual void SetIOSpaceEnable(bool status);

    /**
     * @brief      Sets the memory space enable.
     *
     * @param[in]  status  The status
     */
    virtual void SetMemorySpaceEnable(bool status);

    /**
     * @brief      Sets the bus master enable.
     *
     * @param[in]  status  The status
     */
    virtual void SetBusMasterEnable(bool status);

    /**
     * @brief      Sets the parity error response.
     *
     * @param[in]  status  The status
     */
    virtual void SetParityErrorResponse(bool status);

    /**
     * @brief      Sets the bridge parity error response.
     *
     * @param[in]  status  The status
     */
    virtual void SetBridgeParityErrorResponse(bool status);

    /**
     * @brief      Sets the serr enable.
     *
     * @param[in]  status  The status
     */
    virtual void SetSERREnable(bool status);

    /**
     * @brief      Sets the bridge serr enable.
     *
     * @param[in]  status  The status
     */
    virtual void SetBridgeSERREnable(bool status);

    /**
     * @brief      Sets the interrupt disable.
     *
     * @param[in]  status  The status
     */
    virtual void SetInterruptDisable(bool status);

    /**
     * @brief      Gets the memory bar.
     *
     * @return     The memory bar.
     */
    virtual uint64_t GetMemBar() {
        return 0;
    }

    /**
     * @brief      Gets the dev memory base.
     *
     * @return     The dev memory base.
     */
    virtual uint64_t GetDevMemBase() {
        return 0;
    }

    /**
     * @brief      Gets the dev memory size.
     *
     * @return     The dev memory size.
     */
    virtual uint64_t GetDevMemSize() {
        return 0;
    }

    virtual uint64_t GetDevCmemBase() {
        return 0;
    }

    virtual uint64_t GetDevCmemSize() {
        return 0;
    }

    /**
     * @brief      Gets the dev pcie edf base.
     *
     * @return     The dev pcie edf base.
     */
    virtual uint64_t GetDevPcieEdfBase() {
        return 0;
    }

    /**
     * @brief      Gets the dev pcie ecf base.
     *
     * @return     The dev pcie ecf base.
     */
    virtual uint64_t GetDevPcieEcfBase() {
        return 0;
    }

    /**
     * @brief      Gets i atu maximum region.
     *
     * @param[in]  type  The type
     *
     * @return     I atu maximum region.
     */
    virtual uint32_t GetIAtuMaxRegion(uint32_t type) {
        return 16;
    }

    /**
     * @brief      Sets i atu region.
     *
     * @param[in]  region  The region
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetIAtuRegion(IAtuRegionCtx region) {
        return true;
    }

    /**
     * @brief      Gets i atu region.
     *
     * @param      region  The region
     *
     * @return     I atu region.
     */
    virtual bool GetIAtuRegion(IAtuRegionCtx &region) {
        return true;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool TriggerAerError(AerErrType /* err_type */) {
        return false;
    }

    /**
     * @brief      Saves a configuration space.
     */
    virtual void SaveConfigSpace();

    /**
     * @brief      { function_description }
     */
    virtual void RestoreConfigSpace();

    /**
     * @brief      Dumps a configuration space.
     */
    virtual void DumpConfigSpace();

    /**
     * @brief      { function_description }
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void ConfigLinkWidth(uint8_t /*val*/) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitLinkUp(uint32_t /* timeout */) {
        return false;
    }

    /**
     * @brief      Gets the pcie application parity check en.
     *
     * @return     The pcie application parity check en.
     */
    virtual bool GetPcieAppParityChkEn() {
        return false;
    }

    /**
     * @brief      Sets the pcie application parity check en.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetPcieAppParityChkEn(bool /*val*/) {}

    /**
     * @brief      Gets the pcie parity other check en.
     *
     * @return     The pcie parity other check en.
     */
    virtual bool GetPcieParityOtherChkEn() {
        return false;
    }

    /**
     * @brief      Sets the pcie parity other check en.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetPcieParityOtherChkEn(bool /*val*/) {}

    /**
     * @brief      Gets the pcie automatic link en.
     *
     * @return     The pcie automatic link en.
     */
    virtual bool GetPcieAutoLinkEn(void) {
        return false;
    }

    /**
     * @brief      Sets the pcie automatic link en.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetPcieAutoLinkEn(bool /*val*/) {}

    /**
     * @brief      Gets the pcie ras dp en.
     *
     * @return     The pcie ras dp en.
     */
    virtual bool GetPcieRasDpEn(void) {
        return false;
    }

    /**
     * @brief      Sets the pcie ras dp en.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetPcieRasDpEn(bool /*val*/) {}

    /**
     * @brief      { function_description }
     */
    virtual void PcieExitRasDpMode(void) {}

    /**
     * @brief      Gets the pcie replace register.
     *
     * @return     The pcie replace register.
     */
    virtual uint32_t GetPcieReplaceReg() {
        return 0;
    }

    /**
     * @brief      Sets the pcie replace register.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetPcieReplaceReg(uint32_t val) {}

    virtual bool GetPcieRespCheckEn(void) {
        return false;
    }

    /**
     * @brief      Sets the pcie response check en.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetPcieRespCheckEn(bool /*val*/) {}

    /**
     * @brief      Gets the application integer master identifier.
     *
     * @return     The application integer master identifier.
     */
    virtual uint32_t GetAppIntMasterId() {
        return 0;
    }

    /**
     * @brief      Gets the application integer ecf cause identifier.
     *
     * @return     The application integer ecf cause identifier.
     */
    virtual uint32_t GetAppIntEcfCauseId() {
        return 0;
    }

    /**
     * @brief      Gets the pcie application dummy register address.
     *
     * @return     The pcie application dummy register address.
     */
    virtual uint32_t GetPcieAppDummyRegAddr() {
        return 0;
    }

    /**
     * @brief      Gets the pcie dbi dummy register address.
     *
     * @return     The pcie dbi dummy register address.
     */
    virtual uint32_t GetPcieDbiDummyRegAddr() {
        return 0;
    }

    /**
     * @brief      Gets the pcie phy dummy register address.
     *
     * @return     The pcie phy dummy register address.
     */
    virtual uint32_t GetPciePhyDummyRegAddr() {
        return 0;
    }

    /**
     * @brief      Gets the pcie pcie eh integer register.
     *
     * @return     The pcie pcie eh integer register.
     */
    virtual uint32_t GetPciePcieEhIntReg() {
        return 0;
    }

    /**
     * @brief      Sets the pcie eh integer register.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetPcieEhIntReg(uint32_t /*val*/) {}

    /**
     * @brief       Gets the Pcie iATU region group number.
     *
     * @return      the Pcie iATU region group number
     */
    virtual uint32_t GetPcieDbiAtuRgn() {
        return 0;
    }

    /**
     * @brief       Gets the Pcie iATU region MAX group number.
     *
     * @return      the Pcie iATU region MAX group number
     */
    virtual uint32_t GetPcieDbiMaxAtuRgn() {
        return 0;
    }

    /**
     * @brief       Set the Pcie iATU region group number.
     *
     * @param[in]   <unnamed> { parameter_description }
     */
    virtual void SetPcieDbiAtuRgn(uint32_t /*val*/) {}

    /**
     * @brief      Gets the pcie phy slv error integer.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The pcie phy slv error integer.
     */
    virtual bool GetPciePhySlvErrInt(uint32_t /*phy_id*/) {
        return false;
    }

    /**
     * @brief      Gets the pcie rasdp error integer.
     *
     * @return     The pcie rasdp error integer.
     */
    virtual bool GetPcieRasdpErrInt() {
        return false;
    }

    /**
     * @brief      Gets the pcie application slv error integer.
     *
     * @return     The pcie application slv error integer.
     */
    virtual bool GetPcieAppSlvErrInt() {
        return false;
    }

    /**
     * @brief      Gets the pcie dbi slv error integer.
     *
     * @return     The pcie dbi slv error integer.
     */
    virtual bool GetPcieDbiSlvErrInt() {
        return false;
    }

    /**
     * @brief      Gets the pcie axi slv error integer.
     *
     * @return     The pcie axi slv error integer.
     */
    virtual bool GetPcieAxiSlvErrInt() {
        return false;
    }

    /**
     * @brief      Gets the pcie eh mst wr integer.
     *
     * @return     The pcie eh mst wr integer.
     */
    virtual bool GetPcieEhMstWrInt() {
        return false;
    }

    /**
     * @brief      Gets the pcie control mst read integer.
     *
     * @return     The pcie control mst read integer.
     */
    virtual bool GetPcieCtrlMstReadInt() {
        return false;
    }

    /**
     * @brief      Gets the pcie control mst write integer.
     *
     * @return     The pcie control mst write integer.
     */
    virtual bool GetPcieCtrlMstWriteInt() {
        return false;
    }

    /**
     * @brief      Gets the pcie sac error integer.
     *
     * @return     The pcie sac error integer.
     */
    virtual bool GetPcieSacErrInt() {
        return false;
    }

    /**
     * @brief      Gets the pcie sac error information.
     *
     * @return     The pcie sac error information.
     */
    virtual uint32_t GetPcieSacErrInfo() {
        return 0;
    }

    /**
     * @brief      { function_description }
     */
    virtual void ClearPcieSacErrInt() {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void ClearPciePhySlvErrInt(uint32_t /*phy_id*/) {}

    /**
     * @brief      { function_description }
     */
    virtual void ClearPcieRasdpErrInt() {}

    /**
     * @brief      { function_description }
     */
    virtual void ClearPcieAppSlvErrInt() {}

    /**
     * @brief      { function_description }
     */
    virtual void ClearPcieDbiSlvErrInt() {}

    /**
     * @brief      { function_description }
     */
    virtual void ClearPcieAxiSlvErrInt() {}

    /**
     * @brief      { function_description }
     */
    virtual void ClearPcieEhMstWrInt() {}

    /**
     * @brief      { function_description }
     */
    virtual void ClearPcieCtrlMstReadInt() {}

    /**
     * @brief      { function_description }
     */
    virtual void ClearPcieCtrlMstWriteInt() {}

    virtual void ClearErrorStatus() {}
    virtual bool GetErrorStatus() {
        return false;
    }
    virtual bool GetPcieNocPendingStatus() {
        return false;
    }

    /**
     * @brief      Gets the pcie phy slv error information.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The pcie phy slv error information.
     */
    virtual bool GetPciePhySlvErrInfo(uint32_t /*phy_id*/) {
        return true;
    }

    /**
     * @brief      Gets the pcie application slv error information.
     *
     * @return     The pcie application slv error information.
     */
    virtual bool GetPcieAppSlvErrInfo() {
        return true;
    }

    /**
     * @brief      Gets the pcie dbi slv error information.
     *
     * @return     The pcie dbi slv error information.
     */
    virtual bool GetPcieDbiSlvErrInfo() {
        return true;
    }

    /**
     * @brief      Gets the pcie axi slv error information.
     *
     * @return     The pcie axi slv error information.
     */
    virtual bool GetPcieAxiSlvErrInfo() {
        return true;
    }

    /**
     * @brief      Gets the pcie eh mst wr information.
     *
     * @return     The pcie eh mst wr information.
     */
    virtual bool GetPcieEhMstWrInfo() {
        return true;
    }

    /**
     * @brief      Gets the pcie control mst read information.
     *
     * @return     The pcie control mst read information.
     */
    virtual bool GetPcieCtrlMstReadInfo() {
        return true;
    }

    /**
     * @brief      Gets the pcie control mst write information.
     *
     * @return     The pcie control mst write information.
     */
    virtual bool GetPcieCtrlMstWriteInfo() {
        return true;
    }

    /**
     * @brief      Sets the configuration ro write en.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetCfgRoWriteEn(bool /*val*/) {}

    /**
     * @brief      Writes a ro register.
     *
     * @param[in]  <unnamed>  { parameter_description }
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void WriteROReg(uint32_t /*offset*/, uint32_t /*val*/) {}

    /**
     * @brief      Gets the edf address shift.
     *
     * @return     The edf address shift.
     */
    virtual uint32_t GetEdfAddrShift() {
        return 0;
    }

    /**
     * @brief      Sets the edf address shift.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetEdfAddrShift(uint32_t /*val*/) {}

    /**
     * @brief      Sets the force ro setting.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetForceRoSetting(uint32_t /*val*/) {}

    /**
     * @brief      Gets the force ro setting.
     *
     * @return     The force ro setting.
     */
    virtual uint32_t GetForceRoSetting(void) {
        return 0;
    }

    /**
     * @brief      Sets the en ro checking.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetEnRoChecking(uint32_t /*val*/) {}

    /**
     * @brief      Gets the en ro checking.
     *
     * @return     The en ro checking.
     */
    virtual uint32_t GetEnRoChecking(void) {
        return 0;
    }

    virtual uint32_t GetEdfRoSetting(void) {
        return 0;
    }

    virtual void SetEdfRoSetting(uint32_t /*val*/) {}

    virtual uint32_t GetEcfRoSetting(void) {
        return 0;
    }

    virtual void SetEcfRoSetting(uint32_t /*val*/) {}

    /**
     * @brief      Gets the pcie control master identifier.
     *
     * @return     The pcie control master identifier.
     */
    virtual uint32_t GetPcieCtrlMasterId() {
        return 0;
    }  // pcie controller master ID

    /**
     * @brief      Gets the pcie application master identifier.
     *
     * @return     The pcie application master identifier.
     */
    virtual uint32_t GetPcieAppMasterId() {
        return 0;
    }  // pcie app master ID

    /**
     * @brief      Dumps a clock information.
     */
    virtual void DumpClkInfo() {}

    /**
     * @brief      Sets the edf clock.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetEdfClk(uint32_t /*edf_clk*/) {}

    /**
     * @brief      Sets the ecf clock.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetEcfClk(uint32_t /*ecf_clk*/) {}

    /**
     * @brief      Sets the core clock.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetCoreClk(uint32_t /*core_clk*/) {}

    /**
     * @brief      Gets the ecf clock.
     *
     * @return     The ecf clock.
     */
    virtual uint32_t GetEcfClk() {
        return 0;
    }

    /**
     * @brief      Gets the edf clock.
     *
     * @return     The edf clock.
     */
    virtual uint32_t GetEdfClk() {
        return 0;
    }

    /**
     * @brief      Sets the through put static en.
     *
     * @param[in]  <unnamed>  { parameter_description }
     * @param[in]  <unnamed>  { parameter_description }
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetThroughPutStaticEn(
        uint64_t /*stat_type_mask*/, uint32_t /*cd_timer_val*/, bool /*enable*/) {}

    /**
     * @brief      Gets the core clock.
     *
     * @return     The core clock.
     */
    virtual uint32_t GetCoreClk() {
        return 0;
    }

    /**
     * @brief      Gets the through put static.
     *
     * @param[in]  <unnamed>  { parameter_description }
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The through put static.
     */
    virtual float GetThroughPutStatic(
        uint64_t stat_type_mask, uint32_t cd_timer_val, uint32_t edf_clk) {
        return 0;
    }

    /**
     * @brief      Sets the latency static en.
     *
     * @param[in]  <unnamed>  { parameter_description }
     * @param[in]  <unnamed>  { parameter_description }
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetLatencyStaticEn(
        uint64_t /*stat_type_mask*/, uint32_t /*latency_mode*/, bool /*enable*/) {}

    /**
     * @brief      Gets the latency stati count.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The latency stati count.
     */
    virtual uint32_t GetLatencyStatiCount(uint64_t /*stat_type_mask*/) {
        return 0;
    }

    /**
     * @brief      Sets the performance sts en.
     *
     * @param[in]  <unnamed>  { parameter_description }
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetPerfStsEn(uint64_t /*stat_type_mask*/, bool /*enable*/) {}

    /**
     * @brief      Gets the performance sts counter.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The performance sts counter.
     */
    virtual uint32_t GetPerfStsCounter(uint64_t /*stat_type_mask*/) {
        return 0;
    }

    /**
     * @brief      Gets the snoop sts.
     *
     * @return     The snoop sts.
     */
    virtual bool GetSnoopSts() {
        return false;
    }

    /**
     * @brief      Sets the snoop en.
     *
     * @param[in]  <unnamed>  { parameter_description }
     */
    virtual void SetSnoopEn(bool /*enable*/) {}

    /**
     * @brief      Gets id based ordering sts.
     *
     * @return     The snoop sts.
     */
    uint32_t GetIdoSts() {
        return 0;
    }

    /**
     * @brief      Set id based ordering config.
     *
     * @return     none.
     */
    void SetIdoEn(uint32_t /*rw_en*/) {}

    virtual bool GetAtomicSts() {
        return true;
    }
    virtual void SetAtomicEn(bool /*enable*/) {}

    /**
     * @brief      Dumps a ltssm trace buffer.
     *
     * @param      <unnamed>  { parameter_description }
     */
    virtual void DumpLtssmTraceBuff(std::vector<uint32_t> & /*buff_vec*/) {}

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool CheckSsmInitDone() {
        return true;
    }

    /**
     * @brief      { function_description }
     *
     * @param      <unnamed>  { parameter_description }
     */
    virtual void BackupSacSetting(std::vector<SacInfo> & /*info*/) {}

    /**
     * @brief      Sets the sac setting.
     *
     * @param      <unnamed>  { parameter_description }
     */
    virtual void SetSacSetting(std::vector<SacInfo> & /* info */) {}

    /**
     * @brief      Sets the sac setting.
     *
     * @param      <unnamed>  { parameter_description }
     */
    virtual void SetSacSetting(SacInfo & /*info*/) {}

    /**
     * @brief      { function_description }
     */
    virtual void SacDisableAll() {}

    /**
     * @brief      Gets the phy receive adapt fom register offset.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The phy receive adapt fom register offset.
     */
    virtual uint32_t GetPhyRxAdaptFomRegOffset(uint32_t /*lane_id*/) {
        return 0;
    }

    /**
     * @brief      Gets the phy receive adapt fom register offset.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The phy receive adapt fom register offset.
     */
    virtual uint32_t GetPhyRxAdaptMMFomRegOffset(uint32_t /*lane_id*/) {
        return 0;
    }
    /**
     * @brief      Gets the phy receive adapt  stratup fom register offset.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The phy receive adapt stratup fom register offset.
     */
    virtual uint32_t GetPhyRxAdaptStFomRegOffset(uint32_t /*lane_id*/) {
        return 0;
    }

    /**
     * @brief      Gets the phy receive adapt ctle register offset.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The phy receive adapt ctle register offset.
     */
    virtual uint32_t GetPhyRxAdaptCtleRegOffset(uint32_t /*lane_id*/) {
        return 0;
    }

    /**
     * @brief      Gets the phy receive adapt vga register offset.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The phy receive adapt vga register offset.
     */
    virtual uint32_t GetPhyRxAdaptVgaRegOffset(uint32_t /*lane_id*/) {
        return 0;
    }

    /**
     * @brief      Gets the phy receive adapt dfe TAP1 register offset.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The phy receive adapt dfe TAP1 register offset.
     */
    virtual uint32_t GetPhyRxAdaptDfeTap1RegOffset(uint32_t /*lane_id*/) {
        return 0;
    }

    /**
     * @brief      Gets the phy receive adapt dfe TAP2 register offset.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The phy receive adapt dfe TAP2 register offset.
     */
    virtual uint32_t GetPhyRxAdaptDfeTap2RegOffset(uint32_t /*lane_id*/) {
        return 0;
    }

    /**
     * @brief      Gets the phy receive adapt dfe TAP3 register offset.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The phy receive adapt dfe TAP3 register offset.
     */
    virtual uint32_t GetPhyRxAdaptDfeTap3RegOffset(uint32_t /*lane_id*/) {
        return 0;
    }

    /**
     * @brief      Gets the phy receive adapt dfe TAP4 register offset.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The phy receive adapt dfe TAP4 register offset.
     */
    virtual uint32_t GetPhyRxAdaptDfeTap4RegOffset(uint32_t /*lane_id*/) {
        return 0;
    }

    /**
     * @brief      Gets the phy receive adapt dfe TAP5 register offset.
     *
     * @param[in]  <unnamed>  { parameter_description }
     *
     * @return     The phy receive adapt dfe TAP5 register offset.
     */
    virtual uint32_t GetPhyRxAdaptDfeTap5RegOffset(uint32_t /*lane_id*/) {
        return 0;
    }

    virtual SystemAdapter *GetSa() {
        return nullptr;
    }

    virtual void SetIndirectChannel(uint32_t /*chl_id*/, bool /*val*/) {}

    virtual bool GetChannelSemaphore(uint32_t /*chl_id*/) {
        return true;
    }
    virtual void     ReleaseChannelSemaphore(uint32_t /*chl_id*/) {}
    virtual uint32_t IndirectRegRead(uint32_t /*chl_id*/, uint32_t /*addr*/) {
        return 0;
    }
    virtual void IndirectRegWrite(uint32_t /*chl_id*/, uint32_t /*addr*/, uint32_t /*val*/) {}

    virtual uint32_t PcieAppRegRead(uint32_t offset) = 0;
    virtual void PcieAppRegWrite(uint32_t offset, uint32_t val) = 0;

    // auto reply
    virtual void DumpAutoReplyCfg(void) {}
    virtual bool AutoReplyValid(void) {
        return false;
    }
    virtual void ClearTimeoutValid(void) {}

 protected:
    PcieDevice *m_dev    = nullptr;
    PcieDevice *m_parent = nullptr;
    uint32_t    m_domain;
    uint8_t     m_bus_num;
    uint8_t     m_dev_num;
    uint8_t     m_func_num;
    // buffer used for save/restore cfg space
    std::unique_ptr<uint32_t[]> m_cs_buf               = {};
    bool                        m_ari_capable_hirarchy = false;
};

}  // namespace pcie
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_PCIE_PCIE_H_
