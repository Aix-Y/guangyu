/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_INCLUDE_PCIE_PCIE_RAS_H_
#define HARDWARE_INCLUDE_PCIE_PCIE_RAS_H_

#include "hardware/include/ras.h"

namespace efvf {
namespace hardware {
namespace pcie {

class PcieRasCfg : public efvf::hardware::RasCfg {
 public:
    // internal ras
    bool pcie_parity_check;
    bool pcie_resp_check;
    bool pcie_auto_linkdown_en;
    bool pcie_rasdp_en;

    // aer
    bool caer_mask_set_en;
    bool uaer_mask_set_en;
};

class PcieRasErrInj : public efvf::hardware::RasErrInj {
 public:
    // internal
    bool sram_parity_error = false;

    // aer
    bool aer_correct_internal_error   = false;
    bool aer_uncorrect_internal_error = false;

    // data path
    bool inbound_edf_parity_wr_error = false;
    bool inbound_edf_parity_rd_error = false;
    bool inbound_ecf_parity_wr_error = false;
    bool inbound_ecf_parity_rd_error = false;
    bool outbound_edf_parity_error   = false;
    bool outbound_ecf_parity_error   = false;

    // controller
    bool     crc_error_inj    = false;
    bool     seqnum_error_inj = false;
    bool     dllp_error_inj   = false;
    bool     symbol_error_inj = false;
    bool     fc_error_inj     = false;
    bool     sp_tlp_error_inj = false;
    bool     tlp_error_inj    = false;
    uint32_t value;
    uint32_t sub_type;
    uint32_t count;
};

class PcieIntrptStat : public efvf::hardware::IntrptStat {
 public:
    union {
        struct {
            uint32_t cfg_pme_int : 1;
            uint32_t radm_inta_asserted : 1;
            uint32_t radm_intb_asserted : 1;
            uint32_t radm_intc_asserted : 1;
            uint32_t radm_intd_asserted : 1;
            uint32_t radm_inta_deasserted : 1;
            uint32_t radm_intb_deasserted : 1;
            uint32_t radm_intc_deasserted : 1;
            uint32_t radm_intd_deasserted : 1;
            uint32_t radm_correctable_err : 1;
            uint32_t radm_nonfatal_err : 1;
            uint32_t radm_fatal_err : 1;
            uint32_t hp_pme : 1;
            uint32_t hp_int : 1;
            uint32_t cfg_link_auto_bw_int : 1;
            uint32_t cfg_bw_mgt_int : 1;
            uint32_t autoesm_done_ok : 1;
            uint32_t reserve0 : 1;
            uint32_t reserve1 : 1;
            uint32_t pcie4_app_flr_active_fail : 1;
            uint32_t pm_xtlh_block_tlp_fall : 1;
            uint32_t dma_normal_int : 1;
            uint32_t rbar_ctrl_update : 1;
            uint32_t cfg_cxl_dev_initiate_cxl_rst : 1;
            uint32_t cfg_flr_vf_active : 8;
        } field;

        uint32_t value;
    } eh_intreg_error_sts0;

    union {
        struct {
            uint32_t cfg_mlf_tlp_err_sts : 1;
            uint32_t cfg_surprise_down_err_sts : 1;
            uint32_t cfg_dl_protocol_err_sts : 1;
            uint32_t cfg_ecrc_err_sts : 1;
            uint32_t cfg_corrected_internal_err_sts : 1;
            uint32_t cfg_replay_number_rollover_err_sts : 1;
            uint32_t cfg_replay_timer_timeout_err_sts : 1;
            uint32_t cfg_bad_dllp_err_sts : 1;
            uint32_t cfg_bad_tlp_err_sts : 1;
            uint32_t err_mstr_awaddr : 1;
            uint32_t err_mstr_araddr : 1;
            uint32_t cfg_aer_rc_err_int : 1;
            uint32_t cfg_sys_err_rc : 1;
            uint32_t autoesm_done_fail : 1;
            uint32_t reserve0 : 1;
            uint32_t reserve1 : 1;
            uint32_t ras_errint_ehmst_buser_bresp_err : 1;
            uint32_t ras_errint_cxlmst_buser_bresp_err : 1;
            uint32_t ras_errint_cxlmst_ruser_rresp_prty_err : 1;
            uint32_t ras_errint_aximst_buser_bresp_err : 1;
            uint32_t ras_errint_aximst_ruser_rresp_prty_err : 1;
            uint32_t ras_errint_appreg_slv_prty_err : 1;
            uint32_t ras_errint_phy0_apbslv_prty_err : 1;
            uint32_t ras_errint_phy1_apbslv_prty_err : 1;
            uint32_t ras_errint_phy2_apbslv_prty_err : 1;
            uint32_t ras_errint_phy3_apbslv_prty_err : 1;
            uint32_t ras_errint_dbislv_prty_err : 1;
            uint32_t ras_errint_axislv_prty_err : 1;
            uint32_t sac_error_int : 1;
            uint32_t xmc_irq_addr_fault : 1;
            uint32_t cfg_advisory_nf_sts : 1;
            uint32_t cfg_hdr_log_overflow_sts : 1;
        } field;
        uint32_t value;
    } eh_intreg_error_sts1;
};

class PcieRasErrStat : public efvf::hardware::RasErrStat {
 public:
    PcieIntrptStat sts;
    PcieIntrptStat mask;
    union {
        struct {
            uint32_t buser : 4;
            uint32_t bresp : 2;
            uint32_t rev1 : 2;
            uint32_t bid : 8;
            uint32_t rev2 : 16;
        } field;
        uint32_t value;
    } ras_errlog_hdma_mst_wr;

    union {
        struct {
            uint32_t ruser : 4;
            uint32_t rresp : 2;
            uint32_t rev1 : 2;
            uint32_t rid : 8;
            uint32_t rev2 : 16;
        } field;
        uint32_t value;
    } ras_errlog_hdma_mst_rd;

    union {
        struct {
            uint32_t buser : 4;
            uint32_t bresp : 2;
            uint32_t rev1 : 2;
            uint32_t bid : 8;
            uint32_t rev2 : 16;
        } field;
        uint32_t value;
    } ras_errlog_eventhub_mst_wr;

    union {
        struct {
            uint32_t ruser : 4;
            uint32_t rresp : 2;
            uint32_t rev1 : 2;
            uint32_t rid : 8;
            uint32_t rev2 : 16;
        } field;
        uint32_t value;
    } ras_errlog_eventhub_mst_rd;

    union {
        struct {
            uint32_t buser : 4;
            uint32_t bresp : 2;
            uint32_t rev1 : 2;
            uint32_t bid : 8;
            uint32_t rev2 : 16;
        } field;
        uint32_t value;
    } ras_errlog_autoesm_mst_wr;

    union {
        struct {
            uint32_t ruser : 4;
            uint32_t rresp : 2;
            uint32_t rev1 : 2;
            uint32_t rid : 8;
            uint32_t rev2 : 16;
        } field;
        uint32_t value;
    } ras_errlog_autoesm_mst_rd;

    union {
        struct {
            uint32_t buser : 4;
            uint32_t bresp : 2;
            uint32_t rev1 : 2;
            uint32_t bid : 8;
            uint32_t rev2 : 16;
        } field;
        uint32_t value;
    } ras_errlog_ctrl_mst_wr;

    union {
        struct {
            uint32_t ruser : 4;
            uint32_t rresp : 2;
            uint32_t rev0 : 2;
            uint32_t rid : 7;
            uint32_t parity_err : 1;
            uint32_t rev1 : 15;
        } field;
        uint32_t value;
    } ras_errlog_ctrl_mst_rd;

    struct {
        uint32_t awuser : 16;
        uint32_t rev1 : 16;
        uint32_t awaddr : 32;
    } ras_errlog_appreg_slv_wr;

    struct {
        uint32_t awaddr : 32;
    } ras_errlog_phy0apb_slv_wr;

    struct {
        uint32_t awaddr : 32;
    } ras_errlog_phy1apb_slv_wr;

    struct {
        uint32_t awaddr : 32;
    } ras_errlog_phy2apb_slv_wr;

    struct {
        uint32_t awaddr : 32;
    } ras_errlog_phy3apb_slv_wr;

    struct {
        uint32_t awuser : 16;
    } ras_errlog_ctrl_dbislv_wr0;

    struct {
        uint32_t awaddr : 32;
    } ras_errlog_ctrl_dbislv_wr1;

    struct {
        uint32_t awuser : 16;
    } ras_errlog_ctrl_axislv_wr0;

    struct {
        uint32_t awaddr : 32;
    } ras_errlog_ctrl_axislv_wr1;

    struct {
        uint32_t awaddr : 32;
    } ras_errlog_ctrl_axislv_wr2;

    union {
        struct {
            uint32_t buser : 4;
            uint32_t bresp : 2;
            uint32_t rev1 : 2;
            uint32_t bid : 8;
            uint32_t rev2 : 16;
        } field;
        uint32_t value;
    } ras_errlog_hdma_gpm_mst_wr;

    union {
        struct {
            uint32_t ruser : 4;
            uint32_t rresp : 2;
            uint32_t rev1 : 2;
            uint32_t rid : 8;
            uint32_t rev2 : 16;
        } field;
        uint32_t value;
    } ras_errlog_hdma_gpm_mst_rd;

    union {
        struct {
            uint32_t buser : 4;
            uint32_t bresp : 2;
            uint32_t rev1 : 2;
            uint32_t bid : 8;
            uint32_t rev2 : 16;
        } field;
        uint32_t value;
    } ras_errlog_cxl_axi_mst_wr;

    union {
        struct {
            uint32_t ruser : 4;
            uint32_t rresp : 2;
            uint32_t rev0 : 2;
            uint32_t rid : 7;
            uint32_t rev1 : 1;
            uint32_t r_par_err : 1;
            uint32_t rev2 : 15;
        } field;
        uint32_t value;
    } ras_errlog_cxl_axi_mst_rd;
};

class PcieIntrptCfg : public efvf::hardware::IntrptCfg {
 public:
    union {
        struct {
            uint32_t cfg_pme_int : 1;
            uint32_t radm_inta_asserted : 1;
            uint32_t radm_intb_asserted : 1;
            uint32_t radm_intc_asserted : 1;
            uint32_t radm_intd_asserted : 1;
            uint32_t radm_inta_deasserted : 1;
            uint32_t radm_intb_deasserted : 1;
            uint32_t radm_intc_deasserted : 1;
            uint32_t radm_intd_deasserted : 1;
            uint32_t radm_correctable_err : 1;
            uint32_t radm_nonfatal_err : 1;
            uint32_t radm_fatal_err : 1;
            uint32_t hp_pme : 1;
            uint32_t hp_int : 1;
            uint32_t cfg_link_auto_bw_int : 1;
            uint32_t cfg_bw_mgt_int : 1;
            uint32_t autoesm_done_ok : 1;
            uint32_t reserve0 : 1;
            uint32_t reserve1 : 1;
            uint32_t pcie4_app_flr_active_fail : 1;
            uint32_t pm_xtlh_block_tlp_fall : 1;
            uint32_t dma_normal_int : 1;
            uint32_t rbar_ctrl_update : 1;
            uint32_t cfg_cxl_dev_initiate_cxl_rst : 1;
            uint32_t cfg_flr_vf_active : 8;
        } field;

        uint32_t value;
    } eh_intreg_error_mask0;

    union {
        struct {
            uint32_t cfg_mlf_tlp_err_sts : 1;
            uint32_t cfg_surprise_down_err_sts : 1;
            uint32_t cfg_dl_protocol_err_sts : 1;
            uint32_t cfg_ecrc_err_sts : 1;
            uint32_t cfg_corrected_internal_err_sts : 1;
            uint32_t cfg_replay_number_rollover_err_sts : 1;
            uint32_t cfg_replay_timer_timeout_err_sts : 1;
            uint32_t cfg_bad_dllp_err_sts : 1;
            uint32_t cfg_bad_tlp_err_sts : 1;
            uint32_t err_mstr_awaddr : 1;
            uint32_t err_mstr_araddr : 1;
            uint32_t cfg_aer_rc_err_int : 1;
            uint32_t cfg_sys_err_rc : 1;
            uint32_t autoesm_done_fail : 1;
            uint32_t reserve0 : 1;
            uint32_t reserve1 : 1;
            uint32_t ras_errint_ehmst_buser_bresp_err : 1;
            uint32_t ras_errint_cxlmst_buser_bresp_err : 1;
            uint32_t ras_errint_cxlmst_ruser_rresp_prty_err : 1;
            uint32_t ras_errint_aximst_buser_bresp_err : 1;
            uint32_t ras_errint_aximst_ruser_rresp_prty_err : 1;
            uint32_t ras_errint_appreg_slv_prty_err : 1;
            uint32_t ras_errint_phy0_apbslv_prty_err : 1;
            uint32_t ras_errint_phy1_apbslv_prty_err : 1;
            uint32_t ras_errint_phy2_apbslv_prty_err : 1;
            uint32_t ras_errint_phy3_apbslv_prty_err : 1;
            uint32_t ras_errint_dbislv_prty_err : 1;
            uint32_t ras_errint_axislv_prty_err : 1;
            uint32_t sac_error_int : 1;
            uint32_t xmc_irq_addr_fault : 1;
            uint32_t cfg_advisory_nf_sts : 1;
            uint32_t cfg_hdr_log_overflow_sts : 1;
        } field;
        uint32_t value;
    } eh_intreg_error_mask1;
};

class PcieRas : public efvf::hardware::IRas {};

}  // namespace pcie
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_INCLUDE_PCIE_PCIE_RAS_H_
