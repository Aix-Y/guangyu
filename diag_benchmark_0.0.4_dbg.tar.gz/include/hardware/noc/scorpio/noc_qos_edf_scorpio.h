/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_NOC_SCORPIO_NOC_QOS_EDF_SCORPIO_H_
#define HARDWARE_NOC_SCORPIO_NOC_QOS_EDF_SCORPIO_H_
#include <memory>
#include <set>
#include <string>
#include "device/dtus/scorpio/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_qos.h"

namespace efvf {
namespace hardware {
namespace noc {

class NocQosEdf : public NocQos {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocQosEdf(std::shared_ptr<spdlog::logger> logger) : NocQos(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocQosEdf() {}

    virtual bool SetNocQosReadGen(const NOC_QOS_READ_CFG &noc_qos_read_cfg);
    virtual bool SetNocQosWriteGen(const NOC_QOS_WRITE_CFG &noc_qos_write_cfg);
    virtual void QosMode(uint32_t qos_mode);
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_NOC_SCORPIO_NOC_QOS_EDF_SCORPIO_H_
