/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_NOC_SCORPIO_NOC_ERR_EDFCOREW_H_
#define HARDWARE_NOC_SCORPIO_NOC_ERR_EDFCOREW_H_

#include <memory>
#include <set>
#include <string>
#include "device/dtus/scorpio/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_error.h"

namespace efvf {
namespace hardware {
namespace noc {

class NocErrEdfCoreW : public NocErr {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocErrEdfCoreW(std::shared_ptr<spdlog::logger> logger) : NocErr(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocErrEdfCoreW() {}
    virtual bool Dump(NOC_Err_Info &err);
    virtual bool Clear();

 protected:
    virtual int    TriggerClr();
    virtual std::string DumpInitFlow();
    virtual std::string DumpTargetFlow();
    virtual uint32_t    DumpOffset();
    virtual uint32_t    DumpValid();

 private:
    typedef struct _EDF_CoreW_RouteId_t {
#if BYTE_ORDER == LITTLE_ENDIAN
        unsigned int SeqId : 10;
        unsigned int TargetSubRange : 2;
        unsigned int TargetFlow : 6;
        unsigned int InitFlow : 6;
#elif BYTE_ORDER == BIG_ENDIAN
        unsigned int InitFlow : 6;
        unsigned int TargetFlow : 6;
        unsigned int TargetSubRange : 2;
        unsigned int SeqId : 10;
#endif
    } EDF_CoreW_RouteId_t;

    typedef union {
        unsigned int        val : 24;
        EDF_CoreW_RouteId_t f;
    } EDF_CoreW_RouteId_u;

    const std::array<std::string, 256> NOCERR_EDFCOREW_INIT_FLOW_ARRAY{{
        "ecf_edfcorew_axi/I/0", "wo_aasp_edf_axi/I/0", "wo_cbf0_edf_axi/I/0",
        "wo_cbf10_edf_axi/I/0", "wo_cbf11_edf_axi/I/0", "wo_cbf12_edf_axi/I/0",
        "wo_cbf13_edf_axi/I/0", "wo_cbf14_edf_axi/I/0", "wo_cbf15_edf_axi/I/0",
        "wo_cbf1_edf_axi/I/0", "wo_cbf2_edf_axi/I/0", "wo_cbf3_edf_axi/I/0",
        "wo_cbf4_edf_axi/I/0", "wo_cbf5_edf_axi/I/0", "wo_cbf6_edf_axi/I/0",
        "wo_cbf7_edf_axi/I/0", "wo_cbf8_edf_axi/I/0", "wo_cbf9_edf_axi/I/0",
        "wo_cdte0_edf_axi/I/0", "wo_cdte1_edf_axi/I/0", "wo_cdte2_edf_axi/I/0",
        "wo_cdte3_edf_axi/I/0", "wo_cva_edf_axi/I/0", "wo_dftentry0_edf_axi/I/0",
        "wo_dpf_edf_axi/I/0", "wo_edfcore_m_edfio0_axi/I/0", "wo_edfcore_m_edfio1_axi/I/0",
        "wo_sip0_edf_axi/I/0", "wo_sip10_edf_axi/I/0", "wo_sip11_edf_axi/I/0",
        "wo_sip12_edf_axi/I/0", "wo_sip13_edf_axi/I/0", "wo_sip14_edf_axi/I/0",
        "wo_sip15_edf_axi/I/0", "wo_sip1_edf_axi/I/0", "wo_sip2_edf_axi/I/0",
        "wo_sip3_edf_axi/I/0", "wo_sip4_edf_axi/I/0", "wo_sip5_edf_axi/I/0",
        "wo_sip6_edf_axi/I/0", "wo_sip7_edf_axi/I/0", "wo_sip8_edf_axi/I/0",
        "wo_sip9_edf_axi/I/0", "wo_sp_edf_axi/I/0", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED",
    }};

    const std::array<std::string, 256> NOCERR_EDFCOREW_TARGET_FLOW_ARRAY{{
        "edfcorew_s_service/T/0", "wo_edf_aasp_axi/T/0", "wo_edf_cbf0p0_axi/T/0",
        "wo_edf_cbf0p1_axi/T/0", "wo_edf_cbf10p0_axi/T/0", "wo_edf_cbf10p1_axi/T/0",
        "wo_edf_cbf11p0_axi/T/0", "wo_edf_cbf11p1_axi/T/0", "wo_edf_cbf12p0_axi/T/0",
        "wo_edf_cbf12p1_axi/T/0", "wo_edf_cbf13p0_axi/T/0", "wo_edf_cbf13p1_axi/T/0",
        "wo_edf_cbf14p0_axi/T/0", "wo_edf_cbf14p1_axi/T/0", "wo_edf_cbf15p0_axi/T/0",
        "wo_edf_cbf15p1_axi/T/0", "wo_edf_cbf1p0_axi/T/0", "wo_edf_cbf1p1_axi/T/0",
        "wo_edf_cbf2p0_axi/T/0", "wo_edf_cbf2p1_axi/T/0", "wo_edf_cbf3p0_axi/T/0",
        "wo_edf_cbf3p1_axi/T/0", "wo_edf_cbf4p0_axi/T/0", "wo_edf_cbf4p1_axi/T/0",
        "wo_edf_cbf5p0_axi/T/0", "wo_edf_cbf5p1_axi/T/0", "wo_edf_cbf6p0_axi/T/0",
        "wo_edf_cbf6p1_axi/T/0", "wo_edf_cbf7p0_axi/T/0", "wo_edf_cbf7p1_axi/T/0",
        "wo_edf_cbf8p0_axi/T/0", "wo_edf_cbf8p1_axi/T/0", "wo_edf_cbf9p0_axi/T/0",
        "wo_edf_cbf9p1_axi/T/0", "wo_edf_mdf0p0_axi/T/0", "wo_edf_mdf0p1_axi/T/0",
        "wo_edf_mdf1p0_axi/T/0", "wo_edf_mdf1p1_axi/T/0", "wo_edf_sp_axi/T/0",
        "wo_edfcore_s_edfio_axi/T/0", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
    }};
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_NOC_SCORPIO_NOC_ERR_EDFCOREW_H_
