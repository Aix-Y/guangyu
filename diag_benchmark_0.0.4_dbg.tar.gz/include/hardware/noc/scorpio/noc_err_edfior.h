/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_NOC_SCORPIO_NOC_ERR_EDFIOR_H_
#define HARDWARE_NOC_SCORPIO_NOC_ERR_EDFIOR_H_

#include <memory>
#include <set>
#include <string>
#include "device/dtus/scorpio/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_error.h"

namespace efvf {
namespace hardware {
namespace noc {

class NocErrEdfIOR : public NocErr {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocErrEdfIOR(std::shared_ptr<spdlog::logger> logger) : NocErr(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocErrEdfIOR() {}
    virtual bool Dump(NOC_Err_Info &err);
    virtual bool Clear();

 protected:
    virtual int    TriggerClr();
    virtual std::string DumpInitFlow();
    virtual std::string DumpTargetFlow();
    virtual uint32_t    DumpOffset();
    virtual uint32_t    DumpValid();

 private:
    typedef struct _EDF_IOR_RouteId_t {
#if BYTE_ORDER == LITTLE_ENDIAN
        unsigned int SeqId : 9;
        unsigned int TargetSubRange : 3;
        unsigned int TargetFlow : 2;
        unsigned int InitFlow : 4;
#elif BYTE_ORDER == BIG_ENDIAN
        unsigned int InitFlow : 4;
        unsigned int TargetFlow : 2;
        unsigned int TargetSubRange : 3;
        unsigned int SeqId : 9;
#endif
    } EDF_IOR_RouteId_t;

    typedef union {
        unsigned int      val : 18;
        EDF_IOR_RouteId_t f;
    } EDF_IOR_RouteId_u;

    const std::array<std::string, 256> NOCERR_EDFIOR_INIT_FLOW_ARRAY{{
        "ecf_edfior_axi/I/0", "ro_ap_edf_axi/I/0", "ro_cdft_edf_axi/I/0",
        "ro_edfio_m_edfcore_axi/I/0", "ro_odte0_edf_axi/I/0", "ro_odte1_edf_axi/I/0",
        "ro_pcie_edf_axi/I/0", "ro_ssm_edf_axi/I/0", "ro_vpp0_edf_axi/I/0",
        "ro_vpp1_edf_axi/I/0", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED",
    }};

    const std::array<std::string, 4> NOCERR_EDFIOR_TARGET_FLOW_ARRAY{{
        "edfior_s_service/T/0", "ro_edf_pcie_axi/T/0", "ro_edfio_s_edfcore0_axi/T/0",
        "ro_edfio_s_edfcore1_axi/T/0",
    }};
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_NOC_SCORPIO_NOC_ERR_EDFIOR_H_
