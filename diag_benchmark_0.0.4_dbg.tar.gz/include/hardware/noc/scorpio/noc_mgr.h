/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_NOC_SCORPIO_NOC_MGR_H_
#define HARDWARE_NOC_SCORPIO_NOC_MGR_H_

#include <memory>
#include <string>
#include <vector>
#include "device/dtus/scorpio/scorpio.h"
#include "hardware/include/noc/noc_mgr.h"

namespace efvf {
namespace hardware {
namespace noc {
using efvf::device::DtuScorpio;
class NocMgrScorpio : public NocMgr {
 public:
    NocMgrScorpio(std::shared_ptr<spdlog::logger> logger, const Dtu &dtu);
    virtual ~NocMgrScorpio() {}
    virtual int DumpAllErrorLogger(int die_id, std::vector<NOC_Err_Info> &errors);

    virtual int ClearAllErrorLogger(int die_id);
    virtual NocErr *GetErrLogger(int inst, int die_id, const std::string &alias);
    virtual NocQos *GetQos(int inst, int die_id, const std::string &alias);
    virtual NocQos *GetQosRead(int inst, int die_id);
    virtual int GetDumpLimitation(std::string &limitation) {
        limitation = "None";
        return 0;
    }
    virtual int DumpAllBstpChnl(int die_id, std::vector<std::string> &infos) {
        return 0;
    }

 private:
    const DtuScorpio &dtu_scorpio_;
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_NOC_SCORPIO_NOC_MGR_H_
