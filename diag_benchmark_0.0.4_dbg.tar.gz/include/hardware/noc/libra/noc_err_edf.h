/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_NOC_LIBRA_NOC_ERR_EDF_H_
#define HARDWARE_NOC_LIBRA_NOC_ERR_EDF_H_

#include <memory>
#include <set>
#include <string>
#include "device/dtus/libra/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_error.h"

namespace efvf {
namespace hardware {
namespace noc {
class NocErrEdfLibra : public NocErr {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocErrEdfLibra(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocErrEdfLibra() {}
    virtual bool Dump(NOC_Err_Info &err);
    virtual bool Clear();
    virtual bool IsErrValid(void);

 protected:
    virtual int DumpFailAddr(NOC_Err_Info &err);
    virtual int TriggerClr();
    virtual int DumpRoute(NOC_Err_Info &err);
    virtual int DumpAxUser(NOC_Err_Info &err);
    virtual int DumpValid(NOC_Err_Info &err);
    virtual uint32_t DumpErrType(NOC_Err_Info &err);

 private:
    typedef struct _EDF_RouteId_Libra_t {
#if BYTE_ORDER == LITTLE_ENDIAN
        unsigned int Reserved0 : 18;
        unsigned int Master : 5;
        unsigned int Slave : 5;
        unsigned int Reserved1 : 4;

#elif BYTE_ORDER == BIG_ENDIAN
        unsigned int Reserved1 : 4;
        unsigned int Slave : 5;
        unsigned int Master : 5;
        unsigned int Reserved0 : 18;
#endif
    } EDF_RouteId_Libra_t;

    typedef union {
        unsigned int        val : 32;
        EDF_RouteId_Libra_t f;
    } EDF_RouteId_Libra_u;

    const std::array<std::string, 256> NOCERR_EDF_ERRTYPE_ARRAY{{
        "target error detected by slave", "address decode error", "unsupported request",
        "disconnected target or domain", "Security violation",
        "hidden security violation, reported as OK to initiator", "time-out", "Reserved",
    }};

    const std::array<std::string, 256> NOCERR_EDF_BOTTOMR_USER_FLAGS_ARRAY{{
        "Cache_0", "Cache_1", "Cache_2", "Cache_3", "Prot_0", "Prot_1", "Prot_2", "reqUser_00",
        "reqUser_01", "reqUser_02", "reqUser_03", "reqUser_04", "reqUser_05", "reqUser_06",
        "reqUser_07", "reqUser_08", "reqUser_09", "reqUser_10", "reqUser_11", "reqUser_12",
        "reqUser_13", "reqUser_14", "reqUser_15", "reqUser_16", "reqUser_17", "reqUser_18",
        "reqUser_19", "reqUser_20", "reqUser_21", "reqUser_22", "reqUser_23", "reqUser_24",
        "reqUser_25", "reqUser_26", "reqUser_27", "reqUser_28", "reqUser_29", "reqUser_30",
        "reqUser_31", "reqUser_32", "reqUser_33", "reqUser_34", "reqUser_35",
        "user_endianness",
    }};
    const std::array<std::string, 256> NOCERR_EDF_BOTTOMR_INIT_ARRAY{{
        "Flow:/Specification/ecf_edfbottomr_axi/I/0",
        "Flow:/Specification/ro_esl10_edf_axi/I/0", "Flow:/Specification/ro_esl11_edf_axi/I/0",
        "Flow:/Specification/ro_esl12_edf_axi/I/0", "Flow:/Specification/ro_esl13_edf_axi/I/0",
        "Flow:/Specification/ro_esl14_edf_axi/I/0", "Flow:/Specification/ro_esl15_edf_axi/I/0",
        "Flow:/Specification/ro_esl8_edf_axi/I/0", "Flow:/Specification/ro_esl9_edf_axi/I/0",
        "Flow:/Specification/ro_esl_mmu2_edf_axi/I/0",
        "Flow:/Specification/ro_esl_mmu3_edf_axi/I/0",
        "Flow:/Specification/ro_odte_p0_edf_axi/I/0",
        "Flow:/Specification/ro_odte_p1_edf_axi/I/0",
        "Flow:/Specification/ro_pcie_edf_axi/I/0",
        "Flow:/Specification/ro_pipe_bottom0_edfbottom_axi/I/0", "RESERVED",
    }};
    const std::array<std::string, 256> NOCERR_EDF_BOTTOMR_TARGET_ARRAY{{
        "Flow:/Specification/edf_bottomr_service/T/0",
        "Flow:/Specification/ro_edf_esl_mmu2_axi/T/0",
        "Flow:/Specification/ro_edf_esl_mmu3_axi/T/0",
        "Flow:/Specification/ro_edf_pcie_axi/T/0",
        "Flow:/Specification/ro_edfbottom_pipe_bottom0_axi/T/0",
        "Flow:/Specification/ro_edfbottom_pipe_bottom1_axi/T/0", "RESERVED", "RESERVED",
    }};

    const std::array<std::string, 256> NOCERR_EDF_BOTTOMW_USER_FLAGS_ARRAY{{
        "Cache_0", "Cache_1", "Cache_2", "Cache_3", "Prot_0", "Prot_1", "Prot_2", "reqUser_00",
        "reqUser_01", "reqUser_02", "reqUser_03", "reqUser_04", "reqUser_05", "reqUser_06",
        "reqUser_07", "reqUser_08", "reqUser_09", "reqUser_10", "reqUser_11", "reqUser_12",
        "reqUser_13", "reqUser_14", "reqUser_15", "reqUser_16", "reqUser_17", "reqUser_18",
        "reqUser_19", "reqUser_20", "reqUser_21", "reqUser_22", "reqUser_23", "reqUser_24",
        "reqUser_25", "reqUser_26", "reqUser_27", "reqUser_28", "reqUser_29", "reqUser_30",
        "reqUser_31", "reqUser_32", "reqUser_33", "reqUser_34", "reqUser_35", "reqUser_36",
        "reqUser_37", "reqUser_38", "reqUser_39", "reqUser_40", "reqUser_41", "reqUser_42",
        "reqUser_43", "reqUser_44", "reqUser_45", "reqUser_46", "reqUser_47",
        "user_endianness",
    }};
    const std::array<std::string, 256> NOCERR_EDF_BOTTOMW_INIT_ARRAY{{
        "Flow:/Specification/ecf_edfbottomw_axi/I/0",
        "Flow:/Specification/wo_esl10_edf_axi/I/0",
        "Flow:/Specification/wo_esl10_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl11_edf_axi/I/0",
        "Flow:/Specification/wo_esl11_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl12_edf_axi/I/0",
        "Flow:/Specification/wo_esl12_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl13_edf_axi/I/0",
        "Flow:/Specification/wo_esl13_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl14_edf_axi/I/0",
        "Flow:/Specification/wo_esl14_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl15_edf_axi/I/0",
        "Flow:/Specification/wo_esl15_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl8_edf_axi/I/0",
        "Flow:/Specification/wo_esl8_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl9_edf_axi/I/0",
        "Flow:/Specification/wo_esl9_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl_mmu2_edf_axi/I/0",
        "Flow:/Specification/wo_esl_mmu3_edf_axi/I/0",
        "Flow:/Specification/wo_odte_p0_edf_axi/I/0",
        "Flow:/Specification/wo_odte_p1_edf_axi/I/0",
        "Flow:/Specification/wo_pcie_edf_axi/I/0",
        "Flow:/Specification/wo_pipe_bottom0_edfbottom_axi/I/0",
        "Flow:/Specification/wo_pipe_bottom1_edfbottom_axi/I/0", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
    }};
    const std::array<std::string, 256> NOCERR_EDF_BOTTOMW_TARGET_ARRAY{{
        "Flow:/Specification/edf_bottomw_service/T/0",
        "Flow:/Specification/wo_edf_esl10_axi/T/0", "Flow:/Specification/wo_edf_esl11_axi/T/0",
        "Flow:/Specification/wo_edf_esl12_axi/T/0", "Flow:/Specification/wo_edf_esl13_axi/T/0",
        "Flow:/Specification/wo_edf_esl14_axi/T/0", "Flow:/Specification/wo_edf_esl15_axi/T/0",
        "Flow:/Specification/wo_edf_esl8_axi/T/0", "Flow:/Specification/wo_edf_esl9_axi/T/0",
        "Flow:/Specification/wo_edf_esl_mmu2_axi/T/0",
        "Flow:/Specification/wo_edf_esl_mmu3_axi/T/0",
        "Flow:/Specification/wo_edf_pcie_axi/T/0",
        "Flow:/Specification/wo_edfbottom_pipe_bottom0_axi/T/0",
        "Flow:/Specification/wo_edfbottom_pipe_bottom1_axi/T/0", "RESERVED", "RESERVED",
    }};

    const std::array<std::string, 256> NOCERR_EDF_CORER_USER_FLAGS_ARRAY{{
        "Allocate", "Bufferable", "Cache_0", "Cache_1", "Cache_2", "Cache_3", "Instruction",
        "Lookup", "Modifiable", "Nonsecured", "Privileged", "Prot_0", "Prot_1", "Prot_2",
        "reqUser_00", "reqUser_01", "reqUser_02", "reqUser_03", "reqUser_04", "reqUser_05",
        "reqUser_06", "reqUser_07", "reqUser_08", "reqUser_09", "reqUser_10", "reqUser_11",
        "reqUser_12", "reqUser_13", "reqUser_14", "reqUser_15", "reqUser_16", "reqUser_17",
        "reqUser_18", "reqUser_19", "reqUser_20", "reqUser_21", "reqUser_22", "reqUser_23",
        "reqUser_24", "reqUser_25", "reqUser_26", "reqUser_27", "reqUser_28", "reqUser_29",
        "reqUser_30", "reqUser_31", "reqUser_32", "reqUser_33", "reqUser_34", "reqUser_35",
        "user_endianness",
    }};
    const std::array<std::string, 256> NOCERR_EDF_CORER_INIT_ARRAY{{
        "Flow:/Specification/ecf_edfcorer_axi/I/0", "Flow:/Specification/ro_ap_edf_axi/I/0",
        "Flow:/Specification/ro_cdft_edf_axi/I/0", "Flow:/Specification/ro_dpf_edf_axi/I/0",
        "Flow:/Specification/ro_edte_p0_edf_axi/I/0",
        "Flow:/Specification/ro_edte_p1_edf_axi/I/0",
        "Flow:/Specification/ro_pipe_bottom0_edfcore_axi/I/0",
        "Flow:/Specification/ro_pipe_bottom1_edfcore_axi/I/0",
        "Flow:/Specification/ro_pipe_top0_edfcore_axi/I/0",
        "Flow:/Specification/ro_pipe_top1_edfcore_axi/I/0",
        "Flow:/Specification/ro_sic_mmu0_p0_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu0_p1_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu0_p2_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu0_p3_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu1_p0_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu1_p1_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu1_p2_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu1_p3_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu2_p0_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu2_p1_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu2_p2_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu2_p3_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu3_p0_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu3_p1_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu3_p2_edf_axi/I/0",
        "Flow:/Specification/ro_sic_mmu3_p3_edf_axi/I/0",
        "Flow:/Specification/ro_sp_edf_axi/I/0", "Flow:/Specification/ro_ssm_edf_axi/I/0",
        "Flow:/Specification/ro_vpu_edf_axi/I/0", "RESERVED", "RESERVED", "RESERVED",
    }};
    const std::array<std::string, 256> NOCERR_EDF_CORER_TARGET_ARRAY{{
        "Flow:/Specification/edf_corer_service/T/0", "Flow:/Specification/ro_edf_llc0_axi/T/0",
        "Flow:/Specification/ro_edf_llc10_axi/T/0", "Flow:/Specification/ro_edf_llc11_axi/T/0",
        "Flow:/Specification/ro_edf_llc12_axi/T/0", "Flow:/Specification/ro_edf_llc13_axi/T/0",
        "Flow:/Specification/ro_edf_llc14_axi/T/0", "Flow:/Specification/ro_edf_llc15_axi/T/0",
        "Flow:/Specification/ro_edf_llc1_axi/T/0", "Flow:/Specification/ro_edf_llc2_axi/T/0",
        "Flow:/Specification/ro_edf_llc3_axi/T/0", "Flow:/Specification/ro_edf_llc4_axi/T/0",
        "Flow:/Specification/ro_edf_llc5_axi/T/0", "Flow:/Specification/ro_edf_llc6_axi/T/0",
        "Flow:/Specification/ro_edf_llc7_axi/T/0", "Flow:/Specification/ro_edf_llc8_axi/T/0",
        "Flow:/Specification/ro_edf_llc9_axi/T/0",
        "Flow:/Specification/ro_edfcore_pipe_bottom0_axi/T/pcie",
        "Flow:/Specification/ro_edfcore_sicio0_ft_ob_axi/T/0",
        "Flow:/Specification/ro_edfcore_sicio1_ft_ob_axi/T/0",
        "Flow:/Specification/ro_edfcore_sicio2_ft_ob_axi/T/0",
        "Flow:/Specification/ro_edfcore_sicio3_ft_ob_axi/T/0", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED",
    }};

    const std::array<std::string, 256> NOCERR_EDF_COREW_USER_FLAGS_ARRAY{{
        "Allocate", "Bufferable", "Cache_0", "Cache_1", "Cache_2", "Cache_3", "Instruction",
        "Lookup", "Modifiable", "Nonsecured", "Privileged", "Prot_0", "Prot_1", "Prot_2",
        "reqUser_00", "reqUser_01", "reqUser_02", "reqUser_03", "reqUser_04", "reqUser_05",
        "reqUser_06", "reqUser_07", "reqUser_08", "reqUser_09", "reqUser_10", "reqUser_11",
        "reqUser_12", "reqUser_13", "reqUser_14", "reqUser_15", "reqUser_16", "reqUser_17",
        "reqUser_18", "reqUser_19", "reqUser_20", "reqUser_21", "reqUser_22", "reqUser_23",
        "reqUser_24", "reqUser_25", "reqUser_26", "reqUser_27", "reqUser_28", "reqUser_29",
        "reqUser_30", "reqUser_31", "reqUser_32", "reqUser_33", "reqUser_34", "reqUser_35",
        "reqUser_36", "reqUser_37", "reqUser_38", "reqUser_39", "reqUser_40", "reqUser_41",
        "reqUser_42", "reqUser_43", "reqUser_44", "reqUser_45", "reqUser_46", "reqUser_47",
        "user_endianness",
    }};
    const std::array<std::string, 256> NOCERR_EDF_COREW_INIT_ARRAY{{
        "Flow:/Specification/ecf_edfcorew_axi/I/0", "Flow:/Specification/wo_ap_edf_axi/I/0",
        "Flow:/Specification/wo_cdft_edf_axi/I/0", "Flow:/Specification/wo_dpf_edf_axi/I/0",
        "Flow:/Specification/wo_edte_p0_edf_axi/I/0",
        "Flow:/Specification/wo_edte_p1_edf_axi/I/0",
        "Flow:/Specification/wo_pipe_bottom0_edfcore_axi/I/0",
        "Flow:/Specification/wo_pipe_bottom1_edfcore_axi/I/0",
        "Flow:/Specification/wo_pipe_top0_edfcore_axi/I/0",
        "Flow:/Specification/wo_pipe_top1_edfcore_axi/I/0",
        "Flow:/Specification/wo_sic_mmu0_p0_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu0_p1_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu0_p2_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu0_p3_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu1_p0_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu1_p1_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu1_p2_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu1_p3_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu2_p0_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu2_p1_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu2_p2_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu2_p3_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu3_p0_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu3_p1_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu3_p2_edf_axi/I/0",
        "Flow:/Specification/wo_sic_mmu3_p3_edf_axi/I/0",
        "Flow:/Specification/wo_sp_edf_axi/I/0", "Flow:/Specification/wo_ssm_edf_axi/I/0",
        "Flow:/Specification/wo_vpu_edf_axi/I/0", "RESERVED", "RESERVED", "RESERVED",
    }};
    const std::array<std::string, 256> NOCERR_EDF_COREW_TARGET_ARRAY{{
        "Flow:/Specification/wo_edfcore_pipe_bottom0_axi/T/0",
        "Flow:/Specification/wo_edfcore_pipe_bottom0_axi/T/pcie",
        "Flow:/Specification/edf_corew_service/T/0", "Flow:/Specification/wo_edf_llc0_axi/T/0",
        "Flow:/Specification/wo_edf_llc10_axi/T/0", "Flow:/Specification/wo_edf_llc11_axi/T/0",
        "Flow:/Specification/wo_edf_llc12_axi/T/0", "Flow:/Specification/wo_edf_llc13_axi/T/0",
        "Flow:/Specification/wo_edf_llc14_axi/T/0", "Flow:/Specification/wo_edf_llc15_axi/T/0",
        "Flow:/Specification/wo_edf_llc1_axi/T/0", "Flow:/Specification/wo_edf_llc2_axi/T/0",
        "Flow:/Specification/wo_edf_llc3_axi/T/0", "Flow:/Specification/wo_edf_llc4_axi/T/0",
        "Flow:/Specification/wo_edf_llc5_axi/T/0", "Flow:/Specification/wo_edf_llc6_axi/T/0",
        "Flow:/Specification/wo_edf_llc7_axi/T/0", "Flow:/Specification/wo_edf_llc8_axi/T/0",
        "Flow:/Specification/wo_edf_llc9_axi/T/0",
        "Flow:/Specification/wo_edfcore_pipe_bottom1_axi/T/0",
        "Flow:/Specification/wo_edfcore_pipe_top0_axi/T/0",
        "Flow:/Specification/wo_edfcore_pipe_top1_axi/T/0",
        "Flow:/Specification/wo_edfcore_sicio0_ft_ob_axi/T/0",
        "Flow:/Specification/wo_edfcore_sicio1_ft_ob_axi/T/0",
        "Flow:/Specification/wo_edfcore_sicio2_ft_ob_axi/T/0",
        "Flow:/Specification/wo_edfcore_sicio3_ft_ob_axi/T/0", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED",
    }};

    const std::array<std::string, 256> NOCERR_EDF_TOPR_USER_FLAGS_ARRAY{{
        "Cache_0", "Cache_1", "Cache_2", "Cache_3", "Prot_0", "Prot_1", "Prot_2", "reqUser_00",
        "reqUser_01", "reqUser_02", "reqUser_03", "reqUser_04", "reqUser_05", "reqUser_06",
        "reqUser_07", "reqUser_08", "reqUser_09", "reqUser_10", "reqUser_11", "reqUser_12",
        "reqUser_13", "reqUser_14", "reqUser_15", "reqUser_16", "reqUser_17", "reqUser_18",
        "reqUser_19", "reqUser_20", "reqUser_21", "reqUser_22", "reqUser_23", "reqUser_24",
        "reqUser_25", "reqUser_26", "reqUser_27", "reqUser_28", "reqUser_29", "reqUser_30",
        "reqUser_31", "reqUser_32", "reqUser_33", "reqUser_34", "reqUser_35",
        "user_endianness",
    }};
    const std::array<std::string, 256> NOCERR_EDF_TOPR_INIT_ARRAY{{
        "Flow:/Specification/ecf_edftopr_axi/I/0", "Flow:/Specification/ro_esl0_edf_axi/I/0",
        "Flow:/Specification/ro_esl1_edf_axi/I/0", "Flow:/Specification/ro_esl2_edf_axi/I/0",
        "Flow:/Specification/ro_esl3_edf_axi/I/0", "Flow:/Specification/ro_esl4_edf_axi/I/0",
        "Flow:/Specification/ro_esl5_edf_axi/I/0", "Flow:/Specification/ro_esl6_edf_axi/I/0",
        "Flow:/Specification/ro_esl7_edf_axi/I/0",
        "Flow:/Specification/ro_esl_mmu0_edf_axi/I/0",
        "Flow:/Specification/ro_esl_mmu1_edf_axi/I/0", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED",
    }};
    const std::array<std::string, 256> NOCERR_EDF_TOPR_TARGET_ARRAY{{
        "Flow:/Specification/edf_topr_service/T/0",
        "Flow:/Specification/ro_edf_esl_mmu0_axi/T/0",
        "Flow:/Specification/ro_edf_esl_mmu1_axi/T/0",
        "Flow:/Specification/ro_edftop_pipe_top0_axi/T/0",
        "Flow:/Specification/ro_edftop_pipe_top1_axi/T/0", "RESERVED", "RESERVED", "RESERVED",
    }};

    const std::array<std::string, 256> NOCERR_EDF_TOPW_USER_FLAGS_ARRAY{{
        "Cache_0", "Cache_1", "Cache_2", "Cache_3", "Prot_0", "Prot_1", "Prot_2", "reqUser_00",
        "reqUser_01", "reqUser_02", "reqUser_03", "reqUser_04", "reqUser_05", "reqUser_06",
        "reqUser_07", "reqUser_08", "reqUser_09", "reqUser_10", "reqUser_11", "reqUser_12",
        "reqUser_13", "reqUser_14", "reqUser_15", "reqUser_16", "reqUser_17", "reqUser_18",
        "reqUser_19", "reqUser_20", "reqUser_21", "reqUser_22", "reqUser_23", "reqUser_24",
        "reqUser_25", "reqUser_26", "reqUser_27", "reqUser_28", "reqUser_29", "reqUser_30",
        "reqUser_31", "reqUser_32", "reqUser_33", "reqUser_34", "reqUser_35", "reqUser_36",
        "reqUser_37", "reqUser_38", "reqUser_39", "reqUser_40", "reqUser_41", "reqUser_42",
        "reqUser_43", "reqUser_44", "reqUser_45", "reqUser_46", "reqUser_47",
        "user_endianness",
    }};
    const std::array<std::string, 256> NOCERR_EDF_TOPW_INIT_ARRAY{{
        "Flow:/Specification/ecf_edftopw_axi/I/0", "Flow:/Specification/wo_esl0_edf_axi/I/0",
        "Flow:/Specification/wo_esl0_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl1_edf_axi/I/0",
        "Flow:/Specification/wo_esl1_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl2_edf_axi/I/0",
        "Flow:/Specification/wo_esl2_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl3_edf_axi/I/0",
        "Flow:/Specification/wo_esl3_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl4_edf_axi/I/0",
        "Flow:/Specification/wo_esl4_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl5_edf_axi/I/0",
        "Flow:/Specification/wo_esl5_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl6_edf_axi/I/0",
        "Flow:/Specification/wo_esl6_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl7_edf_axi/I/0",
        "Flow:/Specification/wo_esl7_mirror_edf_axi/I/0",
        "Flow:/Specification/wo_esl_mmu0_edf_axi/I/0",
        "Flow:/Specification/wo_esl_mmu1_edf_axi/I/0",
        "Flow:/Specification/wo_pipe_top0_edftop_axi/I/0",
        "Flow:/Specification/wo_pipe_top1_edftop_axi/I/0", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED",
    }};
    const std::array<std::string, 256> NOCERR_EDF_TOPW_TARGET_ARRAY{{
        "Flow:/Specification/edf_topw_service/T/0", "Flow:/Specification/wo_edf_esl0_axi/T/0",
        "Flow:/Specification/wo_edf_esl1_axi/T/0", "Flow:/Specification/wo_edf_esl2_axi/T/0",
        "Flow:/Specification/wo_edf_esl3_axi/T/0", "Flow:/Specification/wo_edf_esl4_axi/T/0",
        "Flow:/Specification/wo_edf_esl5_axi/T/0", "Flow:/Specification/wo_edf_esl6_axi/T/0",
        "Flow:/Specification/wo_edf_esl7_axi/T/0",
        "Flow:/Specification/wo_edf_esl_mmu0_axi/T/0",
        "Flow:/Specification/wo_edf_esl_mmu1_axi/T/0",
        "Flow:/Specification/wo_edftop_pipe_top0_axi/T/0",
        "Flow:/Specification/wo_edftop_pipe_top1_axi/T/0", "RESERVED", "RESERVED", "",
    }};
};
}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_NOC_LIBRA_NOC_ERR_EDF_H_

// ==============================
// Datapath RouteId decomposition - edf_bottomr
// ==============================

// wRouteId: 19 bits
// ~~~~~~~~~~~~~~~~~
// Field Type    : Bit(s)
// ------------------------
// InitFlow      : 18 .. 15
// TargFlow      : 14 .. 12
// Targ SubRange : 11 .. 10
// OrderKey      : 9 .. 0

// InitFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ------------------------------------------------------------------
// 0          : Flow:/Specification/ecf_edfbottomr_axi/I/0
// 1          : Flow:/Specification/ro_esl10_edf_axi/I/0
// 2          : Flow:/Specification/ro_esl11_edf_axi/I/0
// 3          : Flow:/Specification/ro_esl12_edf_axi/I/0
// 4          : Flow:/Specification/ro_esl13_edf_axi/I/0
// 5          : Flow:/Specification/ro_esl14_edf_axi/I/0
// 6          : Flow:/Specification/ro_esl15_edf_axi/I/0
// 7          : Flow:/Specification/ro_esl8_edf_axi/I/0
// 8          : Flow:/Specification/ro_esl9_edf_axi/I/0
// 9          : Flow:/Specification/ro_esl_mmu2_edf_axi/I/0
// A          : Flow:/Specification/ro_esl_mmu3_edf_axi/I/0
// B          : Flow:/Specification/ro_odte_p0_edf_axi/I/0
// C          : Flow:/Specification/ro_odte_p1_edf_axi/I/0
// D          : Flow:/Specification/ro_pcie_edf_axi/I/0
// E          : Flow:/Specification/ro_pipe_bottom0_edfbottom_axi/I/0
// F          : RESERVED

// TargFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ------------------------------------------------------------------
// 0          : Flow:/Specification/edf_bottomr_service/T/0
// 1          : Flow:/Specification/ro_edf_esl_mmu2_axi/T/0
// 2          : Flow:/Specification/ro_edf_esl_mmu3_axi/T/0
// 3          : Flow:/Specification/ro_edf_pcie_axi/T/0
// 4          : Flow:/Specification/ro_edfbottom_pipe_bottom0_axi/T/0
// 5          : Flow:/Specification/ro_edfbottom_pipe_bottom1_axi/T/0
// 6          : RESERVED
// 7          : RESERVED

// ==============================
// Datapath RouteId decomposition - edf_bottomw
// ==============================

// wRouteId: 21 bits
// ~~~~~~~~~~~~~~~~~
// Field Type    : Bit(s)
// ------------------------
// InitFlow      : 20 .. 16
// TargFlow      : 15 .. 12
// Targ SubRange : 11 .. 10
// OrderKey      : 9 .. 0

// InitFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ------------------------------------------------------------------
// 0          : Flow:/Specification/ecf_edfbottomw_axi/I/0
// 1          : Flow:/Specification/wo_esl10_edf_axi/I/0
// 2          : Flow:/Specification/wo_esl10_mirror_edf_axi/I/0
// 3          : Flow:/Specification/wo_esl11_edf_axi/I/0
// 4          : Flow:/Specification/wo_esl11_mirror_edf_axi/I/0
// 5          : Flow:/Specification/wo_esl12_edf_axi/I/0
// 6          : Flow:/Specification/wo_esl12_mirror_edf_axi/I/0
// 7          : Flow:/Specification/wo_esl13_edf_axi/I/0
// 8          : Flow:/Specification/wo_esl13_mirror_edf_axi/I/0
// 9          : Flow:/Specification/wo_esl14_edf_axi/I/0
// A          : Flow:/Specification/wo_esl14_mirror_edf_axi/I/0
// B          : Flow:/Specification/wo_esl15_edf_axi/I/0
// C          : Flow:/Specification/wo_esl15_mirror_edf_axi/I/0
// D          : Flow:/Specification/wo_esl8_edf_axi/I/0
// E          : Flow:/Specification/wo_esl8_mirror_edf_axi/I/0
// F          : Flow:/Specification/wo_esl9_edf_axi/I/0
// 10         : Flow:/Specification/wo_esl9_mirror_edf_axi/I/0
// 11         : Flow:/Specification/wo_esl_mmu2_edf_axi/I/0
// 12         : Flow:/Specification/wo_esl_mmu3_edf_axi/I/0
// 13         : Flow:/Specification/wo_odte_p0_edf_axi/I/0
// 14         : Flow:/Specification/wo_odte_p1_edf_axi/I/0
// 15         : Flow:/Specification/wo_pcie_edf_axi/I/0
// 16         : Flow:/Specification/wo_pipe_bottom0_edfbottom_axi/I/0
// 17         : Flow:/Specification/wo_pipe_bottom1_edfbottom_axi/I/0
// 18         : RESERVED
// 19         : RESERVED
// 1A         : RESERVED
// 1B         : RESERVED
// 1C         : RESERVED
// 1D         : RESERVED
// 1E         : RESERVED
// 1F         : RESERVED

// TargFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ------------------------------------------------------------------
// 0          : Flow:/Specification/edf_bottomw_service/T/0
// 1          : Flow:/Specification/wo_edf_esl10_axi/T/0
// 2          : Flow:/Specification/wo_edf_esl11_axi/T/0
// 3          : Flow:/Specification/wo_edf_esl12_axi/T/0
// 4          : Flow:/Specification/wo_edf_esl13_axi/T/0
// 5          : Flow:/Specification/wo_edf_esl14_axi/T/0
// 6          : Flow:/Specification/wo_edf_esl15_axi/T/0
// 7          : Flow:/Specification/wo_edf_esl8_axi/T/0
// 8          : Flow:/Specification/wo_edf_esl9_axi/T/0
// 9          : Flow:/Specification/wo_edf_esl_mmu2_axi/T/0
// A          : Flow:/Specification/wo_edf_esl_mmu3_axi/T/0
// B          : Flow:/Specification/wo_edf_pcie_axi/T/0
// C          : Flow:/Specification/wo_edfbottom_pipe_bottom0_axi/T/0
// D          : Flow:/Specification/wo_edfbottom_pipe_bottom1_axi/T/0
// E          : RESERVED
// F          : RESERVED

// ==============================
// Datapath RouteId decomposition - edf_corer
// ==============================

// wRouteId: 28 bits
// ~~~~~~~~~~~~~~~~~
// Field Type    : Bit(s)
// ------------------------
// InitFlow      : 27 .. 23
// TargFlow      : 22 .. 18
// Targ SubRange : 17
// OrderKey      : 16 .. 0

// InitFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ----------------------------------------------------------------
// 0          : Flow:/Specification/ecf_edfcorer_axi/I/0
// 1          : Flow:/Specification/ro_ap_edf_axi/I/0
// 2          : Flow:/Specification/ro_cdft_edf_axi/I/0
// 3          : Flow:/Specification/ro_dpf_edf_axi/I/0
// 4          : Flow:/Specification/ro_edte_p0_edf_axi/I/0
// 5          : Flow:/Specification/ro_edte_p1_edf_axi/I/0
// 6          : Flow:/Specification/ro_pipe_bottom0_edfcore_axi/I/0
// 7          : Flow:/Specification/ro_pipe_bottom1_edfcore_axi/I/0
// 8          : Flow:/Specification/ro_pipe_top0_edfcore_axi/I/0
// 9          : Flow:/Specification/ro_pipe_top1_edfcore_axi/I/0
// A          : Flow:/Specification/ro_sic_mmu0_p0_edf_axi/I/0
// B          : Flow:/Specification/ro_sic_mmu0_p1_edf_axi/I/0
// C          : Flow:/Specification/ro_sic_mmu0_p2_edf_axi/I/0
// D          : Flow:/Specification/ro_sic_mmu0_p3_edf_axi/I/0
// E          : Flow:/Specification/ro_sic_mmu1_p0_edf_axi/I/0
// F          : Flow:/Specification/ro_sic_mmu1_p1_edf_axi/I/0
// 10         : Flow:/Specification/ro_sic_mmu1_p2_edf_axi/I/0
// 11         : Flow:/Specification/ro_sic_mmu1_p3_edf_axi/I/0
// 12         : Flow:/Specification/ro_sic_mmu2_p0_edf_axi/I/0
// 13         : Flow:/Specification/ro_sic_mmu2_p1_edf_axi/I/0
// 14         : Flow:/Specification/ro_sic_mmu2_p2_edf_axi/I/0
// 15         : Flow:/Specification/ro_sic_mmu2_p3_edf_axi/I/0
// 16         : Flow:/Specification/ro_sic_mmu3_p0_edf_axi/I/0
// 17         : Flow:/Specification/ro_sic_mmu3_p1_edf_axi/I/0
// 18         : Flow:/Specification/ro_sic_mmu3_p2_edf_axi/I/0
// 19         : Flow:/Specification/ro_sic_mmu3_p3_edf_axi/I/0
// 1A         : Flow:/Specification/ro_sp_edf_axi/I/0
// 1B         : Flow:/Specification/ro_ssm_edf_axi/I/0
// 1C         : Flow:/Specification/ro_vpu_edf_axi/I/0
// 1D         : RESERVED
// 1E         : RESERVED
// 1F         : RESERVED

// TargFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// -------------------------------------------------------------------
// 0          : Flow:/Specification/edf_corer_service/T/0
// 1          : Flow:/Specification/ro_edf_llc0_axi/T/0
// 2          : Flow:/Specification/ro_edf_llc10_axi/T/0
// 3          : Flow:/Specification/ro_edf_llc11_axi/T/0
// 4          : Flow:/Specification/ro_edf_llc12_axi/T/0
// 5          : Flow:/Specification/ro_edf_llc13_axi/T/0
// 6          : Flow:/Specification/ro_edf_llc14_axi/T/0
// 7          : Flow:/Specification/ro_edf_llc15_axi/T/0
// 8          : Flow:/Specification/ro_edf_llc1_axi/T/0
// 9          : Flow:/Specification/ro_edf_llc2_axi/T/0
// A          : Flow:/Specification/ro_edf_llc3_axi/T/0
// B          : Flow:/Specification/ro_edf_llc4_axi/T/0
// C          : Flow:/Specification/ro_edf_llc5_axi/T/0
// D          : Flow:/Specification/ro_edf_llc6_axi/T/0
// E          : Flow:/Specification/ro_edf_llc7_axi/T/0
// F          : Flow:/Specification/ro_edf_llc8_axi/T/0
// 10         : Flow:/Specification/ro_edf_llc9_axi/T/0
// 11         : Flow:/Specification/ro_edfcore_pipe_bottom0_axi/T/pcie
// 12         : Flow:/Specification/ro_edfcore_sicio0_ft_ob_axi/T/0
// 13         : Flow:/Specification/ro_edfcore_sicio1_ft_ob_axi/T/0
// 14         : Flow:/Specification/ro_edfcore_sicio2_ft_ob_axi/T/0
// 15         : Flow:/Specification/ro_edfcore_sicio3_ft_ob_axi/T/0
// 16         : RESERVED
// 17         : RESERVED
// 18         : RESERVED
// 19         : RESERVED
// 1A         : RESERVED
// 1B         : RESERVED
// 1C         : RESERVED
// 1D         : RESERVED
// 1E         : RESERVED
// 1F         : RESERVED

// ==============================
// Datapath RouteId decomposition - edf_corew
// ==============================

// wRouteId: 28 bits
// ~~~~~~~~~~~~~~~~~
// Field Type    : Bit(s)
// ------------------------
// InitFlow      : 27 .. 23
// TargFlow      : 22 .. 18
// Targ SubRange : 17
// OrderKey      : 16 .. 0

// InitFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ----------------------------------------------------------------
// 0          : Flow:/Specification/ecf_edfcorew_axi/I/0
// 1          : Flow:/Specification/wo_ap_edf_axi/I/0
// 2          : Flow:/Specification/wo_cdft_edf_axi/I/0
// 3          : Flow:/Specification/wo_dpf_edf_axi/I/0
// 4          : Flow:/Specification/wo_edte_p0_edf_axi/I/0
// 5          : Flow:/Specification/wo_edte_p1_edf_axi/I/0
// 6          : Flow:/Specification/wo_pipe_bottom0_edfcore_axi/I/0
// 7          : Flow:/Specification/wo_pipe_bottom1_edfcore_axi/I/0
// 8          : Flow:/Specification/wo_pipe_top0_edfcore_axi/I/0
// 9          : Flow:/Specification/wo_pipe_top1_edfcore_axi/I/0
// A          : Flow:/Specification/wo_sic_mmu0_p0_edf_axi/I/0
// B          : Flow:/Specification/wo_sic_mmu0_p1_edf_axi/I/0
// C          : Flow:/Specification/wo_sic_mmu0_p2_edf_axi/I/0
// D          : Flow:/Specification/wo_sic_mmu0_p3_edf_axi/I/0
// E          : Flow:/Specification/wo_sic_mmu1_p0_edf_axi/I/0
// F          : Flow:/Specification/wo_sic_mmu1_p1_edf_axi/I/0
// 10         : Flow:/Specification/wo_sic_mmu1_p2_edf_axi/I/0
// 11         : Flow:/Specification/wo_sic_mmu1_p3_edf_axi/I/0
// 12         : Flow:/Specification/wo_sic_mmu2_p0_edf_axi/I/0
// 13         : Flow:/Specification/wo_sic_mmu2_p1_edf_axi/I/0
// 14         : Flow:/Specification/wo_sic_mmu2_p2_edf_axi/I/0
// 15         : Flow:/Specification/wo_sic_mmu2_p3_edf_axi/I/0
// 16         : Flow:/Specification/wo_sic_mmu3_p0_edf_axi/I/0
// 17         : Flow:/Specification/wo_sic_mmu3_p1_edf_axi/I/0
// 18         : Flow:/Specification/wo_sic_mmu3_p2_edf_axi/I/0
// 19         : Flow:/Specification/wo_sic_mmu3_p3_edf_axi/I/0
// 1A         : Flow:/Specification/wo_sp_edf_axi/I/0
// 1B         : Flow:/Specification/wo_ssm_edf_axi/I/0
// 1C         : Flow:/Specification/wo_vpu_edf_axi/I/0
// 1D         : RESERVED
// 1E         : RESERVED
// 1F         : RESERVED

// TargFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// -------------------------------------------------------------------
// 0          : Flow:/Specification/wo_edfcore_pipe_bottom0_axi/T/0
// 1          : Flow:/Specification/wo_edfcore_pipe_bottom0_axi/T/pcie
// 2          : Flow:/Specification/edf_corew_service/T/0
// 3          : Flow:/Specification/wo_edf_llc0_axi/T/0
// 4          : Flow:/Specification/wo_edf_llc10_axi/T/0
// 5          : Flow:/Specification/wo_edf_llc11_axi/T/0
// 6          : Flow:/Specification/wo_edf_llc12_axi/T/0
// 7          : Flow:/Specification/wo_edf_llc13_axi/T/0
// 8          : Flow:/Specification/wo_edf_llc14_axi/T/0
// 9          : Flow:/Specification/wo_edf_llc15_axi/T/0
// A          : Flow:/Specification/wo_edf_llc1_axi/T/0
// B          : Flow:/Specification/wo_edf_llc2_axi/T/0
// C          : Flow:/Specification/wo_edf_llc3_axi/T/0
// D          : Flow:/Specification/wo_edf_llc4_axi/T/0
// E          : Flow:/Specification/wo_edf_llc5_axi/T/0
// F          : Flow:/Specification/wo_edf_llc6_axi/T/0
// 10         : Flow:/Specification/wo_edf_llc7_axi/T/0
// 11         : Flow:/Specification/wo_edf_llc8_axi/T/0
// 12         : Flow:/Specification/wo_edf_llc9_axi/T/0
// 13         : Flow:/Specification/wo_edfcore_pipe_bottom1_axi/T/0
// 14         : Flow:/Specification/wo_edfcore_pipe_top0_axi/T/0
// 15         : Flow:/Specification/wo_edfcore_pipe_top1_axi/T/0
// 16         : Flow:/Specification/wo_edfcore_sicio0_ft_ob_axi/T/0
// 17         : Flow:/Specification/wo_edfcore_sicio1_ft_ob_axi/T/0
// 18         : Flow:/Specification/wo_edfcore_sicio2_ft_ob_axi/T/0
// 19         : Flow:/Specification/wo_edfcore_sicio3_ft_ob_axi/T/0
// 1A         : RESERVED
// 1B         : RESERVED
// 1C         : RESERVED
// 1D         : RESERVED
// 1E         : RESERVED
// 1F         : RESERVED

// ==============================
// Datapath RouteId decomposition - edf_topr
// ==============================

// wRouteId: 19 bits
// ~~~~~~~~~~~~~~~~~
// Field Type    : Bit(s)
// ------------------------
// InitFlow      : 18 .. 15
// TargFlow      : 14 .. 12
// Targ SubRange : 11 .. 10
// OrderKey      : 9 .. 0

// InitFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// --------------------------------------------------------
// 0          : Flow:/Specification/ecf_edftopr_axi/I/0
// 1          : Flow:/Specification/ro_esl0_edf_axi/I/0
// 2          : Flow:/Specification/ro_esl1_edf_axi/I/0
// 3          : Flow:/Specification/ro_esl2_edf_axi/I/0
// 4          : Flow:/Specification/ro_esl3_edf_axi/I/0
// 5          : Flow:/Specification/ro_esl4_edf_axi/I/0
// 6          : Flow:/Specification/ro_esl5_edf_axi/I/0
// 7          : Flow:/Specification/ro_esl6_edf_axi/I/0
// 8          : Flow:/Specification/ro_esl7_edf_axi/I/0
// 9          : Flow:/Specification/ro_esl_mmu0_edf_axi/I/0
// A          : Flow:/Specification/ro_esl_mmu1_edf_axi/I/0
// B          : RESERVED
// C          : RESERVED
// D          : RESERVED
// E          : RESERVED
// F          : RESERVED

// TargFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ------------------------------------------------------------
// 0          : Flow:/Specification/edf_topr_service/T/0
// 1          : Flow:/Specification/ro_edf_esl_mmu0_axi/T/0
// 2          : Flow:/Specification/ro_edf_esl_mmu1_axi/T/0
// 3          : Flow:/Specification/ro_edftop_pipe_top0_axi/T/0
// 4          : Flow:/Specification/ro_edftop_pipe_top1_axi/T/0
// 5          : RESERVED
// 6          : RESERVED
// 7          : RESERVED

// ==============================
// Datapath RouteId decomposition - edf_topw
// ==============================

// wRouteId: 21 bits
// ~~~~~~~~~~~~~~~~~
// Field Type    : Bit(s)
// ------------------------
// InitFlow      : 20 .. 16
// TargFlow      : 15 .. 12
// Targ SubRange : 11 .. 10
// OrderKey      : 9 .. 0

// InitFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ------------------------------------------------------------
// 0          : Flow:/Specification/ecf_edftopw_axi/I/0
// 1          : Flow:/Specification/wo_esl0_edf_axi/I/0
// 2          : Flow:/Specification/wo_esl0_mirror_edf_axi/I/0
// 3          : Flow:/Specification/wo_esl1_edf_axi/I/0
// 4          : Flow:/Specification/wo_esl1_mirror_edf_axi/I/0
// 5          : Flow:/Specification/wo_esl2_edf_axi/I/0
// 6          : Flow:/Specification/wo_esl2_mirror_edf_axi/I/0
// 7          : Flow:/Specification/wo_esl3_edf_axi/I/0
// 8          : Flow:/Specification/wo_esl3_mirror_edf_axi/I/0
// 9          : Flow:/Specification/wo_esl4_edf_axi/I/0
// A          : Flow:/Specification/wo_esl4_mirror_edf_axi/I/0
// B          : Flow:/Specification/wo_esl5_edf_axi/I/0
// C          : Flow:/Specification/wo_esl5_mirror_edf_axi/I/0
// D          : Flow:/Specification/wo_esl6_edf_axi/I/0
// E          : Flow:/Specification/wo_esl6_mirror_edf_axi/I/0
// F          : Flow:/Specification/wo_esl7_edf_axi/I/0
// 10         : Flow:/Specification/wo_esl7_mirror_edf_axi/I/0
// 11         : Flow:/Specification/wo_esl_mmu0_edf_axi/I/0
// 12         : Flow:/Specification/wo_esl_mmu1_edf_axi/I/0
// 13         : Flow:/Specification/wo_pipe_top0_edftop_axi/I/0
// 14         : Flow:/Specification/wo_pipe_top1_edftop_axi/I/0
// 15         : RESERVED
// 16         : RESERVED
// 17         : RESERVED
// 18         : RESERVED
// 19         : RESERVED
// 1A         : RESERVED
// 1B         : RESERVED
// 1C         : RESERVED
// 1D         : RESERVED
// 1E         : RESERVED
// 1F         : RESERVED

// TargFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ------------------------------------------------------------
// 0          : Flow:/Specification/edf_topw_service/T/0
// 1          : Flow:/Specification/wo_edf_esl0_axi/T/0
// 2          : Flow:/Specification/wo_edf_esl1_axi/T/0
// 3          : Flow:/Specification/wo_edf_esl2_axi/T/0
// 4          : Flow:/Specification/wo_edf_esl3_axi/T/0
// 5          : Flow:/Specification/wo_edf_esl4_axi/T/0
// 6          : Flow:/Specification/wo_edf_esl5_axi/T/0
// 7          : Flow:/Specification/wo_edf_esl6_axi/T/0
// 8          : Flow:/Specification/wo_edf_esl7_axi/T/0
// 9          : Flow:/Specification/wo_edf_esl_mmu0_axi/T/0
// A          : Flow:/Specification/wo_edf_esl_mmu1_axi/T/0
// B          : Flow:/Specification/wo_edftop_pipe_top0_axi/T/0
// C          : Flow:/Specification/wo_edftop_pipe_top1_axi/T/0
// D          : RESERVED
// E          : RESERVED
// F          : RESERVED

// ==================
// User flags details -- edf_bottomr
// ==================

//    0 : Cache_0
//    1 : Cache_1
//    2 : Cache_2
//    3 : Cache_3
//    4 : Prot_0
//    5 : Prot_1
//    6 : Prot_2
//    7 : reqUser_00
//    8 : reqUser_01
//    9 : reqUser_02
//   10 : reqUser_03
//   11 : reqUser_04
//   12 : reqUser_05
//   13 : reqUser_06
//   14 : reqUser_07
//   15 : reqUser_08
//   16 : reqUser_09
//   17 : reqUser_10
//   18 : reqUser_11
//   19 : reqUser_12
//   20 : reqUser_13
//   21 : reqUser_14
//   22 : reqUser_15
//   23 : reqUser_16
//   24 : reqUser_17
//   25 : reqUser_18
//   26 : reqUser_19
//   27 : reqUser_20
//   28 : reqUser_21
//   29 : reqUser_22
//   30 : reqUser_23
//   31 : reqUser_24
//   32 : reqUser_25
//   33 : reqUser_26
//   34 : reqUser_27
//   35 : reqUser_28
//   36 : reqUser_29
//   37 : reqUser_30
//   38 : reqUser_31
//   39 : reqUser_32
//   40 : reqUser_33
//   41 : reqUser_34
//   42 : reqUser_35
//   43 : user_endianness

// ==================
// User flags details-- edf_bottomw
// ==================

//    0 : Cache_0
//    1 : Cache_1
//    2 : Cache_2
//    3 : Cache_3
//    4 : Prot_0
//    5 : Prot_1
//    6 : Prot_2
//    7 : reqUser_00
//    8 : reqUser_01
//    9 : reqUser_02
//   10 : reqUser_03
//   11 : reqUser_04
//   12 : reqUser_05
//   13 : reqUser_06
//   14 : reqUser_07
//   15 : reqUser_08
//   16 : reqUser_09
//   17 : reqUser_10
//   18 : reqUser_11
//   19 : reqUser_12
//   20 : reqUser_13
//   21 : reqUser_14
//   22 : reqUser_15
//   23 : reqUser_16
//   24 : reqUser_17
//   25 : reqUser_18
//   26 : reqUser_19
//   27 : reqUser_20
//   28 : reqUser_21
//   29 : reqUser_22
//   30 : reqUser_23
//   31 : reqUser_24
//   32 : reqUser_25
//   33 : reqUser_26
//   34 : reqUser_27
//   35 : reqUser_28
//   36 : reqUser_29
//   37 : reqUser_30
//   38 : reqUser_31
//   39 : reqUser_32
//   40 : reqUser_33
//   41 : reqUser_34
//   42 : reqUser_35
//   43 : reqUser_36
//   44 : reqUser_37
//   45 : reqUser_38
//   46 : reqUser_39
//   47 : reqUser_40
//   48 : reqUser_41
//   49 : reqUser_42
//   50 : reqUser_43
//   51 : reqUser_44
//   52 : reqUser_45
//   53 : reqUser_46
//   54 : reqUser_47
//   55 : user_endianness

// ==================
// User flags details - edf_corer
// ==================

//    0 : Allocate
//    1 : Bufferable
//    2 : Cache_0
//    3 : Cache_1
//    4 : Cache_2
//    5 : Cache_3
//    6 : Instruction
//    7 : Lookup
//    8 : Modifiable
//    9 : Nonsecured
//   10 : Privileged
//   11 : Prot_0
//   12 : Prot_1
//   13 : Prot_2
//   14 : reqUser_00
//   15 : reqUser_01
//   16 : reqUser_02
//   17 : reqUser_03
//   18 : reqUser_04
//   19 : reqUser_05
//   20 : reqUser_06
//   21 : reqUser_07
//   22 : reqUser_08
//   23 : reqUser_09
//   24 : reqUser_10
//   25 : reqUser_11
//   26 : reqUser_12
//   27 : reqUser_13
//   28 : reqUser_14
//   29 : reqUser_15
//   30 : reqUser_16
//   31 : reqUser_17
//   32 : reqUser_18
//   33 : reqUser_19
//   34 : reqUser_20
//   35 : reqUser_21
//   36 : reqUser_22
//   37 : reqUser_23
//   38 : reqUser_24
//   39 : reqUser_25
//   40 : reqUser_26
//   41 : reqUser_27
//   42 : reqUser_28
//   43 : reqUser_29
//   44 : reqUser_30
//   45 : reqUser_31
//   46 : reqUser_32
//   47 : reqUser_33
//   48 : reqUser_34
//   49 : reqUser_35
//   50 : user_endianness

// ==================
// User flags details - edf_corew
// ==================

//    0 : Allocate
//    1 : Bufferable
//    2 : Cache_0
//    3 : Cache_1
//    4 : Cache_2
//    5 : Cache_3
//    6 : Instruction
//    7 : Lookup
//    8 : Modifiable
//    9 : Nonsecured
//   10 : Privileged
//   11 : Prot_0
//   12 : Prot_1
//   13 : Prot_2
//   14 : reqUser_00
//   15 : reqUser_01
//   16 : reqUser_02
//   17 : reqUser_03
//   18 : reqUser_04
//   19 : reqUser_05
//   20 : reqUser_06
//   21 : reqUser_07
//   22 : reqUser_08
//   23 : reqUser_09
//   24 : reqUser_10
//   25 : reqUser_11
//   26 : reqUser_12
//   27 : reqUser_13
//   28 : reqUser_14
//   29 : reqUser_15
//   30 : reqUser_16
//   31 : reqUser_17
//   32 : reqUser_18
//   33 : reqUser_19
//   34 : reqUser_20
//   35 : reqUser_21
//   36 : reqUser_22
//   37 : reqUser_23
//   38 : reqUser_24
//   39 : reqUser_25
//   40 : reqUser_26
//   41 : reqUser_27
//   42 : reqUser_28
//   43 : reqUser_29
//   44 : reqUser_30
//   45 : reqUser_31
//   46 : reqUser_32
//   47 : reqUser_33
//   48 : reqUser_34
//   49 : reqUser_35
//   50 : reqUser_36
//   51 : reqUser_37
//   52 : reqUser_38
//   53 : reqUser_39
//   54 : reqUser_40
//   55 : reqUser_41
//   56 : reqUser_42
//   57 : reqUser_43
//   58 : reqUser_44
//   59 : reqUser_45
//   60 : reqUser_46
//   61 : reqUser_47
//   62 : user_endianness

// ==================
// User flags details - edf_topr
// ==================

//    0 : Cache_0
//    1 : Cache_1
//    2 : Cache_2
//    3 : Cache_3
//    4 : Prot_0
//    5 : Prot_1
//    6 : Prot_2
//    7 : reqUser_00
//    8 : reqUser_01
//    9 : reqUser_02
//   10 : reqUser_03
//   11 : reqUser_04
//   12 : reqUser_05
//   13 : reqUser_06
//   14 : reqUser_07
//   15 : reqUser_08
//   16 : reqUser_09
//   17 : reqUser_10
//   18 : reqUser_11
//   19 : reqUser_12
//   20 : reqUser_13
//   21 : reqUser_14
//   22 : reqUser_15
//   23 : reqUser_16
//   24 : reqUser_17
//   25 : reqUser_18
//   26 : reqUser_19
//   27 : reqUser_20
//   28 : reqUser_21
//   29 : reqUser_22
//   30 : reqUser_23
//   31 : reqUser_24
//   32 : reqUser_25
//   33 : reqUser_26
//   34 : reqUser_27
//   35 : reqUser_28
//   36 : reqUser_29
//   37 : reqUser_30
//   38 : reqUser_31
//   39 : reqUser_32
//   40 : reqUser_33
//   41 : reqUser_34
//   42 : reqUser_35
//   43 : user_endianness
// 、

// ==================
// User flags details - edf_topw
// ==================

//    0 : Cache_0
//    1 : Cache_1
//    2 : Cache_2
//    3 : Cache_3
//    4 : Prot_0
//    5 : Prot_1
//    6 : Prot_2
//    7 : reqUser_00
//    8 : reqUser_01
//    9 : reqUser_02
//   10 : reqUser_03
//   11 : reqUser_04
//   12 : reqUser_05
//   13 : reqUser_06
//   14 : reqUser_07
//   15 : reqUser_08
//   16 : reqUser_09
//   17 : reqUser_10
//   18 : reqUser_11
//   19 : reqUser_12
//   20 : reqUser_13
//   21 : reqUser_14
//   22 : reqUser_15
//   23 : reqUser_16
//   24 : reqUser_17
//   25 : reqUser_18
//   26 : reqUser_19
//   27 : reqUser_20
//   28 : reqUser_21
//   29 : reqUser_22
//   30 : reqUser_23
//   31 : reqUser_24
//   32 : reqUser_25
//   33 : reqUser_26
//   34 : reqUser_27
//   35 : reqUser_28
//   36 : reqUser_29
//   37 : reqUser_30
//   38 : reqUser_31
//   39 : reqUser_32
//   40 : reqUser_33
//   41 : reqUser_34
//   42 : reqUser_35
//   43 : reqUser_36
//   44 : reqUser_37
//   45 : reqUser_38
//   46 : reqUser_39
//   47 : reqUser_40
//   48 : reqUser_41
//   49 : reqUser_42
//   50 : reqUser_43
//   51 : reqUser_44
//   52 : reqUser_45
//   53 : reqUser_46
//   54 : reqUser_47
//   55 : user_endianness
