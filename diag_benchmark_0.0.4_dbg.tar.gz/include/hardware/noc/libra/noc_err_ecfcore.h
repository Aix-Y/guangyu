/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_NOC_LIBRA_NOC_ERR_ECFCORE_H_
#define HARDWARE_NOC_LIBRA_NOC_ERR_ECFCORE_H_

#include <memory>
#include <set>
#include <string>
#include "device/dtus/libra/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/noc/noc_error.h"

namespace efvf {
namespace hardware {
namespace noc {
class NocErrEcfCoreLibra : public NocErr {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit NocErrEcfCoreLibra(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~NocErrEcfCoreLibra() {}
    virtual bool Dump(NOC_Err_Info &err);
    virtual bool Clear();
    virtual bool IsErrValid(void);

 protected:
    virtual int TriggerClr();
    virtual int DumpRoute(NOC_Err_Info &err);
    virtual int DumpOffset(NOC_Err_Info &err);
    virtual int DumpAxUser(NOC_Err_Info &err);
    virtual int DumpValid(NOC_Err_Info &err);
    virtual uint32_t DumpErrType(NOC_Err_Info &err);

 private:
    typedef struct _ECF_Core_RouteId_Libra_t {
#if BYTE_ORDER == LITTLE_ENDIAN
        unsigned int Reserved0 : 12;
        unsigned int Slave : 7;
        unsigned int Master : 7;
        unsigned int Reserved1 : 6;

#elif BYTE_ORDER == BIG_ENDIAN
        unsigned int Reserved1 : 6;
        unsigned int Master : 7;
        unsigned int Slave : 7;
        unsigned int Reserved0 : 12;
#endif
    } ECF_Core_RouteId_Libra_t;

    typedef union {
        unsigned int             val : 32;
        ECF_Core_RouteId_Libra_t f;
    } ECF_Core_RouteId_Libra_u;
    const std::array<std::string, 256> NOCERR_ECFCORE_ERRTYPE_ARRAY{{
        "target error detected by slave", "address decode error", "unsupported request",
        "disconnected target or domain", "security violation",
        "hidden security violation, reported as OK to initiator", "time-out", "Reserved",
    }};
    const std::array<std::string, 256> NOCERR_ECFCORE_USER_FLAGS_ARRAY{{
        "Allocate", "Bufferable", "Cache_0", "Cache_1", "Cache_2", "Cache_3", "Instruction",
        "Lookup", "Modifiable", "Nonsecured", "Privileged", "Prot_0", "Prot_1", "Prot_2",
        "reqUser_00", "reqUser_01", "reqUser_02", "reqUser_03", "reqUser_04", "reqUser_05",
        "reqUser_06", "reqUser_07", "reqUser_08", "reqUser_09", "reqUser_10", "reqUser_11",
        "reqUser_12", "reqUser_13", "reqUser_14", "reqUser_15", "reqUser_16", "reqUser_17",
        "reqUser_18", "reqUser_19", "user_endianness",
    }};
    const std::array<std::string, 256> NOCERR_ECFCORE_INIT_FLOW_ARRAY{{
        "Flow:/Specification/rw_ap_ecf_axi/I/0", "Flow:/Specification/rw_cdft_ecf_axi/I/0",
        "Flow:/Specification/rw_dpf_ecf_axi/I/0",
        "Flow:/Specification/rw_esl0_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl0_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl10_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl10_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl11_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl11_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl12_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl12_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl13_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl13_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl14_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl14_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl15_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl15_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl1_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl1_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl2_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl2_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl3_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl3_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl4_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl4_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl5_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl5_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl6_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl6_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl7_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl7_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl8_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl8_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_esl9_local_ecf_axi/I/0",
        "Flow:/Specification/rw_esl9_remote_ecf_axi/I/0",
        "Flow:/Specification/rw_gmu_ecf_axi/I/0", "Flow:/Specification/rw_llc0_ecf_axi/I/0",
        "Flow:/Specification/rw_llc10_ecf_axi/I/0", "Flow:/Specification/rw_llc11_ecf_axi/I/0",
        "Flow:/Specification/rw_llc12_ecf_axi/I/0", "Flow:/Specification/rw_llc13_ecf_axi/I/0",
        "Flow:/Specification/rw_llc14_ecf_axi/I/0", "Flow:/Specification/rw_llc15_ecf_axi/I/0",
        "Flow:/Specification/rw_llc1_ecf_axi/I/0", "Flow:/Specification/rw_llc2_ecf_axi/I/0",
        "Flow:/Specification/rw_llc3_ecf_axi/I/0", "Flow:/Specification/rw_llc4_ecf_axi/I/0",
        "Flow:/Specification/rw_llc5_ecf_axi/I/0", "Flow:/Specification/rw_llc6_ecf_axi/I/0",
        "Flow:/Specification/rw_llc7_ecf_axi/I/0", "Flow:/Specification/rw_llc8_ecf_axi/I/0",
        "Flow:/Specification/rw_llc9_ecf_axi/I/0", "Flow:/Specification/rw_mc0_ecf_axi/I/0",
        "Flow:/Specification/rw_mc1_ecf_axi/I/0", "Flow:/Specification/rw_mc2_ecf_axi/I/0",
        "Flow:/Specification/rw_mc3_ecf_axi/I/0", "Flow:/Specification/rw_pcie_ecf_axi/I/0",
        "Flow:/Specification/rw_sicio0_ecfcore_ft_ib_axi/I/0",
        "Flow:/Specification/rw_sicio1_ecfcore_ft_ib_axi/I/0",
        "Flow:/Specification/rw_sicio2_ecfcore_ft_ib_axi/I/0",
        "Flow:/Specification/rw_sicio3_ecfcore_ft_ib_axi/I/0",
        "Flow:/Specification/rw_sp_ecf_axi/I/0", "Flow:/Specification/rw_ssm_ecf_axi/I/0",
        "Flow:/Specification/rw_vpu_ecf_axi/I/0", "Flow:/Specification/wo_edte_ecf_axi/I/0",
        "Flow:/Specification/wo_esl_mmu0_ecf_axi/I/0",
        "Flow:/Specification/wo_esl_mmu1_ecf_axi/I/0",
        "Flow:/Specification/wo_esl_mmu2_ecf_axi/I/0",
        "Flow:/Specification/wo_esl_mmu3_ecf_axi/I/0",
        "Flow:/Specification/wo_odte_ecf_axi/I/0", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
    }};

    const std::array<std::string, 256> NOCERR_ECFCORE_TARGET_FLOW_ARRAY{{
        "Flow:/Specification/ecf_core_service/T/0",
        "Flow:/Specification/ecf_edfbottomr_axi/T/0",
        "Flow:/Specification/ecf_edfbottomw_axi/T/0",
        "Flow:/Specification/ecf_edfcorer_axi/T/0", "Flow:/Specification/ecf_edfcorew_axi/T/0",
        "Flow:/Specification/ecf_edftopr_axi/T/0", "Flow:/Specification/ecf_edftopw_axi/T/0",
        "Flow:/Specification/rw_ecf_ap_axi/T/0", "Flow:/Specification/rw_ecf_bstp_bc_axi/T/0",
        "Flow:/Specification/rw_ecf_bstp_bl_axi/T/0",
        "Flow:/Specification/rw_ecf_bstp_br_axi/T/0",
        "Flow:/Specification/rw_ecf_bstp_tc_axi/T/0",
        "Flow:/Specification/rw_ecf_bstp_tl_axi/T/0",
        "Flow:/Specification/rw_ecf_bstp_tr_axi/T/0",
        "Flow:/Specification/rw_ecf_cdft_axi/T/0", "Flow:/Specification/rw_ecf_dpf_axi/T/0",
        "Flow:/Specification/rw_ecf_edte_axi/T/0",
        "Flow:/Specification/rw_ecf_esl0_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl10_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl11_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl12_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl13_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl14_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl15_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl1_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl2_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl3_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl4_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl5_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl6_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl7_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl8_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl9_local_axi/T/0",
        "Flow:/Specification/rw_ecf_esl_mmu0_axi/T/0",
        "Flow:/Specification/rw_ecf_esl_mmu1_axi/T/0",
        "Flow:/Specification/rw_ecf_esl_mmu2_axi/T/0",
        "Flow:/Specification/rw_ecf_esl_mmu3_axi/T/0",
        "Flow:/Specification/rw_ecf_gmu_axi/T/0", "Flow:/Specification/rw_ecf_llc0_axi/T/0",
        "Flow:/Specification/rw_ecf_llc10_axi/T/0", "Flow:/Specification/rw_ecf_llc11_axi/T/0",
        "Flow:/Specification/rw_ecf_llc12_axi/T/0", "Flow:/Specification/rw_ecf_llc13_axi/T/0",
        "Flow:/Specification/rw_ecf_llc14_axi/T/0", "Flow:/Specification/rw_ecf_llc15_axi/T/0",
        "Flow:/Specification/rw_ecf_llc1_axi/T/0", "Flow:/Specification/rw_ecf_llc2_axi/T/0",
        "Flow:/Specification/rw_ecf_llc3_axi/T/0", "Flow:/Specification/rw_ecf_llc4_axi/T/0",
        "Flow:/Specification/rw_ecf_llc5_axi/T/0", "Flow:/Specification/rw_ecf_llc6_axi/T/0",
        "Flow:/Specification/rw_ecf_llc7_axi/T/0", "Flow:/Specification/rw_ecf_llc8_axi/T/0",
        "Flow:/Specification/rw_ecf_llc9_axi/T/0", "Flow:/Specification/rw_ecf_mc0_axi/T/0",
        "Flow:/Specification/rw_ecf_mc1_axi/T/0", "Flow:/Specification/rw_ecf_mc2_axi/T/0",
        "Flow:/Specification/rw_ecf_mc3_axi/T/0", "Flow:/Specification/rw_ecf_odte_axi/T/0",
        "Flow:/Specification/rw_ecf_pcie_axi/T/0", "Flow:/Specification/rw_ecf_sp_axi/T/0",
        "Flow:/Specification/rw_ecf_ssm_axi/T/0", "Flow:/Specification/rw_ecf_vpu_axi/T/0",
        "Flow:/Specification/rw_ecfcore_sicio0_ft_ob_axi/T/0",
        "Flow:/Specification/rw_ecfcore_sicio1_ft_ob_axi/T/0",
        "Flow:/Specification/rw_ecfcore_sicio2_ft_ob_axi/T/0",
        "Flow:/Specification/rw_ecfcore_sicio3_ft_ob_axi/T/0",
        "Flow:/Specification/wo_ecf_esl0_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl10_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl11_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl12_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl13_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl14_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl15_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl1_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl2_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl3_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl4_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl5_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl6_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl7_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl8_remote_axi/T/0",
        "Flow:/Specification/wo_ecf_esl9_remote_axi/T/0", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
        "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED", "RESERVED",
    }};
};

}  // namespace noc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_NOC_LIBRA_NOC_ERR_ECFCORE_H_

// reference
// ==============================
// Datapath RouteId decomposition - ecf_core
// ==============================

// wRouteId: 26 bits
// ~~~~~~~~~~~~~~~~~
// Field Type    : Bit(s)
// ------------------------
// InitFlow      : 25 .. 19
// TargFlow      : 18 .. 12
// Targ SubRange : 11 .. 9
// OrderKey      : 8 .. 0

// InitFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ----------------------------------------------------------------
// 0          : Flow:/Specification/rw_ap_ecf_axi/I/0
// 1          : Flow:/Specification/rw_cdft_ecf_axi/I/0
// 2          : Flow:/Specification/rw_dpf_ecf_axi/I/0
// 3          : Flow:/Specification/rw_esl0_local_ecf_axi/I/0
// 4          : Flow:/Specification/rw_esl0_remote_ecf_axi/I/0
// 5          : Flow:/Specification/rw_esl10_local_ecf_axi/I/0
// 6          : Flow:/Specification/rw_esl10_remote_ecf_axi/I/0
// 7          : Flow:/Specification/rw_esl11_local_ecf_axi/I/0
// 8          : Flow:/Specification/rw_esl11_remote_ecf_axi/I/0
// 9          : Flow:/Specification/rw_esl12_local_ecf_axi/I/0
// A          : Flow:/Specification/rw_esl12_remote_ecf_axi/I/0
// B          : Flow:/Specification/rw_esl13_local_ecf_axi/I/0
// C          : Flow:/Specification/rw_esl13_remote_ecf_axi/I/0
// D          : Flow:/Specification/rw_esl14_local_ecf_axi/I/0
// E          : Flow:/Specification/rw_esl14_remote_ecf_axi/I/0
// F          : Flow:/Specification/rw_esl15_local_ecf_axi/I/0
// 10         : Flow:/Specification/rw_esl15_remote_ecf_axi/I/0
// 11         : Flow:/Specification/rw_esl1_local_ecf_axi/I/0
// 12         : Flow:/Specification/rw_esl1_remote_ecf_axi/I/0
// 13         : Flow:/Specification/rw_esl2_local_ecf_axi/I/0
// 14         : Flow:/Specification/rw_esl2_remote_ecf_axi/I/0
// 15         : Flow:/Specification/rw_esl3_local_ecf_axi/I/0
// 16         : Flow:/Specification/rw_esl3_remote_ecf_axi/I/0
// 17         : Flow:/Specification/rw_esl4_local_ecf_axi/I/0
// 18         : Flow:/Specification/rw_esl4_remote_ecf_axi/I/0
// 19         : Flow:/Specification/rw_esl5_local_ecf_axi/I/0
// 1A         : Flow:/Specification/rw_esl5_remote_ecf_axi/I/0
// 1B         : Flow:/Specification/rw_esl6_local_ecf_axi/I/0
// 1C         : Flow:/Specification/rw_esl6_remote_ecf_axi/I/0
// 1D         : Flow:/Specification/rw_esl7_local_ecf_axi/I/0
// 1E         : Flow:/Specification/rw_esl7_remote_ecf_axi/I/0
// 1F         : Flow:/Specification/rw_esl8_local_ecf_axi/I/0
// 20         : Flow:/Specification/rw_esl8_remote_ecf_axi/I/0
// 21         : Flow:/Specification/rw_esl9_local_ecf_axi/I/0
// 22         : Flow:/Specification/rw_esl9_remote_ecf_axi/I/0
// 23         : Flow:/Specification/rw_gmu_ecf_axi/I/0
// 24         : Flow:/Specification/rw_llc0_ecf_axi/I/0
// 25         : Flow:/Specification/rw_llc10_ecf_axi/I/0
// 26         : Flow:/Specification/rw_llc11_ecf_axi/I/0
// 27         : Flow:/Specification/rw_llc12_ecf_axi/I/0
// 28         : Flow:/Specification/rw_llc13_ecf_axi/I/0
// 29         : Flow:/Specification/rw_llc14_ecf_axi/I/0
// 2A         : Flow:/Specification/rw_llc15_ecf_axi/I/0
// 2B         : Flow:/Specification/rw_llc1_ecf_axi/I/0
// 2C         : Flow:/Specification/rw_llc2_ecf_axi/I/0
// 2D         : Flow:/Specification/rw_llc3_ecf_axi/I/0
// 2E         : Flow:/Specification/rw_llc4_ecf_axi/I/0
// 2F         : Flow:/Specification/rw_llc5_ecf_axi/I/0
// 30         : Flow:/Specification/rw_llc6_ecf_axi/I/0
// 31         : Flow:/Specification/rw_llc7_ecf_axi/I/0
// 32         : Flow:/Specification/rw_llc8_ecf_axi/I/0
// 33         : Flow:/Specification/rw_llc9_ecf_axi/I/0
// 34         : Flow:/Specification/rw_mc0_ecf_axi/I/0
// 35         : Flow:/Specification/rw_mc1_ecf_axi/I/0
// 36         : Flow:/Specification/rw_mc2_ecf_axi/I/0
// 37         : Flow:/Specification/rw_mc3_ecf_axi/I/0
// 38         : Flow:/Specification/rw_pcie_ecf_axi/I/0
// 39         : Flow:/Specification/rw_sicio0_ecfcore_ft_ib_axi/I/0
// 3A         : Flow:/Specification/rw_sicio1_ecfcore_ft_ib_axi/I/0
// 3B         : Flow:/Specification/rw_sicio2_ecfcore_ft_ib_axi/I/0
// 3C         : Flow:/Specification/rw_sicio3_ecfcore_ft_ib_axi/I/0
// 3D         : Flow:/Specification/rw_sp_ecf_axi/I/0
// 3E         : Flow:/Specification/rw_ssm_ecf_axi/I/0
// 3F         : Flow:/Specification/rw_vpu_ecf_axi/I/0
// 40         : Flow:/Specification/wo_edte_ecf_axi/I/0
// 41         : Flow:/Specification/wo_esl_mmu0_ecf_axi/I/0
// 42         : Flow:/Specification/wo_esl_mmu1_ecf_axi/I/0
// 43         : Flow:/Specification/wo_esl_mmu2_ecf_axi/I/0
// 44         : Flow:/Specification/wo_esl_mmu3_ecf_axi/I/0
// 45         : Flow:/Specification/wo_odte_ecf_axi/I/0
// 46         : RESERVED
// 47         : RESERVED
// 48         : RESERVED
// 49         : RESERVED
// 4A         : RESERVED
// 4B         : RESERVED
// 4C         : RESERVED
// 4D         : RESERVED
// 4E         : RESERVED
// 4F         : RESERVED
// 50         : RESERVED
// 51         : RESERVED
// 52         : RESERVED
// 53         : RESERVED
// 54         : RESERVED
// 55         : RESERVED
// 56         : RESERVED
// 57         : RESERVED
// 58         : RESERVED
// 59         : RESERVED
// 5A         : RESERVED
// 5B         : RESERVED
// 5C         : RESERVED
// 5D         : RESERVED
// 5E         : RESERVED
// 5F         : RESERVED
// 60         : RESERVED
// 61         : RESERVED
// 62         : RESERVED
// 63         : RESERVED
// 64         : RESERVED
// 65         : RESERVED
// 66         : RESERVED
// 67         : RESERVED
// 68         : RESERVED
// 69         : RESERVED
// 6A         : RESERVED
// 6B         : RESERVED
// 6C         : RESERVED
// 6D         : RESERVED
// 6E         : RESERVED
// 6F         : RESERVED
// 70         : RESERVED
// 71         : RESERVED
// 72         : RESERVED
// 73         : RESERVED
// 74         : RESERVED
// 75         : RESERVED
// 76         : RESERVED
// 77         : RESERVED
// 78         : RESERVED
// 79         : RESERVED
// 7A         : RESERVED
// 7B         : RESERVED
// 7C         : RESERVED
// 7D         : RESERVED
// 7E         : RESERVED
// 7F         : RESERVED

// TargFlow field:
// ~~~~~~~~~~~~~~~
// value (0x) : flow
// ----------------------------------------------------------------
// 0          : Flow:/Specification/ecf_core_service/T/0
// 1          : Flow:/Specification/ecf_edfbottomr_axi/T/0
// 2          : Flow:/Specification/ecf_edfbottomw_axi/T/0
// 3          : Flow:/Specification/ecf_edfcorer_axi/T/0
// 4          : Flow:/Specification/ecf_edfcorew_axi/T/0
// 5          : Flow:/Specification/ecf_edftopr_axi/T/0
// 6          : Flow:/Specification/ecf_edftopw_axi/T/0
// 7          : Flow:/Specification/rw_ecf_ap_axi/T/0
// 8          : Flow:/Specification/rw_ecf_bstp_bc_axi/T/0
// 9          : Flow:/Specification/rw_ecf_bstp_bl_axi/T/0
// A          : Flow:/Specification/rw_ecf_bstp_br_axi/T/0
// B          : Flow:/Specification/rw_ecf_bstp_tc_axi/T/0
// C          : Flow:/Specification/rw_ecf_bstp_tl_axi/T/0
// D          : Flow:/Specification/rw_ecf_bstp_tr_axi/T/0
// E          : Flow:/Specification/rw_ecf_cdft_axi/T/0
// F          : Flow:/Specification/rw_ecf_dpf_axi/T/0
// 10         : Flow:/Specification/rw_ecf_edte_axi/T/0
// 11         : Flow:/Specification/rw_ecf_esl0_local_axi/T/0
// 12         : Flow:/Specification/rw_ecf_esl10_local_axi/T/0
// 13         : Flow:/Specification/rw_ecf_esl11_local_axi/T/0
// 14         : Flow:/Specification/rw_ecf_esl12_local_axi/T/0
// 15         : Flow:/Specification/rw_ecf_esl13_local_axi/T/0
// 16         : Flow:/Specification/rw_ecf_esl14_local_axi/T/0
// 17         : Flow:/Specification/rw_ecf_esl15_local_axi/T/0
// 18         : Flow:/Specification/rw_ecf_esl1_local_axi/T/0
// 19         : Flow:/Specification/rw_ecf_esl2_local_axi/T/0
// 1A         : Flow:/Specification/rw_ecf_esl3_local_axi/T/0
// 1B         : Flow:/Specification/rw_ecf_esl4_local_axi/T/0
// 1C         : Flow:/Specification/rw_ecf_esl5_local_axi/T/0
// 1D         : Flow:/Specification/rw_ecf_esl6_local_axi/T/0
// 1E         : Flow:/Specification/rw_ecf_esl7_local_axi/T/0
// 1F         : Flow:/Specification/rw_ecf_esl8_local_axi/T/0
// 20         : Flow:/Specification/rw_ecf_esl9_local_axi/T/0
// 21         : Flow:/Specification/rw_ecf_esl_mmu0_axi/T/0
// 22         : Flow:/Specification/rw_ecf_esl_mmu1_axi/T/0
// 23         : Flow:/Specification/rw_ecf_esl_mmu2_axi/T/0
// 24         : Flow:/Specification/rw_ecf_esl_mmu3_axi/T/0
// 25         : Flow:/Specification/rw_ecf_gmu_axi/T/0
// 26         : Flow:/Specification/rw_ecf_llc0_axi/T/0
// 27         : Flow:/Specification/rw_ecf_llc10_axi/T/0
// 28         : Flow:/Specification/rw_ecf_llc11_axi/T/0
// 29         : Flow:/Specification/rw_ecf_llc12_axi/T/0
// 2A         : Flow:/Specification/rw_ecf_llc13_axi/T/0
// 2B         : Flow:/Specification/rw_ecf_llc14_axi/T/0
// 2C         : Flow:/Specification/rw_ecf_llc15_axi/T/0
// 2D         : Flow:/Specification/rw_ecf_llc1_axi/T/0
// 2E         : Flow:/Specification/rw_ecf_llc2_axi/T/0
// 2F         : Flow:/Specification/rw_ecf_llc3_axi/T/0
// 30         : Flow:/Specification/rw_ecf_llc4_axi/T/0
// 31         : Flow:/Specification/rw_ecf_llc5_axi/T/0
// 32         : Flow:/Specification/rw_ecf_llc6_axi/T/0
// 33         : Flow:/Specification/rw_ecf_llc7_axi/T/0
// 34         : Flow:/Specification/rw_ecf_llc8_axi/T/0
// 35         : Flow:/Specification/rw_ecf_llc9_axi/T/0
// 36         : Flow:/Specification/rw_ecf_mc0_axi/T/0
// 37         : Flow:/Specification/rw_ecf_mc1_axi/T/0
// 38         : Flow:/Specification/rw_ecf_mc2_axi/T/0
// 39         : Flow:/Specification/rw_ecf_mc3_axi/T/0
// 3A         : Flow:/Specification/rw_ecf_odte_axi/T/0
// 3B         : Flow:/Specification/rw_ecf_pcie_axi/T/0
// 3C         : Flow:/Specification/rw_ecf_sp_axi/T/0
// 3D         : Flow:/Specification/rw_ecf_ssm_axi/T/0
// 3E         : Flow:/Specification/rw_ecf_vpu_axi/T/0
// 3F         : Flow:/Specification/rw_ecfcore_sicio0_ft_ob_axi/T/0
// 40         : Flow:/Specification/rw_ecfcore_sicio1_ft_ob_axi/T/0
// 41         : Flow:/Specification/rw_ecfcore_sicio2_ft_ob_axi/T/0
// 42         : Flow:/Specification/rw_ecfcore_sicio3_ft_ob_axi/T/0
// 43         : Flow:/Specification/wo_ecf_esl0_remote_axi/T/0
// 44         : Flow:/Specification/wo_ecf_esl10_remote_axi/T/0
// 45         : Flow:/Specification/wo_ecf_esl11_remote_axi/T/0
// 46         : Flow:/Specification/wo_ecf_esl12_remote_axi/T/0
// 47         : Flow:/Specification/wo_ecf_esl13_remote_axi/T/0
// 48         : Flow:/Specification/wo_ecf_esl14_remote_axi/T/0
// 49         : Flow:/Specification/wo_ecf_esl15_remote_axi/T/0
// 4A         : Flow:/Specification/wo_ecf_esl1_remote_axi/T/0
// 4B         : Flow:/Specification/wo_ecf_esl2_remote_axi/T/0
// 4C         : Flow:/Specification/wo_ecf_esl3_remote_axi/T/0
// 4D         : Flow:/Specification/wo_ecf_esl4_remote_axi/T/0
// 4E         : Flow:/Specification/wo_ecf_esl5_remote_axi/T/0
// 4F         : Flow:/Specification/wo_ecf_esl6_remote_axi/T/0
// 50         : Flow:/Specification/wo_ecf_esl7_remote_axi/T/0
// 51         : Flow:/Specification/wo_ecf_esl8_remote_axi/T/0
// 52         : Flow:/Specification/wo_ecf_esl9_remote_axi/T/0
// 53         : RESERVED
// 54         : RESERVED
// 55         : RESERVED
// 56         : RESERVED
// 57         : RESERVED
// 58         : RESERVED
// 59         : RESERVED
// 5A         : RESERVED
// 5B         : RESERVED
// 5C         : RESERVED
// 5D         : RESERVED
// 5E         : RESERVED
// 5F         : RESERVED
// 60         : RESERVED
// 61         : RESERVED
// 62         : RESERVED
// 63         : RESERVED
// 64         : RESERVED
// 65         : RESERVED
// 66         : RESERVED
// 67         : RESERVED
// 68         : RESERVED
// 69         : RESERVED
// 6A         : RESERVED
// 6B         : RESERVED
// 6C         : RESERVED
// 6D         : RESERVED
// 6E         : RESERVED
// 6F         : RESERVED
// 70         : RESERVED
// 71         : RESERVED
// 72         : RESERVED
// 73         : RESERVED
// 74         : RESERVED
// 75         : RESERVED
// 76         : RESERVED
// 77         : RESERVED
// 78         : RESERVED
// 79         : RESERVED
// 7A         : RESERVED
// 7B         : RESERVED
// 7C         : RESERVED
// 7D         : RESERVED
// 7E         : RESERVED
// 7F         : RESERVED

// ==================
// User flags details - ecf_core
// ==================

//    0 : Allocate
//    1 : Bufferable
//    2 : Cache_0
//    3 : Cache_1
//    4 : Cache_2
//    5 : Cache_3
//    6 : Instruction
//    7 : Lookup
//    8 : Modifiable
//    9 : Nonsecured
//   10 : Privileged
//   11 : Prot_0
//   12 : Prot_1
//   13 : Prot_2
//   14 : reqUser_00
//   15 : reqUser_01
//   16 : reqUser_02
//   17 : reqUser_03
//   18 : reqUser_04
//   19 : reqUser_05
//   20 : reqUser_06
//   21 : reqUser_07
//   22 : reqUser_08
//   23 : reqUser_09
//   24 : reqUser_10
//   25 : reqUser_11
//   26 : reqUser_12
//   27 : reqUser_13
//   28 : reqUser_14
//   29 : reqUser_15
//   30 : reqUser_16
//   31 : reqUser_17
//   32 : reqUser_18
//   33 : reqUser_19
//   34 : user_endianness
