/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_CODEC_MVE_MMU_H_
#define HARDWARE_CODEC_MVE_MMU_H_
#include <stdint.h>

namespace efvf {
namespace hardware {
namespace codec {

/*
   31:30 29:2                       1 0
  +-----+-------------------------+-----+
  |ATTR | BASE                    | 1 1 |  Format of SOC_CS.LSID[x].MMU_CTRL
  +-----+-------------------------+-----+
  | 0 0 | 0                       | 0 0 |  Format of invalid L1 descriptor
  +-----+-------------------------+-----+
  |ATTR | BASE                    | 0 1 |  Format of valid L1 descriptor
  +-----+-------------------------+-----+
  | 0 0 | 0                       | 0 0 |  Format of invalid L2 descriptor
  +-----+-------------------------+-----+
  |ATTR | BASE                    | ACC |  Format of valid L2 descriptor
  +-----+-------------------------+-----+

   ACC
  +----+
  | 00 |  Invalid page, no access
  +----+
  | 01 |  Read only page, non executable.
  +----+
  | 10 |  Executable, read only page
  +----+
  | 11 |  Read/write page, non executable
  +----+


* The BASE fields correspond to physical address bits 39:12.

* The ACC field selects read/write/executable permissions according to table
  above.

* The ATTR field selects between four modes (0-3) for bus attributes, that are
  used when the VE accesses the address specified by the BASE field.  The
  meaning of the modes can be set up in SOC_LSID[n].BUSATTR[attr] before booting
  the VE.  Each of these four register holds values for ARCACHE, AWCACHE,
  ARDOMAIN and AWDOMAIN.


ATTR usage

00 MVE private, read only.  page tables, firmware text
01 MVE private, read-write. BSS/data, allocated memory, reference frames
10 Shared data, read only.  Input buffers
11 Shared data, read-write. Output buffers

*/

/* The following code assumes 4 kB pages and that the MVE uses a 32-bit
 * virtual address space. */

#define MVE_MMU_PAGE_SHIFT 12
#define MVE_MMU_PAGE_SIZE (1 << MVE_MMU_PAGE_SHIFT)

enum mve_mmu_attrib {
    MMU_ATTR_PRIVATE   = 0,
    MMU_ATTR_REFFRAME  = 1,
    MMU_ATTR_SHARED_RO = 2,
    MMU_ATTR_SHARED_RW = 3
};

enum mve_mmu_access {
    MMU_ACCESS_INVALID   = 0,
    MMU_ACCESS_READ      = 1,
    MMU_ACCESS_EXECUTE   = 2,
    MMU_ACCESS_READWRITE = 3
};

// typedef uint32_t mvx_mmu_pte;

// enum mvx_mmu_attr {
//     MVX_ATTR_PRIVATE   = 0,
//     MVX_ATTR_REFFRAME  = 1,
//     MVX_ATTR_SHARED_RO = 2,
//     MVX_ATTR_SHARED_RW = 3
// };

// enum mvx_mmu_access {
//     MVX_ACCESS_NO         = 0,
//     MVX_ACCESS_READ_ONLY  = 1,
//     MVX_ACCESS_EXECUTABLE = 2,
//     MVX_ACCESS_READ_WRITE = 3
// };

// typedef uint32_t mve_mmu_entry_t;

// /* Number of levels for Page Table Walk. */
// #define MVE_PTW_LEVELS 2
// /* Number of bits from the VA used to index a PTE in a page. */
// #define MVE_INDEX_SHIFT 10
// #define MVE_INDEX_SIZE (1 << MVE_INDEX_SHIFT)
// #define MVE_INDEX_MASK ((1 << MVE_INDEX_SHIFT) - 1)  // GENMASK(MVE_INDEX_SHIFT - 1, 0)

/* Page size in bits. 2^12 = 4kB. */
#define MVE_PAGE_SHIFT 12
#define MVE_PAGE_SIZE (1 << MVE_PAGE_SHIFT)
#define MVE_PAGE_MASK (MVE_PAGE_SIZE - 1)

/* Number of bits for the physical address space. */
#define MVE_PA_BITS 40
#define MVE_PA_MASK ((1 << MVE_PA_BITS) - 1)  // GENMASK_ULL(MVE_PA_BITS - 1, 0)

/* Number of bits for the virtual address space. */
#define MVE_VA_BITS 32
#define MVE_VA_MASK ((1 << MVE_VA_BITS) - 1)  // GENMASK(MVE_VA_BITS - 1, 0)

/* Number of bits from the VA used to index a PTE in a page. */
#define MVE_INDEX_SHIFT 10
#define MVE_INDEX_SIZE (1 << MVE_INDEX_SHIFT)
#define MVE_INDEX_MASK ((1 << MVE_INDEX_SHIFT) - 1)  // GENMASK(MVE_INDEX_SHIFT - 1, 0)

/* Access permission defines. */
#define MVE_PTE_AP_SHIFT 0
#define MVE_PTE_AP_BITS 2
#define MVE_PTE_AP_MASK ((1 << MVE_PTE_AP_BITS) - 1)

/* Physical address defines. */
#define MVE_PTE_PHYSADDR_SHIFT 2
#define MVE_PTE_PHYSADDR_BITS 28
#define MVE_PTE_PHYSADDR_MASK ((1 << MVE_PTE_PHYSADDR_BITS) - 1)

/* Attributes defines. */
#define MVE_PTE_ATTR_SHIFT 30
#define MVE_PTE_ATTR_BITS 2
#define MVE_PTE_ATTR_MASK ((1 << MVE_PTE_ATTR_BITS) - 1)

/* Number of page table entries per page. */
#define MVE_PAGE_PTE_PER_PAGE (MVE_PAGE_SIZE / sizeof(mvx_mmu_pte))
/* Number of levels for Page Table Walk. */
#define MVE_PTW_LEVELS 2

/**
 * mmu_get_index() - Return the PTE index for a given level.
 * @va:        Virtual address.
 * @level:    Level (L1=0, L2=1).
 *
 *                   22                  12                       0
 * +-------------------+-------------------+-----------------------+
 * |      Level 1      |      Level 2      |      Page offset      |
 * +-------------------+-------------------+-----------------------+
 */
uint32_t mmu_get_index(const uint32_t va, const uint32_t level);

uint64_t mmu_get_pa(const uint32_t pte);

uint32_t mmu_get_pte(uint64_t pa, mve_mmu_attrib attr, mve_mmu_access access);

}  // namespace codec
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CODEC_MVE_MMU_H_
