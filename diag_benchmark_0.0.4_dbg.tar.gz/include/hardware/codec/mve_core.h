/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_CODEC_MVE_CORE_H_
#define HARDWARE_CODEC_MVE_CORE_H_
#include <stdint.h>

namespace efvf {
namespace hardware {
namespace codec {

/**
 * write32n() - Write a number of bytes to 'dst' from 'src'.
 * @dst:    Pointer to circular buffer of destination data.
 * @offset:    Current offset in the circular buffer.
 * @src:    Pointer to source buffer.
 * @size:    Size in bytes.
 *
 * Return: New offset in the circular buffer.
 */
uint32_t write32n(volatile uint32_t *dst, uint32_t offset, uint32_t *src, int32_t size);

/**
 * read32n() - Read a number of bytes from 'src' to 'dst'.
 * @src:    Pointer to circular buffer of source data.
 * @offset:    Current offset in the circular buffer.
 * @dst:    Pointer to destination buffer.
 * @size:    Size in bytes.
 *
 * Return: New offset in the circular buffer.
 */
uint32_t read32n(volatile uint32_t *src, uint32_t offset, uint32_t *dst, uint32_t size);

}  // namespace codec
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CODEC_MVE_CORE_H_
