/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_CODEC_LIBRA_VPU_DECODER_LIBRA_H_
#define HARDWARE_CODEC_LIBRA_VPU_DECODER_LIBRA_H_

#include <memory>
#include "hardware/codec/codec_arm.h"
#include "hardware/include/vpu/vpu.h"

using efvf::hardware::vpu::Vpu;

// codec inst: 0 - vdec, 1 - jdec

namespace efvf {
namespace hardware {
namespace codec {

class DecLibra : public CodecArm {
 private:
 public:
    //  DecLibra();
    explicit DecLibra(Vpu *vpu, uint32_t inst, std::shared_ptr<spdlog::logger> logger);
    virtual ~DecLibra();

    bool HwInit(Vpu *vpu);
    bool HwDeinit();
    void Snapshot();

    //
    virtual bool MemConstFill(uint64_t buf_addr, uint64_t buf_size, uint32_t pattern);
    virtual bool DataCopy(uint64_t src_addr, uint64_t dst_addr, uint64_t size);
    virtual uint32_t GetDataCrc(uint64_t src_addr, uint64_t dst_addr, uint64_t size);
    //
    virtual bool SetUserInfo(uint32_t lsid, uint64_t ipa_addr, uint32_t axuser);
};

}  // namespace codec
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CODEC_LIBRA_VPU_DECODER_LIBRA_H_
