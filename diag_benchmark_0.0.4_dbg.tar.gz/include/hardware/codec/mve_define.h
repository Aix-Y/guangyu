/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_CODEC_MVE_DEFINE_H_
#define HARDWARE_CODEC_MVE_DEFINE_H_
#include <stdint.h>

#include "hardware/codec/mve_core.h"
#include "hardware/codec/mve_fw.h"
#include "hardware/codec/mve_hw.h"
#include "hardware/codec/mve_mmu.h"
#include "hardware/codec/mve_protocol_def_libra.h"

#define DIV_ROUND_UP(n, d) (((n) + (d)-1) / (d))
#define __round_mask(x, y) ((__typeof__(x))((y)-1))
#define round_up(x, y) ((((x)-1) | __round_mask(x, y)) + 1)

#endif  // HARDWARE_CODEC_MVE_DEFINE_H_
