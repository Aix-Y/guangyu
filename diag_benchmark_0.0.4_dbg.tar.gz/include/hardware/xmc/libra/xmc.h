/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_XMC_LIBRA_XMC_H_
#define HARDWARE_XMC_LIBRA_XMC_H_

#include <map>
#include <memory>
#include <string>
#include "hardware/include/xmc/xmc.h"
#include "hardware/include/xmc/xmc_ctx.h"

namespace efvf {
namespace hardware {
namespace xmc {

extern const std::map<const std::string, int> kLibraXmcHashType;

class XmcLibra : public Xmc {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    XmcLibra() : Xmc() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit XmcLibra(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~XmcLibra() {
        // Deinit();
    }

    /**
     * @brief Set the BLCG of xmc
     *
     * @param enable true for enable, false for disable.
     */
    virtual void SetEnBLCG(bool enable);

    /**
     * @brief Set the Auto Increment of index.
     *
     * @param enable true for enable, false for disable.
     */
    virtual void SetAutoInc(bool enable);

    /**
     * @brief     Dump all the xmc info in the hardware tree.
     *
     */
    virtual void DumpInfo();

    /**
     * @brief     Dump as an information table.
     */
    virtual void DumpInfoTable();

    /**
     * @brief Parsing fault information if it has.
     *
     */
    virtual void DumpFaultInfo();

    /**
     * @brief      Sets the enable.
     *
     * @param[in]  val   The new value
     */
    virtual void SetEnable(bool val);

    /**
     * @brief Set the Window Map
     *
     * @param ctx
     */
    virtual void SetWindowMap(const XmcAptCfg &ctx);

    /**
     * @brief Set the Basic Apt Configuration
     *
     * @param ctx
     */
    virtual void SetBasicAptCfg(const XmcAptCfg &ctx);

    /**
     * @brief Set the First Apt Configuration
     *
     * @param ctx
     */
    virtual void SetFirstAptCfg(const XmcAptCfg &ctx);

    /**
     * @brief Set the Second Apt Configuration
     *
     * @param ctx
     */
    virtual void SetSecondAptCfg(const XmcAptCfg &ctx);

    /**
     * @brief Set the Stride Configuration
     *
     * @param ctx
     */
    virtual void SetStrideCfg(const XmcAptCfg &ctx);

    /**
     * @brief Set the Reorder
     *
     * @param ctx
     */
    virtual void SetReorder(const XmcAptCfg &ctx);

    /**
     * @brief Set the Hash Mask
     *
     * @param mask Used to specify how many address bits are used for hash calculation.
     * @return true
     * @return false
     */
    virtual bool SetHashMask(uint32_t index, LibraHashMask mask);

    /**
     * @brief
     *
     * @param index
     * @param addr_in
     * @param hash_mask
     * @param isReserved is the view PF reserved.
     * @return uint64_t
     */
    virtual uint64_t GetLLCHashAddr(int index, uint64_t addr_in, bool isReserved = true);

    /**
     * @brief Get the Dsm Hash Addr object
     *
     * @param index
     * @param addr_in
     * @param hash_mask
     * @return uint64_t
     */
    virtual uint64_t GetDsmHashAddr(int index, uint64_t addr_in);

    /**
     * @brief Get the Shadow Port Selec Addr
     *
     * @param index
     * @param addr_in
     * @return uint64_t
     */
    virtual uint64_t GetShadowPortSelecAddr(int index, uint64_t addr_in);

    /**
     * @brief Get the Dsm Harvest
     *
     * @param addr_in
     * @return uint64_t
     */
    virtual uint64_t GetDsmHarvest(uint64_t addr_in);

    /**
     * @brief Translate IPA to PA in libra
     *
     * @param addr_in
     * @return uint64_t
     */
    virtual uint64_t IPA2PA(uint64_t addr_in);

    /**
     * @brief Translate L3 PA to IPA in libra
     *
     * @param addr_in
     * @return uint64_t
     */
    virtual uint64_t PA2IPA(uint64_t addr_in);

 private:
    // out stream
    std::fstream out;

    /**
     * @brief      from Hardware class, call by Init
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit();

    /**
     * @brief      from Hardware class, call by Deinit
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit();

    /**
     * @brief Check whether the XMC on the DF bus path.
     *
     * @return true
     * @return false
     */
    bool IsDF();

    /**
     * @brief Check whether the XMC on teh slaver port.
     *
     * @return true
     * @return false
     */
    bool IsSlave();

    /**
     * @brief Check whether the xmc belongs to SA of IP or is independent instantiation.
     *
     * @return true
     * @return false
     */
    bool IsSA();

    /*
     *  Auxiliary setting interfaces.
     */

    /**
     * @brief Set the Aperture Mode
     *
     * @param mode 0/1/2/3 - 1st level apt/ 2nd level apt/ stride mode/ hash mode
     */
    void SetAptMode(uint32_t mode);

    /**
     * @brief Set the valid bit of each aperture.
     *
     * @param isVld
     */
    void SetVldBit(bool isVld);

    /*
     *  Register-info-read interfaces.
     */

    /**
     * @brief Get the XM_CLIENT_CTRL value
     *
     * @return uint32_t
     */
    uint32_t GetCtrlValue();

    /**
     * @brief Get the XM_CLIENT_FAULT value
     *
     * @return uint32_t
     */
    uint32_t GetFaultValue();

    /**
     * @brief Get the fault address
     *
     * @return uint32_t
     */
    uint64_t GetDefaultAddr();

    /**
     * @brief Get the Window Address
     *
     * @return uint32_t
     */
    uint64_t GetWinAddr();

    /**
     * @brief Get the Window Size
     *
     * @return uint32_t
     */
    uint64_t GetWinSize();

    /**
     * @brief Get the Clip Unit of indicated aperture
     *
     * @param index aperture index
     * @return uint32_t
     */
    uint32_t GetClipUnit(uint32_t index);

    /**
     * @brief Get the Hash Unit of indicated aperture
     *
     * @param index aperture index
     * @return uint32_t
     */
    uint32_t GetHashUnit(uint32_t index);

    /**
     * @brief Get the Hash Group of aperture.
     *
     * @param index aperture index
     * @return int
     */
    int GetHashGroup(int index);

    /**
     * @brief Get the Hash Mode
     *
     * @param index aperture index
     * @return int
     */
    int GetHashMode(int index);

    /**
     * @brief Get the Shadow Mode
     *
     * @param index
     * @return int
     */
    int GetShadowMode(int index);

    /**
     * @brief Get the Str of aperture for stride mode.
     *
     * @param index
     * @return uint32_t
     */
    uint32_t GetStr(int index);

    /**
     * @brief Read aperture data of indicated index
     *
     * @param index aperture index
     * @param attr used to select _ADDR/_EXT/_EXTSCD/_SIZE/_MAP/_VLD (0/1/2/3/4/6) for mode
     * 0/1;
     *                            _ADDR/_EXT/_EXTSCD/_SIZE/_MAP/_STR/_VLD (0/1/2/3/4/5/6) for
     * stride mode.
     * @return uint32_t
     */
    uint64_t ReadAptData(uint32_t index, uint32_t attr);

    /**
     * @brief Get the apreture number according to different mode.
     *
     * @param mode aperture mode 0/1/2/3 - 1st level/2nd level/stride/hash.
     * @return uint32_t
     */
    uint32_t GetAptNumber(uint32_t mode);

    /**
     * @brief Compute the aperture number
     *
     * @param mode_map
     * @param name
     * @return uint32_t
     */
    uint32_t ComputeAptNum(
        const std::map<const std::string, uint32_t> &mode_map, const std::string &name);

    /**
     * @brief if fault happen; log the first fault's input read address;
     * else log the last input request's read address.
     *
     * @return uint32_t
     */
    uint64_t GetRdAddrIn();

    /**
     * @brief Log the last output read address.
     *
     * @return uint32_t
     */
    uint64_t GetRdAddrOut();

    /**
     * @brief if fault happen; log the first fault's input write address;
     * else log the last input request's write address.
     *
     * @return uint32_t
     */
    uint64_t GetWrAddrIn();

    /**
     * @brief Log the last output write address.
     *
     * @return uint32_t
     */
    uint64_t GetWrAddrOut();

    /**
     * @brief      Gets the hash masks -
     *
     * @return     The hash masks:
     *             [4:0][31:0]] for LLC non-PF reserved space;
     *             [9:5][31:0]] for LLC PF reserved space;
     *             [11:10][31:0] for CDTE Balance hash;
     *             [12][15:0] for DSM hash's group index;
     *             [14:13][14:0] for DSM hash's dsm index;
     *             [15][20:0] serves for DSM shadow port choose.
     */
    LibraHashMask GetHashMasks();

    /*
     *   Functions for dump tools.
     */

    /**
     * @brief Print the Aperture configuratio of First Level
     *
     */
    void PrintFirstLevelApt(bool isTabular);

    /**
     * @brief Print the Aperture configuratio of Second Level
     *
     */
    void PrintSecondLevelApt(bool isTabular);

    /**
     * @brief Print the Aperture configuration under the Stride Mode
     *
     */
    void PrintStrideApt(bool isTabular);

    /**
     * @brief Get the Hash Mask.
     *
     */
    void PrintHashMask(bool isTabular);

    /**
     * @brief Print the rd/wr in/out address.
     *
     * @param isTabular
     */
    void PrintAddrInfo(bool isTabular);

    /**
     * @brief Print fault remap info if fault error happend.
     *
     */
    void PrintFaultStat(bool isTabular);

    /**
     * @brief Dump the xmc aperture info, ctrl value and window info.
     *
     */
    void XmcDump();

    /**
     * @brief      Gets the xor.
     *
     * @param[in]  addr  The address
     *
     * @return     The xor.
     */
    uint64_t GetXOR(std::string type, uint64_t addr);

    /**
     * @brief      Gets the bits.
     *
     * @param[in]  addr  The address
     * @param[in]  lhs   lsb (include)
     * @param[in]  rhs   msb (include)
     *
     * @return     The bits.
     */
    uint64_t GetBits(uint64_t addr, int lhs, int rhs);

    /**
     * @brief Determine whether is dsm hash or not.
     *
     * @param index
     * @return true
     * @return false
     */
    bool IsDSMHash(uint32_t index);

    /**
     * @brief Get the L3 Dehashed Address.
     *
     * @param addr
     * @return uint64_t
     */
    uint64_t GetL3DehashedAddr(uint64_t addr);
};

}  //  namespace xmc
}  //  namespace hardware
}  //  namespace efvf

#endif  //  HARDWARE_XMC_LIBRA_XMC_H_
