/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_XMC_SCORPIO_XMC_H_
#define HARDWARE_XMC_SCORPIO_XMC_H_

#include <memory>
#include "hardware/include/xmc/xmc.h"

#define INLINE_HAL_API 1
#define HAL_XMC_V_1_0 1
// #define DIAG_HAL_IMPL

#include "hal/xmc_api.h"

namespace efvf {
namespace hardware {
namespace xmc {

class XmcScorpio : public Xmc {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    XmcScorpio() : Xmc() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit XmcScorpio(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~XmcScorpio() {
        // Deinit();
    }

#if 0
    /**
     * @brief Set the aperture configurations, including index, address and size, etc
     *
     * @param apt_index
     * @param ctx_enable Whether to need match context id for incoming requests.
     * @param ctx_id Valid only if ctx_enable is `1`.
     * @param ctx_host Valid only if ctx_enable is `1`.
     * @param start_addr Start address of this aperture.
     * @param mem_size aperture size
     * @param mapped_addr the mapped address of aperture
     * @param shadow_random whether to select the shadow ports of CBF/MDF randomly.
     * @param sip_index -1 indicates non-sip, 0-15 indicate sip index.
     * @return true
     * @return false
     */
    virtual bool SetAptConfig(int apt_index, int ctx_enable, int ctx_id, int ctx_host,
        uint64_t start_addr, uint64_t mem_size, uint64_t mapped_addr, int shadow_random,
        int sip_index, bool cache_overwrite, uint32_t cache_value);

    /**
     * @brief Set the Stride Cfg object
     *
     * @param apt_index
     * @param ctx_enable Whether to need match context id for incoming requests.
     * @param ctx_host Valid only if ctx_enable is `1`.
     * @param ctx_id Valid only if ctx_enable is `1`.
     * @param ctx_num Do the remap for requests within the range of {ctx_id, ctx_id + ctx_num}.
     * @param start_addr Start address of this aperture.
     * @param mem_size aperture size
     * @param stride_size Indicates the step size for address calculation.
     * @note addr_in[29:2] -> addr_in[29:2] + STRIDE * (ctx_id_in - CTX_ID)
     * @return true
     * @return false
     */
    virtual bool SetStrideCfg(int apt_index, int ctx_enable, int ctx_id, int ctx_host,
        int ctx_num, uint64_t start_addr, uint64_t mem_size, uint32_t stride_size);

    /**
     * @brief Set the Hash Remap object
     *
     * @param apt_index
     * @param ctx_enable Whether to need match context id for incoming requests.
     * @param ctx_id Valid only if ctx_enable is `1`.
     * @param ctx_host Valid only if ctx_enable is `1`.
     * @param start_addr Start address of this aperture.
     * @param mem_size aperture size
     * @param clip_unit Clip incoming requests to the indicated unit, 0/1/2 ->
     * NONE/128Bytes/521Bytes
     * @param hash_unit Indicates the address unit for interleave, 0/1/2/3/4 ->
     * NONE/128Bytes/256Bytes/512Bytes/4KBytes
     * @param hash_mode Indicates how many CBFs to hash between, 0/1/2/3 -> 4/8/16/32 CBF
     * @param hash_group 0 use HASH_MASK[4:0][28:0], 1 use HASH_MASK[9:5][28:0]
     * @param cbf_id The starting CBF ID
     * @param cbd_offset The starting address in the CBF's port 0~16G used.
     * @note 4 CBFs requires 2 valid hash_mask[1:0], 32 CBF requires 5 valid hash_mask[4:0]
     * @return true
     * @return false
     */
    virtual bool SetHashRemap(int apt_index, int ctx_enable, int ctx_id, int ctx_host,
        uint64_t start_addr, uint64_t mem_size, int clip_unit, int hash_unit, int hash_mode,
        int hash_group, uint64_t cbf_id, uint64_t cbf_offset);

    /**
     * @brief Set the Sip Harvest according to index
     *
     * @param sip_index index of sip which need to do the harvest
     * @return true
     * @return false
     */
    virtual bool SetSipHarvest(int sip_index);

    /**
     * @brief Set the Uncache Map object
     *
     * @param pg_start The starting index of the PG of this VF.
     * @param pg_num The total number of PGs in the VF.
     * @param mdf_size DDR size corresponding to each MDF.
     * @param mdf_port Choose which port of mdf, 0 -> port0, 1 -> port1, 2 -> random.
     * @param no_cache Whether CBF is in full buffer mode.
     * @param die_id ID of die.
     * @param sip_index -1 indicates non-sip, 0-15 indicate sip index.
     * @return true
     * @return false
     */
    virtual bool SetUncacheMap(int pg_start, int pg_num, int mdf_size, int mdf_port,
        int no_cache, int die_id, int sip_index);
#endif
    virtual void SetWindowMap(
        int fault, uint64_t default_addr, uint64_t win_addr, uint64_t win_size);

    virtual void SetFirstAptCfg(FirstAptCfgCtx ctx);

    virtual void SetSecondAptCfg(SecondAptCfgCtx ctx);

    virtual void SetHashCfg(HashCfgCtx ctx);

    virtual void SetStrideCfg(StrideCfgCtx ctx);

    virtual void SetCtxOverwrite(int overwrite, int ctx_id, int ctx_host);

    /**
     * @brief Set the Hash Mask
     *
     * @param mask Used to specify how many address bits are used for hash calculation.
     * @return true
     * @return false
     */
    virtual bool SetHashMask(uint32_t index, HashMaskCfg mask);

    /**
     * @brief      Enable AR/AW reorder bit.
     *
     * @param[in]  val   The new value
     */
    virtual void SetReorder(bool val);

    /**
     * @brief      Sets the enable.
     *
     * @param[in]  val   The new value
     */
    virtual void SetEnable(bool val);

    /**
     * @brief      Disable hash function which set hash unit to 0
     *
     */
    virtual void DisableHash();

    /**
     * @brief Dump all the xmc info in the hardware tree.
     *
     */
    virtual void DumpInfo();

    /**
     * @brief      Dumps an information table.
     */
    virtual void DumpInfoTable();

    /**
     * @brief Parsing fault information if it has.
     *
     */
    virtual void DumpFaultInfo();

    /**
     * @brief      Get the physical address from virtual address.
     *
     * @param[in]  addr       virtual address
     * @param[in]  cacheable  The cacheable
     *
     * @return     physical address
     */
    virtual uint64_t VA2PA(uint64_t addr, bool cacheable, int ctx_id = -1);

    /**
     * @brief      Get the virtual address from physical address.
     *
     * @param[in]  addr       physical address
     * @param[in]  cacheable  The cacheable
     *
     * @return     virtual address
     */
    virtual uint64_t PA2VA(uint64_t addr, bool cacheable, int ctx_id = -1);

    /**
     * @brief Get second aperture config of given index.
     *
     * @param index apeture index
     * @return SecondAptCfgCtx
     */
    virtual SecondAptCfgCtx Get2ndAptCfg(int index);

    /**
     * @brief Set the Dynamic Qos of given aperture
     *
     * @param index apeture index
     * @param qos_value overwrite value
     */
    virtual void SetDynamicQos(bool enable, int index, uint32_t qos_value, int qos_ratio);
#if 0
    /**
     * @brief      { function_description }
     *
     * @param[in]  addr       The address
     * @param[in]  cacheable  The cacheable
     *
     * @return     { description_of_the_return_value }
     */
    virtual void DumpVA2PA(uint64_t addr, bool cacheable, int ctx_id = -1);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr       The address
     * @param[in]  cacheable  The cacheable
     *
     * @return     { description_of_the_return_value }
     */
    virtual void DumpPA2VA(uint64_t addr, bool cacheable, int ctx_id = -1);
#endif

 private:
    // out stream
    std::fstream out;

    /**
     * @brief      from Hardware class, call by Init
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit();

    /**
     * @brief      from Hardware class, call by Deinit
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit();

    /**
     * @brief Check whether the XMC on the DF bus path.
     *
     * @return true
     * @return false
     */
    bool IsDF();

    /**
     * @brief Check whether the XMC on teh slaver port.
     *
     * @return true
     * @return false
     */
    bool IsSlave();

    /**
     * @brief Check whether the xmc belongs to SA of IP or is independent instantiation.
     *
     * @return true
     * @return false
     */
    bool IsSA();

    /**
     *  Auxiliary setting interfaces.
     */

    /**
     * @brief Set the Aperture Mode
     *
     * @param mode 0/1/2/3 - 1st level apt/ 2nd level apt/ stride mode/ hash mode
     */
    void SetAptMode(uint32_t mode);

    /**
     * @brief Set aperture basic config.
     *
     * @param index - aperture start index.
     * @param addr - aperture address.
     * @param size - aperture size.
     * @param mapped_addr - the mapped address value.
     */
    void SetAptCfg(int index, uint64_t addr, uint64_t size, uint64_t mapped_addr);

    /**
     * @brief Set the context config if context enabled.
     *
     * @param enable - enable value of context id
     * @param id - context id
     * @param host - context host
     */
    void SetCtxCfg(int enable, int id, int host);

    /**
     * @brief Overwrite cache value of 1st aperture mapping of MDF
     *
     * @param overwrite - cache overwrite bit 0/1
     * @param value - overwritten cache value
     */
    void SetCacheOverwrite(int overwrite, uint32_t value);

    /**
     * @brief Overwrite qos value of 2nd aperture mapping of MDF
     *
     * @param overwrite - qos overwrite bit 0/1
     * @param value - overwritten qos value
     * @param ctx_id - overwritten qos ratio
     */
    void SetQosOverwrite(int overwrite, uint32_t value, int ctx_id);

    /**
     *  Register-info-read interfaces.
     */

    /**
     * @brief Get the XM_CLIENT_CTRL value
     *
     * @return uint32_t
     */
    uint32_t GetCtrlValue();

    /**
     * @brief Get the XM_CLIENT_FAULT value
     *
     * @return uint32_t
     */
    uint32_t GetFaultValue();

    /**
     * @brief Get the fault address
     *
     * @return uint32_t
     */
    uint32_t GetDefaultAddr();

    /**
     * @brief Get the Window Address
     *
     * @return uint32_t
     */
    uint32_t GetWinAddr();

    /**
     * @brief Get the Window Size
     *
     * @return uint32_t
     */
    uint32_t GetWinSize();

    /**
     * @brief Get the Clip Unit of indicated aperture
     *
     * @param index aperture index
     * @return uint32_t
     */
    uint32_t GetClipUnit(uint32_t index);

    /**
     * @brief Get the Hash Unit of indicated aperture
     *
     * @param index aperture index
     * @return uint32_t
     */
    uint32_t GetHashUnit(uint32_t index);

    /**
     * @brief Get the Hash Group of aperture.
     *
     * @param index aperture index
     * @return int
     */
    int GetHashGroup(int index);

    /**
     * @brief Get the Hash Mode
     *
     * @param index aperture index
     * @return int
     */
    int GetHashMode(int index);

    /**
     * @brief Read aperture data of indicated index
     *
     * @param index aperture index
     * @param attr used to select _ADDR/_EXT/_SIZE/_MAP (0/1/2/3)
     * @return uint32_t
     */
    uint32_t ReadAptData(uint32_t index, uint32_t attr);

    /**
     * @brief Get the apreture number according to different mode.
     *
     * @param mode aperture mode 0/1/2/3 - 1st level/2nd level/stride/hash.
     * @return uint32_t
     */
    uint32_t GetAptNumber(uint32_t mode);

    /**
     * @brief Get the Aperture configuratio of First Level
     *
     */
    void GetFirstLevelApt();

    /**
     * @brief Get the Aperture configuratio of Second Level
     *
     */
    void GetSecondLevelApt();

    /**
     * @brief Get the Hash Mask.
     *
     */
    void PrintHashMask();

    /**
     * @brief      Prints a hash mask table.
     */
    void PrintHashMaskTable();

    /**
     * @brief      { function_description }
     *
     * @param[in]  index  The index
     *
     * @return     { description_of_the_return_value }
     */
    bool IgnoreCache(int index);

    /**
     * @brief Get the Aperture configuration under the Stride Mode
     *
     */
    void GetStrideApt();

    /**
     * @brief Dump the xmc aperture info, ctrl value and window info.
     *
     */
    void XmcDump();

    /**
     * @brief      Prints an apt table.
     */
    void PrintAptTable(uint32_t mode);

    /**
     * Auxiliary functions for address hash calculation.
     */

    /**
     * @brief Calculate the hash result of input address.
     *
     * @param index aperture index
     * @param addr input address
     * @return uint64_t
     */
    uint64_t CalHashAddr(int index, uint64_t addr, HashMaskCfg mask);

    /**
     * @brief      { function_description }
     *
     * @param[in]  index    The index
     * @param[in]  addr_in  The address in
     *
     * @return     { description_of_the_return_value }
     */
    uint64_t CalRecoveryHashAddr(int index, uint64_t addr_in, HashMaskCfg mask);

    /**
     * @brief      Gets the hash masks.
     *
     * @return     The hash masks.
     */
    HashMaskCfg GetHashMasks();

    /**
     * @brief      Gets the bits.
     *
     * @param[in]  addr  The address
     * @param[in]  lhs   lsb (include)
     * @param[in]  rhs   msb (include)
     *
     * @return     The bits.
     */
    uint64_t GetBits(uint64_t addr, int lhs, int rhs);

    /**
     * @brief      Gets the xor.
     *
     * @param[in]  addr  The address
     *
     * @return     The xor.
     */
    uint64_t GetXOR(uint64_t addr);
#if 0
    uint64_t CalHashOutAddr(uint64_t in_addr, uint32_t hash_mode, uint32_t hash_unit);
#endif
};

}  // namespace xmc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_XMC_SCORPIO_XMC_H_
