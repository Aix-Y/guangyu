/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_XMC_SCORPIO_HAL_DIAG_XMC_IMPL_H_
#define HARDWARE_XMC_SCORPIO_HAL_DIAG_XMC_IMPL_H_

#include <stddef.h>
#include "hpd/include/hpd.h"

#define xmc_container_of(ptr, type, member)                             \
    ({                                                                  \
        const typeof(((type *)0)->member) *__mptr = (ptr); /* NOLINT */ \
        (type *)((char *)__mptr - offsetof(type, member)); /* NOLINT */ \
    })

struct hpd_xmc_core_ctx_wrapper {
    efvf::hpd::Hpd *   hpd;
    hpd_xmc_core_ctx_t ctx;
};

#define HAL_CTX_READ_REG(_ctx, _reg)                                             \
    ({                                                                           \
        hpd_xmc_core_ctx_wrapper *__tmp =                                        \
            xmc_container_of(_ctx, hpd_xmc_core_ctx_wrapper, ctx);               \
        __tmp->hpd->RegRead(                                                     \
            _ctx->base_addr + ((size_t) & ((hpd_xmc_t *)0)->_reg)); /* NOLINT */ \
    })

#define HAL_CTX_WRITE_REG(_ctx, _reg, _val)                                            \
    ({                                                                                 \
        hpd_xmc_core_ctx_wrapper *__tmp =                                              \
            xmc_container_of(_ctx, hpd_xmc_core_ctx_wrapper, ctx);                     \
        __tmp->hpd->RegWrite(                                                          \
            _ctx->base_addr + ((size_t) & ((hpd_xmc_t *)0)->_reg), _val); /* NOLINT */ \
    })

#endif  // HARDWARE_XMC_SCORPIO_HAL_DIAG_XMC_IMPL_H_
