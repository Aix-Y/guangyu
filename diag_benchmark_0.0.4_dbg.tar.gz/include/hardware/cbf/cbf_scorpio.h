/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_CBF_CBF_SCORPIO_H_
#define HARDWARE_CBF_CBF_SCORPIO_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "hardware/include/bpm.h"
#include "hardware/include/cbf/cbf.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace cbf {

#define SCORPIO_CBF_CACHE_MEM_TYPE_NUM 2

#define SCORPIO_CBF_DF_PORT_NUM 2

#define SCORPIO_CBF_BB_BLOCK_NUM 2
#define SCORPIO_CBF_BC_BLOCK_NUM 2
#define SCORPIO_CBF_BC_CORE_NUM 4

#define SCORPIO_CBF_BB_BLOCK_MASK 0x3
#define SCORPIO_CBF_BC_BLOCK_MASK 0xf

#define SCORPIO_CBF_BUFFER_4MB_SIZE 0x400000          // 4MB
#define SCORPIO_CBF_CACHE_1MB_SIZE 0x100000           // 1MB
#define SCORPIO_CBF_SCRATCH_BUFFER_1MB_SIZE 0x100000  // 1MB

#define SCORPIO_BB_SRAM_BANK_SIZE 0x40000  // 256KB
#define SCORPIO_BC_SRAM_BANK_SIZE 0x20000  // 128KB

#define SCORPIO_BC_CACHELINE_SIZE 0x200    // 512B
#define SCORPIO_BC_CACHE_SECTOR_SIZE 0x80  // 128B

#define SCORPIO_BC_CACHE_MTN_MAX_OUTSTANDING 32

#define SCORPIO_BC_CACHE_MAXWAY_NUM 16

#define SCORPIO_CBF_CACHE_HIT_RATIO_NUM 16

#define SCORPIO_CBF_SLV_BPM_NUM 2
#define SCORPIO_CBF_MST_BPM_NUM 1

class CbfScorpio : public Cbf {
 public:
    explicit CbfScorpio(std::shared_ptr<spdlog::logger> logger) : Cbf(logger) {
        cbf_bc_cnt_      = 2;
        cbf_bc_core_cnt_ = 4;
        cbf_bb_cnt_      = 2;
    }

    virtual ~CbfScorpio() {}

    virtual void LibInit();

    virtual uint16_t GetCbfCnt();

    virtual uint16_t GetCbfBcCnt();

    virtual uint16_t GetCbfBcCoreCnt();

    virtual uint16_t GetCbfBbCnt();

    virtual uint16_t GetDfPortCnt();

    virtual uint16_t GetCbfCacheMemTypeCnt();

    virtual uint16_t GetBbOneBankSramCnt();

    virtual uint16_t GetBcOneBankSramCnt();

    virtual uint16_t GetCacheHitRatioCnt();

    virtual uint16_t GetSlvBpmCnt();

    virtual uint16_t GetMstBpmCnt();

    virtual uint32_t GetBufferTotalSize();

    virtual uint32_t GetSratchBufferTotalSize();

    virtual uint32_t GetCacheTotalSize();

    virtual uint32_t GetBbBankSize();

    virtual uint32_t GetBcBankSize();

    virtual uint32_t GetOneSramSize();

    virtual uint32_t GetCachelineSize();

    virtual uint32_t GetCacheSectorSize();

    virtual uint32_t GetCacheMtnMaxOutstanding();

    virtual uint32_t GetCacheMaxWayNum();

    virtual std::bitset<CBF_BLOCK_MASK_NUM> GetCbfBcMask();

    virtual std::bitset<CBF_BLOCK_MASK_NUM> GetCbfBbMask();

    virtual std::bitset<CBF_BLOCK_MASK_NUM> GetCbfBufMask();

    virtual CbfDp *GetCbfDp();

    virtual CbfBc *GetCbfBc(uint8_t cbf_bc_id);

    virtual CbfBb *GetCbfBb(uint8_t cbf_bb_id);

    virtual Bpm *GetCbfBpm(const CbfBpmType &bpm_type, uint8_t bpm_idx);

    virtual void GetCacheMemAttribute(
        CbfCacheMemCfg *cache_mem_cfg, const CbfCacheMemType &mem_type);

    virtual void SetContextId(uint8_t ctx_id);

    virtual void SetMasterId(uint16_t mst_id);

    virtual void EnableScratchBufferMode();

    virtual void DisableScratchBufferMode();

    virtual bool IsScratchBufferMode();

    virtual void SetCacheAddrBoundary(uint32_t addr_boundary_size);

    virtual uint64_t GetCacheAddrBoundary();

    virtual void EnableHwPrefetchForceClose();

    virtual void DisableHwPrefetchForceClose();

    virtual void SetProfileStart();

    virtual void SetProfileEnd();

    virtual void ClearProfile();

    virtual void GetProfileIndicatorInfo(CbfProfilerInfo *prfl_info);

    virtual void PrintProfileIndicatorInfo(const CbfProfilerInfo &prfl_info);

    virtual bool CheckProfileIndicatorInfo(const CbfProfilerInfo &rd_prfl_info,
        const CbfProfilerInfo &exp_prfl_info, bool check_hit_miss = true);

    virtual void PrintRwChErrInfo();

    virtual void PrintPwstIndicatorInfo();

    virtual void GetCbfInnStatus(CbfInnStatus *cbf_status);

    virtual void ClearCbfInnStatus(const CbfInnStatus &cbf_status);

    virtual void SetCbfInnIrqMask(const CbfIrqStatus &cbf_irq_mask);

    virtual void ClearAllIrqMasks();

    virtual void SetIpuCtrl(uint32_t val);

    virtual bool QueryRasInterrupt(
        const CbfType &buf_type, const CbfRwType &rw_type, uint16_t buf_id, uint16_t port_id);

    virtual void ClearRasInterrupt(
        const CbfType &buf_type, const CbfRwType &rw_type, uint16_t buf_id, uint16_t port_id);

 public:
    virtual SystemAdapter *GetSa();

 protected:
    virtual uint32_t CsrRegRead(uint32_t addr);
    virtual void CsrRegWrite(uint32_t addr, uint32_t val);

    virtual uint32_t Bb0RegRead(uint32_t addr);
    virtual void Bb0RegWrite(uint32_t addr, uint32_t val);

 private:
    virtual bool HwInit();
    virtual bool HwDeinit();

 private:
    std::vector<CbfBc *> cbf_bc_ins_;
    std::vector<CbfBb *> cbf_bb_ins_;
    // std::shared_ptr<CbfDp> cbf_dp_ins_;

    Hardware *hw_cbf_csr_blk_ = nullptr;
    // CbfCacheMemCfg *     cache_mem_cfg_;
    Hardware *hw_cbf_bb0_blk = nullptr;
    Hardware *hw_cbf_bb1_blk = nullptr;

    friend class CbfRasScorpio;
};

}  // namespace cbf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CBF_CBF_SCORPIO_H_
