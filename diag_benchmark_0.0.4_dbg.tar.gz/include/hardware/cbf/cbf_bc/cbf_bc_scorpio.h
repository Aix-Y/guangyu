/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_CBF_CBF_BC_CBF_BC_SCORPIO_H_
#define HARDWARE_CBF_CBF_BC_CBF_BC_SCORPIO_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "hardware/include/cbf/cbf_bc.h"

namespace efvf {
namespace hardware {
namespace cbf {
namespace cbf_bc {

// 512KB (for one bank cache (2 * cache core))
#define SCORPIO_CBF_ONE_CACHE_512KB_SIZE 0x80000
#define SCORPIO_CBF_ONE_CACHE_BANK_CNT 2  // One bank: 256KB

class CbfBcScorpio : public CbfBc {
 public:
    explicit CbfBcScorpio(std::shared_ptr<spdlog::logger> logger);
    virtual ~CbfBcScorpio();

    virtual uint32_t GetOneBcSize() {
        return SCORPIO_CBF_ONE_CACHE_512KB_SIZE / 2;  // one bc core cache size: 256KB
    }

    virtual uint32_t GetOneBcBankCnt() {
        return SCORPIO_CBF_ONE_CACHE_BANK_CNT;
    }

    virtual void EnableRedunMask(uint32_t mask_sel);

    virtual void DisableRedunMask();

    virtual void SetReplacePolicy();

    virtual void SetCachePriorityMaxWay(uint8_t high_way, uint8_t mid_way);

    virtual void EnableParityCheck();

    virtual void DisableParityCheck();

    virtual void EnableParityErrEnj();

    virtual void DisableParityErrEnj();

    virtual void SetParityErrEnjType(const CbfBcParityErrEnjType par_err_enj_type);

    virtual void SetParityErrEnjCountOneTime(uint32_t par_err_enj_count);

    virtual bool CheckParityErrInfo(uint16_t port_id);

    virtual void EnableForceClkOn();

    virtual void DisableForceClkOn();

    virtual bool CheckCacheMshrEmpty(uint16_t mshr_idx);

    virtual void GetCacheMshrStatus(uint16_t mshr_idx, CbfBcCacheMshrStatus *mshr_sts);

    virtual void PrintCacheMshrStatus(uint16_t bc_id, uint16_t mshr_idx);

    virtual void EnableEvictFifoQos();

    virtual void DisableEvictFifoQos();

    virtual void SetEvictFifoQosData(uint16_t qos_data);

    virtual void ConfigCacheFlush(const CbfCacheFlushCtrl &flush_ctrl);

    virtual void LockCacheLine();

    virtual uint32_t CheckTagFlushDone();

    virtual bool CheckSectorFlushDone();

    virtual bool CheckStrobeFlushDone();
};

}  // namespace cbf_bc
}  // namespace cbf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CBF_CBF_BC_CBF_BC_SCORPIO_H_
