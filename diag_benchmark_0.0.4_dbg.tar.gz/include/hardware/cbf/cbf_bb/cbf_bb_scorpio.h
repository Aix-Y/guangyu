/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_CBF_CBF_BB_CBF_BB_SCORPIO_H_
#define HARDWARE_CBF_CBF_BB_CBF_BB_SCORPIO_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "hardware/include/cbf/cbf_bb.h"

namespace efvf {
namespace hardware {
namespace cbf {
namespace cbf_bb {

#define SCORPIO_CBF_ONE_BUFFER_2MB_SIZE 0x200000  // 2MB
#define SCORPIO_CBF_ONE_BUFFER_BANK_CNT 8         // One bank: 256KB

class CbfBbScorpio : public CbfBb {
 public:
    explicit CbfBbScorpio(std::shared_ptr<spdlog::logger> logger);
    virtual ~CbfBbScorpio();

    virtual uint32_t GetOneBbSize() {
        return SCORPIO_CBF_ONE_BUFFER_2MB_SIZE;
    }

    virtual uint32_t GetOneBbBankCnt() {
        return SCORPIO_CBF_ONE_BUFFER_BANK_CNT;
    }

    virtual void EnableRedunMask(uint32_t mask_sel);

    virtual void DisableRedunMask();

    virtual void EnableEccDecode();

    virtual void DisableEccDecode();

    virtual void EnableEccErrEnj();

    virtual void DisableEccErrEnj();

    virtual void SetEccErrEnjType(const CbfBbEccErrEnjType ecc_err_enj_type);

    virtual void SetEccErrEnjCountOneTime(uint32_t ecc_err_enj_count);

    virtual bool CheckEccErrInfo(const CbfRwType &rw, uint16_t port_id);
};

}  // namespace cbf_bb
}  // namespace cbf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_CBF_CBF_BB_CBF_BB_SCORPIO_H_
