/////////////////////////////////////////////////////////////////////////////
//
//  @file dft_pcorpio.h
//
//  @brief Interface declaration of dft library for Libra
//
//  Enflame Tech, All Rights Reserved. 2024 Copyright (C)
//
/////////////////////////////////////////////////////////////////////////////
#ifndef HARDWARE_DFT_DFT_LIBRA_H_
#define HARDWARE_DFT_DFT_LIBRA_H_

#include <stdint.h>
#include <memory>
#include <string>
#include "hardware/dft/dft_base.h"

namespace efvf {
namespace hardware {
namespace dft {

#define CDFT_AXI_ECF_MST_CONFIG     0x40
#define CDFT_AXI_ECF_MST_SETUP      0x41
#define CDFT_AXI_ECF_MST_OUT        0x42
#define CDFT_AXI_ECF_MST_IN         0x43
#define CDFT_AXI_ECF_MST_STATUS     0x44
#define CDFT_AXI_ECF_MST_ERROR_OBS  0x45
#define CDFT_AXI_ECF_MST_USER_OBS   0x46

#define CDFT_STN_CONFIG_MODE_WIDTH        7
#define CDFT_AXI_ECF_MST_CONFIG_WIDTH     31
#define CDFT_AXI_ECF_MST_SETUP_WIDTH      7 
#define CDFT_AXI_ECF_MST_OUT_WIDTH        67
#define CDFT_AXI_ECF_MST_OUT_SP_WIDTH     77
#define CDFT_AXI_ECF_MST_IN_WIDTH         33
#define CDFT_AXI_ECF_MST_STATUS_WIDTH     3
#define CDFT_AXI_ECF_MST_ERROR_OBS_WIDTH  32
#define CDFT_AXI_ECF_MST_USER_OBS_WIDTH   12

class DftLibra : public DftBase {

 typedef union _AXI_MASTER_SETUP_Libra
{
	uint32_t value;
	struct
	{
		uint32_t AXI_ECF_EN                   : 1;
		uint32_t AXI_ECF_CLR_ST               : 1;
        uint32_t ruser_check_enable           : 1;
        uint32_t ruser_check_mode             : 1;
        uint32_t buser_check_enable           : 1;
        uint32_t write_parity_gen_enable      : 1;
        uint32_t write_parity_error_injection : 1;
	};
    uint8_t buf[1] = {0};
} AXI_MASTER_SETUP;

// total 31 bits
typedef union _AXI_MASTER_CONFIG_Libra
{
    uint32_t value;
    struct
    {
        uint32_t ID         : 6;
        uint32_t init_id    : 5;
        uint32_t unit_id    : 5;
        uint32_t burst      : 1;
        uint32_t QOS        : 4;
        uint32_t PROT       : 3;
        uint32_t EXT        : 6;
        uint32_t reserved   : 2;
    };
    uint8_t buf[4] = {0};
} AXI_MASTER_CONFIG;

typedef union _AXI_MASTER_OUT
{
	uint32_t buffer[3] = {0};	// TDR length is 67
	struct _fields
	{
        uint32_t AXI_WR_DATA	: 32;
        uint32_t AXI_ADDR       : 30;
        uint32_t AXI_BYTE_EN1	: 2;    // break here for 64 bit alignment issue
        uint32_t AXI_BYTE_EN2	: 2;
        uint32_t AXI_OPCODE     : 1;
	} fields;
} AXI_MASTER_OUT_u;

typedef union _AXI_MASTER_IN
{
	uint64_t value;		// TDR length is 33
	struct _fields
	{
		uint32_t AXI_RD_DATA 	: 32;
		uint32_t AXI_RD_VALID 	: 1;
	} fields;
} AXI_MASTER_IN_u;

typedef union _AXI_STATUS
{
	uint32_t value = 0;		// TDR length is 3
	struct _fields
	{
		uint32_t AXI_ECF_TRAN_ERROR : 1;
		uint32_t AXI_ECF_TRAN_DONE	: 1;
		uint32_t AXI_ECF_TRAN_START	: 1;
	} fields;
} AXI_STATUS_u;

typedef enum die_mask {
    INVALID_VALUE   = -1,
    SINGLE_DIE_MASK = 0x0,
    MASTER_DIE_MASK = 0x1,
    SLAVE_DIE_MASK  = 0x2,
    DUAL_DIES_MASK  = 0x3,
} die_mask_t;

public:
    DftLibra() {}
    explicit DftLibra(std::shared_ptr<spdlog::logger> logger);
    virtual ~DftLibra();

    virtual bool ReadTDR(std::string tdr, uint32_t &outValue);
    virtual bool WriteTDR(char *tdr, uint32_t value);

    virtual int ShiftIR(uint32_t sizeInBits, uint32_t IR);
    virtual int ShiftDR(uint32_t sizeInBits, uint32_t DR);
    virtual int ShiftDR(uint32_t sizeInBits, uint32_t buffer[]);
    virtual int ShiftIRDR(int irSizeInBits, uint32_t IR, int drSizeInBits, uint32_t DR);
    virtual int ShiftIRDR(int irSizeInBits, uint32_t IR, int drSizeInBits, uint32_t buffer[]);

    virtual int ReadTDO(int sizeInBits, uint32_t &TDO);
    virtual int ReadTDO(int sizeInBits, uint32_t buffer[]);

    virtual void ShiftTMS(void);

    virtual bool TestJTAG();
    virtual bool ReadIDCode();

    virtual void JTAG_Reset();

    virtual void SwitchAltTAP();

    // Access registers via jtag2axi
    virtual int ReadReg(uint32_t addr, uint32_t &outValue);
    virtual int WriteReg(uint32_t addr, uint32_t value);

    // SSM register access methods
    virtual int ReadSSMReg(int offset, uint32_t &outValue);
    virtual int WriteSSMReg(int offset, uint32_t value);

    // MC related functional interfaces
    virtual int MC_SetApbOwnTap(int mc_index, bool enable);
    virtual int MC_WriteIR(int mc_index, int sizeInBits, uint32_t IR);
    virtual int MC_ReadDR(int mc_index, int sizeInBits, uint32_t outValue[]);
    virtual int MC_WriteDR(int mc_index, int sizeInBits, uint32_t data_in[]);

    virtual bool ReadMcLtapIDCode(int mc_index);

    // HBM Phy register access methods
    virtual bool ReadHBMPhyReg(
        int phy_index, int channel_index, int dword_index, int offset, uint32_t &outValue);
    virtual bool WriteHBMPhyReg(
        int phy_index, int channel_index, int dword_index, int offset, uint32_t value);

    // PCIE/CCIX Phy register access methods
    virtual bool ReadPCIePhyReg(int phy_index, int address, uint32_t &outValue);
    virtual bool WritePCIePhyReg(int phy_index, int address, uint32_t value);

    virtual bool ReadCCIXPhyReg(int phy_index, int address, uint32_t &outValue);
    virtual bool WriteCCIXPhyReg(int phy_index, int address, uint32_t value);

    // Scan setup TDR for Libra cluster reset workaround
    virtual int ReadScanSetupTDR(int cluster_id, uint32_t &outValue);
    virtual int WriteScanSetupTDR(int cluster_id);

    virtual int MemoryRepairWorkaround(void);
    virtual int ReadMemoryRepairWorkaroundTDR(void);

    virtual int SampleCode(void);

 private:
    /**
     * @brief      do hardware related init stuff here
     *
     * @return     boolean status of the initialization
     */
    virtual bool HwInit();

    /**
     * @brief      do hardware related de-init stuff here
     *
     * @return     boolean status of the de-initialization
     */
    virtual bool HwDeinit();

 protected:
    uint32_t DFT_BASE_ADDRESS = 0x027C4000;

    void InitJtagAxiCtrl();
    void ReleaseAXITAP();
    void InitMcApbCtrl();
    void ReleaseMcApbTAP();

 private:
    inline void ReadRegCheck(uint32_t address, uint32_t value) {
        if (value != com_reg_->RegRead(address))
            LOG_ERROR("Failed to write value {:#x} to address {:#x}!", value, address);
    }
    bool SelectHBMPhyChannel(int phy_index, int channel_index, int dword_index);
    bool EnablePCIePhyAltTAP();
    bool SelectCCIXPhyChannel(uint32_t phy_index);

    int GetBitsNum(std::string bits_str);
    uint64_t GetTdrValue(int startbit, int *data, int len, int width);
    int ssm_stat_data(int op, int value);
    void ssm_enable(int op /* 0 w, 1 r */, int value);
    void ssm_ctrl_data(int op /* 0 w, 1 r */, uint64_t val);
    void ssm_override(int op /* 0 w, 1 r */, uint32_t value);
    void tdr_ssm_op(int op, uint64_t addr, uint64_t data);
    BitsNumValue BitsStrToBitsNumAndValue(std::string bits_str);
    void Pmtap2Tessent();
    void Tessent2Pmtap();

    void prepare_ir_and_dr(die_mask_t die_mask, uint32_t ir, uint32_t ir_len, uint32_t dr_len, uint32_t *new_ir, uint32_t *new_ir_len, uint32_t *new_dr_len);
    uint8_t* prepare_dr_data(die_mask_t die_mask, uint8_t *shift_data, uint32_t dr_len);

 protected:
    Hardware *com_reg_ = nullptr;   // for register access
};

}  // namespace dft
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_DFT_DFT_LIBRA_H_
