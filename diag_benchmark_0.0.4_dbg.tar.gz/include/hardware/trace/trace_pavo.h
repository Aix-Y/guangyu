/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_TRACE_TRACE_PAVO_H_
#define HARDWARE_TRACE_TRACE_PAVO_H_

#include <memory>
#include <string>
#include "hardware/include/trace.h"

namespace efvf {
namespace hardware {
namespace trace {

class TracePavo : public Trace {
 public:
    explicit TracePavo(std::shared_ptr<spdlog::logger> logger);
    virtual ~TracePavo();

    virtual int Play(std::string trace_path);
    virtual void FillTraceStream(std::string path, std::string pattern);

 private:
    int PlayFillMem(TraceSimpleCmd *cmd);
    int PlayLoopCmd(int cluster_id, TraceLoopCmd *cmd);
    int PlayDmaCmd(int cluster_id, TraceLoopCmd *cmd);
    int PlayLaunchSipCmd(int cluster_id, TraceLoopCmd *cmd);
};

}  // namespace trace
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_TRACE_TRACE_PAVO_H_
