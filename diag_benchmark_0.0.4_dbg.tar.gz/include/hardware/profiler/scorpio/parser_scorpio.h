/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_SCORPIO_PARSER_SCORPIO_H_
#define HARDWARE_PROFILER_SCORPIO_PARSER_SCORPIO_H_

#include "hardware/include/profiler/parser.h"

#include <cstdint>

#include <iostream>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

namespace efvf {
namespace hardware {
namespace profiler {

typedef struct {
    uint32_t master_id : 10;
    uint32_t reserved : 22;
} ProfilingTraceMsgHeader;

typedef struct {
    uint32_t length : 6;
    uint32_t reserved : 25;
    uint32_t profiling_flg : 1;
} ProfilingEventHeader;

typedef struct {
    ProfilingEventHeader  head;
    uint32_t              op_id;
    std::vector<uint32_t> profiling_payload;
} ProfilingEventPacket;

typedef struct {
    uint32_t timer_val_high : 30;
    uint32_t timebase_flg : 1;
    uint32_t timeline_flg : 1;
} TraceEventA;

typedef struct {
    uint32_t timer_val_low : 16;
    uint32_t packet_id_low : 4;
    uint32_t context_id : 4;
    uint32_t type : 5;
    uint32_t base_flg : 1;
    uint32_t timebase_flg : 1;
    uint32_t timeline_flg : 1;
} TraceEventB;

typedef struct {
    uint32_t packet_id_high : 28;
    uint32_t reserved : 1;
    uint32_t base_flg : 1;
    uint32_t timebase_flg : 1;
    uint32_t timeline_flg : 1;
} TraceEventC;

class ProfilerRingScorpio;
class ParserScorpio : public Parser {
 public:
    // messages are always sent to DPF ring buffer in the unit of 128B
    static const uint32_t DPF_MSG_SIZE = 128;

 public:
    explicit ParserScorpio(ProfilerRingScorpio *ring);
    virtual ~ParserScorpio() = default;

    DpfMasterType GetMasterType(uint32_t master_id) override;
    std::string GetMasterName(uint32_t master_id) override;
};

class ProfilerRingProfilingScorpio;
class ParserProfilingScorpio : public ParserScorpio {
 public:
    explicit ParserProfilingScorpio(ProfilerRingProfilingScorpio *ring);
    virtual ~ParserProfilingScorpio() = default;

    //!
    //! @brief parse all events in corresponding specified system buffer
    //!
    void Parse(std::string   filename = "",
        std::vector<uint8_t> len      = std::vector<uint8_t>(8, 4)) override;

    //!
    //! @brief get duration from first valid event to last valid event
    //!
    //! it doesn't parse all events. It finds the first and the last valid event,
    //! and, calculate the duration. It will much faster than Parser() for
    //! large event number
    uint64_t GetDuration() override;
    // duration between first event and last event
    uint64_t GetOverallDuration() override;

    //!
    //! @brief print summary of parsed result
    //!
    void PrintSummary() override;

    //!
    //! @brief write parsed events to a json file
    //!
    void WritetoFile(const std::string &json_filename) override;

    //!
    //! @brief Find the timestamp of a specific event from a given master
    //!
    uint64_t GetEventTimestamp(
        uint32_t master_id, uint8_t event_type, uint32_t index, bool reverve = false) override;
    //!
    //! @brief accessor
    //!
    std::map<uint32_t, std::vector<TraceEvent>> trace_events() {
        return trace_events_;
    }
    std::map<uint32_t, std::vector<ProfilingEvent>> profiling_events() {
        return profiling_events_;
    }

 private:
    bool IsProfilingEvent(uint32_t word) {
        ProfilingEventHeader *tmp = reinterpret_cast<ProfilingEventHeader *>(&word);
        if (tmp->profiling_flg && tmp->reserved == 0)
            return true;
        return false;
    }
    uint32_t GetProfilingEventLength(uint32_t word) {
        ProfilingEventHeader *tmp = reinterpret_cast<ProfilingEventHeader *>(&word);
        return tmp->length;
    }
    bool IsTraceEventA(uint32_t word) {
        TraceEventA *tmp = reinterpret_cast<TraceEventA *>(&word);
        return tmp->timebase_flg;
    }
    bool IsTraceEventB(uint32_t word) {
        TraceEventB *tmp = reinterpret_cast<TraceEventB *>(&word);
        return !tmp->timebase_flg && tmp->base_flg;
    }
    bool IsTraceEventC(uint32_t word) {
        TraceEventC *tmp = reinterpret_cast<TraceEventC *>(&word);
        return !tmp->timebase_flg && !tmp->base_flg;
    }
    void ConvertRawDataToEvents(
        std::unordered_map<uint32_t, std::vector<uint32_t>> &events_map,
        const std::vector<uint8_t> &valid_lengths);
    void ConvertTraceEventToJson();
    void ConvertGdteTraceEventToJson(uint32_t master_id, std::vector<TraceEvent> &events,
        boost::property_tree::ptree &ptree_events);
    void ConvertSipTraceEventToJson(uint32_t master_id, std::vector<TraceEvent> &events,
        boost::property_tree::ptree &ptree_events);
    void ConvertVppTraceEventToJson(uint32_t master_id, std::vector<TraceEvent> &events,
        boost::property_tree::ptree &ptree_events);
    void PrintSipProfilingInfo();
    void PrintPmcCounters(uint32_t index, const std::vector<uint64_t> &counters);
    std::vector<uint64_t> ConvertRawDataToFormatedData(
        const uint8_t *data, const std::vector<uint8_t> &len);

 private:
    //!
    //! @brief property tree root for all events
    //!
    std::map<uint32_t, std::vector<TraceEvent>>     trace_events_;
    std::map<uint32_t, std::vector<ProfilingEvent>> profiling_events_;
    boost::property_tree::ptree ptree_root_;
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_SCORPIO_PARSER_SCORPIO_H_
