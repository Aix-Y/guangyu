/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_SCORPIO_PROFILER_SCORPIO_H_
#define HARDWARE_PROFILER_SCORPIO_PROFILER_SCORPIO_H_

#include <memory>

#include "hardware/include/profiler/profiler.h"

namespace efvf {
namespace hardware {
namespace profiler {

class ProfilerScorpio : public Profiler {
    //!
    //! Three ring buffer in Scorpio DPF
    //! Ring 0: profiling and event trace
    //! Ring 1: sdte l2loss(not implemented)
    //! Ring 2: log/customized events(not implemented)
    //!
    static const uint32_t SCORPIO_DPF_RING_NUM = 3;

 public:
    explicit ProfilerScorpio(std::shared_ptr<spdlog::logger> logger);
    virtual ~ProfilerScorpio() = default;
};

class ProfilerRingScorpio : public ProfilerRing {
 public:
    explicit ProfilerRingScorpio(ProfilerScorpio *profiler);
    virtual ~ProfilerRingScorpio() = default;
};

class ProfilerRingProfilingScorpio : public ProfilerRingScorpio {
 public:
    explicit ProfilerRingProfilingScorpio(ProfilerScorpio *profiler);
    virtual ~ProfilerRingProfilingScorpio() = default;

 private:
    void SetupHW(const RingCfg &cfg) override;
    void StartHW() override;
    void StopHW() override;
    void GetProducerStatus(uint32_t &wptr, bool &wwrap) override;
    void Move(uint64_t ring_offset, uint64_t buf_offset, uint64_t size) override;
    void Update(const uint32_t &rptr, const bool &rwrap) override;
    bool IsDfOngoing();

    void Config();
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_SCORPIO_PROFILER_SCORPIO_H_
