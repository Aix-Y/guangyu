/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_PARSER2D0_H_
#define HARDWARE_PROFILER_PARSER2D0_H_

#include <fstream>
#include <memory>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include "hardware/include/profiler/parser.h"

#include "boost/property_tree/json_parser.hpp"
#include "boost/property_tree/ptree.hpp"

#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace profiler {

//!
//! @brief dms events
//!
enum DpfDmaEventType {
    DMA_BUSY_START   = 0,  // redundant events, skip
    DMA_BUSY_END     = 1,  // redundant events, skip
    DMA_VC_EXE_START = 2,  // events sent when vc starts
    DMA_VC_EXE_END   = 3   // events sent when vc stops
};

//!
//! @brief sip events
//!
enum DpfSipEventType {
    SIP_EVENT_GOTO_IDLE   = 0,  // events sent before halt
    SIP_EVENT_GOTO_BUSY   = 1,  // events sent at the beginning of sip running
    SIP_EVENT_OP_START    = 2,
    SIP_EVENT_OP_FINISH   = 3,
    SIP_EVENT_TRAP_START  = 4,
    SIP_EVENT_TRAP_FINISH = 5,
    SIP_EVENT_WAIT_START  = 6,  // events sent before wait instructions
    SIP_EVENT_WAIT_FINISH = 7   // events sent after wait instructions
};

//!
//! @brief info for each master
//!
typedef struct {
    DpfMasterType type;
    std::string   name;
} DpfInfo;

//!
//! @brief dma event header
//!
typedef struct {
    uint32_t zero1 : 1;
    uint32_t event_type : 2;
    uint32_t vc_id : 5;
    uint32_t zero2 : 1;
    uint32_t packet_id : 23;
} dma_event_header;

//!
//! @brief sip event header
//!
typedef struct {
    uint32_t zero1 : 1;
    uint32_t event_type : 8;
    uint32_t packet_id : 23;
} sip_event_header;

//!
//! general event format
//!
typedef struct {
    union {
        dma_event_header dma_header;
        sip_event_header sip_header;
        uint32_t         val;
    } header;
    struct _info {
        uint32_t master_id : 10;
        uint32_t reserve0 : 2;
        uint32_t context_id : 4;
        uint32_t reserved1 : 16;
    } info;
    uint32_t timestamp_low;
    uint32_t timestamp_high;
} DpfMessage;

class ProfilerRing;
class Parser2D0 : public Parser {
 public:
    //!
    //! @brief magic number for flush dpf fifo
    //!
    //! The magic number to flush ring fifo
    //!
    static const uint32_t kDpfFlushMagicNum = 0xDEADBEEF;

 public:
    explicit Parser2D0(ProfilerRing *ring);
    virtual ~Parser2D0() = default;

    //!
    //! @brief parse all events in corresponding specified system buffer
    //!
    void Parse(std::string   filename = "",
        std::vector<uint8_t> len      = std::vector<uint8_t>{8, 4}) override;

    //!
    //! @brief get duration from first valid event to last valid event
    //!
    //! it doesn't parse all events. It finds the first and the last valid event,
    //! and, calculate the duration. It will much faster than Parser() for
    //! large event number
    uint64_t GetDuration() override;

    //!
    //! @brief print summary of parsed result
    //!
    void PrintSummary() override;

    //!
    //! @brief write parsed events to a json file
    //!
    void WritetoFile(const std::string &json_filename) override;

 public:
    std::array<uint32_t, 9> event_num() {
        return event_num_;
    }

 private:
    //!
    //! @brief parse a dma event and generate a property tree node
    //!
    void ParseDmaEvent(DpfMessage *event, boost::property_tree::ptree &child);

    //!
    //! @brief parse a sip event and generate one or two property tree node(s)
    //!
    //! for start/stop events, generate one node
    //! for wait events, generate two nodes
    //!
    void ParseSipEvent(DpfMessage *event, boost::property_tree::ptree &child);
    void ParseSipStartEvent(DpfMessage *event, boost::property_tree::ptree &child);
    void ParseSipStopEvent(DpfMessage *event, boost::property_tree::ptree &child);
    void ParseSipEnterWaitEvent(DpfMessage *event, boost::property_tree::ptree &child);
    void ParseSipExitWaitEvent(DpfMessage *event, boost::property_tree::ptree &child);

    //!
    //! @brief create alias for processes
    //!
    //! process is named by master id by default, a meainingful name make timeline readable
    //!
    void AddProcessAliasEvents();

    //!
    //! @brief create orders for threads in a process
    //!
    //! sort gdma VCs by VC id
    //!
    void AddThreadSortEvents();

    //!
    //! @brief get the timestamp of first valid event
    //!
    //! a valid event is a supported event from dma or sip
    //!
    uint64_t GetFirstValidEvent();

    //!
    //! @brief get the timestamp of last valid event
    //!
    //! a valid event is a supported event from dma or sip
    //!
    uint64_t GetLastValidEvent();

    //  protected:
    //     //!
    //     //! @brief logger
    //     //!
    //     std::shared_ptr<spdlog::logger> logger_;

 private:
    //!
    //! @brief contains all master id that sends events to system buffer
    //!
    std::set<uint32_t> master_id_set_;

    //!
    //! @brief contains all dma <master id, vc id> pair
    //!
    std::set<std::pair<uint32_t, uint32_t>> dma_id_pair_set_;

    //!
    //! @brief property tree root for all events
    //!
    boost::property_tree::ptree ptree_root_;

    //!
    //! @brief record the event nums of all types
    //!
    //! index
    //! 0: dma vc start event
    //! 1: dma vc stop event
    //! 2: dma start event
    //! 3: dma stop event
    //! 4: sip start event
    //! 5: sip stop event
    //! 6: sip enter wait event
    //! 7: sip exit wait event
    //! 8: unsupported event
    //!
    std::array<uint32_t, 9> event_num_{};
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_PARSER2D0_H_
