/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_LIBRA_PROFILING_PARSER_LIBRA_H_
#define HARDWARE_PROFILER_LIBRA_PROFILING_PARSER_LIBRA_H_

#include <cstdint>

#include <iostream>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

#include "hardware/profiler/libra/parser_libra.h"

namespace efvf {
namespace hardware {
namespace profiler {

typedef struct {
    uint32_t length : 6;
    uint32_t master_id : 10;
    uint32_t context_id : 4;
    uint32_t die_id : 1;
    uint32_t reserved : 11;
} ProfilingEventHeader;

typedef struct {
    ProfilingEventHeader  head;
    uint32_t              op_id;
    std::vector<uint32_t> profiling_payload;
} ProfilingEventPacket;

class ParserProfilingLibra : public ParserLibra {
 public:
    explicit ParserProfilingLibra(ProfilerRingLibra *ring);
    virtual ~ParserProfilingLibra() = default;

    //!
    //! @brief parse all events in corresponding specified system buffer
    //!
    void Parse(std::string   filename = "",
        std::vector<uint8_t> len      = std::vector<uint8_t>(8, 4)) override;

    //!
    //! @brief print summary of parsed result
    //!
    void PrintSummary() override;

 private:
    uint32_t GetProfilingEventLength(uint32_t word) {
        ProfilingEventHeader *tmp = reinterpret_cast<ProfilingEventHeader *>(&word);
        return tmp->length;
    }
    void ConvertRawDataToEvents(
        std::unordered_map<uint32_t, std::vector<uint32_t>> &events_map,
        const std::vector<uint8_t> &valid_lengths);
    void PrintSipProfilingInfo();
    void PrintPmcCounters(uint32_t index, const std::vector<uint64_t> &counters);
    std::vector<uint64_t> ConvertRawDataToFormatedData(
        const uint8_t *data, const std::vector<uint8_t> &len);
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_LIBRA_PROFILING_PARSER_LIBRA_H_
