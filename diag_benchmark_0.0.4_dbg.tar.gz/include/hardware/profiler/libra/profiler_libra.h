/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_LIBRA_PROFILER_LIBRA_H_
#define HARDWARE_PROFILER_LIBRA_PROFILER_LIBRA_H_

#include <memory>
#include <vector>

#include "hardware/include/profiler/profiler.h"

namespace efvf {
namespace hardware {
namespace profiler {

//!
//! Three ring buffer in Libra DPF
//! Ring 0-15: dispatched trace ring
//! Ring 16: undispatched trace ring
//! Ring 17: log buffer ring(not implemented)
//! ring 18: profile ring
//!
static const uint32_t kLibraDispatchedTraceRingNnum  = 16;
static const uint32_t kLibraUndispatchedTraceRingIdx = 16;
static const uint32_t kLibraLogBufRingIdx            = 17;
static const uint32_t kLibraProfileRingIdx           = 18;
static const uint32_t kLibraDpfTotalRingNum          = 19;

class ProfilerLibra : public Profiler {
 public:
    explicit ProfilerLibra(std::shared_ptr<spdlog::logger> logger);
    virtual ~ProfilerLibra() = default;

    ProfilerRing *profiling_ring() override {
        return rings_[kLibraProfileRingIdx].get();
    }
    ProfilerRing *event_ring(uint8_t ring_id) override {
        if (ring_id > kLibraUndispatchedTraceRingIdx) {
            LOG_ERROR("Invalid event ring id {}, valid range [0, 16]", ring_id);
            return nullptr;
        }
        return rings_[ring_id].get();
    }
    ProfilerRing *log_buffer_ring() override {
        return rings_[kLibraLogBufRingIdx].get();
    }

    bool CheckRasStatus() override;

    void ShowStatus() override;

    void StartInterruptHandler() override;
    void StopInterruptHandler() override;
    void HandleInterrupt() override;
    void SetUnDispatchInitId(const std::vector<uint16_t> &init_ids) override;

    void StartSramParityInjection(uint16_t count) override;
    void StopSramParityInjection() override;

 private:
    bool HwInit() override;

 private:
    void ClearStatus();
    void HandleNormalInterrupts();
    void HandleExceptionInterrupts();
};

class ProfilerRingLibra : public ProfilerRing {
 public:
    explicit ProfilerRingLibra(ProfilerLibra *profiler, uint8_t ring_id);
    virtual ~ProfilerRingLibra() = default;

    uint32_t GetCauseAddr() override;

    void MaskAllMaster() override;
    void UnmaskAllMaster() override;

    // DO NOT USE it
    // it is added for error injection
    void set_vf_id(uint8_t vf_id_new) {
        vf_id_ = vf_id_new;
    }

 private:
    void SetupHW(const RingCfg &cfg) override;
    void StartHW() override;
    void StopHW() override;
    void GetProducerStatus(uint32_t &wptr, bool &wwrap) override;
    void Move(uint64_t ring_offset, uint64_t buf_offset, uint64_t size) override;
    void Update(const uint32_t &rptr, const bool &rwrap) override;
    void FlushFifo() override;
    bool IsDfOngoing();

 private:
    uint16_t process_id_ = 0;
    uint8_t  vf_id_      = 0;
    uint8_t  asid_       = 0;

 private:
    static std::mutex mtx_;
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_LIBRA_PROFILER_LIBRA_H_
