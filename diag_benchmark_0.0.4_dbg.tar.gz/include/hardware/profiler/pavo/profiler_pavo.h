/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_PROFILER_PAVO_PROFILER_PAVO_H_
#define HARDWARE_PROFILER_PAVO_PROFILER_PAVO_H_

#include <memory>

#include "hardware/include/profiler/profiler.h"

namespace efvf {
namespace hardware {
namespace profiler {

class ProfilerPavo : public Profiler {
    //!
    //! Only one ring buffer for Pavo DPF
    //!
    static const uint32_t PAVO_DPF_RING_NUM = 1;

 public:
    explicit ProfilerPavo(std::shared_ptr<spdlog::logger> logger);
    virtual ~ProfilerPavo() = default;
};

class ProfilerRingPavo : public ProfilerRing {
 public:
    explicit ProfilerRingPavo(ProfilerPavo *profiler);
    virtual ~ProfilerRingPavo() = default;

    void FlushFifo() override;

 private:
    void SetupHW(const RingCfg &cfg) override;
    void StartHW() override;
    void StopHW() override;
    void GetProducerStatus(uint32_t &wptr, bool &wwrap) override;
    void Move(uint64_t ring_offset, uint64_t buf_offset, uint64_t size) override;
    void Update(const uint32_t &rptr, const bool &rwrap) override;
    bool IsDfOngoing();
};

}  // namespace profiler
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_PROFILER_PAVO_PROFILER_PAVO_H_
