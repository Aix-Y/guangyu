/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_SCORPIO_CDTE_GDTE_H_
#define HARDWARE_GDTE_SCORPIO_CDTE_GDTE_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "hardware/gdte/scorpio/cdte/gdte_vc.h"
#include "hardware/gdte/scorpio/gdte.h"

namespace efvf {
namespace hardware {
namespace gdte {
class CdteScorpio : public GdteScorpio {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit CdteScorpio(std::shared_ptr<spdlog::logger> logger) : GdteScorpio(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~CdteScorpio() {}

    /**
     * @brief      Gets the vc status.
     *
     * @param      status  The status
     */
    virtual void GetVcStatus(std::vector<int> &status);

    /**
     * @brief      Gets the debug position.
     *
     * @return     The debug position.
     */
    virtual uint32_t GetDbgPos();

    /**
     * @brief      Gets the eng name.
     *
     * @return     The eng name.
     */
    virtual std::string GetEngName() {
        return "cdte";
    }

    /**
     * @brief      { function_description }
     */
    virtual bool WaitEngineIdle(int timeout);

    /**
     * @brief      Gets the clock m hz.
     *
     * @return     The clock m hz.
     */
    virtual uint64_t GetClkMHz();

    /**
     * @brief      Gets the thread mask.
     *
     * @return     The thread mask.
     */
    virtual uint32_t GetThreadMask();

    /**
     * @brief      Determines if engine busy.
     *
     * @return     True if engine busy, False otherwise.
     */
    virtual bool IsEngineBusy();

    /**
     * @brief      Determines if stop.
     *
     * @return     True if stop, False otherwise.
     */
    virtual bool IsEngineStop();

    /**
     * @brief      Determines if optimize en.
     *
     * @return     True if optimize en, False otherwise.
     */
    virtual bool IsOptimizeEn();

    /**
     * @brief      Determines if partial write en.
     *
     * @return     True if partial write en, False otherwise.
     */
    virtual bool IsPartialWriteEn();

    /**
     * @brief      Determines if write combine en.
     *
     * @return     True if write combine en, False otherwise.
     */
    virtual bool IsWriteCombineEn();

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  bl_list  {RPORT, WPORT}
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetBL(const DteBurstLen &bl);

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  burstlen  The burstlen
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetBL(uint32_t burstlen);

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  burstlen  The burstlen
     *
     * @return     { description_of_the_return_value }
     */
    virtual void SetMaxBL();

    /**
     * @brief      Gets the bl.
     *
     * @return     The bl.
     */
    virtual DteBurstLen GetBL();

    /**
     * @brief      Sets the debug misc.
     *
     * @param[in]  cfg   The new value
     *
     * @return     { description_of_the_return_value }
     */
    virtual void SetDbgMisc(const DebugMiscCfg &cfg);

    /**
     * @brief      Sets the reorder.
     *
     * @param[in]  status  The status
     */
    virtual void SetReorder(bool status);

    /**
     * @brief      Gets the sa.
     *
     * @return     The sa.
     */
    virtual SystemAdapter *GetSa();

    /**
     * @brief      Gets the bpm number.
     *
     * @return     The bpm number.
     */
    virtual uint32_t GetPortNum() {
        return 4;
    }

    /**
     * @brief      Gets the bpm.
     *
     * @param[in]  index  The index
     *
     * @return     The bpm.
     */
    virtual Bpm *GetBpm(int index);

    /**
     * @brief      Gets the bpm w thro.
     *
     * @param[in]  idex  The idex
     * @param      res   The resource
     */
    virtual void GetBpmResult(int index, BpmResult *res);

    /**
     * @brief      Gets the dvfs.
     *
     * @param[in]  index  The index
     *
     * @return     The dvfs.
     */
    virtual Pmc *GetDvfs(int index);

    /**
     * @brief      Gets the performance pmc.
     *
     * @return     The performance pmc.
     */
    virtual Pmc *GetPerfPmc();

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStart();

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStop();

    /**
     * @brief      Gets the busy cycle.
     */
    virtual uint64_t GetBusyCycle();

    /**
     * @brief Get the Busy Rate
     *
     * @return double
     */
    virtual double GetBusyRate();

    /**
     * @brief      { function_description }
     */
    virtual void DvfsPmcStart();

    /**
     * @brief      { function_description }
     */
    virtual void DvfsPmcStop();

    /**
     * @brief      Gets the dvfs result.
     *
     * @param      result  The result
     */
    virtual void GetDvfsResult(DvfsResult &result);

    /**
     * @brief      { function_description }
     */
    virtual void EnClkGate();

    /**
     * @brief      Enables the bpm.
     */
    virtual void EnableBpm(uint64_t cycle);

    /**
     * @brief      Prints a bpm status.
     */
    virtual void PrintBpmStatus();

    /**
     * @brief      { function_description }
     */
    virtual void EnCrc(uint32_t port, int vc);

    /**
     * @brief      Gets the crc value.
     *
     * @return     The crc value.
     */
    virtual uint32_t GetCrcVal();

    /**
     * @brief      Calc data crc value.
     *
     * @param[in]  src_addr     The src buffer address
     * @param[in]  dst_addr     The dst buffer address
     * @param[in]  size         Calc crc data size
     * @param[in]  timeout      timeout value
     * @return     The crc value.
     */
    virtual uint32_t CalcDataCrc(
        uint64_t src_addr, uint64_t dst_addr, uint64_t size, int timeout);

    /**
     * @brief      Sets the throttle.
     *
     * @param[in]  window  The window
     * @param[in]  rd_bw   The rd bd
     * @param[in]  wr_bw   The wr bd
     * @param[in]  rd_os   The rd operating system
     * @param[in]  wr_os   The wr operating system
     * @param[in]  percent  The percent
     */
    virtual void SetThrottle(
        uint32_t window, uint32_t rd_bw, uint32_t wr_bw, uint32_t rd_os, uint32_t wr_os);

    /**
     * @brief      Sets the port throttle.
     *
     * @param[in]  port    The port
     * @param[in]  window  The window
     * @param[in]  rd_bw   The rd bd
     * @param[in]  wr_bw   The wr bd
     * @param[in]  rd_os   The rd operating system
     * @param[in]  wr_os   The wr operating system
     */
    virtual void SetPortThrottle(int port, uint32_t window, uint32_t rd_bw, uint32_t wr_bw,
        uint32_t rd_os, uint32_t wr_os);

    /**
     * @brief      Sets the hsdc minimum scp.
     *
     * @param[in]  gid   The new value
     * @param[in]  val   The new value
     */
    virtual void SetHsdcMinScp(uint32_t gid, uint32_t val);

    /**
     * @brief      Sets the hsdc maximum scp.
     *
     * @param[in]  gid   The new value
     * @param[in]  val   The new value
     */
    virtual void SetHsdcMaxScp(uint32_t gid, uint32_t val);

    /**
     * @brief      Sets the hsdc minimum gscp.
     *
     * @param[in]  gid   The new value
     * @param[in]  val   The new value
     */
    virtual void SetHsdcMinGscp(uint32_t gid, uint32_t val);

    /**
     * @brief      Sets the hsdc maximum gscp.
     *
     * @param[in]  gid   The new value
     * @param[in]  val   The new value
     */
    virtual void SetHsdcMaxGscp(uint32_t gid, uint32_t val);

    /**
     * @brief      Sets the hsdc minimum gscpc.
     *
     * @param[in]  gid   The new value
     * @param[in]  val   The new value
     */
    virtual void SetHsdcMinGscpc(uint32_t gid, uint32_t val);

    /**
     * @brief      Sets the wr combine.
     *
     * @param[in]  status    The status
     * @param[in]  wait_num  The wait number
     */
    virtual void SetWrCombine(uint32_t status, uint32_t wait_num);

    /**
     * @brief      Sets the partial wr.
     *
     * @param[in]  val   The new value 0 or 1
     */
    virtual void SetPartialWr(uint32_t val);

    /**
     * @brief      DTE time out threshold value; unit is 128 DTE clock cycles.
     *
     * @param[in]  val   The new value
     */
    virtual void SetTimeout(uint32_t val);

    /**
     * @brief      Sets the error stop.
     *
     * @param[in]  val   The new value
     */
    virtual void SetErrStop(uint32_t val);

    /**
     * @brief      Sets the software stop.
     *
     * @param[in]  val   The new value
     */
    virtual void SetSwStop(uint32_t val, uint32_t stop_sig);

    /**
     * @brief      Sets the invld vc clr mbx en.
     *
     * @param[in]  status  The status
     */
    virtual void SetInvldVcClrMbxEn(uint32_t status);

    /**
     * @brief      Sets the ih cause address.
     *
     * @param[in]  addr  The address
     */
    virtual void SetIhCauseAddr(uint32_t addr);

    /**
     * @brief      Sets the data sram parity error.
     *
     * @param[in]  status  The status
     */
    virtual void SetDataSramParityErr(bool status);

    /**
     * @brief      { function_description }
     */
    virtual void SetRegSramParityErr(bool status);

    /**
     * @brief      Sets the hit ratio.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetHitRatio(const HitRatioCfg &cfg);

    /**
     * @brief      Sets the order list pri.
     *
     * @param[in]  status  The status
     */
    virtual void SetOrderListPri(int status);

    /**
     * @brief      Gets the eng control address.
     */
    virtual uint64_t GetEngCtrlAddr();

    /**
     * @brief      Gets the eng control value.
     */
    virtual uint32_t GetEngCtrlVal();

    /**
     * @brief      Gets the timeout control address.
     *
     * @return     The timeout control address.
     */
    virtual uint64_t GetTimeoutCtrlAddr();

    /**
     * @brief      Shows the operation description.
     */
    virtual void ShowOpDesc();

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint64_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void RegWrite(uint64_t addr, uint32_t val);

 private:
    std::mutex mutex_;

 private:
    /**
     * @brief      { function_description }
     */
    virtual void LibInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInitMini();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit();
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_SCORPIO_CDTE_GDTE_H_
