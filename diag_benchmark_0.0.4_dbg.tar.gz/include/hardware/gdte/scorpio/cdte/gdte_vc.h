/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_SCORPIO_CDTE_GDTE_VC_H_
#define HARDWARE_GDTE_SCORPIO_CDTE_GDTE_VC_H_

#include <memory>
#include <string>
#include <vector>
#include "framework/include/log.h"
#include "hardware/gdte/scorpio/gdte_vc.h"
#include "hardware/include/gdte/gdte_ctx.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace gdte {
class CdteVcScorpio : public GdteVcScorpio {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  vc      { parameter_description }
     * @param      dte     The dte
     * @param[in]  logger  The logger
     */
    CdteVcScorpio(int vc, Hardware *dte, std::shared_ptr<spdlog::logger> logger)
        : GdteVcScorpio(vc, dte, logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~CdteVcScorpio() {}

    /**
     * @brief      Initializes the register handle.
     */
    virtual void InitRegHandle() {
        direct_reg_ = dte_->Get("CDTE_VC_DIRECT_REGS", vc_);
        sram_reg_   = dte_->Get("CDTE_VC_SRAM_REGS", vc_);
    }

    /**
     * @brief      set cmd pkt
     *
     * @param[in]  ctx   The new value
     */
    virtual void SetCmdPkt(const DteVcCtx &ctx);

    /**
     * @brief      set trigger
     */
    virtual void Trigger();

    /**
     * @brief      { function_description }
     */
    virtual void Invalidate();

    /**
     * @brief      check vc busy
     *
     * @return     True if busy, False otherwise.
     */
    virtual bool IsBusy();

    /**
     * @brief      check vc occupy
     *
     * @return     True if occupy, False otherwise.
     */
    virtual bool IsOccupy();

    /**
     * @brief      Gets the operation type.
     *
     * @return     The operation type.
     */
    virtual uint32_t GetOpType();

    /**
     * @brief      Sets the signal.
     *
     * @param[in]  addr  The address
     * @param[in]  data  The data
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetSignalSrc(uint32_t addr, uint32_t data);

    /**
     * @brief      Sets the signal sts.
     *
     * @param[in]  type  The type
     * @param[in]  sts   The new value
     */
    virtual void SetSignalSts(const std::string &type, int sts);

    /**
     * @brief      Gets the trigger address.
     *
     * @return     The trigger address.
     */
    virtual uint32_t GetTriggerAddr();

    /**
     * @brief      direct reg access
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t DirectRegRead(uint32_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void DirectRegWrite(uint32_t addr, uint32_t val);

    /**
     * @brief      op access
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t SramRegRead(uint32_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void SramRegWrite(uint32_t addr, uint32_t val);

    /**
     * @brief      Dumps a vc information.
     *
     * @param      data  The data
     */
    virtual std::vector<std::string> DumpVcInfo();

 private:
    /**
     * @brief      { function_description }
     *
     * @param[in]  ctx   The context
     */
    virtual void CacheCfg(const DteVcCtx &ctx);

    /**
     * \brief
     */
    virtual void SelCmdCtrl(const DteVcCtx &ctx);

    /**
     * @brief      Sets the expand packet.
     *
     * @param[in]  ctx   The new value
     */
    virtual void SetExpandPkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the expand packet.
     *
     * @param[in]  ctx   The new value
     */
    virtual void SetL2loss(const DteVcCtx &ctx) {}

    /**
     * \brief
     */
    void SelSrcAddr(const uint64_t &src_df_addr);

    /**
     * \brief
     */
    void SelSrcSize(const uint32_t &src_size);

    /**
     * \brief
     */
    void SelDstAddr(const uint64_t &dest_df_addr);

    /**
     * \brief
     */
    void SelMailBox(const uint32_t &val);

    /**
     * \brief
     */
    void SetPaddingPkt(const DteVcCtx &ctx);

    /**
     * \brief
     */
    void SetReshapePkt(const DteVcCtx &ctx);

    /**
     * \brief
     */
    void SetBrdcstPkt(const DteVcCtx &ctx);

    /**
     * \brief
     */
    void SetSlicePkt(const DteVcCtx &ctx);

    /**
     * \brief
     */
    void SetDeslicePkt(const DteVcCtx &ctx);

    /**
     * \brief
     */
    void SetSubSamplePkt(const DteVcCtx &ctx);

    /**
     * \brief
     */
    void SetHMirrorPkt(const DteVcCtx &ctx);

    /**
     * \brief
     */
    void SetVMirrorPkt(const DteVcCtx &ctx);

    /**
     * \brief
     */
    void SetSlicePadPkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the slice deslice.
     *
     * @param[in]  ctx   The new value
     */
    void SetSliceDeslicePkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the slice expand.
     *
     * @param[in]  ctx   The new value
     */
    void SetSliceExpandPkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the hsdc.
     *
     * @param[in]  ctx   The new value
     */
    void SetHsdcPkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the h mirror deslice packet.
     *
     * @param[in]  ctx   The new value
     */
    void SetHMirrorDeslicePkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the v mirror deslice packet.
     *
     * @param[in]  ctx   The new value
     */
    void SetVMirrorDeslicePkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the h mirror pad packet.
     *
     * @param[in]  ctx   The new value
     */
    void SetHMirrorPadPkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the v mirror pad packet.
     *
     * @param[in]  ctx   The new value
     */
    void SetVMirrorPadPkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the constant fill deslice packet.
     *
     * @param[in]  ctx   The new value
     */
    void SetConstFillDeslicePkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the slice reshape packet.
     *
     * @param[in]  ctx   The new value
     */
    void SetSliceReshapePkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the reshape deslice packet.
     *
     * @param[in]  ctx   The new value
     */
    void SetReshapeDeslicePkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the shrink deslice packet.
     *
     * @param[in]  ctx   The new value
     */
    void SetShrinkDeslicePkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the global synchronize packet.
     *
     * @param[in]  ctx   The new value
     */
    void SetGSyncPkt(const DteVcCtx &ctx);

    /**
     * @brief      { function_description }
     *
     * @param[in]  ctx   The context
     */
    void SetSliceBrdcstPkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the shrink packet.
     *
     * @param[in]  ctx   The new value
     */
    void SetShrinkPkt(const DteVcCtx &ctx);

    /**
     * @brief      Sets the vc control.
     *
     * @param[in]  ctx   The new value
     */
    virtual void SetVcCtrl(const DteVcCtx &ctx);

    /**
     * @brief      Sets the qos control.
     *
     * @param[in]  ctx   The new value
     */
    void SetQosCtrl(const DteVcCtx &ctx);

    /**
     * @brief      Gets the expand packet.
     */
    std::string GetExpandPkt();

    /**
     * @brief      Gets the shrink packet.
     *
     * @return     The shrink packet.
     */
    std::string GetShrinkPkt();

    /**
     * @brief      Gets the constant fill packet.
     *
     * @return     The constant fill packet.
     */
    std::string GetConstFillPkt();

    /**
     * @brief      Gets the padding packet.
     *
     * @return     The padding packet.
     */
    std::string GetPaddingPkt();

    /**
     * @brief      Gets the reshape packet.
     *
     * @return     The reshape packet.
     */
    std::string GetReshapePkt();

    /**
     * @brief      Gets the brdcst packet.
     *
     * @return     The brdcst packet.
     */
    std::string GetBrdcstPkt();

    /**
     * @brief      Gets the slice packet.
     *
     * @return     The slice packet.
     */
    std::string GetSlicePkt();

    /**
     * @brief      Gets the deslice packet.
     *
     * @return     The deslice packet.
     */
    std::string GetDeslicePkt();

    /**
     * @brief      Gets the sub sample packet.
     *
     * @return     The sub sample packet.
     */
    std::string GetSubSamplePkt();

    /**
     * @brief      Gets the h mirror packet.
     *
     * @return     The h mirror packet.
     */
    std::string GetHMirrorPkt();

    /**
     * @brief      Gets the v mirror packet.
     *
     * @return     The v mirror packet.
     */
    std::string GetVMirrorPkt();

    /**
     * @brief      Gets the slice pad packet.
     *
     * @return     The slice pad packet.
     */
    std::string GetSlicePadPkt();

    /**
     * @brief      Gets the slice pad packet.
     *
     * @return     The slice pad packet.
     */
    std::string GetSliceDeslicePkt();

    /**
     * @brief      Gets the slice expand packet.
     *
     * @return     The slice expand packet.
     */
    std::string GetSliceExpandPkt();

    /**
     * @brief      Gets the h mirror deslice packet.
     *
     * @return     The h mirror deslice packet.
     */
    std::string GetHMirrorDeslicePkt();

    /**
     * @brief      Gets the v mirror deslice packet.
     *
     * @return     The v mirror deslice packet.
     */
    std::string GetVMirrorDeslicePkt();

    /**
     * @brief      Gets the h mirror pad packet.
     *
     * @return     The h mirror pad packet.
     */
    std::string GetHMirrorPadPkt();

    /**
     * @brief      Gets the v mirror pad packet.
     *
     * @return     The v mirror pad packet.
     */
    std::string GetVMirrorPadPkt();

    /**
     * @brief      Gets the constant fill deslice packet.
     *
     * @return     The constant fill deslice packet.
     */
    std::string GetConstFillDeslicePkt();

    /**
     * @brief      Gets the slice reshape packet.
     *
     * @return     The slice reshape packet.
     */
    std::string GetSliceReshapePkt();

    /**
     * @brief      Gets the reshape deslice packet.
     *
     * @return     The reshape deslice packet.
     */
    std::string GetReshapeDeslicePkt();

    /**
     * @brief      Gets the shrink deslice packet.
     *
     * @return     The shrink deslice packet.
     */
    std::string GetShrinkDeslicePkt();

    /**
     * @brief      Gets the slice brdcst packet.
     *
     * @return     The slice brdcst packet.
     */
    std::string GetSliceBrdcstPkt();
};

class CdteVcVfScorpio : public CdteVcScorpio {
 public:
    CdteVcVfScorpio(int vc, Hardware *dte, std::shared_ptr<spdlog::logger> logger)
        : CdteVcScorpio(vc, dte, logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~CdteVcVfScorpio() {}

 private:
    /**
     * @brief      Sets the vc control.
     *
     * @param[in]  ctx   The new value
     */
    virtual void SetVcCtrl(const DteVcCtx &ctx);
};
}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_SCORPIO_CDTE_GDTE_VC_H_
