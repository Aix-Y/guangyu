/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_SCORPIO_GDTE_H_
#define HARDWARE_GDTE_SCORPIO_GDTE_H_

#include <memory>
#include <set>
#include <string>
#include <vector>
#include "hardware/gdte/scorpio/gdte_vc.h"
#include "hardware/include/gdte/gdte.h"
#include "hardware/mailbox/mailbox_scorpio.h"
#include "hardware/mailbox/mailbox_scorpio_vf.h"

using efvf::hardware::mailbox::MailboxScorpio;
using efvf::hardware::mailbox::MailboxScorpioParam;
using efvf::hardware::mailbox::MailboxScorpioVf;

namespace efvf {
namespace hardware {
namespace gdte {

class GdteScorpio : public Gdte {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit GdteScorpio(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      Destroys the object.
     */
    virtual ~GdteScorpio() {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  src_df_addr   The source df address
     * @param[in]  dest_df_addr  The destination df address
     * @param[in]  size          The size
     * @param[in]  offset        The offset
     * @param[in]  vc            { parameter_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool LinearCopy(const uint64_t &src_df_addr, const uint64_t &dest_df_addr,
        const uint32_t &size, const uint64_t &offset = 0, const int &vc = 0);

    /**
     * @brief      { function_description }
     *
     * @param[in]  src_df_addr   The source df address
     * @param[in]  dest_df_addr  The destination df address
     * @param[in]  src_off       The source off
     * @param[in]  dst_off       The destination off
     * @param[in]  size          The size
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool Copy(const uint64_t &src_df_addr, const uint64_t &dest_df_addr,
        uint64_t src_off = 0, uint64_t dst_off = 0, uint64_t size = 0, int timeout = 1000);

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  src_off  The source off
     * @param[in]  dst_off  The destination off
     * @param[in]  size     The size
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool Copy(Mem *src, Mem *dst, uint64_t src_off = 0, uint64_t dst_off = 0,
        uint64_t size = 0, int timeout = 1000);

    /**
     * @brief      { function_description }
     *
     * @param      dst      The destination
     * @param[in]  pattern  The pattern
     * @param[in]  off      Off
     * @param[in]  size     The size
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FillConst(
        Mem *dst, uint32_t pattern, uint64_t off = 0, uint64_t size = 0, int timeout = 1000);

    /**
     * @brief      { function_description }
     *
     * @param      buf_addr The destination buffer address
     * @param      buf_size The destination buffer size
     * @param[in]  pattern  The pattern
     * @param[in]  off      Off
     * @param[in]  size     The size
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool FillConst(uint64_t buf_addr, uint64_t buf_size, uint32_t pattern,
        uint64_t off = 0, uint64_t size = 0, int timeout = 1000);

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  src_off  The source off
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool Slice(Mem *src, Mem *dst, const std::vector<uint64_t> &src_off, int timeout);

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  src_off  The source off
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool Slice(const uint64_t &src, const uint64_t &dst,
        const std::vector<uint32_t> &src_dim, const std::vector<uint32_t> &dst_dim,
        const std::vector<uint32_t> &offset, uint32_t bpe, int timeout);

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  dst_off  The destination off
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool DeSlice(
        Mem *src, Mem *dst, const std::vector<uint64_t> &dst_off, int timeout);

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  dst_off  The destination off
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool DeSlice(const uint64_t &src, const uint64_t &dst,
        const std::vector<uint32_t> &src_dim, const std::vector<uint32_t> &dst_dim,
        const std::vector<uint32_t> &offset, uint32_t bpe, int timeout);

    /**
     * @brief      { function_description }
     *
     * @param      src      The source
     * @param      dst      The destination
     * @param[in]  dst_off  The destination off
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SliceDeSlice(const uint64_t &src, const uint64_t &dst,
        const std::vector<uint32_t> &src_dim, const std::vector<uint32_t> &dst_dim,
        const std::vector<uint32_t> &src_off, const std::vector<uint32_t> &dst_off,
        const std::vector<uint32_t> &size, uint32_t bpe, int timeout);

    /**
     * @brief      set one cmd pkt to vc
     *
     * @param[in]  ctx   The new value
     * @param[in]  vc    The new value
     */
    virtual void SetCmdPkt(const DteVcCtx &ctx, int vc = 0);

    /**
     * @brief      Gets the l 2 loss status.
     *
     * @param      ctx   The context
     * @param[in]  vc    { parameter_description }
     */
    virtual void GetL2LossStatus(DteVcCtx *ctx, int vc);

    /**
     * @brief      generate one valid vc cmd pkt config
     *
     * @param      ctx   The context
     */
    virtual void FillCmdPkt(DteVcCtx *ctx);

    /**
     * @brief      launch vc
     *
     * @param[in]  vc    { parameter_description }
     */
    virtual void Trigger(int vc, DteVcCtx *ctx = nullptr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  vc    { parameter_description }
     */
    virtual void Invalidate(int vc = 0);

    /**
     * @brief      check vc busy
     *
     * @param[in]  vc    { parameter_description }
     *
     * @return     True if the specified vc is vc busy, False otherwise.
     */
    virtual bool IsVcBusy(int vc = 0);

    /**
     * @brief      check vc occupy
     *
     * @param[in]  vc    { parameter_description }
     *
     * @return     True if the specified vc is vc occupy, False otherwise.
     */
    virtual bool IsVcOccupy(int vc = 0);

    /**
     * @brief      { function_description }
     *
     * @param[in]  vc       { parameter_description }
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitVcIdle(int vc, uint64_t timeout = 10000, DteVcCtx *ctx = nullptr,
        bool expect_timeout = false);

    virtual bool WaitVcIdleNonBlock(int vc, int timeout);

    /**
     * @brief      { function_description }
     *
     * @param[in]  vc       { parameter_description }
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitVcOccupy(int vc = 0, int timeout = 10000);

    /**
     * @brief      Gets the vc sram register address.
     *
     * @param[in]  vc     { parameter_description }
     * @param[in]  index  The index
     *
     * @return     The vc sram register address.
     */
    virtual uint64_t GetVcSramRegAddr(int vc, uint32_t index);

    /**
     * @brief      Dumps a vc information.
     *
     * @return     { description_of_the_return_value }
     */
    virtual void DumpVcInfo(bool only_abnormal);
    virtual void DumpOneVcInfo(int vc);

    /**
     * @brief      { function_description }
     */
    virtual void Snapshot();

    /**
     * @brief      Gets the vc configuration for django.
     *
     * @param[in]  ctx   The context
     */
    virtual std::string GetVcCfgForDjango(const DteVcCtx &ctx);

    /**
     * @brief      Sets the signal.
     *
     * @param[in]  addr  The address
     * @param[in]  data  The data
     * @param[in]  vc    The new value
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetSignalSrc(uint32_t addr, uint32_t data, int vc);

    /**
     * @brief      Sets the signal sts.
     *
     * @param[in]  type  The type
     * @param[in]  sts   The new value
     * @param[in]  vc    The new value
     */
    virtual void SetSignalSts(const std::string &type, int sts, int vc);

    /**
     * \brief wait engine idle
     */
    virtual bool WaitEngineIdle(int timeout) {
        return false;
    }

    /**
     * @brief      Gets the operation type by string.
     *
     * @param[in]  type_string  The type string
     *
     * @return     The operation type by string.
     */
    virtual DteOpType GetOpTypeByStr(const std::string &type_string);

    /**
     * @brief      Gets the operation.
     *
     * @return     The operation.
     */
    virtual DteOpType GetOp();

    /**
     * @brief      Gets the operation by iterator.
     *
     * @return     The operation by iterator.
     */
    virtual DteOpType GetOpByIter();

    /**
     * @brief      Sets the operation iterator random.
     */
    virtual void SetOpIterRand();

    /**
     * @brief      Gets the operation type.
     *
     * @param[in]  vc    { parameter_description }
     *
     * @return     The operation type.
     */
    virtual uint32_t GetOpType(int vc);

    /**
     * @brief      Gets the aliable vc.
     *
     * @return     The aliable vc.
     */
    virtual int GetAvaliableVc();

    /**
     * @brief      Gets the avaliable vc from last.
     *
     * @return     The avaliable vc from last.
     */
    virtual int GetAvaliableVcFromLast();

    /**
     * @brief      Gets the vc randomly.
     *
     * @return     The vc randomly.
     */
    virtual int GetVcRandomly();

    /**
     * @brief      Gets the maximum bl.
     *
     * @return     The maximum bl.
     */
    virtual uint32_t GetMaxBL() {
        return max_burst_;
    }

    /**
     * @brief      return vc number for a dte
     *
     * @return     The vc number.
     */
    virtual uint32_t get_vc_num() {
        return vc_num_;
    }

    /**
     * @brief      return vaild dir list for a dte
     *
     * @return     The valid dir.
     */
    virtual const std::set<std::string> &get_valid_dir() {
        return valid_dir_;
    }

    /**
     * @brief      Gets the dir.
     *
     * @return     The dir.
     */
    virtual std::string GetDir();

    /**
     * @brief      Gets the valid operation.
     *
     * @return     The valid operation.
     */
    virtual const std::set<DteOpType> &get_valid_op() {
        return valid_op_;
    }

    /**
     * @brief      Gets the mail box.
     *
     * @return     The mail box.
     */
    virtual Mailbox *GetMailBox() {
        return mbx_.get();
    }

    /**
     * @brief      Gets the mbx entry.
     *
     * @return     The mbx entry.
     */
    virtual inline int GetMbxEntry() {
        int tmp = mbx_entry_no_++;
        LOG_ASSERT(mbx_entry_no_ < mbx_entry_max_, "mbx entry exhaustion");
        return tmp;
    }

    /**
     * @brief      Gets the vc trigger address.
     *
     * @param[in]  vc    { parameter_description }
     *
     * @return     The vc trigger address.
     */
    virtual uint32_t GetVcTriggerAddr(int vc);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void CalcDataTransformByCmodel(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param[in]  p     { parameter_description }
     *
     * @return     The hsdc data.
     */
    virtual void GenHsdcData(HsdcPkt &p);

 private:
    /**
     * \brief
     */
    void FillLinearCopyParam(DteVcCtx *ctx);

    /**
     * \brief
     * DTE data expand phase:
     * 0: phase 0, stuff low bits with src element.
     * 1: phase 1, stuff high bits with src element.
     * 2: phase 2.
     * 3: phase 3.
     * DTE data expand ratio:
     * 2’d0: source data size 2x.
     * 2’d1: source data size 4x.
     * 2’d2: source data size expand from 3 to 4. (this case will be used for dim0 padding from
     *       3 to 4 HW accelerate)
     */
    virtual void FillExpandParam(DteVcCtx *ctx);

    /**
     * \brief
     * DTE data shrink phase:
     * 0: phase 0, select low bits ;for bpe4 shrink to bpe1, select byte 0; for bpe8 to bpe4,
     *    select byte0/1/2/3.
     * 1: phase 1, select high bits;for bpe4 shrink to bpe1, select byte 1;
     *    for bpe8 to bpe4, select byte4/5/6/7.
     * 2: phase 2, for bpe4 shrink to bpe1 only, select byte 2.
     * 3: phase 3, for bpe4 shrink to bpe1 only, select byte 3
     * DTE data shrink ratio:
     * 2’d0: source data size x 1/2.
     * 2’d1: source data size x 1/4.
     * 2’d2: source data size x 3/4（EF32 bit to 24bit）
     * 2’d3: source data size x 1/2.BPE8 to BPE4
     */
    virtual void FillShrinkParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillConstantParam(DteVcCtx *ctx);

    /**
     * \brief
     */
    void FillPaddingParam(DteVcCtx *ctx);

    /**
     * \brief
     */
    void FillReshapeParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void FillBrdcstParam(DteVcCtx *ctx);

    /**
     * \brief
     */
    void FillSliceParam(DteVcCtx *ctx);

    /**
     * \brief
     */
    void FillDesliceParam(DteVcCtx *ctx);

    /**
     * \brief
     */
    void FillSubSampleParam(DteVcCtx *ctx);

    /**
     * \brief
     */
    void FillHMirrorParam(DteVcCtx *ctx);

    /**
     * \brief
     */
    void FillVMirrorParam(DteVcCtx *ctx);

    /**
     * \brief
     */
    void FillSlicePadParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillSliceDeSliceParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void FillSliceExpandParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillHsdcParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillHMirDslParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillVMirDslParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillHMirPadParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillVMirPadParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillCFDslParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillSlcRshpParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillRshpDlsParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void FillShkDlsParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    void FillSlcBrdcstParam(DteVcCtx *ctx);

    /**
     * \brief
     */
    void FillRequestMem(DteVcCtx *ctx);

 protected:
    /**
     * @brief      total 4G - 1
     *
     * @param      dims    The dims
     * @param[in]  limits  The limits
     */
    void GenValidDimsSize(
        std::vector<uint64_t> &dims, uint32_t total_size, uint32_t dim_limits = 0x7FF);

    int                   vc_num_    = 0;
    uint32_t              max_burst_ = 0;
    Hardware *            com_reg_   = nullptr;
    std::set<std::string> valid_dir_;
    std::set<DteOpType>   valid_op_;

    int mbx_entry_no_  = 0;
    int mbx_entry_max_ = 0;

    std::vector<std::shared_ptr<GdteVcScorpio>> vc_instances_;

    std::vector<bool> vc_status_;

    std::shared_ptr<MailboxScorpio> mbx_;

    int op_iterator_ = 0;
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_SCORPIO_GDTE_H_
