/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_SCORPIO_SDTE_GDTE_VF_H_
#define HARDWARE_GDTE_SCORPIO_SDTE_GDTE_VF_H_

#include <memory>
#include <set>
#include <string>
#include "hardware/gdte/scorpio/sdte/gdte.h"
#include "hardware/gdte/scorpio/sdte/gdte_vc.h"

namespace efvf {
namespace hardware {
namespace gdte {
class SdteVfScorpio : public SdteScorpio {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit SdteVfScorpio(std::shared_ptr<spdlog::logger> logger) : SdteScorpio(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~SdteVfScorpio() {}
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_SCORPIO_SDTE_GDTE_VF_H_
