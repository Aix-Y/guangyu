/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_SCORPIO_ODTE_GDTE_H_
#define HARDWARE_GDTE_SCORPIO_ODTE_GDTE_H_

#include <memory>
#include <set>
#include <string>
#include "hardware/gdte/scorpio/cdte/gdte.h"
#include "hardware/gdte/scorpio/odte/gdte_vc.h"

namespace efvf {
namespace hardware {
namespace gdte {
class OdteScorpio : public CdteScorpio {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit OdteScorpio(std::shared_ptr<spdlog::logger> logger) : CdteScorpio(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~OdteScorpio() {}

    /**
     * @brief      Determines if optimize en.
     *
     * @return     True if optimize en, False otherwise.
     */
    virtual bool IsOptimizeEn();

    /**
     * @brief      Gets the debug position.
     *
     * @return     The debug position.
     */
    virtual uint32_t GetDbgPos();

    /**
     * @brief      Gets the eng name.
     *
     * @return     The eng name.
     */
    virtual std::string GetEngName() {
        return "odte";
    }

    /**
     * @brief      { function_description }
     */
    virtual bool WaitEngineIdle(int timeout);

    /**
     * @brief      Gets the clock m hz.
     *
     * @return     The clock m hz.
     */
    virtual uint64_t GetClkMHz();

    /**
     * @brief      Gets the thread mask.
     *
     * @return     The thread mask.
     */
    virtual uint32_t GetThreadMask();

    /**
     * @brief      Sets the reorder.
     *
     * @param[in]  status  The status
     */
    virtual void SetReorder(bool status);

    /**
     * @brief      Gets the sa.
     *
     * @return     The sa.
     */
    virtual SystemAdapter *GetSa();

    /**
     * @brief      Gets the bpm number.
     *
     * @return     The bpm number.
     */
    virtual uint32_t GetPortNum() {
        return 2;
    }

    /**
     * @brief      Gets the bpm.
     *
     * @param[in]  index  The index
     *
     * @return     The bpm.
     */
    virtual Bpm *GetBpm(int index);

    /**
     * @brief      Gets the bpm w thro.
     *
     * @param[in]  idex  The idex
     * @param      res   The resource
     */
    virtual void GetBpmResult(int index, BpmResult *res);

    /**
     * @brief      Gets the dvfs.
     *
     * @param[in]  index  The index
     *
     * @return     The dvfs.
     */
    virtual Pmc *GetDvfs(int index);

    /**
     * @brief      { function_description }
     */
    virtual void DvfsPmcStart() {}

    /**
     * @brief      { function_description }
     */
    virtual void DvfsPmcStop() {}

    /**
     * @brief      Gets the dvfs result.
     *
     * @param      result  The result
     */
    virtual void GetDvfsResult(DvfsResult &result) {}

    /**
     * @brief      Gets the performance pmc.
     *
     * @return     The performance pmc.
     */
    virtual Pmc *GetPerfPmc();

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStart();

    /**
     * @brief      { function_description }
     */
    virtual void EnClkGate();

    /**
     * @brief      Enables the bpm.
     */
    virtual void EnableBpm(uint64_t cycle);

    /**
     * @brief      Prints a bpm status.
     */
    virtual void PrintBpmStatus();

    /**
     * @brief      { function_description }
     */
    virtual void EnCrc(uint32_t port, int vc);

    /**
     * @brief      Calc data crc value.
     *
     * @param[in]  src_addr     The src buffer address
     * @param[in]  dst_addr     The dst buffer address
     * @param[in]  size         Calc crc data size
     * @param[in]  timeout      timeout value
     * @return     The crc value.
     */
    virtual uint32_t CalcDataCrc(
        uint64_t src_addr, uint64_t dst_addr, uint64_t size, int timeout);

    /**
     * @brief      Sets the throttle.
     *
     * @param[in]  percent  The percent
     */
    virtual void SetThrottle(
        uint32_t window, uint32_t rd_bw, uint32_t wr_bw, uint32_t rd_os, uint32_t wr_os);

    /**
     * @brief      Sets the wr combine.
     *
     * @param[in]  status    The status
     * @param[in]  wait_num  The wait number
     */
    virtual void SetWrCombine(uint32_t status, uint32_t wait_num) {
        LOG_WARN("odte unsupport write combine");
    }

    /**
     * @brief      Sets the hit ratio.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetHitRatio(const HitRatioCfg &cfg) {}

    /**
     * @brief      Shows the operation description.
     */
    virtual void ShowOpDesc();

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint64_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void RegWrite(uint64_t addr, uint32_t val);

 private:
    std::mutex mutex_;

 private:
    /**
     * @brief      { function_description }
     */
    virtual void LibInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit();

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void FillShrinkParam(DteVcCtx *ctx);

    /**
     * @brief      { function_description }
     *
     * @param      ctx   The context
     */
    virtual void FillBrdcstParam(DteVcCtx *ctx);
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_SCORPIO_ODTE_GDTE_H_
