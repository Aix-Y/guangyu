/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_SCORPIO_ODTE_GDTE_VF_H_
#define HARDWARE_GDTE_SCORPIO_ODTE_GDTE_VF_H_

#include <memory>
#include <set>
#include <vector>
#include "hardware/gdte/scorpio/odte/gdte.h"

namespace efvf {
namespace hardware {
namespace gdte {
class OdteVfScorpio : public OdteScorpio {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit OdteVfScorpio(std::shared_ptr<spdlog::logger> logger) : OdteScorpio(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~OdteVfScorpio() {}

    /**
     * @brief      Sets the reorder.
     *
     * @param[in]  status  The status
     */
    virtual void SetReorder(bool status) {}

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStart() {}

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStop() {}

    /**
     * @brief      Gets the clock m hz.
     *
     * @return     The clock m hz.
     */
    virtual uint64_t GetClkMHz() {
        return 1;
    }

    /**
     * @brief      Gets the busy cycle.
     */
    virtual uint64_t GetBusyCycle() {
        return 0;
    }

    /**
     * @brief      Enables the bpm.
     */
    virtual void EnableBpm(uint64_t cycle) {}

    /**
     * @brief      Prints a bpm status.
     */
    virtual void PrintBpmStatus() {}

    /**
     * @brief      Gets the bpm result.
     *
     * @param[in]  index  The index
     * @param      res    The resource
     */
    virtual void GetBpmResult(int index, BpmResult *res) {}

    /**
     * @brief      { function_description }
     */
    virtual void DvfsPmcStart() {}

    /**
     * @brief      { function_description }
     */
    virtual void DvfsPmcStop() {}

    /**
     * @brief      Gets the crc value.
     *
     * @return     The crc value.
     */
    virtual uint32_t GetCrcVal() {
        return 0;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint64_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void RegWrite(uint64_t addr, uint32_t val);

    /**
     * @brief      Saves a register.
     */
    virtual void SaveReg() {}

    /**
     * @brief      { function_description }
     */
    virtual void Restore() {}

    /**
     * @brief      Gets the dvfs result.
     *
     * @param      result  The result
     */
    virtual void GetDvfsResult(DvfsResult &result) {}

    /**
     * @brief      Sets the varibalie.
     */
    virtual void LibInit();

 private:
    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit() {
        return true;
    }

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit() {
        return true;
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     *
     * @return     { description_of_the_return_value }
     */
    uint64_t Vf2Pf(uint64_t offset);
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_SCORPIO_ODTE_GDTE_VF_H_
