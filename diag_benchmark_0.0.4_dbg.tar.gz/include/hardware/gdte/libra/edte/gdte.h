/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_LIBRA_EDTE_GDTE_H_
#define HARDWARE_GDTE_LIBRA_EDTE_GDTE_H_

#include <memory>
#include <set>
#include <string>
#include "hardware/gdte/libra/cdte/gdte.h"
#include "hardware/gdte/libra/edte/gdte_vc.h"

namespace efvf {
namespace hardware {
namespace gdte {
class EdteLibra : public CdteLibra {
 public:
    /**
    * @brief      Constructs a new instance.
    *
    * @param[in]  logger  The logger
    */
    explicit EdteLibra(std::shared_ptr<spdlog::logger> logger) : CdteLibra(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~EdteLibra() {}

    /**
     * @brief      Gets the eng name.
     *
     * @return     The eng name.
     */
    virtual std::string GetEngName() {
        return "edte";
    }

    /**
     * @brief      Gets the debug position.
     *
     * @return     The debug position.
     */
    virtual uint64_t GetDbgThdPos();

    /**
     * @brief Dump each thread position.
     *
     */
    virtual void DumpThdPos();

    /**
     * @brief      { function_description }
     */
    virtual bool WaitEngineIdle(int timeout);

    /**
     * @brief      Gets the clock m hz.
     *
     * @return     The clock m hz.
     */
    virtual uint64_t GetClkMHz();

    /**
     * @brief      Gets the thread mask.
     *
     * @return     The thread mask.
     */
    virtual uint32_t GetThreadMask();

    /**
     * @brief      Gets the sa.
     *
     * @return     The sa.
     */
    virtual SystemAdapter *GetSa();

    /**
     * @brief      Sets the reorder.
     *
     * @param[in]  status  The status
     */
    virtual void SetReorder(bool status);

    /**
     * @brief Get the Mmu.
     *
     * @return Hardware*
     */
    virtual Hardware *GetMmuHw();

    /**
     * @brief      Gets the bpm number.
     *
     * @return     The bpm number.
     */
    virtual uint32_t GetPortNum() {
        return 2;
    }

    /**
     * @brief      { function_description }
     */
    virtual void EnClkGate();

    /**
     * @brief      Shows the operation description.
     */
    virtual void ShowOpDesc();

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  bl_list  {RPORT, WPORT}
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetBL(const DteBurstLen &bl);

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  burstlen  The burstlen
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool SetBL(uint32_t burstlen);

    /**
     * @brief      Sets the bl.
     *
     * @param[in]  burstlen  The burstlen
     *
     * @return     { description_of_the_return_value }
     */
    virtual void SetMaxBL();

    /**
     * @brief      Calc data crc value.
     *
     * @param[in]  src_addr     The src buffer address
     * @param[in]  dst_addr     The dst buffer address
     * @param[in]  size         Calc crc data size
     * @param[in]  timeout      timeout value
     * @return     The crc value.
     */
    virtual uint32_t CalcDataCrc(
        uint64_t src_addr, uint64_t dst_addr, uint64_t size, int timeout);

    /**
     * @brief      Sets the throttle.
     *
     * @param[in]  percent  The percent
     */
    virtual void SetThrottle(
        uint32_t window, uint32_t rd_bw, uint32_t wr_bw, uint32_t rd_os, uint32_t wr_os);

    /**
     * @brief      Gets the performance pmc.
     *
     * @return     The performance pmc.
     */
    virtual Pmc *GetPerfPmc();

    /**
     * @brief      { function_description }
     */
    virtual void PerfPmcStart();

    /**
     * @brief      Sets the wr combine.
     *
     * @param[in]  status    The status
     * @param[in]  wait_num  The wait number
     */
    virtual void SetWrCombine(uint32_t status, uint32_t wait_num) {
        LOG_WARN("edte unsupport write combine");
    }

    /**
     * @brief      { function_description }
     */
    virtual void EnCrc(uint32_t port, int vc);

    /**
     * @brief      Sets the hit ratio.
     *
     * @param[in]  cfg   The new value
     */
    virtual void SetHitRatio(const HitRatioCfg &cfg) {}

    /**
     * @brief Enable or disable rshp ifb mode
     *
     * @param enable
     */
    virtual void EnRshpIfbMode(bool enable) {
        LOG_WARN("{} do not reshape op.", this->GetEngName());
    }

    /**
     * @brief Enable or disable dynamic queue
     *
     * @param enable
     */
    virtual void EnDynamicQueue(bool enable);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t RegRead(uint64_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void RegWrite(uint64_t addr, uint32_t val);

 private:
    std::mutex mutex_;

 private:
    /**
     * @brief      { function_description }
     */
    virtual void LibInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit();

    uint32_t default_thread_mask_ = 0x3;
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  //  HARDWARE_GDTE_LIBRA_EDTE_GDTE_H_
