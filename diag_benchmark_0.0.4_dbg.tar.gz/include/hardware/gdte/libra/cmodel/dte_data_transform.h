#ifndef DTE_DATA_TRANSFORM_H_
#define DTE_DATA_TRANSFORM_H_

#include <cmath>
#include <map>
#include "common_defines.h"
#include "hardware/gdte/libra/cmodel/dte_utility.h"
#include "log_interface.h"

namespace libra {

class dte_data_transform_t : public log_wrapper_t {
 public:
    dte_data_transform_t() {}

    virtual ~dte_data_transform_t() {}

    data_desc task_lnc(data_desc src_desc);

    data_desc task_ds(uint64_t data_bpe, uint64_t src_total_size, uint64_t shr_phase,
        uint64_t shr_ratio, data_desc src_desc);

    data_desc task_de(uint64_t data_bpe, uint64_t src_total_size, uint64_t exp_phase,
        uint64_t exp_ratio, data_desc src_desc);

    data_desc task_cf(uint64_t src_total_size, uint64_t data_bpe, uint32_t constant_data);

    data_desc task_pad(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size, uint64_t pad_value,
        uint64_t pad_dim0_low, uint64_t pad_dim0_high, uint64_t pad_dim1_low,
        uint64_t pad_dim1_high, uint64_t pad_dim1_interior, uint64_t pad_dim2_low,
        uint64_t pad_dim2_high, uint64_t pad_dim2_interior, uint64_t pad_dim3_low,
        uint64_t pad_dim3_high, uint64_t pad_dim3_interior, data_desc src_desc);

    data_desc task_rshp(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t reshape_dim0_map, uint64_t reshape_dim1_map, uint64_t reshape_dim2_map,
        uint64_t reshape_dim3_map, data_desc src_desc);

    data_desc task_brdcst(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t brdcst_dim, uint64_t brdcst_size, data_desc src_desc);

    data_desc task_slc(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t slice_dim0_size, uint64_t slice_dim1_size, uint64_t slice_dim2_size,
        uint64_t slice_dim3_size, uint64_t slice_dim0_start, uint64_t slice_dim1_start,
        uint64_t slice_dim2_start, uint64_t slice_dim3_start, uint64_t slice_dim0_start_dir,
        uint64_t slice_dim1_start_dir, uint64_t slice_dim2_start_dir,
        uint64_t slice_dim3_start_dir, uint64_t pad_value, data_desc src_desc);

    data_desc task_dsl(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t dst_dim0_size, uint64_t dst_dim1_size, uint64_t dst_dim2_size,
        uint64_t dst_dim3_size, uint64_t dsl_dim0_start, uint64_t dsl_dim1_start,
        uint64_t dsl_dim2_start, uint64_t dsl_dim3_start, data_desc src_desc);

    data_desc task_ssmp(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t ssmp_row_stride, data_desc src_desc);

    data_desc task_hmir(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        data_desc src_desc);

    data_desc task_vmir(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        data_desc src_desc);

    data_desc task_slcpad(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t slice_dim0_size, uint64_t slice_dim1_size, uint64_t slice_dim2_size,
        uint64_t slice_dim3_size, uint64_t slice_dim0_start, uint64_t slice_dim1_start,
        uint64_t slice_dim2_start, uint64_t slice_dim3_start, uint64_t pad_value,
        uint64_t pad_dim0_low, uint64_t pad_dim0_high, uint64_t pad_dim1_low,
        uint64_t pad_dim1_high, uint64_t pad_dim1_interior, uint64_t pad_dim2_low,
        uint64_t pad_dim2_high, uint64_t pad_dim2_interior, uint64_t pad_dim3_low,
        uint64_t pad_dim3_high, uint64_t pad_dim3_interior, data_desc src_desc);

    data_desc task_slcdsl(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t slice_dim0_size, uint64_t slice_dim1_size, uint64_t slice_dim2_size,
        uint64_t slice_dim3_size, uint64_t slice_dim0_start, uint64_t slice_dim1_start,
        uint64_t slice_dim2_start, uint64_t slice_dim3_start, uint64_t dst_dim0_size,
        uint64_t dst_dim1_size, uint64_t dst_dim2_size, uint64_t dst_dim3_size,
        uint64_t dsl_dim0_start, uint64_t dsl_dim1_start, uint64_t dsl_dim2_start,
        uint64_t dsl_dim3_start, data_desc src_desc);

    data_desc task_slcde(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t slice_dim0_size, uint64_t slice_dim1_size, uint64_t slice_dim2_size,
        uint64_t slice_dim3_size, uint64_t slice_dim0_start, uint64_t slice_dim1_start,
        uint64_t slice_dim2_start, uint64_t slice_dim3_start, uint64_t exp_phase,
        uint64_t exp_ratio, data_desc src_desc);

    data_desc task_hmirdsl(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t dst_dim0_size, uint64_t dst_dim1_size, uint64_t dst_dim2_size,
        uint64_t dst_dim3_size, uint64_t dsl_dim0_start, uint64_t dsl_dim1_start,
        uint64_t dsl_dim2_start, uint64_t dsl_dim3_start, data_desc src_desc);

    data_desc task_vmirdsl(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t dst_dim0_size, uint64_t dst_dim1_size, uint64_t dst_dim2_size,
        uint64_t dst_dim3_size, uint64_t dsl_dim0_start, uint64_t dsl_dim1_start,
        uint64_t dsl_dim2_start, uint64_t dsl_dim3_start, data_desc src_desc);

    data_desc task_hmirpad(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size, uint64_t pad_value,
        uint64_t pad_dim0_low, uint64_t pad_dim0_high, uint64_t pad_dim1_low,
        uint64_t pad_dim1_high, uint64_t pad_dim1_interior, uint64_t pad_dim2_low,
        uint64_t pad_dim2_high, uint64_t pad_dim2_interior, uint64_t pad_dim3_low,
        uint64_t pad_dim3_high, uint64_t pad_dim3_interior, data_desc src_desc);

    data_desc task_vmirpad(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size, uint64_t pad_value,
        uint64_t pad_dim0_low, uint64_t pad_dim0_high, uint64_t pad_dim1_low,
        uint64_t pad_dim1_high, uint64_t pad_dim1_interior, uint64_t pad_dim2_low,
        uint64_t pad_dim2_high, uint64_t pad_dim2_interior, uint64_t pad_dim3_low,
        uint64_t pad_dim3_high, uint64_t pad_dim3_interior, data_desc src_desc);

    data_desc task_cfdsl(uint64_t data_bpe, uint64_t constant_data, uint64_t src_dim0_size,
        uint64_t src_dim1_size, uint64_t src_dim2_size, uint64_t src_dim3_size,
        uint64_t dim4_size, uint64_t dst_dim0_size, uint64_t dst_dim1_size,
        uint64_t dst_dim2_size, uint64_t dst_dim3_size, uint64_t dsl_dim0_start,
        uint64_t dsl_dim1_start, uint64_t dsl_dim2_start, uint64_t dsl_dim3_start);

    data_desc task_slcrshp(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t slice_dim0_size, uint64_t slice_dim1_size, uint64_t slice_dim2_size,
        uint64_t slice_dim3_size, uint64_t slice_dim0_start, uint64_t slice_dim1_start,
        uint64_t slice_dim2_start, uint64_t slice_dim3_start, uint64_t slice_dim0_start_dir,
        uint64_t slice_dim1_start_dir, uint64_t slice_dim2_start_dir,
        uint64_t slice_dim3_start_dir, uint64_t slc_reshape_dim0_map,
        uint64_t slc_reshape_dim1_map, uint64_t slc_reshape_dim2_map,
        uint64_t slc_reshape_dim3_map, uint64_t pad_value, data_desc src_desc);

    data_desc task_rshpdsl(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t reshape_dsl_dim0_map, uint64_t reshape_dsl_dim1_map,
        uint64_t reshape_dsl_dim2_map, uint64_t reshape_dsl_dim3_map, uint64_t dst_dim0_size,
        uint64_t dst_dim1_size, uint64_t dst_dim2_size, uint64_t dst_dim3_size,
        uint64_t dsl_dim0_start, uint64_t dsl_dim1_start, uint64_t dsl_dim2_start,
        uint64_t dsl_dim3_start, data_desc src_desc);

    data_desc task_dsdsl(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t dst_dim0_size, uint64_t dst_dim1_size, uint64_t dst_dim2_size,
        uint64_t dst_dim3_size, uint64_t dsl_dim0_start, uint64_t dsl_dim1_start,
        uint64_t dsl_dim2_start, uint64_t dsl_dim3_start, uint64_t shr_ratio,
        uint64_t shr_phase, data_desc src_desc);

    data_desc task_slcbrdcst(uint64_t data_bpe, uint64_t src_dim0_size, uint64_t src_dim1_size,
        uint64_t src_dim2_size, uint64_t src_dim3_size, uint64_t dim4_size,
        uint64_t slice_dim0_size, uint64_t slice_dim1_size, uint64_t slice_dim2_size,
        uint64_t slice_dim3_size, uint64_t slice_dim0_start, uint64_t slice_dim1_start,
        uint64_t slice_dim2_start, uint64_t slice_dim3_start, uint64_t brdcst_dim,
        uint64_t brdcst_size, data_desc src_desc);
};

}  //  namespace libra

#endif
