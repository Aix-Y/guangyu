#ifndef _C_MODEL_UTILS_H_
#define _C_MODEL_UTILS_H_

#include <arpa/inet.h>
#include <string.h>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <utility>
#include <vector>
#include "common_defines.h"
#include "log_interface.h"

namespace libra {
typedef struct data_describe {
    uint64_t data_size         = 0;
    uint64_t dim0_bytes        = 0;
    uint64_t sub_hier_max_size = 0;
    uint64_t rd_min_size       = 0;
    uint8_t *data              = NULL;
} data_desc;

typedef struct size { uint64_t dst_total_size = 0; } size_desc;

class array_t {
 public:
    static void shuffle(void *array, uint64_t n, uint64_t size);
    static void rand_data(uint8_t *data, uint64_t len);
    static void diff(
        uint8_t *exp_data, uint8_t *act_data, uint64_t len, uint8_t wrap_size = 8);
    static void display(uint8_t *data, uint64_t len);
};

class tile_t : public log_wrapper_t {
 protected:
    uint8_t * data_u8  = NULL;
    uint16_t *data_u16 = NULL;
    uint32_t *data_u32 = NULL;

    uint8_t  bpe;
    uint64_t size_dim4, size_dim3, size_dim2, size_dim1, size_dim0;

    uint64_t total_unit_size;
    uint64_t unit_dim4;
    uint64_t unit_dim3;
    uint64_t unit_dim2;
    uint64_t unit_dim1;

 public:
    void init(uint8_t *data, uint8_t bpe, uint64_t size_dim4, uint64_t size_dim3,
        uint64_t size_dim2, uint64_t size_dim1, uint64_t size_dim0);
    void     display();
    uint32_t retrieve_element(uint64_t idx_dim4, uint64_t idx_dim3, uint64_t idx_dim2,
        uint64_t idx_dim1, uint64_t idx_dim0);
    void fill_elements(uint64_t val, uint64_t idx, uint64_t len);
    void fill_all(uint64_t val);
    void fill_dim4(uint64_t val, uint64_t idx_dim4);
    void fill_dim3(uint64_t val, uint64_t idx_dim4, uint64_t idx_dim3);
    void fill_dim2(uint64_t val, uint64_t idx_dim4, uint64_t idx_dim3, uint64_t idx_dim2);
    void fill_dim1(uint64_t val, uint64_t idx_dim4, uint64_t idx_dim3, uint64_t idx_dim2,
        uint64_t idx_dim1);
    void fill_dim0(uint64_t val, uint64_t idx_dim4, uint64_t idx_dim3, uint64_t idx_dim2,
        uint64_t idx_dim1, uint64_t idx_dim0);
    inline uint64_t get_total_unit_size() {
        return total_unit_size;
    }
    inline uint64_t get_unit_dim4() {
        return unit_dim4;
    }
    inline uint64_t get_unit_dim3() {
        return unit_dim3;
    }
    inline uint64_t get_unit_dim2() {
        return unit_dim2;
    }
    inline uint64_t get_unit_dim1() {
        return unit_dim1;
    }
};

typedef std::pair<uint64_t, uint64_t> addr_data_pair;
typedef std::vector<addr_data_pair> addr_data_vct;
typedef std::map<uint64_t, addr_data_vct> addr_data_map;

class file_handler {
 public:
    static bool parse_data_from_str(uint8_t mode, std::string line_str,
        addr_data_pair &pair);  // mode: 0-src data, 1-cfg data, 2-mail data
    static addr_data_vct get_data_from_file(uint8_t mode, std::string file_name);
    static addr_data_vct get_src_data_from_file(std::string file_name);
    static addr_data_vct get_cfg_data_from_file(std::string file_name);
    static addr_data_vct get_mail_data_from_file(std::string file_name);
};

typedef uint8_t mask_t[MASK_BITS / 8];

typedef struct scp_describe {
    uint64_t               payload_size;  // hdr
    std::vector<uint8_t>   sum;
    std::vector<mask_t>    mask;
    std::vector<uint8_t *> nz_data;
    uint64_t               bytes_size = 0;
    uint8_t *              bytes      = NULL;
} scp_desc;

typedef struct gscp_describe {
    uint64_t               payload_size;  // hdr[47:16]
    uint64_t               scp_num;       // hdr[15:0]
    std::vector<uint8_t *> scp;
    uint64_t               bytes_size = 0;
    uint8_t *              bytes      = NULL;
} gscp_desc;

typedef struct gscpc_describe {
    uint64_t               payload_size;  // hdr[47:16]
    uint64_t               scp_num;       // hdr[15:0]
    std::vector<uint8_t *> gscp;
    uint64_t               bytes_size = 0;
    uint8_t *              bytes      = NULL;
} gscpc_desc;

typedef std::vector<data_desc> data_desc_q;

}  //  namespace libra

#endif
