
#ifndef _SM4_XTS_TOP_DPI_H_
#define _SM4_XTS_TOP_DPI_H_

//#include "svdpi.h"
//#include "vpi_user.h"
#include "sm4_user_defs.h"
#include "sm4_core.h"

u8 sm4_xts_enc(u8_p  p_key, 
               u32   key_sel,
               u8_p  p_tweak, 
               u8    du_format, 
               u32   date_size,
               const u8_p p_in_data,
               u8_p p_out_data);

u8 sm4_xts_dec(u8_p  p_key, 
               u32   key_sel,
               u8_p  p_tweak, 
               u8    du_format, 
               u32   date_size,
               const u8_p p_in_data,
               u8_p p_out_data); 

#endif //_SM4_XTS_TOP_DPI_H_
