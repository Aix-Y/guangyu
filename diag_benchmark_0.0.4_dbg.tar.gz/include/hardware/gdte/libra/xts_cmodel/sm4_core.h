
#ifndef _SM4_CORE_H_
#define _SM4_CORE_H_

//#include "svdpi.h"
//#include "vpi_user.h"
#include "sm4_user_defs.h"

u32  bit_left_move(u32 data, u32 cnt) ;
u8   fun_find_sbox(u8 raw_data) ;
u32  fun_t_calc(u32 raw_data , u32 mode) ; 
void gen_round_key(u32_p p_mk, u32_p p_rk) ;
void gen_sm4_encrypt(u32_p p_rk, u32_p p_plain_data, u32_p p_cipher_data) ;
void gen_sm4_decrypt(u32_p p_rk, u32_p p_plain_data, u32_p p_cipher_data) ;
void fun_sm4_core_enc(u8_p p_mk,u8_p p_pt, u8_p p_ct) ;
void fun_sm4_core_dec(u8_p p_mk, u8_p p_pt, u8_p p_ct) ;

#endif //_SM4_CORE_H_
