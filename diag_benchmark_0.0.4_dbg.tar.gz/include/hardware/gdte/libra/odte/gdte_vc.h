/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_GDTE_LIBRA_ODTE_GDTE_VC_H_
#define HARDWARE_GDTE_LIBRA_ODTE_GDTE_VC_H_

#include <memory>
#include "framework/include/log.h"
#include "hardware/gdte/libra/cdte/gdte_vc.h"
#include "hardware/gdte/libra/gdte_vc.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace gdte {
class OdteVcLibra : public CdteVcLibra {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  vc      { parameter_description }
     * @param      dte     The dte
     * @param[in]  logger  The logger
     */
    OdteVcLibra(int vc, Hardware *dte, std::shared_ptr<spdlog::logger> logger)
        : CdteVcLibra(vc, dte, logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~OdteVcLibra() {}

    /**
     * @brief      Initializes the register handle.
     */
    virtual void InitRegHandle() {
        direct_reg_ = dte_->Get("ODTE_VC_DIRECT_REGS", vc_);
        sram_reg_   = dte_->Get("ODTE_VC_SRAM_REGS", vc_);
    }

    /**
     * @brief      direct reg access
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t DirectRegRead(uint32_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void DirectRegWrite(uint32_t addr, uint32_t val);

    /**
     * @brief      op access
     *
     * @param[in]  addr  The address
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t SramRegRead(uint32_t addr);

    /**
     * @brief      { function_description }
     *
     * @param[in]  addr  The address
     * @param[in]  val   The value
     */
    virtual void SramRegWrite(uint32_t addr, uint32_t val);

 private:
    /**
     * @brief      { function_description }
     *
     * @param[in]  ctx   The context
     */
    virtual void SelCmdCtrl(const DteVcCtx &ctx);

    /**
     * @brief      { function_description }
     *
     * @param[in]  ctx   The context
     */
    virtual void CacheCfg(const DteVcCtx &ctx);

    /**
     * @brief      { function_description }
     *
     * @param[in]  ctx   The context
     */
    virtual void AtomicCfg(const DteVcCtx &ctx);

    /**
     * @brief      Set vc decrypt.
     *
     * @param[in]  ctx   The new value
     */
    virtual void SetVcDecrypt(const DteVcCtx &ctx);

    /**
     * @brief      gec vc key schedule done.
     *
     * @return     The done status
     */
    bool GetVcKeySchDone(uint64_t timeout_ms);

    /**
     * @brief      gec vc key schedule done.
     *
     * @return     The done status
     */
    bool VcKeySchIsDone();
};

}  // namespace gdte
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_GDTE_LIBRA_ODTE_GDTE_VC_H_
