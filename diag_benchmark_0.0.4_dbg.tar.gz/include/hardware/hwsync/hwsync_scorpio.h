/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_HWSYNC_HWSYNC_SCORPIO_H_
#define HARDWARE_HWSYNC_HWSYNC_SCORPIO_H_

#include <map>
#include <memory>
#include <set>
#include <string>
#include "device/dtus/scorpio/register_soc.h"
#include "hardware/include/hardware.h"
#include "hardware/include/hwsync/hwsync.h"
using efvf::framework::utils::Millis;
namespace efvf {
namespace hardware {
namespace hwsync {

// L3 hwsync
#define SCORPIO_HWSYNC_ENTRY_NUM 1024
#define SCORPIO_HwSYNC_CNT_NUM 256
#define SCORPIO_HWSYNC_MUTEX_NUM 2048

class HwsyncScorpio : public Hwsync {
 public:
    explicit HwsyncScorpio(std::shared_ptr<spdlog::logger> logger) : Hwsync(logger) {}
    virtual ~HwsyncScorpio() {}
    // common interface
    virtual bool HwInit();
    virtual void ClearSingleEntry(uint32_t entry_id);
    virtual void ClearAllEntries();
    virtual void ClearSingleCounter(uint32_t counter_id);
    virtual void ClearAllCounters();
    virtual void ClearAllMutex();

    virtual void InitVgRes(const HwsyncVgResInit &res_init);
    virtual void InitLut(uint32_t lut_id);
    virtual void SetLut(uint32_t lut_id, uint32_t addr);
    virtual void SetCounter(const HwsyncSetCounter &set_counter);
    virtual void AllocStaticCnt(const HwsyncCntStaticAlloc &alloc_static_cnt);
    virtual uint32_t SetLutNotifyInfo(const HwsyncLutNotifyInfo &notify_info);
    virtual uint32_t GetMaxMutex();
    virtual uint32_t GetMaxCnt();
    virtual uint32_t GetMaxEntry();
    virtual uint32_t GetAllocStaticMutexNum(uint32_t static_mutex_num);
    virtual uint32_t GetAllocStaticCntNum(uint32_t static_cnt_num);
    virtual uint32_t GetAllocEntryNum(uint32_t entry_num);
    virtual uint32_t GetAllocDynamicMutexNum(uint32_t static_mutex_num);
    virtual uint32_t GetAllocDynamicCntNum(uint32_t static_cnt_num);

    // mutex interface
    virtual uint32_t AllocMutex();
    virtual void DeallocMutex(uint32_t mutex_id);
    virtual bool TryLockMutex(uint32_t mutex_id);
    virtual void UnlockMutex(uint32_t mutex_id);

    // barrier interface
    virtual uint32_t AllocBarrier();
    virtual void DeallocBarrier(uint32_t barrier_id);
    virtual void UnRegisterBarrierWait(
        uint32_t counter_id, uint32_t uniq_id, uint32_t thread_id);
    virtual void ArriveBarrier(uint32_t counter_id, uint32_t uniq_id, uint32_t thread_id);
    virtual void ArriveAndDropBarrier(uint32_t counter_id, uint32_t uniq_id);

    // latch interface
    virtual uint32_t AllocLatch();
    virtual void DeallocLatch(uint32_t latch_id);
    virtual void UnregisterLatchWait(
        uint32_t counter_id, uint32_t uniq_id, uint32_t thread_id);
    virtual void ArriveLatch(uint32_t counter_id, uint32_t uniq_id, uint32_t thread_id);

    // queue interface
    virtual uint32_t AllocProdQueue();
    virtual uint32_t AllocConsQueue();
    virtual void DeallocProdQueue(uint32_t queue_producer_id);
    virtual void AdvanceWriteFar(uint32_t queue_producer_id, uint32_t uniq_id);
    virtual void AdvanceReadFar(uint32_t queue_consumer_id, uint32_t uniq_id);
    virtual void UnregisterQueueProd(uint32_t queue_consumer_id, uint32_t uniq_id);

    // atomic interface
    virtual uint32_t ReadAtomic(uint32_t atomic_id);
    virtual void IncSelfIncrMem(uint32_t atomic_id);
    // check cfg error , for debug
    virtual uint32_t SetCfMstOts(uint32_t ostd);
    virtual uint32_t GetMaxOtsNum();
    virtual bool WaitIdle(int timeout);
    virtual void ClockDisable();
    virtual void ClockEnable();
    // virtual void ClrEnable(uint32_t trigger_type);
    virtual void VgReset(uint8_t vg);
    // virtual bool InterrputException(const HwsyncIntStatusChk &hwsync_in_status);
    virtual bool InterrputException(uint32_t status_index);
    virtual void CheckInterruptAndClear();
    // virtual void ClearCurrentInterruptException(uint32_t status_index);
    virtual void SetIhCauseAddr(uint32_t addr);
    virtual void EnableInterrupt();
    virtual void DisableInterrupt();
    virtual void VfRes(uint32_t vg_id);

 private:
    uint32_t alloc_id_             = 0;
    uint32_t mutex_static_num_     = 0;
    uint32_t mutex_dynamic_num_    = 0;
    uint32_t counter_static_num_   = 0;
    uint32_t counter_dynamic_num_  = 0;
    uint32_t entry_num_            = 0;
    uint32_t counter_num_          = 0;
    uint32_t next_phase_threshold_ = 0;
    uint32_t total_thread_num_     = 0;
};

}  // namespace hwsync
}  // namespace hardware
}  // namespace efvf

#endif  //  HARDWARE_HWSYNC_HWSYNC_SCORPIO_H_
