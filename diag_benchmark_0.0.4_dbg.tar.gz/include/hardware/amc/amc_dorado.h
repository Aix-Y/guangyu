/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_AMC_AMC_DORADO_H_
#define HARDWARE_AMC_AMC_DORADO_H_
#include "hardware/include/amc.h"
namespace efvf {
namespace hardware {
namespace amc {
DefineAmc(Dorado, AmcDorado, AM_CLIENT);
}  // namespace amc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_AMC_AMC_DORADO_H_
