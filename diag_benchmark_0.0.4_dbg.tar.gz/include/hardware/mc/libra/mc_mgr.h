/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_LIBRA_MC_MGR_H_
#define HARDWARE_MC_LIBRA_MC_MGR_H_

#include <memory>
#include <string>
#include <vector>
#include "hardware/include/mc/mc_mgr.h"

namespace efvf {
namespace hardware {
namespace mc {
class McMgrLibra : public McMgr {
 public:
    McMgrLibra(std::shared_ptr<spdlog::logger> logger, const Dtu &dtu);
    virtual ~McMgrLibra() {}

    //!
    //! @berif from Hardware
    //!
    // virtual int Deamon(int task_id, void *param);
    // virtual void set_mask(const std::bitset<HW_MAX_BIT> &mask);
    bool Init();

    //!
    //! @berif from McMgr
    //!
    void PrintMemInfo();

    MC_MEM_TYPE  GetMemType();
    MC_VENDOR_ID GetVendorId();
    uint32_t     GetNumOfMcInsts();
    uint32_t     GetNumOfAvailMcInsts();
    uint32_t     GetMaskOfMcInsts();
    uint32_t     GetNumOfMcChannelsPerInst();
    uint64_t     GetTotalMemSize();
    Mc *         GetMcInst(uint32_t);
    bool SetEcc(bool ecc_on, bool hw = false);
    bool GetEcc(void);

 private:
    virtual bool HwDeinit();

 private:
    uint32_t m_num_of_mc;
    uint32_t m_num_of_avail_mc;
    uint32_t m_first_avail_mc;
    uint64_t m_total_mem_size;
    uint64_t m_device_cap;
    bool     m_ecc_on;
    bool     m_hash_on;

 private:
    bool       m_inited;
    std::mutex m_mut;
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_MC_LIBRA_MC_MGR_H_
