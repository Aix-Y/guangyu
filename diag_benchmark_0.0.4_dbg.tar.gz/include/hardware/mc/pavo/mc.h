/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_PAVO_MC_H_
#define HARDWARE_MC_PAVO_MC_H_

#include <memory>
#include <string>
#include <vector>
#include "hardware/include/mc/mc.h"

namespace efvf {
namespace hardware {
namespace mc {
class McPavo : public Mc {
 public:
    explicit McPavo(std::shared_ptr<spdlog::logger> logger);
    virtual ~McPavo() {}

    //!
    //! @berif from Hardware
    //!
    virtual int Deamon(int task_id, void *param);
    virtual void set_mask(const std::bitset<HW_MAX_BIT> &mask);

    virtual Hardware *GetPmc(std::string name);

    //!
    //! @berif from Mc
    //!
    virtual uint8_t  GetHbmInst();
    virtual uint32_t GetGlbInstId() {
        return this->parent_->inst_ * this->num_ + this->inst_;
    }

    virtual bool ConfigChanForRegRw(uint32_t chan);

    virtual bool ConfigECC(bool ecc_en);
    virtual bool ConfigChanRegBrdcst(bool enable);
    virtual void ConfigWrapperRegBrdcst(bool enable);

    //!
    //! memory wrapper/instance, channel info
    //!
    virtual uint32_t GetNumOfInsts() {
        return 8;
    }

    virtual uint32_t GetNumOfMcChannelsPerInst() {
        return 4;
    }

    virtual uint32_t GetNumOfMemoryChannels() {
        return 32;
    }

    virtual bool     SetMcPriority();
    virtual void     EnableMcCFCnt();
    virtual void     DisableMcCFCnt();
    virtual uint32_t CalCntVal();
    virtual void     SoftResetECFPmc();

    void TopRegWrite(uint32_t offset, uint32_t val);
    uint32_t TopRegRead(uint32_t offset);
    std::vector<uint32_t> ChanRegRead(uint32_t chan, uint32_t offset);
    void ChanRegWrite(uint32_t chan, uint32_t offset, uint32_t val);

 private:
    virtual bool HwInit();
    virtual bool HwDeinit();
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_MC_PAVO_MC_H_
