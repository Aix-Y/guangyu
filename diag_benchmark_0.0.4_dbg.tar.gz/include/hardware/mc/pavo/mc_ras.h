/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_MC_PAVO_MC_RAS_H_
#define HARDWARE_MC_PAVO_MC_RAS_H_

#include "hardware/include/mc/mc_ras.h"

namespace efvf {
namespace hardware {
namespace mc {
#if 0
class McPavo;
class McRasPavo : public McRas {
 public:
    explicit McRasPavo(McPavo *hw);
    virtual ~McRasPavo();
    virtual void Enable(const RasCfg *cfg);
    virtual void Disable();
    virtual void StartErrInjection(const RasErrInj *err_inj);
    virtual void StopErrInjection();
    virtual void QueryErrStatus(RasErrStat *err_stat);
    virtual void ClearErrStatus();
    virtual void PrintErrStatus();

    virtual void EnableInterrupt(const IntrptCfg *cfg);
    virtual void DisableInterrupt();
    virtual void ClearInterrupt();
    /**
     * @berif save interrupt
     */
    virtual void QueryInterrupt(IntrptStat *stat) {}

    virtual void PrintInterrupt();

 private:
    virtual bool ConfigErrCount(MC_ERR_CNTR type);

 private:
    McPavo *hw_;
};
#endif
}  // namespace mc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_MC_PAVO_MC_RAS_H_
