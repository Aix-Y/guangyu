/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_DORADO_MC_H_
#define HARDWARE_MC_DORADO_MC_H_

#include <map>
#include <memory>
#include <string>
#include <vector>
#include "hardware/include/mc/mc.h"

namespace efvf {
namespace hardware {
namespace mc {
class McDorado : public Mc {
 public:
    explicit McDorado(std::shared_ptr<spdlog::logger> logger);
    virtual ~McDorado() {}

    //!
    //! @berif from Hardware
    //!
    virtual int Deamon(int task_id, void *param);
    virtual void set_mask(const std::bitset<HW_MAX_BIT> &mask);

    //!
    //! @berif from Mc
    //!
    virtual uint8_t  GetHbmInst();
    virtual uint32_t GetGlbInstId();

    virtual bool ConfigChanForRegRw(uint32_t chan);
    virtual bool ConfigECC(bool ecc_en);
    virtual bool ConfigChanRegBrdcst(bool enable);
    virtual void ConfigWrapperRegBrdcst(bool enable);

    virtual uint32_t GetNumOfInsts();
    virtual uint32_t GetNumOfMcChannelsPerInst();
    virtual uint32_t GetNumOfMemoryChannels();
    virtual bool     SetMcPriority();
    virtual void     EnableMcCFCnt();
    virtual void     DisableMcCFCnt();
    virtual uint32_t CalCntVal();
    virtual void     SoftResetECFPmc();
    virtual void TopRegWrite(uint32_t offset, uint32_t val);
    virtual uint32_t TopRegRead(uint32_t offset);
    virtual std::vector<uint32_t> ChanRegRead(uint32_t chan, uint32_t offset);
    virtual void ChanRegWrite(uint32_t chan, uint32_t offset, uint32_t val);

 private:
    bool         HwInit();
    virtual bool HwDeinit();

    /* 2.0 interface */
 public:
    virtual uint32_t    GetGlbInst(void);
    virtual uint32_t    GetMemSubsysId(void);
    virtual std::string GetName(void);
    virtual uint64_t    RegBase(const std::string & /*mip_mid_sid*/);

 private:
    uint32_t    m_subsys_id;
    uint32_t    m_glb_inst;
    std::string m_name;
    std::map<const std::string, uint64_t> m_reg_base;

 private:
    uint32_t McBase1RegRead(uint32_t offset);
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_MC_DORADO_MC_H_
