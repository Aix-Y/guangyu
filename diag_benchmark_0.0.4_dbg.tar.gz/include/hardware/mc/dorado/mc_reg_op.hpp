/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_MC_REG_OP_DORADO_HPP_
#define HARDWARE_MC_MC_REG_OP_DORADO_HPP_

#include "device/dtus/dorado/data_fabric.h"
#include "device/dtus/dorado/dtu_wrapper.h"
#include "device/dtus/dorado/register_soc.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////
// MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED
//////////////////////////////////////////////////////////////////////////////////////////////////////
#define __hwtree_l0__(_top, _m) ((_top)->Get(#_m)->ecf_addr_)
#define __hwtree_l1__(_top, _mid, _m) ((_top)->Get(#_m, _mid)->ecf_addr_)
#define __hwtree_l2__(_top, _mid, _sid, _m, _s) ((_top)->Get(#_m, _mid)->Get(#_s, _sid)->ecf_addr_)
#define __hwtree_l3__(_top, _mid, _mdid, _sid, _m, _md, _s) ((_top)->Get(#_m, _mid)->Get(#_md,_mdid)->Get(#_s, _sid)->ecf_addr_)
//#define __hwtree_l3__(_top, _mid, _mdid, _sid, _m, _md, _s) ((_top)->Get(#_m, _mid)->Get((#_md, _mdid))->Get(#_s, _sid)->ecf_addr_)

#define ECF_HOBJ_MC_SUBSYS_(_top)         (hw_soc_->Get("MC_TOP_REGMODEL", _top))

#define ECF_ADDR_MC_MC_BASE1(_top, _mid)     __hwtree_l3__(_top, _mid, 0, 0, MC_WRAPPER_REGMODEL, CPU0, MC_BASE1)
#define ECF_ADDR_MC_MC_BASE2(_top, _mid)     __hwtree_l3__(_top, _mid, 0, 0, MC_WRAPPER_REGMODEL, CPU0, MC_BASE2)
#define ECF_ADDR_MC_MC_BASE3(_top, _mid)     __hwtree_l3__(_top, _mid, 0, 0, MC_WRAPPER_REGMODEL, CPU0, MC_BASE3)
#define ECF_ADDR_MC_MC_BASE4(_top, _mid)     __hwtree_l3__(_top, _mid, 0, 0, MC_WRAPPER_REGMODEL, CPU0, MC_BASE4)

//////////////////////////////////////////////////////////////////////////////////////////////////////
// MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED MANUALLY MAINTAINED
//////////////////////////////////////////////////////////////////////////////////////////////////////

#include "hardware/include/mc/mc_reg_op.hpp"

// macro mapping address
#define __reg_addr_mc_base1(_reg)                    (__reg_o(_reg) + __reg_base(mc_base1,         (  0), (   0)))
#define __reg_addr_mc_base2(_reg)                    (__reg_o(_reg) + __reg_base(mc_base2,         (  0), (   0)))
#define __reg_addr_mc_base3(_reg)                    (__reg_o(_reg) + __reg_base(mc_base3,         (  0), (   0)))
#define __reg_addr_mc_base4(_reg)                    (__reg_o(_reg) + __reg_base(mc_base4,         (  0), (   0)))

#define __mc_base1_reg_addr(_reg)                    ((_reg) + __reg_base(mc_base1,         (  0), (   0)))
#define __mc_base2_reg_addr(_reg)                    ((_reg) + __reg_base(mc_base2,         (  0), (   0)))
#define __mc_base3_reg_addr(_reg)                    ((_reg) + __reg_base(mc_base3,         (  0), (   0)))
#define __mc_base4_reg_addr(_reg)                    ((_reg) + __reg_base(mc_base4,         (  0), (   0)))

#define regr32_mc_base1(_reg)                        (regr32(__reg_addr_mc_base1(_reg)))
#define regw32_mc_base1(_reg, _val)                  (regw32(__reg_addr_mc_base1(_reg), (_val)))
#define regr32f_mc_base1(_reg, _f)                   (regr32f(_reg, _f, __reg_addr_mc_base1(_reg)))
#define regw32f_mc_base1(_reg, _f, _fv)              (regw32f(_reg, _f, __reg_addr_mc_base1(_reg), (_fv)))

#endif  // HARDWARE_MC_MC_REG_OP_DORADO_HPP_
