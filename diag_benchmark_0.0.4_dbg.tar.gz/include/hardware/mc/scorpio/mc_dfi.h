/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_SCORPIO_MC_DFI_H_
#define HARDWARE_MC_SCORPIO_MC_DFI_H_

#include <memory>
#include <set>
#include <string>
#include "hardware/include/mc/mc_dfi.h"

namespace efvf {
namespace hardware {
namespace mcdfi {

/*!
 * @brief McDfiScorpio lib
 */
class McDfiScorpio : public McDfi {
 public:
    /**
    * @brief Construct a new Mc Dfi Scorpio object
    *
    * @param init
    */
    explicit McDfiScorpio(std::shared_ptr<spdlog::logger> logger) : McDfi(logger) {}
    /**
     * @brief Destroy the Mc Dfi Scorpio object
     *
     */
    virtual ~McDfiScorpio() {}

 public:
    /**
     * @brief channel a
     *
     */
    virtual void DfiMonChaMatchPattern();
    /**
     * @brief channel b
     *
     */
    virtual void DfiMonChbMatchPattern();
    /**
     * @brief start monitor
     *
     */
    virtual void StartMon();
    /**
     * @brief clear monitor
     *
     */
    virtual void ClearMon();
    /**
     * @brief stop monitor
     *
     */
    virtual void StopMon();
    /**
     * @brief free monitor mode
     *
     */
    virtual void FreeMonMode();
    /**
     * @brief windows monitor mode
     *
     */
    virtual void WindowsMonMode();
    /**
     * @brief dfi monitor status
     *
     */
    virtual bool DfiMonStatus();
    /**
     * @brief dfi monitor counter
     *
     * @return uint32_t
     */
    virtual uint32_t DfiMonEventVal(int ch, Dfi_Event event);
    virtual void     PrintAllEventValue();
    virtual uint32_t CalCycleCounterVal();
};

}  // namespace mcdfi
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_MC_SCORPIO_MC_DFI_H_
