/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MC_SCORPIO_MC_MGR_VF_H_
#define HARDWARE_MC_SCORPIO_MC_MGR_VF_H_

#include <memory>
#include <string>
#include <vector>
#include "hardware/include/mc/mc_mgr.h"

namespace efvf {
namespace hardware {
namespace mc {
class McMgrScorpioVf : public McMgr {
 public:
    // explicit McMgrScorpio(std::shared_ptr<spdlog::logger> logger, const Dtu &dtu);
    McMgrScorpioVf(std::shared_ptr<spdlog::logger> logger, const Dtu &dtu);
    virtual ~McMgrScorpioVf() {}

    bool Init();

    //!
    //! @berif from McMgr
    //!
    void     PrintMemInfo();
    uint64_t GetTotalMemSize();

 private:
    uint64_t m_total_mem_size;
    bool     m_inited;
};

}  // namespace mc
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_MC_SCORPIO_MC_MGR_VF_H_
