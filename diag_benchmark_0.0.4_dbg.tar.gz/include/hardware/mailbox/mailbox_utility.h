/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_MAILBOX_MAILBOX_UTILITY_H_
#define HARDWARE_MAILBOX_MAILBOX_UTILITY_H_

#include <cstdint>

#include "hardware/include/mailbox.h"

typedef struct _MBX_CFG_t {
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned int MBX_CFG_ID : 9;
    unsigned int MBX_CFG_UNIQ_ID : 7;
    unsigned int MBX_CFG_REF : 11;
    unsigned int MBX_INC_MODE : 1;
    unsigned int MBX_TRG_MODE : 1;
    unsigned int MBX_CRE_MODE : 1;
    unsigned int MBX_UPD_MODE : 2;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned int MBX_UPD_MODE : 2;
    unsigned int MBX_CRE_MODE : 1;
    unsigned int MBX_TRG_MODE : 1;
    unsigned int MBX_INC_MODE : 1;
    unsigned int MBX_CFG_REF : 11;
    unsigned int MBX_CFG_UNIQ_ID : 7;
    unsigned int MBX_CFG_ID : 9;
#endif
} MBX_CFG_t;

typedef union {
    unsigned int val : 32;
    MBX_CFG_t    f;
} MBX_CFG_u;

namespace efvf {
namespace hardware {
namespace mailbox {
/**
 * @brief Mailbox status 0 register
 *
 */
struct MbxStatus0 {
#if BYTE_ORDER == LITTLE_ENDIAN
    /// MAIL_COUNTER field of MAIL_BOX_STATUS_0
    uint32_t mail_counter : 16;
    /// REF field of MAIL_BOX_STATUS_0
    uint32_t ref : 16;
#elif BYTE_ORDER == BIG_ENDIAN
    /// REF field of MAIL_BOX_STATUS_0
    uint32_t ref : 16;
    /// MAIL_COUNTER field of MAIL_BOX_STATUS_0
    uint32_t mail_counter : 16;
#endif

    /**
     * @brief default constructer
     * the default initialization values refer to register reset value
     */
    MbxStatus0() : mail_counter(0x0), ref(0x1) {}
};

/**
 * @brief Mailbox status 1 register
 *
 */
struct MbxStatus1 {
#if BYTE_ORDER == LITTLE_ENDIAN
    /// INC_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t inc_mode_config : 1;
    /// TRG_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t trg_mode_config : 1;
    /// CRE_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t cre_mode_config : 1;
    /// UDP_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t udp_mode_config : 2;
    /// UNIQ_ID field of MAIL_BOX_STATUS_1
    uint32_t uniq_id_config : 7;
    /// MASTER_ID field of MAIL_BOX_STATUS_0
    uint32_t master_id : 10;
    uint32_t : 10;
#elif BYTE_ORDER == BIG_ENDIAN
    uint32_t : 10;
    /// MASTER_ID field of MAIL_BOX_STATUS_0
    uint32_t master_id : 10;
    /// UNIQ_ID field of MAIL_BOX_STATUS_1
    uint32_t uniq_id_config : 7;
    /// UDP_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t udp_mode_config : 2;
    /// CRE_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t cre_mode_config : 1;
    /// TRG_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t trg_mode_config : 1;
    /// INC_MODE_CONFIG field of MAIL_BOX_STATUS_1
    uint32_t inc_mode_config : 1;
#endif

    /**
     * @brief default constructer
     * the default initialization values refer to register reset value
     */
    MbxStatus1()
        : inc_mode_config(0x0),
          trg_mode_config(0x0),
          cre_mode_config(0x0),
          udp_mode_config(0x0),
          uniq_id_config(0x0),
          master_id(0x0) {}
};

/**
 * @brief Mailbox status 0 bit-field helper
 *
 */
union MbxStatus0Helper {
    MbxStatus0 reg;
    uint32_t   val;

    /**
     * @brief Construct a new Mbx Status 0 Helper object
     *
     */
    MbxStatus0Helper() : val(0x0) {}
    /**
     * @brief Construct a new Mbx Status 0 Helper object
     *
     * @param val init val
     */
    MbxStatus0Helper(uint32_t val) : val(val) {}
};

/**
 * @brief Mailbox status 1 bit-field helper
 *
 */
union MbxStatus1Helper {
    MbxStatus1 reg;
    uint32_t   val;

    /**
     * @brief Construct a new Mbx Status 1 Helper object
     *
     */
    MbxStatus1Helper() : val(0x0) {}
    /**
     * @brief Construct a new Mbx Status 1 Helper object
     *
     * @param val init val
     */
    MbxStatus1Helper(uint32_t val) : val(val) {}
};

/**
 * @brief Mail box id register
 *
 */
struct MbxIdReg {
#if BYTE_ORDER == LITTLE_ENDIAN
    /// UNIQ_ID field of MAIL_BOX_STATUS_1
    uint32_t mb_id : 9;
    /// MASTER_ID field of MAIL_BOX_STATUS_0
    uint32_t uniq_id : 7;
    uint32_t : 16;
#elif BYTE_ORDER == BIG_ENDIAN
    uint32_t : 16;
    /// MASTER_ID field of MAIL_BOX_STATUS_0
    uint32_t uniq_id : 7;
    /// UNIQ_ID field of MAIL_BOX_STATUS_1
    uint32_t mb_id : 9;
#endif

    MbxIdReg() : mb_id(0x0), uniq_id(0x0) {}
};

/**
 * @brief Mail box id bit-field helper
 *
 */
union MbxIdHelper {
    MbxIdReg reg;
    uint32_t val;

    /**
     * @brief Construct a new Mbx Id Helper object
     *
     */
    MbxIdHelper() : val(0x0) {}
};

struct ErrCode0 {
#if BYTE_ORDER == LITTLE_ENDIAN
    uint32_t counter : 11;
    uint32_t ref : 11;
    uint32_t master_id : 10;
#elif BYTE_ORDER == BIG_ENDIAN
    uint32_t master_id : 10;
    uint32_t ref : 11;
    uint32_t counter : 11;
#endif
    ErrCode0() : counter(0x0), ref(0x0), master_id(0x0) {}
};

union ErrCode0Helper {
    ErrCode0 reg;
    uint32_t val;

    ErrCode0Helper() : val(0x0) {}
};

struct ErrCode1 {
#if BYTE_ORDER == LITTLE_ENDIAN
    uint32_t mbx_id : 9;
    uint32_t mbx_uniq_id : 7;
    uint32_t signaling_uniq_id : 7;
    uint32_t inc_mode : 1;
    uint32_t trg_mode : 1;
    uint32_t cre_mode : 1;
    uint32_t upd_mode : 2;
    uint32_t : 2;
    uint32_t err : 2;
#elif BYTE_ORDER == BIG_ENDIAN
    uint32_t err : 2;
    uint32_t : 2;
    uint32_t upd_mode : 2;
    uint32_t cre_mode : 1;
    uint32_t trg_mode : 1;
    uint32_t inc_mode : 1;
    uint32_t signaling_uniq_id : 7;
    uint32_t mbx_uniq_id : 7;
    uint32_t mbx_id : 9;
#endif
    ErrCode1()
        : mbx_id(0x0),
          mbx_uniq_id(0x0),
          signaling_uniq_id(0x0),
          inc_mode(0x0),
          trg_mode(0x0),
          cre_mode(0x0),
          upd_mode(0x0),
          err(0x0) {}
};

union ErrCode1Helper {
    ErrCode1 reg;
    uint32_t val;

    ErrCode1Helper() : val(0x0) {}
};

/**
 * @brief extruct register field info from mailbox status registers
 *
 * @param status0 mailbox status 0 register value
 * @param status1 mailbox status 1 register value
 * @return MbxStatus
 */
inline MbxStatus MbxStatusHelper(uint32_t status0, uint32_t status1) {
    MbxStatus        ret;
    MbxStatus0Helper s0;
    MbxStatus1Helper s1;
    s0.val              = status0;
    s1.val              = status1;
    ret.mail_counter    = s0.reg.mail_counter;
    ret.ref             = s0.reg.ref;
    ret.inc_mode_config = s1.reg.inc_mode_config;
    ret.trg_mode_config = s1.reg.trg_mode_config;
    ret.cre_mode_config = s1.reg.cre_mode_config;
    ret.udp_mode_config = s1.reg.udp_mode_config;
    ret.uniq_id_config  = s1.reg.uniq_id_config;
    ret.master_id       = s1.reg.master_id;
    return ret;
}

}  // namespace mailbox
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_MAILBOX_MAILBOX_UTILITY_H_
