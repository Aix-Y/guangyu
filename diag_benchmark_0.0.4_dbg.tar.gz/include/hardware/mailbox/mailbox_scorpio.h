/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
   \file mailbox_scorpio.h
*/

#ifndef HARDWARE_MAILBOX_MAILBOX_SCORPIO_H_
#define HARDWARE_MAILBOX_MAILBOX_SCORPIO_H_

#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "hardware/include/hardware.h"
#include "hardware/include/mailbox.h"
#include "hardware/mailbox/mailbox_utility.h"

namespace efvf {
namespace hardware {
namespace mailbox {
/**
 * @brief Mailbox Register Address Offsets for Scorpio
 * pay attention, the mailbox with entry size larger than 64 will
 * have multi group err code registers.
 */
struct MailboxScorpioParam {
    /// mailbox entry size
    uint32_t entry_size = 64;
    /// address offset for MAIL_BOX_ID
    uint32_t mail_box_id_offset = 0x0;
    /// address offset for MAIL_BOX_CONFIG
    uint32_t mail_box_config_offset = 0x0;
    /// address offset for MAIL_BOX_GLB_CONFIG
    uint32_t mail_box_glb_config_offset = 0x0;
    /// address offset for MAIL_BOX_STATUS_SEL
    uint32_t mail_box_status_sel_offset = 0x0;
    /// address offset for MAIL_BOX_STATUS_0
    uint32_t mail_box_status_0_offset = 0x0;
    /// address offset for MAIL_BOX_STATUS_1
    uint32_t mail_box_status_1_offset = 0x0;
    /// address offset for MAIL_BOX_ERR_RPT
    uint32_t mail_box_err_rpt_offset = 0x0;
    /// address offset for MAIL_BOX_BLOCK
    uint32_t mail_box_block_offset = 0x0;
    /// address offsets for MAIL_BOX_ERR_CODE_0
    std::vector<uint32_t> code0_offsets{};
    /// address offsets for MAIL_BOX_ERR_CODE_1
    std::vector<uint32_t> code1_offsets{};

    /**
     * @brief Construct a new Mailbox Scorpio Param object
     *
     */
    MailboxScorpioParam() {}
};

/**
 * @brief MailboxScorpio
 *
 */
class MailboxScorpio : public Mailbox {
 public:
    MailboxScorpio()                                = delete;
    explicit MailboxScorpio(const MailboxScorpio &) = delete;
    explicit MailboxScorpio(MailboxScorpio &&)      = delete;
    MailboxScorpio &operator=(const MailboxScorpio &) = delete;

    /**
     * @brief write register
     *
     * @param addr address offset based on ecf_addr
     * @param val write value
     */
    virtual void Write(uint32_t addr, uint32_t val) {
        hw_->RegWrite(addr, val);
    }

    /**
     * @brief read register
     *
     * @param addr address offset based on ecf_addr
     * @return uint32_t
     */
    virtual uint32_t Read(uint32_t addr) {
        return hw_->RegRead(addr);
    }

    /**
     * @brief Check whether input entry id in valid range
     *
     * @param id entry id
     */
    void CheckIdValid(uint32_t id) {
        if (id >= size()) {
            LOG_ERROR(
                "invalid mailbox entry id : 0x{:x} , mailbox entry id should in range [0x0, "
                "0x{:x})",
                id, size());
            throw std::runtime_error("invalid mailbox entry id!");
        }
    }

    /**
     * @brief Check whether input group id in valid range
     *
     * @param id group id
     */
    void CheckGroupIdValid(uint32_t id) {
        if (id >= group_size()) {
            LOG_ERROR(
                "invalid mailbox group id : 0x{:x} , mailbox group id should in range [0x0, "
                "0x{:x})",
                id, group_size());
            throw std::runtime_error("invalid mailbox entry id!");
        }
    }

    /**
     * @brief group size
     *
     * @return uint32_t
     */
    virtual uint32_t group_size() {
        return group_size_;
    }

    /**
     * @brief entry size
     *
     * @return uint32_t
     */
    virtual uint32_t size() {
        return size_;
    }

    /**
     * @brief config a mailbox entry
     *
     * @param id entry id of mailbox to config
     * @param cfg configuration info
     */
    virtual void ConfigEntry(const MbxConfig &cfg) {
        CheckIdValid(cfg.mb_id);
        MBX_CFG_u mbx_cfg         = {};
        mbx_cfg.f.MBX_CFG_ID      = cfg.mb_id;
        mbx_cfg.f.MBX_CFG_UNIQ_ID = cfg.uniq_id;
        mbx_cfg.f.MBX_CFG_REF     = cfg.ref;
        mbx_cfg.f.MBX_INC_MODE    = cfg.inc_mode;
        mbx_cfg.f.MBX_TRG_MODE    = cfg.trg_mode;
        mbx_cfg.f.MBX_CRE_MODE    = cfg.cre_mode;
        mbx_cfg.f.MBX_UPD_MODE    = cfg.upd_mode;

        // step 2: write reg
        {
            std::lock_guard<std::mutex> lk(cfg_lock_);
            Write(mail_box_glb_config_offset_, 0x0);
            Write(mail_box_config_offset_, mbx_cfg.val);
        }
    }

    /**
     * @brief clear an entry of mailbox
     * clear entry counter by config entry with default configuration
     * @param id entry id
     */
    virtual void ClearEntry(uint32_t id) {
        CheckIdValid(id);
        MbxConfig cfg;
        cfg.mb_id = id;

        MBX_CFG_u mbx_cfg         = {};
        mbx_cfg.f.MBX_CFG_ID      = cfg.mb_id;
        mbx_cfg.f.MBX_CFG_UNIQ_ID = cfg.uniq_id;
        mbx_cfg.f.MBX_CFG_REF     = cfg.ref;
        mbx_cfg.f.MBX_INC_MODE    = cfg.inc_mode;
        mbx_cfg.f.MBX_TRG_MODE    = cfg.trg_mode;
        mbx_cfg.f.MBX_CRE_MODE    = cfg.cre_mode;
        mbx_cfg.f.MBX_UPD_MODE    = cfg.upd_mode;

        // step 2: write reg
        {
            std::lock_guard<std::mutex> lk(cfg_lock_);
            Write(mail_box_glb_config_offset_, 0x0);
            Write(mail_box_config_offset_, mbx_cfg.val);
        }
    }

    /**
     * @brief config all mailbox entry with same configuration
     * all mailbox entry will be configured with same paramter
     * all mailbox entry counter will be cleared
     * @param cfg configuration info
     */
    virtual void ConfigGlobalEntry(const MbxConfig &cfg) {
        // step 1: config
        MBX_CFG_u mbx_cfg         = {};
        mbx_cfg.f.MBX_CFG_ID      = cfg.mb_id;
        mbx_cfg.f.MBX_CFG_UNIQ_ID = cfg.uniq_id;
        mbx_cfg.f.MBX_CFG_REF     = cfg.ref;
        mbx_cfg.f.MBX_INC_MODE    = cfg.inc_mode;
        mbx_cfg.f.MBX_TRG_MODE    = cfg.trg_mode;
        mbx_cfg.f.MBX_CRE_MODE    = cfg.cre_mode;
        mbx_cfg.f.MBX_UPD_MODE    = cfg.upd_mode;
        // step 2: write reg
        {
            std::lock_guard<std::mutex> lk(cfg_lock_);
            Write(mail_box_glb_config_offset_, 0x1);
            Write(mail_box_config_offset_, mbx_cfg.val);
        }
    }

    /**
     * @brief clear all mailbox entry
     * clear all entry counters by config all entry with default configuration
     */
    virtual void ClearGlobalEntry() {
        std::lock_guard<std::mutex> lk(cfg_lock_);
        Write(mail_box_glb_config_offset_, 0x1);
        Write(mail_box_config_offset_, 0x0);
    }

    /**
     * @brief send signal once
     *
     * @param id mailbox entry to send signal
     */
    virtual void SendSignal(uint32_t id) {
        CheckIdValid(id);
        uint32_t status1 = 0xffff'ffff;
        {
            std::lock_guard<std::mutex> lk(sel_lock_);
            Write(mail_box_status_sel_offset_, id);
            status1 = Read(mail_box_status_1_offset_);
        }
        MbxStatus1Helper status1_helper(status1);
        MbxIdHelper      mbxid_hepler;
        mbxid_hepler.reg.uniq_id = status1_helper.reg.uniq_id_config;
        mbxid_hepler.reg.mb_id   = id;
        Write(mail_box_id_offset_, mbxid_hepler.val);
    }

    /**
     * @brief send signal with certain uniq id once
     *
     * @param id mailbox entry to send signal
     */
    virtual void SendSignal(uint32_t id, uint32_t uniq_id) {
        CheckIdValid(id);
        // TODO(zejing.han): check uniq_id range
        MbxIdHelper mbxid_hepler;
        mbxid_hepler.reg.uniq_id = uniq_id;
        mbxid_hepler.reg.mb_id   = id;
        Write(mail_box_id_offset_, mbxid_hepler.val);
    }

    /**
     * @brief      Gets the signal address.
     *
     * @return     The signal address.
     */
    virtual uint32_t GetSignalAddr() {
        return hw_->ecf_addr_ + mail_box_id_offset_ + mail_box_block_offset_;
    }

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual uint32_t GenSignalData(uint32_t id, uint32_t uniq_id) {
        MbxIdHelper mbxid_hepler;
        mbxid_hepler.reg.uniq_id = uniq_id;
        mbxid_hepler.reg.mb_id   = id;
        return mbxid_hepler.val;
    }

    // virtual void SendSignalSeq(uint32_t id, uint32_t times)      = 0;

    /**
     * @brief send signal with certain credits
     * it may send multi signals to the entry, which depends on the entry configuration
     * it means the mailbox entry status checking will happen
     * @param id mailbox entry to send signal
     * @param uniq_id uniq id used for sending signal
     * @param credits total credits to send
     */
    virtual void SendSignalCredit(uint32_t id, uint32_t uniq_id, uint32_t credits) {
        CheckIdValid(id);
        uint32_t status0 = 0xffff'ffff;
        uint32_t status1 = 0xffff'ffff;
        {
            std::lock_guard<std::mutex> lk(sel_lock_);
            Write(mail_box_status_sel_offset_, id);
            status0 = Read(mail_box_status_0_offset_);
            status1 = Read(mail_box_status_1_offset_);
        }
        auto status_helper = MbxStatusHelper(status0, status1);

        uint32_t increase_unit = 0;
        switch (status_helper.inc_mode_config) {
            case MbxIncMode::kIncOne:
                increase_unit = 1;
                break;
            case MbxIncMode::kIncRef:
                increase_unit = status_helper.ref;
                break;
            default:
                LOG_ERROR("invalid mailbox increase mode: 0x{:x}",
                    static_cast<uint32_t>(status_helper.inc_mode_config));
                throw std::runtime_error("invalid mailbox increase mode!");
        }

        if (0 != (credits % increase_unit)) {
            LOG_ERROR("creadit 0x{:x} needs to send is not divisible by ref 0x{:x}", credits,
                increase_unit);
            throw std::runtime_error("creadit needs to send is not divisible by ref!");
        }

        MbxIdHelper mbxid_hepler;
        mbxid_hepler.reg.uniq_id = uniq_id;
        mbxid_hepler.reg.mb_id   = id;

        uint32_t send_times = credits / increase_unit;
        for (uint32_t i = 0; i < send_times; ++i) {
            Write(mail_box_id_offset_, mbxid_hepler.val);
        }
    }

    // sending signal and check error.
    // virtual bool SendSignalWithChk(uint32_t id)                         = 0;
    // virtual bool SendSignalSeqWithChk(uint32_t id, uint32_t times)      = 0;
    // virtual bool SendSignalCreditWithChk(uint32_t id, uint32_t credits) = 0;

    /**
     * @brief Get the Entry Status
     *
     * @param id entry id to get status
     * @return MbxStatus
     */
    virtual MbxStatus GetStatus(uint32_t id) {
        CheckIdValid(id);
        uint32_t status0 = 0xffff'ffff;
        uint32_t status1 = 0xffff'ffff;
        {
            std::lock_guard<std::mutex> lk(sel_lock_);
            Write(mail_box_status_sel_offset_, id);
            status0 = Read(mail_box_status_0_offset_);
            status1 = Read(mail_box_status_1_offset_);
        }
        auto status = MbxStatusHelper(status0, status1);
        return status;
    }

    /**
     * @brief Get the Entry Ref
     * get the ref value configured
     * @param id entry id to get ref
     * @return uint32_t
     */
    virtual uint32_t GetRef(uint32_t id) {
        CheckIdValid(id);
        uint32_t status0 = 0xffff'ffff;
        {
            std::lock_guard<std::mutex> lk(sel_lock_);
            Write(mail_box_status_sel_offset_, id);
            status0 = Read(mail_box_status_0_offset_);
        }
        MbxStatus0Helper status0_helper(status0);
        return status0_helper.reg.ref;
    }

    /**
     * @brief Get the Entry Mail Counter
     * get the mail counter of entry
     * @param id entry id to get mail counter
     * @return uint32_t
     */
    virtual uint32_t GetCounter(uint32_t id) {
        CheckIdValid(id);
        uint32_t status0 = 0xffff'ffff;
        {
            std::lock_guard<std::mutex> lk(sel_lock_);
            Write(mail_box_status_sel_offset_, id);
            status0 = Read(mail_box_status_0_offset_);
        }
        MbxStatus0Helper status0_helper(status0);
        return status0_helper.reg.mail_counter;
    }

    virtual uint32_t GetMasterId() {
        uint32_t status1 = 0xffff'ffff;
        {
            std::lock_guard<std::mutex> lk(sel_lock_);
            // Write(mail_box_status_sel_offset_, id);
            status1 = Read(mail_box_status_1_offset_);
        }
        MbxStatus1Helper status1_helper(status1);
        return status1_helper.reg.master_id;
    }

    // trace last mail, derived class mast make sure mbox status sel not touched
    // virtual void     TraceLastMailStart(uint32_t id) = 0;  // lock mutex?
    // virtual uint32_t GetLastMail()                   = 0;  // get status field
    // release the mutex
    // virtual void TraceLastMailStop() = 0;  // unlock?

    // chk error
    // virtual bool     ChkErr()                                        = 0;
    // virtual uint32_t GetErrGroup()                                   = 0;
    // virtual bool     ChkGroupErr(uint32_t group_id)                  = 0;
    // virtual void     GetErrInfo(uint32_t group_id, MbxErr &err_info) = 0;
    // virtual void     ClearErr(uint32_t group_id)                     = 0;
    // virtual void     ClearErr()                                      = 0;

    // for debug
    /**
     * @brief print an entry configuration to log
     *
     * @param id entry id to pring
     */
    virtual void PrintConfig(uint32_t id) {
        CheckIdValid(id);
        uint32_t status0 = 0xffff'ffff;
        uint32_t status1 = 0xffff'ffff;
        {
            std::lock_guard<std::mutex> lk(sel_lock_);
            Write(mail_box_status_sel_offset_, id);
            status0 = Read(mail_box_status_0_offset_);
            status1 = Read(mail_box_status_1_offset_);
        }
        auto status  = MbxStatusHelper(status0, status1);
        auto str_vec = status.GenStringVec();
        for (auto iter = str_vec.begin() + 1; iter != str_vec.end() - 1; ++iter) {
            PrintFormat(iter->first, iter->second);
        }
    }

    /**
     * @brief print all entry configurations to log
     *
     */
    virtual void PrintAllConfig() {
        for (uint32_t i = 0; i < size(); ++i) {
            PrintConfig(i);
        }
    }

    /**
     * @brief print an entry status to log
     *
     * @param id entry id to print
     */
    virtual void PrintStatus(uint32_t id) {
        CheckIdValid(id);
        uint32_t status0 = 0xffff'ffff;
        uint32_t status1 = 0xffff'ffff;
        {
            std::lock_guard<std::mutex> lk(sel_lock_);
            Write(mail_box_status_sel_offset_, id);
            status0 = Read(mail_box_status_0_offset_);
            status1 = Read(mail_box_status_1_offset_);
        }
        auto status  = MbxStatusHelper(status0, status1);
        auto str_vec = status.GenStringVec();
        for (auto iter = str_vec.begin(); iter != str_vec.end(); ++iter) {
            PrintFormat(iter->first, iter->second);
        }
    }

    virtual void PrintStatus() {
        uint32_t status0 = 0xffff'ffff;
        uint32_t status1 = 0xffff'ffff;
        {
            std::lock_guard<std::mutex> lk(sel_lock_);
            status0 = Read(mail_box_status_0_offset_);
            status1 = Read(mail_box_status_1_offset_);
        }
        auto        status  = MbxStatusHelper(status0, status1);
        auto        str_vec = status.GenStringVec();
        std::string res;
        for (auto iter = str_vec.begin(); iter != str_vec.end(); ++iter) {
            res += fmt::format("{}:{:#x},", iter->first, iter->second);
        }
        LOG_INFO("{}", res);
    }

    virtual uint32_t GetErrRpt() {
        return Read(mail_box_err_rpt_offset_);
    }

    virtual std::vector<uint32_t> GetErrGroup() {
        std::vector<uint32_t> err_groups;
        std::bitset<32>       flags(GetErrRpt());
        for (uint32_t gid = 0; gid < group_size(); ++gid) {
            if (flags.test(gid)) {
                err_groups.push_back(gid);
            }
        }
        return err_groups;
    }

    virtual bool ChkGroupErr(uint32_t group_id) {
        CheckGroupIdValid(group_id);
        std::vector<uint32_t> err_groups;
        std::bitset<32>       flags(GetErrRpt());
        return flags.test(group_id);
    }

    virtual void GetErrInfo(uint32_t group_id, MbxErr *err_info) {
        CheckGroupIdValid(group_id);
        ErrCode0Helper code0;
        ErrCode1Helper code1;
        code0.val               = Read(code0_offsets_[group_id]);
        code1.val               = Read(code1_offsets_[group_id]);
        err_info->group_id      = group_id;
        err_info->uniq_id_err   = false;
        err_info->overflow_err  = false;
        err_info->underflow_err = false;
        if (code1.reg.err == 0b00 /*&& code0.reg.master_id != 0*/) {
            err_info->uniq_id_err = true;
        } else if (code1.reg.err == 0b01 /*&& code0.reg.master_id != 0*/) {
            err_info->overflow_err = true;
        } else if (code1.reg.err == 0b10 && code0.reg.master_id == 0) {
            err_info->underflow_err = true;
        } else {
            LOG_ERROR("no err happened in mailbox");
            throw;
        }
        err_info->code0             = code0.val;
        err_info->code1             = code1.val;
        err_info->master_id         = code0.reg.master_id;
        err_info->ref               = code0.reg.ref;
        err_info->counter           = code0.reg.counter;
        err_info->upd_mode          = code1.reg.upd_mode;
        err_info->cre_mode          = code1.reg.cre_mode;
        err_info->trg_mode          = code1.reg.trg_mode;
        err_info->inc_mode          = code1.reg.inc_mode;
        err_info->signaling_uniq_id = code1.reg.signaling_uniq_id;
        err_info->mbx_uniq_id       = code1.reg.mbx_uniq_id;
        err_info->mbx_id            = code1.reg.mbx_id;
    }

    virtual void ClearErr() {
        for (uint32_t gid = 0; gid < group_size(); ++gid) {
            ClearErr(gid);
        }
    }

    virtual void ClearErr(uint32_t group_id) {
        CheckGroupIdValid(group_id);
        std::bitset<32> flags(0x0);
        flags.set(group_id);
        Write(mail_box_err_rpt_offset_, flags.to_ullong());
    }

    virtual void ClearErr(const std::vector<uint32_t> &group_ids) {
        for (auto gid : group_ids) {
            ClearErr(gid);
        }
    }

    /**
     * @brief print all entry status to log
     *
     */
    virtual void PrintAllStatus() {
        for (uint32_t i = 0; i < size(); ++i) {
            PrintStatus(i);
        }
    }

    /**
     * @brief print error info of a group to log
     *
     * @param group_id group id to print
     */
    virtual void PrintGroupErr(uint32_t group_id, const std::string &ip_desc = "") {
        CheckGroupIdValid(group_id);
        MbxErr err_info;
        GetErrInfo(group_id, &err_info);
        std::string err_msg = err_info.GetErrInfoStr(ip_desc);
        LOG_DEBUG("{}", err_msg);
    }

    /**
     * @brief print error info of all groups to log
     *
     */
    virtual void PrintAllErr(const std::string &ip_desc = "") {
        for (uint32_t gid = 0; gid < group_size(); ++gid) {
            PrintGroupErr(gid, ip_desc);
        }
    }

    virtual uint32_t GetCounterMaxValue() {
        return kCounterMaxValue;
    }

    /**
     * @brief get physical entry id from virtual entry id
     *
     * @param id
     * @return uint32_t
     */
    virtual uint32_t WaitId(uint32_t id) {
        CheckIdValid(id);
        return id;
    }

    /**
     * @brief Construct a new Mailbox Scorpio object
     *
     * @param size mailbox entry size
     * @param reg_cfg mailbox entry configuration
     */
    MailboxScorpio(Hardware *hw, const MailboxScorpioParam &reg_cfg)
        : group_size_(std::ceil(static_cast<float>(reg_cfg.entry_size) / 64.)),
          size_(reg_cfg.entry_size),
          mail_box_id_offset_(reg_cfg.mail_box_id_offset),
          mail_box_config_offset_(reg_cfg.mail_box_config_offset),
          mail_box_glb_config_offset_(reg_cfg.mail_box_glb_config_offset),
          mail_box_status_sel_offset_(reg_cfg.mail_box_status_sel_offset),
          mail_box_status_0_offset_(reg_cfg.mail_box_status_0_offset),
          mail_box_status_1_offset_(reg_cfg.mail_box_status_1_offset),
          mail_box_err_rpt_offset_(reg_cfg.mail_box_err_rpt_offset),
          mail_box_block_offset_(reg_cfg.mail_box_block_offset),
          code0_offsets_(reg_cfg.code0_offsets),
          code1_offsets_(reg_cfg.code1_offsets),
          hw_(hw),
          logger_(hw->get_logger()) {}

 protected:
    /**
     * @brief internal usage, print reg field name & reg field val pair to log
     *
     * @param name reg field name
     * @param val reg field value
     */
    void PrintFormat(const std::string &name, uint32_t val) {
        LOG_DEBUG("value of {} : 0x{}", name, val);
    }

    /// group size ceil(size_/64)
    uint32_t group_size_;
    /// entry size
    uint32_t size_;
    /// address offset for MAIL_BOX_ID
    uint32_t mail_box_id_offset_;
    /// address offset for MAIL_BOX_CONFIG
    uint32_t mail_box_config_offset_;
    /// address offset for MAIL_BOX_GLB_CONFIG
    uint32_t mail_box_glb_config_offset_;
    /// address offset for MAIL_BOX_STATUS_SEL
    uint32_t mail_box_status_sel_offset_;
    /// address offset for MAIL_BOX_STATUS_0
    uint32_t mail_box_status_0_offset_;
    /// address offset for MAIL_BOX_STATUS_1
    uint32_t mail_box_status_1_offset_;
    /// address offset for MAIL_BOX_ERR_RPT
    uint32_t mail_box_err_rpt_offset_;
    /// address offset for MAIL_BOX_BLOCK
    uint32_t mail_box_block_offset_;
    /// address offsets for MAIL_BOX_ERR_CODE_0
    std::vector<uint32_t> code0_offsets_;
    /// address offsets for MAIL_BOX_ERR_CODE_1
    std::vector<uint32_t> code1_offsets_;

    /// mutex for configuration
    std::mutex cfg_lock_{};
    /// mutex for status sel register
    std::mutex sel_lock_{};

    /// hardware ptr to object owning this mailbox instance
    Hardware *                      hw_     = nullptr;
    std::shared_ptr<spdlog::logger> logger_ = nullptr;

    static const uint32_t kCounterMaxValue = 0x7ffu;

 public:
    /**
     * @brief Get the Mailbox object
     *
     * @param hw hardware ptr
     * @param reg_cfg mailbox entry configuration
     * @return MailboxScorpio
     */
    static MailboxScorpio *GetMailbox(Hardware *hw, const MailboxScorpioParam &reg_cfg) {
        auto size = reg_cfg.entry_size;
        if (size > 64 && size != 128 && size != 256 && size != 512) {
            std::ostringstream oss;
            oss << "invalid size for mailbox entry 0x" << std::hex << size
                << ", must be less than 64 or 128, 256, 512!";
            throw std::runtime_error(oss.str());
        }
        if (reg_cfg.code0_offsets.size() != reg_cfg.code1_offsets.size()) {
            std::ostringstream oss;
            oss << "num of error code_0 offsets 0x" << std::hex << reg_cfg.code0_offsets.size()
                << " and num of error code_1 offsets 0x" << std::hex
                << reg_cfg.code1_offsets.size() << " mismatch!";
            throw std::runtime_error(oss.str());
        }
        if (reg_cfg.code0_offsets.size() != (size / 64)) {
            std::ostringstream oss;
            oss << "num of error code0/1 offsets 0x" << std::hex
                << reg_cfg.code0_offsets.size() << " and num of entry groups 0x" << std::hex
                << size / 64 << " mismatch!";
            throw std::runtime_error(oss.str());
        }
        return new MailboxScorpio(hw, reg_cfg);
    }
};

}  // namespace mailbox
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_MAILBOX_MAILBOX_SCORPIO_H_
