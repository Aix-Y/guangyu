/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file raf_scorpio.h
    \brief define a common register access filter
 */

#ifndef HARDWARE_COMMON_RAF_RAF_SCORPIO_H_
#define HARDWARE_COMMON_RAF_RAF_SCORPIO_H_

#include <string>
#include <memory>
#include <vector>
#include "hardware/include/raf.h"


namespace efvf {
namespace hardware {
namespace raf {
#define DEFAULT_REGION_IDX (0x000000FF)
class AddrRegionScorpio : public AddrRegion {
 public:
    /**
     * @brief Construct a new Addr Region object
     *
     * @param raf the raf
     * @param idx the address region index
     */
    AddrRegionScorpio(Hardware *raf, int idx);

    /**
     * @brief Destroy the Addr Region object
     *
     */
    virtual ~AddrRegionScorpio();

    /**
     * @brief Set the Region's Start Addr
     *
     * @param start
     */
    virtual void SetStartAddr(uint64_t start);

    /**
     * @brief Set the Region End Addr
     *
     * @param end
     */
    virtual void SetEndAddr(uint64_t end);

    /**
     * @brief Set the Master Mask
     *        block / allow specified masters.
     * @param ipmask -- each bit indicate a master
     * @param block  -- action applied to the master: block(1) or allow(0)
     */
    virtual void SetMasterMask(uint64_t ipmask, bool block = true);

    /**
     * @brief Set the Master Mask
     *        block / allow specified masters.
     * @param ips   -- ip name lists
     * @param block -- action applied to the master: block(1) or allow(0)
     */
    virtual void SetMasterMask(const std::vector<std::string> &ips, bool block = true);

    /**
     * @brief Set the Secure Level Checker
     *
     * @param level -- permitted secure level
     *        secure_level >= permited level is allowed
     */
    virtual void SetSecuLevelChecker(uint32_t level);

    /**
     * @brief Set the AxProt Checker
     *
     * @param check
     */
    virtual void SetAxProtChecker(AxProt_Checker_t check);

    /**
     * @brief Set the Read Checker
     *
     * @param rd_check
     */
    virtual void SetReadChecker(bool enable);

    /**
     * @brief Set the Write Checker
     *
     * @param wr_check
     */
    virtual void SetWriteChecker(bool enable);

 private:
    bool is_default_region = false;
    bool CheckRegValue(uint32_t addr, uint32_t expect);
    void WriteCheckSwitchOn(bool enable);
    // std::map<std::string, uint32_t>  master_id_map_;
};

class RafScorpio : public Raf {
 public:
    /**
    * @brief Construct new object of register-access-filter
    */
    explicit RafScorpio(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief Destroy the object.
     */
    virtual ~RafScorpio();

    virtual void Enable();
    virtual void Disable();

    virtual void InterruptEnable();
    virtual void InterruptDisable();

    virtual bool SetMasterSecureLevel(uint32_t level, std::string &master);
    virtual bool SetAllMasterSecureLevel(uint32_t level);

    virtual std::shared_ptr<AddrRegion> AllocAddrRegion(int idx = -1);
    virtual std::shared_ptr<AddrRegion> AllocDefaultRegion();

    virtual std::vector<Err_Log_t> GetErrorLog(bool clear);
    virtual void ClearErrorLog();

 private:
    virtual bool HwInit();
    virtual bool HwDeinit();
    virtual bool ClearAllRegion();
    bool CheckRegValue(uint32_t addr, uint32_t expect);
};

}  // namespace raf
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_RAF_RAF_SCORPIO_H_
