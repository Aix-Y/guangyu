/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_LOG_BUFFER_LOG_BUFFER_AGENT_LIBRA_H_
#define HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_LOG_BUFFER_LOG_BUFFER_AGENT_LIBRA_H_

#include <memory>
#include <vector>

#include "hardware/common/message_collector/libra/message_agent_libra.h"

namespace efvf {
namespace hardware {
namespace message_collector {

//!
//! @brief Libra log buffer agent lib
//!
class LogBufferAgentLibra : public MessageAgentLibra, public LogBufferAgent {
    static const uint32_t LOG_BUFFER_AGENT_STRIDE_IN_MC = 0xe0;

 public:
    explicit LogBufferAgentLibra(MessageCollectorLibra *mc);
    ~LogBufferAgentLibra() = default;

 public:
    //!
    //! @brief set log buffer process id
    //!
    //! @param pid: specify the log_buffer data
    void SetProcessId(uint16_t pid) override;

    //!
    //! @brief flush log buffer agent
    //!
    void Flush() override;

    //!
    //! @brief get log agent cause's ecf address
    //!
    uint32_t GetCauseAddr() override;
};

}  // namespace message_collector
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_LOG_BUFFER_LOG_BUFFER_AGENT_LIBRA_H_
