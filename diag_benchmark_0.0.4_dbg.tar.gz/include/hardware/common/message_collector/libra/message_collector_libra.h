/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_MESSAGE_COLLECTOR_LIBRA_H_
#define HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_MESSAGE_COLLECTOR_LIBRA_H_

#include <memory>
#include <vector>

#include "hardware/common/message_collector/libra/message_agent_libra.h"
#include "hardware/include/message_collector.h"

namespace efvf {
namespace hardware {
namespace message_collector {

//! Message agents index definition
enum LibraMcIndex {
    kLibraMcIndexIntExceptionToSp,
    kLibraMcIndexIntExceptionToPcie,
    kLibraMcIndexIntNormalToPcie,
    kLibraMcIndexProfiling,
    kLibraMcIndexTraceEvent,
    kLibraMcIndexCustomizedEvent,
    kLibraMcIndexLogBuffer,
    kLibraMcIndexCommunication1,
    kLibraMcIndexCommunication2,
    kLibraMcIndexCommunication3,
    kLibraMcIndexNUM,
};

//!
//! @brief libra message collector base lib
//!
//! It provides interfaces to get profiling and trace event agents
//!
class MessageCollectorLibra : public MessageCollector {
 public:
    explicit MessageCollectorLibra(std::shared_ptr<spdlog::logger> logger);
    ~MessageCollectorLibra() = default;

    void EnableMasterIDOverride() override;
    void DisableMasterIDOverride() override;

    InterruptAgent *interrupt_agent(uint8_t id = kLibraMcIndexIntNormalToPcie) override {
        assert(id <= kLibraMcIndexIntNormalToPcie);
        return dynamic_cast<InterruptAgent *>(agent(id));
    }

    InterruptAgent *int_excp_to_sp() override {
        return dynamic_cast<InterruptAgent *>(agent(kLibraMcIndexIntExceptionToSp));
    }

    InterruptAgent *int_excp_to_pcie() override {
        return dynamic_cast<InterruptAgent *>(agent(kLibraMcIndexIntExceptionToPcie));
    }

    InterruptAgent *int_normal_to_pcie() override {
        return dynamic_cast<InterruptAgent *>(agent(kLibraMcIndexIntNormalToPcie));
    }

    ProfilingAgent *profiling_agent() override {
        return dynamic_cast<ProfilingAgent *>(agent(kLibraMcIndexProfiling));
    }

    TraceEventAgent *trace_event_agent() override {
        return dynamic_cast<TraceEventAgent *>(agent(kLibraMcIndexTraceEvent));
    }

    CustomizedEventAgent *customized_event_agent() override {
        return dynamic_cast<CustomizedEventAgent *>(agent(kLibraMcIndexCustomizedEvent));
    }

    LogBufferAgent *log_buffer_agent() override {
        return dynamic_cast<LogBufferAgent *>(agent(kLibraMcIndexLogBuffer));
    }
};

}  // namespace message_collector
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MESSAGE_COLLECTOR_LIBRA_MESSAGE_COLLECTOR_LIBRA_H_
