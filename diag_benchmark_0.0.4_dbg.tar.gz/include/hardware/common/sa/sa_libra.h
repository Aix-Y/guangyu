/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file raf_libra.h
    \brief define a common register access filter
 */

#ifndef HARDWARE_COMMON_SA_SA_LIBRA_H_
#define HARDWARE_COMMON_SA_SA_LIBRA_H_

#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include "hardware/include/system_adapter.h"

namespace efvf {
namespace hardware {
namespace system_adapter {

class SystemAdapterLibra : public SystemAdapter {
 public:
    SystemAdapterLibra(std::shared_ptr<spdlog::logger> logger, const std::string &prefix)
        : SystemAdapter(logger), prefix_(prefix) {}
    virtual ~SystemAdapterLibra() = default;

 public:
    //!
    //! @brief configure AxUser info
    //!
    //! @param master_id: 10-bit master id, -1 if no change of it
    //! @param die_id: 1 bit die id, -1 if no change of it
    //! @param context_id: 4 bit context id, -1 if no change of it
    //! @param asid: 4 bit asid, -1 if no change of it
    //!
    void SetAxUser(
        int32_t master_id, int32_t die_id, int32_t context_id, int32_t asid) override;
    uint32_t GetAxUser() override;

    Xmc * cf_slave_xmc() override;
    Xmc * cf_master_xmc() override;
    Ecmo *cf_slave_ecmo() override;
    Ecmo *cf_master_ecmo() override;
    Absp *cf_slave_absp() override;
    Absp *extcf_slave_absp() override;
    Abmp *cf_master_abmp() override;
    Abmp *extcf_master_abmp() override;
    Raf * raf() override;

    // ip_regmodel
    Pmc *             pmc() override;
    MessageCollector *mc() override;

    // df_regmodel
    Ecmo *df_master_ecmo(int index = 0) override;
    Ecmo *df_slave_ecmo(int index = 0) override;
    Xmc *df_master_xmc(int index = 0) override;
    Abmp *df_master_abmp(int index = 0) override;
    Absp *df_slave_absp(int index = 0) override;
    Bpm *bpm(int index = 0) override;

 private:
    std::string prefix_;
};

}  // namespace system_adapter
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_SA_SA_LIBRA_H_
