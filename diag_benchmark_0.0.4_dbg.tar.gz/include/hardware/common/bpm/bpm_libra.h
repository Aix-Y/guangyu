/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_COMMON_BPM_BPM_LIBRA_H_
#define HARDWARE_COMMON_BPM_BPM_LIBRA_H_

#include <memory>
#include "hardware/include/bpm.h"

namespace efvf {
namespace hardware {
namespace pmc {

class BpmLibra : public Bpm {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit BpmLibra(std::shared_ptr<spdlog::logger> logger) : Bpm(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~BpmLibra() {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  time  The time
     */
    virtual void ConfigSingleMode(uint64_t time, bool tigger = true);
    virtual void SingleModeTigger();

    /**
     * @brief      { function_description }
     */
    virtual void CleanupSingleMode();

    /**
     * @brief      Gets the result.
     */
    virtual void GetResult(BpmResult *res);

    /**
     * @brief      Prints a result.
     */
    virtual void PrintResult();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual Pmc *PmcMode() {
        return pmc_.get();
    }

 private:
    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual void LibInit();

    /**
     * @brief      Gets the bpm idle status.
     *
     * @return     The bpm idle status.
     */
    virtual bool GetBpmIdleStatus();

    /**
     * @brief      { function_description }
     *
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitBpmIdleStatus();

    /**
     * @brief      Gets the bpm ready status.
     *
     * @return     The bpm ready status.
     */
    virtual bool GetBpmReadyStatus();

    /**
     * @brief      { function_description }
     *
     * @param[in]  timeout  The timeout
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitBpmReadyStatus();

    std::shared_ptr<Pmc> pmc_;

    uint64_t time_ = 0;
};

}  // namespace pmc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_BPM_BPM_LIBRA_H_
