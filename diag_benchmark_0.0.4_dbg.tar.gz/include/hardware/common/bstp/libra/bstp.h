/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

/*!
    \file bstp.h
    \brief define a common axi bus master parity lib
 */

#ifndef HARDWARE_COMMON_BSTP_LIBRA_BSTP_H_
#define HARDWARE_COMMON_BSTP_LIBRA_BSTP_H_

#include <memory>
#include <string>
#include <vector>

#include "hardware/include/bstp.h"

namespace efvf {
namespace hardware {
namespace bstp {

/*!
 * @brief BstpLibra lib
 */
class BstpBcLibra : public Bstp {
 public:
    /*!
     * @brief bstp constructors
     */
    explicit BstpBcLibra(std::shared_ptr<spdlog::logger> logger);

    /*!
     * @brief desctructor
     */
    virtual ~BstpBcLibra();

 public:
    /*!
      * @brief get bstp error status
      */
    virtual bool BstpGetErrStat(void);

    /*!
      * @brief clean error status
      */
    virtual void BstpClearErrStat(void);

    /*!
      * @brief start error inject
      */
    virtual void BstpStartErrInject(std::string inj_type);

    /*!
      * @brief stop error inject
      */
    virtual void BstpStopErrInject(std::string inj_type);

    /*!
      * @brief dump bstp channel debug info
      */
    virtual void BstpChnlDebugDump(std::vector<std::string> &infos);

 private:
    Hardware *BstpGetItems(std::string);
};

class BstpBlLibra : public Bstp {
 public:
    /*!
     * @brief bstp constructors
     */
    explicit BstpBlLibra(std::shared_ptr<spdlog::logger> logger);

    /*!
     * @brief desctructor
     */
    virtual ~BstpBlLibra();

 public:
    /*!
      * @brief get bstp error status
      */
    virtual bool BstpGetErrStat(void);

    /*!
      * @brief clean error status
      */
    virtual void BstpClearErrStat(void);

    /*!
      * @brief start error inject
      */
    virtual void BstpStartErrInject(std::string inj_type);

    /*!
      * @brief stop error inject
      */
    virtual void BstpStopErrInject(std::string inj_type);

    /*!
      * @brief dump bstp channel debug info
      */
    virtual void BstpChnlDebugDump(std::vector<std::string> &infos);

 private:
    Hardware *BstpGetItems(std::string);
};

class BstpBrLibra : public Bstp {
 public:
    /*!
     * @brief bstp constructors
     */
    explicit BstpBrLibra(std::shared_ptr<spdlog::logger> logger);

    /*!
     * @brief desctructor
     */
    virtual ~BstpBrLibra();

 public:
    /*!
      * @brief get bstp error status
      */
    virtual bool BstpGetErrStat(void);

    /*!
      * @brief clean error status
      */
    virtual void BstpClearErrStat(void);

    /*!
      * @brief start error inject
      */
    virtual void BstpStartErrInject(std::string inj_type);

    /*!
      * @brief stop error inject
      */
    virtual void BstpStopErrInject(std::string inj_type);

    /*!
      * @brief dump bstp channel debug info
      */
    virtual void BstpChnlDebugDump(std::vector<std::string> &infos);

 private:
    Hardware *BstpGetItems(std::string);
};

class BstpTcLibra : public Bstp {
 public:
    /*!
     * @brief bstp constructors
     */
    explicit BstpTcLibra(std::shared_ptr<spdlog::logger> logger);

    /*!
     * @brief desctructor
     */
    virtual ~BstpTcLibra();

 public:
    /*!
      * @brief get bstp error status
      */
    virtual bool BstpGetErrStat(void);

    /*!
      * @brief clean error status
      */
    virtual void BstpClearErrStat(void);

    /*!
      * @brief start error inject
      */
    virtual void BstpStartErrInject(std::string inj_type);

    /*!
      * @brief stop error inject
      */
    virtual void BstpStopErrInject(std::string inj_type);

    /*!
      * @brief dump bstp channel debug info
      */
    virtual void BstpChnlDebugDump(std::vector<std::string> &infos);

 private:
    Hardware *BstpGetItems(std::string);
};

class BstpTlLibra : public Bstp {
 public:
    /*!
     * @brief bstp constructors
     */
    explicit BstpTlLibra(std::shared_ptr<spdlog::logger> logger);

    /*!
     * @brief desctructor
     */
    virtual ~BstpTlLibra();

 public:
    /*!
      * @brief get bstp error status
      */
    virtual bool BstpGetErrStat(void);

    /*!
      * @brief clean error status
      */
    virtual void BstpClearErrStat(void);

    /*!
      * @brief start error inject
      */
    virtual void BstpStartErrInject(std::string inj_type);

    /*!
      * @brief stop error inject
      */
    virtual void BstpStopErrInject(std::string inj_type);

    /*!
      * @brief dump bstp channel debug info
      */
    virtual void BstpChnlDebugDump(std::vector<std::string> &infos);

 private:
    Hardware *BstpGetItems(std::string);
};

class BstpTrLibra : public Bstp {
 public:
    /*!
     * @brief bstp constructors
     */
    explicit BstpTrLibra(std::shared_ptr<spdlog::logger> logger);

    /*!
     * @brief desctructor
     */
    virtual ~BstpTrLibra();

 public:
    /*!
      * @brief get bstp error status
      */
    virtual bool BstpGetErrStat(void);

    /*!
      * @brief clean error status
      */
    virtual void BstpClearErrStat(void);

    /*!
      * @brief start error inject
      */
    virtual void BstpStartErrInject(std::string inj_type);

    /*!
      * @brief stop error inject
      */
    virtual void BstpStopErrInject(std::string inj_type);

    /*!
      * @brief dump bstp channel debug info
      */
    virtual void BstpChnlDebugDump(std::vector<std::string> &infos);

 private:
    Hardware *BstpGetItems(std::string);
};

class BstpRasLibra : public BstpRas {
 public:
    explicit BstpRasLibra(Bstp *bstp);
    virtual ~BstpRasLibra();

    /**
     * @brief enable ras
     */
    virtual void Enable(RasCfg *cfg);

    /**
     * @brief disable ras
     */
    virtual void Disable(RasCfg *cfg);

    /**
     * @brief start ras inject
     */
    virtual void StartErrInjection(RasCfg *cfg, RasErrInj *err_inj);

    /**
     * @brief stop ras inject
     */
    virtual void StopErrInjection(RasCfg *cfg, RasErrInj *err_inj);

    /**
     * @brief query err
     */
    virtual void QueryErrStatus(RasCfg *cfg, RasErrStat *err_stat);

    /**
     * @brief clear err
     */
    virtual void ClearErrStatus(RasCfg *cfg);

    /**
     * @brief print err
     */
    virtual void PrintErrStatus(RasCfg *cfg) {}

    /**
     * @berif get ras cfg
     *
     * @param      cfg   The configuration
     */
    virtual void GetRasCfg(RasCfg *cfg) {}

    /**
     * @brief enable interrupt
     */
    virtual void EnableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief disable interrupt
     */
    virtual void DisableInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief clear interrupt
     */
    virtual void ClearInterrupt(IntrptCfg *cfg) {}

    /**
     * @berif save interrupt
     */
    virtual void QueryInterrupt(IntrptCfg *cfg, IntrptStat *stat) {}

    /**
     * @brief print interrupt
     */
    virtual void PrintInterrupt(IntrptCfg *cfg) {}

    /**
     * @brief      { function_description }
     *
     * @param[in]  type     The type
     * @param[in]  is_stop  is stopping err inj?
     *
     * @return     { description_of_the_return_value }
     */
    virtual RasErrInj *GenRasErrInjCfg(const std::string &type, bool is_stop = false);

 private:
    Bstp *bstp_;
};

}  // namespace bstp
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_BSTP_LIBRA_BSTP_H_
