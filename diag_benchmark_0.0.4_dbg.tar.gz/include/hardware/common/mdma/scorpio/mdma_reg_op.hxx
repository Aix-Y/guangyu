/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MDMA_SCORPIO_MDMA_REG_OP_HXX_
#define HARDWARE_COMMON_MDMA_SCORPIO_MDMA_REG_OP_HXX_

#include "device/dtus/scorpio/register_soc.h"

#define __reg_f_g(_val, _reg, _f)                                 \
({                                                                \
    _reg##_u u_reg = { .val = _val };                             \
    (u_reg.f._f);                                                 \
})

#define __reg_f_s(_val, _reg, _f, _fv)                            \
({                                                                \
    _reg##_u u_reg = { .val = _val };                             \
    u_reg.f._f = (_fv);                                           \
    (u_reg.val);                                                  \
})

#define __regr32f(_reg, _f, _addr)                                \
(                                                                 \
    __reg_f_g(__regr32(_addr), _reg, _f)                          \
)

#define __regw32f(_reg, _f, _addr, _fv)                           \
(                                                                 \
    __regw32(_addr, __reg_f_s(__regr32(_addr), _reg, _f, (_fv)))  \
)

#define __regr32(_addr)                         (hpd_regr32((_addr)))
#define __regw32(_addr, _val)                   (hpd_regw32((_addr), (_val)))
#define __reg_o(_reg)                           (_reg##_OFFSET)

#define regr32(_reg)                            (__regr32(__reg_o(_reg)))
#define regw32(_reg, _val)                      (__regw32(__reg_o(_reg), (_val)))
#define regr32f(_reg, _f)                       (__regr32f(_reg, _f, __reg_o(_reg)))
#define regw32f(_reg, _f, _fv)                  (__regw32f(_reg, _f, __reg_o(_reg), (_fv)))

#endif  // HARDWARE_COMMON_MDMA_SCORPIO_MDMA_REG_OP_HXX_
