/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MDMA_SCORPIO_MDMA_COMP_HQS_QUEUE_H_
#define HARDWARE_COMMON_MDMA_SCORPIO_MDMA_COMP_HQS_QUEUE_H_

#include "hardware/include/mdma/mdma.h"

namespace efvf {
namespace hardware {
namespace mdma {

class MdmaCHqsQueueScorpio : public MdmaCHqsQueue {
 public:
    explicit MdmaCHqsQueueScorpio(Mdma *dma, MdmaEngineCompDesc_t &comp)
        : MdmaCHqsQueue(dma, comp) {}
    virtual ~MdmaCHqsQueueScorpio() {}

 public:
    void HandleCfg(const MdmaCfg &);

 private:
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MDMA_SCORPIO_MDMA_COMP_HQS_QUEUE_H_
