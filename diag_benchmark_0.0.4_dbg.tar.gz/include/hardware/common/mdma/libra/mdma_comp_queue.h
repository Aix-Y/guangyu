/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_QUEUE_H_
#define HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_QUEUE_H_

#include "hardware/include/mdma/mdma.h"

namespace efvf {
namespace hardware {
namespace mdma {

typedef struct _MdmaCommandPointerLibra {
    uint32_t fence : 1;       // fence flag
    uint32_t dependency : 1;  // dependency flag
    uint32_t mcp : 20;        // MDMA command buffer pointer
    uint32_t asid : 4;        // mcp asid
    uint32_t priority : 2;    // priority
    uint32_t ctx : 4;         // context id
} MdmaCommandPointerLibra;

class MdmaCQueueLibra : public MdmaCQueue {
 public:
    explicit MdmaCQueueLibra(Mdma *dma, MdmaEngineCompDesc_t &comp) : MdmaCQueue(dma, comp) {}
    virtual ~MdmaCQueueLibra() {}

 public:
    void HandleCfg(const MdmaCfg &);
    bool Flush(void) override;
    bool LaunchCmd(const MdmaCommandPointer &mcp) override;
    bool     IsEmpty(void) override;
    bool     IsFull(void) override;
    uint32_t FreeSize(void) override;
    uint32_t UsedSize(void) override;
    bool     IsBusy(void) override;
    uint32_t CurMcp(void) override;

 private:
    void set_queue_entry(uint32_t val);
    uint32_t get_queue_entry();
    void set_queue_ctrl_enable(bool enable);
    bool get_queue_ctrl_enable();
    void set_queue_ctrl_input_sel(bool val);
    bool get_queue_ctrl_input_sel();
    void set_queue_ctrl_pri_mode(bool val);
    bool get_queue_ctrl_pri_mode();
    void set_queue_ctrl_flush(bool val);
    bool get_queue_ctrl_flush();
    void set_queue_ctrl_pri_thld(uint32_t val);
    uint32_t get_queue_ctrl_pri_thld();
    uint32_t get_queue_status_free_entry_num();
    bool     get_queue_status_full();
    uint32_t get_queue_status_used_entry_num();
    bool     get_queue_status_empty();
    void set_queue_status_ovfl(bool val);
    uint32_t get_queue_cur_mcp();
    uint32_t get_queue_idle_status();

 private:
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MDMA_LIBRA_MDMA_COMP_QUEUE_H_
