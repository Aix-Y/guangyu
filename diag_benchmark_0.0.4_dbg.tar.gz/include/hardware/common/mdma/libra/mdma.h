/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_COMMON_MDMA_LIBRA_MDMA_H_
#define HARDWARE_COMMON_MDMA_LIBRA_MDMA_H_

#include <memory>
#include <utility>
#include <vector>

#include "hardware/include/mdma/mdma.h"

#include "hardware/common/mdma/libra/mdma_comp_common.h"
#include "hardware/common/mdma/libra/mdma_comp_hqs_queue.h"
#include "hardware/common/mdma/libra/mdma_comp_hqs_top.h"
#include "hardware/common/mdma/libra/mdma_comp_mpq.h"
#include "hardware/common/mdma/libra/mdma_comp_polling.h"
#include "hardware/common/mdma/libra/mdma_comp_queue.h"
#include "hardware/common/mdma/libra/mdma_comp_vc.h"

namespace efvf {
namespace hardware {
namespace mdma {

struct GatherDescHeader {
    /*address DW 0*/
    uint32_t addr_31_0;  // gather address
    /*address DW 1*/
    uint32_t addr_47_32 : 16;
    uint32_t burst_length : 4;  // Burst length
    uint32_t rsvd : 8;
    uint32_t offset_flag : 1;  // Offset flag
    uint32_t idc_flag : 1;     // ID change flag
    uint32_t inv_flag : 1;     // invalid flag
    uint32_t last_flag : 1;    // last flag
};

struct ScatterDescHeader {
    /*address DW 0*/
    uint32_t addr_31_0;  // scatter addr 48bit
    /*address DW 1*/
    uint32_t addr_47_32 : 16;
    uint32_t burst_length : 4;  // Burst length
    uint32_t rsvd : 8;
    uint32_t tdc : 1;          // Template data change flag
    uint32_t offset_flag : 1;  // Offset flag
    uint32_t sr_flag : 1;      // Signal resource flag
    uint32_t fw_flag : 1;      // Fake write flag
};

struct MdmaCommandHeader {
    uint32_t id : 5;  // 4:0, static id only for linear copy when im = 1
    // 0: dynamic id
    // 1: static id specifed by 4:0
    uint32_t id_mode : 1;         // 5, id mode only for linear copy
    uint32_t fence : 1;           // 6, fence flag
    uint32_t last : 1;            // 7, last flag
    uint32_t op : 4;              // 11:8, operation
    uint32_t static_inst_en : 1;  // 12, static instance enable
    uint32_t static_inst : 3;     // 15:13, static instance number
    uint32_t wc : 4;              // 19:16, write cacheable attribution
    uint32_t rc : 4;              // 23:20, read cacheable attribution
    uint32_t len : 8;             // 31:24, dword length of command includingheader
};

struct MdmaLinearCopyCmd {
    /* header */
    struct MdmaCommandHeader header;
    /*body*/
    uint32_t src_addr_31_0;  // copy source address, support 48bit addr
    uint32_t dst_addr_31_0;  // copy destination address, support 48bit addr
    uint32_t dst_addr_47_32 : 16;
    uint32_t src_addr_47_32 : 16;
    uint32_t size;                 // copy data size in byte
    uint32_t sig_addr_47_32 : 16;  // signaling target address
    uint32_t sig_en : 1;           // signaling target enable
    uint32_t rsvd : 7;
    uint32_t aw_asid : 4;  // virtual memory address id
    uint32_t ar_asid : 4;  // virtual memory address id
    uint32_t sig_addr_31_0;
    uint32_t sig_data;           // signaling target data
    uint32_t awuser_35_20 : 16;  // awuser bits[35:20] on cf/df
    uint32_t aruser_35_20 : 16;  // aruser bits[35:20] on cf/df
};

struct MdmaScatterCmd {
    /* header */
    struct MdmaCommandHeader header;
    /*body*/
    uint32_t desc_addr;       // descriptor addr，point to local memory
    uint32_t desc_size : 16;  // descriptor size in byte
    uint32_t rsvd_0 : 16;
    uint32_t scatter_offset;       // scatter offset
    uint32_t resource_id;          // scatter resource id
    uint32_t sig_addr_47_32 : 16;  // signaling target address
    uint32_t sig_en : 1;           // signaling target enable
    uint32_t sig_mode : 1;         // signaling target mode
    uint32_t rsvd_1 : 6;
    uint32_t aw_asid : 4;  // virtual memory address id
    uint32_t ar_asid : 4;  // virtual memory address id
    uint32_t sig_addr_31_0;
    uint32_t sig_data;           // signaling target data
    uint32_t awuser_35_20 : 16;  // awuser bits[35:20] on cf/df
    uint32_t rsvd_2 : 16;
};

struct MdmaDerivedScatterCmd {
    /* header */
    struct MdmaCommandHeader header;
    /*body*/
    uint32_t template_desc_addr;       // template descriptor address
    uint32_t template_desc_size : 16;  // template scatter descriptor size inbyte
    uint32_t derived_desc_size : 16;   // derived scatter descriptor size inbyte
    uint32_t scatter_offset;           // scatter offset
    uint32_t resource_id;              // scatter resource id
    uint32_t derived_desc_addr;        // derived descriptor addr，point to localmemory
    uint32_t sig_addr_47_32 : 16;      // signaling target address
    uint32_t sig_en : 1;               // signaling target enable
    uint32_t sig_mode : 1;             // signaling target mode
    uint32_t rsvd_0 : 6;
    uint32_t aw_asid : 4;  // virtual memory address id
    uint32_t ar_asid : 4;  // virtual memory address id
    uint32_t sig_addr_31_0;
    uint32_t sig_data;           // signaling target data
    uint32_t awuser_35_20 : 16;  // awuser bits[35:20] on cf/df
    uint32_t rsvd_1 : 16;
};

class MdmaLibra : public Mdma {
 public:
    /**
     * @brief      mcu dma constructor
     *
     * @param[in]  logger
     */
    explicit MdmaLibra(std::shared_ptr<spdlog::logger> logger);

    /**
     * @brief      mcu dma desctructor
     */
    virtual ~MdmaLibra();

    /**
     * @brief      mcu dma hw init
     */
    bool HwInit(void);

    /**
     * @brief      mcu dma engine type support check
     */
    bool IsEngineSupport(const MdmaEngine_t &);

    /**
     * @brief      mcu dma engine type specify
     */
    bool SetEngineType(const MdmaEngine_t &);

    /**
     * @brief      mcu dma engine comp fetch max num
     */
    uint32_t GetEngineCompNum(const MdmaComp_t &);

    /**
     * @brief      mcu dma engine comp fetch by type.inst
     *
     * @param[in]  comp type and inst index (default inst.0)
     */
    std::shared_ptr<MdmaComp> GetEngineComp(const MdmaComp_t &, uint32_t = 0);

    /**
     * @brief      mcu dma engine config
     *
     * @param[in]  comp type vs cfg vs inst index (default inst.0)
     */
    void CfgEngineComp(const MdmaComp_t &, const MdmaCfg &, uint32_t inst = 0);

    /**
     * @brief      dma linear copy
     *
     * @param[in]  src Engine view data source addr
     * @param[in]  dst Engine view data destination addr
     * @param[in]  siz Engine copy data bytes
     * @param[in]  vc  Engine vc inst idx (if not specified, pick available)
     *
     * @return     status [true] done or [false] error
     */
    bool LinearCopy(const uint64_t &src, const uint64_t &dst, const uint32_t &siz,
        uint32_t vc = NON_SPECIFIED) override;

    /**
     * @brief config linear copy and trigger
     *
     * @param opt_cfg  mdma linear copy info
     *
     * @return         True if success, False otherwise.
     */
    bool LinearCopy(const MdmaLinearCopyCfg &opt_cfg, uint32_t vc = NON_SPECIFIED) override;

    /**
     * @brief      dma constant filling
     *
     * @param[in]  dst Engine view data destination addr
     * @param[in]  siz Engine fill data bytes
     * @param[in]  pat Engine fill data pattern
     * @param[in]  vc  Engine vc inst idx (if not specified, pick available)
     *
     * @return     status [true] done or [false] error
     */
    bool ConstFill(const uint64_t &dst, const uint32_t &siz, const uint32_t &pat,
        uint32_t vc = NON_SPECIFIED) override;

    /**
     * @brief config constant filling and trigger
     *
     * @param opt_cfg  mdma constant filling info
     *
     * @return         True if success, False otherwise.
     */
    bool ConstFill(const MdmaConstFillCfg &opt_cfg, uint32_t vc = NON_SPECIFIED) override;

    /**
     * @brief      dma scatter
     *
     * @param[in]  des Engine view data descriptor addr
     * @param[in]  siz Engine view data descriptor size
     * @param[in]  vc  Engine vc inst idx (if not specified, pick available)
     *
     * @return     status [true] done or [false] error
     */
    bool Scatter(
        const uint64_t &des, const uint32_t &siz, uint32_t vc = NON_SPECIFIED) override;

    /**
     * @brief config scatter and trigger
     *
     * @param opt_cfg  mdma scatter info
     *
     * @return         True if success, False otherwise.
     */
    bool Scatter(const MdmaScatterCfg &opt_cfg, uint32_t vc = NON_SPECIFIED) override;

    /**
     * @brief      dma scatter derived
     *
     * @param[in]  des_t Engine view data descriptor addr template
     * @param[in]  des_d Engine view data descriptor addr derived
     * @param[in]  siz_t Engine view size descriptor template
     * @param[in]  siz_d Engine view size descriptor derived
     * @param[in]  vc    Engine vc inst idx (if not specified, pick available)
     *
     * @return     status [true] done or [false] error
     */
    bool ScatterDerived(const uint64_t &des_t, const uint64_t &des_d, uint32_t &siz_t,
        uint32_t &siz_d, uint32_t vc = NON_SPECIFIED) override;

    /**
     * @brief config derived scatter and trigger
     *
     * @param opt_cfg  mdma derived scatter info
     *
     * @return         True if success, False otherwise.
     */
    bool ScatterDerived(
        const MdmaScatterDerivedCfg &opt_cfg, uint32_t vc = NON_SPECIFIED) override;

    /**
     * @brief      dma gather
     *
     * @param[in]  des Engine view data descriptor addr
     * @param[in]  dst Engine view data gather-dat addr
     * @param[in]  vc  Engine vc inst idx (if not specified, pick available)
     *
     * @return     status [true] done or [false] error
     */
    bool Gather(
        const uint64_t &des, const uint32_t &dst, uint32_t vc = NON_SPECIFIED) override;

    /**
     * @brief config gather and trigger
     *
     * @param opt_cfg  mdma gather info
     *
     * @return         True if success, False otherwise.
     */
    bool Gather(const MdmaGatherCfg &opt_cfg, uint32_t vc = NON_SPECIFIED) override;

    /**
     * @brief   flush command queue
     *
     * @return  True if success, False otherwise.
     */
    bool CmdQueueFlush(uint32_t qid = NON_SPECIFIED) override;

    /**
     * @brief write mcp to command queue
     *
     * @param mcp    mdma command pointer info
     *
     * @return       True if success, False otherwise.
     */
    bool CmdQueueLaunchCmd(
        const MdmaCommandPointer &mcp, uint32_t qid = NON_SPECIFIED) override;
    /**
     * @brief    check command queue is empty
     *
     * @return   True if empty ,false if has mcp
     */
    bool CmdQueueIsEmpty(uint32_t qid = NON_SPECIFIED) override;
    /**
     * @brief    check command queue is full
     *
     * @return   True if full ,false if has free
     */
    bool CmdQueueIsFull(uint32_t qid = NON_SPECIFIED) override;

    /**
     * @brief    get command queue free size
     *
     * @return   free size
     */
    uint32_t CmdQueueFreeSize(uint32_t qid = NON_SPECIFIED) override;

    /**
     * @brief   get command queue used queue
     *
     * @return  used size
     */
    uint32_t CmdQueueUsedSize(uint32_t qid = NON_SPECIFIED) override;

    /**
     * @brief build scatter descriptor
     *
     * @param scatter_info <uint64_t, uint32_t> represents destination <addr,data>
     * @param offset_flag  offset flag
     * @param sig_res_flag signal resource flag
     * @param desc_data    descriptor data
     * @param desc_len     descriptor len
     *
     * @return             True if success, False otherwise.
     */
    bool BuildScatterDesc(const std::vector<std::pair<uint64_t, uint32_t>> &scatter_info,
        const bool offset_flag, const std::vector<bool> &sig_res_flag, uint32_t *desc_data,
        uint32_t &desc_len) override;

    /**
     * @brief build Derived Scatter descriptor
     * derived descriptor just have data
     * when template desc TDC=1, will use derived desc corresponding data
     * @param template_info        represents template info <addr,data>
     * @param offset_flag          offset flag
     * @param sig_res_flag         signal resource flag
     * @param template_desc_data   template descriptor data
     * @param template_desc_len    template descriptor len
     * @param derived_info         represents derived info
     * @param derived_desc_data    derived descriptor data
     * @param derived_desc_len     derived descriptor len
     *
     * @return             True if success, False otherwise.
     */
    bool BuildScatterDerivedDesc(const std::vector<MdmaScatterTemplateInfo> &template_info,
        const bool offset_flag, const std::vector<bool> &sig_res_flag,
        uint32_t *template_desc_data, uint32_t &template_desc_len,
        const std::vector<uint32_t> &derived_info, uint32_t *derived_desc_data,
        uint32_t &derived_desc_len) override;

    /**
     * @brief build Gather descriptor
     *
     * @param gather_info  <uint64_t, uint32_t> represents src <addr,dwlen>
     * @param offset_flag  offset flag
     * @param desc_data    descriptor data
     * @param desc_len     descriptor len
     *
     * @return             True if success, False otherwise.
     */
    bool BuildGatherDesc(const std::vector<std::pair<uint64_t, uint32_t>> &gather_info,
        const bool offset_flag, uint32_t *desc_data, uint32_t &desc_len) override;

    /**
     * @brief build LinearCopy Command
     * command consist of header and body
     * @param opt_cfg     linear copy cfg
     * @param cmd_data    Command data
     * @param cmd_len     Command len
     * @param last        Command last flag
     *
     * @return            True if success, False otherwise.
     */
    bool BuildLinearCopyCmd(const MdmaLinearCopyCfg &opt_cfg, uint32_t *cmd_data,
        uint32_t &cmd_len, bool last = false) override;

    /**
     * @brief build Scatte Command
     * command consist of header and body
     * @param opt_cfg     Scatte cfg
     * @param cmd_data    Command data
     * @param cmd_len     Command len
     * @param last        Command last flag
     *
     * @return            True if success, False otherwise.
     */
    bool BuildScatterCmd(const MdmaScatterCfg &opt_cfg, uint32_t *cmd_data, uint32_t &cmd_len,
        bool last = false) override;

    /**
     * @brief build Derived Scatter Command
     * command consist of header and body
     * @param opt_cfg     Derived Scatter cfg
     * @param cmd_data    Command data
     * @param cmd_len     Command len
     *
     * @return            True if success, False otherwise.
     */
    bool BuildDerivedScatterCmd(const MdmaScatterDerivedCfg &opt_cfg, uint32_t *cmd_data,
        uint32_t &cmd_len, bool last = false) override;

 private:
    /**
     * @brief      mcu dma engine desc setup per ip
     */
    bool SetEngineTypePerIp(const MdmaEngine_t &);

    /**
     * @brief      mcu dma engine desc setup
     */
    bool SetEngineTypeSp(void);

    /**
     * @brief      mcu dma engine desc setup
     */
    bool SetEngineTypeAp(void);

    /**
     * @brief      mcu dma engine desc setup
     */
    bool SetEngineTypeVpu(void);

    /**
     * @brief      mcu dma engine desc setup
     */
    bool SetEngineTypeSsm(void);

    /**
     * @brief      mcu dma engine desc setup
     */
    bool SetupEngineComps(void);

    /**
     * @brief      mcu dma engine ready set
     */
    bool SetEngineReady(bool);

    /**
     * @brief      mcu dma engine ready get
     */
    bool IsEngineReady(void);

 private:
    MdmaEngineDesc_t                                 m_engine_desc     = {};
    std::vector<std::shared_ptr<MdmaCCommonLibra>>   m_comps_common    = {};
    std::vector<std::shared_ptr<MdmaCPollingLibra>>  m_comps_polling   = {};
    std::vector<std::shared_ptr<MdmaCVcLibra>>       m_comps_vc        = {};
    std::vector<std::shared_ptr<MdmaCQueueLibra>>    m_comps_queue     = {};
    std::vector<std::shared_ptr<MdmaCHqsQueueLibra>> m_comps_hqs_queue = {};
    std::vector<std::shared_ptr<MdmaCHqsTopLibra>>   m_comps_hqs_top   = {};
    std::vector<std::shared_ptr<MdmaCMpqLibra>>      m_comps_mpq       = {};
};

}  // namespace mdma
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_MDMA_LIBRA_MDMA_H_
