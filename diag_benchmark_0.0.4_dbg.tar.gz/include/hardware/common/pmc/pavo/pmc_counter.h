/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_COMMON_PMC_PAVO_PMC_COUNTER_H_
#define HARDWARE_COMMON_PMC_PAVO_PMC_COUNTER_H_

#include <stdint.h>
#include <memory>
#include <string>

#include "hardware/include/pmc.h"

namespace efvf {
namespace hardware {
namespace pmc {

class PmcCounterPavo {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param      pmc   The pmc
     * @param[in]  cnt   The count
     */
    PmcCounterPavo(Hardware *pmc, int cnt)
        : pmc_(pmc), cnt_(cnt), logger_(pmc->get_logger()) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~PmcCounterPavo() {}

    /**
     * @brief      Resets the object.
     */
    virtual void Reset();

    /**
     * @brief      { function_description }
     */
    virtual void Start();

    /**
     * @brief      { function_description }
     */
    virtual void Stop();

    /**
     * @brief      { function_description }
     */
    virtual void CounterSelSetting();

    /**
     * @brief      ignore when hardware and cvalue mode.
     *
     * @return     The result.
     */
    virtual uint64_t GetResult();

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     *
     * @return     { description_of_the_return_value }
     */
    inline uint32_t RegRead(uint64_t offset) {
        return pmc_->RegRead(offset);
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  offset  The offset
     * @param[in]  val     The value
     */
    inline void RegWrite(uint64_t offset, uint32_t val) {
        pmc_->RegWrite(offset, val);
    }

    Hardware *pmc_        = nullptr;
    bool      actived_    = false;
    int       cnt_        = -1;
    int       state_      = 0;
    int       evt_or_cvl_ = 0;
    int       start_sel_  = 0;
    int       stop_sel_   = 0;
    int       int_mask_   = 0;
    uint32_t  cvalue_     = 0;
    int       state_sel_  = 0;
    int       rpt_count_  = 1;
    int       inc_mode_   = 2;
    uint32_t  event_      = 0;

    std::string event_desc_;

    std::shared_ptr<spdlog::logger> logger_;
};

}  // namespace pmc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_PMC_PAVO_PMC_COUNTER_H_
