/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_COMMON_PMC_SCORPIO_PMC_COUNTER_H_
#define HARDWARE_COMMON_PMC_SCORPIO_PMC_COUNTER_H_

#include <stdint.h>
#include <memory>
#include "hardware/common/pmc/pavo/pmc_counter.h"

namespace efvf {
namespace hardware {
namespace pmc {

class PmcCounterScorpio : public PmcCounterPavo {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param      pmc   The pmc
     * @param[in]  cnt   The count
     */
    PmcCounterScorpio(Hardware *pmc, int cnt) : PmcCounterPavo(pmc, cnt) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~PmcCounterScorpio() {}

    /**
     * @brief      Resets the object.
     */
    virtual void Reset();

    /**
     * @brief      { function_description }
     */
    virtual void Start();

    /**
     * @brief      { function_description }
     */
    virtual void Stop();

    /**
     * @brief      { function_description }
     */
    virtual void CounterSelSetting();

    /**
     * @brief      Gets the result.
     *
     * @return     The result.
     */
    virtual uint64_t GetResult();
};

}  // namespace pmc
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_COMMON_PMC_SCORPIO_PMC_COUNTER_H_
