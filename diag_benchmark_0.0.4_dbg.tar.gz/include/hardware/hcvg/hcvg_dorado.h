/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_HCVG_HCVG_DORADO_H_
#define HARDWARE_HCVG_HCVG_DORADO_H_

#include "hardware/include/hcvg/hcvg.h"

namespace efvf {
namespace hardware {
namespace hcvg {
DefineHcvg(DORADO, HcvgDorado, HCVG_TOP_REGBLOCK);

}  // namespace hcvg
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_HCVG_HCVG_DORADO_H_
