/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_SP_LIBRA_CUSTOM_MEM_MGR_H_
#define HARDWARE_SP_LIBRA_CUSTOM_MEM_MGR_H_

#include <memory>
#include <mutex>
#include <utility>
#include <vector>
#include "framework/include/log.h"
#include "hpd/mem_mgr/ivt_policy.h"
#include "smgr/include/spm.h"

namespace efvf {
namespace hardware {
namespace sp {

class CustomMemMgr;
class CustomMemBlock {
    friend class CustomMemMgr;

 public:
    /**
    * @brief      Constructs a new instance.
    *
    * @param[in]  logger    logger
    */
    explicit CustomMemBlock(std::shared_ptr<spdlog::logger> logger) : logger_(logger) {}

    /**
    * @brief      Move Constructor.
    *
    * @param[in]  rho    Right-hand operand
    */
    CustomMemBlock(CustomMemBlock &&rho) noexcept {
        size_          = rho.size_;
        range_start_   = rho.range_start_;
        root_node_     = rho.root_node_;
        mgr_node_      = rho.mgr_node_;
        success_       = rho.success_;
        offset_        = rho.offset_;
        dev_addr_      = rho.dev_addr_;
        host_addr_     = rho.host_addr_;
        host_ptr_      = rho.host_ptr_;
        logger_        = rho.logger_;
        rho.root_node_ = rho.mgr_node_ = nullptr;
        rho.logger_                    = nullptr;
    }

    /**
    * @brief      Move Assignment Operator.
    *
    * @param[in]  rho    Right-hand operand
    */
    CustomMemBlock &operator=(CustomMemBlock &&rho) noexcept {
        if (this != &rho) {
            size_          = rho.size_;
            range_start_   = rho.range_start_;
            root_node_     = rho.root_node_;
            mgr_node_      = rho.mgr_node_;
            success_       = rho.success_;
            offset_        = rho.offset_;
            dev_addr_      = rho.dev_addr_;
            host_addr_     = rho.host_addr_;
            host_ptr_      = rho.host_ptr_;
            logger_        = rho.logger_;
            rho.root_node_ = rho.mgr_node_ = nullptr;
            rho.logger_                    = nullptr;
        }
        return *this;
    }

    /**
     * @brief      Destroys the object.
     */
    virtual ~CustomMemBlock() {
        if (root_node_ != nullptr && mgr_node_ != nullptr) {
            // LOG_DEBUG("custom_mem: free {:#x} {:#x}, size {:#x}", host_addr_, dev_addr_[0],
            //    ivt_node_size(mgr_node_));
            ivt_put_node(root_node_, mgr_node_);
        }
    }

    /**
     * @brief      GetDevAddr
     *
     * @return     return DevAddr
     */
    const std::vector<uint64_t> &GetDevAddr() const {
        return dev_addr_;
    }

    /**
     * @brief      GetSize
     *
     * @return     return Size
     */
    uint64_t GetSize() const {
        return size_;
    }

    /**
     * @brief      GetHostPtr
     *
     * @return     return HostPtr
     */
    uint64_t GetHostAddr() const {
        return host_addr_;
    }

    /**
     * @brief      GetHostPtr
     *
     * @return     return HostPtr
     */
    uint8_t *GetHostPtr() const {
        return host_ptr_;
    }

    /**
     * @brief      GetMemOffset
     *
     * @return     return Offset
     */
    uint64_t GetMemOffset() const {
        return offset_;
    }

 protected:
    uint64_t                        size_{0};
    uint64_t                        range_start_{0};
    void *                          root_node_{nullptr};
    void *                          mgr_node_{nullptr};
    bool                            success_{false};
    uint64_t                        offset_{0};
    uint64_t                        host_addr_{0};
    uint8_t *                       host_ptr_{};
    std::vector<uint64_t>           dev_addr_{};
    std::shared_ptr<spdlog::logger> logger_{nullptr};
};

class CustomMemMgr {
 public:
    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  dev_addr  dev_addr
     * @param[in]  host_ptr  host_ptr
     * @param[in]  mem_size  mem_size
     * @param[in]  logger    logger
     */
    CustomMemMgr(uint64_t dev_addr, uint64_t host_addr, uint8_t *host_ptr, uint64_t mem_size,
        std::shared_ptr<spdlog::logger> logger)
        : dev_addr_(dev_addr),
          host_addr_(host_addr),
          host_ptr_(host_ptr),
          mem_size_(mem_size),
          logger_(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~CustomMemMgr() {
        std::unique_lock<std::mutex> lk(obj_mut_);
        if (MaxContiSize() != mem_size_) {
            LOG_WARN("custom_mem_mgr_ has unreleased resources");
        }
        if (custom_mem_mgr_) {
            LOG_DEBUG("del custom_mem_mgr_");
            ivt_destroy(custom_mem_mgr_);
            custom_mem_mgr_ = nullptr;
        }
        lk.unlock();
    }

    /**
     * @brief      malloc a CustomMemBlock
     *
     * @param[in]  malloc_size    size
     * @param[in]  malloc_offset  offset
     * @param[in]  malloc_align   align
     *
     * @return     return one CustomMemBlock
     */
    virtual CustomMemBlock Malloc(
        uint64_t malloc_size, uint64_t malloc_offset = 0, uint32_t malloc_align = 1) {
        std::unique_lock<std::mutex> lk(obj_mut_);
        if (mem_size_ != 0 && custom_mem_mgr_ == nullptr) {
            LOG_DEBUG("create custom_mem_mgr_");
            custom_mem_mgr_ = ivt_create(dev_addr_, mem_size_);
        }
        lk.unlock();
        uint64_t s_off = malloc_offset;
        uint64_t e_off = mem_size_;

        auto range = ivt_get_node(custom_mem_mgr_, malloc_size, malloc_align, s_off, e_off);
        if (range == nullptr) {
            LOG_ASSERT(0, "custom_mem: malloc fail, {:#x}", malloc_size);
        }

        CustomMemBlock resp(logger_);
        //! fill resp
        resp.root_node_ = custom_mem_mgr_;
        resp.mgr_node_  = range;
        resp.offset_    = ivt_node_start(range) - dev_addr_;
        resp.size_      = malloc_size;

        resp.dev_addr_.push_back(dev_addr_ + resp.offset_);
        resp.host_ptr_  = host_ptr_ + resp.offset_;
        resp.host_addr_ = host_addr_ + resp.offset_;
        resp.success_   = true;

        // LOG_DEBUG(
        //    "custom_mem: malloc success {:#x}, size {:#x}", resp.dev_addr_[0], resp.size_);
        return resp;
    }

    /**
     * @brief      free one CustomMemBlock
     *
     * @param      resp  The CustomMemBlock
     */
    virtual void Free(CustomMemBlock &resp) {
        LOG_DEBUG("custom_mem: free {:#x}, size {:#x}", resp.dev_addr_[0],
            ivt_node_size(resp.mgr_node_));
        ivt_put_node(custom_mem_mgr_, resp.mgr_node_);
    }

    /**
     * @brief      get MaxContiSize
     *
     * @return     MaxContiSize
     */
    virtual uint64_t MaxContiSize(void) {
        uint64_t size = ivt_max_range_size(custom_mem_mgr_);
        return size;
    }

 protected:
    std::mutex                      obj_mut_{};
    spm_h                           custom_mem_mgr_{nullptr};
    uint64_t                        dev_addr_{0};
    uint64_t                        host_addr_{0};
    uint8_t *                       host_ptr_{nullptr};
    uint64_t                        mem_size_{0};
    std::shared_ptr<spdlog::logger> logger_{nullptr};
};

}  // namespace sp
}  // namespace hardware
}  // namespace efvf
#endif  // HARDWARE_SP_LIBRA_CUSTOM_MEM_MGR_H_
