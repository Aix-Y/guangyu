/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_ESL_LIBRA_ESL_MGR_H_
#define HARDWARE_ESL_LIBRA_ESL_MGR_H_
#include <map>
#include <memory>
#include <string>
#include <vector>
#include "device/dtus/libra/register_soc.h"
#include "hardware/esl/libra/esl.h"
#include "framework/include/utils.h"
#include "framework/utils/utils_etable.h"

using efvf::framework::lock::PLock;
using efvf::framework::utils::Etable;

namespace efvf {
namespace hardware {
namespace esl {

class EslMgrLibra : public EslMgr {
 public:
    explicit EslMgrLibra(std::shared_ptr<spdlog::logger> logger);
    virtual ~EslMgrLibra();

    virtual bool Init();
    virtual bool Deinit();
    virtual bool Init(uint32_t server_id, bool over_net);
    virtual bool Deinit(uint32_t server_id);
    virtual bool Bind(const EslCtx &ctx);
    virtual bool Bind(const EslCtx &ctx, bool mstr_side);
    virtual bool IsConnected(const EslCtx &ctx);
    virtual void ConnectionInfo(const EslCtx &ctx);
    virtual bool QueueLevelReset(const EslQpCfg &qp_cfg);
    virtual bool GlobalInit(Dtu *esl_dtu);
    virtual void InitMtt(uint32_t mtt_idx);

    virtual bool CtxInit(EslCtx &ctx);
    virtual bool CtxInit(EslCtx &ctx, bool mstr_side, uint32_t client_idx, Esl *local_esl);
    virtual bool CtxDeInit(EslCtx &ctx);

    // sip commands
    virtual bool SendSipCmd(uint32_t dev_id, SIP_CMD &cmd);

    virtual bool StartSC();
    virtual bool StopSC();

    virtual void SetNonBlocking(int fd);
    virtual void StatisticPrint();

    virtual std::string GetPortPairKey(PortPair &pair);
    virtual PortPair GetKeyPortPair(const std::string &key_str);

    virtual bool SyncReady(uint32_t client_idx, bool mstr_side = true, uint32_t interval = 200,
        uint32_t timeout_l = 60);
    virtual bool TriggerRemoteCmp(uint32_t client_idx, bool mstr_side, bool qp_mstr,
        std::shared_ptr<EslCtx> l_qpctx, bool remote_clear = true);
    virtual bool ReplyCmpRes(uint32_t client_idx, bool mstr_side, bool qp_mstr,
        std::shared_ptr<EslCtx> l_qpctx, uint64_t loop);
    virtual bool ReplyClearRes(
        uint32_t client_idx, bool mstr_side, bool qp_mstr, std::shared_ptr<EslCtx> l_qpctx);

    virtual bool TrySendCmd(
        uint32_t client_id, uint32_t msg_type, PortPair dev_port_pair, bool mstr_side = false);
    virtual bool SetMem(EslCpCtxTran &ctx, uint32_t client_idx, bool mstr_side, bool qp_mstr,
        std::shared_ptr<EslCtx> l_qpctx);
    virtual bool SyncTrafficEnd(uint32_t client_idx, uint32_t timeout_l = 60);

    virtual void ClientFunc(uint32_t client_idx);
    virtual void ServerFunc();
    virtual void ServerInner(struct sockaddr_in clientaddr, int clientfd);
    virtual bool SendCmd(uint32_t client_idx, InteractCmd &cmd);
    virtual void ProcessRData(char *ptr);
    virtual void TrafficCount(uint32_t client_idx, int send, int cmd_ack, int succeed);
    virtual uint32_t GetIpIdx(std::string ip);
    virtual bool FilterIp(const std::string &line, std::vector<std::string> &res);
    virtual bool GetServerCfg(const std::string &fn);
    virtual void CmdHandler(InteractCmd &cmd, uint32_t client_idx);

    uint32_t GetEslDevCount() {
        return m_dev_esl_map.size();
    }

    std::map<int, std::vector<Esl *> > GetAllEslDevMap() {
        return m_dev_esl_map;
    }

    virtual Dtu *GetDtu(int dev_id);
    virtual EslLibra *GetEslHw(int dev_id, uint32_t port_id);

    virtual uint64_t DevAddrToEslOB(uint64_t ipa, uint32_t port_id) {
        return ipa - ESL_CONST_96T + ESL_CONST_96T + port_id * ESL_CONST_8T;
    }

    virtual uint64_t EslOBToDevAddr(uint64_t ob_addr, uint32_t port_id) {
        return ob_addr + ESL_CONST_5T - port_id * ESL_CONST_8T - ESL_CONST_96T;
    }

    virtual uint64_t EslOBToElsIntAddr(uint64_t ob_addr, uint32_t port_id) {
        return ob_addr - port_id * ESL_CONST_8T - ESL_CONST_96T;
    }

    virtual void CtxDump(EslCtx &ctx);
    virtual std::string FormatString(const uint8_t *in_char, uint8_t len,
        const std::string deli, const std::string format = "hex");

    virtual uint32_t GetMttEntryNum() {
        return 1024U;
    }
    virtual int Dump(MonitorCfg &cfg);
    virtual int DumpEslDevice(int dev_id, const DeviceCfg &cfg, Etable& mon_tab);
    virtual int DumpEslPort(int dev_id, int port_id, const PortCfg &cfg, Etable& port_tab);
    virtual int DumpEslQp(int dev_id, int port_id, const QpCfg &cfg, Etable& mon_tab);

 private:
    void ConvertQpConfig(const EslQpCfg &src_qpc, EslQpCfg &dst_qpc);

 private:
    std::map<int, std::vector<Esl *> > m_dev_esl_map = {};
};

}  // namespace esl
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_ESL_LIBRA_ESL_MGR_H_
