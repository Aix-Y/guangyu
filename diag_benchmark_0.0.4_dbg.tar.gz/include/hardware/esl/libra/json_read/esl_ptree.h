/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_ESL_LIBRA_JSON_READ_ESL_PTREE_H_
#define HARDWARE_ESL_LIBRA_JSON_READ_ESL_PTREE_H_

#include <string>
#include "device/include/dtu.h"

boost::property_tree::ptree GetCfgTree(const std::string &cfg);

#endif  // HARDWARE_ESL_LIBRA_JSON_READ_ESL_PTREE_H_
