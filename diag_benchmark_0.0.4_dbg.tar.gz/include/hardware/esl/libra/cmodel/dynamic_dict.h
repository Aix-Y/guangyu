/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */

#ifndef HARDWARE_ESL_LIBRA_CMODEL_DYNAMIC_DICT_H_
#define HARDWARE_ESL_LIBRA_CMODEL_DYNAMIC_DICT_H_

#include <algorithm>
#include <bitset>
#include <deque>
#include <vector>
#include "hardware/esl/libra/cmodel/config.h"
#define DICTION_DEPTH 11
class DynDict {
 private:
    deque<uint8_t> dict                = deque<uint8_t>(11, 0);
    deque<uint8_t> dict_propagation    = deque<uint8_t>(11, 0);
    deque<string>  de_dict             = deque<string>(11, "00");
    deque<string>  de_dict_propagation = deque<string>(11, "00");
    pair<uint8_t, uint16_t> *code_table;
    uint32_t des_data_bit_len;

 public:
    void gen_code_table();
    void dict_initialize(uint8_t *init_dict);
    string is_entropy_dict_pattern_match(uint8_t data_type, uint8_t data, uint32_t sym_idx);
    uint32_t   get_comp_data_size();
    data_desc *data_pack(string cmp_data);
    uint8_t *decmp_match(uint8_t data_type, string cmp_data, uint8_t dst_data_num,
        uint8_t whether_init, uint8_t *init_dict);
};
data_desc *DynDict_compression(
    DynDict *dyn_dict, data_desc *uncmp_data, uint8_t whether_init, uint8_t *init_dict);
uint8_t *DynDict_decompression(DynDict *dyn_dict, uint8_t data_type, string cmp_data,
    uint8_t dst_data_num, uint8_t whether_init, uint8_t *init_de_dict);
#endif  // HARDWARE_ESL_LIBRA_CMODEL_DYNAMIC_DICT_H_