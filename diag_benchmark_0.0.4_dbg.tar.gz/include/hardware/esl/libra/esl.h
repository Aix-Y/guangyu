/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_ESL_LIBRA_ESL_H_
#define HARDWARE_ESL_LIBRA_ESL_H_
#include <map>
#include <memory>
#include <string>
#include <vector>
#include "device/dtus/libra/register_soc.h"
#include "hardware/include/esl/esl.h"

// using efvf::hardware::esl::Esl;
namespace efvf {
namespace hardware {
namespace esl {

#define MAC_FORM_LOW(name)                                                             \
    ((static_cast<uint32_t>(name[2]) << 24) | (static_cast<uint32_t>(name[3]) << 16) | \
        (static_cast<uint32_t>(name[4]) << 8) | (static_cast<uint32_t>(name[5])))
#define MAC_FORM_HI(name) \
    ((static_cast<uint32_t>(name[0]) << 8) | (static_cast<uint32_t>(name[1])))

#define IP_FORM(name)                                                                  \
    ((static_cast<uint32_t>(name[0]) << 24) | (static_cast<uint32_t>(name[1]) << 16) | \
        (static_cast<uint32_t>(name[2]) << 8) | (static_cast<uint32_t>(name[3])))

class EslLibra : public Esl {
 public:
    EslLibra() {}
    explicit EslLibra(std::shared_ptr<spdlog::logger> logger);
    virtual ~EslLibra() {}

    virtual bool HwInit();
    virtual bool HwDeinit();

    virtual uint32_t GetPortNum();

    bool PhyInit();
    bool MacInit(uint32_t rate = 5, uint32_t fec = 2, uint32_t rmode = 2);
    void MacInit200GR4Rs544();
    void MacInit100GR2Rs544();
    void MacInit100GR4Rs528();
    void MacInit50GR1Rs544();
    void MacInit10GR1NoFec();
    bool SetLoopback(const std::string &lb_type, bool enable);
    // bool         MacInitSsm();
    bool             SysInit();
    virtual bool     GlobalInit();
    virtual bool     IsLinkUp();
    virtual uint32_t LineRate();

    // test registers
    virtual std::vector<uint32_t> GetTestRegisters();
    virtual std::vector<uint32_t> GetInternalTestRegs();
    virtual uint32_t              GetEslEcfObOffset();

    // NNC api
    virtual void BypassNnc(bool bypass);
    virtual void BypassNnc(uint32_t st);
    virtual void GetNncBypassSta(uint32_t &st);
    virtual uint32_t GetNncCrSts();
    virtual void InitNncDict(uint32_t val1, uint32_t val2, uint32_t val3);
    virtual void StartNncCr(uint32_t range);
    virtual void CfgCrRange(uint32_t range);
    virtual uint32_t GetNncRawSize();
    virtual uint32_t GetNncCmpSize();
    virtual float    CalCompRate();

    // wcb api
    virtual void WcbEnable(bool enable);

    virtual void QpcConfig(const EslQpCfg &cfg);
    virtual void SetQpcDestMac(const uint32_t qid, uint64_t mac);
    virtual void SetQpcDestIp(const uint32_t qid, uint32_t ip);
    virtual void UpdateProdPtr(EslQpCfg &cfg, uint32_t inc_val);
    virtual uint32_t ProdPtr(uint32_t qid);
    virtual uint32_t ConsPtr(uint32_t qid);

    virtual uint64_t GetMacAddr(uint32_t idx);
    virtual void GetMacAddr(uint32_t idx, uint8_t *ptr);
    virtual void SetMacAddr(uint32_t idx, uint64_t mac);
    virtual void SetMacAddr(uint32_t idx, uint8_t *mac_ptr);

    virtual uint32_t GetIpAddr(uint32_t idx);
    virtual void GetIpAddr(uint32_t idx, uint8_t *ptr);
    virtual void SetIpAddr(uint32_t idx, uint32_t ip_addr);
    virtual void SetIpAddr(uint32_t idx, uint8_t *ip_ptr);

    bool GetMacCheck(bool val);
    void SetMacCheck(bool val);
    bool GetIpCheck(bool val);
    void SetIpCheck(bool val);

    virtual const std::vector<uint32_t> GetBlockRegisters();

    virtual void SetTxdPfcBuffDscp(uint32_t buff_id, uint32_t dscp_val);
    virtual void SetTxcPfcBuffDscp(uint32_t buff_id, uint32_t dscp_val);
    virtual uint32_t GetTxdPfcBuffDscp(uint32_t buff_id);
    virtual uint32_t GetTxcPfcBuffDscp(uint32_t buff_id);
    virtual void SetPfcMapTxBuff(uint32_t buff_id, uint32_t pause_bit);
    virtual uint32_t GetPfcMapTxBuff(uint32_t buff_id);

    virtual void SetPfcMapAckCnp(uint32_t buff_id, uint32_t pause_bit);

    virtual bool QLR(uint32_t qid);
    virtual bool QLR(uint32_t qid, const EslQpCfg &cfg);
    virtual bool QLR(const EslCtx &ctx, bool mstr_queue);
    virtual void QDisable(uint32_t qid);
    virtual void QEnable(uint32_t qid, uint32_t tx_buff_id = 0, uint32_t asid = 0);
    virtual void QIntHandle(uint32_t qid, uint32_t int_pos, const EslQpCfg &cfg);
    virtual void EslErrHandle();

    virtual void SetRetryTimerThd(uint32_t qid, uint32_t val, uint32_t to_ms = 1000,
        uint32_t timer_src = 0, uint32_t retry_mode = 0);

    virtual bool SqConfig(const EslQpCfg &qpc);
    virtual void RetryBufferConfig(const uint64_t addr, const uint32_t size);

    // slave mode
    virtual uint32_t GetMttMbit();
    virtual void SetMttMbit(uint32_t mbit_val);
    virtual void SetMtte(
        uint64_t in_addr, uint64_t out_addr, uint32_t trans_bitN, uint32_t source_qid);
    virtual void UpdateMtteAddr(uint64_t in_addr, uint64_t out_addr);
    virtual void UpdateMtteQid(uint64_t in_addr, uint32_t queue_id);

    virtual uint32_t GetAvaliableQueue(bool rand_queue = false);
    virtual bool GetQueue(uint32_t qid);
    virtual void ReleaseQueue(const uint32_t qid);
    virtual bool QueueOccupied(const uint32_t qid);
    virtual bool QueueInited(const uint32_t qid);
    virtual void SetQueueInit(const uint32_t qid, bool val);

    virtual bool Submit(EslQpCfg &qpc, Wqe *src_wqe, uint32_t wqe_num, bool launch);
    virtual bool Submit(EslQpCfg &qpc, std::vector<Wqe> &src_wqe, bool launch);
    virtual void Launch(EslQpCfg &qpc, uint32_t wqe_num);
    virtual bool WaitForIdle(EslQpCfg &qpc, uint32_t timeout_s = 0);
    virtual void WqeDump(Wqe *wqe);
    virtual void PortPktDump(EslPortPktMonitor *port_pkt_monitor = nullptr);

    void WinCntConfig(uint32_t cyc_val = 1000000U);
    void WinCntDump(const uint32_t sel_mask, WinCntMonitor *win_cnt_monitor);
    void AxiLatDump(const uint32_t axi_lat_mask_sel = 0x3U);
    void AxiLatCfg(const LatSeg seg);
    void EthLatCfg(const LatSeg seg);
    void QStubCfg(const std::map<int, uint32_t> stub_cfg, const uint32_t stub_mask,
        uint32_t mode_mask = 0xf);
    void EthLatDump(const uint32_t eth_lat_q_mask_sel);
    void QueueRateDump(const uint32_t q_stub_mask_sel,
        EslQueueRateMonitor *q_rate_monitor_p = nullptr, uint32_t *qpn_stub_p = nullptr);

    // ST PKT
    void StPktClear(const uint32_t st_pkt_mask = 0xf);
    void StPktDump(const uint32_t st_pkt_mask);

    // RAS
    virtual void ErrorSnapshot(uint32_t qid);
    virtual void EslErrInj(const std::string type, ErrInjCfg &inj_cfg, bool wait_done);
    virtual void ClearErrCnt();
    virtual void ClearBlackHoleErrCnt();
    virtual void ErrCntDump(bool clr_cnt = true);

    // SQ
    uint64_t SqBaseAddr(uint32_t qid);
    uint32_t SqSize(uint32_t qid);

    // xoff/xon thd
    void SetXoffThd(uint32_t val);
    uint32_t GetXoffThd(void);
    void SetXonThd(uint32_t val);
    uint32_t GetXonThd(void);

    // rx cc  ctrl
    void SetTxCcCtrl(bool val);
    void CcConfig(uint32_t qid, bool val);

    // basic Nic
    bool NicEnable(NicCfg &cfg);
    bool NicDisable(NicCfg &cfg);
    void NicSubmit(std::vector<NicDesc> &desc_v, bool launch);
    void NicUpdateTxPtr(uint32_t val);
    bool NicRxValid();
    void NicGetRxDesc(std::vector<NicDesc> &rx_desc);
    bool NicWaitForIdle(uint32_t timeout_s);
    void NicCopy(uint8_t *mem_ptr, uint64_t base, uint64_t size, bool lunch);

    // RAS interface
    void SetEslRespChkEn(bool val);
    void SetEslParityChkEn(bool val);
    bool GetEslParityChkEn();
    bool GetEslRespCheckEn();
    bool CheckErrorValid();
    void ClearEslErrorStatus();
    void SramMiscErrInj(bool val);
    void MacFcsErrInj(bool val);
    bool FindRasQBitMap(uint32_t int_pos, RasQBitMapInfo &map);

    // Snapshot
    virtual int GetNicRasErr(uint32_t index, EslSnapShotInfo &info);
    virtual int GetNicOversizeDropCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetNicSopEopErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetICrcErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetIpTotLenErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetIpTotCheckSumErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetIpAddrErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetMacAddrErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetMacErrCodeCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetDecapErrCntThreshold(uint32_t index, EslSnapShotInfo &info);
    virtual int GetOversizeErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetRasRxtmReqErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetRasRxtmRspErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetRasEslRdmaOpErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetRasReqCommErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetRasRspCommErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetRasRxPauseBufferDropErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetEslPerfRxErrCntMacFcsTotal(uint32_t index, EslSnapShotInfo &info);
    virtual int GetEslPerfRxErrCntMacFcsRdma(uint32_t index, EslSnapShotInfo &info);
    virtual int GetEslPerfRxErrCntRdmaIcrc(uint32_t index, EslSnapShotInfo &info);
    virtual int GetBlackHoleRocev2ErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetBlackHoleUdpErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetBlackHoleIpv4ErrCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetQpSrcIp(uint32_t index, EslSnapShotInfo &info);
    virtual int GetQpSrcMac(uint32_t index, EslSnapShotInfo &info);
    virtual int GetQpDstIp(uint32_t index, EslSnapShotInfo &info);
    virtual int GetQpDstMac(uint32_t index, EslSnapShotInfo &info);
    virtual int GetQpSrcUdpPort(uint32_t index, EslSnapShotInfo &info);
    virtual int GetQpDstUdpPort(uint32_t index, EslSnapShotInfo &info);
    virtual int GetQpTtl(uint32_t index, EslSnapShotInfo &info);
    virtual int GetQpRemoteQp(uint32_t index, EslSnapShotInfo &info);
    virtual int GetNncCmpRate(uint32_t index, EslSnapShotInfo &info);
    virtual int GetSqWqe(uint32_t index, EslSnapShotInfo &info);
    virtual int GetWinCntMonPauseLastTx(uint32_t index, EslSnapShotInfo &info);
    virtual int GetWinCntMonPauseLastRx(uint32_t index, EslSnapShotInfo &info);
    virtual int GetWinCntMonPauseCntTx(uint32_t index, EslSnapShotInfo &info);
    virtual int GetWinCntMonPauseCntRx(uint32_t index, EslSnapShotInfo &info);
    virtual int GetQpRxTm(uint32_t index, EslSnapShotInfo &info);
    virtual int GetMacTxRdy(uint32_t index, EslSnapShotInfo &info);
    virtual int GetMacTxVldRdy(uint32_t index, EslSnapShotInfo &info);
    virtual int GetMacRxVldRdy(uint32_t index, EslSnapShotInfo &info);
    virtual int GetMacTxPps(uint32_t index, EslSnapShotInfo &info);
    virtual int GetMacTxKbps(uint32_t index, EslSnapShotInfo &info);
    virtual int GetMacRxPps(uint32_t index, EslSnapShotInfo &info);
    virtual int GetMacRxKbps(uint32_t index, EslSnapShotInfo &info);
    virtual int GetEslTxPps(uint32_t index, EslSnapShotInfo &info);
    virtual int GetEslTxKbps(uint32_t index, EslSnapShotInfo &info);
    virtual int GetEslRxPps(uint32_t index, EslSnapShotInfo &info);
    virtual int GetEslRxKbps(uint32_t index, EslSnapShotInfo &info);
    virtual int GetTotalTxPktCnt(uint32_t index, EslSnapShotInfo &info);
    virtual int GetTotalRxPktCnt(uint32_t index, EslSnapShotInfo &info);

    bool m_nic_inited = false;

 private:
    Hardware * esl_rdma_reg_ptr          = nullptr;
    Hardware * esl_ind_reg_ptr           = nullptr;
    Hardware * esl_mmu_reg_ptr           = nullptr;
    Hardware * esl_ind_qpc_reg_ptr       = nullptr;
    Hardware * esl_ind_sq_reg_ptr        = nullptr;
    Hardware * esl_ind_sa_reg_ptr        = nullptr;
    Hardware * esl_ind_mtt_reg_ptr       = nullptr;
    Hardware * esl_ind_trans_qp_reg_ptr  = nullptr;
    Hardware * esl_ind_rxtm_qp_reg_ptr   = nullptr;
    Hardware * esl_ind_wrap_reg_ptr      = nullptr;
    Hardware * esl_ind_macpcspma_reg_ptr = nullptr;
    Hardware * esl_ind_cc_qp_ptr         = nullptr;
    Hardware * esl_ind_tx_qos_ptr        = nullptr;
    std::mutex q_mtx[256]                = {};
    uint64_t   m_queue_status[4];
    uint64_t   m_queue_inited[4];

    uint8_t *   m_nic_tx_desc_ptr = nullptr;
    uint8_t *   m_nic_tx_buff_ptr = nullptr;
    uint8_t *   m_nic_rx_desc_ptr = nullptr;
    uint8_t *   m_nic_rx_buff_ptr = nullptr;
    uint8_t *   m_nic_cq_ptr      = nullptr;
    uint32_t    m_q_size_idx      = 10;
    uint64_t    m_nic_src_mac     = 0ULL;
    uint64_t    m_nic_dst_mac     = 0ULL;
    std::thread m_nic_rx_thread;
    static bool m_nic_rx_exit;
};

}  // namespace esl
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_ESL_LIBRA_ESL_H_
