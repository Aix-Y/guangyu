/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_IH_IH_PAVO_H_
#define HARDWARE_IH_IH_PAVO_H_

#include <memory>
#include "hardware/include/ih.h"

namespace efvf {
namespace hardware {
namespace ih {

class IhPavo : public Ih {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    IhPavo() : Ih() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit IhPavo(std::shared_ptr<spdlog::logger> logger) : Ih(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~IhPavo() {
        if (ring_mem_) {
            LOG_DEBUG("Free Ring buf {}", (uint64_t)ring_mem_);
            delete ring_mem_;
        }
    }

    /**
     * @brief      { function_description }
     *
     * @param[in]  cause_id  The cause identifier
     * @param[in]  userdata  The userdata
     */
    virtual void TriggerIrq(uint32_t cause_id, uint32_t userdata);

    /**
     * @brief      Gets one interrupt.
     *
     * @param      entry  The entry
     *
     * @return     One interrupt.
     */
    virtual bool GetOneIrq(IrqEntry *entry);

    /**
     * @brief      { function_description }
     *
     * @param[in]  master_id    The master identifier
     * @param[in]  cause_id     The cause identifier
     * @param      entry        The entry
     * @param[in]  timeout_sec  The timeout security
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool WaitForIrq(uint32_t master_id, uint32_t cause_id, IrqEntry *entry,
        int timeout_sec, uint32_t asid = 0);

 private:
    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwInit();

    /**
     * @brief      { function_description }
     *
     * @return     { description_of_the_return_value }
     */
    virtual bool HwDeinit();

 protected:
    uint64_t ring_dword_size_ = 0x1000;  // dword

    uint64_t ring_entry_size = 0;
    uint32_t ring_size_byte  = 0;
    uint32_t ring_size_4byte = 0;
    Mem *    ring_mem_       = nullptr;
};

class IhPavoSystem : public IhPavo {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    IhPavoSystem() : IhPavo() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit IhPavoSystem(std::shared_ptr<spdlog::logger> logger) : IhPavo(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~IhPavoSystem() {}
};

class IhPavoTs : public IhPavo {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    IhPavoTs() : IhPavo() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit IhPavoTs(std::shared_ptr<spdlog::logger> logger) : IhPavo(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~IhPavoTs() {}
};

}  // namespace ih
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_IH_IH_PAVO_H_
