/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_IH_IH_DORADO_H_
#define HARDWARE_IH_IH_DORADO_H_
#include <memory>
#include "hardware/ih/ih_pavo.h"
namespace efvf {
namespace hardware {
namespace ih {

class IhDoradoSystem : public IhPavoSystem {
 public:
    /**
     * @brief      Constructs a new instance.
     */
    IhDoradoSystem() : IhPavoSystem() {}

    /**
     * @brief      Constructs a new instance.
     *
     * @param[in]  logger  The logger
     */
    explicit IhDoradoSystem(std::shared_ptr<spdlog::logger> logger) : IhPavoSystem(logger) {}

    /**
     * @brief      Destroys the object.
     */
    virtual ~IhDoradoSystem() {}
};

}  // namespace ih
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_IH_IH_DORADO_H_
