/**
 *
 * Enflame Tech, All Rights Reserved. 2024 Copyright (C)
 *
 */
#ifndef HARDWARE_ECMO_SCORPIO_ECMO_H_
#define HARDWARE_ECMO_SCORPIO_ECMO_H_

#include <iomanip>
#include <iostream>
#include <memory>
#include <vector>
#include "hardware/include/ecmo.h"
#include "hardware/include/hardware.h"

namespace efvf {
namespace hardware {
namespace ecmo {

class ScorpioMstrEcmo : public Ecmo {
 public:
    explicit ScorpioMstrEcmo(std::shared_ptr<spdlog::logger> logger);
    virtual ~ScorpioMstrEcmo();

    virtual bool HwInit() {
        return true;
    }
    virtual bool HwDeinit() {
        return true;
    }

    // single ECMO instance stop&idle
    void Stop(bool val);
    bool Idle();
    void Config(const EcmoCfg &cfg);
    void Status(EcmoSts &sts);
    void StatusDump(const EcmoSts &sts);
};

class ScorpioSlvEcmo : public Ecmo {
 public:
    explicit ScorpioSlvEcmo(std::shared_ptr<spdlog::logger> logger);
    virtual ~ScorpioSlvEcmo();

    virtual bool HwInit() {
        return true;
    }
    virtual bool HwDeinit() {
        return true;
    }

    // single ECMO instance stop&idle
    void Stop(bool val);
    bool Idle();
    void Config(const EcmoCfg &cfg);
    void Status(EcmoSts &sts);
    void StatusDump(const EcmoSts &sts);
};

}  // namespace ecmo
}  // namespace hardware
}  // namespace efvf

#endif  // HARDWARE_ECMO_SCORPIO_ECMO_H_
